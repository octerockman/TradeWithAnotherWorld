using System;

namespace BlackAbbeySixRooms
{
    internal static class WindowProjectionReceiverPolicy
    {
        // RoomPackage puts authored room visuals on static_solid. Restrict the
        // three RGB cookie lights to those surfaces: forward-rendered native
        // dust/steam must not pick up a competing red/green/blue channel light.
        // Candle lights keep their original masks and natural warm illumination.
        internal static int Mask(int solidLayer,int glassLayer)
        {
            if(solidLayer<0||solidLayer>31||glassLayer<8||glassLayer>31||solidLayer==glassLayer)
                throw new InvalidOperationException("Window projection requires distinct valid stone/glass receiver layers.");
            return 1<<solidLayer;
        }
    }
}
