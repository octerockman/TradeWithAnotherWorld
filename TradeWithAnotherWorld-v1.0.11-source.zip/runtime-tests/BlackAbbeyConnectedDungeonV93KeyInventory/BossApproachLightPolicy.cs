using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // The approach occupies negative source Z; the accepted nave is Z >= 0.
    // Adjust only candle reach/brightness here, never emission or global bloom.
    internal static class BossApproachLightPolicy
    {
        internal const float IntensityScale = .75f, Range = 8.5f;
        internal static bool Applies(string roomId, IEnumerable<double> wickZ)
        {
            if (roomId != "R09"&&!R09SplitIdentity.IsHall(roomId)) return false;
            if (wickZ == null) throw new InvalidDataException("Missing approach wick coordinates.");
            var coordinates = wickZ.ToArray();
            if (coordinates.Length == 0 || coordinates.Any(z => double.IsNaN(z) || double.IsInfinity(z)))
                throw new InvalidDataException("Invalid approach wick coordinates.");
            if (coordinates.Any(z => z < 0) && coordinates.Any(z => z >= 0))
                throw new InvalidDataException("A candle group cannot cross the boss-room threshold.");
            if(R09SplitIdentity.IsHall(roomId)&&coordinates.Any(z=>z>=0))
                throw new InvalidDataException("A split approach fixture must remain in its source-owned hall.");
            return coordinates.All(z => z < 0);
        }
    }
}
