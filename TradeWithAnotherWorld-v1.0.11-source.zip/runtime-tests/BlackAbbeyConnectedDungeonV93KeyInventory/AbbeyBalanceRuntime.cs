using System;
using System.Reflection;
using HarmonyLib;
using Jotunn.Managers;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Only helper-owned dungeon actors receive these persisted tags. Native
    // creatures, authoring previews, and unrelated enemy modules stay alone.
    public static class AbbeyBalanceRuntime
    {
        const string RevisionKey="ba_balance_revision",TierKey="ba_balance_tier",ActorKey="ba_balance_actor",RunKey="ba_balance_run",HealthKey="ba_balance_health";
        static Harmony hooks;
        static bool censerHook;
        public static int ContractRevision=>AbbeyBalancePolicy.Revision;
        internal static void Initialize()
        {
            if(hooks!=null)return;
            hooks=new Harmony(RuntimeTestPlugin.Id+".balance");
            hooks.Patch(AccessTools.Method(typeof(Character),"RPC_Damage"),prefix:new HarmonyMethod(typeof(AbbeyBalanceRuntime),nameof(BeforeDamage)));
            hooks.Patch(AccessTools.Method(typeof(Character),"Awake"),postfix:new HarmonyMethod(typeof(AbbeyBalanceRuntime),nameof(AfterAwake)));
            hooks.Patch(AccessTools.Method(typeof(Character),"SetupMaxHealth"),prefix:new HarmonyMethod(typeof(AbbeyBalanceRuntime),nameof(BeforeSetupHealth)));
        }
        internal static void Shutdown(){hooks?.UnpatchSelf();hooks=null;censerHook=false;}
        internal static int CaptureWorldTier()
        {
            if(!ZoneSystem.instance)throw new InvalidOperationException("World progression is not ready; dungeon generation retained safely.");
            string[] bosses={"Eikthyr","gd_king","Bonemass","Dragon","GoblinKing","SeekerQueen","Fader"};
            int tier=0;
            // Queen/Fader keys are read from the actual registered vanilla
            // Character, not guessed from a name or the separate NG+ level.
            for(int i=0;i<bosses.Length;i++)
            {
                var prefab=PrefabManager.Instance.GetPrefab(bosses[i]);
                var character=prefab?prefab.GetComponent<Character>():null;
                if(!character||string.IsNullOrEmpty(character.m_defeatSetGlobalKey))
                    throw new InvalidOperationException("World-boss progression prefab not ready: "+bosses[i]+". No dungeon tier was saved.");
                if(ZoneSystem.instance.GetGlobalKey(character.m_defeatSetGlobalKey))tier=i+1;
            }
            return tier;
        }
        static bool Owner(Character c)
        {var view=c?c.GetComponent<ZNetView>():null;return view&&view.IsValid()&&view.IsOwner();}
        static bool Profile(Character c,out string actor,out int tier)
        {
            actor=null;tier=0;var view=c?c.GetComponent<ZNetView>():null;
            if(!view||!view.IsValid())return false;
            var z=view.GetZDO();
            if(z.GetInt(RevisionKey,0)!=AbbeyBalancePolicy.Revision||string.IsNullOrEmpty(z.GetString(RunKey,"")))return false;
            actor=z.GetString(ActorKey,"");tier=z.GetInt(TierKey,-1);
            return AbbeyBalancePolicy.Known(actor)&&tier>=0&&tier<=7;
        }
        internal static void Bind(Character c,string actor,string run,int tier,bool fresh,bool health=true)
        {
            if(!Owner(c)||!AbbeyBalancePolicy.Known(actor)||string.IsNullOrEmpty(run))throw new InvalidOperationException("Balance binding requires one known, host-owned dungeon actor.");
            AbbeyBalancePolicy.Validate(AbbeyBalancePolicy.Revision,tier);
            var z=c.GetComponent<ZNetView>().GetZDO();
            string existing=z.GetString(RunKey,"");
            if(existing.Length>0&&(existing!=run||z.GetInt(TierKey,-1)!=tier||z.GetString(ActorKey,"")!=actor))
                throw new InvalidOperationException("Actor balance belongs to a different generated dungeon; no rescaling performed.");
            z.Set(RevisionKey,AbbeyBalancePolicy.Revision);z.Set(TierKey,tier);z.Set(ActorKey,actor);z.Set(RunKey,run);
            if(actor==AbbeyBalancePolicy.Profaned)EnsureCenserHook();
            if(health)
            {
                float prior=c.GetHealth();
                c.m_health=AbbeyBalancePolicy.BaseHealth(actor)*AbbeyBalancePolicy.HealthMultiplier(actor,tier);
                bool initialize=fresh&&z.GetInt(HealthKey,0)!=AbbeyBalancePolicy.Revision;
                // Native level and NG+ rules still apply exactly once. A
                // repeated bind never refills an already initialized actor.
                c.SetMaxHealth(c.GetMaxHealthBase()*c.GetLevel());
                c.SetHealth(initialize?c.GetMaxHealth():Mathf.Min(prior,c.GetMaxHealth()));
                z.Set(HealthKey,AbbeyBalancePolicy.Revision);
            }
            Present(c,actor);
        }
        static HitData.DamageModifier Modifier(float n)
        {
            if(n==0)return HitData.DamageModifier.Immune;
            if(n==.5f)return HitData.DamageModifier.Resistant;
            if(n==.75f)return HitData.DamageModifier.SlightlyResistant;
            if(n==1.25f)return HitData.DamageModifier.SlightlyWeak;
            if(n==1)return HitData.DamageModifier.Normal;
            throw new InvalidOperationException("Unsupported approved damage modifier.");
        }
        static void Present(Character c,string actor)
        {
            var n=AbbeyBalancePolicy.Resistances(actor);
            var modifiers=c.m_damageModifiers.Clone();
            modifiers.m_blunt=Modifier(n[0]);modifiers.m_slash=Modifier(n[1]);modifiers.m_pierce=Modifier(n[2]);
            modifiers.m_fire=Modifier(n[3]);modifiers.m_frost=Modifier(n[4]);modifiers.m_lightning=Modifier(n[5]);
            modifiers.m_poison=Modifier(n[6]);modifiers.m_spirit=Modifier(n[7]);c.m_damageModifiers=modifiers;
            if(actor==AbbeyBalancePolicy.Thrall)
                foreach(var weak in c.m_weakSpots??Array.Empty<WeakSpot>())
                    if(weak)weak.m_damageModifiers=modifiers.Clone();
        }
        static void AfterAwake(Character __instance)
        {if(Profile(__instance,out var actor,out _))Present(__instance,actor);}
        static void BeforeSetupHealth(Character __instance)
        {
            // Runs inside native Awake after ZNetView initialization, before
            // native max-HP setup could clamp a reloaded scaled actor to its
            // unscaled prefab maximum. Abbot's own two-bar guard owns its HP.
            if(Profile(__instance,out var actor,out int tier)&&actor!=AbbeyBalancePolicy.Abbot)
                __instance.m_health=AbbeyBalancePolicy.BaseHealth(actor)*AbbeyBalancePolicy.HealthMultiplier(actor,tier);
        }
        static void BeforeDamage(Character __instance,ref HitData __1)
        {
            if(!Owner(__instance)||__1==null)return;
            var original=__1;
            bool incoming=Profile(__instance,out var target,out _);
            var attacker=original.GetAttacker();bool outgoing=Profile(attacker,out var source,out int tier);
            if(!incoming&&!outgoing)return;
            // Native damage handlers can be called with reused packets. Work
            // on a native clone so another target never sees prior scaling.
            var hit=original.Clone();
            if(incoming)
            {
                Present(__instance,target);
                if(target==AbbeyBalancePolicy.Thrall&&hit.m_weakSpot>=0&&__instance.m_weakSpots!=null&&hit.m_weakSpot<__instance.m_weakSpots.Length&&__instance.m_weakSpots[hit.m_weakSpot])
                    hit.ApplyModifier(AbbeyBalancePolicy.ThrallHeadMultiplier);
            }
            if(outgoing)
            {
                if(source==AbbeyBalancePolicy.Monk)hit.m_damage.m_blunt*=26f/18f;
                if(source==AbbeyBalancePolicy.Profaned&&hit.m_damage.m_fire==0)hit.m_damage.m_blunt*=20f/14f;
                hit.ApplyModifier(AbbeyBalancePolicy.DamageMultiplier(source,tier));
            }
            __1=hit;
            // RPC_Damage continues through native difficulty, blocking,
            // armor and resistances. Never apply this scale in ApplyDamage.
        }
        static void EnsureCenserHook()
        {
            if(censerHook)return;
            if(hooks==null)throw new InvalidOperationException("Dungeon balance hooks are unavailable.");
            var type=AccessTools.TypeByName("BlackAbbey.CenserBrother.CenserInstance");
            var method=type==null?null:AccessTools.Method(type,"PublishSweep",Type.EmptyTypes);
            if(method==null)throw new MissingMethodException("Profaned smoke snapshot hook is unavailable.");
            hooks.Patch(method,postfix:new HarmonyMethod(typeof(AbbeyBalanceRuntime),nameof(AfterCenserSweep)));
            censerHook=true;
        }
        static void AfterCenserSweep(Component __instance)
        {
            var c=__instance?__instance.GetComponent<Character>():null;
            if(!Owner(c)||!Profile(c,out var actor,out int tier)||actor!=AbbeyBalancePolicy.Profaned)return;
            // Stamp the cloud's published DPS, so lingering smoke retains its
            // tier even after its source dies. No damage-time second multiplier.
            c.GetComponent<ZNetView>().GetZDO().Set("cb_chokeDps",AbbeyBalancePolicy.ChokeDps(tier));
        }
    }
}
