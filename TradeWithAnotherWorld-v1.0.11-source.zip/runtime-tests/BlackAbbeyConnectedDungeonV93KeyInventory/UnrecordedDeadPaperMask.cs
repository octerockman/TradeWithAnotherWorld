using System;
using System.Collections.Generic;
using System.IO;

namespace BlackAbbeySixRooms
{
    // Remove only explicitly owned triangle ordinals. Vertex attributes and
    // the retained triangle winding/order remain owned by the source mesh.
    internal static class UnrecordedDeadPaperMask
    {
        internal const int MaximumIndexCount=12000000,MaximumVertexCount=2000000;
        internal static int[] Excluding(int[] sourceIndices,IEnumerable<int> removedTriangles)
        {
            if(sourceIndices==null)throw new ArgumentNullException(nameof(sourceIndices));
            if(removedTriangles==null)throw new ArgumentNullException(nameof(removedTriangles));
            if(sourceIndices.Length>MaximumIndexCount||sourceIndices.Length%3!=0)
                throw new InvalidDataException("Paper source indices must contain bounded triangle triples.");
            foreach(int vertex in sourceIndices)
                if(vertex<0||vertex>=MaximumVertexCount)throw new InvalidDataException("Paper source index exceeds the checked BAR vertex bounds.");
            int triangleCount=sourceIndices.Length/3,removedCount=0;
            var removed=new bool[triangleCount];
            foreach(int triangle in removedTriangles)
            {
                if(triangle<0||triangle>=triangleCount)throw new InvalidDataException("Paper triangle ordinal is outside its source mesh.");
                if(removed[triangle])throw new InvalidDataException("Paper triangle ownership is repeated or overlaps another partition.");
                removed[triangle]=true;removedCount++;
            }
            var remaining=new int[sourceIndices.Length-removedCount*3];int target=0;
            for(int triangle=0;triangle<triangleCount;triangle++)
            {
                if(removed[triangle])continue;
                int start=triangle*3;
                remaining[target++]=sourceIndices[start];remaining[target++]=sourceIndices[start+1];remaining[target++]=sourceIndices[start+2];
            }
            return remaining;
        }
    }
}
