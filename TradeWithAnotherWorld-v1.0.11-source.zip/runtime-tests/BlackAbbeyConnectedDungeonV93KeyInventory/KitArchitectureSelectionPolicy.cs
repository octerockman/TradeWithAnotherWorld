using System;
using System.IO;
namespace BlackAbbeySixRooms
{
    internal static class KitArchitectureSelectionPolicy
    {
        internal static int Revision(bool fresh,int? savedRevision,bool entranceHasSeed,string savedEntranceCatalog,string legacyCatalog,string rebuiltCatalog)
        {
            if(fresh)return KitArchitectureProfile.Revision;
            if(savedRevision.HasValue){DungeonGenerationPolicy.RequireRevision(savedRevision.Value);if(savedRevision.Value!=KitArchitectureProfile.Revision)throw new InvalidDataException("The Abbey rooms were rebuilt. Use twa_test_regenerate from the surface before entering; the saved run and return point were retained.");return KitArchitectureProfile.Revision;}
            if(!entranceHasSeed)return KitArchitectureProfile.Revision;
            if(CatalogReader.Hash(rebuiltCatalog)&&savedEntranceCatalog==rebuiltCatalog)return KitArchitectureProfile.Revision;
            throw new InvalidDataException("The Abbey rooms were rebuilt. Use twa_test_regenerate from the surface before entering; the saved entrance and return point were retained.");
        }
    }
}
