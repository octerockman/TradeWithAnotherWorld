using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlackAbbeySixRooms
{
    // Called by the current run store before its ordinary DTO deserialization.
    // The parent snapshot field is optional; an existing null/absent field is
    // a legacy/nonselected run, not permission to regenerate its layout.
    internal static class FalseVowsPersistence
    {
        internal static FalseVowsSnapshot Read(JObject data, string expectedRunId)
        {
            if (data == null) return null;
            Shape(data, new[] { "schemaVersion", "revision", "collectedMask", "solvedMask" },
                new[] { "routeId", "runId" }, new[] { "noteReleased", "cabinetsUnlocked", "bookPlaced" },
                new[] { "rooms" }, new[] { "releaseSeeds", "deliveries", "consumptions" });
            Shape((JObject)data["rooms"], Array.Empty<string>(),
                new[] { "scriptorium", "vestry", "saint", "boss", "gateA", "gateB" }, Array.Empty<string>(), Array.Empty<string>(), Array.Empty<string>());
            var seeds = (JArray)data["releaseSeeds"];
            if (seeds.Count != 3 || seeds.Any(v => v.Type != JTokenType.Integer)) throw new InvalidDataException("Invalid saved wax release seeds.");
            foreach (string field in new[] { "deliveries", "consumptions" })
            {
                var array = (JArray)data[field];
                if (array.Count > (field == "deliveries" ? 6 : 4)) throw new InvalidDataException("Oversized Abbey item receipt journal.");
                foreach (var item in array)
                {
                    if (!(item is JObject receipt)) throw new InvalidDataException("Invalid Abbey item receipt.");
                    Shape(receipt, Array.Empty<string>(), new[] { "itemId", "actorId", "token" }, Array.Empty<string>(), Array.Empty<string>(), Array.Empty<string>());
                }
            }
            FalseVowsSnapshot value;
            try
            {
                value = data.ToObject<FalseVowsSnapshot>(JsonSerializer.Create(new JsonSerializerSettings
                { TypeNameHandling = TypeNameHandling.None, MetadataPropertyHandling = MetadataPropertyHandling.Ignore, DateParseHandling = DateParseHandling.None, MaxDepth = 16 }));
            }
            catch (JsonException ex) { throw new InvalidDataException("Saved Abbey item journal values are invalid.", ex); }
            FalseVowsState.Validate(value, expectedRunId); return value;
        }
        private static void Shape(JObject value, string[] integers, string[] strings, string[] booleans, string[] objects, string[] arrays)
        {
            var names = new HashSet<string>(integers.Concat(strings).Concat(booleans).Concat(objects).Concat(arrays), StringComparer.Ordinal);
            if (value == null || value.Properties().Count() != names.Count || value.Properties().Any(p => !names.Contains(p.Name)) ||
                integers.Any(n => value[n]?.Type != JTokenType.Integer) || strings.Any(n => value[n]?.Type != JTokenType.String) ||
                booleans.Any(n => value[n]?.Type != JTokenType.Boolean) || objects.Any(n => !(value[n] is JObject)) || arrays.Any(n => !(value[n] is JArray)))
                throw new InvalidDataException("Unrecognized/missing/mistyped Three False Vows save fields; retain the existing run.");
        }
    }
}
