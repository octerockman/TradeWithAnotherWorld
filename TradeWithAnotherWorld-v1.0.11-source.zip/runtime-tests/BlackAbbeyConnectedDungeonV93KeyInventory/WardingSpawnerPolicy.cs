using System;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    internal static class WardingSpawnerPolicy
    {
        internal const float UnbarringSeconds = 30f;
        internal const float EmptyReverseRate = .5f;
        // Float integration can leave a few millionths of normalized work at
        // an endpoint. Snap only when that endpoint is being reached, never
        // when enemy work begins (even tiny partial work disables the pin).
        const float EndpointTolerance = .00001f;
        internal const int MaximumActorSequence = 1000000;
        static readonly WardingSpawnerSettings Defaults = new WardingSpawnerSettings();

        static bool Finite(float n) => !float.IsNaN(n) && !float.IsInfinity(n);
        static bool Id(string s) => !string.IsNullOrWhiteSpace(s) && s.Length <= 160 && !s.Any(char.IsControl);
        internal static float GroupSpeed(int count) => count <= 0 ? 0f : count == 1 ? 1f : count == 2 ? 1.3f : 1.5f;
        internal static int MaximumSources(int rooms, int bossRooms = 1, int entranceRooms = 1)
        {
            if (rooms < 0 || rooms > 64 || bossRooms < 0 || entranceRooms < 0 || bossRooms + entranceRooms > rooms)
                throw new ArgumentOutOfRangeException(nameof(rooms));
            return (rooms - bossRooms - entranceRooms) / 8;
        }
        internal static bool EligibleHost(string sourceId, int depth) => depth >= 2 && depth < 64 &&
            new[] { "R01", "R02", "R03", "R03_complete", "R04", "R05", "R06" }.Contains(sourceId);

        internal static void Validate(WardingSpawnerSettings settings)
        {
            if (settings == null || !Finite(settings.SealingSeconds) || settings.SealingSeconds < 1 || settings.SealingSeconds > 300 ||
                !Finite(settings.FirstSpawnDelay) || settings.FirstSpawnDelay < 0 || settings.FirstSpawnDelay > 300 ||
                !Finite(settings.MinimumSpawnInterval) || !Finite(settings.MaximumSpawnInterval) || settings.MinimumSpawnInterval < 1 ||
                settings.MaximumSpawnInterval < settings.MinimumSpawnInterval || settings.MaximumSpawnInterval > 300 ||
                settings.MaximumLivingLocal < 1 || settings.MaximumLivingLocal > 32 || settings.MaximumLivingGlobal < settings.MaximumLivingLocal || settings.MaximumLivingGlobal > 64 ||
                settings.MonkWeight < 0 || settings.GuardWeight < 0 || settings.CenserWeight < 0 ||
                (long)settings.MonkWeight + settings.GuardWeight + settings.CenserWeight < 1 ||
                (long)settings.MonkWeight + settings.GuardWeight + settings.CenserWeight > 1000000)
                throw new InvalidDataException("Invalid warding spawner settings.");
        }
        internal static void Validate(WardingSpawnerState state)
        {
            if (state == null || !Id(state.id) || !Id(state.roomId) || !Id(state.portId) || !Finite(state.progress) || state.progress < 0 || state.progress > 1 ||
                !Finite(state.spawnCooldown) || state.spawnCooldown < 0 || state.spawnCooldown > 300 ||
                state.nextActorSequence < 0 || state.nextActorSequence > MaximumActorSequence ||
                state.locked && (state.progress != 1 || !state.initialSequenceCompleted || state.unbarring) ||
                state.unbarring && (!state.initialSequenceCompleted || state.progress <= 0) ||
                state.initialSequenceCompleted && state.progress != 1 && !state.unbarring ||
                state.progress == 1 && !state.initialSequenceCompleted)
                throw new InvalidDataException("Invalid warding spawner state; retained unchanged.");
        }
        internal static bool CanPin(WardingSpawnerState state) => state != null && !state.locked &&
            state.progress == 1 && state.initialSequenceCompleted && !state.unbarring;
        // A partially closed source keeps producing, with ONE living actor
        // from that source in the whole run. Pending/missing records count too.
        // A retry owns one already-counted reservation; it is not a new slot.
        internal static bool CanProduce(WardingSpawnerState state, int livingLocal, int livingGlobal,
            bool ownsReservation = false, WardingSpawnerSettings settings = null)
        {
            Validate(state); settings = settings ?? Defaults; Validate(settings);
            if (livingLocal < 0 || livingGlobal < livingLocal) throw new ArgumentOutOfRangeException(nameof(livingLocal));
            if (state.locked || state.progress >= 1 || state.awaitingReturn) return false;
            int limit = state.progress > 0 ? 1 : settings.MaximumLivingLocal;
            return ownsReservation ? livingLocal > 0 && livingLocal <= limit && livingGlobal <= settings.MaximumLivingGlobal :
                livingLocal < limit && livingGlobal < settings.MaximumLivingGlobal;
        }
        internal static bool TryPin(WardingSpawnerState state)
        {
            Validate(state);
            if (!CanPin(state)) return false;
            state.locked = true;
            return true;
        }
        internal static int PreviewFrame(WardingSpawnerState state)
        {
            Validate(state);
            return state.locked ? 165 : 1 + (int)Math.Round(state.progress * 150f, MidpointRounding.AwayFromZero);
        }
        static void ValidateInput(WardingSpawnerInput input)
        {
            if (input.Players < 0 || input.Players > 64 || input.Enemies < 0 || input.Enemies > 256 || input.Monks < 0 || input.Monks > input.Enemies ||
                input.LivingLocal < 0 || input.LivingLocal > 256 || input.LivingGlobal < input.LivingLocal || input.LivingGlobal > 1024)
                throw new InvalidDataException("Invalid ward occupancy/population snapshot.");
        }
        internal static WardingSpawnerStep Tick(WardingSpawnerState state, WardingSpawnerInput input, float deltaTime, WardingSpawnerSettings settings = null)
        {
            Validate(state); ValidateInput(input); settings = settings ?? Defaults; Validate(settings);
            if (!Finite(deltaTime) || deltaTime < 0 || deltaTime > 1) throw new ArgumentOutOfRangeException(nameof(deltaTime));
            var result = new WardingSpawnerStep { Contested = input.Players > 0 && input.Enemies > 0 };
            float prior = state.progress, priorCooldown = state.spawnCooldown;
            bool priorCompleted = state.initialSequenceCompleted, priorUnbarring = state.unbarring, priorWaiting = state.awaitingReturn;
            if (!state.locked && deltaTime > 0 && !result.Contested && !input.Obstructed)
            {
                if (input.Players > 0 && (state.progress < 1 || state.unbarring))
                {
                    result.PlayerWorking = true;
                    float step = deltaTime * GroupSpeed(input.Players) / settings.SealingSeconds;
                    state.progress = step >= 1f - state.progress - EndpointTolerance ? 1f : state.progress + step;
                    if (state.progress == 1)
                    {
                        state.initialSequenceCompleted = true; state.unbarring = false;
                        result.BecameFullyBarred = true;
                    }
                }
                else if (input.Enemies > 0 && state.initialSequenceCompleted && state.progress > 0)
                {
                    result.EnemyWorking = true;
                    // Set before reducing progress: the same tick can reach
                    // fully open and ask to produce. Already reinforced sources
                    // require another trip after every new barred-door cycle.
                    if (!state.unbarring) state.awaitingReturn = true;
                    float speed = input.Monks > 0 ? GroupSpeed(input.Monks) : 1f;
                    float step = deltaTime * speed / UnbarringSeconds;
                    state.progress = step >= state.progress - EndpointTolerance ? 0f : state.progress - step;
                    if (state.progress == 0)
                    {
                        state.initialSequenceCompleted = false; state.unbarring = false;
                        result.BecameFullyOpen = true;
                    }
                    else state.unbarring = true;
                }
                else if (input.Players == 0 && !state.initialSequenceCompleted && state.progress > 0)
                    state.progress = Math.Max(0f, state.progress - deltaTime * EmptyReverseRate / settings.SealingSeconds);
            }

            // Only loaded, active gameplay consumes a spawn clock. Boss death
            // is intentionally absent: unsealed sources continue afterward.
            if (input.Activation && !state.activatedEver)
            {
                state.activatedEver = true; state.spawnCooldown = settings.FirstSpawnDelay; result.Changed = true;
            }
            if (input.Activation && !state.locked && state.progress < 1)
            {
                state.spawnCooldown = deltaTime >= state.spawnCooldown - EndpointTolerance ? 0f : state.spawnCooldown - deltaTime;
                result.SpawnRequested = state.spawnCooldown == 0 && !input.ProductionBlocked && !input.Obstructed &&
                    state.nextActorSequence < MaximumActorSequence && CanProduce(state, input.LivingLocal, input.LivingGlobal, false, settings);
            }
            result.Changed |= prior != state.progress || priorCooldown != state.spawnCooldown ||
                priorCompleted != state.initialSequenceCompleted || priorUnbarring != state.unbarring || priorWaiting != state.awaitingReturn;
            Validate(state);
            return result;
        }
        static uint Sample(int seed, string id, int sequence, uint salt)
        {
            unchecked
            {
                uint h = 2166136261u ^ (uint)seed ^ salt;
                foreach (char c in id) { h ^= c; h *= 16777619u; }
                h ^= (uint)sequence; h *= 16777619u;
                h ^= h >> 16; h *= 0x7feb352du; h ^= h >> 15; h *= 0x846ca68bu; return h ^ (h >> 16);
            }
        }
        internal static WardingSpawnerKind ChooseRoster(int seed, WardingSpawnerState state, WardingSpawnerSettings settings = null)
        {
            Validate(state); settings = settings ?? Defaults; Validate(settings);
            if (state.reinforced) return WardingSpawnerKind.Guard;
            uint total = (uint)(settings.MonkWeight + settings.GuardWeight + settings.CenserWeight);
            uint pick = Sample(seed, state.id, state.nextActorSequence, 0x6f3a1c25u) % total;
            return pick < settings.MonkWeight ? WardingSpawnerKind.Monk : pick < settings.MonkWeight + settings.GuardWeight ? WardingSpawnerKind.Guard : WardingSpawnerKind.Censer;
        }
        internal static void CommitSpawn(int seed, WardingSpawnerState state, WardingSpawnerSettings settings = null)
        {
            Validate(state); settings = settings ?? Defaults; Validate(settings);
            if (state.nextActorSequence >= MaximumActorSequence) throw new InvalidOperationException("Spawner actor sequence exhausted.");
            state.nextActorSequence++;
            float unit = (float)(Sample(seed, state.id, state.nextActorSequence, 0xa3f719bdu) / (double)uint.MaxValue);
            state.spawnCooldown = settings.MinimumSpawnInterval + (settings.MaximumSpawnInterval - settings.MinimumSpawnInterval) * unit;
        }
    }
}
