using System;
using System.Collections.Generic;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Profiling;
using Object=UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // Read-only, opt-in after the first automatic load capture. No retained
    // meshes/textures, garbage collections, camera movement or quality changes.
    internal static class AbbeyLoadDiagnostics
    {
        private sealed class EmptyScope : IDisposable { public void Dispose(){} }
        private static readonly IDisposable empty=new EmptyScope();
        private sealed class Attempt
        {
            public string Schema="black-abbey-load-diagnostics-v1",BuildVersion,ProcessSession,AttemptId,StartedUtc,Mode,CatalogHash,RunId,Outcome,ReuseClassification;
            public int? RequestedSeed,ActualDungeonSeed;
            public bool Regeneration;
            public int ProcessAttemptOrdinal;
            public object Settings,ActualPlan;
            public double InclusiveLoadElapsedMs;
            public double BeforeCaptureOverheadMs,AfterCaptureOverheadMs;
            public double? ProcessCpuDeltaMs;
            public object Before,After,BeforeRegenerationReset;
            public DiagnosticRoomReport Lifecycle;
            public DiagnosticSourceReport[] SourcesSlowestFirst;
            public DiagnosticRoomReport[] InstancesSlowestFirst;
            public string[] Interpretation=Notes;
            [JsonIgnore] public long Started;
            [JsonIgnore] public double? CpuStart;
            [JsonIgnore] public DiagnosticRoomContext LifecycleContext;
            [JsonIgnore] public readonly List<DiagnosticRoomContext> Rooms=new List<DiagnosticRoomContext>();
        }
        private sealed class RunIdentity
        { public string BuildVersion,ProcessSession,AttemptId,Mode,CatalogHash,RunId;public int? ActualDungeonSeed; }
        private static readonly string session=Guid.NewGuid().ToString("N");
        private static readonly string[] Notes={
            "Elapsed load/room/coroutine spans include yields and are inclusive. Do not sum them with phase timings.",
            "Phase inclusiveBlockingWallMs includes nested instrumented calls. exclusiveBlockingWallMs subtracts those children on the same thread. Sum exclusive only within the chosen category/thread; main and managed-worker work can overlap.",
            "Blocking wall is not CPU. ProcessCpuDeltaMs measures all process threads including unrelated game work; per-room/per-phase CPU and disk device service time are unsupported.",
            "Worker-await elapsed includes scheduler/frame latency and does not prove disk or CPU idle time. Main scheduler metrics are MoveNext blocking wall, never GPU timing.",
            "ImageConversion.LoadImage combines native image decode and upload; those costs cannot be separated here. Texture compression is not requested by this loader; texture GPU completion is not measured.",
            "Mesh assignment/bounds are mesh upload API wall, not GPU completion. MeshCollider.sharedMesh assignment includes any synchronous cooking; Unity may reuse a cook, so it is not isolated cook CPU.",
            "Shared resource build work belongs to the source/instance that first actually read/built it. Cache acquisitions are actual hits, not inferred warm reuse. No encoded byte array cache or new resource retention is introduced.",
            "Shared live Unity objects are deduplicated by instance ID once per snapshot. Profiler object bytes are Unity runtime object allocation scope, not GPU VRAM. Mesh payload and texture RGBA estimates exclude overhead and overlap runtime estimates; never add them.",
            "Process working set and private committed bytes overlap and are process-wide; never add them to each other, managed heap, or Unity allocation/reservation totals. File sizes are IO volume, not resident RAM.",
            "Before/after values are point samples, not peaks. Unity Destroy is deferred; a post-release snapshot can still include pending destruction. No forced GC or unload is performed.",
            "Loaded triangles/renderer inventory are residency counts, not triangles drawn. View samples are application frame intervals only, not renderer/GPU timings or proof of a bottleneck.",
            "First-process attempt is not a measured cold OS/disk cache. Regeneration and warm labels describe lifecycle; rebuild versus reuse is shown by actual events and snapshots."
        };
        private static Attempt active;
        private static RunIdentity identity;
        private static bool nextCapture=true;
        private static bool pendingRegeneration;
        private static object beforeRegeneration;
        private static int attemptOrdinal,mainThread;
        private static string outputDirectory,buildVersion;
        private static Action<string> log;
        private static AbbeyDiagnosticSampler sampler;
        internal static bool Capturing=>active!=null;
        internal static void CacheEvent(string key,long amount=1) { active?.LifecycleContext.Event(key,amount); }
        internal static void Initialize(GameObject host,string directory,Action<string> logger,string version)
        {
            log=logger;
            try
            {
                mainThread=Thread.CurrentThread.ManagedThreadId;outputDirectory=Path.GetFullPath(directory);buildVersion=version;
                if(host&&!sampler){sampler=host.AddComponent<AbbeyDiagnosticSampler>();sampler.enabled=false;}
            }
            catch(Exception ex){SafeLog("ABBEY_DIAGNOSTICS_INIT_FAILED: "+ex.Message+"; helper gameplay remains enabled.");}
        }
        internal static string CatalogIdentity(string path){try{return CatalogReader.HashFile(path);}catch{return "unavailable";}}
        internal static void ArmNext() { nextCapture=true;SafeLog("ABBEY_DIAGNOSTICS: next load armed; no gameplay or rendering settings changed."); }
        internal static void NoteRegeneration(IEnumerable<LoadedRoom> rooms)
        { pendingRegeneration=true;beforeRegeneration=nextCapture?SafeMemory(rooms):null; }
        internal static void BeginAttempt(string mode,bool regeneration,int? requestedSeed,string catalogHash,IEnumerable<LoadedRoom> rooms=null)
        {
            try { BeginAttemptCore(mode,regeneration,requestedSeed,catalogHash,rooms); }
            catch(Exception ex) { active=null;SafeLog("ABBEY_DIAGNOSTICS_BEGIN_FAILED: "+ex.Message+"; gameplay continues without this capture."); }
        }
        private static void BeginAttemptCore(string mode,bool regeneration,int? requestedSeed,string catalogHash,IEnumerable<LoadedRoom> rooms)
        {
            if(active!=null)Finish("superseded-before-finish",rooms);
            int ordinal=++attemptOrdinal;regeneration|=pendingRegeneration;pendingRegeneration=false;
            identity=new RunIdentity { BuildVersion=buildVersion,ProcessSession=session,AttemptId=Guid.NewGuid().ToString("N"),Mode=mode,CatalogHash=catalogHash };
            object beforeReset=beforeRegeneration;beforeRegeneration=null;
            if(!nextCapture)return;nextCapture=false;
            if(mainThread==0)mainThread=Thread.CurrentThread.ManagedThreadId;
            var probe=Stopwatch.StartNew();
            var a=new Attempt { BuildVersion=buildVersion??typeof(AbbeyLoadDiagnostics).Assembly.GetName().Version.ToString(),ProcessSession=session,
                AttemptId=identity.AttemptId,StartedUtc=DateTime.UtcNow.ToString("o"),Mode=mode,Regeneration=regeneration,
                RequestedSeed=requestedSeed,CatalogHash=catalogHash,ProcessAttemptOrdinal=ordinal,
                ReuseClassification=regeneration?"regeneration (inspect actual cache events)":ordinal==1?"first process attempt (OS/disk cache unknown)":"warm process attempt (inspect actual cache events)",
                Settings=SafeSettings(),Before=SafeMemory(rooms),BeforeRegenerationReset=beforeReset,
                LifecycleContext=new DiagnosticRoomContext("_lifecycle","Dungeon lifecycle","_attempt",mainThread) };
            a.BeforeCaptureOverheadMs=probe.Elapsed.TotalMilliseconds;a.Started=Stopwatch.GetTimestamp();a.CpuStart=ProcessCpu();
            active=a;SafeLog("ABBEY_DIAGNOSTICS_BEGIN: attempt="+a.AttemptId+"; mode="+mode+"; requestedSeed="+requestedSeed+"; next captures require twa_test_diagnostics_arm.");
        }
        internal static void BindPlan(DungeonPlan plan,string runId=null)
        {
            if(plan==null)return;
            if(identity!=null){identity.ActualDungeonSeed=plan.Seed;if(runId!=null)identity.RunId=runId;}
            var a=active;if(a==null)return;
            a.ActualDungeonSeed=plan.Seed;a.RunId=runId??a.RunId;
            a.ActualPlan=new { plan.Mode,RoomCount=plan.Rooms?.Length,LinkCount=plan.Links?.Length,plan.EntryPort,
                CycleRank=plan.Links!=null&&plan.Rooms!=null?plan.CycleRank:0,
                Instances=plan.Rooms?.Select(p=>new { InstanceId=p.Spec.Id,p.Spec.SourceId,p.QuarterTurns,X=p.Position.X,Z=p.Position.Z,p.Elevation }).ToArray(),
                Planning=plan.Diagnostics?.ToString() };
        }
        internal static void BindRun(string runId) { if(active!=null)active.RunId=runId;if(identity!=null)identity.RunId=runId; }
        internal static void Outcome(string outcome) { if(active!=null)active.Outcome=outcome; }
        internal static IDisposable Measure(string phase,string category="lifecycle")
            =>active==null?empty:new DiagnosticBlockingScope(active.LifecycleContext,phase,category);
        internal static IDisposable Measure(DiagnosticRoomContext room,string phase,string category)
            =>room==null||!room.RecordingEnabled?empty:new DiagnosticBlockingScope(room,phase,category);
        private sealed class ElapsedScope : IDisposable
        {
            private readonly DiagnosticRoomContext room;private readonly string phase;private readonly long start=Stopwatch.GetTimestamp();private bool done;
            internal ElapsedScope(DiagnosticRoomContext room,string phase){this.room=room;this.phase=phase;}
            public void Dispose(){if(done)return;done=true;double elapsed=DiagnosticMath.Milliseconds(start,Stopwatch.GetTimestamp());room.Record(phase,"coroutine-wait-elapsed-nonadditive",mainThread,elapsed,elapsed);}
        }
        internal static IDisposable Wait(DiagnosticRoomContext room,string phase)=>room==null||!room.RecordingEnabled?empty:new ElapsedScope(room,phase);
        internal static IEnumerator ObserveSteps(IEnumerator work,string phase)
        {
            // The elapsed span is explicitly nonadditive. Only MoveNext is
            // inside a blocking timer; no blocking scope survives a yield.
            var context=active?.LifecycleContext;
            using(Wait(context,phase+".coroutine-inclusive"))
                yield return ObservedStepsCore(work,phase,context);
        }
        private static IEnumerator ObservedStepsCore(IEnumerator work,string phase,DiagnosticRoomContext context)
        {
            try
            {
                while(true)
                {
                    bool moved;object current=null;
                    using(Measure(context,phase+".main-step","lifecycle")){moved=work.MoveNext();if(moved)current=work.Current;}
                    if(!moved)yield break;
                    if(current is IEnumerator child)yield return ObservedStepsCore(child,phase,context);
                    else yield return current;
                }
            }
            finally{(work as IDisposable)?.Dispose();}
        }
        internal static DiagnosticRoomContext BeginRoom(CatalogRoomRecord record,string instanceId,string role="placed-room")
        {
            var a=active;if(a==null)return null;
            var room=new DiagnosticRoomContext(record.roomId,record.displayName,instanceId,mainThread,role);
            lock(a.Rooms){if(a.Rooms.Count>=256){a.LifecycleContext.Event("room-report-cap-reached");return null;}a.Rooms.Add(room);}return room;
        }
        internal static void EndRoom(DiagnosticRoomContext context,string outcome,LoadedRoom room,RoomLoadScheduling.Result timing=null)
        {
            if(context==null)return;
            if(room!=null){context.Report.LoadedVisualTriangles=room.VisualTriangles;context.Report.LoadedColliderTriangles=room.ColliderTriangles;}
            if(timing!=null){context.Report.ResourceCoroutineElapsedMs=timing.WallMilliseconds;context.Report.LargestMainMoveNextMs=timing.MaximumMainStepMilliseconds;context.Report.YieldedResourceFrames=timing.Frames;}
            context.Finish(outcome);
        }
        internal static void SchedulerStep(double milliseconds,bool yielded)
        {
            var a=active;if(a==null)return;
            a.LifecycleContext.Record("scheduler.outermost-move-next","main-scheduler-nonadditive",mainThread,milliseconds,milliseconds);
            if(yielded)a.LifecycleContext.Event("scheduler-yields");
        }
        internal static void Finish(string outcome,IEnumerable<LoadedRoom> rooms=null)
        {
            var a=active;if(a==null)return;active=null;
            try
            {
                a.Outcome=outcome??a.Outcome??"ended-without-success-marker";a.InclusiveLoadElapsedMs=DiagnosticMath.Milliseconds(a.Started,Stopwatch.GetTimestamp());
                double? cpuEnd=ProcessCpu();a.ProcessCpuDeltaMs=cpuEnd.HasValue&&a.CpuStart.HasValue?(double?)Math.Max(0,cpuEnd.Value-a.CpuStart.Value):null;
                a.LifecycleContext.Finish(a.Outcome);a.Lifecycle=a.LifecycleContext.Snapshot();
                var afterProbe=Stopwatch.StartNew();a.After=SafeMemory(rooms);a.AfterCaptureOverheadMs=afterProbe.Elapsed.TotalMilliseconds;
                lock(a.Rooms)a.InstancesSlowestFirst=a.Rooms.Select(r=>r.Snapshot()).OrderByDescending(r=>r.InclusiveElapsedMs).ToArray();
                a.SourcesSlowestFirst=DiagnosticMath.BySource(a.InstancesSlowestFirst);
                string path=Write("load-"+a.AttemptId,a);
                SafeLog("ABBEY_DIAGNOSTICS_END: outcome="+a.Outcome+"; actualDungeonSeed="+a.ActualDungeonSeed+"; run="+a.RunId+"; elapsedMs="+a.InclusiveLoadElapsedMs.ToString("F1")+"; report="+path);
                foreach(var source in a.SourcesSlowestFirst.Take(10))SafeLog("ABBEY_DIAGNOSTICS_SOURCE: "+source.SourceId+" | "+source.DescriptiveName+"; instances="+source.Instances+"; summedInclusiveInstanceMs="+source.SummedInclusiveInstanceElapsedMs.ToString("F1")+"; sharedBuildExclusiveWorkMs="+source.SharedBuildWorkMs.ToString("F1")+"; placedExclusiveWorkMs="+source.PlacedInstanceWorkMs.ToString("F1"));
                foreach(var room in a.InstancesSlowestFirst.Take(8))SafeLog("ABBEY_DIAGNOSTICS_INSTANCE: "+room.SourceId+" | "+room.DescriptiveName+" | "+room.InstanceId+"; inclusiveElapsedMs="+room.InclusiveElapsedMs.ToString("F1"));
            }
            catch(Exception ex){SafeLog("ABBEY_DIAGNOSTICS_WRITE_FAILED: "+ex.GetType().Name+": "+ex.Message+"; diagnostics failure did not change gameplay.");}
            finally
            {
                a.LifecycleContext.RecordingEnabled=false;lock(a.Rooms)foreach(var room in a.Rooms)room.RecordingEnabled=false;
                foreach(var room in rooms??Enumerable.Empty<LoadedRoom>())if(room?.Diagnostic!=null&&!room.Diagnostic.RecordingEnabled)room.Diagnostic=null;
            }
        }
        internal static void Snapshot(string label,IEnumerable<LoadedRoom> rooms=null)
        {
            try { string path=Write("snapshot-"+SafeLabel(label),new { Schema="black-abbey-memory-snapshot-v1",Identity=identity,Label=label,Utc=DateTime.UtcNow.ToString("o"),Memory=SafeMemory(rooms),Settings=SafeSettings(),Interpretation=Notes });SafeLog("ABBEY_DIAGNOSTICS_SNAPSHOT: "+path); }
            catch(Exception ex){SafeLog("ABBEY_DIAGNOSTICS_SNAPSHOT_FAILED: "+ex.Message);}
        }
        internal static void StartViewSample(string label,double seconds=8)
        { try{if(!sampler){SafeLog("ABBEY_DIAGNOSTICS: sample host unavailable.");return;}sampler.Begin(label,Math.Max(2,Math.Min(15,seconds)));}catch(Exception ex){SafeLog("ABBEY_DIAGNOSTICS_VIEW_FAILED: "+ex.Message);} }
        internal static object ViewIdentity()
        {
            var c=Camera.main;var p=Player.m_localPlayer;
            return new { Identity=identity,PlayerPosition=p?Coordinates(p.transform.position):null,CameraPosition=c?Coordinates(c.transform.position):null,
                CameraRotation=c?new[]{c.transform.rotation.x,c.transform.rotation.y,c.transform.rotation.z,c.transform.rotation.w}:null,
                CameraFieldOfView=c?(float?)c.fieldOfView:null, Settings=SafeSettings() };
        }
        internal static void FinishView(string label,List<double> frames,object before,object after,float moved)
        {
            try { string path=Write("view-"+SafeLabel(label),new { Schema="black-abbey-application-frame-sample-v1",BuildVersion=buildVersion,ProcessSession=session,Label=label,Utc=DateTime.UtcNow.ToString("o"),Before=before,After=after,
                SampleCount=frames.Count,MeanFrameIntervalMs=frames.Count==0?0:frames.Average(),P50FrameIntervalMs=DiagnosticMath.Percentile(frames,.5),P95FrameIntervalMs=DiagnosticMath.Percentile(frames,.95),MaximumFrameIntervalMs=frames.Count==0?0:frames.Max(),PlayerDisplacementMetres=moved,
                SamePositionWithin15cm=moved<=.15f,CompareOnlyWithinSameSessionSettingsAndPosition=true,DrawnTriangles="unsupported",GpuTime="unsupported",Interpretation=Notes });SafeLog("ABBEY_DIAGNOSTICS_VIEW: "+path); }
            catch(Exception ex){SafeLog("ABBEY_DIAGNOSTICS_VIEW_FAILED: "+ex.Message);}
        }
        private static float[] Coordinates(Vector3 v)=>new[]{v.x,v.y,v.z};
        private static object Settings()=>new { Quality=QualitySettings.GetQualityLevel(),QualitySettings.pixelLightCount,Shadows=QualitySettings.shadows.ToString(),ShadowResolution=QualitySettings.shadowResolution.ToString(),QualitySettings.shadowDistance,QualitySettings.antiAliasing,QualitySettings.vSyncCount,
            Screen.width,Screen.height,Application.targetFrameRate,GraphicsDevice=SystemInfo.graphicsDeviceName,GraphicsApi=SystemInfo.graphicsDeviceType.ToString(),SystemMemoryCapacityMiB=SystemInfo.systemMemorySize,GraphicsMemoryCapacityMiB=SystemInfo.graphicsMemorySize,
            CapacityIsNotUsage=true,GraphicsMemoryUsageBytes=(long?)null };
        private static double? ProcessCpu(){try{using(var p=Process.GetCurrentProcess())return p.TotalProcessorTime.TotalMilliseconds;}catch{return null;}}
        private static object SafeSettings(){try{return Settings();}catch(Exception ex){return new {Unavailable=ex.GetType().Name,Reason=ex.Message};}}
        private static object SafeMemory(IEnumerable<LoadedRoom> rooms){try{return Memory(rooms);}catch(Exception ex){return new {Unavailable=ex.GetType().Name,Reason=ex.Message};}}
        internal static object Memory(IEnumerable<LoadedRoom> rooms)
        {
            long? working=null,privateBytes=null;try{using(var p=Process.GetCurrentProcess()){p.Refresh();working=p.WorkingSet64;privateBytes=p.PrivateMemorySize64;}}catch{}
            var shared=SharedRoomResources.DiagnosticSnapshot();var sharedIds=new HashSet<int>(shared.Select(v=>v.InstanceId));var owned=new Dictionary<int,Object>();
            int loadedInstances=0,renderers=0,activeRenderers=0,colliders=0;long loadedTriangles=0;
            foreach(var room in rooms??Enumerable.Empty<LoadedRoom>())
            {
                if(room==null)continue;loadedInstances++;loadedTriangles+=room.VisualTriangles;
                foreach(var value in room.Resources)if(value&&!sharedIds.Contains(value.GetInstanceID()))owned[value.GetInstanceID()]=value;
                if(room.Root){var rs=room.Root.GetComponentsInChildren<Renderer>(true);renderers+=rs.Length;activeRenderers+=rs.Count(r=>r.enabled&&r.gameObject.activeInHierarchy);colliders+=room.Root.GetComponentsInChildren<Collider>(true).Length;}
            }
            var ownedRows=owned.Values.Select(ResourceMemory).ToArray();
            return new { ProcessWorkingSetBytes=working,ProcessPrivateCommittedBytes=privateBytes,ManagedHeapBytes=GC.GetTotalMemory(false),
                UnityAllocatedBytes=PositiveOrUnknown(Profiler.GetTotalAllocatedMemoryLong()),UnityReservedBytes=PositiveOrUnknown(Profiler.GetTotalReservedMemoryLong()),
                SharedResidentObjectCount=shared.Length,SharedResidentAliasCount=SharedRoomResources.ResidentAliasCount,
                SharedKnownUniqueUnityRuntimeObjectBytes=shared.Sum(v=>v.UnityRuntimeObjectBytes??0),SharedObjectsWithUnknownRuntimeBytes=shared.Count(v=>!v.UnityRuntimeObjectBytes.HasValue),SharedObjects=shared,
                OwnedKnownUniqueUnityRuntimeObjectBytes=ownedRows.Sum(v=>v.UnityRuntimeObjectBytes??0),OwnedObjectsWithUnknownRuntimeBytes=ownedRows.Count(v=>!v.UnityRuntimeObjectBytes.HasValue),OwnedObjects=ownedRows,
                LoadedRoomInstances=loadedInstances,LoadedVisualTriangles=loadedTriangles,ResidentRendererCount=renderers,EnabledActiveRendererCount=activeRenderers,ColliderComponentCount=colliders,
                GpuVramUsageBytes=(long?)null,GpuVramStatus="unsupported; hardware capacity in Settings is not live usage",
                Scope="Process/managed/Unity totals overlap and include non-Abbey allocations. Unique object subtotals are scoped snapshots, not additive to those totals. Renderer/triangle counts are residency, not drawn work." };
        }
        internal sealed class ResourceMemoryRow
        {
            public int InstanceId,References;
            public string Name,Type,Identity;
            public long? UnityRuntimeObjectBytes;
            public long? EstimatedMeshStreamBytes,EstimatedRgbaTextureMipBytes;
            public long LockedEncodedSourceBytes;
        }
        internal static ResourceMemoryRow ResourceMemory(Object value)
        {
            var row=new ResourceMemoryRow { InstanceId=value.GetInstanceID(),Name=value.name,Type=value.GetType().Name };
            try{row.UnityRuntimeObjectBytes=PositiveOrUnknown(Profiler.GetRuntimeMemorySizeLong(value));}catch{}
            if(value is Mesh mesh)
            {
                // Actual stream strides when supported, index format actual.
                try { long bytes=0;for(int i=0;i<mesh.vertexBufferCount;i++)bytes+=(long)mesh.GetVertexBufferStride(i)*mesh.vertexCount;
                    for(int i=0;i<mesh.subMeshCount;i++)bytes+=(long)mesh.GetIndexCount(i)*(mesh.indexFormat==UnityEngine.Rendering.IndexFormat.UInt32?4:2);row.EstimatedMeshStreamBytes=bytes; }catch{}
            }
            if(value is Texture2D texture){long bytes=0;int w=texture.width,h=texture.height;for(int i=0;i<texture.mipmapCount;i++){bytes+=(long)Math.Max(1,w)*Math.Max(1,h)*4;w/=2;h/=2;}row.EstimatedRgbaTextureMipBytes=bytes;}
            return row;
        }
        private static long? PositiveOrUnknown(long value)=>value>0?(long?)value:null;
        private static string SafeLabel(string label)=>new string((label??"snapshot").Where(c=>char.IsLetterOrDigit(c)||c=='-'||c=='_').Take(48).ToArray());
        private static string Write(string name,object value)
        {
            if(string.IsNullOrEmpty(outputDirectory))throw new InvalidOperationException("Diagnostics output directory was not initialized.");
            Directory.CreateDirectory(outputDirectory);string path=Path.Combine(outputDirectory,DateTime.UtcNow.ToString("yyyyMMdd-HHmmssfff")+"-"+name+".json");
            File.WriteAllText(path,JsonConvert.SerializeObject(value,Formatting.Indented));return path;
        }
        private static void SafeLog(string message){try{log?.Invoke(message);}catch{}}
    }
    internal sealed class AbbeyDiagnosticSampler : MonoBehaviour
    {
        private string label;private float remaining;private object before;private Vector3 playerStart;private readonly List<double> frames=new List<double>();
        internal void Begin(string label,double seconds){this.label=label;remaining=(float)seconds;frames.Clear();before=AbbeyLoadDiagnostics.ViewIdentity();playerStart=Player.m_localPlayer?Player.m_localPlayer.transform.position:Vector3.zero;enabled=true;}
        private void Update(){if(remaining<=0){enabled=false;return;}float dt=Time.unscaledDeltaTime;frames.Add(dt*1000.0);remaining-=dt;if(remaining>0&&frames.Count<4096)return;
            enabled=false;float moved=Player.m_localPlayer?Vector3.Distance(playerStart,Player.m_localPlayer.transform.position):float.PositiveInfinity;
            AbbeyLoadDiagnostics.FinishView(label,frames,before,AbbeyLoadDiagnostics.ViewIdentity(),moved);frames.Clear();}
    }
}
