using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // Only immutable uploaded meshes and input textures are shared. Materials,
    // repairs, moving leaves, effects and gameplay state belong to each room.
    internal static class SharedRoomResources
    {
        private sealed class Entry
        {
            internal string Key;
            internal Object Value;
            internal int References;
            internal bool Dropped;
            internal readonly List<VerifiedResourceFile> Sources = new List<VerifiedResourceFile>();
            internal readonly List<string> Aliases = new List<string>();
        }
        private sealed class ResourceLease : IDisposable
        {
            private Action release;
            internal ResourceLease(Action release) { this.release = release; }
            public void Dispose() { System.Threading.Interlocked.Exchange(ref release, null)?.Invoke(); }
        }
        private static readonly Dictionary<string, Entry> entries = new Dictionary<string, Entry>(StringComparer.Ordinal);
        private static readonly Dictionary<string, Entry> aliases = new Dictionary<string, Entry>(StringComparer.Ordinal);
        internal static bool TryAcquire<T>(string key, LoadedRoom room, out T value) where T : Object
        {
            if (!TryAcquireLease(key, out value, out var lease)) { room.Diagnostic?.Event("shared-miss-"+typeof(T).Name); return false; }
            room.Diagnostic?.Event("shared-hit-"+typeof(T).Name);
            room.SharedResourceReleases.Add(lease.Dispose); return true;
        }
        internal static bool TryAcquireAlias<T>(string alias, LoadedRoom room, out T value) where T : Object
        {
            if (aliases.TryGetValue(alias, out var entry) && !entry.Dropped &&
                entries.TryGetValue(entry.Key, out var current) && ReferenceEquals(current, entry))
                return TryAcquire(entry.Key, room, out value);
            value = null; return false;
        }
        internal static void BindAlias(string alias, string key, VerifiedResourceFile source, LoadedRoom room)
        {
            if (string.IsNullOrEmpty(alias) || !entries.TryGetValue(key, out var entry) || entry.Dropped || !entry.Value || source == null || !source.IsVerified)
                throw new InvalidOperationException("A path alias requires a verified resident resource and live source lock.");
            if (aliases.TryGetValue(alias, out var previous))
            {
                if (!ReferenceEquals(previous, entry)) throw new InvalidOperationException("An active verified path alias cannot change identity.");
                if (!entry.Sources.Contains(source)) { room.PendingSources.Remove(source); source.Dispose(); }
                return;
            }
            AdoptSource(entry, source, room);
            aliases.Add(alias, entry); entry.Aliases.Add(alias);
        }
        internal static void Retain(string key, Object value, LoadedRoom room, VerifiedResourceFile source = null)
        {
            var entry = Register(key, value);
            try
            {
                if (source != null) AdoptSource(entry, source, room);
                room.SharedResourceReleases.Add(Lease(entry).Dispose);
                room.Resources.Remove(value);
            }
            catch { Drop(entry); throw; }
        }
        // State-owned immutable derived meshes have a shorter lifetime than a
        // whole room: Restore releases their lease, while base sources remain.
        internal static IDisposable RetainLease(string key, Object value)
        { return Lease(Register(key, value)); }
        internal static bool TryAcquireLease<T>(string key, out T value, out IDisposable lease) where T : Object
        {
            if (entries.TryGetValue(key, out var entry))
            {
                if (!entry.Dropped && entry.Value is T found && found)
                { value = found; lease = Lease(entry); AbbeyLoadDiagnostics.CacheEvent("shared-lease-hit-"+typeof(T).Name); return true; }
                if (!entry.Value) Drop(entry);
            }
            value = null; lease = null; AbbeyLoadDiagnostics.CacheEvent("shared-lease-miss-"+typeof(T).Name); return false;
        }
        private static Entry Register(string key, Object value)
        {
            if (string.IsNullOrEmpty(key) || !value || entries.ContainsKey(key)) throw new InvalidOperationException("Invalid shared room resource registration.");
            var entry = new Entry { Key = key, Value = value }; entries.Add(key, entry);
            AbbeyLoadDiagnostics.CacheEvent("shared-built-"+value.GetType().Name); return entry;
        }
        private static void AdoptSource(Entry entry, VerifiedResourceFile source, LoadedRoom room)
        {
            if (entry.Sources.Contains(source)) return;
            if (!source.IsVerified || !room.PendingSources.Remove(source)) throw new InvalidOperationException("A resident source must transfer from its owning pending room.");
            entry.Sources.Add(source);
        }
        private static IDisposable Lease(Entry entry)
        {
            if (entry.Dropped) throw new InvalidOperationException("Cannot lease a released room resource.");
            entry.References++;
            return new ResourceLease(() => { if (--entry.References == 0) Drop(entry); });
        }
        private static void Drop(Entry entry)
        {
            if (entry.Dropped) return;
            AbbeyLoadDiagnostics.CacheEvent("shared-dropped-"+(entry.Value?entry.Value.GetType().Name:"destroyed"));
            entry.Dropped = true;
            if (entries.TryGetValue(entry.Key, out var current) && ReferenceEquals(current, entry)) entries.Remove(entry.Key);
            foreach (string alias in entry.Aliases)
                if (aliases.TryGetValue(alias, out var owner) && ReferenceEquals(owner, entry)) aliases.Remove(alias);
            entry.Aliases.Clear();
            try { if (entry.Value) Object.Destroy(entry.Value); }
            finally
            {
                entry.Value = null;
                foreach (var source in entry.Sources) source.Dispose();
                entry.Sources.Clear();
            }
        }
        internal static int ResidentCount => entries.Count;
        internal static int ResidentAliasCount => aliases.Count;
        // Main-thread snapshot only. Alias and room leases refer to one live
        // object and must not multiply its residency/memory accounting.
        internal static AbbeyLoadDiagnostics.ResourceMemoryRow[] DiagnosticSnapshot()
        {
            return entries.Values.Where(e=>!e.Dropped&&e.Value).GroupBy(e=>e.Value.GetInstanceID()).Select(group=> {
                var first=group.First();var row=AbbeyLoadDiagnostics.ResourceMemory(first.Value);
                row.References=group.Sum(e=>e.References);row.Identity=first.Key;
                row.LockedEncodedSourceBytes=group.SelectMany(e=>e.Sources).Distinct().Sum(s=>s.BytesRead);
                return row;
            }).ToArray();
        }
    }
}
