using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using Newtonsoft.Json;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // The checked derived payload is inside the helper. Disk BAR1/manifests,
    // catalog/layout identity, and accepted editable room sources stay intact.
    internal static class StairCollarRepair
    {
        internal const string PayloadSha256="5633f643e071d53c6432e7d963fb4bce5c33027506b18150b661497e9835a42a";
        internal const string ResourceName="BlackAbbey.SourceRangeRepairsV82.json";
        private static readonly Lazy<PinnedMeshRangePatchFile> payload=new Lazy<PinnedMeshRangePatchFile>(ReadPayload,LazyThreadSafetyMode.ExecutionAndPublication);
        private static PinnedMeshRangePatchFile ReadPayload()
        {
            using(var source=typeof(StairCollarRepair).Assembly.GetManifestResourceStream(ResourceName))
            {
                if(source==null||source.Length<1||source.Length>32*1024*1024)throw new InvalidDataException("Checked source-range repair payload is missing or oversized.");
                byte[] bytes;using(var memory=new MemoryStream()){source.CopyTo(memory);bytes=memory.ToArray();}
                if(BarMeshReader.Hash(bytes)!=PayloadSha256)throw new InvalidDataException("Checked source-range repair payload changed.");
                return PinnedMeshRangePatchPolicy.Parse(System.Text.Encoding.UTF8.GetString(bytes));
            }
        }
        private static bool SameDirectory(string a,string b)=>!string.IsNullOrWhiteSpace(a)&&!string.IsNullOrWhiteSpace(b)&&
            string.Equals(Path.GetFullPath(a).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar),Path.GetFullPath(b).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar),StringComparison.OrdinalIgnoreCase);
        internal static MeshPatchIdentity Identity(string directory,string ownerDirectory,CatalogRoomRecord room,PackageManifest manifest,MeshRecord mesh,bool collider)
        {
            // Auxiliary quest/door meshes can share generic relative filenames;
            // their resource owner never makes them the primary room mesh.
            if(!SameDirectory(directory,ownerDirectory)||room==null||manifest==null||mesh==null)return null;
            string asset=room.packageDirectory;
            if(!payload.Value.patches.Any(p=>p.assetId==asset))return null;
            if(room.sourceSha256!=manifest.sourceSha256||manifest.roomId!=room.roomId)throw new InvalidDataException("Source-range repair room owner differs from its manifest.");
            return new MeshPatchIdentity{AssetId=asset,SourceSha256=room.sourceSha256,ManifestSha256=room.manifestSha256,MeshFile=mesh.meshFile,
                MeshSha256=mesh.sha256,MeshName=mesh.name,Collider=collider,SourceVertices=mesh.vertices,SourceIndices=mesh.indices};
        }
        internal static string CacheToken(MeshPatchIdentity identity)=>identity==null||PinnedMeshRangePatchPolicy.Select(payload.Value,identity).Length==0?"":"|source-range-repair-v82|"+PayloadSha256;
        // Read-only diagnostic view of the already validated source ownership.
        internal static object DescribeRanges(LoadedRoom room,MeshRecord record)
        {
            var id=Identity(room.PackageDirectory,room.PackageDirectory,room.Record,room.Manifest,record,false);
            if(id==null)return Array.Empty<object>();
            return PinnedMeshRangePatchPolicy.Select(payload.Value,id).Select(p=>new {
                p.assetId,p.meshName,p.meshSha256,p.firstIndex,p.indexCount,p.appendAtEnd,p.witnessSha256,
                replacementVertices=p.newVertices.Length,replacementIndices=p.newIndices.Length
            }).ToArray();
        }
        internal static void RegisterPewSource(object mesh,MeshPatchIdentity identity,int uploadedVertices,int uploadedIndices,bool welded)
        {
            var rows=PinnedMeshRangePatchPolicy.Select(payload.Value,identity);
            if(rows.Length==0)throw new InvalidDataException("Only an exact repaired primary source may carry pew repair provenance.");
            PewRepairProvenance.Register(mesh,PewRepairCompositionPolicy.Create(identity,rows,PayloadSha256,uploadedVertices,uploadedIndices,welded));
        }
        private static MeshPatchIdentity PewIdentity(LoadedRoom room,MeshRecord record,bool collider)
        {
            var identity=Identity(room.PackageDirectory,room.PackageDirectory,room.Record,room.Manifest,record,collider);
            if(identity==null||CacheToken(identity).Length==0)throw new InvalidDataException("Pew repair provenance requires its exact primary room/mesh binding.");
            return identity;
        }
        internal static void RequireRemainderLineage(LoadedRoom room,MeshRecord record,bool collider,PewRepairProof proof,int derivedSourceIndexCount)
        {PewRepairCompositionPolicy.RequireLineage(proof,PewIdentity(room,record,collider),PayloadSha256,derivedSourceIndexCount);}
        internal static int RequirePewSource(LoadedRoom room,PewMeshRecord source,bool collider,int actualVertices,int actualIndices,PewRepairProof proof,PewIndexRange[] pewRanges,string dataRoot)
        {
            var record=(collider?room.Manifest.colliderMeshes:room.Manifest.meshes).SingleOrDefault(r=>r.name==source.name);
            if(record==null||record.sha256!=source.sourceMeshSha256||record.vertices!=source.sourceVertexCount||record.indices!=source.sourceIndexCount||
                source.purpose!=(collider?"collider":"render")||pewRanges==null)
                throw new InvalidDataException("Pew repair source differs from its declared original ownership.");
            var protectedSets=new List<int[]>{pewRanges.SelectMany(r=>Enumerable.Range(r.startIndex/3,r.indexCount/3)).ToArray()};
            const string relative="false-vows/false-vows-assets.json";
            string expected=KitArchitectureProfile.ExpectedHash(dataRoot,relative,FalseVowsAssetVersion.ManifestSha256);
            var bytes=BarMeshReader.ReadVerifiedBytes(RoomPackage.FilePath(dataRoot,relative),expected,8L*1024*1024);
            var quest=JsonConvert.DeserializeObject<FalseVowsAssetManifest>(System.Text.Encoding.UTF8.GetString(bytes),ManifestReader.Settings());
            if(quest?.rooms==null||quest.routeVisibilityBindings==null)throw new InvalidDataException("Repaired pew source lacks its checked later-mask inventory.");
            var maskSets=quest.rooms.Where(r=>r.id==room.Manifest.roomId&&r.baseSourceSha256==room.Manifest.sourceSha256).Select(r=>r.masks)
                .Concat(quest.routeVisibilityBindings.Where(r=>r.roomId==room.Manifest.roomId&&r.baseSourceSha256==room.Manifest.sourceSha256).Select(r=>r.masks));
            foreach(var masks in maskSets)
            {
                if(masks==null)throw new InvalidDataException("Missing protected later source masks.");
                foreach(var mask in masks.Where(m=>m.collider==collider&&m.name==record.name))
                {
                    if(mask.meshSha256!=record.sha256||mask.triangleIndices==null)throw new InvalidDataException("Later mask differs from its repaired original source.");
                    protectedSets.Add(mask.triangleIndices);
                }
            }
            return PewRepairCompositionPolicy.Require(proof,PewIdentity(room,record,collider),PayloadSha256,actualVertices,actualIndices,protectedSets.ToArray());
        }
        internal static BarMeshData Apply(MeshPatchIdentity identity,BarMeshData source)
        {
            if(identity==null)return source;
            if(source?.Positions==null||source.Positions.Length!=identity.SourceVertices||source.Indices==null)
                throw new InvalidDataException("Source-range repair requires the decoded original source buffer.");
            var result=PinnedMeshRangePatchPolicy.Apply(payload.Value,identity,source.Indices,(i,c)=>c==0?source.Positions[i].x:c==1?source.Positions[i].y:source.Positions[i].z);
            if(result==null)return source;
            if(identity.Collider?(source.Normals!=null||source.UV!=null||source.Tangents!=null):
                (source.Normals?.Length!=source.Positions.Length||source.UV?.Length!=source.Positions.Length||source.Tangents?.Length!=source.Positions.Length))
                throw new InvalidDataException("Source-range repair channel ownership differs from BAR1 decoding.");
            int count=checked(source.Positions.Length+result.AddedVertices.Length);
            var output=new BarMeshData{Positions=new Vector3[count],Indices=result.Indices,Normals=identity.Collider?null:new Vector3[count],
                UV=identity.Collider?null:new Vector2[count],Tangents=identity.Collider?null:new Vector4[count]};
            Array.Copy(source.Positions,output.Positions,source.Positions.Length);
            if(!identity.Collider){Array.Copy(source.Normals,output.Normals,source.Normals.Length);Array.Copy(source.UV,output.UV,source.UV.Length);Array.Copy(source.Tangents,output.Tangents,source.Tangents.Length);}
            for(int added=0;added<result.AddedVertices.Length;added++)
            {
                int at=source.Positions.Length+added;var v=result.AddedVertices[added];output.Positions[at]=new Vector3(v[0],v[1],v[2]);
                if(identity.Collider)continue;
                output.Normals[at]=new Vector3(v[3],v[4],v[5]);output.UV[at]=new Vector2(v[6],v[7]);output.Tangents[at]=new Vector4(v[8],v[9],v[10],v[11]);
            }
            return output;
        }
        internal static int VisualTriangleDelta(CatalogRoomRecord room,PackageManifest manifest)
        {
            if(room==null||manifest==null||!payload.Value.patches.Any(p=>p.assetId==room.packageDirectory))return 0;
            if(room.sourceSha256!=manifest.sourceSha256||manifest.roomId!=room.roomId)throw new InvalidDataException("Source-range triangle accounting differs from its room owner.");
            return PinnedMeshRangePatchPolicy.VisualTriangleDelta(payload.Value,room.packageDirectory,room.sourceSha256,room.manifestSha256);
        }
    }
}
