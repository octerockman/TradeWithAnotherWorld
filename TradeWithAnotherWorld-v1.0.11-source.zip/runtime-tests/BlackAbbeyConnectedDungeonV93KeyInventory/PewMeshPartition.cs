using System;
using System.Collections.Generic;
using System.IO;

namespace BlackAbbeySixRooms
{
    internal sealed class PewMeshSection
    {
        internal int[] SourceVertices, SourceTriangles, Indices;
        internal int TriangleCount => Indices.Length / 3;
        internal T[] Copy<T>(T[] source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            var result = new T[SourceVertices.Length];
            for (int i = 0; i < result.Length; i++) result[i] = source[SourceVertices[i]];
            return result;
        }
    }
    // Offsets refer to the original triangle stream. Native exact-position
    // collider welding changes vertex indices, but retains that stream order.
    internal static class PewMeshPartition
    {
        internal static PewMeshSection Build(int[] sourceIndices, int vertexCount, IEnumerable<PewIndexRange> ranges, bool remainder = false)
        {
            if (sourceIndices == null || sourceIndices.Length % 3 != 0 || vertexCount < 3 || ranges == null)
                throw new InvalidDataException("Invalid source mesh for pew partition.");
            var selected = new bool[sourceIndices.Length / 3];
            foreach (var range in ranges)
            {
                if (range == null || range.startIndex < 0 || range.indexCount <= 0 || range.startIndex % 3 != 0 || range.indexCount % 3 != 0 ||
                    (long)range.startIndex + range.indexCount > sourceIndices.Length) throw new InvalidDataException("Pew range exceeds source mesh.");
                for (int i = range.startIndex / 3; i < (range.startIndex + range.indexCount) / 3; i++)
                { if (selected[i]) throw new InvalidDataException("Duplicate pew triangle."); selected[i] = true; }
            }
            var vertices = new List<int>(); var triangles=new List<int>();var indices = new List<int>(); var remap = new Dictionary<int, int>();
            for (int i = 0; i < sourceIndices.Length; i++)
            {
                int old = sourceIndices[i];
                if (old < 0 || old >= vertexCount) throw new InvalidDataException("Source mesh has an invalid vertex index.");
                if (selected[i / 3] == remainder) continue;
                if(i%3==0)triangles.Add(i/3);
                if (!remap.TryGetValue(old, out int next)) { next = vertices.Count; vertices.Add(old); remap.Add(old, next); }
                indices.Add(next);
            }
            return new PewMeshSection { SourceVertices = vertices.ToArray(), SourceTriangles=triangles.ToArray(),Indices = indices.ToArray() };
        }
    }
}
