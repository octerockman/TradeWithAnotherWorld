using System;
using System.IO;
using System.Linq;
using HarmonyLib;

namespace BlackAbbeySixRooms
{
    /// <summary>Explicit process-only test profile; never changes Steam/account settings.</summary>
    internal static class IsolatedSaveProfile
    {
        internal const string Flag = "-ba-test-save-dir";
        private const string MarkerName = ".black-abbey-room-test-profile";
        private const string MarkerText = "BlackAbbeyRoomTest isolated local save profile v1";
        private static Harmony processOverride;
        internal static string ActivePath { get; private set; }
        private static string Normalize(string path) => Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        private static bool CloudUnsupported(ref bool __result) { __result = false; return false; }

        internal static void Configure(Action<string> log)
        {
            string[] args = Environment.GetCommandLineArgs();
            int[] found = args.Select((value, index) => new { value, index }).Where(x => string.Equals(x.value, Flag, StringComparison.OrdinalIgnoreCase)).Select(x => x.index).ToArray();
            if (found.Length == 0) { log("Isolated save override inactive: no " + Flag + ". No save path/cloud patch applied."); return; }
            if (found.Length != 1 || found[0] + 1 >= args.Length) throw new InvalidOperationException("Provide exactly one " + Flag + " followed by an absolute private test directory.");
            string argument = args[found[0] + 1];
            if (string.IsNullOrWhiteSpace(argument) || argument.StartsWith("-", StringComparison.Ordinal) || !Path.IsPathRooted(argument)) throw new InvalidOperationException("Isolated save directory must be absolute.");
            string path = Normalize(argument);
            if (path.Length == 0 || path.Equals(Normalize(Path.GetPathRoot(path)), StringComparison.OrdinalIgnoreCase) || File.Exists(path)) throw new InvalidOperationException("A filesystem root/file cannot be the isolated save directory.");
            string marker = Path.Combine(path, MarkerName);
            if (Directory.Exists(path) && Directory.EnumerateFileSystemEntries(path).Any())
            {
                if (!File.Exists(marker) || File.ReadAllText(marker).Trim() != MarkerText) throw new InvalidOperationException("Refusing nonempty unmarked save directory. Existing save data is left untouched.");
            }
            // Early BepInEx Awake can precede PlatformManager initialization.
            // Even GetSaveDataPath(Local) can consult cloud support first, so
            // preserve the verified raw nullable override without calling it.
            var overrideField = AccessTools.Field(typeof(Utils), "m_saveDataOverride");
            if (overrideField == null || !overrideField.IsStatic || overrideField.FieldType != typeof(string)) throw new MissingFieldException("Verified Utils.m_saveDataOverride field is unavailable; no profile override applied.");
            string previousOverride = (string)overrideField.GetValue(null);
            var getter = AccessTools.PropertyGetter(typeof(FileHelpers), "CloudStorageSupported") ?? AccessTools.Method(typeof(FileHelpers), "get_CloudStorageSupported", Type.EmptyTypes);
            if (getter == null || getter.ReturnType != typeof(bool)) throw new MissingMethodException("Verified FileHelpers.CloudStorageSupported getter is unavailable; no profile override applied.");
            Directory.CreateDirectory(path);
            if (!File.Exists(marker)) File.WriteAllText(marker, MarkerText + Environment.NewLine);
            processOverride = new Harmony(RuntimeTestPlugin.Id + ".isolated-save-profile");
            try
            {
                processOverride.Patch(getter, prefix: new HarmonyMethod(typeof(IsolatedSaveProfile), nameof(CloudUnsupported)) { priority = Priority.First });
                Utils.SetSaveDataPath(path);
                string local = Utils.GetSaveDataPath(FileHelpers.FileSource.Local), auto = Utils.GetSaveDataPath(FileHelpers.FileSource.Auto);
                bool cloud = FileHelpers.CloudStorageSupported, cloudEnabled = FileHelpers.CloudStorageSupportedAndEnabled;
                if (!Normalize(local).Equals(path, StringComparison.OrdinalIgnoreCase) || !Normalize(auto).Equals(path, StringComparison.OrdinalIgnoreCase) || cloud || cloudEnabled)
                    throw new InvalidOperationException("Isolated profile verification failed: Local=" + local + ", Auto=" + auto + ", CloudSupported=" + cloud + ", CloudSupportedAndEnabled=" + cloudEnabled);
                ActivePath = path;
                log("ISOLATED_TEST_PROFILE PASS: requested=" + path + "; GetSaveDataPath(Local)=" + local + "; GetSaveDataPath(Auto)=" + auto + "; cloud-disabled-for-this-process=true. New local test profile only; Steam/account settings and existing saves unchanged.");
                // Keep the prefix for this process, including all shutdown save
                // callbacks. A full restart without the opt-in flag has none.
            }
            catch
            {
                try { overrideField.SetValue(null, previousOverride); } finally { processOverride.UnpatchSelf(); processOverride = null; }
                throw;
            }
        }
    }
}
