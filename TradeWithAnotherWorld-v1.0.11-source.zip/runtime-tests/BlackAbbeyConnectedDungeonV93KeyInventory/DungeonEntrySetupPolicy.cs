using System;

namespace BlackAbbeySixRooms
{
    internal enum EncounterRegistryAction { Create, Reconcile, RestoreSuspended }
    internal static class DungeonEntrySetupPolicy
    {
        internal static bool CanUseResident(bool naturalPlan, bool committedSetup, bool geometryReady, bool monkReady, bool wardingRequired, bool wardingReady)
            => naturalPlan && committedSetup && geometryReady && monkReady && (!wardingRequired || wardingReady);
        internal static EncounterRegistryAction Registry(bool exists, bool disposed, bool sameSeed, bool sameWorld)
        {
            if (!exists) return EncounterRegistryAction.Create;
            if (!sameSeed || !sameWorld) throw new InvalidOperationException("A changed layout/world needs a new dungeon-run identity.");
            return disposed ? EncounterRegistryAction.RestoreSuspended : EncounterRegistryAction.Reconcile;
        }
        internal static T ResumeSnapshot<T>(T supplied, T suspended) where T : class => suspended ?? supplied;
        internal static void Initialize(Action begin, Action monks, Action warding, Func<bool> checkpoint, Action complete, Action failed)
        {
            if (begin == null || monks == null || warding == null || checkpoint == null || complete == null || failed == null) throw new ArgumentNullException("Encounter setup callbacks are required.");
            begin();
            try
            {
                monks(); warding();
                if (!checkpoint()) throw new InvalidOperationException("Encounter setup checkpoint could not be committed; the saved run was retained.");
                complete();
            }
            catch { failed(); throw; }
        }
    }
}
