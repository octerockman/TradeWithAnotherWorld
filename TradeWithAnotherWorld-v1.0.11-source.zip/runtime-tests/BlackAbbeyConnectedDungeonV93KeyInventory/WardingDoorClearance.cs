using UnityEngine;

namespace BlackAbbeySixRooms
{
    internal static class WardingDoorClearance
    {
        internal static bool InSwing(Transform door,Character actor,out Vector3 local,out float radius)
        {
            local=Vector3.zero;radius=.35f;
            if(!actor||actor.IsDead())return false;
            local=door.InverseTransformPoint(actor.transform.position);
            var cap=actor.GetComponent<CapsuleCollider>();
            if(cap)radius=Mathf.Max(.2f,cap.radius*Mathf.Max(Mathf.Abs(actor.transform.lossyScale.x),Mathf.Abs(actor.transform.lossyScale.z)));
            return local.z>-.02f-radius&&local.z<1.62f+radius&&Mathf.Abs(local.x)<1.54f+radius&&local.y>-.5f&&local.y<4.5f;
        }
        internal static void Nudge(Transform door,Character actor)
        {
            if(!WardingSpawnerActors.IsHostOwned(actor)||!actor.CanMove()||actor.InAttack()||actor.IsStaggering()||
                !InSwing(door,actor,out var local,out float radius))return;
            var body=actor.GetComponent<Rigidbody>();var cap=actor.GetComponent<CapsuleCollider>();
            if(!body||!cap)return;
            // Push toward the nearest end of the real swing bay. Native
            // pushback respects the character body and never teleports it.
            Vector3 direction=door.forward*(local.z<.8f?-1:1);
            int mask=LayerMask.GetMask("static_solid");if(mask==0)return;
            float height=Mathf.Max(radius*2+.02f,cap.height*Mathf.Abs(actor.transform.lossyScale.y));
            Vector3 center=actor.transform.TransformPoint(cap.center);float extent=height*.5f-radius;
            if(Physics.CapsuleCast(center+Vector3.up*extent,center-Vector3.up*extent,radius*.94f,direction,out _,.22f,mask,QueryTriggerInteraction.Ignore)||
                !Physics.Raycast(actor.transform.position+direction*.32f+Vector3.up*.25f,Vector3.down,out var floor,.55f,mask,QueryTriggerInteraction.Ignore)||
                floor.normal.y<.65f)return;
            actor.ApplyPushback(direction,body.mass*.55f/2.5f);
        }
    }
}
