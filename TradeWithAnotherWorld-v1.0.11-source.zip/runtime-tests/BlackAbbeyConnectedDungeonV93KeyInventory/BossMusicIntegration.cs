using System;
using BepInEx.Configuration;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        private BossMusicRuntime bossMusic;
        private ConfigEntry<bool> bossMusicEnabled;
        private ConfigEntry<float> bossMusicVolume;
        private void InitializeBossMusic()
        {
            bossMusicEnabled = Config.Bind("BossMusic", "Enabled", true, "Play The Sealed Choir for the local R09 encounter.");
            bossMusicVolume = Config.Bind("BossMusic", "Volume", 1f,
                new ConfigDescription("Multiplier for the boss score; native Music and Master sliders also apply.", new AcceptableValueRange<float>(0f, 1f)));
            bossMusic = gameObject.AddComponent<BossMusicRuntime>();
            bossMusic.Initialize(SharedDataPath, text => Logger.LogInfo(text));
            Add("twa_boss_music_status", "Report owned R09 soundtrack readiness, phase and native music-volume routing.", false,
                () => bossMusic?.LogStatus(Print));
        }
        private void TickBossMusic(bool insideBossRoom)
        {
            try
            {
                bossMusic?.Configure(bossMusicEnabled.Value, bossMusicVolume.Value);
                bossMusic?.Tick(insideBossRoom, Time.unscaledDeltaTime);
            }
            catch (Exception error)
            {
                bossMusic?.Release();
                Logger.LogWarning("R09 music stopped safely: " + error.Message);
            }
        }
    }
}
