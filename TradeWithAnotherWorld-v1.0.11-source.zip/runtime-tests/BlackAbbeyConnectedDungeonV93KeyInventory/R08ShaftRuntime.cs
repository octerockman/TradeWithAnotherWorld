using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using Jotunn.Managers;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // Bounded shaft recovery and haze; ordinary landings retain native fall damage. No hidden floor bridges the
    // authored broken stairs or central well.
    internal sealed class R08ShaftRuntime : MonoBehaviour
    {
        private static readonly List<R08ShaftRuntime> instances = new List<R08ShaftRuntime>();
        private static readonly FieldInfo airAltitude = AccessTools.Field(typeof(Character), "m_maxAirAltitude");
        private LoadedRoom room;
        private BottomMistRecord record;
        private Func<Player, bool> authorized;
        private Action<string> log;
        private Material mistMaterial;
        private float nextRecovery;

        internal static void Attach(LoadedRoom room, Func<Player, bool> authorized, Action<string> log)
        {
            if (room.Manifest.roomId != "R08") return;
            var r = room.Manifest.bottomMist;
            if (r == null) throw new InvalidOperationException("R08 requires its source-bound bottom/recovery datums.");
            var position = RoomPackage.Vector(r.position, "bottom mist position");
            var size = RoomPackage.Vector(r.size, "bottom mist extent");
            var recovery = RoomPackage.Vector(r.recoveryPosition, "lower arrival recovery");
            if (size.x <= 0 || size.z <= 0 || size.y <= 0 || size.x > 16 || size.z > 16 || size.y > 8 ||
                !UnrecordedDeadFallPolicy.Allows(room.Manifest.sourceSha256,r.recoveryBelow) ||
                !RoomPackage.Finite(r.density) || r.density <= 0 || r.density > .25f ||
                !RoomPackage.Finite(r.opacity) || r.opacity <= 0 || r.opacity > 1 ||
                r.color?.Length != 3 || r.color.Any(v => !RoomPackage.Finite(v) || v < 0 || v > 1) ||
                position.y > -20 || position.y < -28 || recovery.y < .3 || recovery.y > 2)
                throw new InvalidOperationException("R08 source bottom/recovery inventory is invalid.");
            if (airAltitude == null || airAltitude.FieldType != typeof(float) || AccessTools.Method(typeof(Character), "UpdateGroundContact") == null)
                throw new MissingFieldException("Installed Valheim fall state differs; refuse unsafe R08 test loading.");
            var component = room.Root.AddComponent<R08ShaftRuntime>();
            component.room = room; component.record = r; component.authorized = authorized; component.log = log;
            instances.Add(component); component.CreateMist(position, size);
            log("R08_SHAFT: authored broken descent retained; recovery below localY=" + r.recoveryBelow + "; safe arrival=" + recovery + "; native landing fall damage enabled; no global god-mode/world setting change.");
        }

        private bool Contains(Player player, float lowerPadding = 0)
        {
            if (!player || !room.Root || !room.Root.activeInHierarchy || player.transform.position.y < 7000 || authorized == null || !authorized(player)) return false;
            var p = room.Root.transform.InverseTransformPoint(player.transform.position);
            Vector3 low = RoomPackage.Vector(room.Manifest.boundsMin, "shaft min"), high = RoomPackage.Vector(room.Manifest.boundsMax, "shaft max");
            return p.x >= low.x && p.x <= high.x && p.z >= low.z && p.z <= high.z && p.y >= low.y - lowerPadding && p.y <= high.y + 2;
        }

        internal bool TryRecover(Player player)
        {
            // A fall inside a loaded room is a local physics reset, not a
            // distant world teleport. Native UpdateTeleport waits on streamed
            // terrain readiness and can leave its loading state open forever.
            if (!player || player != Player.m_localPlayer || player.IsDead() || player.IsTeleporting() || !Contains(player, 8) ||
                room.Root.transform.InverseTransformPoint(player.transform.position).y >= record.recoveryBelow) return false;
            if (Time.unscaledTime < nextRecovery) return true;
            nextRecovery = Time.unscaledTime + 1;
            var target = room.Root.transform.TransformPoint(RoomPackage.Vector(record.recoveryPosition, "R08 safe recovery"));
            var forward = Vector3.ProjectOnPlane(room.Root.transform.TransformDirection(RoomPackage.Vector(room.Manifest.entryForward, "R08 recovery forward")), Vector3.up);
            var facing = Quaternion.LookRotation(forward, Vector3.up);
            var body = player.GetComponent<Rigidbody>();
            if (!body) { log("R08_FALL_RECOVERY_UNAVAILABLE: live local player has no physics body; no teleport/loading state was started."); return false; }
            // Use only the source-bound arrival in this exact loaded room.
            // Check its real collider rather than relying on a terrain zone at
            // the dungeon's synthetic altitude. Never add a hidden shaft floor.
            var support = Physics.RaycastAll(target + Vector3.up * 2, Vector3.down, 4,
                LayerMask.GetMask("static_solid"), QueryTriggerInteraction.Ignore)
                .Any(h => h.collider && h.normal.y >= .6f && h.point.y <= target.y &&
                    target.y - h.point.y <= 2 && h.collider.transform.IsChildOf(room.Root.transform));
            if (!support)
            {
                // The room normally passed its source-bound floor preflight.
                // If that live support disappears, retain local control and
                // allow the existing authored-room return path to handle it.
                log("R08_FALL_RECOVERY_UNAVAILABLE: source-bound arrival has no live room floor; no teleport/loading state was started.");
                return false;
            }
            // The void catcher is a supported local arrival, not fall immunity.
            // Match this installed Character.UpdateGroundContact formula and
            // its native status-effect modifier before resetting fall history.
            float drop=Mathf.Max(0,(float)airAltitude.GetValue(player)-player.transform.position.y);
            float damage=Mathf.Clamp01((drop-4f)/16f)*100f;
            player.GetSEMan().ModifyFallDamage(damage,ref damage);
            body.linearVelocity = Vector3.zero; body.angularVelocity = Vector3.zero;
            body.position = target; body.rotation = facing;
            player.transform.SetPositionAndRotation(target, facing);
            airAltitude.SetValue(player, target.y);
            player.SetLookDir(forward, 0); player.ResetCloth();
            Physics.SyncTransforms();
            if(damage>0)
            {
                var hit=new HitData();hit.m_damage.m_damage=damage;hit.m_point=target;hit.m_dir=Vector3.up;hit.m_hitType=HitData.HitType.Fall;
                player.Damage(hit);
            }
            log("R08_FALL_RECOVERY: completed local physics reset to the same room arrival; no native teleport/loading state; surface checkpoint and dungeon state retained.");
            return true;
        }

        private void CreateMist(Vector3 position, Vector3 size)
        {
            var fire = PrefabManager.Instance.GetPrefab("fire_pit");
            var source = fire ? fire.GetComponentsInChildren<ParticleSystemRenderer>(true).FirstOrDefault(r => r.name.IndexOf("smoke", StringComparison.OrdinalIgnoreCase) >= 0 && r.sharedMaterial && r.sharedMaterial.shader && r.sharedMaterial.shader.isSupported) : null;
            if (!source) { log("R08_BOTTOM_MIST_PENDING: loaded vanilla fire_pit smoke material unavailable; fall recovery enabled. No substitute polygon floor."); return; }
            var host = new GameObject("BA_R08 | static bottom mist | native fire smoke"); host.transform.SetParent(room.Root.transform, false); host.transform.localPosition = position;
            var system = host.AddComponent<ParticleSystem>(); var main = system.main;
            main.loop = false; main.playOnAwake = false; main.simulationSpace = ParticleSystemSimulationSpace.Local;
            main.startSpeed = 0; main.gravityModifier = 0; main.startLifetime = 999999; main.maxParticles = 128;
            var emission = system.emission; emission.enabled = false; var shape = system.shape; shape.enabled = false;
            var renderer = system.GetComponent<ParticleSystemRenderer>();
            mistMaterial = new Material(source.sharedMaterial) { name = "BA_R08 | native smoke bottom haze" };
            renderer.sharedMaterial = mistMaterial; renderer.renderMode = ParticleSystemRenderMode.Billboard;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off; renderer.receiveShadows = false;
            int count = Mathf.Clamp(Mathf.RoundToInt(size.x * size.y * size.z * record.density * 6), 48, 128);
            var random = new System.Random(80829); var particles = new ParticleSystem.Particle[count];
            for (int i = 0; i < count; i++) particles[i] = new ParticleSystem.Particle {
                position = new Vector3(((float)random.NextDouble() - .5f) * size.x, ((float)random.NextDouble() - .5f) * size.y, ((float)random.NextDouble() - .5f) * size.z),
                startSize = 3.5f + (float)random.NextDouble() * 2.5f, startColor = new Color(record.color[0], record.color[1], record.color[2], record.opacity),
                startLifetime = 999999, remainingLifetime = 999999, rotation = (float)random.NextDouble() * 360, velocity = Vector3.zero };
            system.Play(false); system.SetParticles(particles, count);
            log("R08_BOTTOM_MIST: native fire_pit/" + source.name + "; material=" + source.sharedMaterial.name + "; bounded stationary smoke billboards=" + count + "; local=" + position + "; size=" + size + "; no gameplay prefab, shadow light or hidden floor.");
        }

        private void OnDestroy() { instances.Remove(this); if (mistMaterial) Object.Destroy(mistMaterial); }
    }
}
