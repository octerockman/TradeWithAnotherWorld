using System;
using System.IO;
using System.Linq;
using UnityEngine;
using Object=UnityEngine.Object;
namespace BlackAbbeySixRooms
{
    internal static partial class KitPointedArchitecture
    {
        internal static GameObject CreateModule(Transform parent,Vector3 position,Quaternion rotation,string part,LoadedRoom kit)
        {
            if(!parent||kit?.Root==null||kit.Manifest.roomId!=KitId)throw new InvalidDataException("Wrong pointed connector source.");
            var root=new GameObject("Pointed shared connector | "+part);root.SetActive(false);root.transform.SetParent(parent,false);
            root.transform.localPosition=position;root.transform.localRotation=rotation;root.transform.localScale=Vector3.one;
            try
            {
                foreach(var row in kit.Manifest.meshes.Where(m=>m.partId==part))Clone(kit.Root.transform.Find(row.name),root.transform,row.name);
                foreach(var row in kit.Manifest.colliderMeshes.Where(m=>m.partId==part))Clone(kit.Root.transform.Find("Collider | "+row.name),root.transform,"Collider | "+row.name);
                if(root.transform.childCount==0)throw new InvalidDataException("Empty pointed connector module.");
                root.SetActive(true);return root;
            }
            catch{Object.Destroy(root);throw;}
        }
        private static void Clone(Transform source,Transform parent,string name)
        {
            if(!source)throw new InvalidDataException("Missing pointed source chunk: "+name);
            var clone=Object.Instantiate(source.gameObject,parent,false);clone.name=name;clone.transform.localPosition=Vector3.zero;clone.transform.localRotation=Quaternion.identity;clone.transform.localScale=Vector3.one;clone.SetActive(true);
        }
        internal static AbbeyDoor CreateDoor(Transform parent,Vector3 inner,Quaternion outward,bool barred,AbbeyDoorAssets assets,PortRecord port)
        {
            if(!Pointed(port)||assets?.Template?.Manifest?.roomId!=DoorId||assets.Fit.woodProfileMode!=DoorMode)throw new InvalidDataException("Rebuilt ordinary door requires its exact pointed source and mouth.");
            var root=Object.Instantiate(assets.Template.Root,parent);root.SetActive(false);root.name="Pointed oak doors | "+port.id;
            root.transform.localPosition=inner+outward*(Vector3.forward*(port.depth-HalfReach));root.transform.localRotation=outward;root.transform.localScale=Vector3.one;
            try
            {
                var bodies=new MeshCollider[2];var bounds=new Bounds[2];var hinges=new Transform[2];
                for(int i=0;i<2;i++)
                {
                    string id=i==0?"left_leaf":"right_leaf";
                    Vector3 pivot=RoomPackage.Vector(i==0?assets.Fit.leftHinge:assets.Fit.rightHinge,"pointed hinge");
                    var hinge=new GameObject("Hinge | "+id).transform;hinge.SetParent(root.transform,false);hinge.localPosition=pivot;hinges[i]=hinge;
                    foreach(var rec in assets.Template.Manifest.meshes.Where(m=>m.partId==id))
                    {
                        var child=root.transform.Find(rec.name);if(!child)throw new InvalidDataException("Missing pointed moving leaf chunk.");
                        child.SetParent(hinge,false);child.localPosition=-pivot;
                        // The rebuilt source keeps its molten opening inlay in
                        // separate owned chunks, so unused barred mouths retain
                        // the same non-glowing policy as ordinary old doors.
                        if(rec.name.IndexOf("opening_symbol_",StringComparison.OrdinalIgnoreCase)>=0)child.gameObject.SetActive(!barred);
                    }
                    var source=root.transform.Find("Collider | "+id);if(!source)throw new InvalidDataException("Missing pointed leaf body.");
                    var body=source.GetComponent<MeshCollider>();if(!body||body.sharedMesh.triangles.Length/3>255)throw new InvalidDataException("Pointed leaf requires a bounded convex body.");
                    source.SetParent(hinge,false);source.localPosition=-pivot;body.convex=true;bodies[i]=body;
                    bounds[i]=body.sharedMesh.bounds;bounds[i].center-=pivot;
                }
                foreach(var rec in assets.Template.Manifest.meshes.Where(m=>m.partId=="barred_crossbar"))root.transform.Find(rec.name).gameObject.SetActive(barred);
                if(barred)
                {
                    BarredDoorPresentation.Apply(root,assets);
                }
                var door=root.AddComponent<AbbeyDoor>();door.Configure(hinges[0],hinges[1],bounds[0],bounds[1],barred,assets.Fit.openAngle);
                foreach(var body in bodies)body.gameObject.AddComponent<AbbeyDoorHandle>().Door=door;
                root.SetActive(true);return door;
            }
            catch{Object.Destroy(root);throw;}
        }
        internal static void ValidateDoor(PackageManifest m)
        {
            if(m?.roomId!=DoorId||m.sourceSha256!="80c745a777adaec71c7370376036a4de51e72d37b2d1283cffcf2c15f6829675"||m.doorFit?.woodProfileMode!=DoorMode||m.doorFit.assemblyStyle!=DoorMode||!Near(m.doorFit.clearWidth,3)||!Near(m.doorFit.clearHeight,4)||!Near(m.doorFit.openAngle,90)||!Near(m.doorFit.mountDepth,0))throw new InvalidDataException("Invalid pointed oak source fit.");
            foreach(var id in new[]{"left_leaf","right_leaf"})
                if(!m.meshes.Any(x=>x.partId==id)||m.colliderMeshes.Count(x=>x.name==id)!=1)throw new InvalidDataException("Pointed oak requires separate mapped visuals and one convex body per leaf.");
            if(m.meshes.Any(x=>!new[]{"left_leaf","right_leaf","static","barred_crossbar"}.Contains(x.partId)))throw new InvalidDataException("Unowned pointed oak visual chunk.");
        }
    }
}
