using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Shared managed rules for the real actor journey and joint source/actor
    // checkpoint. Missing actors remain reservations, never proof of a return.
    internal static class WardingSpawnerRetrieval
    {
        internal static bool FetchJourney(WardingActorRecord actor) => actor != null &&
            actor.prefab == "TWA_HushedMonk_Test" && (actor.journey == "Entering" || actor.journey == "Away" ||
            actor.journey == "Returning" || actor.journey == "Blocked" || actor.journey == "Exiting");

        internal static bool HasRetrieval(IEnumerable<WardingActorRecord> actors, string source) =>
            actors.Any(actor => actor.sourceId == source && actor.state != "Dead" && FetchJourney(actor));

        internal static bool LegacyAwaitingReturn(WardingActorRecord actor)
        {
            if (actor == null || actor.returned) return false;
            if (FetchJourney(actor)) return true;
            // V82 replaced any travelling journey with Died. Borrowed monks
            // were always fetchers. Produced fetches used the exact8s route;
            // produced emergence used3.5s. Require its complete saved path so
            // an ordinary dead/emerging monk does not turn into a fetch.
            return actor.prefab == "TWA_HushedMonk_Test" && actor.journey == "Died" &&
                actor.uidUser != 0 && actor.uidId != 0 && (actor.borrowed || actor.journeySeconds == 8f &&
                actor.mouth != null && actor.hidden != null && actor.innerDoor != null && actor.exit != null);
        }

        internal static bool CommitSourceReturn(WardingSpawnerState source, Func<bool> commit)
        {
            bool reinforced = source.reinforced, waiting = source.awaitingReturn, saved = false;
            source.reinforced = true; source.awaitingReturn = false;
            try { saved = commit(); return saved; }
            finally { if (!saved) { source.reinforced = reinforced; source.awaitingReturn = waiting; } }
        }

        internal static bool NotifyReturn(WardingActorRecord actor, Func<string, Func<bool>, bool> returnedAlive, Func<bool> commit)
        {
            if (actor.returned) return true;
            if (actor.state != "Alive" || actor.journey != "Blocked" && actor.journey != "Exiting" || returnedAlive == null) return false;
            bool saved = false; actor.returned = true;
            try { saved = returnedAlive(actor.sourceId, commit); return saved; }
            finally { if (!saved) actor.returned = false; }
        }

        internal static bool Begin(IDictionary<string, WardingActorRecord> records, WardingActorRecord actor,
            bool added, Action prepare, Func<bool> commit)
        {
            var before = added ? null : WardingSpawnerActorPersistence.Copy(new WardingActorLedger {
                actors = new List<WardingActorRecord> { actor }
            }).actors[0];
            bool saved = false;
            try { prepare(); saved = commit(); return saved; }
            finally
            {
                // Restore the entire previous journey, including returned and
                // its source association; do not turn Completed into None or
                // leave a newly borrowed record behind after a failed save.
                if (!saved) { if (added) records.Remove(actor.key); else records[actor.key] = before; }
            }
        }
    }
}
