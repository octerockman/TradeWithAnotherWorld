using System.IO;

namespace BlackAbbeySixRooms
{
    // The room identity stays real. Only this parchment interaction accepts
    // the exact rebuilt R02 sources admitted by the sealed kit master.
    internal static class ScriptoriumParchmentSourcePolicy
    {
        internal static void Require(string roomId, string source, string recordSource, string manifestHash)
        {
            if (roomId != "R02" || source != recordSource)
                throw new InvalidDataException("Scriptorium clue requires matching R02 manifest/catalog identities.");
            var rebuilt = KitArchitectureProfile.Find(source, manifestHash);
            if (rebuilt != null && rebuilt.roomId == "R02" &&
                (rebuilt.assetId == "R02" || rebuilt.assetId == "R02-UD")) return;
            if (UnrecordedDeadSourceBindings.Canonical(roomId, source) == ScriptoriumParchment.RoomSource) return;
            throw new InvalidDataException("Scriptorium clue requires the checked R02 parchment source.");
        }
    }
}
