using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using BepInEx.Bootstrap;
using HarmonyLib;
using Jotunn.Managers;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // No prefab/AI-wide patches. A small component leases movement only for an
    // explicitly claimed host actor; Character, health and SEMan stay enabled.
    internal sealed partial class WardingSpawnerActors:IDisposable
    {
        const string RunKey="twa_ward_run",WorldKey="twa_ward_world",SourceKey="twa_ward_source",ActorKey="twa_ward_actor";
        static readonly MethodInfo AlertMethod=typeof(BaseAI).GetMethod("SetAlerted",BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic,null,new[]{typeof(bool)},null);
        static readonly MethodInfo FlushDestroyed=typeof(ZDOMan).GetMethod("SendDestroyed",BindingFlags.Instance|BindingFlags.NonPublic,null,Type.EmptyTypes,null);
        static Harmony deathPresentationHook;
        readonly string runId,worldKey;readonly int seed;readonly Action<string> log;
        readonly Func<WardingActorLedger,bool> checkpoint;
        readonly Func<string,Vector3?> recoveryAnchor;
        readonly ZNet network;readonly Dictionary<string,WardingActorRecord> records=new Dictionary<string,WardingActorRecord>(StringComparer.Ordinal);
        readonly Dictionary<string,Character> live=new Dictionary<string,Character>(StringComparer.Ordinal);
        readonly HashSet<string> freshReservations=new HashSet<string>(StringComparer.Ordinal);
        readonly List<ZDO> scanBatch=new List<ZDO>();readonly Dictionary<string,List<ZDOID>> scanMatches=new Dictionary<string,List<ZDOID>>(StringComparer.Ordinal);
        string[] scanPrefabs;int scanPrefab,scanCursor;bool pendingScanFinished;float nextScan;
        bool stopped,saveBlocked;float nextRefresh;WardingActorLedger suspended;string rebindFailure;
        internal WardingSpawnerActors(string runId,string worldKey,int seed,Action<string> log,Func<WardingActorLedger,bool> checkpoint=null,Func<string,Vector3?> recoveryAnchor=null)
        {this.recoveryAnchor=recoveryAnchor;this.runId=runId;this.worldKey=worldKey;this.seed=seed;this.log=log;this.checkpoint=checkpoint;network=ZNet.instance;RequireHost();EnsureDeathPresentation();}
        static void EnsureDeathPresentation()
        {
            if(deathPresentationHook!=null)return;
            var method=AccessTools.Method(typeof(Character),nameof(Character.OnDeath));if(method==null)throw new InvalidOperationException("Native Character death presentation API missing.");
            var hook=new Harmony("studio.otherworld.blackabbeyroomtest.ward-owned-death-projection");
            hook.Patch(method,prefix:new HarmonyMethod(typeof(WardingSpawnerActors),nameof(BeforeDeath)){priority=Priority.First});deathPresentationHook=hook;
        }
        static void BeforeDeath(Character __instance)
        {if(__instance&&__instance.GetComponent<WardingSpawnerActorTag>())__instance.GetComponent<WardingMonkHallProjection>()?.ResetVisual();}
        bool Scope=>network&&ZNet.instance==network&&network.IsServer()&&RuntimeTestPlugin.MonkWorldMatches(worldKey);
        void RequireHost(){if(!Scope||!ZNetScene.instance||ZDOMan.instance==null)throw new InvalidOperationException("Warding actors require their matching local host/world.");}
        internal static bool IsAlive(Character c)=>c&&!c.IsDead()&&c.GetHealth()>0;
        internal static bool IsHostOwned(Character c){var v=c?c.GetComponent<ZNetView>():null;return IsAlive(c)&&v&&v.IsValid()&&v.IsOwner();}
        internal static bool IsMonk(Character c)=>c&&c.GetComponents<MonoBehaviour>().Any(x=>x&&x.GetType().FullName=="BlackAbbey.HushedMonk.HushedMonkInstance");
        internal int LivingLocal(string sourceId)=>records.Values.Count(r=>!r.borrowed&&r.productionSourceId==sourceId&&r.state!="Dead");
        internal int LivingTotal=>records.Values.Count(r=>!r.borrowed&&r.state!="Dead");
        internal Character[] OwnedCharacters()=>live.Values.Where(IsAlive).Distinct().ToArray();
        internal bool HasRetrieval(string sourceId)=>WardingSpawnerRetrieval.HasRetrieval(records.Values,sourceId);
        internal string PendingKey(string sourceId)=>records.Values.FirstOrDefault(r=>r.productionSourceId==sourceId&&r.state=="Pending"&&freshReservations.Contains(r.key))?.key;
        internal string PendingPrefab(string key)=>key!=null&&records.TryGetValue(key,out var r)&&r.state=="Pending"?r.prefab:null;
        internal bool IsCancelledReservation(string source,string key)=>records.TryGetValue(key,out var r)&&
            !r.borrowed&&r.productionSourceId==source&&WardingSpawnerActorPersistence.AllowedPrefab(r.prefab)&&r.state=="Dead"&&r.uidUser==0&&r.uidId==0;
        internal static bool IsTravelling(Character c){var tag=c?c.GetComponent<WardingSpawnerActorTag>():null;return tag&&tag.Travelling;}
        internal bool Travelling(string key)=>records.TryGetValue(key,out var r)&&r.state!="Dead"&&r.journey!="None"&&r.journey!="Completed"&&r.journey!="Died";
        static float[] V(Vector3 p)=>new[]{p.x,p.y,p.z};static Vector3 V(float[] p)=>new Vector3(p[0],p[1],p[2]);
        static float[] Q(Quaternion q)=>new[]{q.x,q.y,q.z,q.w};
        static ZDOID Id(WardingActorRecord r)=>new ZDOID(r.uidUser,r.uidId);
        bool Matches(ZDO z,WardingActorRecord r)=>z!=null&&z.m_uid==Id(r)&&z.GetPrefab()==r.prefab.GetStableHashCode()&&
            (r.borrowed?z.GetString("twa_abbey_enemy_run","")==runId&&z.GetString("twa_abbey_enemy_world","")==worldKey:
                z.GetString(RunKey,"")==runId&&z.GetString(WorldKey,"")==worldKey&&z.GetString(SourceKey,"")==r.productionSourceId&&z.GetString(ActorKey,"")==r.key);
        bool NativeIdentity(ZDO z,WardingActorRecord r)=>z!=null&&!r.borrowed&&z.GetPrefab()==r.prefab.GetStableHashCode()&&
            z.GetString(RunKey,"")==runId&&z.GetString(WorldKey,"")==worldKey&&z.GetString(SourceKey,"")==r.productionSourceId&&z.GetString(ActorKey,"")==r.key;
        bool Save()
        {
            try {bool ok=checkpoint?.Invoke(Capture())??true;saveBlocked=!ok;return ok;}
            catch(Exception ex){saveBlocked=true;log?.Invoke("WARD_ACTOR_SAVE_BLOCKED: "+ex.Message);return false;}
        }
        internal bool Reserve(string sourceId,string actorKey,string prefab)
        {
            RequireHost();if(stopped||!WardingSpawnerActorPersistence.AllowedPrefab(prefab))return false;
            if(records.TryGetValue(actorKey,out var existing))return existing.sourceId==sourceId&&existing.prefab==prefab&&existing.state=="Pending"&&freshReservations.Contains(actorKey);
            PruneDead();if(records.Count>=WardingSpawnerActorPersistence.MaximumActors)return false;
            records.Add(actorKey,new WardingActorRecord{sourceId=sourceId,productionSourceId=sourceId,key=actorKey,prefab=prefab});
            pendingScanFinished=false;
            if(!Save()){records.Remove(actorKey);return false;}
            freshReservations.Add(actorKey);return true;
        }
        static bool Prefab(string name,out GameObject prefab)
        {
            return AbbeyEnemyPrefabLookup.TryGetReady(name,out prefab,out _);
        }
        internal bool TrySpawn(string sourceId,string actorKey,string prefab,Vector3 position,Quaternion rotation,out Character actor)
        {
            actor=null;RequireHost();if(stopped||saveBlocked&&!Save())return false;
            if(!records.ContainsKey(actorKey)&&!Reserve(sourceId,actorKey,prefab))return false;
            var r=records[actorKey];if(r.productionSourceId!=sourceId||r.prefab!=prefab||!freshReservations.Remove(actorKey)||r.state!="Pending")return false;
            if(!Prefab(prefab,out var template)){freshReservations.Add(actorKey);return false;}
            if(!ClearSpawn(template,position)){freshReservations.Add(actorKey);return false;}
            GameObject own=null;
            try
            {
                own=Object.Instantiate(template,position,rotation);var view=own.GetComponent<ZNetView>();
                if(!view||!view.IsValid()||!view.IsOwner())throw new InvalidOperationException("Spawner actor lacks a valid host-owned native view.");
                var z=view.GetZDO();view.m_persistent=true;z.Persistent=true;z.Set(RunKey,runId);z.Set(WorldKey,worldKey);z.Set(SourceKey,sourceId);z.Set(ActorKey,actorKey);
                r.uidUser=z.m_uid.UserID;r.uidId=z.m_uid.ID;r.state="Alive";
                // Keep a complete native identity/pose before any optional
                // actor binding can throw. A failed bind must remain a valid
                // dead record rather than poison the entire run checkpoint.
                r.position=V(own.transform.position);r.rotation=Q(own.transform.rotation);
                actor=own.GetComponent<Character>();Bind(r,actor,true);Snapshot(r,actor);
                // A failed post-spawn checkpoint keeps the tagged native record;
                // pending restoration never creates a second copy for this key.
                Save();log?.Invoke("WARD_ACTOR_SPAWN: "+actorKey+"; "+prefab+"; uid="+z.m_uid);return true;
            }
            catch(Exception ex)
            {
                if(own){var view=own.GetComponent<ZNetView>();if(view&&view.IsValid()&&view.IsOwner())ZNetScene.instance.Destroy(own);else Object.Destroy(own);}
                r.state="Dead";r.health=0;live.Remove(actorKey);actor=null;Save();log?.Invoke("WARD_ACTOR_SPAWN_FAILED: "+actorKey+"; "+ex.Message);return false;
            }
        }
        static bool ClearSpawn(GameObject prefab,Vector3 position)
        {
            var cap=prefab.GetComponent<CapsuleCollider>();int mask=LayerMask.GetMask("static_solid");if(!cap||mask==0)return false;
            float radius=Mathf.Max(.2f,cap.radius*Mathf.Max(Mathf.Abs(prefab.transform.lossyScale.x),Mathf.Abs(prefab.transform.lossyScale.z)))+.07f;
            float height=Mathf.Max(radius*2+.05f,cap.height*Mathf.Abs(prefab.transform.lossyScale.y));
            if(!Physics.Raycast(position+Vector3.up*.5f,Vector3.down,out var floor,.8f,mask,QueryTriggerInteraction.Ignore)||floor.normal.y<.8f||Mathf.Abs(floor.point.y-position.y)>.2f)return false;
            var center=position+Vector3.up*(radius+.05f);var top=position+Vector3.up*(height-radius);
            if(Physics.CheckCapsule(center,top,radius,mask,QueryTriggerInteraction.Ignore))return false;
            foreach(var col in Physics.OverlapCapsule(center,top,radius,~0,QueryTriggerInteraction.Ignore))if(col.GetComponentInParent<Character>())return false;
            return true;
        }
        void Bind(WardingActorRecord r,Character c,bool fresh=false)
        {
            RuntimeTestPlugin.BindRunBalance(c,r.prefab,runId,fresh);
            live[r.key]=c;var tag=c.GetComponent<WardingSpawnerActorTag>()??c.gameObject.AddComponent<WardingSpawnerActorTag>();tag.Bind(this,r.key);
            if(!r.borrowed){var drop=c.GetComponent<CharacterDrop>();if(drop)drop.m_drops=new List<CharacterDrop.Drop>();}
            DungeonActorResidency.Track(c.gameObject,c.GetComponent<ZNetView>()?.GetZDO());
            c.gameObject.SetActive(true);
        }
        internal void Died(string key)
        {
            if(!records.TryGetValue(key,out var r))return;r.state="Dead";r.health=0;if(r.journey!="None"&&r.journey!="Completed")r.journey="Died";
                if(live.TryGetValue(key,out var c)&&c){Release(c);c.GetComponent<WardingMonkHallProjection>()?.ResetVisual();WardingSpawnerAudio.Stop(r.sourceId);}
            Save();
        }
        Character Find(WardingActorRecord r)
        {
            if(!Scope||r.uidUser==0||!ZNetScene.instance||ZDOMan.instance==null)return null;
            var z=ZDOMan.instance.GetZDO(Id(r));if(!Matches(z,r))return null;
            var own=ZNetScene.instance.FindInstance(Id(r));var c=own?own.GetComponent<Character>():null;
            if(!own&&r.state!="Dead"&&z.GetFloat("health",r.health??0)>0&&!RuntimeTestPlugin.DungeonActorPositionValid(worldKey,runId,z.GetPosition())&&
                Prefab(r.prefab,out var proxy)&&TryRestorationLanding(r,z,proxy,out var landing))
            {
                z.SetOwner(ZDOMan.GetSessionID());z.SetPosition(landing);r.position=V(landing);
                log?.Invoke("WARD_ACTOR_UNLOADED_REPAIRED: "+r.key+"; exact UID="+z.m_uid+"; no actor cloned.");
            }
            if(c){if(!IsAlive(c)){r.state="Dead";r.health=0;return null;}if(!ResumeOnReadyFloor(r,z,c))return null;Bind(r,c);if(IsAlive(c)){if(r.health.HasValue&&r.health>0)c.SetHealth(Mathf.Min(c.GetHealth(),r.health.Value));r.state="Alive";RestoreMissingEffects(r,c);}}
            return c;
        }
        void ReconcilePending()
        {
            if(!Scope||Time.unscaledTime<nextScan)return;
            var missing=records.Values.Where(r=>!r.borrowed&&(r.state=="Pending"&&!freshReservations.Contains(r.key)||r.state=="Missing")).ToArray();
            if(missing.Length==0){scanPrefabs=null;pendingScanFinished=true;return;}
            if(scanPrefabs==null){scanPrefabs=missing.Select(r=>r.prefab).Distinct().OrderBy(x=>x,StringComparer.Ordinal).ToArray();scanPrefab=0;scanCursor=0;scanMatches.Clear();pendingScanFinished=false;}
            bool done;
            try
            {
                done=ZDOMan.instance.GetAllZDOsWithPrefabIterative(scanPrefabs[scanPrefab],scanBatch,ref scanCursor);
                foreach(var z in scanBatch)foreach(var r in missing)if(NativeIdentity(z,r))
                {if(!scanMatches.TryGetValue(r.key,out var list))scanMatches[r.key]=list=new List<ZDOID>();if(!list.Contains(z.m_uid)&&list.Count<3)list.Add(z.m_uid);}
            }
            catch(Exception e){nextScan=Time.unscaledTime+5;log?.Invoke("WARD_NATIVE_SCAN_DEFERRED: "+e.Message);return;}
            finally{scanBatch.Clear();}
            if(done){scanCursor=0;scanPrefab++;}
            if(scanPrefab<scanPrefabs.Length)return;
            pendingScanFinished=true;scanPrefabs=null;nextScan=Time.unscaledTime+10;
            var claims=new List<WardingActorUidClaim>();
            foreach(var r in missing)
            {
                scanMatches.TryGetValue(r.key,out var ids);
                if(ids==null||ids.Count!=1)continue;
                var z=ZDOMan.instance.GetZDO(ids[0]);if(!NativeIdentity(z,r))continue;
                var poseSupported=RuntimeTestPlugin.DungeonActorPositionValid(worldKey,runId,z.GetPosition());
                claims.Add(new WardingActorUidClaim{key=r.key,sourceId=r.productionSourceId,prefab=r.prefab,runId=runId,worldKey=worldKey,
                    uidUser=z.m_uid.UserID,uidId=z.m_uid.ID,exactMatches=ids.Count,scanComplete=pendingScanFinished,
                    position=poseSupported?V(z.GetPosition()):null,rotation=poseSupported?Q(z.GetRotation()):null});
            }
            var current=new WardingActorLedger{runId=runId,worldKey=worldKey,seed=seed,actors=records.Values.ToList()};
            if(!WardingActorUidRebind.TryPlan(current,claims,out var rebound,out var diagnostic))
            {
                if(rebindFailure!=diagnostic)log?.Invoke("WARD_NATIVE_REBIND_DEFERRED: "+diagnostic+" Ledger unchanged; no actor cloned.");
                rebindFailure=diagnostic;return;
            }
            rebindFailure=null;
            // Preserve the existing record objects: wardingSaved and live actor
            // tags may already reference them. The complete candidate was checked
            // before this synchronous assignment; there is no intermediate save.
            foreach(var accepted in rebound.actors)
            {
                var r=records[accepted.key];r.uidUser=accepted.uidUser;r.uidId=accepted.uidId;
                if(!WardingSpawnerActorPersistence.ValidPose(r.position,r.rotation)&&WardingSpawnerActorPersistence.ValidPose(accepted.position,accepted.rotation))
                {r.position=accepted.position;r.rotation=accepted.rotation;}
            }
            foreach(var r in missing)
            {
                scanMatches.TryGetValue(r.key,out var ids);
                if(WardingSpawnerActorPersistence.CancelUncreatedPending(r,ids?.Count??0,pendingScanFinished))
                {r.state="Dead";r.health=0;log?.Invoke("WARD_RESERVATION_CANCELLED: "+r.key+"; complete native query found no actor");continue;}
                if(ids==null||ids.Count!=1)continue;
                var z=ZDOMan.instance.GetZDO(ids[0]);if(!Matches(z,r))continue;
                if(RuntimeTestPlugin.DungeonActorPositionValid(worldKey,runId,z.GetPosition())){r.position=V(z.GetPosition());r.rotation=Q(z.GetRotation());}
                float nativeHealth=z.GetFloat("health",float.NaN);if(!float.IsNaN(nativeHealth)&&nativeHealth>=0)r.health=r.health.HasValue?Mathf.Min(r.health.Value,nativeHealth):nativeHealth;
                r.state=r.health.HasValue&&r.health<=0?"Dead":"Missing";z.Persistent=true;z.SetOwner(ZDOMan.GetSessionID());
                var actor=Find(r);if(actor)Snapshot(r,actor);
            }
            Save();
        }
        internal bool BeginRetrieval(string sourceId,Character monk,Vector3 mouth,Vector3 hidden,Vector3 innerDoor,Vector3 exit,float journeySeconds=8)
        {
            RequireHost();if(stopped||!IsMonk(monk)||!IsHostOwned(monk)||HasRetrieval(sourceId))return false;
            var view=monk.GetComponent<ZNetView>();var id=view.GetZDO().m_uid;
            var r=records.Values.FirstOrDefault(x=>x.uidUser==id.UserID&&x.uidId==id.ID);bool added=false;
            if(r==null)
            {
                if(view.GetZDO().GetString("twa_abbey_enemy_run","")!=runId||view.GetZDO().GetString("twa_abbey_enemy_world","")!=worldKey)return false;
                PruneDead();if(records.Count>=WardingSpawnerActorPersistence.MaximumActors)return false;
                r=new WardingActorRecord{key="borrow/"+id.UserID+"/"+id.ID,sourceId=sourceId,prefab="TWA_HushedMonk_Test",borrowed=true,state="Alive",uidUser=id.UserID,uidId=id.ID};records.Add(r.key,r);added=true;
            }
            if(r.state=="Dead"||r.journey!="None"&&r.journey!="Completed")return false;
            bool started=WardingSpawnerRetrieval.Begin(records,r,added,()=>{
                r.sourceId=sourceId;r.mouth=V(mouth);r.hidden=V(hidden);r.innerDoor=V(innerDoor);r.exit=V(exit);r.journeySeconds=Mathf.Clamp(journeySeconds,1,120);r.journeyElapsed=0;r.journey="Entering";r.returned=false;r.state="Alive";
                Snapshot(r,monk);
            },Save);
            // A failed first borrow must not leave a live/tag entry whose
            // durable record was removed by the transaction rollback.
            if(started)Bind(r,monk);return started;
        }
        internal bool BeginEmergence(string sourceId,Character actor,Vector3 mouth,Vector3 hidden,Vector3 innerDoor,Vector3 exit)
        {
            RequireHost();if(stopped||!IsHostOwned(actor))return false;
            var id=actor.GetComponent<ZNetView>().GetZDO().m_uid;
            var r=records.Values.SingleOrDefault(x=>!x.borrowed&&x.productionSourceId==sourceId&&x.uidUser==id.UserID&&x.uidId==id.ID);
            if(r==null||r.journey!="None")return false;
            r.mouth=V(mouth);r.hidden=V(hidden);r.innerDoor=V(innerDoor);r.exit=V(exit);
            r.journeySeconds=3.5f;r.journeyElapsed=0;r.journey="Emerging";
            // Claim the native AI immediately. Health, status effects and the
            // network body stay live; only this produced Visual is projected.
            Hold(actor,hidden);Face(actor,mouth-hidden);
            var projection=actor.GetComponent<WardingMonkHallProjection>()??actor.gameObject.AddComponent<WardingMonkHallProjection>();
            projection.ShowArrival(mouth,hidden,0);Snapshot(r,actor);Save();return true;
        }
        internal void Tick(float dt,Func<string,bool> doorOpen,Func<string,Func<bool>,bool> returnedAlive,Func<string,Character,Vector3?> hallYield=null)
        {
            if(stopped||!Scope)return;dt=Mathf.Clamp(dt,0,.5f);
            ReconcilePending();
            foreach(var r in records.Values.ToArray())
            {
                if(r.state=="Dead"||r.state=="Pending")continue;
                if(!live.TryGetValue(r.key,out var c)||!c)c=Find(r);
                if(!c){r.state="Missing";continue;}
                if(!IsAlive(c)){Died(r.key);continue;}
                if(!IsHostOwned(c))continue;
                bool open=doorOpen?.Invoke(r.sourceId)??false;
                var yieldPoint=HallYieldPoint(r,c,hallYield);
                if(r.journey=="Emerging")
                {
                    Hold(c,yieldPoint??V(r.hidden));Face(c,V(r.mouth)-V(r.hidden));
                    // The false hall is presentation behind the real leaves.
                    // Closing the bars must not freeze its walking approach.
                    // Native movement/attack impairments retain their priority.
                    if(c.CanMove()&&!c.IsStaggering()&&!c.InAttack())r.journeyElapsed=Mathf.Min(r.journeySeconds,r.journeyElapsed+dt);
                    var projection=c.GetComponent<WardingMonkHallProjection>()??c.gameObject.AddComponent<WardingMonkHallProjection>();
                    projection.ShowArrival(V(r.mouth),V(r.hidden),Mathf.Clamp01(r.journeyElapsed/r.journeySeconds));
                    if(r.journeyElapsed>=r.journeySeconds)
                    {
                        // Finish the approach without freezing its presentation.
                        // An actively moving door can keep this produced body in
                        // the checked hall while native steering clears its sweep.
                        projection.FinishArrival();r.journey="Clearing";
                        if(yieldPoint.HasValue)Hold(c,yieldPoint.Value);else RunClear(c,ClearDestination(c,r));Save();
                    }
                }
                else if(r.journey=="Clearing")
                {
                    // Produced actors may use a real safe partial opening. The
                    // native capsule/floor probe stops at closed leaves; unlike
                    // returned monks, they need no fully-open logical gate.
                    if(yieldPoint.HasValue){Hold(c,yieldPoint.Value);continue;}
                    var destination=ClearDestination(c,r);RunClear(c,destination);
                    if(Distance(c.transform.position,destination)<.4f){r.journey="Completed";Release(c);NativeAlert(c);Save();}
                }
                else if(r.journey=="Entering")
                {
                    if(!open){ApproachWard(c,V(r.mouth));continue;}
                    Hold(c,V(r.hidden));
                    if(Distance(c.transform.position,V(r.hidden))<.055f){r.journey="Away";r.journeyElapsed=0;Save();}
                }
                else if(r.journey=="Away")
                {
                    Hold(c,V(r.hidden));r.journeyElapsed+=dt;
                    var projection=c.GetComponent<WardingMonkHallProjection>()??c.gameObject.AddComponent<WardingMonkHallProjection>();
                    projection.Show(V(r.mouth),V(r.hidden),Mathf.Clamp01(r.journeyElapsed/r.journeySeconds));
                    if(r.journeyElapsed>=r.journeySeconds){projection.ResetVisual();Face(c,V(r.mouth)-V(r.hidden));r.journey="Returning";r.journeyElapsed=0;Save();}
                }
                else if(r.journey=="Returning")
                {
                    Hold(c,V(r.innerDoor));Face(c,V(r.mouth)-V(r.hidden));
                    if(Distance(c.transform.position,V(r.innerDoor))<.055f)
                    {
                        r.journey=open?"Exiting":"Blocked";
                        NotifyReturn(r,returnedAlive);
                    }
                }
                else if(r.journey=="Blocked")
                {
                    if(!NotifyReturn(r,returnedAlive)){Hold(c,V(r.innerDoor));continue;}
                    Hold(c,V(r.innerDoor));Face(c,V(r.mouth)-V(r.hidden));
                    if(open){WardingSpawnerAudio.Stop(r.sourceId);r.journey="Exiting";Save();}
                    else WardingSpawnerAudio.Bang(r.sourceId,V(r.innerDoor)+Vector3.up*.8f,c);
                }
                else if(r.journey=="Exiting")
                {
                    if(!NotifyReturn(r,returnedAlive)){Hold(c,V(r.innerDoor));continue;}
                    if(!open&&BehindDoor(c,r)){r.journey="Blocked";Save();continue;}
                    var destination=ClearDestination(c,r);RunClear(c,destination);
                    if(Distance(c.transform.position,destination)<.4f){r.journey="Completed";Release(c);NativeAlert(c);Save();}
                }
            }
            if(Time.unscaledTime>=nextRefresh){nextRefresh=Time.unscaledTime+1;foreach(var r in records.Values.ToArray())if(live.TryGetValue(r.key,out var c)&&c)Snapshot(r,c);}
        }
        bool HallYieldEligible(string source,WardingActorRecord r,Character c)
        {
            // Only this source's exact produced body may be directed back into
            // its hall. Borrowed/returning monks and ordinary room combat keep
            // their existing journeys. The art callback checks the real body
            // side, supported floor and radius clearance, never its projection.
            if(stopped||!Scope||string.IsNullOrEmpty(source)||r.borrowed||r.productionSourceId!=source||r.sourceId!=source||
                r.journey!="Emerging"&&r.journey!="Clearing"||!IsHostOwned(c))return false;
            var view=c.GetComponent<ZNetView>();
            return view&&view.IsValid()&&Matches(view.GetZDO(),r);
        }
        internal bool CanYieldToDoor(string source,Character c)
        {
            if(!IsHostOwned(c))return false;var view=c.GetComponent<ZNetView>();
            if(!view||!view.IsValid())return false;var z=view.GetZDO();
            return z!=null&&records.TryGetValue(z.GetString(ActorKey,""),out var r)&&HallYieldEligible(source,r,c);
        }
        Vector3? HallYieldPoint(WardingActorRecord r,Character c,Func<string,Character,Vector3?> hallYield)=>
            hallYield!=null&&HallYieldEligible(r.productionSourceId,r,c)?hallYield(r.productionSourceId,c):null;
        bool NotifyReturn(WardingActorRecord r,Func<string,Func<bool>,bool> returnedAlive)=>
            WardingSpawnerRetrieval.NotifyReturn(r,returnedAlive,Save);
        static float Distance(Vector3 a,Vector3 b)=>Vector3.ProjectOnPlane(a-b,Vector3.up).magnitude;
        static bool BehindDoor(Character c,WardingActorRecord r)=>Vector3.Dot(c.transform.position-V(r.mouth),(V(r.hidden)-V(r.mouth)).normalized)>-1.2f;
        static Vector3 ClearDestination(Character c,WardingActorRecord r)
        {
            var mouth=V(r.mouth);var outward=Vector3.ProjectOnPlane(V(r.exit)-mouth,Vector3.up).normalized;
            var side=Vector3.Cross(Vector3.up,outward);var cap=c.GetComponent<CapsuleCollider>();
            int mask=LayerMask.GetMask("static_solid");if(mask==0||!cap)return V(r.exit);
            float radius=Mathf.Max(.2f,cap.radius*Mathf.Max(Mathf.Abs(c.transform.lossyScale.x),Mathf.Abs(c.transform.lossyScale.z)));
            float height=Mathf.Max(radius*2+.05f,cap.height*Mathf.Abs(c.transform.lossyScale.y));
            // Stable per-identity lanes, deeper into the real room. Prefer a
            // supported clear destination; never extend the decorative bay or
            // teleport through a player, actor, stone wall or missing floor.
            int sequence;string suffix=r.key.Substring(r.key.LastIndexOf('/')+1);
            int lane=int.TryParse(suffix,NumberStyles.None,CultureInfo.InvariantCulture,out sequence)?sequence%3-1:(int)(r.uidId%3)-1;
            foreach(float distance in new[]{4.2f,3.4f,2.6f})foreach(float offset in new[]{lane*.9f,0f,-lane*.9f})
            {
                Vector3 p=mouth+outward*distance+side*offset;
                if(!Physics.Raycast(p+Vector3.up*.65f,Vector3.down,out var floor,1.2f,mask,QueryTriggerInteraction.Ignore)||floor.normal.y<.65f||Mathf.Abs(floor.point.y-mouth.y)>.4f)continue;
                p.y=floor.point.y+.025f;
                if(Physics.CheckCapsule(p+Vector3.up*(radius+.06f),p+Vector3.up*(height-radius),radius*.94f,mask,QueryTriggerInteraction.Ignore))continue;
                return p;
            }
            return V(r.exit);
        }
        static void Hold(Character c,Vector3 p)=>Controller(c)?.Command(p,.025f,.8f);
        static void Face(Character c,Vector3 direction)
        {direction=Vector3.ProjectOnPlane(direction,Vector3.up);if(!c||direction.sqrMagnitude<.001f)return;direction.Normalize();c.SetLookDir(direction,0);c.transform.rotation=Quaternion.LookRotation(direction);}
        static WardingSpawnerSteering Controller(Character c)=>IsHostOwned(c)?c.GetComponent<WardingSpawnerSteering>()??c.gameObject.AddComponent<WardingSpawnerSteering>():null;
        internal static void ApproachWard(Character c,Vector3 point)=>Controller(c)?.Command(point,.2f,.8f);
        static void RunClear(Character c,Vector3 point)=>Controller(c)?.Command(point,.2f,.8f,true);
        internal static void Release(Character c){var lease=c?c.GetComponent<WardingSpawnerSteering>():null;if(lease)lease.Release();if(c)c.GetComponent<WardingMonkHallProjection>()?.ResetVisual();}
        internal static void SetFrantic(Character c,bool enabled)
        {if(!c)return;if(enabled&&IsMonk(c)&&IsHostOwned(c)){var lease=Controller(c);lease?.Frantic();NativeAlert(c);}else{var lease=c.GetComponent<WardingSpawnerSteering>();if(lease)lease.ClearFrantic();}}
        static void NativeAlert(Character c){var ai=c.GetComponent<BaseAI>();if(ai&&AlertMethod!=null)AlertMethod.Invoke(ai,new object[]{true});}
        internal static bool IsWardResponder(Character c)
        {
            var view=c?c.GetComponent<ZNetView>():null;if(!view||!view.IsValid())return false;
            int prefab=view.GetZDO().GetPrefab();return prefab==AbbeyMonkSpawnPolicy.Monk.GetStableHashCode()||
                prefab==AbbeyMonkSpawnPolicy.Guard.GetStableHashCode()||prefab==AbbeyMonkSpawnPolicy.Censer.GetStableHashCode()||prefab==AbbeyMonkSpawnPolicy.Thrall.GetStableHashCode();
        }
        internal static void Alert(IEnumerable<Character> eligible,Vector3 point)
        {
            if(eligible==null)return;foreach(var c in eligible.Take(128))if(IsHostOwned(c)&&IsWardResponder(c))
            {
                NativeAlert(c);var ai=c.GetComponent<BaseAI>();var target=ai?ai.GetTargetCreature():null;
                // Native combat remains primary even when a sealing alarm is
                // heard. Only an unengaged responder receives a short run cue.
                if(!c.InAttack()&&!IsAlive(target))RunClear(c,point);
            }
        }
        void Snapshot(WardingActorRecord r,Character c)
        {
            if(!c)return;bool safePosition=!DungeonActorResidency.Held(c.gameObject)&&RuntimeTestPlugin.DungeonActorPositionValid(worldKey,runId,c.transform.position);
            if(safePosition){r.position=V(c.transform.position);r.rotation=Q(c.transform.rotation);}r.health=Mathf.Max(0,c.GetHealth());
            if(c.IsDead()||r.health<=0){r.state="Dead";if(r.journey!="None"&&r.journey!="Completed")r.journey="Died";}else r.effects=CaptureEffects(c);
            var view=c.GetComponent<ZNetView>();if(safePosition&&view&&view.IsValid()&&view.IsOwner()){var z=view.GetZDO();z.SetPosition(c.transform.position);z.SetRotation(c.transform.rotation);}
        }
        static IEnumerable<FieldInfo> ScalarFields(Type t)
        {for(var k=t;k!=null&&typeof(StatusEffect).IsAssignableFrom(k);k=k.BaseType)foreach(var f in k.GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.DeclaredOnly))if(!f.IsInitOnly&&(f.FieldType==typeof(float)||f.FieldType==typeof(int)||f.FieldType==typeof(bool)))yield return f;}
        static List<WardingEffectRecord> CaptureEffects(Character c)
        {
            var result=new List<WardingEffectRecord>();var manager=c.GetSEMan();if(manager==null)return result;
            foreach(var e in manager.GetStatusEffects().Where(x=>x).Take(WardingSpawnerActorPersistence.MaximumEffects))
            {
                var r=new WardingEffectRecord{name=e.name.Replace("(Clone)","").Trim(),type=e.GetType().FullName};
                foreach(var f in ScalarFields(e.GetType()).Take(WardingSpawnerActorPersistence.MaximumScalars))
                {
                    var value=f.GetValue(e);string text=f.FieldType==typeof(float)?((float)value).ToString("R",CultureInfo.InvariantCulture):Convert.ToString(value,CultureInfo.InvariantCulture);
                    if(f.FieldType==typeof(float)&&(float.IsNaN((float)value)||float.IsInfinity((float)value)||Math.Abs((float)value)>100000000))continue;
                    r.scalars.Add(new WardingEffectScalar{declaringType=f.DeclaringType.FullName,field=f.Name,type=f.FieldType==typeof(float)?"f":f.FieldType==typeof(int)?"i":"b",value=text});
                }
                result.Add(r);
            }
            return result;
        }
        static void RestoreMissingEffects(WardingActorRecord r,Character c)
        {
            var manager=c.GetSEMan();if(manager==null)return;
            foreach(var saved in r.effects)
            {
                int hash=saved.name.GetStableHashCode();if(manager.GetStatusEffect(hash))continue;
                var e=manager.AddStatusEffect(hash,false);if(!e||e.GetType().FullName!=saved.type)continue;
                foreach(var f in ScalarFields(e.GetType()))
                {
                    var s=saved.scalars.FirstOrDefault(x=>x.declaringType==f.DeclaringType.FullName&&x.field==f.Name);if(s==null)continue;
                    if(s.type=="f"&&f.FieldType==typeof(float))f.SetValue(e,float.Parse(s.value,CultureInfo.InvariantCulture));
                    else if(s.type=="i"&&f.FieldType==typeof(int))f.SetValue(e,int.Parse(s.value,CultureInfo.InvariantCulture));
                    else if(s.type=="b"&&f.FieldType==typeof(bool))f.SetValue(e,bool.Parse(s.value));
                }
            }
            // Only missing effects were reconstructed; existing native effects
            // never have their timers, damage remainder or stacks rolled back.
        }
        internal WardingActorLedger Capture()
        {
            if(stopped&&suspended!=null)return suspended;
            if(Scope)foreach(var r in records.Values)if(live.TryGetValue(r.key,out var c)&&c)Snapshot(r,c);
            var value=new WardingActorLedger{runId=runId,worldKey=worldKey,seed=seed,actors=records.Values.OrderBy(x=>x.key,StringComparer.Ordinal).ToList()};
            WardingSpawnerActorPersistence.Validate(value,runId,worldKey,seed);return value;
        }
        internal void Restore(WardingActorLedger saved)
        {
            RequireHost();if(records.Count!=0)throw new InvalidOperationException("Restore actor ledger before any production.");
            if(saved==null)return;WardingSpawnerActorPersistence.Validate(saved,runId,worldKey,seed);
            foreach(var r in saved.actors){records.Add(r.key,r);if(r.state=="Dead")continue;var c=Find(r);if(c){Snapshot(r,c);}else if(r.state!="Pending")r.state="Missing";}
            // No Instantiate path here. Missing or pending records retain cap
            // ownership rather than resurrecting an actor with lost effects.
        }
        void PruneDead()
        {foreach(var r in records.Values.Where(r=>r.state=="Dead"||r.borrowed&&r.journey=="Completed").Take(Math.Max(0,records.Count-96)).ToArray()){records.Remove(r.key);live.Remove(r.key);}}
        internal void Suspend()
        {
            if(stopped)return;suspended=Capture();Save();DungeonActorResidency.ParkRun(worldKey,runId);stopped=true;
            foreach(var pair in live){var c=pair.Value;if(!c)continue;Release(c);c.GetComponent<WardingSpawnerActorTag>()?.Unbind(this);if(!records[pair.Key].borrowed)c.gameObject.SetActive(false);}
            live.Clear();
        }
        internal void Retire()
        {
            if(!Scope){log?.Invoke("WARD_ACTOR_RETIRE_REFUSED: mismatched host/world");return;}
            if(UnresolvedReservation())throw new InvalidOperationException("Spawner pending native UID scan is incomplete or ambiguous; retain the current run before retirement.");
            foreach(var r in records.Values)
            {
                if(live.TryGetValue(r.key,out var c)&&c){Release(c);c.GetComponent<WardingSpawnerActorTag>()?.Unbind(this);}
                WardingSpawnerAudio.Stop(r.sourceId);if(r.borrowed||r.uidUser==0)continue;
                var z=ZDOMan.instance.GetZDO(Id(r));if(!Matches(z,r))continue;z.Persistent=false;z.SetOwner(ZDOMan.GetSessionID());
                var own=ZNetScene.instance.FindInstance(Id(r));if(own){own.GetComponent<ZNetView>()?.ClaimOwnership();ZNetScene.instance.Destroy(own);}else ZDOMan.instance.DestroyZDO(z);
            }
            if(FlushDestroyed==null)throw new InvalidOperationException("Cannot verify native spawner retirement: destruction flush API missing.");
            FlushDestroyed.Invoke(ZDOMan.instance,null);
            if(records.Values.Any(r=>!r.borrowed&&r.uidUser!=0&&Matches(ZDOMan.instance.GetZDO(Id(r)),r)))
                throw new InvalidOperationException("Own spawner UIDs remain after native retirement; retain the dungeon record and retry.");
            stopped=true;live.Clear();records.Clear();suspended=null;
        }
        bool UnresolvedReservation()=>records.Values.Any(r=>!r.borrowed&&r.state!="Dead"&&r.uidUser==0&&!freshReservations.Contains(r.key));
        internal IEnumerator PrepareRetirement()
        {
            RequireHost();int batches=0;
            // This drains only the native identity query. It never advances a
            // journey, moves a creature, clones one or consumes a spawn clock.
            while(UnresolvedReservation())
            {
                if(!Scope)throw new InvalidOperationException("Spawner retirement preparation lost its host/world scope.");
                if(pendingScanFinished)throw new InvalidOperationException("Spawner reservation has ambiguous native actor identities; retain this run.");
                if(batches++>=4096)throw new InvalidOperationException("Spawner native retirement query exceeded its bounded batch budget; retain this run.");
                nextScan=0;ReconcilePending();yield return null;
            }
        }
        public void Dispose()=>Suspend();
    }
    public sealed class WardingSpawnerActorTag:MonoBehaviour
    {
        WardingSpawnerActors owner;string key;Character actor;
        internal bool Travelling=>owner?.Travelling(key)??false;
        internal void Bind(WardingSpawnerActors next,string nextKey){if(owner==next&&key==nextKey)return;if(actor)actor.m_onDeath-=Died;owner=next;key=nextKey;actor=GetComponent<Character>();if(actor)actor.m_onDeath+=Died;}
        void Died()=>owner?.Died(key);
        internal void Unbind(WardingSpawnerActors expected){if(owner!=expected)return;if(actor)actor.m_onDeath-=Died;owner=null;key=null;actor=null;}
        void OnDestroy(){if(actor)actor.m_onDeath-=Died;}
    }
    public sealed class WardingSpawnerSteering:MonoBehaviour
    {
        Character actor;BaseAI ai;bool leased,wasEnabled,frantic,run;float until,stop;Vector3 goal;
        float oldAttackInterval,writtenAttackInterval;MonsterAI monster;List<Vector3> path;int corner;float nextPlan;Component navigation;MethodInfo probe;
        void Awake(){actor=GetComponent<Character>();ai=GetComponent<BaseAI>();monster=GetComponent<MonsterAI>();navigation=GetComponents<MonoBehaviour>().FirstOrDefault(c=>c&&c.GetType().GetMethod("TryProbePath",BindingFlags.Public|BindingFlags.Instance)!=null);probe=navigation?navigation.GetType().GetMethod("TryProbePath",BindingFlags.Public|BindingFlags.Instance):null;}
        internal void Command(Vector3 target,float stopDistance,float seconds,bool running=false)
        {
            if(!WardingSpawnerActors.IsHostOwned(actor))return;ClearFrantic();
            if(!leased){wasEnabled=ai&&ai.enabled;leased=true;if(ai)ai.enabled=false;}
            if((target-goal).sqrMagnitude>.04f){path=null;nextPlan=0;}goal=target;stop=stopDistance;until=Time.time+seconds;run=running;
        }
        internal void Frantic(){Release();if(frantic||!monster)return;oldAttackInterval=monster.m_minAttackInterval;writtenAttackInterval=Mathf.Max(.25f,oldAttackInterval*.75f);monster.m_minAttackInterval=writtenAttackInterval;frantic=true;}
        internal void ClearFrantic(){if(frantic&&monster&&Mathf.Abs(monster.m_minAttackInterval-writtenAttackInterval)<.0001f)monster.m_minAttackInterval=oldAttackInterval;frantic=false;}
        void FixedUpdate()
        {
            if(!leased)return;if(!WardingSpawnerActors.IsHostOwned(actor)||Time.time>until){Release();return;}
            if(!actor.CanMove()||actor.IsStaggering()){actor.SetMoveDir(Vector3.zero);return;}
            Vector3 delta=Vector3.ProjectOnPlane(goal-transform.position,Vector3.up);if(delta.magnitude<=stop){actor.SetMoveDir(Vector3.zero);return;}
            Vector3 waypoint=goal;
            if(probe!=null&&Time.time>=nextPlan){nextPlan=Time.time+.65f;object[] args={transform.position,goal,null};if((bool)probe.Invoke(navigation,args)){path=args[2] as List<Vector3>;corner=1;}else path=null;}
            if(path!=null&&path.Count>1){while(corner<path.Count-1&&Vector3.ProjectOnPlane(path[corner]-transform.position,Vector3.up).magnitude<.35f)corner++;waypoint=path[Math.Min(corner,path.Count-1)];}
            Vector3 move=Vector3.ProjectOnPlane(waypoint-transform.position,Vector3.up).normalized;
            int mask=LayerMask.GetMask("static_solid");var cap=GetComponent<CapsuleCollider>();
            if(cap&&mask!=0){float radius=Mathf.Max(.2f,cap.radius*Mathf.Max(transform.lossyScale.x,transform.lossyScale.z));float height=Mathf.Max(radius*2+.02f,cap.height*transform.lossyScale.y);Vector3 center=transform.TransformPoint(cap.center);float extent=height*.5f-radius;
                if(Physics.CapsuleCast(center+Vector3.up*extent,center-Vector3.up*extent,radius*.94f,move,out _,.25f,mask,QueryTriggerInteraction.Ignore)||!Physics.Raycast(transform.position+move*.4f+Vector3.up*.5f,Vector3.down,1.2f,mask,QueryTriggerInteraction.Ignore))move=Vector3.zero;}
            actor.SetMoveDir(move);actor.SetRun(run);actor.SetWalk(!run);
            if(move.sqrMagnitude>.01f){actor.SetLookDir(move,0);transform.rotation=Quaternion.RotateTowards(transform.rotation,Quaternion.LookRotation(move),120*Time.fixedDeltaTime);}
        }
        internal void Release(){if(leased){if(actor){actor.SetMoveDir(Vector3.zero);actor.SetRun(false);actor.SetWalk(false);}if(ai)ai.enabled=wasEnabled;leased=false;}ClearFrantic();}
        void OnDisable()=>Release();void OnDestroy()=>Release();
    }
    // Match the authored hall's exact perspective mapping, on the Visual root
    // only. Native body/capsule, health and status effects stay at real staging.
    // Cosmetic bell bodies are parked for this short presentation and restored.
    [DefaultExecutionOrder(11000)]
    public sealed class WardingMonkHallProjection:MonoBehaviour
    {
        Transform visual;Vector3 localPosition,localScale;Quaternion localRotation;Animator animator;
        readonly List<Rigidbody> bodies=new List<Rigidbody>();readonly List<bool> kinematic=new List<bool>();readonly List<Behaviour> cosmetics=new List<Behaviour>();
        bool active,hasForwardSpeed,arrival,finishingArrival;Vector3 mouth,staging;float progress,oldForwardSpeed;static readonly int ForwardSpeed=Animator.StringToHash("forward_speed");
        WardingDoorMotion presentation;WardingHallAnimation hallAnimation;
        internal void Show(Vector3 from,Vector3 realStaging,float normalized)
        {
            arrival=false;ShowCore(from,realStaging,normalized);
        }
        internal void ShowArrival(Vector3 from,Vector3 realStaging,float normalized)
        {
            arrival=true;ShowCore(from,realStaging,normalized);
        }
        internal void FinishArrival(){if(active&&arrival)finishingArrival=true;}
        void ShowCore(Vector3 from,Vector3 realStaging,float normalized)
        {
            // No ordinary encounter can acquire the perspective presentation.
            var tag=GetComponent<WardingSpawnerActorTag>();if(!tag||!tag.Travelling)return;
            if(!active)
            {
                visual=transform.Find("Visual");if(!visual)return;
                localPosition=visual.localPosition;localRotation=visual.localRotation;localScale=visual.localScale;animator=visual.GetComponentInChildren<Animator>(true);
                hasForwardSpeed=animator&&animator.parameters.Any(p=>p.type==AnimatorControllerParameterType.Float&&p.nameHash==ForwardSpeed);
                if(hasForwardSpeed)oldForwardSpeed=animator.GetFloat(ForwardSpeed);
                foreach(var body in visual.GetComponentsInChildren<Rigidbody>(true)){bodies.Add(body);kinematic.Add(body.isKinematic);body.isKinematic=true;}
                foreach(var b in GetComponents<MonoBehaviour>())if(b&&b.enabled&&b.GetType().FullName=="BlackAbbey.HushedMonk.WristBellPhysics"){cosmetics.Add(b);b.enabled=false;}
                presentation=new WardingDoorMotion(normalized);
                hallAnimation=new WardingHallAnimation();hallAnimation.Begin(GetComponent<Character>(),animator);
                active=true;
            }
            mouth=from;staging=realStaging;presentation.Target(normalized,.15f);
        }
        void Update()
        {
            // Applied before animation evaluation, rather than only after
            // native Character has already evaluated a stationary pose.
            if(active&&animator&&hasForwardSpeed&&(hallAnimation==null||!hallAnimation.Active))animator.SetFloat(ForwardSpeed,1.0f);
        }
        void LateUpdate()
        {
            if(!active||!visual)return;var actor=GetComponent<Character>();var tag=GetComponent<WardingSpawnerActorTag>();
            if(!WardingSpawnerActors.IsHostOwned(actor)||!tag||!tag.Travelling){ResetVisual();return;}
            float previous=progress;progress=presentation.Advance(Time.deltaTime);hallAnimation?.Evaluate(Time.deltaTime,progress>previous+.000001f);
            Vector3 forward=Vector3.ProjectOnPlane(staging-mouth,Vector3.up).normalized;
            Vector3 origin=staging-forward*2.04f,eye=origin-forward*4.2f+Vector3.up*1.8f;
            float trip=arrival?1-progress:Mathf.Sin(progress*Mathf.PI);float virtualDepth=Mathf.Lerp(2.04f,15f,trip);
            WardingHallProjectionMath.Map(virtualDepth,out _,out var mappedScale);float scale=(float)mappedScale;
            Vector3 projected=eye+(origin+forward*virtualDepth-eye)*scale;
            // Preserve every local offset. During the final arrival interval
            // follow the actual body's safe native movement, so at depth2.04 /
            // scale1 the mapped pose is exactly the body-local pose we restore.
            Vector3 bodyTravel=arrival?transform.position-staging:Vector3.zero;
            visual.position=projected+bodyTravel+transform.TransformVector(localPosition)*scale;visual.rotation=(arrival?transform.rotation:Quaternion.LookRotation(progress<.5f?forward:-forward,Vector3.up))*localRotation;visual.localScale=localScale*scale;
            if(animator&&hasForwardSpeed)animator.SetFloat(ForwardSpeed,1.0f);
            if(finishingArrival&&progress>=1)ResetVisual(true);
        }
        internal void ResetVisual(bool walkingHandoff=false)
        {
            if(!active)return;active=false;finishingArrival=false;if(visual){visual.localPosition=localPosition;visual.localRotation=localRotation;visual.localScale=localScale;}
            hallAnimation?.End(walkingHandoff);hallAnimation=null;presentation=null;
            if(animator&&hasForwardSpeed&&!walkingHandoff)animator.SetFloat(ForwardSpeed,oldForwardSpeed);
            for(int i=0;i<bodies.Count;i++)if(bodies[i])bodies[i].isKinematic=kinematic[i];bodies.Clear();kinematic.Clear();
            foreach(var c in cosmetics)if(c)c.enabled=true;cosmetics.Clear();
        }
        void OnDisable()=>ResetVisual();void OnDestroy()=>ResetVisual();
    }
}
