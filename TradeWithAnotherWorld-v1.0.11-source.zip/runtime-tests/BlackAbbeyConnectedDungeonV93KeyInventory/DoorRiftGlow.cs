using System;
using System.Collections.Generic;
using System.Linq;
using Jotunn.Managers;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // World-portal-only correction. The authored orange maps, source UVs and
    // native keyword variant stay intact. The dim baked map needs HDR gain
    // to read as luminous in daylight; this never changes global exposure.
    public sealed class DoorRiftGlow : MonoBehaviour
    {
        private readonly List<Material> owned = new List<Material>();
        private readonly List<Color> originalEmission = new List<Color>();
        private readonly List<Light> spills = new List<Light>();
        private Transform[] glyphs;
        private bool bound;
        internal const float DefaultEmissionGain = 8f;
        internal const float DefaultSpillIntensity = 0f;
        private float emissionGain = DefaultEmissionGain;
        private float spillIntensity = DefaultSpillIntensity;

        internal static DoorRiftGlow AttachWorld(GameObject root, float gain = DefaultEmissionGain, float spill = DefaultSpillIntensity)
        {
            var glow = root.GetComponent<DoorRiftGlow>() ?? root.AddComponent<DoorRiftGlow>();
            var glyph = root.transform.Find("portal_rift");
            if (!glyph) throw new InvalidOperationException("The world portal's original carved rift piece is missing.");
            glyph.gameObject.SetActive(true);
            glow.glyphs = new[] { glyph }; glow.Bind(DefaultSpillIntensity, 4f); glow.SetProfile(gain, spill); return glow;
        }

        private void Bind(float intensity, float range)
        {
            if (bound) return;
            var prefab = PrefabManager.Instance.GetPrefab("SurtlingCore");
            var native = prefab ? prefab.GetComponentsInChildren<Renderer>(true).SelectMany(r => r.sharedMaterials)
                .FirstOrDefault(m => m && m.name == "surtlingcore" && m.shader && m.shader.isSupported &&
                    m.IsKeywordEnabled("_EMISSION") && m.HasProperty("_EmissionMap") && m.HasProperty("_EmissionColor")) : null;
            foreach (var glyph in glyphs)
            {
                var renderer = glyph.GetComponent<MeshRenderer>(); var filter = glyph.GetComponent<MeshFilter>();
                if (!renderer || !filter || !filter.sharedMesh) throw new InvalidOperationException("Rift art lost its source renderer/mesh.");
                var materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                {
                    var original = materials[i];
                    if (!original || !original.HasProperty("_EmissionMap") || !original.GetTexture("_EmissionMap") ||
                        !original.HasProperty("_EmissionColor") || original.GetColor("_EmissionColor").maxColorComponent <= 0)
                        throw new InvalidOperationException("The original door rift emission map/value is unavailable.");
                    if (native)
                    {
                        var material = new Material(native) { name = "BA door rift | native emission variant | " + original.name };
                        foreach (string key in new[] { "_MainTex", "_BumpMap", "_MetallicGlossMap", "_EmissionMap" })
                            if (material.HasProperty(key) && original.HasProperty(key))
                            { material.SetTexture(key, original.GetTexture(key)); material.SetTextureScale(key, original.GetTextureScale(key)); material.SetTextureOffset(key, original.GetTextureOffset(key)); }
                        foreach (string key in new[] { "_Color", "_EmissionColor" })
                            if (material.HasProperty(key) && original.HasProperty(key)) material.SetColor(key, original.GetColor(key));
                        foreach (string key in new[] { "_BumpScale", "_Metallic", "_Glossiness", "_GlossMapScale", "_Mode", "_SrcBlend", "_DstBlend", "_ZWrite" })
                            if (material.HasProperty(key) && original.HasProperty(key)) material.SetFloat(key, original.GetFloat(key));
                        // Keep the exact retained native combination. Copying
                        // the BA metallic-map keyword could request another
                        // stripped variant despite the native emission source.
                        // Its texture remains bound; this thin inlay uses the
                        // preserved scalar metallic/gloss finish when the native
                        // variant does not declare _METALLICGLOSSMAP.
                        material.shaderKeywords = native.shaderKeywords;
                        material.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
                        material.renderQueue = original.renderQueue; materials[i] = material;
                    }
                    else
                    {
                        materials[i] = new Material(original) { name = "BA world rift | fallback variant unverified" };
                        Debug.LogWarning("BA_DOOR_RIFT_VARIANT_UNVERIFIED: native SurtlingCore emission material unavailable; private original-material clone preserves maps. Draw variant remains unverified.");
                    }
                    // Save the unit source colour once. Live changes always
                    // rebase to it rather than multiplying prior HDR values.
                    owned.Add(materials[i]); originalEmission.Add(original.GetColor("_EmissionColor"));
                    Debug.Log("BA_DOOR_RIFT: part=" + glyph.name + "; shader=" + materials[i].shader.name + "; nativeEmissionVariant=" + (bool)native +
                        "; emissionKeyword=" + materials[i].IsKeywordEnabled("_EMISSION") + "; keywords=" + string.Join(",", materials[i].shaderKeywords) + "; map=" + materials[i].GetTexture("_EmissionMap").name +
                        "; emissionColor=" + materials[i].GetColor("_EmissionColor") + "; sourceUVAndOrangeMapPreserved=true.");
                }
                renderer.sharedMaterials = materials; renderer.enabled = true;
                var host = new GameObject("BA door rift | local orange spill"); host.transform.SetParent(glyph, false);
                host.transform.localPosition = filter.sharedMesh.bounds.center;
                var light = host.AddComponent<Light>(); light.type = LightType.Point; light.color = new Color(1f, .29f, .055f);
                light.intensity = intensity; light.range = range; light.shadows = LightShadows.None;
                light.renderMode = LightRenderMode.ForcePixel; light.bounceIntensity = 0;
                spills.Add(light);
            }
            bound = true;
            Debug.Log("BA_WORLD_DOOR_RIFT_SPILL: source=" + gameObject.name + "; lights=" + glyphs.Length + "; intensityEach=" + intensity +
                "; range=" + range + "; shadowless=true; followsOriginalRiftPieces=true; no candle/global changes.");
        }

        internal void SetProfile(float gain, float spill)
        {
            if (!float.IsFinite(gain) || gain < 0 || gain > 64 || !float.IsFinite(spill) || spill < 0 || spill > 2)
                throw new ArgumentOutOfRangeException("World portal gain must be0..64 and spill0..2.");
            emissionGain = gain; spillIntensity = spill;
            for (int i = 0; i < owned.Count; i++)
                if (owned[i])
                {
                    owned[i].SetColor("_EmissionColor", originalEmission[i] * gain);
                    owned[i].EnableKeyword("_EMISSION");
                    owned[i].globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
                }
            foreach (var light in spills) if (light) { light.intensity = spill; light.enabled = spill > 0; }
            LogStatus(s => Debug.Log(s));
        }

        internal void LogStatus(Action<string> write)
        {
            var camera = Camera.main;
            write?.Invoke("BA_WORLD_PORTAL_HDR: gain=" + emissionGain + "; spill=" + spillIntensity +
                "; activeColorSpace=" + QualitySettings.activeColorSpace + "; cameraHDR=" + (camera ? camera.allowHDR.ToString() : "no MainCamera") +
                "; materials=" + owned.Count + "; orangeMapsAndUVsPreserved=true; globalExposureAndBloomUnchanged=true.");
            foreach (var material in owned)
                if (material) write?.Invoke("BA_WORLD_PORTAL_EMISSION: shader=" + material.shader.name +
                    "; keyword=" + material.IsKeywordEnabled("_EMISSION") + "; color=" + material.GetColor("_EmissionColor") +
                    "; map=" + material.GetTexture("_EmissionMap").name);
        }

        private void OnDestroy() { foreach (var material in owned) if (material) Object.Destroy(material); }
    }
}
