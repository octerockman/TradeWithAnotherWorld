using System;

namespace BlackAbbeySixRooms
{
    // DSP-time transport policy, shared verbatim with the offline regressions.
    internal sealed class BossMusicTimeline
    {
        internal enum Phase { Waiting, Fighting, Victory, Finished }
        internal const double EntranceSeconds = 20, CombatSeconds = 520;
        internal const double VictorySeconds = 1356032d / 44100d, FadeSeconds = 1.15;
        // Jesse requested a small increase: +0.966dB over the reviewed0.8947
        // bus, retaining native Music/Master controls and every fade/timing.
        internal const double BusGain = 1.0;
        internal Phase Current { get; private set; }
        internal int Epoch { get; private set; }
        internal bool Suspended { get; private set; }
        internal double EntranceStartDsp { get; private set; }
        internal double CombatStartDsp { get; private set; }
        internal double VictoryStartDsp { get; private set; }
        internal double BattleStopDsp => VictoryStartDsp + FadeSeconds;
        internal double VictoryEndDsp => VictoryStartDsp + VictorySeconds;
        private static void Clock(double now)
        { if (double.IsNaN(now) || double.IsInfinity(now) || now < 0) throw new ArgumentOutOfRangeException(nameof(now)); }
        internal bool Start(double scheduledDsp)
        {
            Clock(scheduledDsp);
            if (Current != Phase.Waiting) return false;
            ++Epoch; Current = Phase.Fighting; Suspended = false;
            EntranceStartDsp = scheduledDsp; CombatStartDsp = scheduledDsp + EntranceSeconds;
            return true;
        }
        internal bool Complete(double scheduledDsp)
        {
            Clock(scheduledDsp);
            if (Current == Phase.Victory || Current == Phase.Finished) return false;
            ++Epoch; Current = Phase.Victory; Suspended = false; VictoryStartDsp = scheduledDsp;
            return true;
        }
        internal double BattleGain(double now)
        {
            Clock(now);
            if (Suspended || Current == Phase.Waiting || Current == Phase.Finished) return 0;
            if (Current == Phase.Fighting || now <= VictoryStartDsp) return 1;
            if (now >= BattleStopDsp) return 0;
            double x = Math.Cos((now - VictoryStartDsp) / FadeSeconds * Math.PI / 2);
            return x * x;
        }
        internal bool CombatMayStartDuringVictory => Current == Phase.Victory && CombatStartDsp >= EntranceStartDsp &&
            CombatStartDsp < BattleStopDsp && CombatStartDsp > 0;
        internal double CombatOffsetSeconds(double now)
        {
            Clock(now); return Math.Max(0, now - CombatStartDsp) % CombatSeconds;
        }
        internal void Tick(double now)
        {
            Clock(now);
            if (Current == Phase.Victory && now >= VictoryEndDsp) Current = Phase.Finished;
        }
        internal void Suspend()
        {
            if (Current == Phase.Fighting) Suspended = true;
            // Never replay victory after death, surface return or room exit.
            else if (Current == Phase.Victory) Current = Phase.Finished;
        }
        internal bool ResumeCombat(double scheduledDsp)
        {
            Clock(scheduledDsp);
            if (Current != Phase.Fighting || !Suspended) return false;
            ++Epoch; Suspended = false;
            EntranceStartDsp = scheduledDsp - EntranceSeconds; CombatStartDsp = scheduledDsp;
            return true;
        }
        internal void Reset()
        {
            ++Epoch; Current = Phase.Waiting; Suspended = false;
            EntranceStartDsp = CombatStartDsp = VictoryStartDsp = 0;
        }
    }
}
