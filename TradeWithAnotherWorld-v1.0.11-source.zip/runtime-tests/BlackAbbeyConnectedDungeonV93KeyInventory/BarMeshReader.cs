using System;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Managed file/decode work only: safe on a worker. Mesh upload, material
    // creation and collider cooking stay on Unity's main thread.
    internal sealed class BarMeshData
    {
        internal Vector3[] Positions, Normals;
        internal Vector2[] UV;
        internal Vector4[] Tangents;
        internal int[] Indices;
    }
    internal static class BarMeshReader
    {
        internal const int VertexBatch = 1024, IndexBatch = 4096;
        internal static byte[] ReadVerifiedBytes(string path, string expectedHash, long maximumBytes)
        {
            if (new FileInfo(path).Length > maximumBytes) throw new InvalidDataException("Compressed resource exceeds load budget.");
            var bytes = File.ReadAllBytes(path);
            if (bytes.LongLength > maximumBytes) throw new InvalidDataException("Resource grew beyond load budget.");
            if (expectedHash != null && Hash(bytes) != expectedHash) throw new InvalidDataException("Resource differs from its declared hash: " + Path.GetFileName(path));
            return bytes;
        }
        internal static string Hash(byte[] bytes)
        {
            using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
        }
        internal static BarMeshData Read(string path, MeshRecord record, bool collider)
        {
            var bytes = ReadVerifiedBytes(path, record.sha256, 512L * 1024 * 1024);
            using (var file = new MemoryStream(bytes, false))
            using (var gzip = new GZipStream(file, CompressionMode.Decompress)) return Decode(gzip, record, collider);
        }
        internal static BarMeshData Decode(Stream stream, MeshRecord record, bool collider)
        {
            if (!BitConverter.IsLittleEndian) throw new PlatformNotSupportedException("BAR1 requires little-endian decoding.");
            using (var reader = new BinaryReader(stream, System.Text.Encoding.UTF8, true))
            {
                if (new string(reader.ReadChars(4)) != "BAR1") throw new InvalidDataException("Invalid BAR1 magic.");
                uint vc = reader.ReadUInt32(), ic = reader.ReadUInt32();
                if (record.vertices != vc || record.indices != ic || record.triangles != ic / 3) throw new InvalidDataException("Room mesh counts differ from its manifest.");
                if (vc < 3 || vc > 2000000 || ic < 3 || ic > 12000000 || ic % 3 != 0) throw new InvalidDataException("Invalid BAR1 counts.");
                var data = new BarMeshData { Positions = new Vector3[vc], Normals = collider ? null : new Vector3[vc],
                    UV = collider ? null : new Vector2[vc], Tangents = collider ? null : new Vector4[vc], Indices = new int[ic] };
                var block = new byte[VertexBatch * 48]; var floats = new float[VertexBatch * 12];
                for (int start = 0; start < vc; start += VertexBatch)
                {
                    int count = Math.Min(VertexBatch, (int)vc - start); ReadExactly(stream, block, count * 48);
                    Buffer.BlockCopy(block, 0, floats, 0, count * 48);
                    for (int j = 0; j < count; j++)
                    {
                        int a = j * 12, i = start + j;
                        for (int k = 0; k < 12; k++) if (!Finite(floats[a + k])) throw new InvalidDataException("Nonfinite BAR1 vertex.");
                        var p = new Vector3(floats[a], floats[a + 1], floats[a + 2]);
                        if (p.sqrMagnitude > 40000) throw new InvalidDataException("BAR1 vertex outside isolated room bounds.");
                        data.Positions[i] = p;
                        if (collider) continue;
                        var n = new Vector3(floats[a + 3], floats[a + 4], floats[a + 5]);
                        if (n.sqrMagnitude < .01f) throw new InvalidDataException("BAR1 normal is zero.");
                        data.Normals[i] = n; data.UV[i] = new Vector2(floats[a + 6], floats[a + 7]);
                        data.Tangents[i] = new Vector4(floats[a + 8], floats[a + 9], floats[a + 10], floats[a + 11]);
                    }
                }
                var indexBlock = new byte[IndexBatch * 4]; var indices = new uint[IndexBatch];
                for (int start = 0; start < ic; start += IndexBatch)
                {
                    int count = Math.Min(IndexBatch, (int)ic - start); ReadExactly(stream, indexBlock, count * 4);
                    Buffer.BlockCopy(indexBlock, 0, indices, 0, count * 4);
                    for (int j = 0; j < count; j++)
                    { if (indices[j] >= vc) throw new InvalidDataException("BAR1 index out of bounds."); data.Indices[start + j] = (int)indices[j]; }
                }
                if (stream.ReadByte() != -1) throw new InvalidDataException("Unexpected BAR1 trailing data.");
                return data;
            }
        }
        private static bool Finite(float f) => !float.IsNaN(f) && !float.IsInfinity(f);
        private static void ReadExactly(Stream stream, byte[] buffer, int count)
        {
            int offset = 0;
            while (offset < count) { int read = stream.Read(buffer, offset, count - offset); if (read == 0) throw new EndOfStreamException("Truncated BAR1 resource."); offset += read; }
        }
    }
}
