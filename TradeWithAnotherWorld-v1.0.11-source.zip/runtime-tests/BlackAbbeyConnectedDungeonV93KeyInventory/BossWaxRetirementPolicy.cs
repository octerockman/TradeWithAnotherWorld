using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;

namespace BlackAbbeySixRooms
{
#pragma warning disable 0649
    internal sealed class BossWaxRoomPin { public string assetId, sourceSha256, manifestSha256; }
    internal sealed class BossWaxMeshPin
    {
        public string name, meshFile, sha256, partId;
        public int materialIndex, vertices, indices, triangles;
        public long bytes;
    }
    internal sealed class BossWaxOwner
    {
        public string sourceObject, cornerPositionsSha256;
        public int firstIndex, indexCount;
    }
    internal sealed class BossWaxRetirementFile
    {
        public int schemaVersion;
        public BossWaxRoomPin[] rooms;
        public BossWaxMeshPin sourceMesh, extraMesh;
        public BossWaxOwner[] owners;
        public string extraResource, extraSha256;
    }
#pragma warning restore 0649
    internal sealed class BossWaxRetirementResult
    {
        internal int[] Indices, OriginalTriangles;
        internal int RemovedTriangles;
    }
    // Runs only after the original exact-count pew partition. It removes
    // actual owned triangles; it never degenerates or buries old cap faces.
    internal static class BossWaxRetirementPolicy
    {
        internal const int OwnerCount = 30, MaximumExtraVertices = 30000, MaximumExtraIndices = 90000;
        private static bool Hash(string value) => value != null && value.Length == 64 && value.All(c => c >= '0' && c <= '9' || c >= 'a' && c <= 'f');
        private static bool Mesh(BossWaxMeshPin m, int maximumVertices, int maximumIndices) => m != null && !string.IsNullOrWhiteSpace(m.name) && Hash(m.sha256) &&
            m.vertices >= 3 && m.vertices <= maximumVertices && m.indices >= 3 && m.indices <= maximumIndices && m.indices % 3 == 0 && m.triangles == m.indices / 3 && m.materialIndex >= 0;
        internal static int[] Require(BossWaxRetirementFile file)
        {
            if (file == null || file.schemaVersion != 1 || file.rooms == null || file.rooms.Length != 2 || file.rooms.Any(r => r == null || !Hash(r.sourceSha256) || !Hash(r.manifestSha256)) ||
                !file.rooms.Select(r => r.assetId).OrderBy(x => x, StringComparer.Ordinal).SequenceEqual(new[] { "R09", "R09-UD" }) ||
                !Mesh(file.sourceMesh, 2000000, 12000000) || file.sourceMesh.name != "bake-props_fixtures" ||
                !Mesh(file.extraMesh, MaximumExtraVertices, MaximumExtraIndices) || file.extraMesh.materialIndex != file.sourceMesh.materialIndex ||
                string.IsNullOrWhiteSpace(file.extraResource) || !Hash(file.extraSha256) || file.extraMesh.sha256 != file.extraSha256 ||
                file.owners == null || file.owners.Length != OwnerCount || file.owners.Any(o => o == null || string.IsNullOrWhiteSpace(o.sourceObject) || o.sourceObject.Length > 1024 || !Hash(o.cornerPositionsSha256)) ||
                file.owners.Select(o => o.sourceObject).Distinct(StringComparer.Ordinal).Count() != OwnerCount)
                throw new InvalidDataException("Invalid exact boss wax retirement contract.");
            var original = new HashSet<int>();
            foreach (var owner in file.owners)
            {
                if (owner.firstIndex < 0 || owner.firstIndex % 3 != 0 || owner.indexCount < 3 || owner.indexCount % 3 != 0 || (long)owner.firstIndex + owner.indexCount > file.sourceMesh.indices)
                    throw new InvalidDataException("Boss wax ownership exceeds its original triangle stream.");
                for (int i = owner.firstIndex / 3; i < (owner.firstIndex + owner.indexCount) / 3; i++)
                    if (!original.Add(i)) throw new InvalidDataException("Boss wax source owners overlap.");
            }
            return original.OrderBy(i => i).ToArray();
        }
        internal static void RequireDisjoint(BossWaxRetirementFile file, params int[][] protectedOriginalTriangles)
        {
            var owned = new HashSet<int>(Require(file));
            if (protectedOriginalTriangles == null) throw new InvalidDataException("Missing protected source triangle ownership.");
            foreach (var protectedSet in protectedOriginalTriangles)
            {
                if (protectedSet == null || protectedSet.Any(t => t < 0 || t >= file.sourceMesh.indices / 3) || protectedSet.Distinct().Count() != protectedSet.Length || protectedSet.Any(owned.Contains))
                    throw new InvalidDataException("Boss wax ownership intersects or differs from protected source ownership.");
            }
        }
        internal static string ProofHash(int[] originalTriangles)
        {
            if (originalTriangles == null) throw new InvalidDataException("Missing boss wax triangle provenance.");
            var bytes = new byte[checked(originalTriangles.Length * 4)];
            for (int i = 0; i < originalTriangles.Length; i++)
            {
                int value = originalTriangles[i]; bytes[i * 4] = (byte)value; bytes[i * 4 + 1] = (byte)(value >> 8); bytes[i * 4 + 2] = (byte)(value >> 16); bytes[i * 4 + 3] = (byte)(value >> 24);
            }
            using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
        }
        internal static void RequireCurrentReference(object currentMesh, object provenMesh, int currentVertices, int currentIndices, int[] currentProof, int[] preparedProof, int expectedVertices, int expectedIndices, string expectedProofHash)
        {
            if (currentMesh == null || !ReferenceEquals(currentMesh, provenMesh) || !ReferenceEquals(currentProof, preparedProof) || expectedVertices < 3 || expectedIndices < 3 || expectedIndices % 3 != 0 ||
                currentVertices != expectedVertices || currentIndices != expectedIndices || currentProof == null || currentProof.Length != expectedIndices / 3 || ProofHash(currentProof) != expectedProofHash)
                throw new InvalidDataException("Boss wax current mesh/provenance differs from its exact prepared remainder.");
        }
        internal static BossWaxRetirementResult Retire(BossWaxRetirementFile file, int vertexCount, int[] currentIndices, int[] retainedOriginalTriangles, Func<int, int, float> position)
        {
            var owned = new HashSet<int>(Require(file));
            if (vertexCount < 3 || vertexCount > file.sourceMesh.vertices || currentIndices == null || currentIndices.Length == 0 || currentIndices.Length % 3 != 0 || currentIndices.Length > file.sourceMesh.indices ||
                retainedOriginalTriangles == null || retainedOriginalTriangles.Length != currentIndices.Length / 3 || position == null ||
                currentIndices.Any(i => i < 0 || i >= vertexCount)) throw new InvalidDataException("Invalid current boss wax source/provenance frame.");
            var current = new Dictionary<int, int>(); int previous = -1;
            for (int i = 0; i < retainedOriginalTriangles.Length; i++)
            {
                int original = retainedOriginalTriangles[i];
                if (original <= previous || original >= file.sourceMesh.indices / 3) throw new InvalidDataException("Boss wax provenance is unordered, duplicate or outside its source.");
                current.Add(original, i); previous = original;
            }
            if (owned.Any(t => !current.ContainsKey(t))) throw new InvalidDataException("A boss wax source triangle was already removed by another owner.");
            foreach (var owner in file.owners)
            {
                using (var memory = new MemoryStream())
                {
                    using (var writer = new BinaryWriter(memory, System.Text.Encoding.UTF8, true))
                    for (int t = owner.firstIndex / 3; t < (owner.firstIndex + owner.indexCount) / 3; t++)
                    for (int corner = 0; corner < 3; corner++)
                    for (int axis = 0; axis < 3; axis++)
                    {
                        float value = position(currentIndices[current[t] * 3 + corner], axis);
                        if (float.IsNaN(value) || float.IsInfinity(value) || Math.Abs(value) > 200) throw new InvalidDataException("Invalid boss wax source corner.");
                        writer.Write(value);
                    }
                    string digest; using (var sha = SHA256.Create()) digest = BitConverter.ToString(sha.ComputeHash(memory.ToArray())).Replace("-", "").ToLowerInvariant();
                    if (digest != owner.cornerPositionsSha256) throw new InvalidDataException("Boss wax current corner witness differs from the checked original owner.");
                }
            }
            var indices = new int[currentIndices.Length - owned.Count * 3]; var proof = new int[retainedOriginalTriangles.Length - owned.Count]; int at = 0;
            for (int t = 0; t < retainedOriginalTriangles.Length; t++)
            {
                int original = retainedOriginalTriangles[t]; if (owned.Contains(original)) continue;
                proof[at] = original; Array.Copy(currentIndices, t * 3, indices, at * 3, 3); at++;
            }
            return new BossWaxRetirementResult { Indices = indices, OriginalTriangles = proof, RemovedTriangles = owned.Count };
        }
    }
}
