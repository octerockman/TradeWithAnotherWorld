using System;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Both custom pages share this guard. Vanilla Player.TakeInput checks the
    // TextViewer, but PlayerController.TakeInput does not; blocking UI raycasts
    // alone cannot stop that separate native controller from polling attacks.
    internal static class ParchmentInputGuard
    {
        private const string HarmonyId = "studio.otherworld.blackabbeyroomtest.parchment-input";
        private static readonly ParchmentInputPolicy policy = new ParchmentInputPolicy();
        private static Harmony hooks;
        private static Func<bool> readerOpen;
        private static Player scopedPlayer;
        private static AccessTools.FieldRef<PlayerController, Player> controllerPlayer;
        private static AccessTools.FieldRef<Character, bool> attack, attackHold, secondary, secondaryHold, blocking;
        private static AccessTools.FieldRef<Player, bool> toggleBlock;
        private static AccessTools.FieldRef<Player, float> queuedAttack, queuedSecondary;
        private static bool warned;

        internal static void Initialize(Func<bool> isReaderOpen)
        {
            if (isReaderOpen == null) throw new ArgumentNullException(nameof(isReaderOpen));
            readerOpen = isReaderOpen;
            if (hooks != null) return;
            controllerPlayer = Field<PlayerController, Player>("m_character");
            attack = Field<Character, bool>("m_attack");
            attackHold = Field<Character, bool>("m_attackHold");
            secondary = Field<Character, bool>("m_secondaryAttack");
            secondaryHold = Field<Character, bool>("m_secondaryAttackHold");
            blocking = Field<Character, bool>("m_blocking");
            toggleBlock = Field<Player, bool>("m_toggleBlock");
            queuedAttack = Field<Player, float>("m_queuedAttackTimer");
            queuedSecondary = Field<Player, float>("m_queuedSecondAttackTimer");
            var controls = new[] { typeof(Vector3) }.Concat(Enumerable.Repeat(typeof(bool), 11)).ToArray();
            var targets = new[]
            {
                RequireMethod(typeof(PlayerController), "TakeInput", typeof(bool), new[] { typeof(bool) }),
                RequireMethod(typeof(Player), "TakeInput", typeof(bool), Type.EmptyTypes),
                RequireMethod(typeof(Player), "SetControls", typeof(void), controls),
                RequireMethod(typeof(Humanoid), "StartAttack", typeof(bool), new[] { typeof(Character), typeof(bool) })
            };
            string[] prefixes = { nameof(ControllerTakeInput), nameof(PlayerTakeInput), nameof(PlayerControls), nameof(StartAttack) };
            var candidate = new Harmony(HarmonyId);
            try
            {
                for (int i = 0; i < targets.Length; i++)
                    candidate.Patch(targets[i], prefix: new HarmonyMethod(typeof(ParchmentInputGuard), prefixes[i]) { priority = Priority.First });
                hooks = candidate;
            }
            catch { candidate.UnpatchSelf(); readerOpen = null; throw; }
        }

        private static AccessTools.FieldRef<T, TValue> Field<T, TValue>(string name)
        {
            var field = AccessTools.Field(typeof(T), name);
            if (field == null || field.IsStatic || field.FieldType != typeof(TValue))
                throw new MissingFieldException(typeof(T).FullName, name);
            return AccessTools.FieldRefAccess<T, TValue>(name);
        }
        private static MethodInfo RequireMethod(Type type, string name, Type result, Type[] args)
        {
            var method = AccessTools.Method(type, name, args);
            if (method == null || method.IsStatic || method.ReturnType != result)
                throw new MissingMethodException(type.FullName, name);
            return method;
        }

        // Initialize once before showing the page. Tick immediately after its
        // root becomes active, then from Update while open. Do not Shutdown on
        // Close: the native hooks must keep watching a held UI click afterward.
        internal static void Tick() { if (hooks != null) Sample(); }
        internal static bool BlocksInput => hooks != null && Sample();

        private static bool Sample()
        {
            var local = Player.m_localPlayer;
            if (!local)
            { scopedPlayer = null; policy.Reset(); return false; }
            if (scopedPlayer != local)
            { scopedPlayer = local; policy.Reset(); }
            bool open = false;
            try { open = readerOpen != null && readerOpen(); }
            catch (Exception ex)
            {
                if (!warned) { warned = true; Debug.LogWarning("Abbey reader input visibility check failed: " + ex.Message); }
            }
            if (!open && !policy.BlocksInput) return false;
            bool held = Input.GetMouseButton(0) || Input.GetMouseButton(1) || Input.GetMouseButton(2) ||
                ZInput.GetButton("Attack") || ZInput.GetButton("JoyAttack") ||
                ZInput.GetButton("SecondaryAttack") || ZInput.GetButton("JoySecondaryAttack") ||
                ZInput.GetButton("Block") || ZInput.GetButton("JoyBlock");
            bool block = policy.Observe(open, held);
            if (block) ClearLocalCombat(local);
            return block;
        }
        private static bool ForPlayer(Player player) => player && player == Player.m_localPlayer && Sample();
        private static void ClearLocalCombat(Player player)
        {
            // These are transient controls/queues only. Never cancel an enemy,
            // replace an inventory, change a saved value or abort a prior hit.
            attack(player) = false; attackHold(player) = false;
            secondary(player) = false; secondaryHold(player) = false;
            blocking(player) = false; toggleBlock(player) = false;
            queuedAttack(player) = 0f; queuedSecondary(player) = 0f;
        }
        private static bool ControllerTakeInput(PlayerController __instance, ref bool __result)
        {
            if (!__instance || !ForPlayer(controllerPlayer(__instance))) return true;
            __result = false; return false;
        }
        private static bool PlayerTakeInput(Player __instance, ref bool __result)
        {
            if (!ForPlayer(__instance)) return true;
            __result = false; return false;
        }
        private static void PlayerControls(Player __instance, ref bool attack, ref bool attackHold,
            ref bool secondaryAttack, ref bool secondaryAttackHold, ref bool block, ref bool blockHold)
        {
            if (!ForPlayer(__instance)) return;
            attack = attackHold = secondaryAttack = secondaryAttackHold = block = blockHold = false;
        }
        private static bool StartAttack(Humanoid __instance, ref bool __result)
        {
            if (!ForPlayer(__instance as Player)) return true;
            __result = false; return false;
        }
        internal static void Shutdown()
        {
            hooks?.UnpatchSelf(); hooks = null; readerOpen = null; scopedPlayer = null;
            policy.Reset(); warned = false;
        }
    }
}
