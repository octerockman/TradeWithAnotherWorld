using System;
using System.Collections.Generic;
using System.Reflection;

namespace BlackAbbeySixRooms
{
    // Cache only API metadata. No world object, UID value or result survives
    // Read: checkpoint authority always sees the current native owner/state.
    internal sealed class RuntimeWorldIdentity
    {
        private readonly MethodInfo method;
        private readonly FieldInfo worldField;
        private readonly Func<Type, string, FieldInfo> findField;
        private readonly Dictionary<Type, FieldInfo> uidFields = new Dictionary<Type, FieldInfo>();

        internal RuntimeWorldIdentity(Type ownerType, Func<Type, string, MethodInfo> findMethod, Func<Type, string, FieldInfo> findField)
        {
            if (ownerType == null || findMethod == null || findField == null) throw new ArgumentNullException();
            method = findMethod(ownerType, "GetWorldUID");
            worldField = findField(ownerType, "m_world");
            this.findField = findField;
        }

        internal string Read(object owner)
        {
            if (owner == null) return null;
            if (method != null)
            {
                var key = Key(method.Invoke(method.IsStatic ? null : owner, null));
                if (key != null) return key;
            }
            var world = worldField?.GetValue(owner);
            if (world == null) return null;
            var type = world.GetType();
            if (!uidFields.TryGetValue(type, out var field))
            {
                field = findField(type, "m_uid");
                uidFields.Add(type, field);
            }
            return Key(field?.GetValue(world));
        }

        private static string Key(object uid)
        {
            if (uid == null) return null;
            string text = uid.ToString();
            return text == "0" ? null : "uid:" + text;
        }
    }
}
