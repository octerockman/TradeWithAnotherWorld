using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

namespace BlackAbbeySixRooms
{
    internal static class FalseVowsBookCombat
    {
        private const string PatchId="studio.otherworld.blackabbeyroomtest.false-vows-book-combat";
        private static Harmony hooks;
        [ThreadStatic] private static Attack currentMelee;
        private static readonly AccessTools.FieldRef<Attack,Humanoid> Attacker=AccessTools.FieldRefAccess<Attack,Humanoid>("m_character");
        private static readonly AccessTools.FieldRef<Attack,ItemDrop.ItemData> Weapon=AccessTools.FieldRefAccess<Attack,ItemDrop.ItemData>("m_weapon");

        internal static void Initialize()
        {
            if(hooks!=null)return;
            var melee=AccessTools.Method(typeof(Attack),"DoMeleeAttack",Type.EmptyTypes);
            var damage=AccessTools.Method(typeof(Character),nameof(Character.Damage),new[]{typeof(HitData)});
            if(melee==null||damage==null)throw new MissingMethodException("The book melee/damage contract changed.");
            var candidate=new Harmony(PatchId);
            try
            {
                candidate.Patch(melee,prefix:new HarmonyMethod(typeof(FalseVowsBookCombat),nameof(BeforeMelee)){priority=Priority.First},
                    transpiler:new HarmonyMethod(typeof(FalseVowsBookCombat),nameof(PlayerTargetGate)),
                    finalizer:new HarmonyMethod(typeof(FalseVowsBookCombat),nameof(AfterMelee)));
                candidate.Patch(damage,prefix:new HarmonyMethod(typeof(FalseVowsBookCombat),nameof(MarkPlayerHit)){priority=Priority.First});
                hooks=candidate;
            }
            catch{candidate.UnpatchSelf();throw;}
        }
        internal static ItemDrop.ItemData.SharedData NativeClub()
        {
            // Jotunn's vanilla-prefab event runs BEFORE ObjectDB.CopyOtherDB.
            // Its known-vanilla cache is ready there; ObjectDB's hash table is not.
            var prefab=Jotunn.Managers.PrefabManager.Instance.GetPrefab("Club");
            var club=prefab?prefab.GetComponent<ItemDrop>()?.m_itemData?.m_shared:null;
            RequireClub(club);
            return club;
        }
        private static void RequireClub(ItemDrop.ItemData.SharedData club)
        {
            if(club?.m_attack==null||string.IsNullOrEmpty(club.m_attack.m_attackAnimation)||float.IsNaN(club.m_attackForce)||float.IsInfinity(club.m_attackForce)||club.m_attackForce<=0)
                throw new InvalidOperationException("The actual native wood Club attack/knockback is not ready; quest registration will retry without reserving item names.");
        }
        internal static void Configure(ItemDrop.ItemData.SharedData shared,ItemDrop.ItemData.SharedData club)
        {
            if(shared==null)throw new ArgumentNullException(nameof(shared));
            RequireClub(club);
            shared.m_itemType=ItemDrop.ItemData.ItemType.OneHandedWeapon;
            shared.m_animationState=club.m_animationState;
            shared.m_skillType=club.m_skillType;
            shared.m_buildPieces=null;shared.m_toolTier=0;
            // Two private templates: neither the vanilla Club nor the other
            // quest items are modified. Native skill/armor/chain rules remain.
            shared.m_attack=club.m_attack.Clone();shared.m_secondaryAttack=club.m_attack.Clone();
            shared.m_attackForce=club.m_attackForce;
            shared.m_damages=new HitData.DamageTypes{m_blunt=FalseVowsBookRules.BaseBluntDamage};
            shared.m_damagesPerLevel=new HitData.DamageTypes();shared.m_backstabBonus=1f;
            shared.m_blockPower=0;shared.m_blockPowerPerLevel=0;
            shared.m_hitEffect=club.m_hitEffect;shared.m_hitTerrainEffect=club.m_hitTerrainEffect;shared.m_startEffect=club.m_startEffect;
            shared.m_equipDuration=.25f;
        }
        private static bool IsBook(Attack attack)=>attack!=null&&Attacker(attack) is Player&&FalseVowsItems.Id(Weapon(attack))==FalseVowsState.Book;
        private static bool BeforeMelee(Attack __instance,out Attack __state)
        {
            __state=currentMelee;currentMelee=IsBook(__instance)?__instance:null;
            // No book strike may land from UI input, including an already
            // scheduled animation event while either page or fit tool is open.
            return currentMelee==null||Attacker(currentMelee)!=Player.m_localPlayer||!ParchmentInputGuard.BlocksInput;
        }
        private static Exception AfterMelee(Exception __exception,Attack __state)
        {currentMelee=__state;return __exception;}
        private static bool AllowPlayerTarget(Character attacker,Character target)
        {
            bool book=IsBook(currentMelee);
            if(FalseVowsBookRules.BypassPlayerPvp(book,book&&Attacker(currentMelee)==attacker,target is Player&&target!=attacker))return true;
            return attacker&&attacker.IsPVPEnabled();
        }
        private static void MarkPlayerHit(Character __instance,HitData __0)
        {
            var hit=__0;
            if(hit==null||!(__instance is Player)||!IsBook(currentMelee))return;
            var attacker=Attacker(currentMelee);
            if(FalseVowsBookRules.BypassPlayerPvp(true,hit.GetAttacker()==attacker,__instance!=attacker))hit.m_ignorePVP=true;
        }
        private static IEnumerable<CodeInstruction> PlayerTargetGate(IEnumerable<CodeInstruction> instructions,MethodBase original)
        {
            var code=instructions.ToList();var pvp=AccessTools.Method(typeof(Character),nameof(Character.IsPVPEnabled),Type.EmptyTypes);
            var sites=Enumerable.Range(0,code.Count).Where(i=>code[i].Calls(pvp)).ToArray();
            if(sites.Length!=1)throw new InvalidOperationException("Book PvP gate expected exactly one native melee query; native code retained.");
            int site=sites[0];var stores=new List<LocalBuilder>();
            for(int i=0;i<site-1;i++)
            {
                if(!(code[i].operand is MethodInfo method)||method.Name!="GetComponent"||!method.IsGenericMethod||method.GetGenericArguments().Length!=1||method.GetGenericArguments()[0]!=typeof(Character))continue;
                var store=code[i+1];
                if((store.opcode==OpCodes.Stloc||store.opcode==OpCodes.Stloc_S)&&store.operand is LocalBuilder local&&local.LocalType==typeof(Character))stores.Add(local);
            }
            if(stores.Count!=1)throw new InvalidOperationException("Book PvP gate could not identify the actual native character target; native code retained.");
            var bridge=AccessTools.Method(typeof(FalseVowsBookCombat),nameof(AllowPlayerTarget));
            for(int i=0;i<code.Count;i++)
            {
                if(i==site)
                {
                    var load=new CodeInstruction(OpCodes.Ldloc,stores[0]);
                    load.labels.AddRange(code[i].labels);code[i].labels.Clear();
                    load.blocks.AddRange(code[i].blocks);code[i].blocks.Clear();
                    yield return load;code[i].opcode=OpCodes.Call;code[i].operand=bridge;
                }
                yield return code[i];
            }
        }
        internal static void Shutdown(){hooks?.UnpatchSelf();hooks=null;currentMelee=null;}
    }
}
