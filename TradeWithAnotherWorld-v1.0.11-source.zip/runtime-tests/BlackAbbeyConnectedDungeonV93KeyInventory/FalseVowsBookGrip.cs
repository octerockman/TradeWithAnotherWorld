using System;
using System.Globalization;
using System.IO;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // A temporary Rule-only adaptation of OctoArsenal's archived live fitting
    // panel. It owns cosmetic equipped-clone transforms, never the item mesh.
    internal static class FalseVowsBookGrip
    {
        private static ConfigFile config;
        private static ConfigEntry<bool> enabled;
        private static ConfigEntry<KeyboardShortcut> shortcut;
        private static ConfigEntry<Vector3> position,rotation;
        private static FalseVowsBookFitSession session=new FalseVowsBookFitSession(FalseVowsBookPose.Default);
        private static GameObject host;
        private static FalseVowsBookGripPanel panel;
        private static Transform heldVisual;
        private static Harmony cursorHooks;
        internal static bool IsOpen=>panel&&panel.Visible;
        internal static FalseVowsBookFitSession Session=>session;
        internal static KeyboardShortcut Shortcut=>shortcut?.Value??new KeyboardShortcut(KeyCode.F8);
        internal static bool Enabled=>enabled?.Value??true;

        internal static void Initialize()
        {
            if(host)return;
            try
            {
                string path=Path.Combine(Paths.ConfigPath,"BlackAbbey.RuleGrip.cfg");
                config=new ConfigFile(path,true){SaveOnConfigSet=false};
                enabled=config.Bind("Temporary grip editor","Enabled",true,"Temporary local grip editor for the held Abbey Rule only. Disable after fitting is accepted.");
                shortcut=config.Bind("Temporary grip editor","ToggleKey",new KeyboardShortcut(KeyCode.F8),"Open the held Rule position/rotation editor; F8 avoids OctoArsenal's F9.");
                var d=FalseVowsBookPose.Default;
                position=config.Bind("Rule grip","Position",new Vector3(d.X,d.Y,d.Z),"Absolute right-hand attachment position in metres; no world/drop/pan change.");
                rotation=config.Bind("Rule grip","Rotation",new Vector3(d.RX,d.RY,d.RZ),"Absolute right-hand attachment Euler rotation in degrees.");
                try{var p=position.Value;var r=rotation.Value;session=new FalseVowsBookFitSession(new FalseVowsBookPose(p.x,p.y,p.z,r.x,r.y,r.z));}
                catch(ArgumentException){session=new FalseVowsBookFitSession(d);Debug.LogWarning("Abbey Rule grip contained nonfinite values; default grip retained until a valid preset is saved.");}
                host=new GameObject("Abbey | temporary Rule grip editor");Object.DontDestroyOnLoad(host);panel=host.AddComponent<FalseVowsBookGripPanel>();
                ParchmentInputGuard.Initialize(()=>SharedParchmentReader.IsOpen||IsOpen);
                var cursor=AccessTools.Method(typeof(GameCamera),nameof(GameCamera.UpdateMouseCapture));
                if(cursor==null)throw new MissingMethodException("GameCamera.UpdateMouseCapture");
                cursorHooks=new Harmony("studio.otherworld.blackabbeyroomtest.rule-grip-cursor");
                cursorHooks.Patch(cursor,postfix:new HarmonyMethod(typeof(FalseVowsBookGrip),nameof(CaptureCursor)));
            }
            catch(Exception ex)
            {
                if(host)Object.Destroy(host);host=null;panel=null;
                cursorHooks?.UnpatchSelf();cursorHooks=null;
                Debug.LogWarning("Abbey Rule grip editor unavailable; default/saved grip remains: "+ex.Message);
            }
        }
        internal static bool HasHeldRule()
        {var p=Player.m_localPlayer;return p&&!p.IsDead()&&!p.IsTeleporting()&&FalseVowsItems.Id(p.GetCurrentWeapon())==FalseVowsState.Book;}
        internal static void Attach(VisEquipment equipment,GameObject visual)
        {
            if(!visual)return;
            var owner=equipment?equipment.GetComponentInParent<Player>():null;
            bool local=owner&&owner==Player.m_localPlayer;
            Apply(visual.transform,local?session.Current:FalseVowsBookPose.Default);
            if(local)heldVisual=visual.transform;
        }
        private static void Apply(Transform visual,FalseVowsBookPose pose)
        {
            visual.localPosition=new Vector3(pose.X,pose.Y,pose.Z);
            visual.localRotation=Quaternion.Euler(pose.RX,pose.RY,pose.RZ);
        }
        internal static void RefreshHeld()
        {if(heldVisual&&HasHeldRule())Apply(heldVisual,session.Current);else heldVisual=null;}
        internal static void Save()
        {
            if(config==null)throw new InvalidOperationException("Rule grip configuration is unavailable.");
            session.Save(p=>{position.Value=new Vector3(p.X,p.Y,p.Z);rotation.Value=new Vector3(p.RX,p.RY,p.RZ);config.Save();});
        }
        internal static void CaptureCursor()
        {if(IsOpen){ZCursor.LockState=CursorLockMode.None;ZCursor.Show();}}
        internal static void Shutdown()
        {
            if(panel)panel.Close();if(host)Object.Destroy(host);host=null;panel=null;heldVisual=null;
            cursorHooks?.UnpatchSelf();cursorHooks=null;
            // The shared input guard owns its teardown and its close-click latch.
        }
    }
    public sealed class FalseVowsBookGripPanel:MonoBehaviour
    {
        internal bool Visible{get;private set;}
        private Rect window=new Rect(20,60,570,560);
        private float move=.01f,angle=1;
        private readonly string[] typed=new string[6];
        private string status="Equip the Abbey Rule. Changes preview live; Save keeps the grip after restart.";
        private GUIStyle statusStyle;
        private static bool Busy()=>SharedParchmentReader.IsOpen||global::Console.IsVisible()||(Chat.instance&&Chat.instance.HasFocus())||TextInput.IsVisible()||Menu.IsVisible()||InventoryGui.IsVisible()||Minimap.IsOpen()||StoreGui.IsVisible()||Hud.IsPieceSelectionVisible()||Hud.InRadial();
        private void Update()
        {
            if(Visible&&(!FalseVowsBookGrip.Enabled||!FalseVowsBookGrip.HasHeldRule()||Busy()))Close();
            if(FalseVowsBookGrip.Enabled&&FalseVowsBookGrip.Shortcut.IsDown()&&!Busy()&&FalseVowsBookGrip.HasHeldRule())
            {
                if(Visible)Close();
                else{Visible=true;SyncText();ParchmentInputGuard.Tick();if(GameCamera.instance)GameCamera.instance.UpdateMouseCapture();}
            }
            if(!Visible)return;
            if(BepInEx.UnityInput.Current.GetKeyDown(KeyCode.Escape))Close();
            else{FalseVowsBookGrip.CaptureCursor();ParchmentInputGuard.Tick();}
        }
        private void LateUpdate()=>FalseVowsBookGrip.RefreshHeld();
        internal void Close()
        {Visible=false;if(GameCamera.instance)GameCamera.instance.UpdateMouseCapture();}
        private void OnDisable()=>Close();
        private void OnDestroy()=>Close();
        private void SyncText(){var p=FalseVowsBookGrip.Session.Current;for(int i=0;i<6;i++)typed[i]=p.Get(i).ToString("0.####",CultureInfo.InvariantCulture);}
        private void Change(FalseVowsBookPose value)
        {if(FalseVowsBookGrip.Session.Change(value)){SyncText();status="Preview updated. Save to keep this grip after restarting.";FalseVowsBookGrip.RefreshHeld();}}
        private void OnGUI()
        {
            if(!Visible)return;
            if(statusStyle==null)statusStyle=new GUIStyle(GUI.skin.label){wordWrap=true};
            var old=GUI.matrix;float scale=Mathf.Min(1,Mathf.Min(Screen.width/610f,Screen.height/620f));
            try
            {
                GUI.matrix=Matrix4x4.TRS(Vector3.zero,Quaternion.identity,Vector3.one*scale);
                window.x=Mathf.Clamp(window.x,0,Mathf.Max(0,Screen.width/scale-window.width));window.y=Mathf.Clamp(window.y,0,Mathf.Max(0,Screen.height/scale-window.height));
                window=GUI.Window(1947361,window,Draw,"Abbey Rule — temporary grip adjustment");
            }
            catch(Exception ex){Debug.LogWarning("Abbey Rule grip panel closed: "+ex);Close();}
            finally{GUI.matrix=old;}
        }
        private void Draw(int id)
        {
            GUILayout.BeginVertical();
            GUILayout.Label("Toggle: "+FalseVowsBookGrip.Shortcut+"   |   Equipped Rule only");
            GUILayout.Label("Position uses hand attachment axes. World drops and the scales stay unchanged.");
            GUILayout.Space(5);GUILayout.Label("Position (metres)");
            for(int i=0;i<3;i++)Row(i,move,.75f);
            GUILayout.Space(5);GUILayout.Label("Rotation (degrees)");
            for(int i=3;i<6;i++)Row(i,angle,360);
            GUILayout.BeginHorizontal();
            if(GUILayout.Button("Move step: "+(move*1000).ToString("0")+" mm"))move=move==.001f?.01f:move==.01f?.05f:.001f;
            if(GUILayout.Button("Angle step: "+angle+"°"))angle=angle==1?5:angle==5?15:1;
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            if(GUILayout.Button("Apply typed values"))
            {if(FalseVowsBookPose.TryParse(typed,out var pose))Change(pose);else status="Enter six finite numbers using a decimal point, then Apply.";}
            if(GUILayout.Button("Undo last edit")&&FalseVowsBookGrip.Session.Undo()){SyncText();FalseVowsBookGrip.RefreshHeld();status="Last edit undone.";}
            if(GUILayout.Button("Reset grip")){FalseVowsBookGrip.Session.Reset();SyncText();FalseVowsBookGrip.RefreshHeld();}
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            if(GUILayout.Button("SAVE GRIP"))
            {try{FalseVowsBookGrip.Save();status="Saved: BepInEx/config/BlackAbbey.RuleGrip.cfg";}catch(Exception ex){status="Save failed. Preview retained; check the log.";Debug.LogWarning("Abbey Rule grip save failed: "+ex);}}
            if(GUILayout.Button("Discard unsaved")){FalseVowsBookGrip.Session.Discard();SyncText();FalseVowsBookGrip.RefreshHeld();status="Restored the last saved grip.";}
            if(GUILayout.Button("Close"))Close();
            GUILayout.EndHorizontal();
            GUILayout.Label(FalseVowsBookGrip.Session.Dirty?"UNSAVED CHANGES":"Saved values");
            GUILayout.Label("Close the panel to move the camera; reopen to continue fitting.");
            GUILayout.Label(status,statusStyle);GUILayout.EndVertical();GUI.DragWindow(new Rect(0,0,570,22));
        }
        private void Row(int axis,float step,float bound)
        {
            var value=FalseVowsBookGrip.Session.Current;
            GUILayout.BeginHorizontal();GUILayout.Label(new[]{"X","Y","Z"}[axis%3],GUILayout.Width(20));
            typed[axis]=GUILayout.TextField(typed[axis]??"",GUILayout.Width(92));
            if(GUILayout.Button("−",GUILayout.Width(28)))Change(value.With(axis,(float)Math.Round(value.Get(axis)-step,4)));
            if(GUILayout.Button("+",GUILayout.Width(28)))Change(value.With(axis,(float)Math.Round(value.Get(axis)+step,4)));
            if(GUILayout.Button("Reset",GUILayout.Width(48)))Change(value.With(axis,FalseVowsBookPose.Default.Get(axis)));
            float slid=GUILayout.HorizontalSlider(value.Get(axis),-bound,bound,GUILayout.Width(250));
            if(Mathf.Abs(slid-value.Get(axis))>.00001f)Change(value.With(axis,(float)Math.Round(slid,4)));
            GUILayout.EndHorizontal();
        }
    }
}

