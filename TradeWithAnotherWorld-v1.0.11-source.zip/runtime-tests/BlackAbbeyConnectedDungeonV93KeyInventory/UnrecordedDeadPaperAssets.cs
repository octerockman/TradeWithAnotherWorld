using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Rendering;
using Object=UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    internal sealed class AbbeyPaperMaterial
    {public string id,name,albedo,albedoSha256;public bool cutout;}
    internal sealed class AbbeyPaperOverlay
    {public string id,materialId;public MeshRecord mesh;public FalseVowsAssetPose roomPose;}
    internal sealed class AbbeyPaperPartition
    {public string id,targetKind,targetMeshName,targetKitId;public MeshRecord sourceMesh;public int[] removeTriangles;public AbbeyPaperOverlay[] overlays;}
    internal sealed class AbbeyPaperRoom
    {public string roomId,sourceSha256,manifestSha256,dynamicsSha256;public AbbeyPaperPartition[] partitions;}
    internal sealed class AbbeyPaperManifest
    {public int schemaVersion;public string coordinateMode;public AbbeyPaperMaterial[] materials;public AbbeyPaperRoom[] rooms;}
    internal sealed class AbbeyPaperApplied:MonoBehaviour{}
    // Four exact readable faces get their own approved images. All other room
    // vertices/materials/colliders and the inventory reading UI stay unchanged.
    internal sealed class UnrecordedDeadPaperAssets:IDisposable
    {
        private readonly string directory;
        private readonly Action<string> log;
        private readonly AbbeyPaperManifest manifest;
        private readonly LoadedRoom resources;
        private readonly Dictionary<string,Material> materials=new Dictionary<string,Material>(StringComparer.Ordinal);
        private readonly Dictionary<string,Mesh> meshes=new Dictionary<string,Mesh>(StringComparer.Ordinal);
        private sealed class Work
        {internal MeshFilter Filter;internal Mesh Masked;internal List<AbbeyPaperOverlay> Overlays=new List<AbbeyPaperOverlay>();internal HashSet<int> Removed=new HashSet<int>();}
        internal UnrecordedDeadPaperAssets(string directory,Action<string> log)
        {
            this.directory=directory;this.log=log;
            string expectedManifest=KitArchitectureProfile.ExpectedHash(directory,"papers.json",UnrecordedDeadPaperVersion.ManifestSha256);
            Verify("papers.json",expectedManifest);
            manifest=JsonConvert.DeserializeObject<AbbeyPaperManifest>(File.ReadAllText(RoomPackage.FilePath(directory,"papers.json")),ManifestReader.Settings());
            if(manifest?.schemaVersion!=1||manifest.materials?.Length!=4||manifest.rooms?.Length!=2||
                manifest.rooms.Any(r=>r==null||r.partitions==null||r.partitions.Length<1||r.partitions.Length>4))
                throw new InvalidDataException("Invalid source-bound paper feedback manifest.");
            resources=new LoadedRoom{Root=new GameObject("Abbey | direct approved paper resources"),Manifest=new PackageManifest{roomId="UD-Paper"},
                Record=new CatalogRoomRecord{roomId="UD-Paper",sourceSha256=expectedManifest,manifestSha256=expectedManifest}};
            resources.Root.SetActive(false);Object.DontDestroyOnLoad(resources.Root);
        }
        private void Verify(string file,string hash)
        {if(!CatalogReader.Hash(hash)||CatalogReader.HashFile(RoomPackage.FilePath(directory,file))!=hash)throw new InvalidDataException("Changed approved paper resource: "+file);}
        private Material Material(string id)
        {
            if(materials.TryGetValue(id,out var cached))return cached;
            var record=manifest.materials.Single(m=>m.id==id);Verify(record.albedo,record.albedoSha256);
            var material=RoomPackage.LoadAdditionalMaterial(directory,new MaterialRecord{name=record.name,albedo=record.albedo,
                cutout=record.cutout,roughness=1,metallic=0},resources,log);
            // A native stone prefab can supply a different shader later in a
            // load. Keep the paper response on the already-supported Standard
            // family, including the stripped-registry native fallback.
            if(!material.shader||material.shader.name!="Standard")
            {
                var shader=Shader.Find("Standard");
                if(!shader||!shader.isSupported){var native=WaterPresentation.FindLoadedTransparentStandard();shader=native?native.shader:null;}
                if(!shader||!shader.isSupported)throw new InvalidOperationException("Supported native Standard paper shader unavailable.");
                material.shader=shader;
            }
            if(!material.HasProperty("_EmissionMap")||!material.HasProperty("_EmissionColor"))
                throw new InvalidOperationException("The approved paper requires the existing image-capable Standard shader.");
            material.SetOverrideTag("RenderType","TransparentCutout");material.SetFloat("_Mode",1);material.SetFloat("_Cutoff",.5f);
            material.SetInt("_SrcBlend",(int)BlendMode.One);material.SetInt("_DstBlend",(int)BlendMode.Zero);material.SetInt("_ZWrite",1);
            material.EnableKeyword("_ALPHATEST_ON");material.DisableKeyword("_ALPHABLEND_ON");material.DisableKeyword("_ALPHAPREMULTIPLY_ON");material.renderQueue=2450;
            material.SetTexture("_EmissionMap",material.GetTexture("_MainTex"));
            // A bounded image response avoids both a dark face at the chain and
            // the close candle hot spot. No Light, global setting or source
            // atlas material is modified; the book's binding remains normally lit.
            material.SetColor("_Color",Color.black);material.SetColor("_EmissionColor",Color.white*.65f);
            foreach(string property in new[]{"_Metallic","_Glossiness","_GlossMapScale","_SpecularHighlights","_GlossyReflections"})if(material.HasProperty(property))material.SetFloat(property,0);
            material.EnableKeyword("_SPECULARHIGHLIGHTS_OFF");material.EnableKeyword("_GLOSSYREFLECTIONS_OFF");
            material.DisableKeyword("_NORMALMAP");material.DisableKeyword("_METALLICGLOSSMAP");material.EnableKeyword("_EMISSION");
            materials.Add(id,material);return material;
        }
        private Mesh Mesh(MeshRecord record)
        {
            if(record==null||record.vertices<3||record.vertices>4096||record.indices<3||record.indices>12288)throw new InvalidDataException("Invalid approved paper geometry budget.");
            if(meshes.TryGetValue(record.sha256,out var cached))return cached;
            Verify(record.meshFile,record.sha256);
            var mesh=RoomPackage.LoadAdditionalMesh(directory,record,false,resources,log);meshes.Add(record.sha256,mesh);return mesh;
        }
        internal void Apply(LoadedRoom room,IDictionary<string,GameObject> worldKits)
        {
            if(room.Root.GetComponent<AbbeyPaperApplied>())return;
            var binding=manifest.rooms.Single(r=>r.roomId==room.Manifest.roomId);
            if(room.Manifest.sourceSha256!=binding.sourceSha256||room.Record.sourceSha256!=binding.sourceSha256||
                room.Record.manifestSha256!=binding.manifestSha256||CatalogReader.HashFile(RoomPackage.FilePath(room.PackageDirectory,"manifest.json"))!=binding.manifestSha256||
                CatalogReader.HashFile(RoomPackage.FilePath(room.PackageDirectory,"unrecorded-dead.json"))!=binding.dynamicsSha256)
                throw new InvalidDataException("The paper partition belongs to a different exact room/source export.");
            var work=new Dictionary<MeshFilter,Work>();
            foreach(var partition in binding.partitions)
            {
                if(partition.removeTriangles==null||partition.removeTriangles.Length<1||partition.removeTriangles.Length>512||partition.overlays==null||partition.overlays.Length<1||partition.overlays.Length>2)
                    throw new InvalidDataException("Invalid paper triangle partition.");
                GameObject scope;
                if(partition.targetKind=="static")scope=room.Root;
                else if(partition.targetKind=="kit"&&worldKits.TryGetValue(partition.targetKitId,out var kit))scope=kit;
                else throw new InvalidDataException("Missing paper source component.");
                var targets=scope.GetComponentsInChildren<MeshFilter>(true).Where(f=>f.sharedMesh&&f.sharedMesh.name==partition.targetMeshName).ToArray();
                if(targets.Length!=1)throw new InvalidDataException("Paper source mesh must match exactly once: "+partition.targetMeshName);
                var target=targets[0];var source=target.sharedMesh;var indices=source.triangles;
                var record=partition.sourceMesh;
                if(record==null||source.vertexCount!=record.vertices||indices.Length!=record.indices||
                    CatalogReader.HashFile(RoomPackage.FilePath(room.PackageDirectory,record.meshFile))!=record.sha256)
                    throw new InvalidDataException("Paper source mesh/hash differs: "+partition.id);
                if(!work.TryGetValue(target,out var entry)){entry=new Work{Filter=target};work.Add(target,entry);}
                foreach(int triangle in partition.removeTriangles)
                    if(triangle<0||triangle>=indices.Length/3||!entry.Removed.Add(triangle))throw new InvalidDataException("Invalid or overlapping paper face ownership.");
                foreach(var overlay in partition.overlays)
                {Mesh(overlay.mesh);Material(overlay.materialId);entry.Overlays.Add(overlay);}
            }
            // Preflight every target and resource before changing an instance.
            foreach(var entry in work.Values)
            {
                var source=entry.Filter.sharedMesh;var remaining=UnrecordedDeadPaperMask.Excluding(source.triangles,entry.Removed);
                entry.Masked=Object.Instantiate(source);room.Resources.Add(entry.Masked);entry.Masked.name=source.name+" | approved paper faces separated";entry.Masked.triangles=remaining;
            }
            foreach(var entry in work.Values)
            {
                entry.Filter.sharedMesh=entry.Masked;
                foreach(var overlay in entry.Overlays)
                {
                    var node=new GameObject("Abbey approved paper | "+overlay.id);node.layer=entry.Filter.gameObject.layer;node.transform.SetParent(entry.Filter.transform,false);
                    overlay.roomPose?.Apply(node.transform);
                    node.AddComponent<MeshFilter>().sharedMesh=Mesh(overlay.mesh);
                    var renderer=node.AddComponent<MeshRenderer>();renderer.sharedMaterial=Material(overlay.materialId);renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;
                }
            }
            room.Root.AddComponent<AbbeyPaperApplied>();
            log?.Invoke("UNRECORDED_DEAD_PAPER_READY: "+room.InstanceId+"; exact source faces; full approved image UVs; bounded private paper response; source binding/edges/colliders and UI retained.");
        }
        public void Dispose(){resources.Dispose();}
    }
}
