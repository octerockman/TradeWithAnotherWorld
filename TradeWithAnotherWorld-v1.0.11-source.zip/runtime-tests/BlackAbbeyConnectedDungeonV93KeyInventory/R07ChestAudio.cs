using System;
using Jotunn.Managers;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // These custom local containers bypass Container.SetInUse, including its
    // normal sounds. Borrow its normal open effect only when our lid moves.
    internal sealed class R07ChestAudio
    {
        private readonly Transform source;
        private readonly EffectList opening;
        private bool openingStroke;
        private readonly Action<string> log;
        private R07ChestAudio(Transform source, EffectList opening, Action<string> log)
        { this.source = source; this.opening = opening; this.log = log; }
        internal static R07ChestAudio Attach(Transform source, string partId, Action<string> log)
        {
            if (partId != "chest-lid") return null;
            var prefab = PrefabManager.Instance.GetPrefab("piece_chest_wood");
            var container = prefab ? prefab.GetComponent<Container>() : null;
            if (!container || container.m_openEffects == null) { log?.Invoke("R07_CHEST_AUDIO_UNAVAILABLE: native chest opening effect unavailable."); return null; }
            return new R07ChestAudio(source, container.m_openEffects, log);
        }
        internal void Advanced(float previous, float current)
        {
            if (current < previous) { openingStroke = false; return; }
            if (current <= previous || openingStroke) return;
            openingStroke = true;
            // Called after an unblocked pose advance, never on use/hover,
            // stationary refresh, immediate saved-state restore or resume.
            opening.Create(source.position, source.rotation);
            log?.Invoke("R07_CHEST_OPEN_SOUND: native wood chest open effect; real lid advance; once per opening stroke.");
        }
        internal void Restored(bool open) { openingStroke = open; }
    }
}
