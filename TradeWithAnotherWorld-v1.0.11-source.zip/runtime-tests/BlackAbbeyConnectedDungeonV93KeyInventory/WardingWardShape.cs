using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Candidate room-floor dressing footprint; deliberately independent of the
    // physical recess reservation and its collision bodies.
    internal static class WardingWardShape
    {
        internal const float HalfWidth=1.78f;
        internal const float StraightLength=1.8f;
        internal const float FrontInset=.10f;
        internal const float TotalReach=StraightLength+HalfWidth;
        internal static Vector3 WorkPoint=>new Vector3(0,.015f,-1.90f);
        internal static bool Contains(Vector3 local)
        {
            if(Mathf.Abs(local.y-WorkPoint.y)>=1.5f||local.z>-FrontInset||Mathf.Abs(local.x)>HalfWidth)return false;
            if(local.z>=-StraightLength)return true;
            float dz=local.z+StraightLength;
            return local.x*local.x+dz*dz<=HalfWidth*HalfWidth;
        }
        internal static float Glow(float closingProgress)=>Mathf.SmoothStep(1,0,Mathf.Clamp01(closingProgress));
    }
}
