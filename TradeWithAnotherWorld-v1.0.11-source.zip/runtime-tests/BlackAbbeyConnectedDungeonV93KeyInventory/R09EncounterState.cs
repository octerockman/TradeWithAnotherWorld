using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Instance-owned local test state. No Unity, clock globals, persistence or
    // network authority: callers provide an eligible player's room coordinates.
    internal sealed class R09EncounterState
    {
        internal const string ScopedNativeSourceSha256 = "869bac079de49440aebe2c2dd5cabbbce2e0040173eb65977d0f1ae57fd8efb4";
        internal const float SourceChamberEndZ = 32.52f;
        internal const float QuarterDepthTriggerZ = SourceChamberEndZ * .25f;
        // Keep the hashed sidecar as source evidence. This copy is an exact
        // V7c runtime override; older/different native sources retain theirs.
        internal static R09EncounterRecord Effective(R09EncounterRecord source,string nativeSourceSha256)
        {
            if(source==null || UnrecordedDeadSourceBindings.Canonical("R09",nativeSourceSha256)!=ScopedNativeSourceSha256) return source;
            Validate(source);
            return new R09EncounterRecord{schemaVersion=source.schemaVersion,enabled=source.enabled,chamberStartZ=source.chamberStartZ,
                triggerZ=QuarterDepthTriggerZ,triggerMinX=source.triggerMinX,triggerMaxX=source.triggerMaxX,triggerMinY=source.triggerMinY,triggerMaxY=source.triggerMaxY,
                sequenceSeconds=source.sequenceSeconds,slamDurationSeconds=source.slamDurationSeconds};
        }
        internal enum Stage { Waiting, Lighting, Active, Completed }
        internal Stage Current { get; private set; }
        internal bool Locked => Current == Stage.Lighting || Current == Stage.Active;
        internal bool Started => Current != Stage.Waiting;
        private readonly R09EncounterRecord spec;
        private bool previousValid;
        private double previousZ, startedAt;

        internal R09EncounterState(R09EncounterRecord spec)
        {
            Validate(spec); this.spec = spec;
        }
        internal static void Validate(R09EncounterRecord s)
        {
            bool F(double x) => !double.IsNaN(x) && !double.IsInfinity(x);
            if (s == null || s.schemaVersion != 1 || !s.enabled ||
                !new[] { s.chamberStartZ,s.triggerZ,s.triggerMinX,s.triggerMaxX,s.triggerMinY,s.triggerMaxY,s.sequenceSeconds,s.slamDurationSeconds }.All(x => F(x)) ||
                s.chamberStartZ != 0 || s.triggerZ < 1 || s.triggerZ > 12 || s.triggerMinX >= s.triggerMaxX ||
                s.triggerMinX < -14 || s.triggerMaxX > 14 || s.triggerMinY < -1 || s.triggerMaxY > 5 || s.triggerMinY >= s.triggerMaxY ||
                s.sequenceSeconds < 1 || s.sequenceSeconds > 30 || s.slamDurationSeconds < .2 || s.slamDurationSeconds > 1)
                throw new ArgumentException("Invalid source-bound R09 encounter trigger/sequence/slam contract.");
        }
        internal bool Observe(bool eligible, double x, double y, double z, double now)
        {
            bool valid = eligible && x >= spec.triggerMinX && x <= spec.triggerMaxX &&
                y >= spec.triggerMinY && y <= spec.triggerMaxY && z >= spec.chamberStartZ && z <= 32.6 &&
                !double.IsNaN(now) && !double.IsInfinity(now);
            bool crossed = Current == Stage.Waiting && valid && previousValid && previousZ < spec.triggerZ && z >= spec.triggerZ;
            previousValid = valid; previousZ = z;
            if (crossed) { Current = Stage.Lighting; startedAt = now; }
            Tick(now); return crossed;
        }
        internal void Tick(double now)
        {
            if (Current == Stage.Lighting && now >= startedAt + spec.sequenceSeconds) Current = Stage.Active;
        }
        internal bool Lit(double groupZ, double farthestZ, double nearestZ, double now)
        {
            if (groupZ < spec.chamberStartZ || Current == Stage.Completed || Current == Stage.Active) return true;
            if (Current == Stage.Waiting) return false;
            double span = farthestZ - nearestZ;
            double delay = span <= .00001 ? 0 : Math.Max(0, Math.Min(1, (farthestZ - groupZ) / span)) * spec.sequenceSeconds;
            return now >= startedAt + delay;
        }
        internal bool Complete(bool forceForTest=false)
        {
            if (Current == Stage.Completed || !forceForTest && Current != Stage.Lighting && Current != Stage.Active) return false;
            Current = Stage.Completed; return true;
        }
        internal void Reset() { Current = Stage.Waiting; previousValid = false; startedAt = previousZ = 0; }
        internal void Restore(bool started,bool completed)
        { Reset();Current=completed?Stage.Completed:started?Stage.Active:Stage.Waiting; }
    }

    // Optional V25 sidecar field. A missing field retains the V24 room behaviour.
#pragma warning disable 0649 // JSON sidecar fields, populated by the bounded reader.
    internal sealed class R09EncounterRecord
    {
        public int schemaVersion;
        public bool enabled;
        public float chamberStartZ,triggerZ,triggerMinX,triggerMaxX,triggerMinY,triggerMaxY,sequenceSeconds,slamDurationSeconds;
    }
#pragma warning restore 0649
}
