using System;
using System.Collections.Generic;

namespace BlackAbbeySixRooms
{
    // Pure screen-space clipping. No Unity, room lifecycle or gameplay state.
    internal readonly struct PortalPoint
    {
        internal readonly double X,Y;
        internal PortalPoint(double x,double y){X=x;Y=y;}
    }
    internal sealed class PortalEdge
    {
        internal int A,B;
        internal bool Open;
        internal PortalPoint[] Window;
    }
    internal static class PortalVisibilityPolicy
    {
        internal const double ViewMargin=.08, AreaEpsilon=.0000001;
        internal const float HideDelay=.65f, OpenWarmSeconds=1.5f;
        internal static bool PortalOpen(bool desiredOpen,float physicalDegrees)=>desiredOpen||physicalDegrees>.1f;
        internal static int ClosedDoorOrigin(int a,int b,double signedDistance)=>signedDistance<=0?a:b;
        internal static bool Hold(bool visible,float now,float lastVisible)=>visible||now-lastVisible<HideDelay;
        internal static bool[] IncludeOccupiedNeighbours(bool[] visible,IReadOnlyList<PortalEdge> edges,IReadOnlyList<int> occupied)
        {
            // One hop from physical occupancy, not from the expanding visible
            // set: closed rear-mounted doors still need their room/reveal as
            // backing. This must not recursively render the entire dungeon.
            var result=(bool[])visible.Clone();
            foreach(int room in occupied)
            {
                if(room<0||room>=result.Length)continue;result[room]=true;
                foreach(var edge in edges)
                {
                    int next=edge.A==room?edge.B:edge.B==room?edge.A:-1;
                    if(next>=0&&next<result.Length)result[next]=true;
                }
            }
            return result;
        }
        internal static double Cross(PortalPoint a,PortalPoint b,PortalPoint p)=>(b.X-a.X)*(p.Y-a.Y)-(b.Y-a.Y)*(p.X-a.X);
        internal static double Area(IReadOnlyList<PortalPoint> p)
        {double a=0;for(int i=0;i<p.Count;i++){var q=p[(i+1)%p.Count];a+=p[i].X*q.Y-q.X*p[i].Y;}return Math.Abs(a)*.5;}
        internal static PortalPoint[] View()=>new[]{new PortalPoint(-ViewMargin,-ViewMargin),new PortalPoint(1+ViewMargin,-ViewMargin),new PortalPoint(1+ViewMargin,1+ViewMargin),new PortalPoint(-ViewMargin,1+ViewMargin)};
        internal static PortalPoint[] Clip(IReadOnlyList<PortalPoint> subject,IReadOnlyList<PortalPoint> mask)
        {
            var result=new List<PortalPoint>(subject);
            for(int e=0;e<mask.Count&&result.Count>0;e++)
            {
                var input=result;result=new List<PortalPoint>();var a=mask[e];var b=mask[(e+1)%mask.Count];var prev=input[input.Count-1];double pc=Cross(a,b,prev);
                foreach(var p in input)
                {
                    double c=Cross(a,b,p);bool inside=c>=-1e-9,prior=pc>=-1e-9;
                    if(inside!=prior){double t=pc/(pc-c);result.Add(new PortalPoint(prev.X+(p.X-prev.X)*t,prev.Y+(p.Y-prev.Y)*t));}
                    if(inside)result.Add(p);prev=p;pc=c;
                }
            }
            return result.ToArray();
        }
        internal static bool Contains(IReadOnlyList<PortalPoint> outer,IReadOnlyList<PortalPoint> inner)
        {foreach(var p in inner)for(int i=0;i<outer.Count;i++)if(Cross(outer[i],outer[(i+1)%outer.Count],p)<-1e-8)return false;return true;}
        internal static PortalPoint[] CounterClockwise(PortalPoint[] polygon)
        {
            double a=0;for(int i=0;i<polygon.Length;i++){var q=polygon[(i+1)%polygon.Length];a+=polygon[i].X*q.Y-q.X*polygon[i].Y;}
            if(a<0)Array.Reverse(polygon);return polygon;
        }
        internal static bool[] Visible(int count,IReadOnlyList<PortalEdge> edges,IReadOnlyList<int> origins,out bool conservativeFallback)
        {
            conservativeFallback=false;var visible=new bool[count];var windows=new List<PortalPoint[]>[count];for(int i=0;i<count;i++)windows[i]=new List<PortalPoint[]>();
            var pending=new Queue<(int room,PortalPoint[] window)>();foreach(int start in origins)if(start>=0&&start<count)pending.Enqueue((start,View()));
            int work=0;
            while(pending.Count>0)
            {
                var visit=pending.Dequeue();bool covered=false;foreach(var prior in windows[visit.room])if(Contains(prior,visit.window)){covered=true;break;}if(covered)continue;
                windows[visit.room].Add(visit.window);visible[visit.room]=true;
                // A pathological cyclic graph falls back visibly, never to a missing room.
                if(++work>count*32+64){conservativeFallback=true;for(int i=0;i<count;i++)visible[i]=true;break;}
                foreach(var edge in edges)
                {
                    if(!edge.Open||edge.Window==null||edge.Window.Length<3)continue;
                    int next=edge.A==visit.room?edge.B:edge.B==visit.room?edge.A:-1;if(next<0)continue;
                    var clipped=Clip(edge.Window,visit.window);if(clipped.Length>=3&&Area(clipped)>AreaEpsilon)pending.Enqueue((next,clipped));
                }
            }
            return visible;
        }
    }
}
