using System;
using System.Collections.Generic;
using System.Collections;
using System.Threading.Tasks;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.Rendering;
using Jotunn.Managers;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    internal sealed class LoadedRoom : IDisposable
    {
        internal GameObject Root;
        internal string InstanceId;
        internal PackageManifest Manifest;
        internal RoomPresentationBinding PresentationBinding;
        internal string DoorSourceSha256;
        internal CatalogRoomRecord Record;
        internal string PackageDirectory;
        internal int VisualTriangles, ColliderTriangles, FlameCount;
        internal int ColliderSourceVertices, ColliderUploadedVertices, WeldEligibleMeshes;
        internal int ResidentMeshHits, ResidentTextureHits, ColdResourceReads;
        internal long ColdEncodedBytes;
        internal DiagnosticRoomContext Diagnostic;
        internal MeshRenderer WaterRenderer;
        internal Material WaterMaterial, WaterOriginal;
        internal readonly List<Object> Resources = new List<Object>();
        internal readonly List<Action> SharedResourceReleases = new List<Action>();
        internal readonly List<VerifiedResourceFile> PendingSources = new List<VerifiedResourceFile>();
        internal readonly Dictionary<string, Texture2D> R09Textures = new Dictionary<string, Texture2D>(StringComparer.OrdinalIgnoreCase);
        public void Dispose()
        {
            try
            {
                if (Root) { Root.SetActive(false); Object.Destroy(Root); Root = null; }
                foreach (var resource in Resources) if (resource) Object.Destroy(resource);
                Resources.Clear();
                foreach (var release in SharedResourceReleases) release();
                SharedResourceReleases.Clear();
                R09Textures.Clear();
            }
            finally
            {
                foreach (var source in PendingSources) source.Dispose();
                PendingSources.Clear();
            }
        }
    }

    internal static class RoomPackage
    {
        // The isolated test sits at Y=8000, where float precision is about
        // 0.488mm. Preserve the native mesh but lift only the non-colliding
        // water renderer clear of the paving by a bounded two millimetres.
        internal const float WetSurfaceLift = .002f;
        internal static void LogResinPreflight(Action<string> log)
        {
            var source = PrefabManager.Instance.GetPrefab(TradeWithAnotherWorld.ResinCandleFlame.SourcePrefab);
            if (!source) { log("RESIN_PREFLIGHT PENDING: Candle_resin is not available yet. Read-only; no effects spawned."); return; }
            var flame = source.transform.Find("high/vfx"); var light = source.transform.Find("high/Point Light");
            Func<Transform, string> components = t => t ? string.Join(",", t.GetComponents<Component>().Select(c => c ? c.GetType().Name : "<missing component>")) : "<missing transform>";
            var particles = flame ? flame.GetComponent<ParticleSystem>() : null; var renderer = flame ? flame.GetComponent<ParticleSystemRenderer>() : null;
            var point = light ? light.GetComponent<Light>() : null;
            log("Resin source high/vfx: children=" + (flame ? flame.childCount.ToString() : "missing") + "; components=" + components(flame) + "; looping=" + (particles ? particles.main.loop.ToString() : "missing") + "; materials=" + (renderer ? string.Join(",", renderer.sharedMaterials.Select(m => m ? m.name : "<null>")) : "missing") + ".");
            log("Resin source high/Point Light: children=" + (light ? light.childCount.ToString() : "missing") + "; components=" + components(light) + "; type=" + (point ? point.type.ToString() : "missing") + ".");
            try
            {
                var helper = typeof(TradeWithAnotherWorld.ResinCandleFlame);
                var validateFlame = helper.GetMethod("ValidateFlame", BindingFlags.Static | BindingFlags.NonPublic);
                var validateLight = helper.GetMethod("ValidateLight", BindingFlags.Static | BindingFlags.NonPublic);
                if (validateFlame == null || validateLight == null) throw new MissingMethodException("Compiled canonical resin validators are missing.");
                validateFlame.Invoke(null, new object[] { flame }); validateLight.Invoke(null, new object[] { light });
                log("RESIN_PREFLIGHT PASS: actual installed Candle_resin leaves satisfy the compiled flame/light validators. Read-only; no effects instantiated.");
            }
            catch (Exception ex)
            {
                if (ex is TargetInvocationException invocation && invocation.InnerException != null) ex = invocation.InnerException;
                log("RESIN_PREFLIGHT ERROR: " + ex.GetType().Name + ": " + ex.Message + ". Read-only; no effects instantiated.");
            }
        }
        internal static void LogShaderPreflight(Action<string> log)
        {
            var standard = Shader.Find("Standard");
            log("BA shader preflight (read-only, no payload required): Standard=" + (standard ? standard.name + ", supported=" + standard.isSupported : "not found/stripped"));
            foreach (string name in new[] { "stone_floor_2x2", "piece_chest_wood", "piece_banner01", "Pickable_Dandelion" })
            {
                var prefab = PrefabManager.Instance.GetPrefab(name);
                if (!prefab) { log("Shader preflight prefab " + name + ": not currently available."); continue; }
                var materials = prefab.GetComponentsInChildren<Renderer>(true).SelectMany(r => r.sharedMaterials).Where(m => m).Distinct().Take(8).ToArray();
                foreach (var material in materials)
                {
                    var properties = new[] { "_MainTex", "_BumpMap", "_MetallicGlossMap", "_Glossiness", "_Metallic", "_Cutoff", "_Mode", "_SrcBlend", "_DstBlend", "_ZWrite", "_Color", "_Cull", "_CullMode" };
                    log("Shader preflight " + name + " / " + material.name + ": shader=" + material.shader.name + ", supported=" + material.shader.isSupported + ", queue=" + material.renderQueue + "; " + string.Join(", ", properties.Select(p => p + "=" + material.HasProperty(p))) + "; keywords=" + string.Join(",", material.shaderKeywords));
                    foreach (string property in new[] { "_MainTex", "_BumpMap", "_MetallicGlossMap" })
                        if (material.HasProperty(property)) log("  native " + property + ": texture=" + (material.GetTexture(property) ? material.GetTexture(property).name : "null") + ", tiling=" + material.GetTextureScale(property) + ", offset=" + material.GetTextureOffset(property));
                }
                if (materials.Length == 0) log("Shader preflight " + name + ": no renderer materials.");
            }
        }
        internal static bool Finite(float f) => !float.IsNaN(f) && !float.IsInfinity(f);
        internal static Vector3 Vector(float[] a, string label)
        {
            if (a == null || a.Length != 3 || a.Any(v => !Finite(v))) throw new InvalidDataException(label + " must contain three finite values.");
            return new Vector3(a[0], a[1], a[2]);
        }
        internal static string FilePath(string directory, string relative)
        {
            if (string.IsNullOrWhiteSpace(relative) || Path.IsPathRooted(relative)) throw new InvalidDataException("Package paths must be relative.");
            string root = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string path = Path.GetFullPath(Path.Combine(root, relative));
            if (!path.StartsWith(root, StringComparison.OrdinalIgnoreCase) || !File.Exists(path)) throw new InvalidDataException("Missing/outside package file: " + relative);
            return path;
        }
        internal static LoadedRoom Load(string directory, CatalogRoomRecord expected, Action<string> log)
        {
            LoadedRoom loaded = null;
            var steps = LoadSteps(directory, expected, log, value => loaded = value, null, false);
            try { while (steps.MoveNext()) { } } finally { (steps as IDisposable)?.Dispose(); }
            return loaded;
        }
        internal static IEnumerator LoadSteps(string directory, CatalogRoomRecord expected, Action<string> log,
            Action<LoadedRoom> completed, Action<LoadedRoom> created = null, bool incremental = true, Action<string> progress = null, DiagnosticRoomContext diagnostic = null)
        {
            bool auxiliary=diagnostic==null;
            var room = new LoadedRoom { Diagnostic=diagnostic??AbbeyLoadDiagnostics.BeginRoom(expected,"template:"+expected.roomId,"auxiliary-template") }; bool succeeded = false;
            var slice = new RoomLoadSlice();
            try
            {
                string manifestPath = FilePath(directory, "manifest.json");
                string json;
                using(AbbeyLoadDiagnostics.Measure(room.Diagnostic,"manifest.read-verify","placed-instance"))
                {
                if (!string.IsNullOrEmpty(expected.manifestSha256) && CatalogReader.HashFile(manifestPath) != expected.manifestSha256) throw new InvalidDataException("Room manifest differs from its catalog hash.");
                json = File.ReadAllText(manifestPath);
                }
                if (json.Length > 4 * 1024 * 1024) throw new InvalidDataException("Room manifest is too large.");
                PackageManifest manifest;
                using(AbbeyLoadDiagnostics.Measure(room.Diagnostic,"manifest.json-parse","placed-instance"))manifest = ManifestReader.Read(json);
                if (manifest == null || manifest.schemaVersion != 1 || manifest.roomId != expected.roomId || manifest.sourceSha256 != expected.sourceSha256)
                    throw new InvalidDataException("Expected schema1 " + expected.roomId + " package bound to source " + expected.sourceSha256 + ".");
                log($"Parsed BA manifest with installed Newtonsoft.Json: meshes={manifest.meshes?.Length ?? -1}, materials={manifest.materials?.Length ?? -1}, colliders={manifest.colliderMeshes?.Length ?? -1}, sockets={manifest.sockets?.Length ?? -1}, triangles={manifest.triangles}.");
                if (manifest.meshes == null || manifest.meshes.Length == 0 || manifest.meshes.Length > 512 || manifest.materials == null || manifest.materials.Length == 0 || manifest.materials.Length > 128)
                    throw new InvalidDataException("Room visual mesh/material inventory is invalid.");
                if (manifest.colliderMeshes == null || manifest.colliderMeshes.Length == 0 || manifest.colliderMeshes.Length > 512 || (manifest.sockets?.Length ?? 0) > 4096)
                    throw new InvalidDataException("Room collider/socket inventory is invalid.");
                var low = Vector(manifest.boundsMin, "boundsMin"); var high = Vector(manifest.boundsMax, "boundsMax");
                if (high.x <= low.x || high.y <= low.y || high.z <= low.z || (high - low).magnitude > 200) throw new InvalidDataException("Room bounds are invalid.");
                Vector(manifest.entryPosition, "entryPosition");
                if (Vector3.ProjectOnPlane(Vector(manifest.entryForward, "entryForward"), Vector3.up).sqrMagnitude < .01f) throw new InvalidDataException("Room entry forward has no horizontal direction.");
                room.Manifest = manifest; room.Record = expected; room.InstanceId = expected.roomId; room.PackageDirectory = Path.GetFullPath(directory); room.Root = new GameObject("BA_" + expected.roomId + "_StandaloneTest_NO_ZDO"); room.Root.SetActive(false);
                created?.Invoke(room);
                int layer = LayerMask.NameToLayer("static_solid");
                if (layer < 0) throw new InvalidOperationException("Valheim static_solid layer is unavailable.");
                var materials = new Material[manifest.materials.Length];
                if (manifest.materials.Any(m => m == null)) throw new InvalidDataException("Null room material.");
                if (incremental)
                {
                    var requests = new List<TextureRequest>(); var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    foreach (var material in manifest.materials.Where(m => !m.unlit))
                    {
                        var images = new[] { material.albedo, material.normal, material.metallicSmoothness, material.emission };
                        for (int j = 0; j < images.Length; j++)
                        {
                            string image = images[j]; if (string.IsNullOrWhiteSpace(image)) continue;
                            bool linear = j == 1 || j == 2;
                            var sampler = TextureSamplerPolicy.For(material, j);
                            if (BossPresentationRepair.HandlesTexture(directory, image, linear, room)||R09HallRepairV90.HandlesTexture(directory,image,linear,room)) continue;
                            string path = FilePath(directory, image), key = TextureAlias(path, linear, sampler);
                            if (seen.Add(key) && !TryResidentTexture(path, linear, room, out _, sampler))
                                requests.Add(new TextureRequest { Relative = image, Path = path, Linear = linear, Sampler = sampler });
                        }
                    }
                    using (var prepared = new RoomResourcePrefetch<PreparedTexture>(requests.Count,
                        index => {
                            var source = CreateSource(requests[index].Path, null, 256L * 1024 * 1024, room);
                            return RoomLoadScheduling.Worker(() => PrepareTexture(source));
                        }))
                    {
                        for (int i = 0; i < requests.Count; i++)
                        {
                            var request = requests[i]; var task = prepared.Current;
                            using(AbbeyLoadDiagnostics.Wait(room.Diagnostic,"texture.worker-await"))
                            while (!task.IsCompleted) yield return null;
                            slice.Resume();
                            LoadPreparedTexture(directory, request.Relative, request.Linear, room, task.GetAwaiter().GetResult(), request.Sampler);
                            prepared.Advance();
                            progress?.Invoke("textures " + (i + 1) + "/" + requests.Count);
                            if (slice.Spent) { yield return null; slice.Resume(); }
                        }
                    }
                }
                for (int i = 0; i < materials.Length; ++i)
                {
                    materials[i] = LoadMaterial(directory, manifest.materials[i], room, log);
                    if (incremental && slice.Spent) { yield return null; slice.Resume(); }
                }
                foreach (var record in manifest.meshes)
                {
                    if (record == null || record.materialIndex < 0 || record.materialIndex >= materials.Length) throw new InvalidDataException("Invalid visual material index.");
                    var pending = BeginMesh(directory, record, false, room, incremental);
                    using(AbbeyLoadDiagnostics.Wait(room.Diagnostic,"mesh.worker-await"))
                    while (!pending.Task.IsCompleted) yield return null;
                    slice.Resume();
                    var mesh = FinishMesh(pending, directory, record, false, room, log);
                    room.VisualTriangles += (int)mesh.GetIndexCount(0) / 3;
                    using(AbbeyLoadDiagnostics.Measure(room.Diagnostic,"visual.create-bind-renderer","placed-instance"))
                    {
                    var ob = new GameObject(record.name ?? "Room visual"); ob.transform.SetParent(room.Root.transform, false); ob.layer = layer;
                    if (WaterPresentation.IsSurface(manifest, record))
                    {
                        ob.transform.localPosition = Vector3.up * WetSurfaceLift;
                        log($"BA WET_SURFACE_BIAS: water renderer lifted {WetSurfaceLift:F3}m for Y8000 precision; BAR1 vertices, normals, UVs, maps and every collider are unchanged.");
                    }
                    ob.AddComponent<MeshFilter>().sharedMesh = mesh;
                    var renderer = ob.AddComponent<MeshRenderer>(); renderer.sharedMaterial = materials[record.materialIndex];
                    renderer.receiveShadows = !manifest.materials[record.materialIndex].unlit;
                    // Nearly transparent water does not become an opaque
                    // shadow caster. Preserve opaque/cutout fixture shadows.
                    renderer.shadowCastingMode = manifest.materials[record.materialIndex].transparent || manifest.materials[record.materialIndex].unlit
                        ? ShadowCastingMode.Off : ShadowCastingMode.On;
                    if (WaterPresentation.IsSurface(manifest, record))
                        WaterPresentation.Bind(room, renderer, log);
                    }
                    progress?.Invoke("visual meshes " + room.VisualTriangles + "/" + manifest.triangles);
                    if (incremental && slice.Spent) { yield return null; slice.Resume(); }
                }
                int sourceRangeDelta=StairCollarRepair.VisualTriangleDelta(room.Record,manifest)+R09HallRepairV90.VisualTriangleDelta(directory,room);
                if (checked(manifest.triangles+sourceRangeDelta) != room.VisualTriangles) throw new InvalidDataException("Manifest/actual visual triangle counts differ from the exact checked source-range repair.");
                foreach (var record in manifest.colliderMeshes)
                {
                    if (record == null) throw new InvalidDataException("Missing collision mesh record.");
                    var ob = new GameObject("Collider | " + record.name); ob.transform.SetParent(room.Root.transform, false); ob.layer = layer;
                    var collider = ob.AddComponent<MeshCollider>(); collider.convex = false;
                    // Read the actual component's native cooking flag. Do not
                    // assume a Unity-version default or change its options.
                    bool weld = (collider.cookingOptions & MeshColliderCookingOptions.WeldColocatedVertices) != 0;
                    var pending = BeginMesh(directory, record, true, room, incremental, weld);
                    using(AbbeyLoadDiagnostics.Wait(room.Diagnostic,"collider.worker-await"))
                    while (!pending.Task.IsCompleted) yield return null;
                    slice.Resume();
                    var mesh = FinishMesh(pending, directory, record, true, room, log);
                    room.ColliderTriangles += (int)mesh.GetIndexCount(0) / 3;
                    using(AbbeyLoadDiagnostics.Measure(room.Diagnostic,"collider.assign-including-sync-cook","placed-instance"))collider.sharedMesh = mesh;
                    room.ColliderSourceVertices += record.vertices; room.ColliderUploadedVertices += mesh.vertexCount;
                    if (weld) room.WeldEligibleMeshes++;
                    progress?.Invoke("collision meshes " + room.ColliderTriangles + " triangles");
                    if (incremental && slice.Spent) { yield return null; slice.Resume(); }
                }
                using(AbbeyLoadDiagnostics.Measure(room.Diagnostic,"sockets.create","placed-instance"))
                foreach (var socket in manifest.sockets ?? Array.Empty<SocketRecord>())
                {
                    if (socket == null) throw new InvalidDataException("Null candle socket.");
                    string name = socket.name ?? "Wick";
                    if (name.IndexOf(TradeWithAnotherWorld.ResinCandleFlame.SocketToken, StringComparison.Ordinal) < 0) name += " | FLAME_SOCKET";
                    var ob = new GameObject(name); ob.transform.SetParent(room.Root.transform, false); ob.transform.localPosition = R09HallRepairV90.SocketPosition(directory,room,socket);
                }
                log($"COLLIDER_VERTEX_INPUT: room={manifest.roomId}; sourceVertices={room.ColliderSourceVertices}; uploadedVertices={room.ColliderUploadedVertices}; triangles={room.ColliderTriangles}; nativeWeldEligibleMeshes={room.WeldEligibleMeshes}; exact corner positions/order/winding retained; no visual mesh changes.");
                log($"RESOURCE_REUSE: room={manifest.roomId}; residentMeshHits={room.ResidentMeshHits}; residentTexturePathHits={room.ResidentTextureHits}; coldEncodedReads={room.ColdResourceReads}; coldEncodedBytes={room.ColdEncodedBytes}; verified source handles retained only for resident resource lifetime; no encoded byte cache.");
                log($"Read BA package: {manifest.meshes.Length} visual meshes/{room.VisualTriangles} triangles, {manifest.colliderMeshes.Length} collision meshes/{room.ColliderTriangles} triangles, {manifest.sockets?.Length ?? 0} wick sockets. Coordinates already Unity metres; no axis conversion applied.");
                succeeded = true; completed(room); yield break;
            }
            finally
            {
                if(auxiliary)AbbeyLoadDiagnostics.EndRoom(room.Diagnostic,succeeded?"auxiliary-template-loaded":"auxiliary-template-failed-or-cancelled",room);
                if (!succeeded) room.Dispose();
            }
        }
        private sealed class PendingMesh
        { internal string Key; internal Mesh Shared; internal VerifiedResourceFile Source; internal Task<BarMeshData> Task; internal MeshPatchIdentity RangePatchIdentity; internal bool RangePatched, BossPatched, WeldedCollider; }
        private static PendingMesh BeginMesh(string directory, MeshRecord record, bool collider, LoadedRoom room, bool background, bool weldCollider = false)
        {
            if (record == null || string.IsNullOrWhiteSpace(record.meshFile) || !record.meshFile.EndsWith(".mesh.gz", StringComparison.OrdinalIgnoreCase) || !CatalogReader.Hash(record.sha256))
                throw new InvalidDataException("Expected a source-hashed gzip BAR1 mesh.");
            string path = FilePath(directory, record.meshFile);
            if (weldCollider && !collider) throw new InvalidOperationException("Collision compaction cannot change a visual resource.");
            var patchIdentity=StairCollarRepair.Identity(directory,room.PackageDirectory,room.Record,room.Manifest,record,collider);
            string patchToken=StairCollarRepair.CacheToken(patchIdentity);
            string bossToken=BossPresentationRepair.MeshCacheToken(directory,record,collider)+PointedConnectorRepair.MeshCacheToken(directory,record,collider)+R09HallRepairV90.MeshCacheToken(directory,record,collider);
            var pending = new PendingMesh { Key = "mesh|" + path + "|" + record.sha256 + "|" + room.Record.manifestSha256 + "|" + collider + (weldCollider ? "|exact-collision-weld-v29" : "|source-vertices")+patchToken+bossToken,
                RangePatchIdentity=patchIdentity,RangePatched=patchToken.Length>0,BossPatched=bossToken.Length>0,WeldedCollider=weldCollider };
            SharedRoomResources.TryAcquire<Mesh>(pending.Key, room, out pending.Shared);
            if (pending.Shared)
            {
                room.ResidentMeshHits++;
                pending.Task = Task.FromResult<BarMeshData>(null); return pending;
            }
            pending.Source = CreateSource(path, record.sha256, 512L * 1024 * 1024, room,collider?"collider":"mesh");
            Func<BarMeshData> read = () => {
                var bytes = pending.Source.Read();
                using(AbbeyLoadDiagnostics.Measure(room.Diagnostic,collider?"collider.gzip-bar1-decode":"mesh.gzip-bar1-decode","shared-resource-build"))
                using (var file = new MemoryStream(bytes, false))
                using (var gzip = new GZipStream(file, CompressionMode.Decompress))
                {
                    var data = BarMeshReader.Decode(gzip, record, collider);
                    data=BossPresentationRepair.Apply(directory,record,collider,data);
                    data=PointedConnectorRepair.Apply(directory,record,collider,data);
                    data=R09HallRepairV90.Apply(directory,record,collider,data);
                    data=StairCollarRepair.Apply(pending.RangePatchIdentity,data);
                    if(!weldCollider)return data;
                    using(AbbeyLoadDiagnostics.Measure(room.Diagnostic,"collider.exact-vertex-weld","shared-resource-build"))return ColliderVertexWeld.Compact(data);
                }
            };
            pending.Task = background ? RoomLoadScheduling.Worker(read) : Task.FromResult(read());
            return pending;
        }
        private static Mesh FinishMesh(PendingMesh pending, string directory, MeshRecord record, bool collider, LoadedRoom room, Action<string> log)
        {
            var data = pending.Task.GetAwaiter().GetResult();
            if (pending.Shared) return pending.Shared;
            using(AbbeyLoadDiagnostics.Measure(room.Diagnostic,collider?"collider.mesh-upload-api":"mesh.upload-api","shared-resource-build"))
            return UploadMesh(pending,directory,record,collider,room,log,data);
        }
        private static Mesh UploadMesh(PendingMesh pending,string directory,MeshRecord record,bool collider,LoadedRoom room,Action<string> log,BarMeshData data)
        {
            if (pending.Source == null || !pending.Source.IsVerified || pending.Source.Hash != record.sha256)
                throw new InvalidDataException("Mesh upload requires its verified locked source.");
            room.ColdResourceReads++; room.ColdEncodedBytes += pending.Source.BytesRead;
            if(pending.RangePatched)log($"BA SOURCE_RANGE_REPAIR: {room.Record.packageDirectory}/{record.name}; collider={collider}; sourceTriangles={record.triangles}; derivedTriangles={data.Indices.Length/3}; exact source-range witness checked before welding; catalog and disk source unchanged.");
            if(pending.BossPatched)log($"BA BOSS_SOURCE_PRESENTATION: {room.Record.packageDirectory}/{record.name}; source index stream/counts and all positions/normals retained; checked atlas frame; old decorative caps retire only after exact Pew selection.");
            if (!collider && !string.IsNullOrEmpty(room.Manifest.repairFile))
                using(AbbeyLoadDiagnostics.Measure(room.Diagnostic,"mesh.surface-repair","shared-resource-build"))RuntimeSurfaceRepair.Apply(directory, room.Manifest.repairFile, record, data.Positions, log);
            var mesh = new Mesh { name = record.name ?? "BA mesh", indexFormat = IndexFormat.UInt32 }; room.Resources.Add(mesh);
            mesh.vertices = data.Positions;
            if (!collider)
            {
                mesh.normals = data.Normals; mesh.uv = data.UV; mesh.tangents = data.Tangents;
                var colors = new Color32[data.Positions.Length]; for (int i = 0; i < colors.Length; i++) colors[i] = new Color32(255,255,255,255);
                mesh.colors32 = colors;
            }
            mesh.SetIndices(data.Indices, MeshTopology.Triangles, 0, false); mesh.RecalculateBounds();
            if(pending.RangePatched)StairCollarRepair.RegisterPewSource(mesh,pending.RangePatchIdentity,data.Positions.Length,data.Indices.Length,pending.WeldedCollider);
            SharedRoomResources.Retain(pending.Key, mesh, room, pending.Source); return mesh;
        }
        // The quest kits use the same verified BAR1 upload and resource owner
        // as rooms, without replacing or rebaking the accepted room payloads.
        internal static Mesh LoadAdditionalMesh(string directory, MeshRecord record, bool collider, LoadedRoom resources, Action<string> log)
            => FinishMesh(BeginMesh(directory, record, collider, resources, false), directory, record, collider, resources, log);
        internal static Material LoadAdditionalMaterial(string directory, MaterialRecord record, LoadedRoom resources, Action<string> log)
            => LoadMaterial(directory, record, resources, log);
        private sealed class TextureRequest { internal string Relative, Path; internal bool Linear; internal TextureSamplerRecord Sampler; }
        private sealed class PreparedTexture { internal byte[] Bytes; internal string Hash; internal VerifiedResourceFile Source; }
        private static VerifiedResourceFile CreateSource(string path, string hash, long maximum, LoadedRoom room,string diagnosticKind="texture")
        {
            var source = new VerifiedResourceFile(path, hash, maximum, room.Diagnostic,diagnosticKind);
            room.PendingSources.Add(source); return source;
        }
        private static PreparedTexture PrepareTexture(VerifiedResourceFile source)
        {
            var bytes = source.Read();
            return new PreparedTexture { Bytes = bytes, Hash = source.Hash, Source = source };
        }
        private static string TextureAlias(string path, bool linear, TextureSamplerRecord sampler = null) => "texture-path-v76|" + Path.GetFullPath(path).ToLowerInvariant() + (linear ? "|linear" : "|srgb") + TextureSamplerPolicy.Key(sampler);
        private static bool TryResidentTexture(string path, bool linear, LoadedRoom room, out Texture2D texture, TextureSamplerRecord sampler = null)
        {
            string cacheKey = TextureAlias(path, linear, sampler);
            if (room.R09Textures.TryGetValue(cacheKey, out texture)) { room.Diagnostic?.Event("texture-room-local-hit");return true; }
            if (!SharedRoomResources.TryAcquireAlias(TextureAlias(path, linear, sampler), room, out texture)) return false;
            room.ResidentTextureHits++; room.R09Textures.Add(cacheKey, texture); return true;
        }
        private static Texture2D LoadTexture(string directory, string relative, bool linear, LoadedRoom room, TextureSamplerRecord sampler = null)
        {
            if (string.IsNullOrWhiteSpace(relative)) return null;
            if (R09HallRepairV90.TryTexture(directory,relative,linear,room,sampler,out var hallTexture)) return hallTexture;
            if (BossPresentationRepair.TryTexture(directory, relative, linear, room, sampler, out var bossTexture)) return bossTexture;
            string path = FilePath(directory, relative);
            if (TryResidentTexture(path, linear, room, out var cached, sampler)) return cached;
            return LoadPreparedTexture(directory, relative, linear, room,
                PrepareTexture(CreateSource(path, null, 256L * 1024 * 1024, room)), sampler);
        }
        private static Texture2D LoadPreparedTexture(string directory, string relative, bool linear, LoadedRoom room, PreparedTexture prepared, TextureSamplerRecord sampler = null)
        {
            try
            {
                if(R09HallRepairV90.TryTexture(directory,relative,linear,room,sampler,out var hallTexture))
                {if(prepared?.Source!=null&&room.PendingSources.Remove(prepared.Source))prepared.Source.Dispose();return hallTexture;}
                if (BossPresentationRepair.TryTexture(directory, relative, linear, room, sampler, out var bossTexture))
                {
                    if (prepared?.Source != null && room.PendingSources.Remove(prepared.Source)) prepared.Source.Dispose();
                    return bossTexture;
                }
                string path = FilePath(directory, relative), cacheKey = TextureAlias(path, linear, sampler);
                if (prepared?.Source == null || prepared.Bytes == null || !prepared.Source.IsVerified || prepared.Source.Hash != prepared.Hash)
                    throw new InvalidDataException("Texture upload requires its verified locked source.");
                room.ColdResourceReads++; room.ColdEncodedBytes += prepared.Source.BytesRead;
                if (room.R09Textures.TryGetValue(cacheKey, out var cached))
                { room.PendingSources.Remove(prepared.Source); prepared.Source.Dispose(); return cached; }
                string sharedKey = RoomTextureIdentity.Key(prepared.Hash, linear, sampler);
                if (SharedRoomResources.TryAcquire<Texture2D>(sharedKey, room, out var sharedTexture))
                {
                    SharedRoomResources.BindAlias(TextureAlias(path, linear, sampler), sharedKey, prepared.Source, room);
                    room.R09Textures.Add(cacheKey, sharedTexture); return sharedTexture;
                }
                using(AbbeyLoadDiagnostics.Measure(room.Diagnostic,"texture.allocate-configure-retain","shared-resource-build"))
                {
                var texture = new Texture2D(2, 2, TextureFormat.RGBA32, true, linear); room.Resources.Add(texture);
                // Source PNGs remain on disk for inspection; runtime shaders
                // need only the uploaded copy. The source lock pins that copy.
                bool decoded;
                using(AbbeyLoadDiagnostics.Measure(room.Diagnostic,"texture.native-decode-and-upload-api","shared-resource-build"))decoded=ImageConversion.LoadImage(texture, prepared.Bytes, true);
                if (!decoded || texture.width > 8192 || texture.height > 8192)
                    throw new InvalidDataException("Invalid/oversized room texture: " + relative);
                texture.name = relative; texture.filterMode = TextureSamplerPolicy.Filter(sampler) == "point" ? FilterMode.Point : TextureSamplerPolicy.Filter(sampler) == "bilinear" ? FilterMode.Bilinear : FilterMode.Trilinear; texture.wrapMode = TextureSamplerPolicy.Wrap(sampler) == "repeat" ? TextureWrapMode.Repeat : TextureWrapMode.Clamp; texture.anisoLevel = 8;
                SharedRoomResources.Retain(sharedKey, texture, room, prepared.Source);
                SharedRoomResources.BindAlias(TextureAlias(path, linear, sampler), sharedKey, prepared.Source, room);
                room.R09Textures.Add(cacheKey, texture);
                return texture;
                }
            }
            finally { if (prepared != null) prepared.Bytes = null; }
        }
        private static Material LoadMaterial(string directory, MaterialRecord record, LoadedRoom room, Action<string> log)
        {
            using(AbbeyLoadDiagnostics.Measure(room.Diagnostic,"material.construct-and-bind","placed-instance"))return LoadMaterialCore(directory,record,room,log);
        }
        private static Material LoadMaterialCore(string directory, MaterialRecord record, LoadedRoom room, Action<string> log)
        {
            if (record == null || string.IsNullOrWhiteSpace(record.albedo) || record.cutout && record.transparent || !Finite(record.roughness) || !Finite(record.metallic)) throw new InvalidDataException("Invalid room material.");
            if (record.unlit)
            {
                if (!R09SplitIdentity.IsChamber(room.Manifest.roomId) || record.cutout || record.transparent)
                    throw new InvalidDataException("Opaque unlit material is scoped to the source-bound R09 hood interiors.");
                FilePath(directory, record.albedo);
                // Unity's built-in vertex-colour shader has no lighting/fog pass.
                // Explicit opaque blending and depth writes keep the lining solid.
                // https://docs.unity3d.com/6000.0/Documentation/ScriptReference/GL.html
                var shader = Shader.Find("Hidden/Internal-Colored");
                if (!shader || !shader.isSupported)
                    shader = Resources.FindObjectsOfTypeAll<Shader>().FirstOrDefault(s => s && s.name == "Hidden/Internal-Colored" && s.isSupported);
                if (!shader || !shader.isSupported) throw new InvalidOperationException("The supported built-in opaque unlit hood shader is unavailable; R09 stops before player travel.");
                var black = new Material(shader) { name = "BA test | " + record.name, renderQueue = 2000 };
                room.Resources.Add(black);
                foreach (string property in new[] { "_Color", "_SrcBlend", "_DstBlend", "_ZWrite", "_Cull" })
                    if (!black.HasProperty(property)) throw new InvalidOperationException("The unlit hood shader is missing " + property + ".");
                black.SetColor("_Color", new Color(0, 0, 0, 1));
                black.SetInt("_SrcBlend", (int)BlendMode.One); black.SetInt("_DstBlend", (int)BlendMode.Zero);
                black.SetInt("_ZWrite", 1); black.SetInt("_Cull", (int)CullMode.Back);
                if (black.HasProperty("_ZTest")) black.SetInt("_ZTest", (int)CompareFunction.LessEqual);
                if (black.HasProperty("_ZBias")) black.SetFloat("_ZBias", 0);
                black.SetOverrideTag("RenderType", "Opaque");
                log("BA_R09_UNLIT_HOOD: shader=" + shader.name + "; opaque black; lighting-independent; depth-write on; no reflection/emission or global light/fog setting changed.");
                return black;
            }
            if (record.alphaCutoff.HasValue && (!Finite(record.alphaCutoff.Value) || record.alphaCutoff.Value <= 0 || record.alphaCutoff.Value >= 1))
                throw new InvalidDataException("Invalid source-bound alpha cutoff.");
            if (record.normalStrength.HasValue && (!Finite(record.normalStrength.Value) || record.normalStrength.Value < 0 || record.normalStrength.Value > 4))
                throw new InvalidDataException("Invalid source-bound normal strength.");
            Material template = null; var prefab = PrefabManager.Instance.GetPrefab("stone_floor_2x2");
            if (prefab)
                template = prefab.GetComponentsInChildren<MeshRenderer>(true).SelectMany(r => r.sharedMaterials).FirstOrDefault(m => m && m.HasProperty("_MainTex") && m.HasProperty("_BumpMap") && m.HasProperty("_MetallicGlossMap") && m.HasProperty("_Glossiness") && (!record.cutout || m.HasProperty("_Cutoff")) && !record.transparent);
            Material material; string shaderSource;
            if (template) { material = new Material(template); shaderSource = "cloned loaded stone_floor_2x2 material"; }
            else
            {
                var shader = Shader.Find("Standard");
                shaderSource = "Shader.Find Standard";
                if (record.transparent)
                {
                    var nativeTransparent = WaterPresentation.FindLoadedTransparentStandard();
                    if (nativeTransparent)
                    {
                        shader = nativeTransparent.shader;
                        shaderSource = "loaded native transparent Standard shader from " + nativeTransparent.name + "; fresh material; native active keywords=" + string.Join(",", nativeTransparent.shaderKeywords);
                    }
                    else log("BA WATER_VARIANT_UNVERIFIED: no loaded native Standard transparent material was found; the fallback shader's requested transparency variant needs actual visual checking.");
                }
                if (!shader || !shader.isSupported)
                {
                    // Valheim can retain a supported Standard shader through an
                    // asset while stripping it from the Shader.Find registry.
                    // Borrow only that shader, never the plant's ADDSNOW or
                    // other material properties/keywords.
                    var dandelion = PrefabManager.Instance.GetPrefab("Pickable_Dandelion");
                    var loaded = dandelion ? dandelion.GetComponentsInChildren<Renderer>(true).SelectMany(r => r.sharedMaterials).FirstOrDefault(m => m && m.shader && m.shader.name == "Standard" && m.shader.isSupported && m.HasProperty("_MainTex") && m.HasProperty("_BumpMap") && m.HasProperty("_MetallicGlossMap") && m.HasProperty("_Glossiness")) : null;
                    if (loaded) { shader = loaded.shader; shaderSource = "loaded Pickable_Dandelion Standard shader, fresh material without inherited plant keywords"; }
                }
                if (!shader || !shader.isSupported) throw new InvalidOperationException("No compatible loaded Valheim static material or supported Standard shader is available for " + record.name + ". No invisible substitute is spawned.");
                material = new Material(shader);
            }
            room.Resources.Add(material); material.name = "BA test | " + record.name;
            if (!material.shader || !material.shader.isSupported || material.shader.name.IndexOf("InternalError", StringComparison.OrdinalIgnoreCase) >= 0) throw new InvalidOperationException("BA material selected an unsupported/error shader.");
            material.SetTexture("_MainTex", LoadTexture(directory, record.albedo, false, room, TextureSamplerPolicy.For(record, 0)));
            material.SetColor("_Color", Color.white);
            var normal = LoadTexture(directory, record.normal, true, room, TextureSamplerPolicy.For(record, 1));
            if (normal) { material.SetTexture("_BumpMap", normal); material.EnableKeyword("_NORMALMAP"); if (material.HasProperty("_BumpScale")) material.SetFloat("_BumpScale", record.normalStrength ?? 1f); }
            else if (R09SplitIdentity.IsPiece(room.Manifest.roomId)) { material.SetTexture("_BumpMap", null); material.DisableKeyword("_NORMALMAP"); }
            var mr = LoadTexture(directory, record.metallicSmoothness, true, room, TextureSamplerPolicy.For(record, 2));
            if (mr) { material.SetTexture("_MetallicGlossMap", mr); material.EnableKeyword("_METALLICGLOSSMAP"); }
            else if (R09SplitIdentity.IsPiece(room.Manifest.roomId)) { material.SetTexture("_MetallicGlossMap", null); material.DisableKeyword("_METALLICGLOSSMAP"); }
            if (!string.IsNullOrEmpty(record.emission))
            {
                if (!material.HasProperty("_EmissionMap") || !material.HasProperty("_EmissionColor") || !Finite(record.emissionStrength) || record.emissionStrength < 0 || record.emissionStrength > 128)
                    throw new InvalidDataException("Unsupported/invalid room emission material.");
                material.SetTexture("_EmissionMap", LoadTexture(directory, record.emission, false, room, TextureSamplerPolicy.For(record, 3)));
                material.SetColor("_EmissionColor", Color.white * (record.emissionStrength > 0 ? record.emissionStrength : 1f)); material.EnableKeyword("_EMISSION");
            }
            else
            {
                material.DisableKeyword("_EMISSION"); if (material.HasProperty("_EmissionColor")) material.SetColor("_EmissionColor", Color.black);
            }
            foreach (string property in new[] { "_MainTex", "_BumpMap", "_MetallicGlossMap", "_EmissionMap" })
                if (material.HasProperty(property)) { material.SetTextureScale(property, Vector2.one); material.SetTextureOffset(property, Vector2.zero); }
            if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", Mathf.Clamp01(record.metallic));
            material.SetFloat("_Glossiness", 1f - Mathf.Clamp01(record.roughness));
            if (material.HasProperty("_GlossMapScale")) material.SetFloat("_GlossMapScale", 1f);
            material.DisableKeyword("_ALPHATEST_ON"); material.DisableKeyword("_ALPHABLEND_ON"); material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            if (material.HasProperty("_Mode")) material.SetFloat("_Mode", record.transparent ? 3 : record.cutout ? 1 : 0);
            if (record.transparent)
            {
                material.SetOverrideTag("RenderType", "Transparent"); material.EnableKeyword("_ALPHAPREMULTIPLY_ON");
                if (material.HasProperty("_SrcBlend")) material.SetInt("_SrcBlend", (int)BlendMode.One);
                if (material.HasProperty("_DstBlend")) material.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
                if (material.HasProperty("_ZWrite")) material.SetInt("_ZWrite", 0);
                material.renderQueue = 3000;
            }
            else
            {
                material.SetOverrideTag("RenderType", record.cutout ? "TransparentCutout" : "Opaque");
                if (material.HasProperty("_SrcBlend")) material.SetInt("_SrcBlend", (int)BlendMode.One);
                if (material.HasProperty("_DstBlend")) material.SetInt("_DstBlend", (int)BlendMode.Zero);
                if (material.HasProperty("_ZWrite")) material.SetInt("_ZWrite", 1);
                if (record.cutout) { material.EnableKeyword("_ALPHATEST_ON"); material.SetFloat("_Cutoff", record.alphaCutoff ?? .45f); }
                material.renderQueue = record.cutout ? 2450 : -1;
            }
            log($"Material {record.name}: shader={material.shader.name}, source={shaderSource}, cutout={record.cutout}, transparent={record.transparent}, normal={normal != null}, metallicSmoothness={mr != null}; properties MainTex={material.HasProperty("_MainTex")}, BumpMap={material.HasProperty("_BumpMap")}, MetallicGlossMap={material.HasProperty("_MetallicGlossMap")}, Cutoff={material.HasProperty("_Cutoff")}, Mode={material.HasProperty("_Mode")}, SrcBlend={material.HasProperty("_SrcBlend")}, DstBlend={material.HasProperty("_DstBlend")}, ZWrite={material.HasProperty("_ZWrite")}; baked albedo sRGB, normal/MR linear, mipmaps enabled, atlas transforms reset.");
            PointedConnectorRepair.ApplyMaterial(directory,record,room,material);
            return material;
        }
    }
}
