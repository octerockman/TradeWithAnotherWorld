using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // The caller alone supplies character/world/host/containment authority. This
    // scope is independent of the custom ambience Enabled and Volume settings.
    // Native managers keep updating normally; only their owned background
    // emitters are leased muted. In particular, the shared ambient mixer and
    // AudioMan's shield hum/gameplay ZSFX are never changed.
    internal sealed class NativeDungeonBackgroundScope : MonoBehaviour
    {
        private const double DiscoveryInterval = .25;
        private static NativeDungeonBackgroundScope activeScope;
        private static readonly BindingFlags NativeFields = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public;

        private sealed class SourceIdentity : IEqualityComparer<AudioSource>
        {
            internal static readonly SourceIdentity Instance = new SourceIdentity();
            public bool Equals(AudioSource left, AudioSource right) => ReferenceEquals(left, right);
            public int GetHashCode(AudioSource value) => RuntimeHelpers.GetHashCode(value);
        }

        private readonly HashSet<AudioSource> discovered = new HashSet<AudioSource>(SourceIdentity.Instance);
        private readonly Dictionary<AudioSource, string> sourceOwners = new Dictionary<AudioSource, string>(SourceIdentity.Instance);
        private readonly List<AudioSource> sourceBuffer = new List<AudioSource>(32);
        private ReversibleAudioMuteLease<AudioSource> lease;
        private Harmony patches;
        private Action<string> log;
        private FieldInfo oceanField, ambientField, windField, shieldField, lavaField, musicField, environmentField, particlesField;
        private AudioMan audioOwner;
        private MusicMan musicOwner;
        private EnvMan environmentOwner;
        private GameObject environmentRoot;
        private GameObject[] particleRoots;
        private bool available, requested, disposed;
        private string failure;
        private double nextDiscovery;
        private static double Now => Time.realtimeSinceStartup;

        internal void Initialize(Action<string> write)
        {
            DisposeScope();
            log = write; disposed = false; failure = null;
            lease = new ReversibleAudioMuteLease<AudioSource>(source => source, source => source.mute, (source, muted) => source.mute = muted);
            try
            {
                // These exact fields and the two emission methods are checked
                // against the installed assembly by native-background-inspection.
                // Cache reflection once, rather than repeatedly searching types.
                oceanField = RequireField<AudioSource>(typeof(AudioMan), "m_oceanAmbientSource");
                ambientField = RequireField<AudioSource>(typeof(AudioMan), "m_ambientLoopSource");
                windField = RequireField<AudioSource>(typeof(AudioMan), "m_windLoopSource");
                shieldField = RequireField<AudioSource>(typeof(AudioMan), "m_shieldHumSource");
                lavaField = RequireField<List<ZSFX>>(typeof(AudioMan), "m_ambientLavaLoops");
                musicField = RequireField<AudioSource>(typeof(MusicMan), "m_musicSource");
                environmentField = RequireField<GameObject>(typeof(EnvMan), "m_currentEnvObject");
                particlesField = RequireField<GameObject[]>(typeof(EnvMan), "m_currentPSystems");
                var random = RequireMethod(typeof(AudioMan), "UpdateRandomAmbient");
                var lava = RequireMethod(typeof(AudioMan), "UpdateLavaAmbient");
                patches = new Harmony(RuntimeTestPlugin.Id + ".native-background." + GetInstanceID());
                var prefix = new HarmonyMethod(typeof(NativeDungeonBackgroundScope), nameof(AllowNativeBackgroundEmission));
                patches.Patch(random, prefix: prefix);
                patches.Patch(lava, prefix: prefix);
                available = true;
                Write("BA_NATIVE_BACKGROUND_READY: scoped native source mute leases and biome/lava emission gates; mixer, volumes, weather visuals and gameplay SFX remain native.");
            }
            catch (Exception ex)
            {
                Restore();
                patches?.UnpatchSelf(); patches = null;
                available = false; failure = ex.GetType().Name + ": " + ex.Message;
                Write("BA_NATIVE_BACKGROUND_UNAVAILABLE: " + failure);
            }
        }

        internal void SetInside(bool eligible)
        {
            if (!eligible || disposed || !available || !isActiveAndEnabled)
            {
                Restore(); return;
            }
            try
            {
                if (!ReferenceEquals(activeScope, this))
                {
                    // Replacing the component cannot abandon the old owner's
                    // saved mute states, even if its GameObject still survives.
                    if (activeScope) activeScope.Restore();
                    activeScope = this;
                }
                bool entering = !requested;
                requested = true;
                if (entering || Now >= nextDiscovery || OwnersChanged()) DiscoverNativeSources();
                lease.Enforce();
            }
            catch (Exception ex) { DisableAfterFailure(ex); }
        }

        private void LateUpdate()
        {
            if (!requested || disposed || !available) return;
            if (!ReferenceEquals(activeScope, this)) { Restore(); return; }
            try
            {
                if (Now >= nextDiscovery || OwnersChanged()) DiscoverNativeSources();
                // Reapply after normal manager updates without rescanning the
                // scene, reallocating component arrays, or changing gain/mixers.
                lease.Enforce();
            }
            catch (Exception ex) { DisableAfterFailure(ex); }
        }

        private bool OwnersChanged()
        {
            var currentAudio = AudioMan.instance;
            var currentMusic = MusicMan.instance;
            var currentEnvironment = EnvMan.instance;
            return !ReferenceEquals(audioOwner, currentAudio) || !ReferenceEquals(musicOwner, currentMusic) ||
                !ReferenceEquals(environmentOwner, currentEnvironment) || currentEnvironment &&
                (!ReferenceEquals(environmentRoot, environmentField.GetValue(currentEnvironment)) ||
                 !ReferenceEquals(particleRoots, particlesField.GetValue(currentEnvironment)));
        }

        private void DiscoverNativeSources()
        {
            nextDiscovery = Now + DiscoveryInterval;
            discovered.Clear(); sourceOwners.Clear();
            audioOwner = AudioMan.instance;
            musicOwner = MusicMan.instance;
            environmentOwner = EnvMan.instance;
            environmentRoot = environmentOwner ? environmentField.GetValue(environmentOwner) as GameObject : null;
            particleRoots = environmentOwner ? particlesField.GetValue(environmentOwner) as GameObject[] : null;

            AudioSource shield = audioOwner ? shieldField.GetValue(audioOwner) as AudioSource : null;
            if (audioOwner)
            {
                Add(oceanField.GetValue(audioOwner) as AudioSource, "AudioMan.ocean", shield);
                Add(ambientField.GetValue(audioOwner) as AudioSource, "AudioMan.environment-loop", shield);
                Add(windField.GetValue(audioOwner) as AudioSource, "AudioMan.wind", shield);
                var lava = lavaField.GetValue(audioOwner) as List<ZSFX>;
                if (lava != null)
                    for (int i = 0; i < lava.Count; ++i)
                        if (lava[i]) AddChildren(lava[i].gameObject, "AudioMan.lava-loop", shield);

                // UpdateRandomAmbient parents this exact prefab's root ZSFX to
                // AudioMan. Restrict pre-entry tails to those direct clone roots;
                // scanning all AudioMan children would also collect shield hum.
                var prefab = audioOwner.m_randomAmbientPrefab;
                if (prefab)
                {
                    string cloneName = prefab.name + "(Clone)";
                    var parent = audioOwner.transform;
                    for (int i = 0; i < parent.childCount; ++i)
                    {
                        var child = parent.GetChild(i);
                        if (child.name == cloneName && child.GetComponent<ZSFX>())
                            AddChildren(child.gameObject, "AudioMan.random-biome-tail", shield);
                    }
                }
            }
            if (musicOwner) Add(musicField.GetValue(musicOwner) as AudioSource, "MusicMan.music", shield);
            AddChildren(environmentRoot, "EnvMan.environment-FX", shield);
            if (particleRoots != null)
                for (int i = 0; i < particleRoots.Length; ++i)
                    AddChildren(particleRoots[i], "EnvMan.weather-FX", shield);

            // Restores surviving sources that no longer belong to the current
            // native owners/FX roots, as well as replacing singleton managers.
            lease.RetainOnly(discovered);
            foreach (var source in discovered) lease.Acquire(source);
        }

        private void AddChildren(GameObject root, string owner, AudioSource shield)
        {
            if (!root) return;
            sourceBuffer.Clear();
            root.GetComponentsInChildren<AudioSource>(true, sourceBuffer);
            for (int i = 0; i < sourceBuffer.Count; ++i) Add(sourceBuffer[i], owner, shield);
            sourceBuffer.Clear();
        }

        private void Add(AudioSource source, string owner, AudioSource shield)
        {
            if (!source || ReferenceEquals(source, shield) || !discovered.Add(source)) return;
            sourceOwners.Add(source, owner);
        }

        private static bool AllowNativeBackgroundEmission(AudioMan __instance)
        {
            var scope = activeScope;
            return !scope || !scope.requested || !scope.available || scope.disposed || !scope.isActiveAndEnabled ||
                !ReferenceEquals(__instance, AudioMan.instance);
        }

        internal void Restore()
        {
            // Clear the predicate first: a failing/destroyed native source must
            // never leave new native ambience suppressed after an exit.
            requested = false;
            if (ReferenceEquals(activeScope, this)) activeScope = null;
            lease?.RestoreAll();
            discovered.Clear(); sourceOwners.Clear(); sourceBuffer.Clear();
            audioOwner = null; musicOwner = null; environmentOwner = null;
            environmentRoot = null; particleRoots = null; nextDiscovery = 0;
        }

        internal void DisposeScope()
        {
            Restore();
            if (disposed) return;
            disposed = true; available = false;
            patches?.UnpatchSelf(); patches = null;
            lease?.Dispose();
        }

        internal void LogStatus(Action<string> write)
        {
            if (write == null) return;
            var status = new StringBuilder("BA_NATIVE_BACKGROUND_STATUS: available=").Append(available)
                .Append("; inside=").Append(requested && ReferenceEquals(activeScope, this))
                .Append("; leased-sources=").Append(lease?.Count ?? 0)
                .Append("; native-emission-gates=").Append(patches != null ? "biome,lava" : "none")
                .Append("; discovery-seconds=").Append(DiscoveryInterval);
            if (failure != null) status.Append("; failure=").Append(failure);
            write(status.ToString());
            foreach (var pair in sourceOwners)
            {
                var source = pair.Key;
                if (!source) continue;
                write("BA_NATIVE_BACKGROUND_SOURCE: owner=" + pair.Value + "; native-name=" + source.name +
                    "; clip=" + (source.clip ? source.clip.name : "none") + "; muted=" + source.mute);
            }
        }

        private void DisableAfterFailure(Exception ex)
        {
            Restore(); available = false;
            failure = ex.GetType().Name + ": " + ex.Message;
            Write("BA_NATIVE_BACKGROUND_DISABLED: " + failure + "; native mute leases restored.");
        }

        private static FieldInfo RequireField<T>(Type type, string name)
        {
            var field = type.GetField(name, NativeFields);
            if (field == null || field.IsStatic || field.FieldType != typeof(T))
                throw new MissingFieldException(type.Name, name);
            return field;
        }

        private static MethodInfo RequireMethod(Type type, string name)
        {
            var method = AccessTools.Method(type, name);
            if (method == null || method.IsStatic || method.ReturnType != typeof(void))
                throw new MissingMethodException(type.Name, name);
            return method;
        }

        private void Write(string message) { log?.Invoke(message); }
        private void OnDisable() { Restore(); }
        private void OnDestroy() { DisposeScope(); }
    }
}
