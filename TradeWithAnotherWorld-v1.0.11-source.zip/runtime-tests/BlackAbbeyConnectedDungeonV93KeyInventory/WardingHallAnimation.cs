using System;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.Playables;

namespace BlackAbbeySixRooms
{
    // An instance-local pose lease on a travelling source actor. No controller
    // assets, root translation, health, effects or AI settings are replaced.
    internal sealed class WardingHallAnimation : IDisposable
    {
        Animator animator; PlayableGraph graph; AnimatorControllerPlayable controller;
        MonoBehaviour custom; MethodInfo customWalk; bool customEnabled;
        AnimatorControllerParameter[] parameters;
        bool rootMotion; AnimatorCullingMode culling;
        internal bool Active => graph.IsValid() || custom && customWalk != null;
        internal bool Begin(Character actor,Animator target)
        {
            if(!actor)return false;
            var components=actor.GetComponents<MonoBehaviour>();
            // Profaned uses its own sampled bones, not the native Animator.
            // Only the explicitly supported actor API can lease those bones.
            custom=components.FirstOrDefault(c=>c&&c.GetType().FullName=="BlackAbbey.CenserBrother.CenserInstance");
            if(custom)
            {
                customWalk=custom.GetType().GetMethod("SetWardingHallWalk",BindingFlags.Instance|BindingFlags.Public,null,new[]{typeof(bool)},null);
                if(customWalk==null||customWalk.ReturnType!=typeof(void)){custom=null;customWalk=null;return false;}
                return true;
            }
            if(!target||!target.runtimeAnimatorController)return false;
            string name=target.runtimeAnimatorController.name;
            bool guard=name=="Player_animator"&&components.Any(c=>c&&c.GetType().FullName=="BlackAbbey.ReliquaryGuard.GuardInstance");
            bool monk=name=="Skeleton_animator"&&components.Any(c=>c&&c.GetType().FullName=="BlackAbbey.HushedMonk.HushedMonkInstance");
            if(!guard&&!monk)return false;
            parameters=target.parameters;
            if(!Has("forward_speed",AnimatorControllerParameterType.Float))return false;
            animator=target;rootMotion=target.applyRootMotion;culling=target.cullingMode;
            try
            {
                graph=PlayableGraph.Create("Abbey owned source hall walk");graph.SetTimeUpdateMode(DirectorUpdateMode.Manual);
                controller=AnimatorControllerPlayable.Create(graph,target.runtimeAnimatorController);
                var output=AnimationPlayableOutput.Create(graph,"Source hall",target);output.SetSourcePlayable(controller);
                target.applyRootMotion=false;target.cullingMode=AnimatorCullingMode.AlwaysAnimate;graph.Play();
                Parameters(true);for(int i=0;i<12;i++)graph.Evaluate(1f/12f);
                return true;
            }
            catch(Exception ex){Dispose();Debug.LogWarning("WARD_HALL_ANIMATION_UNAVAILABLE: "+ex.Message+"; native presentation retained");return false;}
        }
        bool Has(string name,AnimatorControllerParameterType type)=>parameters!=null&&parameters.Any(p=>p.name==name&&p.type==type);
        void Bool(string name,bool value){if(Has(name,AnimatorControllerParameterType.Bool))controller.SetBool(name,value);}
        void Float(string name,float value){if(Has(name,AnimatorControllerParameterType.Float))controller.SetFloat(name,value);}
        void Parameters(bool moving)
        {
            Bool("wakeup",false);Bool("intro",false);Bool("onGround",true);Bool("blocking",false);
            Float("statef",4);if(Has("statei",AnimatorControllerParameterType.Int))controller.SetInteger("statei",4);
            Float("forward_speed",moving?1:0);Float("sideway_speed",0);
        }
        void CustomWalk(bool enabled)
        {
            if(!custom||customWalk==null)return;
            // true refreshes the actor module's short expiry lease each frame.
            // false is explicit on stops/end; actor death/loss also expires it.
            try{customWalk.Invoke(custom,new object[]{enabled});customEnabled=enabled;}
            catch(Exception ex){Debug.LogWarning("WARD_HALL_CUSTOM_WALK_UNAVAILABLE: "+ex.Message);customEnabled=false;custom=null;customWalk=null;}
        }
        internal void Evaluate(float dt,bool moving=true)
        {
            if(custom){if(moving||customEnabled)CustomWalk(moving);return;}
            if(!graph.IsValid())return;Parameters(moving);graph.Evaluate(Mathf.Clamp(dt,0,.1f));
        }
        internal void End(bool walkingHandoff)
        {
            if(custom&&(customEnabled||walkingHandoff))CustomWalk(false);
            // The native controller resumes in the same displayed walk phase,
            // rather than restarting its default idle when the graph is freed.
            AnimatorStateInfo[] states=null;
            if(walkingHandoff&&animator&&graph.IsValid())
            {
                states=new AnimatorStateInfo[controller.GetLayerCount()];
                for(int i=0;i<states.Length;i++)states[i]=controller.GetCurrentAnimatorStateInfo(i);
            }
            if(graph.IsValid())graph.Destroy();
            if(animator)
            {
                animator.applyRootMotion=rootMotion;animator.cullingMode=culling;
                if(states!=null)for(int i=0;i<states.Length;i++)if(animator.HasState(i,states[i].fullPathHash))animator.Play(states[i].fullPathHash,i,states[i].normalizedTime);
            }
            animator=null;custom=null;customWalk=null;customEnabled=false;parameters=null;
        }
        public void Dispose()=>End(false);
    }
}
