using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlackAbbeySixRooms
{
    internal sealed class WardingSpawnerSnapshot
    {
        public int schemaVersion=1,seed;
        public string runId,worldKey,assetSha256;
        public List<WardingSpawnerState> sources=new List<WardingSpawnerState>();
        public WardingActorLedger actors;
    }
    internal static class WardingSpawnerPersistence
    {
        static JsonSerializer Serializer()=>JsonSerializer.Create(new JsonSerializerSettings {
            TypeNameHandling=TypeNameHandling.None,MetadataPropertyHandling=MetadataPropertyHandling.Ignore,
            DateParseHandling=DateParseHandling.None,MissingMemberHandling=MissingMemberHandling.Error,MaxDepth=24});
        internal static JObject ToJson(WardingSpawnerSnapshot value)=>value==null?null:JObject.FromObject(value,Serializer());
        internal static WardingSpawnerSnapshot Read(JObject value,string world,string run,int seed)
        {
            if(value==null)return null;
            if(value.ToString(Formatting.None).Length>2*1024*1024)throw new InvalidDataException("Oversized saved warding-spawner state; retained unchanged.");
            var state=value.ToObject<WardingSpawnerSnapshot>(Serializer());Validate(state,world,run,seed);
            // Old checkpoints did not save the per-cycle gate. Infer it only
            // for those sources; an explicit new false is a committed return.
            var sources=(JArray)value["sources"];
            foreach(var source in state.sources)
            {
                var saved=sources.OfType<JObject>().Single(s=>(string)s["id"]==source.id);
                if(saved.Property("awaitingReturn")==null)
                    source.awaitingReturn=source.unbarring||(state.actors?.actors.Any(a=>a.sourceId==source.id&&WardingSpawnerRetrieval.LegacyAwaitingReturn(a))??false);
            }
            return state;
        }
        internal static void Validate(WardingSpawnerSnapshot state,string world,string run,int seed)
        {
            if(state==null||state.schemaVersion!=1||state.worldKey!=world||state.runId!=run||state.seed!=seed||
                string.IsNullOrWhiteSpace(world)||string.IsNullOrWhiteSpace(run)||state.assetSha256==null||state.assetSha256.Length!=64||
                state.assetSha256.Any(c=>!(c>='a'&&c<='f'||c>='0'&&c<='9'))||state.sources==null||state.sources.Count>8||
                state.sources.Any(s=>s==null)||state.sources.Select(s=>s.id).Distinct(StringComparer.Ordinal).Count()!=state.sources.Count)
                throw new InvalidDataException("Saved warding-spawner identity/schema differs; retained unchanged.");
            foreach(var source in state.sources)WardingSpawnerPolicy.Validate(source);
            if(state.actors!=null)WardingSpawnerActorPersistence.Validate(state.actors,run,world,seed);
        }
        internal static WardingSpawnerSnapshot Clone(WardingSpawnerSnapshot value)=>value==null?null:Read(ToJson(value),value.worldKey,value.runId,value.seed);
    }
}
