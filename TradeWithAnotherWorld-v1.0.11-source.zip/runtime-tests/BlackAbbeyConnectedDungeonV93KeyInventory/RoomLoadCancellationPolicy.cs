using System;

namespace BlackAbbeySixRooms
{
    internal static class RoomLoadCancellationPolicy
    {
        // Unity's destroyed-object == null semantics must not hide a change
        // in the managed owner reference while a worker load is pending.
        internal static bool OwnerChanged(object current, object observed) => !ReferenceEquals(current, observed);
        internal static bool Orphaned(bool playerAlive, bool busy, int committedRooms, bool partialRoom, bool partialAssets)
            => !playerAlive && (busy || committedRooms > 0 || partialRoom || partialAssets);
    }
}
