using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace BlackAbbeySixRooms
{
    // A seed alone is insufficient if a future planner changes. Bind the exact
    // generated transforms and links, not the current assembly's version label.
    internal static class DungeonPlanFingerprint
    {
        internal static string Compute(DungeonPlan plan)
        {
            if(plan?.Rooms==null||plan.Links==null)throw new InvalidDataException("Missing persistent layout.");
            using(var stream=new MemoryStream())
            using(var writer=new BinaryWriter(stream,Encoding.UTF8,true))
            {
                writer.Write(1);writer.Write(plan.Seed);writer.Write(plan.Mode);writer.Write(plan.Rooms.Length);
                if(plan.GenerationRevision>=2){writer.Write(plan.GenerationRevision);writer.Write(plan.BossUnlockRoute??"");}
                foreach(var p in plan.Rooms)
                {
                    writer.Write(p.Spec.Id);writer.Write(p.Spec.SourceId);writer.Write(p.Position.X);writer.Write(p.Position.Z);
                    if(plan.GenerationRevision>=2)
                    {
                        writer.Write(p.Spec.AssetId);writer.Write(p.Spec.Reservations?.Length??0);
                        if(p.Spec.Reservations!=null)foreach(var volume in p.Spec.Reservations)foreach(var value in volume)writer.Write(value);
                        if(plan.GenerationRevision>=3)writer.Write(p.Spec.KitConnectedExteriorCollar);
                    }
                    writer.Write(p.Elevation);writer.Write(p.QuarterTurns);
                    writer.Write(p.Spec.Bounds.Length);foreach(var d in p.Spec.Bounds)writer.Write(d);
                    writer.Write(p.Spec.BoundsY.Length);foreach(var d in p.Spec.BoundsY)writer.Write(d);
                    writer.Write(p.Spec.Ports.Length);
                    foreach(var port in p.Spec.Ports)
                    {
                        writer.Write(port.id);foreach(var f in port.position)writer.Write(f);foreach(var f in port.outward)writer.Write(f);
                        writer.Write(port.width);writer.Write(port.height);writer.Write(port.depth);
                    }
                }
                writer.Write(plan.Links.Length);
                foreach(var link in plan.Links)
                {
                    if(plan.GenerationRevision>=4)writer.Write(link.Kind??"");
                    writer.Write(link.A);writer.Write(link.B);writer.Write(link.PortA.id);writer.Write(link.PortB.id);
                    writer.Write(link.Start.X);writer.Write(link.Start.Z);writer.Write(link.End.X);writer.Write(link.End.Z);writer.Write(link.Elevation);writer.Write(link.IsLoop);
                }
                writer.Flush();using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(stream.ToArray())).Replace("-","").ToLowerInvariant();
            }
        }
    }
}
