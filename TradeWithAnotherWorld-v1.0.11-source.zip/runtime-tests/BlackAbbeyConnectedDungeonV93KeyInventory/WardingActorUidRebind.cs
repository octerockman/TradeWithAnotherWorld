using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Native world loading assigns new ZDO IDs. Only a completed, unique query
    // of the durable world/run/source/actor tags can propose a new binding.
    internal sealed class WardingActorUidClaim
    {
        internal string key,sourceId,prefab,runId,worldKey;
        internal long uidUser;
        internal uint uidId;
        internal int exactMatches;
        internal bool scanComplete;
        internal float[] position,rotation;
    }

    internal static class WardingActorUidRebind
    {
        static string Uid(long user,uint id)=>user+":"+id;
        internal static bool TryPlan(WardingActorLedger original,IEnumerable<WardingActorUidClaim> proposed,
            out WardingActorLedger candidate,out string diagnostic)
        {
            candidate=null;diagnostic=null;
            try
            {
                WardingSpawnerActorPersistence.Validate(original,original?.runId,original?.worldKey,original?.seed??0);
                if(proposed==null)throw new InvalidOperationException("Native UID claim batch is missing.");
                var claims=proposed.Take(WardingSpawnerActorPersistence.MaximumActors+1).ToArray();
                if(claims.Length>WardingSpawnerActorPersistence.MaximumActors)throw new InvalidOperationException("Native UID claim batch exceeds its bound.");
                var records=original.actors.ToDictionary(r=>r.key,StringComparer.Ordinal);
                var keys=new HashSet<string>(StringComparer.Ordinal);var ids=new HashSet<string>(StringComparer.Ordinal);
                foreach(var c in claims)
                {
                    if(c==null||c.key==null||!records.TryGetValue(c.key,out var r)||!keys.Add(c.key)||
                        r.borrowed||r.state!="Pending"&&r.state!="Missing"||!c.scanComplete||c.exactMatches!=1||
                        c.runId!=original.runId||c.worldKey!=original.worldKey||c.sourceId!=r.productionSourceId||c.prefab!=r.prefab||c.uidUser==0||c.uidId==0)
                        throw new InvalidOperationException("Unverified, duplicate, terminal or borrowed native UID claim: "+(c?.key??"<null>")+".");
                    if(!ids.Add(Uid(c.uidUser,c.uidId)))throw new InvalidOperationException("Two native actor keys claim UID "+Uid(c.uidUser,c.uidId)+" (including "+c.key+").");
                    if(!WardingSpawnerActorPersistence.ValidPose(r.position,r.rotation)&&
                        !(r.state=="Pending"&&r.uidUser==0&&WardingSpawnerActorPersistence.ValidPose(c.position,c.rotation)))
                        throw new InvalidOperationException("Native UID claim has no supported pose: "+c.key+".");
                }
                var copy=WardingSpawnerActorPersistence.Copy(original);var next=copy.actors.ToDictionary(r=>r.key,StringComparer.Ordinal);
                foreach(var c in claims)
                {
                    var r=next[c.key];r.uidUser=c.uidUser;r.uidId=c.uidId;
                    if(!WardingSpawnerActorPersistence.ValidPose(r.position,r.rotation))
                    {r.position=(float[])c.position.Clone();r.rotation=(float[])c.rotation.Clone();}
                }
                // Applying all assignments before checking conflicts permits
                // native UID permutations. No partially rebound ledger escapes.
                foreach(var c in claims)
                {
                    foreach(var old in next.Values.Where(r=>r.key!=c.key&&r.uidUser==c.uidUser&&r.uidId==c.uidId))
                    {
                        if(old.borrowed||old.state!="Dead"||keys.Contains(old.key))
                            throw new InvalidOperationException("Native UID "+Uid(c.uidUser,c.uidId)+" for "+c.key+" is retained by "+old.key+" ("+old.state+(old.borrowed?", borrowed":"")+").");
                        // The unique exact tags on this UID prove it now belongs
                        // to c, not this dead produced tombstone. Keep its death
                        // record, cap history, health, effects and journey intact.
                        old.uidUser=0;old.uidId=0;
                    }
                }
                WardingSpawnerActorPersistence.Validate(copy,copy.runId,copy.worldKey,copy.seed);
                candidate=copy;return true;
            }
            catch(Exception ex){diagnostic=ex.Message;return false;}
        }
    }
}
