using System;
using System.Linq;

namespace BlackAbbeySixRooms
{
    internal static class DungeonExitPolicy
    {
        internal static bool ObserveInside(DungeonRunSnapshot run,string playerId)
        {
            if(run==null||string.IsNullOrWhiteSpace(playerId))return false;
            var participant=run.participants.SingleOrDefault(p=>p.playerId==playerId);
            if(participant==null){run.participants.Add(new RunParticipant{playerId=playerId,exitedProperly=false});return true;}
            if(!participant.exitedProperly)return false;
            participant.exitedProperly=false;return true;
        }
        internal static bool Exit(DungeonRunSnapshot run,string playerId)
        {
            var participant=run?.participants.SingleOrDefault(p=>p.playerId==playerId);
            if(participant==null||participant.exitedProperly)return false;
            participant.exitedProperly=true;return true;
        }
        internal static bool CanRetire(DungeonRunSnapshot run,int physicallyInside)
            =>run!=null&&run.bossCompleted&&physicallyInside==0&&run.participants.Count>0&&run.participants.All(p=>p.exitedProperly);
    }
}
