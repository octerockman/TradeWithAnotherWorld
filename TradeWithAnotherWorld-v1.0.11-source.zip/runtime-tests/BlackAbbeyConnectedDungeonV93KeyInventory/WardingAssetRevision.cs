namespace BlackAbbeySixRooms
{
    internal static class WardingAssetRevision
    {
        internal const string Previous="18dddfffd6f27cfc85b88b5289fd54e675a0db3cb42ea2b840190a433b31691e";
        internal const string Prior="9ac2aed0702291c07a8bf3b1114867745d2293c6a4a057795208707a87f0ca63";
        internal const string Current="5ef81123aaba20a08228c8b034fcae00b070641f5c1c26ae41d978f5097afcd9";
        // Exact audited appearance-only chain. The packed2K export changes
        // UV/tangent/maps only; IDs, mounts, collider geometry, sockets and
        // motions remain. Retain both previously admitted saved hashes.
        internal static bool Compatible(string saved,string loaded)=>saved==loaded
            ||saved==Previous&&loaded==Prior
            ||loaded==Current&&(saved==Previous||saved==Prior);
    }
}
