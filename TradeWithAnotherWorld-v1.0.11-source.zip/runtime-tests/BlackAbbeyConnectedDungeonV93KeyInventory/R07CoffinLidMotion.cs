using System;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Source-bound motion of the unchanged full lid, including its locating
    // lip. Child meshes retain source coordinates minus the manifest pivot.
    // This is a deterministic kinematic slide and gravity-like tip, not a
    // replacement mesh or an unconstrained physics body.
    internal static class R07CoffinLidMotion
    {
        internal const float DurationSeconds = 3.2f;
        internal const float LiftEndPhase = .08f;
        internal const float TippingStartPhase = .50f;
        internal const float SettleStartPhase = .88f;
        internal const float ImpactPhase = 1f;
        internal const float FinalAngleDegrees = 33.40555276f;
        // Centroid of the actual unchanged lid's lowest final bevel edge.
        internal static readonly Vector3 ImpactPosition = new Vector3(-1.1138500271f, .001f, 5f);
        // The fallen lid covers the earlier room-facing side handle. Keep E
        // above the true hollow, accessible over the rim from the room.
        internal static readonly Vector3 UseCenter = new Vector3(-2.8f, .90f, 5f);
        internal static readonly Vector3 UseSize = new Vector3(.65f, .35f, 2f);
        private const float LeftX = -3.4500000477f;
        private const float LeftY = .7785000205f;

        // Scrape while sliding across and off the rim; the final floor impact
        // is a separate one-shot, triggered only by real advancing motion.
        internal static bool IsSliding(float phase) => phase > LiftEndPhase && phase < ImpactPhase;

        internal static void Evaluate(float phase, Vector3 sourcePivot, out Vector3 localHostPosition, out Quaternion localHostRotation)
        {
            if (!float.IsFinite(phase)) throw new ArgumentOutOfRangeException(nameof(phase));
            phase = Mathf.Clamp01(phase);
            localHostRotation = Quaternion.identity;
            if (phase <= LiftEndPhase)
            {
                // The existing locating lip hangs 38mm below the rim. Lift
                // 40.5mm to free it before scraping across that same rim.
                localHostPosition = sourcePivot + new Vector3(0, .0405f * Smooth(phase / LiftEndPhase), 0);
                return;
            }
            if (phase <= TippingStartPhase)
            {
                localHostPosition = sourcePivot + new Vector3(.645f * Smooth((phase - LiftEndPhase) / (TippingStartPhase - LiftEndPhase)), .0405f, 0);
                return;
            }
            float sourceContactX, angle, contactY;
            if (phase <= SettleStartPhase)
            {
                float t = (phase - TippingStartPhase) / (SettleStartPhase - TippingStartPhase);
                sourceContactX = Mathf.Lerp(-2.8f, LeftX, Smooth(t));
                // Match angular velocity into the final settling segment;
                // the lid must not hesitate at the end of its roll.
                float endTangent = (FinalAngleDegrees - 32.8f) *
                    (SettleStartPhase - TippingStartPhase) / (ImpactPhase - SettleStartPhase);
                angle = -(32.8f * Smooth(t) + endTangent * (t * t * t - t * t));
                contactY = .752f;
            }
            else
            {
                float t = (phase - SettleStartPhase) / (ImpactPhase - SettleStartPhase);
                sourceContactX = LeftX;
                angle = -32.8f - (FinalAngleDegrees - 32.8f) * t;
                contactY = .752f + (.720f - .752f) * t * t;
            }
            localHostRotation = Quaternion.AngleAxis(angle, Vector3.forward);
            Vector3 sourceContact = new Vector3(sourceContactX, LowerHullY(sourceContactX), 5);
            Vector3 roomContact = new Vector3(-2.155f, contactY, 5);
            // For a source point p, the complete mapping is
            // roomContact + rotation * (p-sourceContact). Consequently the
            // existing host with children p-sourcePivot uses this position.
            localHostPosition = roomContact + localHostRotation * (sourcePivot - sourceContact);
        }

        private static float Smooth(float t) => t * t * (3 - 2 * t);
        private static float LowerHullY(float x)
        {
            if (x <= -3.4149999619f)
                return Mathf.LerpUnclamped(LeftY, .7515000105f, (x - LeftX) / (-3.4149999619f - LeftX));
            if (x <= -3.1510000229f)
                return Mathf.LerpUnclamped(.7515000105f, .7115000486f, (x + 3.4149999619f) / (-3.1510000229f + 3.4149999619f));
            return .7115000486f;
        }
    }
}
