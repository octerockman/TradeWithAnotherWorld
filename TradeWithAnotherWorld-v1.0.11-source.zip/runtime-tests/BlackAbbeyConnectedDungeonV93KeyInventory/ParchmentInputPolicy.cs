namespace BlackAbbeySixRooms
{
    // A UI press stays owned by the reader until every combat control is up.
    // Ordinary gameplay never arms this latch merely by holding a weapon key.
    internal sealed class ParchmentInputPolicy
    {
        internal bool BlocksInput { get; private set; }
        internal bool Observe(bool readerOpen, bool combatHeld)
        {
            if (readerOpen) BlocksInput = true;
            else if (BlocksInput && !combatHeld) BlocksInput = false;
            return BlocksInput;
        }
        internal void Reset() { BlocksInput = false; }
    }
}
