using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;

namespace BlackAbbeySixRooms
{
    internal sealed class PewRepairSlot
    {
        internal readonly int FirstIndex, SourceIndexCount, ReplacementIndexCount;
        internal readonly bool AppendAtEnd;
        internal PewRepairSlot(PinnedMeshRangePatch row)
        { FirstIndex = row.firstIndex; SourceIndexCount = row.indexCount; ReplacementIndexCount = row.newIndices.Length; AppendAtEnd = row.appendAtEnd; }
    }
    internal sealed class PewRepairProof
    {
        internal readonly string AssetId, SourceSha256, ManifestSha256, MeshFile, MeshSha256, MeshName, PayloadSha256;
        internal readonly bool Collider, Welded;
        internal readonly int OriginalVertexCount, OriginalIndexCount, PreWeldVertexCount, DerivedVertexCount, DerivedSourceIndexCount, AppendedTailIndexCount;
        private readonly PewRepairSlot[] slots;
        internal PewRepairSlot[] Slots => (PewRepairSlot[])slots.Clone();
        internal PewRepairProof(MeshPatchIdentity source, PinnedMeshRangePatch[] rows, string payload, int preWeldVertices, int uploadedVertices, int uploadedIndices, bool welded)
        {
            AssetId = source.AssetId; SourceSha256 = source.SourceSha256; ManifestSha256 = source.ManifestSha256;
            MeshFile = source.MeshFile; MeshSha256 = source.MeshSha256; MeshName = source.MeshName; Collider = source.Collider;
            OriginalVertexCount = source.SourceVertices; OriginalIndexCount = source.SourceIndices; PreWeldVertexCount = preWeldVertices;
            DerivedVertexCount = uploadedVertices; DerivedSourceIndexCount = uploadedIndices; Welded = welded; PayloadSha256 = payload;
            slots = rows.Select(r => new PewRepairSlot(r)).ToArray();
            AppendedTailIndexCount = slots.Where(r => r.AppendAtEnd).Sum(r => r.ReplacementIndexCount);
        }
    }
    // Only the verified loader registers actual uploaded Mesh instances.
    // Object keys make reference identity independently testable without Unity.
    internal static class PewRepairProvenance
    {
        private static readonly ConditionalWeakTable<object, PewRepairProof> proofs = new ConditionalWeakTable<object, PewRepairProof>();
        internal static void Register(object mesh, PewRepairProof proof)
        {
            if (mesh == null || proof == null) throw new InvalidDataException("A repaired source requires its exact uploaded object and immutable proof.");
            try { proofs.Add(mesh, proof); }
            catch (ArgumentException error) { throw new InvalidDataException("A repaired source object was already registered.", error); }
        }
        internal static bool TryGet(object mesh, out PewRepairProof proof)
        { proof = null; return mesh != null && proofs.TryGetValue(mesh, out proof); }
    }
    internal static class PewRepairCompositionPolicy
    {
        private static bool Hash(string value) => value != null && value.Length == 64 && value.All(c => c >= '0' && c <= '9' || c >= 'a' && c <= 'f');
        internal static PewRepairProof Create(MeshPatchIdentity source, PinnedMeshRangePatch[] rows, string payloadSha256, int uploadedVertices, int uploadedIndices, bool welded)
        {
            if (source == null || rows == null || rows.Length == 0 || !Hash(payloadSha256) || welded && !source.Collider)
                throw new InvalidDataException("Missing verified source-range presentation identity.");
            var file = new PinnedMeshRangePatchFile { schemaVersion = 1, patches = rows };
            PinnedMeshRangePatchPolicy.Validate(file);
            if (PinnedMeshRangePatchPolicy.Select(file, source).Length != rows.Length)
                throw new InvalidDataException("Repaired source rows differ from their exact original record.");
            int preWeldVertices = checked(source.SourceVertices + rows.Sum(r => r.newVertices.Length));
            int expectedIndices = checked(source.SourceIndices + rows.Sum(r => r.newIndices.Length - r.indexCount));
            if (preWeldVertices > 4000000 || expectedIndices < 3 || expectedIndices > 16000000 || uploadedIndices != expectedIndices || uploadedVertices < 3 || uploadedVertices > preWeldVertices || !welded && uploadedVertices != preWeldVertices)
                throw new InvalidDataException("Uploaded repair counts differ from the verified decode/repair/weld result.");
            return new PewRepairProof(source, rows, payloadSha256, preWeldVertices, uploadedVertices, uploadedIndices, welded);
        }
        internal static void RequireLineage(PewRepairProof proof, MeshPatchIdentity expected, string expectedPayloadSha256, int derivedSourceIndexCount)
        {
            if (proof == null || expected == null || proof.AssetId != expected.AssetId || proof.SourceSha256 != expected.SourceSha256 || proof.ManifestSha256 != expected.ManifestSha256 ||
                proof.MeshFile != expected.MeshFile || proof.MeshSha256 != expected.MeshSha256 || proof.MeshName != expected.MeshName || proof.Collider != expected.Collider ||
                proof.OriginalVertexCount != expected.SourceVertices || proof.OriginalIndexCount != expected.SourceIndices || proof.PayloadSha256 != expectedPayloadSha256 ||
                derivedSourceIndexCount != proof.DerivedSourceIndexCount || expected.AssetId != "R04" && expected.AssetId != "R09" && expected.AssetId != "R09-UD")
                throw new InvalidDataException("Pew repair lineage differs from its exact source owner or sealed payload.");
            var slots = proof.Slots;
            foreach (var slot in slots)
            {
                if (slot.AppendAtEnd)
                {
                    if (slot.FirstIndex != proof.OriginalIndexCount || slot.SourceIndexCount != 0)
                        throw new InvalidDataException("Pew repair derived faces require an explicit exact EOF tail.");
                }
                else if (slot.SourceIndexCount != slot.ReplacementIndexCount)
                    throw new InvalidDataException("Pew repair cannot shift any original source triangle slot.");
            }
            if (proof.DerivedSourceIndexCount != checked(proof.OriginalIndexCount + proof.AppendedTailIndexCount))
                throw new InvalidDataException("Pew repair source stream differs from its individually preserved slots and verified tail.");
        }
        internal static int Require(PewRepairProof proof, MeshPatchIdentity expected, string expectedPayloadSha256, int actualVertices, int actualIndices, int[][] protectedOriginalTriangleSets)
        {
            RequireLineage(proof, expected, expectedPayloadSha256, actualIndices);
            if (actualVertices != proof.DerivedVertexCount || actualIndices != proof.DerivedSourceIndexCount || protectedOriginalTriangleSets == null || protectedOriginalTriangleSets.Length == 0 || protectedOriginalTriangleSets[0] == null || protectedOriginalTriangleSets[0].Length == 0)
                throw new InvalidDataException("Current pew source counts differ from its registered uploaded mesh.");
            var slots = proof.Slots.Where(r => !r.AppendAtEnd).ToArray();
            foreach (var set in protectedOriginalTriangleSets)
            {
                if (set == null || set.Any(t => t < 0 || t >= proof.OriginalIndexCount / 3) || set.Distinct().Count() != set.Length ||
                    slots.Any(r => set.Any(t => t >= r.FirstIndex / 3 && t < (r.FirstIndex + r.SourceIndexCount) / 3)))
                    throw new InvalidDataException("Repaired source ranges intersect or differ from protected original triangle ownership.");
            }
            return proof.DerivedSourceIndexCount;
        }
    }
}
