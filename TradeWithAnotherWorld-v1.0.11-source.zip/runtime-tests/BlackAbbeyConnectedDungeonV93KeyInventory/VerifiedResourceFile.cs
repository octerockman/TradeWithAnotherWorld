using System;
using System.IO;
using System.Security.Cryptography;

namespace BlackAbbeySixRooms
{
    // A resident resource is an immutable verified snapshot. FileShare.Read
    // permits other readers but denies mutation/replacement/deletion while the
    // uploaded object or one of its exact path aliases is leased. No encoded
    // byte array is kept by this owner after Read has returned to the decoder.
    internal sealed class VerifiedResourceFile : IDisposable
    {
        private readonly object gate = new object();
        private readonly string path, expected;
        private readonly long maximum;
        private readonly DiagnosticRoomContext diagnostic;
        private readonly string diagnosticKind;
        private FileStream stream;
        private bool started, verified, disposed;
        internal string Hash { get; private set; }
        internal long BytesRead { get; private set; }
        internal string Path => path;
        internal bool IsVerified { get { lock (gate) return verified && !disposed && stream != null; } }
        internal bool IsDisposed { get { lock (gate) return disposed; } }
        internal VerifiedResourceFile(string path, string expectedHash, long maximumBytes, DiagnosticRoomContext diagnostic = null, string diagnosticKind = "resource")
        {
            if (string.IsNullOrWhiteSpace(path) || !System.IO.Path.IsPathRooted(path) || maximumBytes < 1 || maximumBytes > int.MaxValue)
                throw new ArgumentException("Expected an absolute resource path and a bounded encoded size.");
            if (expectedHash != null && !ValidHash(expectedHash)) throw new ArgumentException("Invalid resource SHA256 identity.");
            this.path = System.IO.Path.GetFullPath(path); expected = expectedHash; maximum = maximumBytes; this.diagnostic=diagnostic;
            this.diagnosticKind=diagnosticKind=="mesh"||diagnosticKind=="collider"||diagnosticKind=="texture"?diagnosticKind:"resource";
        }
        internal byte[] Read()
        {
            using(var scope=AbbeyLoadDiagnostics.Measure(diagnostic,diagnosticKind+".file-open-read-verify","shared-resource-build"))
            return ReadVerified();
        }
        private byte[] ReadVerified()
        {
            FileStream input;
            CinematicEncodedPreparation.PreparedFile prepared = null;
            lock (gate)
            {
                if (disposed) throw new ObjectDisposedException(nameof(VerifiedResourceFile));
                if (started) throw new InvalidOperationException("A verified resource source can only be read once.");
                started = true;
                // Keep this handle until final object/alias release, rather
                // than trusting timestamps or retaining a duplicate byte cache.
                if (CinematicEncodedPreparation.TryTakeCurrent(path, expected, maximum, out prepared))
                {
                    // Adopt the exact file lease opened and verified by the
                    // attempt worker. The original read lock remains held.
                    stream = input = prepared.Input; prepared.Input = null;
                }
                else stream = input = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 65536, FileOptions.SequentialScan);
            }
            try
            {
                long length = input.Length;
                if (length > maximum) throw new InvalidDataException("Encoded resource exceeds its load budget.");
                var bytes = prepared?.Bytes ?? new byte[(int)length];
                if (bytes.LongLength != length) throw new InvalidDataException("Prepared resource differs from its locked encoded length.");
                if (prepared != null) prepared.Bytes = null;
                string hash;
                if (prepared == null)
                {
                using(var readScope=AbbeyLoadDiagnostics.Measure(diagnostic,diagnosticKind+".file-read","shared-resource-build"))
                {
                int offset = 0;
                while (offset < bytes.Length)
                {
                    int count = input.Read(bytes, offset, bytes.Length - offset);
                    if (count == 0) throw new EndOfStreamException("Resource was truncated before its verified read completed.");
                    offset += count;
                }
                if (input.ReadByte() != -1) throw new InvalidDataException("Resource grew beyond its locked read.");
                }
                using(var hashScope=AbbeyLoadDiagnostics.Measure(diagnostic,diagnosticKind+".sha256","shared-resource-build"))
                using (var algorithm = SHA256.Create()) hash = BitConverter.ToString(algorithm.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
                }
                else { hash = prepared.Hash; diagnostic?.Event("cinematic-preparation-adoptions"); }
                if (expected != null && hash != expected) throw new InvalidDataException("Resource differs from its declared hash: " + System.IO.Path.GetFileName(path));
                lock (gate)
                {
                    if (disposed) throw new ObjectDisposedException(nameof(VerifiedResourceFile));
                    Hash = hash; BytesRead = bytes.LongLength; verified = true;
                }
                diagnostic?.Bytes(bytes.LongLength);diagnostic?.Event(diagnosticKind+".verified-encoded-bytes",bytes.LongLength);diagnostic?.Event("verified-file-reads");return bytes;
            }
            catch { Dispose(); throw; }
            finally { prepared?.Dispose(); }
        }
        public void Dispose()
        {
            FileStream close;
            lock (gate)
            {
                if (disposed) return;
                disposed = true; verified = false; close = stream; stream = null;
            }
            // Cancelling an in-flight read may make its managed worker fail;
            // the existing scheduling observer consumes that abandoned fault.
            close?.Dispose();
        }
        private static bool ValidHash(string hash)
        {
            if (hash.Length != 64) return false;
            foreach (char c in hash) if (!(c >= '0' && c <= '9') && !(c >= 'a' && c <= 'f')) return false;
            return true;
        }
    }
}
