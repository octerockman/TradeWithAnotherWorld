using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
namespace BlackAbbeySixRooms
{
    internal static class SourceTriangleComposition
    {
        internal static HashSet<int> MapMask(int[] retainedOriginalTriangles,int originalTriangleCount,int[] requestedOriginalTriangles,int currentTriangleCount)
            =>MapMask(retainedOriginalTriangles,originalTriangleCount,requestedOriginalTriangles,currentTriangleCount,originalTriangleCount);
        internal static HashSet<int> MapMask(int[] retainedOriginalTriangles,int originalTriangleCount,int[] requestedOriginalTriangles,int currentTriangleCount,int derivedSourceTriangleCount)
        {
            if(originalTriangleCount<1||derivedSourceTriangleCount<originalTriangleCount||derivedSourceTriangleCount>16000000/3||retainedOriginalTriangles==null||requestedOriginalTriangles==null||retainedOriginalTriangles.Length!=currentTriangleCount||
                retainedOriginalTriangles.Any(t=>t<0||t>=derivedSourceTriangleCount)||retainedOriginalTriangles.Distinct().Count()!=retainedOriginalTriangles.Length||
                retainedOriginalTriangles.Count(t=>t>=originalTriangleCount)!=derivedSourceTriangleCount-originalTriangleCount||
                requestedOriginalTriangles.Any(t=>t<0||t>=originalTriangleCount)||requestedOriginalTriangles.Distinct().Count()!=requestedOriginalTriangles.Length)
                throw new InvalidDataException("Invalid exact source-triangle composition.");
            var requested=new HashSet<int>(requestedOriginalTriangles);var mapped=new HashSet<int>();
            for(int i=0;i<retainedOriginalTriangles.Length;i++)if(requested.Contains(retainedOriginalTriangles[i]))mapped.Add(i);
            if(mapped.Count!=requested.Count)throw new InvalidDataException("Quest and pew triangle ownership intersects; no source mask was applied.");
            return mapped;
        }
    }
}
