using System;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Deliberately local: vanilla Destructible expects ZNetView/RPC ownership.
    // Native attacks already find this interface above the exact pew colliders.
    public sealed class AbbeyBreakablePew : MonoBehaviour, IDestructible
    {
        private string roomId, pewId;
        private Func<bool> authorized, tryMarkBroken;
        private PewDebrisPart[] fragments;
        private Collider[] colliders;
        private Renderer[] visuals;
        private Action<string> log;
        private bool configured, broken, reportedFailure;

        internal bool Broken => broken;

        internal void Configure(string roomId, string pewId, Func<bool> authorized,
            Func<bool> tryMarkBroken, PewDebrisPart[] fragments, Action<string> log)
        {
            if (configured) throw new InvalidOperationException("A pew owner cannot be rebound to a different run.");
            if (string.IsNullOrWhiteSpace(roomId) || string.IsNullOrWhiteSpace(pewId) ||
                authorized == null || tryMarkBroken == null || !transform.parent)
                throw new ArgumentException("A pew needs its exact room, identity, run ledger and room parent.");
            if (fragments != null && fragments.Length > PewBreakEffects.MaximumPartsPerBreak)
                throw new ArgumentException("A pew exceeds the bounded source-fragment budget.");
            this.roomId = roomId; this.pewId = pewId; this.authorized = authorized;
            this.tryMarkBroken = tryMarkBroken; this.fragments = fragments ?? Array.Empty<PewDebrisPart>();
            this.log = log;
            // Setup places all solid colliders on this same GameObject, so
            // Unity collision messages never rely on implicit parent forwarding.
            colliders = GetComponents<Collider>();
            visuals = GetComponentsInChildren<Renderer>(true);
            if (colliders.Length == 0 || visuals.Length == 0)
                throw new InvalidOperationException("A breakable pew needs its own exact solid and visual pieces.");
            foreach (var collider in colliders)
                if (!collider || collider.isTrigger)
                    throw new InvalidOperationException("A breakable pew requires ordinary solid colliders.");
            configured = true;
            PewBreakEffects.Prepare(log);
        }

        public DestructibleType GetDestructibleType() => DestructibleType.Default;

        public void Damage(HitData hit)
        {
            if (hit == null || !PositiveFiniteDamage(hit.GetTotalDamage())) return;
            // Player and enemy attacks follow this same native hit boundary.
            // No attacker-type filter prevents a monk's strike from breaking it.
            TryBreak(Finite(hit.m_dir) ? hit.m_dir : Vector3.zero, "native-hit");
        }

        internal static bool PositiveFiniteDamage(float value) => value > 0 && !float.IsNaN(value) && !float.IsInfinity(value);

        private void OnCollisionEnter(Collision collision) => TryRoll(collision);
        private void OnCollisionStay(Collision collision) => TryRoll(collision);

        private void TryRoll(Collision collision)
        {
            if (broken || !configured || collision == null || collision.contactCount == 0 || !collision.collider) return;
            var player = collision.collider.GetComponentInParent<Player>();
            if (!player || player != Player.m_localPlayer || player.IsDead() || !player.InDodge()) return;
            TryBreak(player.transform.forward, "player-roll");
        }

        private void TryBreak(Vector3 direction, string cause)
        {
            if (!configured || broken || !isActiveAndEnabled || !gameObject.activeInHierarchy) return;
            try
            {
                if (!authorized() || !tryMarkBroken()) return;
            }
            catch (Exception ex)
            {
                if (!reportedFailure)
                {
                    reportedFailure = true;
                    log?.Invoke("ABBEY_PEW_SCOPE_REJECTED: room=" + roomId + "; pew=" + pewId + "; " + ex.GetType().Name + ": " + ex.Message);
                }
                return;
            }

            broken = true;
            var room = transform.parent;
            Vector3 origin = transform.position;
            bool hasBounds = false;
            Bounds bounds = default;
            foreach (var visual in visuals)
            {
                if (!visual) continue;
                if (!hasBounds) { bounds = visual.bounds; hasBounds = true; }
                else bounds.Encapsulate(visual.bounds);
            }
            if (hasBounds) origin = bounds.center;
            // All pew renderers contribute the base datum, even when the six
            // cosmetic fragments happen to contain no leg/base source part.
            float floorBaseY = hasBounds
                ? room.InverseTransformPoint(new Vector3(origin.x, bounds.min.y, origin.z)).y
                : float.NaN;
            // Disable only this pew's original surfaces before cosmetic work.
            foreach (var collider in colliders) if (collider) collider.enabled = false;
            foreach (var visual in visuals) if (visual) visual.enabled = false;

            try { PewBreakEffects.Emit(transform, origin, direction, fragments, log, floorBaseY); }
            catch (Exception ex)
            {
                log?.Invoke("ABBEY_PEW_EFFECT_OMITTED: room=" + roomId + "; pew=" + pewId + "; " + ex.GetType().Name + ": " + ex.Message);
            }
            log?.Invoke("ABBEY_PEW_BROKEN: room=" + roomId + "; pew=" + pewId + "; cause=" + cause + "; run-ledger=true; loot=0.");
            gameObject.SetActive(false);
        }

        private static bool Finite(Vector3 value) => Finite(value.x) && Finite(value.y) && Finite(value.z);
        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
    }
}
