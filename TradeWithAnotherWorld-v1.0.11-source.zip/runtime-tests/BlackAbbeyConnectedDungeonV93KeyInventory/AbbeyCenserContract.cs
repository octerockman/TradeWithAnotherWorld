using System;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
#pragma warning disable 0649
    internal sealed class AbbeyCenserRecord
    {
        public string id,cookie,cookieSha256;
        public float[] position,wallDirection,floorPosition;
        public float floorY,glowIntensity,glowRange,wallIntensity,wallRange,wallSpotAngle;
        public AbbeyCenserSmokeRecord smoke;
    }
    internal sealed class AbbeyCenserSmokeRecord
    {
        public bool enabled;
        public int maxParticles,floorMaxParticles;
        public float rate,lifetime,bodyRadius,startSize,downSpeed,floorRate,floorLifetime,floorRadius;
    }
#pragma warning restore 0649
    internal static class AbbeyCenserContract
    {
        static bool F(float x) => !float.IsNaN(x) && !float.IsInfinity(x);
        static bool Range(float x,float low,float high) => F(x) && x>=low && x<=high;
        static bool Vector(float[] v) => v!=null && v.Length==3 && v.All(F);
        internal static void Validate(AbbeyCenserRecord[] records)
        {
            if(records==null) return;
            if(records.Length>16 || records.Any(r=>r==null || string.IsNullOrWhiteSpace(r.id) || r.id.Length>128 || r.id.Any(char.IsControl)) ||
                records.Select(r=>r.id).Distinct(StringComparer.Ordinal).Count()!=records.Length) throw new InvalidDataException("Censers require at most sixteen distinct room-owned fixtures.");
            foreach(var r in records)
            {
                if(!Vector(r.position) || !Range(r.position[0],-14,14) || !Range(r.position[1],.5f,15.5f) || !Range(r.position[2],0,32.6f) ||
                    !Vector(r.wallDirection) || Math.Abs(r.wallDirection[1])>.001f || Math.Abs(r.wallDirection.Sum(x=>x*x)-1)>.005f ||
                    !Range(r.floorY,-.5f,r.position[1]-.25f) || !Range(r.glowIntensity,.01f,1) || !Range(r.glowRange,.2f,1.5f) ||
                    !Range(r.wallIntensity,.01f,2) || !Range(r.wallRange,1,3.5f) || !Range(r.wallSpotAngle,20,95) ||
                    string.IsNullOrWhiteSpace(r.cookie) || Path.IsPathRooted(r.cookie) || r.cookie.Contains('\\') || r.cookie.Contains(':') ||
                    r.cookie.Split('/').Any(p=>p==".." || p=="." || p.Length==0) || !CatalogReader.Hash(r.cookieSha256))
                    throw new InvalidDataException("Invalid bounded/source-bound censer light, floor or cookie: "+r.id);
                if(r.floorPosition!=null && (!Vector(r.floorPosition) || !Range(r.floorPosition[0],-14,14) || !Range(r.floorPosition[2],0,32.6f) ||
                    !Range(r.floorPosition[1],r.floorY+.06f,r.floorY+.3f) ||
                    Math.Pow(r.floorPosition[0]-r.position[0],2)+Math.Pow(r.floorPosition[2]-r.position[2],2)>4))
                    throw new InvalidDataException("Censer floor anchor must remain near the source and above its actual floor: "+r.id);
                var s=r.smoke;
                if(s==null) throw new InvalidDataException("Censer smoke policy must be explicit: "+r.id);
                if(!s.enabled) continue;
                if(!Range(s.rate,1,24) || s.maxParticles<16 || s.maxParticles>160 || !Range(s.lifetime,2,12) ||
                    !Range(s.bodyRadius,.05f,.6f) || !Range(s.startSize,.15f,1) || !Range(s.downSpeed,.15f,1) ||
                    !Range(s.floorRate,1,12) || s.floorMaxParticles<8 || s.floorMaxParticles>80 || !Range(s.floorLifetime,2,12) || !Range(s.floorRadius,.3f,2) ||
                    s.lifetime*s.downSpeed+s.bodyRadius<r.position[1]-r.floorY)
                    throw new InvalidDataException("Censer smoke must remain bounded and reach its declared floor: "+r.id);
            }
            if(MaximumParticles(records)>3840) throw new InvalidDataException("Room censer smoke exceeds its finite maximum-particle budget.");
        }
        internal static int MaximumParticles(AbbeyCenserRecord[] records) => (records??Array.Empty<AbbeyCenserRecord>()).Where(r=>r.smoke?.enabled==true).Sum(r=>r.smoke.maxParticles+r.smoke.floorMaxParticles);
        internal static bool BodyParticleExpired(float roomY,float floorY) => roomY < floorY+.08f;
        internal static float FloorParticleY(float roomY,float floorY) => Math.Max(floorY+.06f,Math.Min(floorY+.3f,roomY));
    }
}
