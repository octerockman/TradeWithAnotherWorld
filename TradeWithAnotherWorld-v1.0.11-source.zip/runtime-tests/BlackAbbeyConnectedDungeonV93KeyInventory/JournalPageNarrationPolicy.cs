using System;
using System.Collections.Generic;
using System.IO;

namespace BlackAbbeySixRooms
{
    internal static class JournalPageNarrationSource
    {
        // Exact frozen fourteen-page narration export identity.
        internal const string ManifestSha256="ff49b231a71ac0ce1c1ee12eba64ee992495e0bcf5cbe6eba67ebd5392c76112";
    }
    internal sealed class JournalPageNarrationPage
    {
        internal readonly string PageId,File,Sha256;
        internal readonly long Bytes;
        internal readonly double DurationSeconds;
        internal JournalPageNarrationPage(string pageId,string file,string sha256,long bytes,double duration)
        {PageId=pageId;File=file;Sha256=sha256;Bytes=bytes;DurationSeconds=duration;}
    }
    internal static class JournalPageNarrationContract
    {
        internal const int PageCount=14,MaximumCachedPages=2;
        internal const long MaximumManifestBytes=65536,MaximumPageBytes=16000000;
        internal const double MaximumDurationSeconds=600;
        static readonly HashSet<string> voiced=new HashSet<string>(StringComparer.Ordinal){
            "02-oswin-final-01","02-oswin-final-02","02-oswin-final-03",
            "03-oswin-older-01","03-oswin-older-02","03-oswin-older-03","03-oswin-older-04","03-oswin-older-05",
            "03-oswin-older-06","03-oswin-older-07","03-oswin-older-08","03-oswin-older-09",
            "05-matthien-note","06-edrin-folded-pages"};
        internal static bool IsVoiced(string id)=>id!=null&&voiced.Contains(id);
        internal static bool IsHash(string hash)
        {
            if(hash==null||hash.Length!=64)return false;
            foreach(char c in hash)if(!(c>='0'&&c<='9')&&!(c>='a'&&c<='f'))return false;
            return true;
        }
        internal static void Validate(int schemaVersion,JournalPageNarrationPage[] pages)
        {
            if(schemaVersion!=1||pages==null||pages.Length!=PageCount)throw new InvalidDataException("Expected fourteen approved journal narration pages.");
            var seen=new HashSet<string>(StringComparer.Ordinal);
            foreach(var page in pages)
                if(page==null||!IsVoiced(page.PageId)||!seen.Add(page.PageId)||page.File!=page.PageId+".ogg"||
                    !IsHash(page.Sha256)||page.Bytes<44||page.Bytes>MaximumPageBytes||double.IsNaN(page.DurationSeconds)||
                    double.IsInfinity(page.DurationSeconds)||page.DurationSeconds<=0||page.DurationSeconds>MaximumDurationSeconds)
                    throw new InvalidDataException("Journal narration page identity, path or budget differs.");
        }
    }
    // A closed or replaced page cannot acquire audio, even if a worker/native
    // request completes later. Only page changes affect this policy; R/scroll do not.
    internal sealed class JournalPageNarrationPolicy
    {
        long revision;
        string pageId;
        internal long Begin(string id){revision=unchecked(revision+1);pageId=JournalPageNarrationContract.IsVoiced(id)?id:null;return revision;}
        internal void Stop(){revision=unchecked(revision+1);pageId=null;}
        internal bool MayPlay(long ticket,string id,bool readerOpen)=>readerOpen&&pageId!=null&&ticket==revision&&string.Equals(pageId,id,StringComparison.Ordinal);
    }
}
