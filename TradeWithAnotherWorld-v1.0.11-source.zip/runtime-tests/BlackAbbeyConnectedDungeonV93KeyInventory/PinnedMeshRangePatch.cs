using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlackAbbeySixRooms
{
#pragma warning disable 0649
    internal sealed class PinnedMeshRangePatchFile { public int schemaVersion; public PinnedMeshRangePatch[] patches; }
    internal sealed class PinnedMeshRangePatch
    {
        public string assetId, sourceSha256, manifestSha256, meshFile, meshSha256, meshName, witnessSha256;
        public bool collider, appendAtEnd;
        public int sourceVertices, sourceIndices, firstIndex, indexCount;
        public float[][] newVertices;
        public int[] newIndices;
    }
#pragma warning restore 0649
    internal sealed class MeshPatchIdentity
    {
        internal string AssetId, SourceSha256, ManifestSha256, MeshFile, MeshSha256, MeshName;
        internal bool Collider;
        internal int SourceVertices, SourceIndices;
    }
    internal sealed class MeshRangePatchResult
    {
        internal float[][] AddedVertices;
        internal int[] Indices;
        internal int AppliedRanges, TriangleDelta;
    }
    // Pure managed source-range admission and index splicing. The caller owns
    // channel upload and must append AddedVertices without changing source rows.
    internal static class PinnedMeshRangePatchPolicy
    {
        // V82 retains the V80 ranges and adds the source-witnessed internal
        // shrine cut profile and banner UV restoration (209 total before
        // the entrance-floor additions). Keep a fixed bounded allowance.
        internal const int MaximumRanges = 256;
        internal const string EmptyWitnessSha256="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
        private static bool Hash(string value)=>value!=null&&value.Length==64&&value.All(c=>c>='0'&&c<='9'||c>='a'&&c<='f');
        private static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
        private static bool Name(string value)=>!string.IsNullOrWhiteSpace(value)&&value.Length<=1024&&!value.Any(char.IsControl);
        private static bool SameSource(PinnedMeshRangePatch p,MeshPatchIdentity i)=>p.assetId==i.AssetId&&p.sourceSha256==i.SourceSha256&&p.manifestSha256==i.ManifestSha256;
        private static bool SameMesh(PinnedMeshRangePatch p,MeshPatchIdentity i)=>SameSource(p,i)&&p.collider==i.Collider&&p.meshFile==i.MeshFile&&
            p.meshSha256==i.MeshSha256&&p.meshName==i.MeshName&&p.sourceVertices==i.SourceVertices&&p.sourceIndices==i.SourceIndices;
        internal static PinnedMeshRangePatchFile Parse(string json)
        {
            if(json==null||json.Length>32*1024*1024)throw new InvalidDataException("Pinned mesh-range JSON is absent or oversized.");
            try
            {
            using(var text=new StringReader(json??""))using(var reader=new JsonTextReader(text){MaxDepth=32,DateParseHandling=DateParseHandling.None})
            {
                var token=JObject.Load(reader,new JsonLoadSettings{DuplicatePropertyNameHandling=DuplicatePropertyNameHandling.Error});
                if(reader.Read()||!(token["patches"] is JArray patches)||patches.Any(row=>!CanonicalAppendFlag(row)))
                    throw new InvalidDataException("Pinned append mode must be an explicit JSON boolean, with no trailing payload.");
                var file=token.ToObject<PinnedMeshRangePatchFile>(JsonSerializer.Create(new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MetadataPropertyHandling=MetadataPropertyHandling.Ignore,MaxDepth=32}));
                Validate(file);return file;
            }
            }
            catch(JsonException error){throw new InvalidDataException("Invalid pinned mesh-range JSON.",error);}
        }
        private static bool CanonicalAppendFlag(JToken value)
        {
            if(!(value is JObject row))return false;
            var flags=row.Properties().Where(p=>string.Equals(p.Name,"appendAtEnd",StringComparison.OrdinalIgnoreCase)).ToArray();
            return flags.Length==0||flags.Length==1&&flags[0].Name=="appendAtEnd"&&flags[0].Value.Type==JTokenType.Boolean;
        }
        internal static void Validate(PinnedMeshRangePatchFile file)
        {
            if(file?.schemaVersion!=1||file.patches==null||file.patches.Length<1||file.patches.Length>MaximumRanges)
                throw new InvalidDataException("Invalid pinned mesh-range payload.");
            foreach(var p in file.patches)
            {
                if(p==null||!Name(p.assetId)||!Name(p.meshFile)||!Name(p.meshName)||!Hash(p.sourceSha256)||!Hash(p.manifestSha256)||!Hash(p.meshSha256)||!Hash(p.witnessSha256)||
                    p.sourceVertices<3||p.sourceVertices>2000000||p.sourceIndices<3||p.sourceIndices>12000000||p.sourceIndices%3!=0||
                    p.firstIndex<0||p.firstIndex%3!=0||p.indexCount<0||p.indexCount%3!=0||(long)p.firstIndex+p.indexCount>p.sourceIndices||
                    p.newVertices==null||p.newVertices.Length>500000||p.newIndices==null||p.newIndices.Length>3000000||p.newIndices.Length%3!=0||
                    p.newIndices.Length>0&&p.newVertices.Length<3)
                    throw new InvalidDataException("Pinned mesh-range identity, range or replacement counts differ.");
                if(p.appendAtEnd?(p.firstIndex!=p.sourceIndices||p.indexCount!=0||p.witnessSha256!=EmptyWitnessSha256||p.newIndices.Length<3||p.newVertices.Length<3):p.indexCount<3)
                    throw new InvalidDataException("Pinned append mode requires the exact original EOF and nonempty derived geometry; ordinary ranges stay nonempty.");
                foreach(var v in p.newVertices)
                    if(v==null||v.Length!=12||v.Any(n=>!Finite(n))||(double)v[0]*v[0]+(double)v[1]*v[1]+(double)v[2]*v[2]>40000||
                        !p.collider&&(double)v[3]*v[3]+(double)v[4]*v[4]+(double)v[5]*v[5]<.01)
                        throw new InvalidDataException("Invalid pinned replacement vertex channels.");
                if(p.newIndices.Any(index=>(uint)index>=(uint)p.newVertices.Length))
                    throw new InvalidDataException("Pinned replacement index exceeds its new vertex rows.");
            }
            foreach(var group in file.patches.GroupBy(p=>p.assetId+"|"+p.collider+"|"+p.meshFile))
            {
                var rows=group.OrderBy(p=>p.firstIndex).ToArray();var first=rows[0];long end=0;bool appended=false;
                foreach(var p in rows)
                {
                    if(p.sourceSha256!=first.sourceSha256||p.manifestSha256!=first.manifestSha256||p.meshSha256!=first.meshSha256||p.meshName!=first.meshName||
                        p.sourceVertices!=first.sourceVertices||p.sourceIndices!=first.sourceIndices||p.firstIndex<end||appended)
                        throw new InvalidDataException("Pinned ranges overlap or disagree about their exact source.");
                    end=(long)p.firstIndex+p.indexCount;
                    appended=p.appendAtEnd;
                }
            }
        }
        internal static PinnedMeshRangePatch[] Select(PinnedMeshRangePatchFile file,MeshPatchIdentity identity)
        {
            if(identity==null)throw new ArgumentNullException(nameof(identity));
            if(file?.patches==null)throw new InvalidDataException("Pinned mesh-range payload is absent.");
            var owned=file.patches.Where(p=>p.assetId==identity.AssetId).ToArray();
            if(owned.Length==0)return Array.Empty<PinnedMeshRangePatch>();
            if(!owned.Any(p=>SameSource(p,identity)))throw new InvalidDataException("Pinned mesh repair refuses changed room source/manifest identity.");
            var rows=owned.Where(p=>p.collider==identity.Collider&&p.meshFile==identity.MeshFile).OrderBy(p=>p.firstIndex).ToArray();
            if(rows.Length==0)
            {
                if(owned.Any(p=>p.collider==identity.Collider&&p.meshSha256==identity.MeshSha256))throw new InvalidDataException("Pinned target mesh path changed.");
                return rows;
            }
            if(rows.Any(p=>!SameMesh(p,identity)))throw new InvalidDataException("Pinned target mesh differs from its exact original record.");
            return rows;
        }
        // Witness: selected original Int32 indices first; then the float32 XYZ
        // of every selected corner, all little endian and in original order.
        internal static string Witness(int[] indices,int firstIndex,int indexCount,Func<int,int,float> coordinate)
        {
            if(indices==null||coordinate==null||firstIndex<0||indexCount<0||indexCount==0&&firstIndex!=indices.Length||firstIndex%3!=0||indexCount%3!=0||(long)firstIndex+indexCount>indices.Length)
                throw new InvalidDataException("Invalid original triangle witness range.");
            using(var stream=new MemoryStream())using(var writer=new BinaryWriter(stream,System.Text.Encoding.UTF8,true))
            {
                for(int at=firstIndex;at<firstIndex+indexCount;at++)writer.Write(indices[at]);
                for(int at=firstIndex;at<firstIndex+indexCount;at++)for(int channel=0;channel<3;channel++)
                {float value=coordinate(indices[at],channel);if(!Finite(value))throw new InvalidDataException("Nonfinite original triangle witness.");writer.Write(value);}
                writer.Flush();using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(stream.ToArray())).Replace("-","").ToLowerInvariant();
            }
        }
        internal static MeshRangePatchResult Apply(PinnedMeshRangePatchFile file,MeshPatchIdentity identity,int[] sourceIndices,Func<int,int,float> coordinate)
        {
            Validate(file);var rows=Select(file,identity);if(rows.Length==0)return null;
            if(sourceIndices==null||sourceIndices.Length!=identity.SourceIndices||sourceIndices.Any(index=>(uint)index>=(uint)identity.SourceVertices)||coordinate==null)
                throw new InvalidDataException("Original pinned mesh buffer differs from its source record.");
            long addedVertices=0,indexLength=sourceIndices.Length;int triangleDelta=0;
            foreach(var p in rows)
            {
                if(Witness(sourceIndices,p.firstIndex,p.indexCount,coordinate)!=p.witnessSha256)
                    throw new InvalidDataException("Original selected triangles differ from their pinned witness.");
                addedVertices+=p.newVertices.Length;indexLength+=(long)p.newIndices.Length-p.indexCount;
                triangleDelta=checked(triangleDelta+(p.newIndices.Length-p.indexCount)/3);
            }
            if((long)identity.SourceVertices+addedVertices>4000000||indexLength<3||indexLength>16000000)
                throw new InvalidDataException("Pinned replacement exceeds derived mesh budget.");
            var indices=new int[(int)indexLength];var vertices=new float[(int)addedVertices][];
            int read=0,write=0,vertexAt=0;
            foreach(var p in rows)
            {
                int preserved=p.firstIndex-read;Array.Copy(sourceIndices,read,indices,write,preserved);write+=preserved;
                foreach(int index in p.newIndices)indices[write++]=checked(identity.SourceVertices+vertexAt+index);
                foreach(var vertex in p.newVertices)vertices[vertexAt++]=(float[])vertex.Clone();
                read=p.firstIndex+p.indexCount;
            }
            Array.Copy(sourceIndices,read,indices,write,sourceIndices.Length-read);
            return new MeshRangePatchResult{AddedVertices=vertices,Indices=indices,AppliedRanges=rows.Length,TriangleDelta=triangleDelta};
        }
        internal static int VisualTriangleDelta(PinnedMeshRangePatchFile file,string assetId,string sourceSha256,string manifestSha256)
        {
            var rows=file.patches.Where(p=>p.assetId==assetId&&!p.collider).ToArray();
            if(rows.Length==0)return 0;
            if(rows.Any(p=>p.sourceSha256!=sourceSha256||p.manifestSha256!=manifestSha256))throw new InvalidDataException("Pinned visual delta refuses changed source.");
            int delta=0;foreach(var p in rows)delta=checked(delta+(p.newIndices.Length-p.indexCount)/3);return delta;
        }
    }
}
