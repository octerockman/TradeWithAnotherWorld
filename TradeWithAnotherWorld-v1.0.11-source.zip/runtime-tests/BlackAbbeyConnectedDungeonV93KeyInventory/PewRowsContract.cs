using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace BlackAbbeySixRooms
{
#pragma warning disable 0649
    internal sealed class PewRowsManifest
    {
        public int schemaVersion;
        public string roomId, sourceRoomSha256, sourceRoomManifestSha256, sourcePewId;
        public PewRowInstance[] instances;
    }
    internal sealed class PewRowInstance
    {
        public string id;
        public float[] position, scale;
        public float yawDegrees;
    }
#pragma warning restore 0649

    // An additive placement plan, never a replacement of the sealed room bank.
    // Coordinates act on the original room-space source mesh, not a new pivot.
    internal static class PewRowsContract
    {
        internal const string RelativePath = "breakable-pews/r09-nave-rows.json";
        internal const string ManifestSha256 = "9308a0464bb04f3cf3c58c5fd7810e1364618e42797d363ccf8969c37d0c4903";
        internal static PewRowsManifest Read(string dataRoot, PackageManifest room, string roomManifestHash, PewRoomRecord ownership)
        {
            string path = Path.GetFullPath(Path.Combine(dataRoot, RelativePath));
            if (!File.Exists(path) || new FileInfo(path).Length > 64 * 1024 || CatalogReader.HashFile(path) != ManifestSha256)
                throw new InvalidDataException("Missing or changed R09 nave pew placement plan.");
            return Validate(JsonConvert.DeserializeObject<PewRowsManifest>(File.ReadAllText(path)), room, roomManifestHash, ownership);
        }
        internal static PewRowsManifest Validate(PewRowsManifest data, PackageManifest room, string roomManifestHash, PewRoomRecord ownership)
        {
            if (data == null || data.schemaVersion != 1 || room == null || room.roomId != "R09" || data.roomId != room.roomId ||
                data.sourceRoomSha256 != UnrecordedDeadSourceBindings.Canonical(room.roomId,room.sourceSha256) || data.sourceRoomManifestSha256 != UnrecordedDeadSourceBindings.CanonicalManifest(roomManifestHash) ||
                ownership == null || ownership.roomId != room.roomId || ownership.sourceSha256 != UnrecordedDeadSourceBindings.Canonical(room.roomId,room.sourceSha256) ||
                ownership.manifestSha256 != UnrecordedDeadSourceBindings.CanonicalManifest(roomManifestHash) || ownership.pews == null || ownership.pews.Any(p => p == null) || data.sourcePewId != "pew-east-0" ||
                data.instances == null || data.instances.Length != 16 || data.instances.Any(p => p == null))
                throw new InvalidDataException("R09 nave placements do not match the loaded canonical source.");
            var source = ownership.pews.SingleOrDefault(p => p.id == data.sourcePewId);
            if (source == null || !Triple(source.boundsMin) || !Triple(source.boundsMax) ||
                Enumerable.Range(0, 3).Any(i => source.boundsMax[i] <= source.boundsMin[i]))
                throw new InvalidDataException("R09 nave placements lack their exact source pew template.");
            var ids = new HashSet<string>(ownership.pews.Select(p => p.id), StringComparer.Ordinal);
            var envelopes = new List<float[][]>();
            foreach (var row in data.instances)
            {
                if (!ExpectedId(row.id) || !ids.Add(row.id) || !Triple(row.position) || !Triple(row.scale) ||
                    row.position.Any(v => Math.Abs(v) > 100) || row.scale.Any(v => v < .25f || v > 3) ||
                    row.yawDegrees != 90)
                    throw new InvalidDataException("Invalid R09 nave identity, pose or forward orientation.");
                var envelope = TransformBounds(row, source.boundsMin, source.boundsMax);
                var min = envelope[0]; var max = envelope[1];
                // Keep the central through-aisle, side circulation and bell dais
                // approach clear. Exact floor contact is measured in the native.
                if (min[0] < -9 || max[0] > 9 || min[2] < 3 || max[2] > 24 || min[1] < -.25f || max[1] > 3 ||
                    !(max[0] <= -2 || min[0] >= 2) ||
                    row.id.StartsWith("nave-west-", StringComparison.Ordinal) != (max[0] < 0))
                    throw new InvalidDataException("R09 nave placement obstructs reserved circulation or leaves the main floor.");
                foreach (var prior in envelopes)
                    if (min[0] < prior[1][0] && max[0] > prior[0][0] && min[2] < prior[1][2] && max[2] > prior[0][2])
                        throw new InvalidDataException("R09 nave pew placements overlap.");
                envelopes.Add(envelope);
            }
            return data;
        }
        internal static float[] TransformPoint(PewRowInstance row, float[] point)
        {
            if (row == null || !Triple(row.position) || !Triple(row.scale) || !Triple(point) ||
                row.yawDegrees != 0 && row.yawDegrees != 90 && row.yawDegrees != 180 && row.yawDegrees != 270)
                throw new InvalidDataException("A pew pose requires finite source coordinates and cardinal yaw.");
            float x = point[0] * row.scale[0], y = point[1] * row.scale[1], z = point[2] * row.scale[2];
            float rx = x, rz = z;
            if (row.yawDegrees == 90) { rx = z; rz = -x; }
            else if (row.yawDegrees == 180) { rx = -x; rz = -z; }
            else if (row.yawDegrees == 270) { rx = -z; rz = x; }
            return new[] { rx + row.position[0], y + row.position[1], rz + row.position[2] };
        }
        internal static float[][] TransformBounds(PewRowInstance row, float[] min, float[] max)
        {
            var low = new[] { float.PositiveInfinity, float.PositiveInfinity, float.PositiveInfinity };
            var high = new[] { float.NegativeInfinity, float.NegativeInfinity, float.NegativeInfinity };
            for (int corner = 0; corner < 8; corner++)
            {
                var p = TransformPoint(row, new[] { (corner & 1) == 0 ? min[0] : max[0], (corner & 2) == 0 ? min[1] : max[1], (corner & 4) == 0 ? min[2] : max[2] });
                for (int axis = 0; axis < 3; axis++) { low[axis] = Math.Min(low[axis], p[axis]); high[axis] = Math.Max(high[axis], p[axis]); }
            }
            return new[] { low, high };
        }
        private static bool ExpectedId(string id)
        {
            for (int i = 1; i <= 8; i++) if (id == "nave-west-" + i.ToString("00") || id == "nave-east-" + i.ToString("00")) return true;
            return false;
        }
        private static bool Triple(float[] value) => value != null && value.Length == 3 && value.All(v => !float.IsNaN(v) && !float.IsInfinity(v));
    }
}
