using System;
using BepInEx.Bootstrap;
using Jotunn.Utils;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // These names belong to our modules. A missing custom registration must
    // never enter Jotunn's vanilla soft-asset fallback (which can throw/log).
    internal static class AbbeyEnemyPrefabLookup
    {
        internal static bool TryGetReady(string name, out GameObject prefab, out string reason)
        {
            prefab = null;
            if (name == AbbeyMonkSpawnPolicy.Monk)
                return AbbeyMonkDependency.TryGetReady(out prefab, out reason);
            string provider; System.Version minimum;
            switch (name)
            {
                case AbbeyMonkSpawnPolicy.Guard: provider="studio.otherworld.reliquaryguardtest"; minimum=new System.Version(0,4,0); break;
                case AbbeyMonkSpawnPolicy.Censer: provider="studio.otherworld.censerbrother"; minimum=new System.Version(0,3,3); break;
                case AbbeyMonkSpawnPolicy.Thrall: provider="studio.otherworld.bellthralltest"; minimum=new System.Version(0,2,1); break;
                case UnrecordedDeadKnightPolicy.Prefab: provider=UnrecordedDeadKnightPolicy.Provider; minimum=new System.Version(0,1,3); break;
                default: reason="Unknown Abbey enemy; no fallback or substitute permitted."; return false;
            }
            if (!Chainloader.PluginInfos.TryGetValue(provider,out var plugin) || plugin?.Instance == null || plugin.Metadata.Version < minimum)
            { reason="Required enemy module is missing or older than "+minimum+": "+provider; return false; }
            var registered = ModQuery.GetPrefab(name);
            var own = registered?.Prefab;
            if (!own || registered.SourceMod?.GUID != provider || own.name != name ||
                !own.GetComponent<Character>() || !own.GetComponent<ZNetView>() ||
                own.GetComponentsInChildren<SkinnedMeshRenderer>(true).Length == 0)
            { reason="Own enemy registration is not ready: "+name+"; saved encounter remains pending."; return false; }
            prefab=own; reason="Own enemy registration ready: "+name; return true;
        }
    }
}
