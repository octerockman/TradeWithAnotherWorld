namespace BlackAbbeySixRooms
{
    internal static class BossConnectionExtensionPolicy
    {
        internal const int MaximumRooms=ThirdLoopExtensionPolicy.MaximumRooms,MaximumApproachRooms=6;
        internal const int PlacementBudget=12000,PerAnchorBudget=3000;
        internal const string Reason="preferred far anchor direct fit failed; necessary terminal approach route";
        internal static bool IsExtraId(string id)=>id!=null&&id.IndexOf("_boss_extra_",System.StringComparison.Ordinal)>=0;
        internal static bool Eligible(int normalTarget,int inventory,int bossCount,int missingNormalRooms,int thirdExtras,int placedRooms,int knightExtras=0)=>
            normalTarget>=NaturalDungeonRoster.MinimumRooms&&normalTarget<=NaturalDungeonRoster.MaximumRooms&&inventory==normalTarget&&
            bossCount==0&&missingNormalRooms==0&&thirdExtras>=0&&thirdExtras<=ThirdLoopExtensionPolicy.MaximumRouteExtras&&
            knightExtras>=0&&knightExtras<=R08KnightReturnPolicy.MaximumExtraRooms&&placedRooms==normalTarget-1+thirdExtras+knightExtras&&normalTarget+thirdExtras+knightExtras<=MaximumRooms;
        internal static bool Accepts(int normalTarget,int thirdExtras,int bossExtras,int knightExtras=0)=>normalTarget>=NaturalDungeonRoster.MinimumRooms&&normalTarget<=NaturalDungeonRoster.MaximumRooms&&
            thirdExtras>=0&&thirdExtras<=ThirdLoopExtensionPolicy.MaximumRouteExtras&&bossExtras>0&&bossExtras<=MaximumApproachRooms&&knightExtras>=0&&knightExtras<=R08KnightReturnPolicy.MaximumExtraRooms&&normalTarget+thirdExtras+knightExtras+bossExtras<=MaximumRooms;
    }
}
