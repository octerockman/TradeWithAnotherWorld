using System.IO;

namespace BlackAbbeySixRooms
{
    internal static class RuntimeRoomBounds
    {
        private static void Validate(float[] values, string label)
        {
            if (values == null || values.Length != 3)
                throw new InvalidDataException(label + " must contain three finite values.");
            for (int i = 0; i < values.Length; i++)
                if (float.IsNaN(values[i]) || float.IsInfinity(values[i]))
                    throw new InvalidDataException(label + " must contain three finite values.");
        }
        internal static bool Contains(float[] low, float[] high, float x, float y, float z)
        {
            // Retain current-array validation and the existing recovery margin,
            // without LINQ enumerators or a cached world/transform/bounds value.
            Validate(low, "boundsMin"); Validate(high, "boundsMax");
            return x >= low[0] - 2f && x <= high[0] + 2f &&
                z >= low[2] - 2f && z <= high[2] + 2f &&
                y >= low[1] - 4.5f && y <= high[1] + 5f;
        }
    }
}
