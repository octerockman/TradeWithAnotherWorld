using System;

namespace BlackAbbeySixRooms
{
    // Preserve the accepted total span while undoing row-scale inflation of
    // the end cheeks/posts/straps. Only the middle joinery gains extra length.
    internal static class PewRefinementPolicy
    {
        internal const float ProtectedEndBand = .38f;
        internal static float Coordinate(float value, float min, float max, float lengthScale)
        {
            if (float.IsNaN(value) || float.IsInfinity(value) || !(max > min) || lengthScale < 1 || lengthScale > 3)
                throw new ArgumentException("Invalid source-bound pew length mapping.");
            float band = Math.Min(ProtectedEndBand, (max-min)*.2f);
            if (value <= min+band) return min+(value-min)/lengthScale;
            if (value >= max-band) return max-(max-value)/lengthScale;
            float t=(value-min-band)/(max-min-2*band);
            return min+band/lengthScale+t*(max-min-2*band/lengthScale);
        }
        internal static float Lifetime(int index) => index % 3 == 0 ? 20f : index % 3 == 1 ? 12f : 8f;
        internal static float Derivative(float value,float min,float max,float lengthScale)
        {
            float band=Math.Min(ProtectedEndBand,(max-min)*.2f);
            return value<=min+band||value>=max-band?1/lengthScale:(max-min-2*band/lengthScale)/(max-min-2*band);
        }
    }
}
