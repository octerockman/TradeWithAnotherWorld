using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace BlackAbbeySixRooms
{
    // Same loaded-Standard route already used successfully by RoomPackage.
    // A supported shader may exist on an asset even when Shader.Find is stripped.
    internal static class WardingSpawnerMaterial
    {
        internal static Shader Resolve(Func<string,GameObject> prefab,Func<string,Shader> find,out string source)
        {
            foreach(string name in new[]{"Pickable_Dandelion","stone_floor_2x2","piece_chest_wood"}){
                var go=prefab(name);if(!go)continue;
                var loaded=go.GetComponentsInChildren<Renderer>(true).SelectMany(r=>r.sharedMaterials).FirstOrDefault(m=>m&&m.shader&&m.shader.name=="Standard"&&m.shader.isSupported&&m.HasProperty("_MainTex")&&m.HasProperty("_BumpMap")&&m.HasProperty("_MetallicGlossMap")&&m.HasProperty("_Glossiness"));
                if(loaded){source="loaded "+name+" Standard shader; fresh opaque material";return loaded.shader;}
            }
            var direct=find("Standard");
            if(direct&&direct.isSupported&&direct.name=="Standard"){source="Shader.Find Standard";return direct;}
            throw new InvalidOperationException("Supported spawner Standard shader is unavailable, including loaded native-prefab fallback.");
        }
        internal static Material Create(string kind,Dictionary<string,Texture2D> maps,Func<string,GameObject> prefab,Func<string,Shader> find)
        {
            var shader=Resolve(prefab,find,out var source);var material=new Material(shader){name="BA spawner baked "+kind,enableInstancing=true};
            material.SetOverrideTag("BA_ShaderSource",source);material.SetOverrideTag("RenderType","Opaque");
            material.SetTexture("_MainTex",maps["albedo"]);material.SetTexture("_BumpMap",maps["normal"]);material.SetTexture("_MetallicGlossMap",maps["metallic-smoothness"]);
            material.SetColor("_Color",Color.white);material.SetFloat("_Glossiness",1);material.SetFloat("_GlossMapScale",1);material.SetFloat("_BumpScale",1);
            material.SetFloat("_Mode",0);material.SetInt("_SrcBlend",(int)UnityEngine.Rendering.BlendMode.One);material.SetInt("_DstBlend",(int)UnityEngine.Rendering.BlendMode.Zero);material.SetInt("_ZWrite",1);material.renderQueue=-1;
            material.EnableKeyword("_NORMALMAP");material.EnableKeyword("_METALLICGLOSSMAP");material.EnableKeyword("_EMISSION");
            material.SetTexture("_EmissionMap",maps["albedo"]);material.SetColor("_EmissionColor",Color.black);
            return material;
        }
    }
}
