namespace BlackAbbeySixRooms { internal static class FalseVowsAssetVersion { internal const string ManifestSha256="d9b57cd7fd2eb3698b0d0b192836d2b75b5d34985925c7dea6e5ba90e23ff47c"; } }
