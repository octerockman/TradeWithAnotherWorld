using System;

namespace BlackAbbeySixRooms
{
    // A native Player object is destroyed/replaced during respawn. The loaded
    // run belongs to the host session and stable profile/world IDs instead.
    internal sealed class DungeonSessionLifetime
    {
        internal enum Decision { Unbound, Retain, Release }
        object ownerNetwork;
        string ownerWorld, ownerCharacter;

        internal Decision Observe(object network, bool hostAlive, string world, string character)
        {
            bool bound = ownerNetwork != null;
            bool changed = bound && (!hostAlive || !ReferenceEquals(network, ownerNetwork) ||
                KnownMismatch(world, ownerWorld) || KnownMismatch(character, ownerCharacter));
            if (changed) { ownerNetwork = null; ownerWorld = ownerCharacter = null; }
            if (ownerNetwork == null && hostAlive && network != null && !string.IsNullOrEmpty(world) && !string.IsNullOrEmpty(character))
            { ownerNetwork = network; ownerWorld = world; ownerCharacter = character; }
            if (changed) return Decision.Release;
            return ownerNetwork != null ? Decision.Retain : Decision.Unbound;
        }

        static bool KnownMismatch(string current, string expected) => !string.IsNullOrEmpty(current) && !string.Equals(current, expected, StringComparison.Ordinal);

        internal static bool RetainActorRun(object expectedNetwork, object currentNetwork, bool hostAlive, long ownerId, long? currentId)
            => expectedNetwork != null && hostAlive && ReferenceEquals(expectedNetwork, currentNetwork) && (!currentId.HasValue || currentId.Value == ownerId);
    }
}
