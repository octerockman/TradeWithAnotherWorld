using System;
using System.IO;
using System.Linq;
namespace BlackAbbeySixRooms
{
    internal static partial class KitPointedArchitecture
    {
        internal const string KitId="POINTED_CONNECTOR_KIT_V1",DoorId="OAK_DOOR_POINTED_V1",DoorMode="pointed-standard-kit-v1";
        internal const float Span=.8f,HalfReach=.39f,Gap=.02f;
        internal static bool Pointed(PortRecord p)=>p!=null&&Near(p.width,3)&&Near(p.height,4)&&Near(p.springHeight,2)&&Near(p.archRise,2)&&p.depth>=.1f&&p.depth<=HalfReach+.0002f;
        private static bool Near(float a,float b)=>!float.IsNaN(a)&&!float.IsInfinity(a)&&Math.Abs(a-b)<.0002f;
        internal static void ValidatePlan(DungeonPlan plan,PackageManifest kit)
        {
            if(plan==null||plan.GenerationRevision<3||kit?.roomId!=KitId||kit.sourceSha256!="7c9dd2542f26a7a6a5489907d506d883683ae8b0ef887f15354195710d01ff1b"||plan.Rooms==null||plan.Links==null)throw new InvalidDataException("A pointed kit connector requires the rebuilt revision3 plan and exact canonical source.");
            if(plan.Rooms.Any(r=>r?.Spec?.Ports==null||r.Spec.Ports.Any(p=>!Pointed(p)&&!R09SplitPlanning.IsBoundary(p))))throw new InvalidDataException("Every rebuilt room mouth must use the measured3m x4m pointed profile and inset depth.");
            foreach(var l in plan.Links)
            {
                if(R09SplitPlanning.IsThreshold(l)){R09SplitPlanning.ValidateThreshold(plan,l);continue;}
                if(l?.Kind==R08KnightReturnPolicy.SleeveKind){R08KnightReturnPolicy.ValidateSleeve(plan,l);continue;}
                if(l==null||!Pointed(l.PortA)||!Pointed(l.PortB)||Math.Abs((l.End-l.Start).Length-Gap)>.0002)throw new InvalidDataException("Rebuilt pointed connection has an invalid source gap.");
            }
            foreach(var id in new[]{"pointed_080","pointed_080_return"})
                if(!kit.meshes.Any(m=>m.partId==id)||!kit.colliderMeshes.Any(m=>m.partId==id))throw new InvalidDataException("Missing source-bound pointed module: "+id);
        }
    }
}
