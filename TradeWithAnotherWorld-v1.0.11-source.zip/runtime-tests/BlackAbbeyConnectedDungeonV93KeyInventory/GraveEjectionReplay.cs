using System;
using System.Collections;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        float nextGraveReplay;
        bool replayingGraveExits;
        string graveReplayFailure;
        void TickGraveEjectionReplay(Player player)
        {
            if(!player||busy||replayingGraveExits||!ZNet.instance||!ZNet.instance.IsServer()||ZDOMan.instance==null||
                !ZNetScene.instance||!ZoneSystem.instance||Time.unscaledTime<nextGraveReplay)return;
            nextGraveReplay=Time.unscaledTime+10;
            StartCoroutine(ReplayGraveEjections());
        }
        IEnumerator ReplayGraveEjections()
        {
            replayingGraveExits=true;
            try
            {
                var network=ZNet.instance;var manager=ZDOMan.instance;var scene=ZNetScene.instance;string world;
                System.Collections.Generic.List<GraveExitRecord> records;
                try {world=WorldKey();records=GraveJournal.Load(world);graveReplayFailure=null;}
                catch(Exception ex)
                {
                    if(graveReplayFailure!=ex.Message)Logger.LogWarning("Grave exit replay retained its journal: "+ex.Message);
                    graveReplayFailure=ex.Message;yield break;
                }
                int processed=0;
                foreach(var record in records)
                {
                    if(busy||!SameRetirementWorld(network,manager,world))yield break;
                    var grave=manager.GetZDO(new ZDOID(record.userId,record.objectId));
                    if(grave!=null&&grave.IsValid()&&GraveEjectionPolicy.NeedsReplay(record,grave.GetPrefab(),grave.GetLong(ZDOVars.s_owner,0),
                        Array(grave.GetPosition()),Array(grave.GetVec3(ZDOVars.s_spawnPoint,grave.GetPosition()))))
                    {
                        Vector3 destination=RoomPackage.Vector(record.destination,"recorded grave exit");
                        // Terrain must actually be loaded. Missing native UIDs
                        // and unloaded surface sectors are retried, never spawned.
                        if(ZoneSystem.instance&&ZoneSystem.instance.GetGroundHeight(destination,out float h)&&RoomPackage.Finite(h)&&Mathf.Abs(h-destination.y)<1f&&
                            MoveExistingGrave(network,manager,scene,world,grave,destination))
                            Logger.LogInfo("ABBEY_GRAVE_EXIT_REPLAYED: nativeUID="+grave.m_uid+"; existing inventory retained.");
                    }
                    if(++processed%8==0)yield return null;
                }
            }
            finally {replayingGraveExits=false;}
        }
    }
}
