using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeySixRooms
{
    internal sealed class R07PuzzleSnapshot
    {
        public int start;
        public bool[] lit;
        public bool coffinUnlocked, secretUnlocked, chestEverOpened, coffinEverOpened;
    }
    // Local generated-run state, independent of Unity, lid pose and inventory UI.
    internal sealed class R07PuzzleState
    {
        internal const string Pattern = "lloloolollol";
        private readonly int[] clockwise, counterclockwise;
        private readonly bool[] lit = new bool[12];
        private readonly int start;
        internal Action Changed;
        internal bool CoffinUnlocked { get; private set; }
        internal bool SecretUnlocked { get; private set; }
        internal bool ChestEverOpened { get; private set; }
        internal bool CoffinEverOpened { get; private set; }
        // Kept as empty diagnostics for existing status callers. Neither
        // puzzle now records or evaluates the lighting chronology.
        internal int AttemptsReset => 0;
        internal int[] Chronology => Array.Empty<int>();
        internal bool[] Lit => (bool[])lit.Clone();
        internal int[] ClockwiseSolution => (int[])clockwise.Clone();
        internal int[] CounterclockwiseSolution => (int[])counterclockwise.Clone();
        // Both rewards compare current physical states only. The same L/O
        // pattern uses the original coffin anchor and a one-step shifted statue anchor.
        internal bool CoffinPatternMatches => MaskMatches(clockwise);
        internal bool SecretPatternMatches => MaskMatches(counterclockwise);
        internal enum Result { Progress, Reset, CoffinSolved, SecretSolved, SecretDenied }
        internal R07PuzzleState(int start = 0)
        {
            if (start < 0 || start >= 12) throw new ArgumentOutOfRangeException(nameof(start));
            this.start = start;
            clockwise = Enumerable.Range(0, 12).Where(i => Pattern[i] == 'l').Select(i => (start + i) % 12).ToArray();
            // Jesse: shift only the statue's full mask one candle counterclockwise.
            // Source indices increase clockwise; -1 rotates every lit/out position.
            counterclockwise = Enumerable.Range(0, 12).Where(i => Pattern[i] == 'l').Select(i => (start - i - 1 + 24) % 12).ToArray();
        }
        private bool MaskMatches(int[] solution) => Enumerable.Range(0, 12).All(i => lit[i] == solution.Contains(i));
        internal Result Toggle(int index)
        {
            if (index < 0 || index >= lit.Length) throw new ArgumentOutOfRangeException(nameof(index));
            lit[index] = !lit[index];
            // Every toggle remains under player control. Exact masks may be
            // reached in any order, including by snuffing an extra candle.
            if (!CoffinUnlocked && CoffinPatternMatches) { CoffinUnlocked = true; Changed?.Invoke(); return Result.CoffinSolved; }
            if (!SecretUnlocked && SecretPatternMatches)
            {
                if (ChestEverOpened || CoffinEverOpened) { Changed?.Invoke(); return Result.SecretDenied; }
                SecretUnlocked = true; Changed?.Invoke(); return Result.SecretSolved;
            }
            Changed?.Invoke();
            return Result.Progress;
        }
        internal bool CanOpen(string id) => id == "chest" || id == "coffin" && CoffinUnlocked || id == "secret-box" && SecretUnlocked;
        internal bool MarkOpened(string id)
        {
            if (!CanOpen(id)) return false;
            if (id == "chest") ChestEverOpened = true;
            if (id == "coffin") CoffinEverOpened = true;
            Changed?.Invoke();
            return true;
        }
        internal R07PuzzleSnapshot Capture() => new R07PuzzleSnapshot { start=start, lit=Lit, coffinUnlocked=CoffinUnlocked,
            secretUnlocked=SecretUnlocked, chestEverOpened=ChestEverOpened, coffinEverOpened=CoffinEverOpened };
        internal static R07PuzzleState Restore(R07PuzzleSnapshot saved)
        {
            if (saved == null || saved.start < 0 || saved.start >= 12 || saved.lit == null || saved.lit.Length != 12 ||
                saved.coffinEverOpened && !saved.coffinUnlocked)
                throw new ArgumentException("Invalid saved shrine puzzle state.");
            var result = new R07PuzzleState(saved.start);
            Array.Copy(saved.lit,result.lit,12);result.CoffinUnlocked=saved.coffinUnlocked;result.SecretUnlocked=saved.secretUnlocked;
            result.ChestEverOpened=saved.chestEverOpened;result.CoffinEverOpened=saved.coffinEverOpened;return result;
        }
    }

    internal sealed class R07RunState<T> where T : class
    {
        internal readonly string RunId;
        internal readonly int Seed;
        internal readonly R07PuzzleState Puzzle;
        private readonly Dictionary<string, T> inventories = new Dictionary<string, T>(StringComparer.Ordinal);
        internal R07RunState(int seed, int start = 0) { Seed = seed; RunId = Guid.NewGuid().ToString("N"); Puzzle = new R07PuzzleState(start); }
        internal R07RunState(int seed, string runId, R07PuzzleSnapshot puzzle)
        {
            if (!Guid.TryParseExact(runId,"N",out _)) throw new ArgumentException("Invalid saved shrine run identity.");
            Seed=seed;RunId=runId;Puzzle=R07PuzzleState.Restore(puzzle);
        }
        internal KeyValuePair<string,T>[] ExistingInventories => inventories.ToArray();
        internal void RestoreInventory(string id,T value)
        {
            if (!new[] { "chest", "coffin", "secret-box" }.Contains(id) || value == null || inventories.ContainsKey(id))
                throw new ArgumentException("Invalid or duplicate saved shrine inventory.");
            inventories.Add(id,value);
        }
        internal T Inventory(string id, Func<int, T> initialize)
        {
            if (!new[] { "chest", "coffin", "secret-box" }.Contains(id)) throw new ArgumentException("Unknown shrine container.");
            if (!inventories.TryGetValue(id, out T existing))
            {
                // Stable within a run and independent of string.GetHashCode's runtime salt.
                int seed = Seed; unchecked { foreach (char c in id) seed = seed * 31 + c; }
                existing = initialize(seed) ?? throw new InvalidOperationException("Container initialization failed.");
                inventories.Add(id, existing);
            }
            return existing;
        }
    }
    internal static class R07OpeningPolicy
    {
        // Only the animation's first actual, unblocked pose advance may record
        // opening history. Hovering, pressing E at a locked lid and blocked
        // sweep requests leave the unopened-container secret eligible.
        internal static bool RecordStart(R07PuzzleState state, string id, bool sweepClear, bool actualPoseAdvance)
            => sweepClear && actualPoseAdvance && state.MarkOpened(id);
    }
    internal sealed class R07UseLifecycle
    {
        internal string Pending { get; private set; }
        internal bool Busy => Pending != null;
        internal bool Begin(string id) { if (Busy) return false; Pending = id; return true; }
        internal bool Complete(string id) { if (Pending != id) return false; Pending = null; return true; }
        // Cancels only the interrupted UI request, never earned run state.
        internal void Disable() { Pending = null; }
    }
}
