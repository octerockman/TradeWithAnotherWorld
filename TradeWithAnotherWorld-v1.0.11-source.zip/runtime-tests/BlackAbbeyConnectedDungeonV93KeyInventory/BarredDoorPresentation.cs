using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Barred mouths share one template-owned matte material family. The
    // orange glyph was ALSO painted into the oak albedo, so emission=0 alone
    // could never remove it. Opening doors keep the exact original materials.
    internal static class BarredDoorPresentation
    {
        internal const string WoodMaterial = "BA test | OAK_DOOR_POINTED_V1 runtime BA Door Test | Baked oak source2K";
        private const string MapHash = "7b1352c5ef6fe5582a7c5b611842bc9a36cc917ec7269575901ad4b728a2bcfc";
        internal static void Apply(GameObject root, AbbeyDoorAssets assets)
        {
            if (assets?.Template?.Manifest?.sourceSha256 != "80c745a777adaec71c7370376036a4de51e72d37b2d1283cffcf2c15f6829675")
                throw new InvalidDataException("Barred oak correction requires its exact pointed source.");
            foreach (var renderer in root.GetComponentsInChildren<Renderer>(true))
            {
                var materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                {
                    var source = materials[i];
                    if (!source) continue;
                    if (!assets.BarredMaterials.TryGetValue(source, out var quiet) || !quiet)
                    {
                        quiet = new Material(source) { name = "BA barred matte | " + source.name };
                        assets.Template.Resources.Add(quiet);
                        quiet.DisableKeyword("_EMISSION");
                        if (quiet.HasProperty("_EmissionColor")) quiet.SetColor("_EmissionColor", Color.black);
                        if (quiet.HasProperty("_EmissionMap")) quiet.SetTexture("_EmissionMap", null);
                        quiet.globalIlluminationFlags = MaterialGlobalIlluminationFlags.EmissiveIsBlack;
                        if (source.name == WoodMaterial) quiet.SetTexture("_MainTex", PlainOak(assets));
                        assets.BarredMaterials[source] = quiet;
                    }
                    materials[i] = quiet;
                }
                renderer.sharedMaterials = materials;
            }
        }
        private static Texture2D PlainOak(AbbeyDoorAssets assets)
        {
            if (assets.BarredPlainOak) return assets.BarredPlainOak;
            byte[] bytes;
            using (var source = typeof(BarredDoorPresentation).Assembly.GetManifestResourceStream("BlackAbbey.BarredPlainOak.png"))
            using (var output = new MemoryStream())
            {
                if (source == null) throw new InvalidDataException("Missing pinned barred oak map.");
                source.CopyTo(output); bytes = output.ToArray();
            }
            using (var sha = SHA256.Create())
                if (BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant() != MapHash)
                    throw new InvalidDataException("Barred oak map differs from its source transport.");
            var map = new Texture2D(2, 2, TextureFormat.RGBA32, true, false)
                { name = "BA barred oak | original plank pixels without orange paint", wrapMode = TextureWrapMode.Repeat, filterMode = FilterMode.Point, anisoLevel = 8 };
            assets.Template.Resources.Add(map);
            if (!ImageConversion.LoadImage(map, bytes, true) || map.width != 2048 || map.height != 2048)
                throw new InvalidDataException("Barred oak map must retain its exact 2K source atlas.");
            return assets.BarredPlainOak = map;
        }
    }
}
