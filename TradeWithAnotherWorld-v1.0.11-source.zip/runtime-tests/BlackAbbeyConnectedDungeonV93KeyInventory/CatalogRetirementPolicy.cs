using System;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
#pragma warning disable 0649
    internal sealed class LegacyRetirementFile { public int schemaVersion;public LegacyRetirementRecord[] runs; }
    internal sealed class LegacyRetirementRecord
    {
        public string worldKey,runId,catalogSha256,layoutSha256;
        public int seed,generationRevision;
        public float[] origin;
        // Local plan-space minX,minZ,maxX,maxZ,minY,maxY, including spawner bays.
        public float[][] volumes;
    }
#pragma warning restore 0649
    // Admission for explicit retirement only. This never makes another catalog
    // eligible for ordinary entry or replays an old plan with the current art.
    internal static class CatalogRetirementPolicy
    {
        internal static bool NeedsEnvelope(DungeonRunSnapshot run,string currentCatalogSha256)
        {
            if(run==null)return false;
            DungeonGenerationPolicy.RequireRevision(run.generationRevision);
            if(!CatalogReader.Hash(run.catalogSha256)||!CatalogReader.Hash(currentCatalogSha256))
                throw new InvalidDataException("Retirement requires valid saved and current catalog identities.");
            return run.generationRevision<DungeonGenerationPolicy.CurrentRevision||
                !DungeonAssetRevision.CatalogMatches(run.catalogSha256,currentCatalogSha256);
        }
        internal static LegacyRetirementRecord RequireExact(LegacyRetirementFile data,DungeonRunSnapshot run)
        {
            if(run==null||data?.schemaVersion!=1||data.runs==null||data.runs.Length>64)
                throw new InvalidDataException("Invalid checked retirement metadata.");
            DungeonGenerationPolicy.RequireRevision(run.generationRevision);
            if(string.IsNullOrWhiteSpace(run.worldKey)||string.IsNullOrWhiteSpace(run.runId)||
                !CatalogReader.Hash(run.catalogSha256)||!CatalogReader.Hash(run.layoutSha256))
                throw new InvalidDataException("Invalid saved retirement identity.");
            var matches=data.runs.Where(x=>x!=null&&x.worldKey==run.worldKey&&x.runId==run.runId&&x.seed==run.seed&&
                x.generationRevision==run.generationRevision&&x.catalogSha256==run.catalogSha256&&x.layoutSha256==run.layoutSha256).ToArray();
            if(matches.Length!=1)throw new InvalidDataException("No unique exact retirement envelope for this saved Abbey. Its run and graves were retained.");
            var row=matches[0];
            bool Finite(float x)=>!float.IsNaN(x)&&!float.IsInfinity(x);
            if(row.origin?.Length!=3||run.origin?.Length!=3||row.origin.Any(x=>!Finite(x))||!row.origin.SequenceEqual(run.origin)||
                row.volumes==null||row.volumes.Length<1||row.volumes.Length>4096||row.volumes.Any(v=>v==null||v.Length!=6||
                v.Any(n=>!Finite(n)||Math.Abs(n)>10000)||v[0]>=v[2]||v[1]>=v[3]||v[4]>=v[5]))
                throw new InvalidDataException("Retirement bounds differ from their exact saved origin/source.");
            return new LegacyRetirementRecord {worldKey=row.worldKey,runId=row.runId,seed=row.seed,generationRevision=row.generationRevision,
                catalogSha256=row.catalogSha256,layoutSha256=row.layoutSha256,origin=(float[])row.origin.Clone(),
                volumes=row.volumes.Select(v=>(float[])v.Clone()).ToArray()};
        }
    }
}
