using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    internal sealed class AbbeyDoorAssets : IDisposable
    {
        internal readonly System.Collections.Generic.Dictionary<Material, Material> BarredMaterials = new System.Collections.Generic.Dictionary<Material, Material>();
        internal Texture2D BarredPlainOak;
        internal LoadedRoom Template;
        internal DoorFitRecord Fit;
        internal bool ProfileHinges;
        internal sealed class Prepared
        {
            internal string Directory;
            internal PackageManifest Manifest;
            internal CatalogRoomRecord Record;
            internal bool ProfileHinges;
        }
        // Managed contract work only; safe on RoomLoadScheduling.Worker.
        internal static Prepared Prepare(string directory, string expectedManifestSha256)
        {
            string manifestPath = Path.Combine(directory, "manifest.json");
            if (!CatalogReader.Hash(expectedManifestSha256) || CatalogReader.HashFile(manifestPath) != expectedManifestSha256)
                throw new InvalidDataException("Interior oak door manifest differs from its pinned build.");
            var manifest = ManifestReader.Read(File.ReadAllText(manifestPath));
            if ((manifest.roomId != "OAK_DOOR_V1"&&manifest.roomId!=KitPointedArchitecture.DoorId) || !CatalogReader.Hash(manifest.sourceSha256)) throw new InvalidDataException("Wrong interior oak door asset.");
            AssemblyPartPolicy.ValidateOakParts(manifest);
            var fit = manifest.doorFit;
            AssemblyPartPolicy.ValidateOakFit(fit);
            var record = new CatalogRoomRecord { roomId = manifest.roomId, displayName = "Interior great oak double doors", sourceSha256 = manifest.sourceSha256, manifestSha256 = expectedManifestSha256 };
            return new Prepared { Directory = directory, Manifest = manifest, Record = record,
                ProfileHinges = manifest.roomId!=KitPointedArchitecture.DoorId && fit.woodProfileMode != AssemblyPartPolicy.PerPortMode && AssemblyPartPolicy.HasProfileHinges(manifest) };
        }
        internal static AbbeyDoorAssets Load(string directory, string expectedManifestSha256, Action<string> log)
        {
            var data = Prepare(directory, expectedManifestSha256);
            var asset = new AbbeyDoorAssets { Fit = data.Manifest.doorFit, ProfileHinges = data.ProfileHinges };
            try
            {
                asset.Template = RoomPackage.Load(data.Directory, data.Record, log);
                ValidateLoaded(asset);
                return asset;
            }
            catch { asset.Dispose(); throw; }
        }
        internal static IEnumerator LoadSteps(string directory, string expectedManifestSha256, Action<string> log,
            Action<AbbeyDoorAssets> completed, Action<AbbeyDoorAssets> created = null)
        {
            var task = RoomLoadScheduling.Worker(() => Prepare(directory, expectedManifestSha256));
            while (!task.IsCompleted) yield return null;
            var nested = LoadPreparedSteps(task.GetAwaiter().GetResult(), log, completed, created);
            try { while (nested.MoveNext()) yield return nested.Current; }
            finally { (nested as IDisposable)?.Dispose(); }
        }
        internal static IEnumerator LoadPreparedSteps(Prepared data, Action<string> log,
            Action<AbbeyDoorAssets> completed, Action<AbbeyDoorAssets> created = null)
        {
            var asset = new AbbeyDoorAssets { Fit = data.Manifest.doorFit, ProfileHinges = data.ProfileHinges };
            bool succeeded = false; IEnumerator nested = null;
            try
            {
                created?.Invoke(asset);
                nested = RoomPackage.LoadSteps(data.Directory, data.Record, log,
                    value => asset.Template = value, value => asset.Template = value);
                while (nested.MoveNext()) yield return nested.Current;
                ValidateLoaded(asset);
                completed(asset); succeeded = true;
            }
            finally { (nested as IDisposable)?.Dispose(); if (!succeeded) asset.Dispose(); }
        }
        private static void ValidateLoaded(AbbeyDoorAssets asset)
        {
            if(asset.Template.Manifest.roomId==KitPointedArchitecture.DoorId){KitPointedArchitecture.ValidateDoor(asset.Template.Manifest);return;}
            if (asset.Fit.woodProfileMode != AssemblyPartPolicy.PerPortMode)
                foreach (string name in new[] { "left_leaf", "right_leaf", "barred_crossbar", "opening_symbol_left", "opening_symbol_right", "Collider | left_leaf", "Collider | right_leaf" })
                    if (!asset.Template.Root.transform.Find(name)) throw new InvalidDataException("Missing oak door part: " + name);
            if (asset.Template.Root.transform.Find("fixed_arch_head")) throw new InvalidDataException("The restored arched door must not contain the rejected stationary upper panel.");
        }
        public void Dispose() { Template?.Dispose(); Template = null; Fit = null; BarredMaterials.Clear(); BarredPlainOak = null; }
    }

    internal static class AbbeyDoorAssembly
    {
        // Per-port sources mount at the measured front-arch datum and fit
        // their wood to that original opening. Legacy assets retain their
        // recorded placement; V9 does not add a stone rebate.
        internal static AbbeyDoor Create(Transform parent, Vector3 localPosition, Quaternion localRotation, bool barred, AbbeyDoorAssets assets, PortRecord port, LoadedRoom stoneKit, LoadedRoom sourceRoom)
        {
            if(assets?.Template?.Manifest?.roomId==KitPointedArchitecture.DoorId)return KitPointedArchitecture.CreateDoor(parent,localPosition,localRotation,barred,assets,port);
            if (!parent || assets?.Template?.Root == null || port == null) throw new ArgumentException("Oak door assembly needs a parent, checked asset and source port.");
            if (port.width < 2.9f || port.width > 3.1f || Mathf.Abs(port.height - 3.5f) > .06f)
                throw new InvalidDataException("Oak door prototype fits the recorded3m ×3.5m Abbey ports only.");
            bool circle = Mathf.Abs(port.springHeight - 2f) < .03f && Mathf.Abs(port.archRise - 1.5f) < .03f;
            bool ellipse = Mathf.Abs(port.springHeight - 2.6f) < .03f && Mathf.Abs(port.archRise - .9f) < .03f;
            if (!circle && !ellipse) throw new InvalidDataException("Unsupported oak door aperture profile; refuse to cover or obstruct an unknown opening.");
            var variant = AssemblyPartPolicy.SelectVariant(assets.Template.Manifest, sourceRoom?.Manifest?.roomId, port.id, sourceRoom?.DoorSourceSha256??UnrecordedDeadSourceBindings.Canonical(sourceRoom?.Manifest?.roomId,sourceRoom?.Manifest?.sourceSha256));
            float mountDepth = variant != null ? variant.mountDepth : assets.Fit.mountDepth;
            var root = Object.Instantiate(assets.Template.Root, parent); root.name = barred ? "BA Barred oak branch | " + port.id : "BA Opening oak doors | " + port.id;
            root.SetActive(false);
            if (variant != null) SelectVariantObjects(root.transform, variant);
            root.transform.localPosition = localPosition + localRotation * (Vector3.forward * mountDepth); root.transform.localRotation = localRotation; root.transform.localScale = new Vector3(port.width / 3f, 1, 1);
            if (variant == null) AttachStoneRebate(root.transform, stoneKit, circle);
            var left = Hinge(root.transform, "left_leaf", RoomPackage.Vector(variant != null ? variant.leftHinge : AssemblyPartPolicy.HingeForProfile(assets.Fit, circle, true), "left oak hinge"));
            var right = Hinge(root.transform, "right_leaf", RoomPackage.Vector(variant != null ? variant.rightHinge : AssemblyPartPolicy.HingeForProfile(assets.Fit, circle, false), "right oak hinge"));
            if (variant == null && assets.ProfileHinges) AttachProfileHinges(root.transform, left, right, circle);
            var leftBody = LeafCollider(root.transform, left, "left_leaf"); var rightBody = LeafCollider(root.transform, right, "right_leaf");
            AbbeyDoorGlyphAttachment.Attach(root.transform, left, right, barred);
            var transom = root.transform.Find("ellipse_transom");
            if (transom) transom.gameObject.SetActive(ellipse);
            root.transform.Find("barred_crossbar").gameObject.SetActive(barred);
            var door = root.AddComponent<AbbeyDoor>(); door.Configure(left, right, leftBody.LocalBounds, rightBody.LocalBounds, barred, assets.Fit.openAngle);
            foreach (var body in new[] { leftBody, rightBody }) body.Collider.gameObject.AddComponent<AbbeyDoorHandle>().Door = door;
            root.SetActive(true); return door;
        }

        private static void SelectVariantObjects(Transform root, DoorVariantRecord variant)
        {
            // Disable whole objects, including every unselected collider,
            // while the assembly root is still inactive. Only the selected
            // six visuals and two bodies can enter the active hierarchy.
            foreach (Transform child in root.Cast<Transform>().ToArray()) child.gameObject.SetActive(false);
            string[] names = AssemblyPartPolicy.VariantObjectNames(variant);
            for (int i = 0; i < names.Length; i++)
            {
                var part = root.Find(names[i]);
                if (!part) throw new InvalidDataException("Missing selected oak variant object: " + names[i]);
                part.name = i < AssemblyPartPolicy.VariantVisualParts.Length ? AssemblyPartPolicy.VariantVisualParts[i]
                    : "Collider | " + AssemblyPartPolicy.VariantCollisionParts[i - AssemblyPartPolicy.VariantVisualParts.Length];
                part.gameObject.SetActive(true);
            }
        }

        private static void AttachStoneRebate(Transform doorRoot, LoadedRoom kit, bool circle)
        {
            if (!kit?.Root || !AssemblyPartPolicy.HasDoorRebates(kit.Manifest)) return;
            string name = circle ? "fit_rebate_c" : "fit_rebate_e";
            // Authored at the inset oak-root datum; remains static, never on
            // a moving leaf or the independent outside portal.
            foreach (string part in new[] { name, "Collider | " + name })
            {
                var source = kit.Root.transform.Find(part);
                if (!source) throw new InvalidDataException("Declared fitted oak rebate missing: " + part);
                var clone = Object.Instantiate(source.gameObject, doorRoot, false);
                clone.name = part; clone.transform.localPosition = Vector3.zero;
                clone.transform.localRotation = Quaternion.identity; clone.transform.localScale = Vector3.one; clone.SetActive(true);
            }
        }

        private static void AttachProfileHinges(Transform root, Transform left, Transform right, bool circle)
        {
            foreach (string profile in new[] { "e", "c" })
            {
                bool selected = circle == (profile == "c");
                var fixedMetal = root.Find("fixed_hinges_" + profile);
                if (!fixedMetal) throw new InvalidDataException("Missing profile-specific fixed hinge metal.");
                fixedMetal.gameObject.SetActive(selected);
                foreach (var side in new[] { new { Name = "left", Hinge = left }, new { Name = "right", Hinge = right } })
                {
                    var metal = root.Find("hinge_" + profile + "_" + side.Name);
                    if (!metal) throw new InvalidDataException("Missing profile-specific moving hinge metal.");
                    metal.gameObject.SetActive(selected);
                    if (!selected) continue;
                    metal.SetParent(side.Hinge, false); metal.localPosition = -side.Hinge.localPosition;
                    metal.localRotation = Quaternion.identity; metal.localScale = Vector3.one;
                }
            }
        }

        private static Transform Hinge(Transform root, string name, Vector3 pivot)
        {
            var hinge = new GameObject("Hinge | " + name).transform; hinge.SetParent(root, false); hinge.localPosition = pivot;
            var visual = root.Find(name); visual.SetParent(hinge, false); visual.localPosition = -pivot; return hinge;
        }
        private sealed class LeafBody { internal MeshCollider Collider; internal Bounds LocalBounds; }
        private static LeafBody LeafCollider(Transform root, Transform hinge, string name)
        {
            var source = root.Find("Collider | " + name); var original = source.GetComponent<MeshCollider>();
            if (!original || !original.sharedMesh) throw new InvalidDataException("Missing recorded oak leaf body.");
            if (original.sharedMesh.triangles.Length / 3 > 255) throw new InvalidDataException("The restored arched leaf needs its checked low-polygon convex profile collider.");
            Bounds bounds = original.sharedMesh.bounds; bounds.center -= hinge.localPosition;
            source.SetParent(hinge, false); source.localPosition = -hinge.localPosition;
            original.convex = true; original.isTrigger = false;
            return new LeafBody { Collider = original, LocalBounds = bounds };
        }
    }
}
