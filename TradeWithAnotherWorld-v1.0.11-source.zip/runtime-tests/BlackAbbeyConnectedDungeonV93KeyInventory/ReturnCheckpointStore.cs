using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlackAbbeySixRooms
{
    /// <summary>Identity-separated recovery records. No game APIs or save-file access.</summary>
    internal sealed class ReturnCheckpointStore
    {
        private const int MaxBytes = 64 * 1024;
        private readonly string legacyPath, root, active, archive;
        private readonly Action<string> log;
        private static readonly UTF8Encoding Utf8 = new UTF8Encoding(false, true);
        internal ReturnCheckpointStore(string legacyPath, Action<string> log)
        {
            if (string.IsNullOrWhiteSpace(legacyPath) || !Path.IsPathRooted(legacyPath)) throw new ArgumentException("Recovery store requires an absolute legacy-file path.");
            this.legacyPath = Path.GetFullPath(legacyPath); this.log = log ?? (_ => { });
            root = Path.Combine(Path.GetDirectoryName(this.legacyPath), "return-checkpoints");
            active = Path.Combine(root, "active"); archive = Path.Combine(root, "archive");
        }
        internal string Load(string playerId, string worldKey)
        {
            string key = Key(playerId, worldKey);
            using (Lock())
            {
                string path = Path.Combine(active, key + ".json");
                if (File.Exists(path))
                {
                    var current = ReadMatching(path, playerId, worldKey, false);
                    if (current == null) return null; // A bad keyed file cannot authorize a fallback overwrite.
                    // Keep the newer identity record when an older same-owner
                    // legacy record also exists. Archive it only after a save.
                    var old = ReadMatchingLegacy(playerId, worldKey);
                    if (old != null) { SaveCore(path, current.Text, current.Bytes); ArchiveLegacy(key, old.Bytes); }
                    return current.Text;
                }
                var legacy = ReadMatchingLegacy(playerId, worldKey);
                if (legacy == null) return null;
                SaveCore(path, legacy.Text, Utf8.GetBytes(legacy.Text));
                ArchiveLegacy(key, legacy.Bytes);
                log("Migrated the matching legacy return checkpoint; other identities remain untouched.");
                return legacy.Text;
            }
        }
        internal void Save(string playerId, string worldKey, string json)
        {
            string key = Key(playerId, worldKey); byte[] bytes = Encode(json);
            Validate(json, playerId, worldKey);
            using (Lock())
            {
                string path = Path.Combine(active, key + ".json");
                if (File.Exists(path) && ReadMatching(path, playerId, worldKey, false) == null)
                    throw new InvalidDataException("An invalid keyed recovery record was preserved instead of overwritten.");
                SaveCore(path, json, bytes);
                var legacy = ReadMatchingLegacy(playerId, worldKey);
                if (legacy != null) ArchiveLegacy(key, legacy.Bytes);
            }
        }
        internal void Clear(string playerId, string worldKey)
        {
            string key = Key(playerId, worldKey);
            using (Lock())
            {
                string path = Path.Combine(active, key + ".json");
                if (!File.Exists(path)) return;
                if (ReadMatching(path, playerId, worldKey, false) == null) { log("Invalid keyed recovery was preserved during clear."); return; }
                File.Delete(path); // Only this exact identity's active record.
            }
        }
        private sealed class Record { internal byte[] Bytes; internal string Text; }
        private Record ReadMatchingLegacy(string playerId, string worldKey) => File.Exists(legacyPath) ? ReadMatching(legacyPath, playerId, worldKey, true) : null;
        private Record ReadMatching(string path, string playerId, string worldKey, bool legacy)
        {
            try
            {
                byte[] bytes = ReadBounded(path); string json = Utf8.GetString(bytes).TrimStart('\uFEFF'); Validate(json, playerId, worldKey);
                return new Record { Bytes = bytes, Text = json };
            }
            catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is JsonException || ex is InvalidDataException || ex is DecoderFallbackException)
            { log(legacy ? "Legacy recovery is invalid or belongs to another identity; retained unchanged." : "Keyed recovery validation failed; retained unchanged."); return null; }
        }
        private static byte[] ReadBounded(string path)
        {
            using (var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                if (file.Length > MaxBytes) throw new InvalidDataException("Recovery record exceeds64KiB.");
                var bytes = new byte[MaxBytes + 1]; int count = 0, read;
                while (count < bytes.Length && (read = file.Read(bytes, count, bytes.Length - count)) > 0) count += read;
                if (count > MaxBytes) throw new InvalidDataException("Recovery record exceeds64KiB.");
                return bytes.Take(count).ToArray();
            }
        }
        private static byte[] Encode(string json)
        {
            if (json == null || json.Length > MaxBytes) throw new InvalidDataException("Recovery JSON is absent or oversized.");
            byte[] bytes = Utf8.GetBytes(json); if (bytes.Length > MaxBytes) throw new InvalidDataException("Recovery UTF8 exceeds64KiB."); return bytes;
        }
        private static void Validate(string json, string playerId, string worldKey)
        {
            Encode(json);
            // A token tree never creates a CLR type. Explicit settings also
            // prohibit type-name/metadata interpretation and trailing content.
            var settings = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.None, MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
                DateParseHandling = DateParseHandling.None, MaxDepth = 16, CheckAdditionalContent = true };
            using (var text = new StringReader(json)) using (var reader = new JsonTextReader(text) { MaxDepth = 16, DateParseHandling = DateParseHandling.None })
            {
                var token = JObject.Load(reader, new JsonLoadSettings { DuplicatePropertyNameHandling = DuplicatePropertyNameHandling.Error });
                if (reader.Read()) throw new InvalidDataException("Recovery JSON has trailing content.");
                var data = token.ToObject<JObject>(JsonSerializer.Create(settings));
                string version = data["schemaVersion"]?.ToString(Formatting.None);
                if (data["schemaVersion"]?.Type != JTokenType.Integer || (version != "1" && version != "2") ||
                    data["pending"]?.Type != JTokenType.Boolean || !(bool)data["pending"] || data["playerId"]?.Type != JTokenType.String || data["worldKey"]?.Type != JTokenType.String ||
                    !string.Equals((string)data["playerId"], playerId, StringComparison.Ordinal) || !string.Equals((string)data["worldKey"], worldKey, StringComparison.Ordinal))
                    throw new InvalidDataException("Recovery schema, pending state or identity differs.");
            }
        }
        private static string Key(string playerId, string worldKey)
        {
            if (string.IsNullOrWhiteSpace(playerId) || string.IsNullOrWhiteSpace(worldKey) || Utf8.GetByteCount(playerId) > 4096 || Utf8.GetByteCount(worldKey) > 4096)
                throw new ArgumentException("Player/world recovery identity is missing or oversized.");
            using (var data = new MemoryStream())
            {
                using (var writer = new BinaryWriter(data, Utf8, true))
                    foreach (string identity in new[] { worldKey, playerId }) { byte[] bytes = Utf8.GetBytes(identity); writer.Write(bytes.Length); writer.Write(bytes); }
                return Hash(data.ToArray());
            }
        }
        private static string Hash(byte[] bytes)
        { using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
        private FileStream Lock()
        {
            Directory.CreateDirectory(root); var timer = Stopwatch.StartNew();
            while (true)
            {
                try { return new FileStream(Path.Combine(root, ".store.lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None); }
                catch (IOException) { if (timer.ElapsedMilliseconds > 1000) throw; Thread.Sleep(10); }
            }
        }
        private void SaveCore(string path, string json, byte[] bytes)
        {
            Directory.CreateDirectory(active); string temporary = Path.Combine(active, "." + Guid.NewGuid().ToString("N", CultureInfo.InvariantCulture) + ".tmp");
            try
            {
                using (var file = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None)) { file.Write(bytes, 0, bytes.Length); file.Flush(true); }
                if (File.Exists(path)) File.Replace(temporary, path, null); else File.Move(temporary, path);
            }
            finally { if (File.Exists(temporary)) File.Delete(temporary); }
        }
        private void ArchiveLegacy(string key, byte[] expected)
        {
            if (!File.Exists(legacyPath) || !ReadBounded(legacyPath).SequenceEqual(expected)) { log("Legacy recovery changed during migration; it remains available."); return; }
            Directory.CreateDirectory(archive); string target = Path.Combine(archive, "legacy-" + key + "-" + Hash(expected) + ".json");
            if (File.Exists(target))
            {
                if (!ReadBounded(target).SequenceEqual(expected)) throw new IOException("An archive collision was preserved for inspection.");
                File.Delete(legacyPath);
            }
            else File.Move(legacyPath, target);
        }
    }
}
