using UnityEngine;

namespace BlackAbbeySixRooms
{
    internal sealed partial class WardingSpawnerActors
    {
        bool ResumeOnReadyFloor(WardingActorRecord record,ZDO zdo,Character actor)
        {
            if(!Matches(zdo,record)||!actor)return false;
            if(!DungeonActorResidency.Held(actor.gameObject)&&actor.gameObject.activeSelf&&RuntimeTestPlugin.DungeonActorPositionValid(worldKey,runId,actor.transform.position))return true;
            DungeonActorResidency.Park(actor.gameObject,zdo);
            if(!TryRestorationLanding(record,zdo,actor.gameObject,out var landing))return false;
            var rotation=record.rotation!=null?new Quaternion(record.rotation[0],record.rotation[1],record.rotation[2],record.rotation[3]).normalized:zdo.GetRotation();
            if(!DungeonActorResidency.Resume(actor.gameObject,zdo,worldKey,runId,landing,rotation,true))return false;
            record.position=V(landing);record.rotation=Q(rotation);
            log?.Invoke("WARD_ACTOR_FLOOR_RESUME: "+record.key+"; exact UID="+zdo.m_uid+"; health/effects/journey retained.");return true;
        }
        bool TryRestorationLanding(WardingActorRecord record,ZDO zdo,GameObject proxy,out Vector3 landing)
        {
            bool supported=RuntimeTestPlugin.TryDungeonActorLanding(worldKey,runId,proxy,zdo.GetPosition(),out landing);
            if(!supported&&record.position!=null)supported=RuntimeTestPlugin.TryDungeonActorLanding(worldKey,runId,proxy,V(record.position),out landing);
            var anchor=recoveryAnchor?.Invoke(record.productionSourceId??record.sourceId);
            if(!supported&&anchor.HasValue)
            {
                // Recover already-fallen produced actors near their own source,
                // preserving journey/status/health. Occupied spots wait and retry.
                foreach(float forward in new[]{0f,1f,-1f,2f,-2f})
                {
                    foreach(float side in new[]{0f,.9f,-.9f,1.5f,-1.5f})
                    {
                        var point=anchor.Value+new Vector3(side,.1f,forward);
                        if(RuntimeTestPlugin.TryDungeonActorLanding(worldKey,runId,proxy,point,out landing)){supported=true;break;}
                    }
                    if(supported)break;
                }
            }
            return supported;
        }

    }
}
