namespace BlackAbbeySixRooms
{
    // One reviewed material-only R06 revision. This never rewrites a saved
    // catalog identity, changes room geometry, or accepts an unknown asset.
    internal static class DungeonAssetRevision
    {
        internal const string BeforeCatalog = "2074b1a5445f7821713596d00da614cd10d7a64018059577e996ffa727990c4f";
        internal const string MaterialOnlyCatalog = "d70381e5a1bb88c107f5987ce9833dfdeb5a8fe2b45142a7ee4f47eb98a721af";
        internal const string BeforeVestry = "ad00295b0fa44f0c41b48b0e9afaf20e653bd86df4f7893801539b5af52917e5";
        internal const string MaterialOnlyVestry = "b1e34617e2e0622d0a3540747abdfcd1b3ff9a60119cd79453281364a6320a54";
        internal const string VestrySource = "7fc31f189adb4b349a512264cf4ea5e11629a6693905071e342901e74631e323";

        internal static bool CatalogMatches(string saved, string current) =>
            CatalogReader.Hash(saved) && CatalogReader.Hash(current) &&
            (saved == current || saved == BeforeCatalog && current == MaterialOnlyCatalog);

        internal static bool ManifestMatches(string room, string expected, string current,
            string expectedSource, string actualSource, int maskCount)
        {
            if (!CatalogReader.Hash(expected) || !CatalogReader.Hash(current) ||
                !CatalogReader.Hash(expectedSource) || expectedSource != actualSource || maskCount < 0) return false;
            if (expected == current) return true;
            // The R06 quest record owns no triangles. A nonempty mask must
            // still match its original exact manifest and triangle ownership.
            return room == "R06" && expected == BeforeVestry && current == MaterialOnlyVestry &&
                actualSource == VestrySource && maskCount == 0;
        }
    }
}
