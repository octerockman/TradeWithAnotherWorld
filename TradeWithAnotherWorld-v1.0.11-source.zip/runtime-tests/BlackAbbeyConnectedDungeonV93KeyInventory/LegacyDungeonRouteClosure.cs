using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Bounded, two-frontier search over the actual authored room/socket
    // transforms. Routes are discovered from geometry, never from room-name
    // rectangles. The only closing bridge is the ordinary 20mm source join.
    internal static class LegacyDungeonRouteClosure
    {
        internal const int MinimumCycleRooms=6,MaximumHalfRooms=3,MaximumHalfPaths=12000;
        private sealed class Shape
        {
            internal DungeonRoomSpec[] Instances;
            internal DungeonRoomSpec Source;
        }
        private sealed class Step
        {
            internal int Shape;
            internal string Entry,Exit;
        }
        private sealed class Path
        {
            internal Step[] Steps;
            internal int[] Counts;
            internal PlanPoint End,Normal;
            internal double Height;
        }
        private sealed class Transition
        {
            internal Step Step;
            internal PlanPoint End,Normal;
            internal double[] Bounds;
        }
        private static readonly Dictionary<string,Path[]> libraries=new Dictionary<string,Path[]>(StringComparer.Ordinal);
        private static readonly Dictionary<string,Path[]> availableLibraries=new Dictionary<string,Path[]>(StringComparer.Ordinal);
        private static readonly object libraryLock=new object();
        private sealed class Search
        {
            internal int Budget;
            internal Random Random;
            internal DungeonPlanningDiagnostics Diagnostics;
            internal Shape[] Shapes;
            internal Path[] Routes;
        }
        private static string Number(double x)=>x.ToString("R",CultureInfo.InvariantCulture);
        private static string ShapeKey(DungeonRoomSpec s)=>string.Join("/",s.Bounds.Concat(s.BoundsY).Select(Number))+"|"+
            string.Join(";",s.Ports.Select(p=>p.id+":"+string.Join(",",p.position.Concat(p.outward).Select(v=>Number(v)))+":"+Number(p.depth)+":"+Number(p.width)+":"+Number(p.height)));
        private readonly struct PoseKey:IEquatable<PoseKey>
        {
            private readonly long x,z,y;private readonly int nx,nz;
            internal PoseKey(PlanPoint p,PlanPoint n,double height){x=(long)Math.Round(p.X*10000);z=(long)Math.Round(p.Z*10000);y=(long)Math.Round(height*10000);nx=(int)Math.Round(n.X);nz=(int)Math.Round(n.Z);}
            public bool Equals(PoseKey other)=>x==other.x&&z==other.z&&y==other.y&&nx==other.nx&&nz==other.nz;
            public override bool Equals(object other)=>other is PoseKey key&&Equals(key);
            public override int GetHashCode(){unchecked{int h=x.GetHashCode();h=h*397^z.GetHashCode();h=h*397^y.GetHashCode();h=h*397^nx;return h*397^nz;}}
            public override string ToString()=>x+","+z+","+y+","+nx+","+nz;
        }
        private static PoseKey Pose(PlanPoint p,PlanPoint n,double y)=>new PoseKey(p,n,y);
        private static void Shuffle<T>(IList<T> values,Random random)
        {for(int i=values.Count-1;i>0;i--){int j=random.Next(i+1);T v=values[i];values[i]=values[j];values[j]=v;}}
        private static bool Used(List<DungeonLink> links,int room,PortRecord port)=>links.Any(l=>l.A==room&&l.PortA.id==port.id||l.B==room&&l.PortB.id==port.id);

        internal static int Distance(int a,int b,int count,List<DungeonLink> links,int skip=-1)
        {
            var distances=Enumerable.Repeat(-1,count).ToArray();var queue=new Queue<int>();distances[a]=0;queue.Enqueue(a);
            while(queue.Count>0)
            {
                int node=queue.Dequeue();if(node==b)return distances[node];
                for(int i=0;i<links.Count;i++)
                {if(i==skip)continue;var edge=links[i];int other=edge.A==node?edge.B:edge.B==node?edge.A:-1;if(other>=0&&distances[other]<0){distances[other]=distances[node]+1;queue.Enqueue(other);}}
            }
            return -1;
        }
        internal static HashSet<int> CycleVertices(int count,List<DungeonLink> links)
        {
            var result=new HashSet<int>();
            for(int i=0;i<links.Count;i++)if(Distance(links[i].A,links[i].B,count,links,i)>=0){result.Add(links[i].A);result.Add(links[i].B);}
            return result;
        }
        private static double[] TransformBounds(double[] b,PlanPoint origin,int q)
        {
            switch(q){case 1:return new[]{origin.X+b[1],origin.Z-b[2],origin.X+b[3],origin.Z-b[0]};case 2:return new[]{origin.X-b[2],origin.Z-b[3],origin.X-b[0],origin.Z-b[1]};case 3:return new[]{origin.X-b[3],origin.Z+b[0],origin.X-b[1],origin.Z+b[2]};default:return new[]{origin.X+b[0],origin.Z+b[1],origin.X+b[2],origin.Z+b[3]};}
        }
        private static void ExploreAbstract(Transition[] transitions,PlanPoint position,PlanPoint normal,List<Step> steps,int[] used,List<double[]> envelopes,List<Path> output)
        {
            if(output.Count>=MaximumHalfPaths)return;
            output.Add(new Path{Steps=steps.ToArray(),Counts=(int[])used.Clone(),End=position,Normal=normal});
            if(steps.Count==MaximumHalfRooms)return;
            int rotation=Enumerable.Range(0,4).First(q=>(PlanPoint.Rotate(new PlanPoint(0,1),q)-normal).Length<.001);
            foreach(var transition in transitions)
            {
                var envelope=TransformBounds(transition.Bounds,position,rotation);
                if(envelopes.Any(b=>LegacyDungeonLayoutPlanner.Overlap(b,envelope)))continue;
                used[transition.Step.Shape]++;steps.Add(transition.Step);
                envelopes.Add(envelope);
                ExploreAbstract(transitions,position+PlanPoint.Rotate(transition.End,rotation),PlanPoint.Rotate(transition.Normal,rotation),steps,used,envelopes,output);
                envelopes.RemoveAt(envelopes.Count-1);steps.RemoveAt(steps.Count-1);used[transition.Step.Shape]--;
            }
        }
        private static Path[] Library(Shape[] shapes,out string key)
        {
            key=string.Join("#",shapes.Select(s=>ShapeKey(s.Source)));
            lock(libraryLock)
            {
                if(libraries.TryGetValue(key,out var cached))return cached;
                var transitions=new List<Transition>();
                for(int i=0;i<shapes.Length;i++)
                {
                    var source=shapes[i].Source;var seen=new HashSet<string>(StringComparer.Ordinal);
                    foreach(var entry in source.Ports)foreach(var exit in source.Ports)
                    {
                        if(entry==exit)continue;
                        int q=Enumerable.Range(0,4).First(r=>(PlanPoint.Rotate(new PlanPoint(entry.outward[0],entry.outward[2]),r)+new PlanPoint(0,1)).Length<.001);
                        var room=new DungeonPlacement{Spec=source,QuarterTurns=q};
                        room.Position=new PlanPoint(0,LegacyDungeonLayoutPlanner.JointClearance)-room.Outer(entry);
                        var end=room.Outer(exit);var normal=room.Normal(exit);
                        string signature=Pose(end,normal,0)+"|"+string.Join(",",room.Envelope().Select(Number));
                        if(seen.Add(signature))transitions.Add(new Transition{Step=new Step{Shape=i,Entry=entry.id,Exit=exit.id},End=end,Normal=normal,Bounds=room.Envelope()});
                    }
                }
                var paths=new List<Path>();ExploreAbstract(transitions.ToArray(),new PlanPoint(0,0),new PlanPoint(0,1),new List<Step>(),new int[shapes.Length],new List<double[]>(),paths);
                // The finite cache holds only pure immutable geometry routes,
                // never room instances, Unity objects or candidate world state.
                if(libraries.Count>=8){libraries.Clear();availableLibraries.Clear();}return libraries[key]=paths.ToArray();
            }
        }
        private static Path[] AvailableRoutes(Shape[] shapes)
        {
            var library=Library(shapes,out string geometry);
            string key=geometry+"@"+string.Join(",",shapes.Select(s=>Math.Min(MaximumHalfRooms,s.Instances.Length)));
            lock(libraryLock)
            {
                if(availableLibraries.TryGetValue(key,out var cached))return cached;
                var output=new List<Path>();
                foreach(var path in library)
                {
                    bool okay=true;for(int i=0;i<shapes.Length;i++)if(path.Counts[i]>shapes[i].Instances.Length){okay=false;break;}
                    if(okay)output.Add(path);
                }
                // These subsets share the one immutable path/step inventory;
                // they add only bounded arrays of references, not route copies.
                if(availableLibraries.Count>=128)availableLibraries.Clear();return availableLibraries[key]=output.ToArray();
            }
        }
        private static List<Path> Paths(Search search,int room,PortRecord port,List<DungeonPlacement> placed,List<DungeonLink> links)
        {
            var origin=placed[room];var normal=origin.Normal(port);int rotation=Enumerable.Range(0,4).First(q=>(PlanPoint.Rotate(new PlanPoint(0,1),q)-normal).Length<.001);
            var output=new List<Path>();
            foreach(var route in search.Routes)
            {
                output.Add(new Path{Steps=route.Steps,Counts=route.Counts,End=origin.Outer(port)+PlanPoint.Rotate(route.End,rotation),Normal=PlanPoint.Rotate(route.Normal,rotation),Height=origin.Height(port.position)});
            }
            Shuffle(output,search.Random);return output.OrderBy(p=>p.Steps.Length).ToList();
        }
        private static bool ApplyPath(Path path,int start,PortRecord open,Search search,List<DungeonPlacement> placed,List<DungeonLink> links,HashSet<string> assigned,out int end,out PortRecord endPort)
        {
            end=start;endPort=open;
            foreach(var step in path.Steps)
            {
                var source=search.Shapes[step.Shape].Instances.FirstOrDefault(s=>!assigned.Contains(s.Id));if(source==null)return false;
                var entry=source.Ports.Single(p=>p.id==step.Entry);var exit=source.Ports.Single(p=>p.id==step.Exit);
                if(!LegacyDungeonLayoutPlanner.TryPlacement(source,end,endPort,entry,placed,links,search.Diagnostics,out var next,out var link))return false;
                end=placed.Count;endPort=exit;placed.Add(next);links.Add(link);assigned.Add(source.Id);
            }
            return true;
        }
        private static bool Join(int a,PortRecord ap,int b,PortRecord bp,List<DungeonPlacement> placed,List<DungeonLink> links)
        {
            if(a==b||Used(links,a,ap)||Used(links,b,bp)||Distance(a,b,placed.Count,links)+1<MinimumCycleRooms)return false;
            string family=LegacyNaturalDungeonRoster.Family(placed[a].Spec.SourceId);
            if(family==LegacyNaturalDungeonRoster.Family(placed[b].Spec.SourceId))
            {
                // A new edge must not close a same-family subcycle, even when
                // a different, mixed shortest path also exists in the graph.
                var visited=new HashSet<int>{a};var queue=new Queue<int>();queue.Enqueue(a);
                while(queue.Count>0)
                {
                    int node=queue.Dequeue();if(node==b)return false;
                    foreach(var branch in links){int other=branch.A==node?branch.B:branch.B==node?branch.A:-1;if(other>=0&&LegacyNaturalDungeonRoster.Family(placed[other].Spec.SourceId)==family&&visited.Add(other))queue.Enqueue(other);}
                }
            }
            var left=placed[a];var right=placed[b];var edge=new DungeonLink{A=a,B=b,PortA=ap,PortB=bp,Start=left.Outer(ap),End=right.Outer(bp),Elevation=left.Height(ap.position),IsLoop=true};
            if((left.Normal(ap)+right.Normal(bp)).Length>.001||Math.Abs(edge.Elevation-right.Height(bp.position))>.0001||
                (edge.End-edge.Start-left.Normal(ap)*LegacyDungeonLayoutPlanner.JointClearance).Length>.0001)return false;
            var box=edge.Envelope();
            if(placed.Where((p,i)=>i!=a&&i!=b).Any(p=>LegacyDungeonLayoutPlanner.Overlap3D(box,edge.LowY,edge.HighY,p.Envelope(),p.LowY,p.HighY))||
                links.Any(l=>LegacyDungeonLayoutPlanner.Overlap3D(box,edge.LowY,edge.HighY,l.Envelope(),l.LowY,l.HighY)))return false;
            links.Add(edge);return true;
        }
        internal static bool TryClose(List<DungeonRoomSpec> pool,List<DungeonPlacement> placed,List<DungeonLink> links,string entrance,Random random,ref int budget,DungeonPlanningDiagnostics diagnostics,int firstAnchor=-1,int secondAnchor=-1,bool needsFurtherCycle=false,Func<int,int> continuation=null,DungeonRoomSpec[] canonical=null)
        {
            // Use the complete canonical shape set for one reusable library;
            // available instance counts are filtered separately, including zero.
            var shapes=(canonical??pool.ToArray()).Where(s=>s.Ports.Length>=2&&s.SourceId!="R08").GroupBy(ShapeKey).OrderBy(g=>g.Key,StringComparer.Ordinal)
                .Select(g=>new Shape{Source=g.First(),Instances=pool.Where(s=>g.Any(c=>c.SourceId==s.SourceId)).ToArray()}).ToArray();
            var search=new Search{Budget=budget,Random=random,Diagnostics=diagnostics,Shapes=shapes};
            search.Routes=AvailableRoutes(shapes);
            var cyclic=CycleVertices(placed.Count,links);var pairs=new List<Tuple<int,PortRecord,int,PortRecord>>();
            for(int i=0;i<placed.Count;i++)if(firstAnchor>=0?i==firstAnchor:cyclic.Contains(i))
                foreach(var a in placed[i].Spec.Ports)if(!(i==0&&a.id==entrance)&&!Used(links,i,a))
                    for(int j=0;j<placed.Count;j++)if(j!=i&&(secondAnchor>=0?j==secondAnchor:cyclic.Contains(j)))
                        foreach(var b in placed[j].Spec.Ports)if(!Used(links,j,b)&&Math.Abs(placed[i].Height(a.position)-placed[j].Height(b.position))<.0001)
                            pairs.Add(Tuple.Create(i,a,j,b));
            Shuffle(pairs,random);
            var pathsByPort=new Dictionary<Tuple<int,string>,List<Path>>();
            var indexesByPort=new Dictionary<Tuple<int,string>,Dictionary<PoseKey,List<Path>>>();
            foreach(var pair in pairs)
            {
                if(--search.Budget<=0){search.Budget=0;break;}diagnostics.RouteAttempts++;
                var rightKey=Tuple.Create(pair.Item3,pair.Item4.id);
                if(!indexesByPort.TryGetValue(rightKey,out var index))
                {
                    var right=Paths(search,pair.Item3,pair.Item4,placed,links);index=new Dictionary<PoseKey,List<Path>>();
                    foreach(var path in right){var key=Pose(path.End,path.Normal,path.Height);if(!index.TryGetValue(key,out var group))index[key]=group=new List<Path>();if(group.Count<48)group.Add(path);}
                    indexesByPort[rightKey]=index;
                }
                var leftKey=Tuple.Create(pair.Item1,pair.Item2.id);
                if(!pathsByPort.TryGetValue(leftKey,out var left))pathsByPort[leftKey]=left=Paths(search,pair.Item1,pair.Item2,placed,links);
                int baseDistance=Distance(pair.Item1,pair.Item3,placed.Count,links);
                foreach(var a in left)
                {
                    if(search.Budget<=0)break;
                    if(!index.TryGetValue(Pose(a.End+a.Normal*LegacyDungeonLayoutPlanner.JointClearance,a.Normal*-1,a.Height),out var matches))continue;
                    foreach(var b in matches)
                    {
                        bool inventory=true;for(int i=0;i<shapes.Length;i++)if(a.Counts[i]+b.Counts[i]>shapes[i].Instances.Length){inventory=false;break;}
                        if(!inventory||baseDistance+a.Steps.Length+b.Steps.Length+1<MinimumCycleRooms)continue;
                        if(--search.Budget<=0){search.Budget=0;break;}diagnostics.RouteMatches++;
                        int rooms=placed.Count,edges=links.Count;var assigned=new HashSet<string>(StringComparer.Ordinal);
                        bool okay=ApplyPath(a,pair.Item1,pair.Item2,search,placed,links,assigned,out int ai,out var ap)&&
                            ApplyPath(b,pair.Item3,pair.Item4,search,placed,links,assigned,out int bi,out var bp)&&Join(ai,ap,bi,bp,placed,links);
                        if(okay&&needsFurtherCycle)
                        {
                            var vertices=CycleVertices(placed.Count,links);
                            okay=vertices.Count(v=>placed[v].Spec.Ports.Any(p=>!Used(links,v,p)))>=2;
                        }
                        if(okay)
                        {
                            var before=pool.ToArray();pool.RemoveAll(s=>assigned.Contains(s.Id));
                            int remaining=continuation==null?search.Budget:continuation(search.Budget);
                            if(remaining>=0){diagnostics.MaximumPlaced=Math.Max(diagnostics.MaximumPlaced,placed.Count);budget=remaining;return true;}
                            // A valid first closure may consume the only route
                            // pieces needed by the next cycle. Backtrack that
                            // decision, not the whole unrelated entrance route.
                            search.Budget=-remaining-1;pool.Clear();pool.AddRange(before);
                        }
                        if(links.Count>edges)links.RemoveRange(edges,links.Count-edges);if(placed.Count>rooms)placed.RemoveRange(rooms,placed.Count-rooms);
                    }
                }
            }
            budget=search.Budget;if(budget<=0)diagnostics.BudgetExhaustions++;return false;
        }
    }
}
