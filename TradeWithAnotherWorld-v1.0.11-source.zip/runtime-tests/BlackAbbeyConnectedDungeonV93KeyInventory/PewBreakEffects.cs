using System;
using System.Collections.Generic;
using Jotunn.Managers;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // Meshes/materials belong to the room's existing shared-resource leases.
    // The effect owns only transient GameObjects and never mutates source data.
    internal struct PewDebrisPart
    {
        internal Mesh Mesh;
        internal Material Material;
        internal Vector3 LocalPosition;
    }

    internal static class PewBreakEffects
    {
        internal const int MaximumPartsPerBreak = 24, MaximumActiveParts = 72, MaximumAudioVoices = 4;
        internal const float FragmentLifetime = 20f;
        private static readonly List<PewDebrisMotion> activeParts = new List<PewDebrisMotion>(MaximumActiveParts);
        private static readonly List<PewWoodAudioVoice> activeVoices = new List<PewWoodAudioVoice>(MaximumAudioVoices);
        private static WoodCue cue;
        private static bool audioAbsenceReported;
        private static float nextResolve;

        private sealed class WoodCue
        {
            internal AudioClip[] Clips;
            internal AudioMixerGroup Mixer;
            internal float MinVolume, MaxVolume, MinPitch, MaxPitch;
            internal string Source;
            internal float NextDataRequest;
            internal bool Alive
            {
                get
                {
                    if (!Mixer || Clips == null || Clips.Length == 0) return false;
                    foreach (var clip in Clips) if (!clip) return false;
                    return true;
                }
            }
        }

        internal static void Prepare(Action<string> log)
        {
            // Resolve/request native audio during room setup, never queue an
            // old break cue to play later after decoding finishes.
            if (!TryResolveCue(log) || Time.realtimeSinceStartup < cue.NextDataRequest) return;
            cue.NextDataRequest = Time.realtimeSinceStartup + 2f;
            try
            {
                foreach (var clip in cue.Clips)
                    if (clip && (clip.loadState == AudioDataLoadState.Unloaded || clip.loadState == AudioDataLoadState.Failed))
                        clip.LoadAudioData();
            }
            catch (Exception ex)
            {
                if (!audioAbsenceReported)
                {
                    audioAbsenceReported = true;
                    log?.Invoke("ABBEY_PEW_WOOD_AUDIO_UNAVAILABLE: " + ex.GetType().Name + ": " + ex.Message + "; audio data preparation omitted, break remains available.");
                }
            }
        }

        internal static void Emit(Transform owner, Vector3 worldOrigin, Vector3 worldDirection, PewDebrisPart[] pieces, Action<string> log, float floorBaseY = float.NaN)
        {
            if (!owner || !owner.parent || !owner.gameObject.activeInHierarchy) return;
            var room = owner.parent;
            // Source fragments are expressed in the original room-space pew
            // coordinates. Added nave owners apply translation/yaw/length scale.
            // Effects live under the room so breaking/deactivating that owner
            // cannot hide the transient pieces or move them to the old alcove.
            var baseScale = owner.localScale;
            var baseRotation = owner.localRotation;
            if (pieces == null) pieces = Array.Empty<PewDebrisPart>();
            int count = Math.Min(pieces.Length, MaximumPartsPerBreak);
            float floor = Finite(floorBaseY) ? floorBaseY : float.PositiveInfinity;
            if (!Finite(floorBaseY))
                for (int i = 0; i < count; ++i)
                    if (pieces[i].Mesh && pieces[i].Material && Finite(pieces[i].LocalPosition))
                        floor = Mathf.Min(floor, room.InverseTransformPoint(owner.TransformPoint(pieces[i].LocalPosition)).y + pieces[i].Mesh.bounds.min.y * baseScale.y);
            if (!float.IsPositiveInfinity(floor))
            {
                floor += .04f;
                var direction = room.InverseTransformDirection(Finite(worldDirection) ? worldDirection : Vector3.zero);
                direction.y = 0;
                if (direction.sqrMagnitude > .0001f) direction.Normalize();
                for (int i = 0; i < count; ++i)
                {
                    var part = pieces[i];
                    if (!part.Mesh || !part.Material || !Finite(part.LocalPosition)) continue;
                    PruneParts();
                    while (activeParts.Count >= MaximumActiveParts)
                    {
                        var oldest = activeParts[0]; activeParts.RemoveAt(0);
                        if (oldest) oldest.Retire();
                    }
                    var node = new GameObject("Abbey pew wood fragment"); node.SetActive(false);
                    node.transform.SetParent(room, false);
                    node.transform.localPosition = room.InverseTransformPoint(owner.TransformPoint(part.LocalPosition));
                    node.transform.localRotation = baseRotation; node.transform.localScale = baseScale;
                    var filter = node.AddComponent<MeshFilter>(); filter.sharedMesh = part.Mesh;
                    var renderer = node.AddComponent<MeshRenderer>(); renderer.sharedMaterial = part.Material;
                    renderer.shadowCastingMode = ShadowCastingMode.Off; renderer.receiveShadows = false;
                    var motion = node.AddComponent<PewDebrisMotion>();
                    var spread = new Vector3(UnityEngine.Random.Range(-.75f, .75f), UnityEngine.Random.Range(.55f, 1.25f), UnityEngine.Random.Range(-.75f, .75f));
                    motion.Configure(part.Mesh.bounds, floor, direction * UnityEngine.Random.Range(.5f, 1.3f) + spread,PewRefinementPolicy.Lifetime(i));
                    activeParts.Add(motion); node.SetActive(true);
                }
            }
            TryPlayWoodCue(room, worldOrigin, log);
        }

        private static bool Finite(Vector3 p) => Finite(p.x) && Finite(p.y) && Finite(p.z);
        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        private static void PruneParts() { for (int i = activeParts.Count - 1; i >= 0; --i) if (!activeParts[i]) activeParts.RemoveAt(i); }
        private static void PruneVoices() { for (int i = activeVoices.Count - 1; i >= 0; --i) if (!activeVoices[i]) activeVoices.RemoveAt(i); }

        private static void TryPlayWoodCue(Transform room, Vector3 position, Action<string> log)
        {
            try
            {
                if (!TryResolveCue(log)) return;
                var clip = cue.Clips[UnityEngine.Random.Range(0, cue.Clips.Length)];
                if (clip.loadState != AudioDataLoadState.Loaded) { Prepare(log); return; }
                PruneVoices();
                while (activeVoices.Count >= MaximumAudioVoices)
                {
                    var oldest = activeVoices[0]; activeVoices.RemoveAt(0);
                    if (oldest) oldest.Retire();
                }
                var node = new GameObject("Abbey pew native wood break audio"); node.SetActive(false);
                node.transform.SetParent(room, false); node.transform.position = position;
                var audio = node.AddComponent<AudioSource>(); audio.playOnAwake = false; audio.loop = false;
                audio.clip = clip;
                audio.outputAudioMixerGroup = cue.Mixer;
                audio.volume = UnityEngine.Random.Range(cue.MinVolume, cue.MaxVolume);
                audio.pitch = UnityEngine.Random.Range(cue.MinPitch, cue.MaxPitch);
                audio.spatialBlend = 1; audio.rolloffMode = AudioRolloffMode.Linear;
                audio.minDistance = 2; audio.maxDistance = 22; audio.dopplerLevel = 0; audio.spread = 0; audio.priority = 72;
                var voice = node.AddComponent<PewWoodAudioVoice>(); voice.Configure(audio);
                activeVoices.Add(voice); node.SetActive(true); audio.Play();
            }
            catch (Exception ex)
            {
                cue = null; nextResolve = Time.realtimeSinceStartup + 2f;
                if (!audioAbsenceReported)
                {
                    audioAbsenceReported = true;
                    log?.Invoke("ABBEY_PEW_WOOD_AUDIO_UNAVAILABLE: " + ex.GetType().Name + ": " + ex.Message + "; break remains available.");
                }
            }
        }

        private static bool TryResolveCue(Action<string> log)
        {
            if (cue != null && cue.Alive) return true;
            if (Time.realtimeSinceStartup < nextResolve) return false;
            nextResolve = Time.realtimeSinceStartup + 2f;
            try
            {
                cue = ResolveWoodCue();
                if (cue == null)
                {
                    if (!audioAbsenceReported)
                    {
                        audioAbsenceReported = true;
                        log?.Invoke("ABBEY_PEW_WOOD_AUDIO_UNAVAILABLE: no playable registered wooden furniture destruction cue with native SFX mixer; furniture break remains available.");
                    }
                    return false;
                }
                audioAbsenceReported = false;
                log?.Invoke("ABBEY_PEW_WOOD_AUDIO_BOUND: " + cue.Source + "; mixer=" + cue.Mixer.name + "; borrowed native clips; voices<=4; no prefab/network clone.");
                return true;
            }
            catch (Exception ex)
            {
                cue = null;
                if (!audioAbsenceReported)
                {
                    audioAbsenceReported = true;
                    log?.Invoke("ABBEY_PEW_WOOD_AUDIO_UNAVAILABLE: " + ex.GetType().Name + ": " + ex.Message + "; break remains available.");
                }
                return false;
            }
        }

        private static WoodCue ResolveWoodCue()
        {
            if (PrefabManager.Instance == null) return null;
            // Borrow only cues from an actual registered wooden furniture/piece
            // destruction list. Neither a furniture prefab nor its effects spawn.
            foreach (string id in new[] { "piece_bench01", "piece_bench02", "piece_chair", "piece_chair02", "wood_floor", "wood_wall_half" })
            {
                var prefab = PrefabManager.Instance.GetPrefab(id); if (!prefab) continue;
                var wear = prefab.GetComponent<WearNTear>();
                var destructible = prefab.GetComponent<Destructible>();
                var effects = wear ? wear.m_destroyedEffect : destructible ? destructible.m_destroyedEffect : null;
                if (effects?.m_effectPrefabs == null) continue;
                foreach (var effect in effects.m_effectPrefabs)
                {
                    if (effect == null || !effect.m_enabled || !effect.m_prefab) continue;
                    foreach (var sound in effect.m_prefab.GetComponentsInChildren<ZSFX>(true))
                    {
                        if (!sound || sound.m_audioClips == null) continue;
                        var template = sound.GetComponent<AudioSource>();
                        if (!template || !Finite(sound.m_minVol) || !Finite(sound.m_maxVol) ||
                            !Finite(sound.m_minPitch) || !Finite(sound.m_maxPitch) || sound.m_minVol < 0 || sound.m_maxVol < sound.m_minVol ||
                            sound.m_minPitch <= 0 || sound.m_maxPitch < sound.m_minPitch) continue;
                        var clips = new List<AudioClip>();
                        foreach (var clip in sound.m_audioClips) if (clip && clip.length > 0 && !clips.Contains(clip)) clips.Add(clip);
                        if (clips.Count == 0) continue;
                        var mixer = ResolveSfxMixer(template);
                        if (!mixer) continue;
                        return new WoodCue { Clips = clips.ToArray(), Mixer = mixer,
                            MinVolume = sound.m_minVol, MaxVolume = sound.m_maxVol,
                            MinPitch = sound.m_minPitch, MaxPitch = sound.m_maxPitch,
                            Source = id + "/" + effect.m_prefab.name + "/" + sound.name };
                    }
                }
            }
            return null;
        }

        private static AudioMixerGroup ResolveSfxMixer(AudioSource template)
        {
            var direct = template ? template.outputAudioMixerGroup : null;
            if (direct && AbbeyAmbiencePolicy.IsDungeonOutputGroup(direct.name)) return direct;
            // Native effect templates can leave the group null. Reuse the
            // same audible native SFX resolution as the candle catches.
            foreach (string id in new[] { R07StoneAudio.SlidePrefab, R07StoneAudio.ImpactPrefab })
            {
                var prefab = PrefabManager.Instance.GetPrefab(id);
                var source = prefab ? prefab.GetComponentInChildren<AudioSource>(true) : null;
                var candidate = source ? source.outputAudioMixerGroup : null;
                if (candidate && AbbeyAmbiencePolicy.IsDungeonOutputGroup(candidate.name)) return candidate;
            }
            var ambient = AudioMan.instance ? AudioMan.instance.m_ambientMixer : null;
            if (ambient && ambient.audioMixer)
                foreach (var group in ambient.audioMixer.FindMatchingGroups("SFX"))
                    if (group && AbbeyAmbiencePolicy.IsDungeonOutputGroup(group.name)) return group;
            return null;
        }

        internal static void ForgetPart(PewDebrisMotion part) => activeParts.Remove(part);
        internal static void ForgetVoice(PewWoodAudioVoice voice) => activeVoices.Remove(voice);
    }

    internal sealed class PewDebrisMotion : MonoBehaviour
    {
        private Bounds bounds;
        private Vector3 velocity, angularVelocity, baseScale;
        private float floor, age, lifetime;
        private bool resting;
        private bool retired;
        internal void Configure(Bounds originalBounds, float floorHeight, Vector3 initialVelocity,float lifetime)
        {
            bounds = originalBounds; floor = floorHeight; velocity = initialVelocity; baseScale = transform.localScale;this.lifetime=lifetime;
            angularVelocity = new Vector3(UnityEngine.Random.Range(-150f, 150f), UnityEngine.Random.Range(-120f, 120f), UnityEngine.Random.Range(-150f, 150f));
        }
        private void Update()
        {
            if (retired) return;
            float dt = Mathf.Min(Time.deltaTime, .05f); age += Time.deltaTime;
            if (age >= lifetime) { Retire(); return; }
            if(resting&&age<lifetime-.8f)return;
            velocity.y -= 7.5f * dt;
            var position = transform.localPosition + velocity * dt;
            var rotation = Quaternion.Euler(angularVelocity * dt) * transform.localRotation;
            float scale = Mathf.Clamp01((lifetime - age) / .8f);
            var extents = Vector3.Scale(bounds.extents, baseScale);
            float height = (Mathf.Abs((rotation * Vector3.right).y) * extents.x + Mathf.Abs((rotation * Vector3.up).y) * extents.y + Mathf.Abs((rotation * Vector3.forward).y) * extents.z) * scale;
            float bottom = position.y + (rotation * Vector3.Scale(bounds.center, baseScale)).y * scale - height;
            if (bottom < floor)
            {
                position.y += floor - bottom; velocity.y = 0;
                velocity.x *= Mathf.Max(0, 1 - dt * 7); velocity.z *= Mathf.Max(0, 1 - dt * 7);
                angularVelocity = Vector3.zero;
                if(velocity.sqrMagnitude<.003f)resting=true;
            }
            transform.localPosition = position; transform.localRotation = rotation; transform.localScale = baseScale * scale;
        }
        internal void Retire()
        {
            if (retired) return; retired = true;
            PewBreakEffects.ForgetPart(this);
            if (gameObject) { gameObject.SetActive(false); Object.Destroy(gameObject); }
        }
        private void OnDisable() => Retire();
        private void OnDestroy() { retired = true; PewBreakEffects.ForgetPart(this); }
    }

    internal sealed class PewWoodAudioVoice : MonoBehaviour
    {
        private AudioSource source;
        private float age;
        private bool retired;
        internal void Configure(AudioSource audio) { source = audio; }
        private void Update()
        {
            age += Time.deltaTime;
            if (!source || age > 8 || age > .1f && !source.isPlaying) Retire();
        }
        internal void Retire()
        {
            if (retired) return; retired = true;
            PewBreakEffects.ForgetVoice(this);
            if (source) source.Stop();
            if (gameObject) { gameObject.SetActive(false); Object.Destroy(gameObject); }
        }
        private void OnDisable() => Retire();
        private void OnDestroy() { retired = true; PewBreakEffects.ForgetVoice(this); }
    }
}
