using System;
using System.Collections.Generic;
using System.IO;
namespace BlackAbbeySixRooms
{
    // A newly exported block must already be closed. This validates topology;
    // it never invents caps, reslices old atlases or manufactures replacement stones.
    internal static class MappedWallStoneGeometry
    {
        internal static void RequireClosed(float[][] vertices,int[] indices)
        {
            if(vertices==null||vertices.Length<4||vertices.Length>65536||indices==null||indices.Length<12||indices.Length%3!=0||indices.Length>196608)throw new InvalidDataException("Invalid mapped rubble block inventory.");
            var welded=new Dictionary<string,int>(StringComparer.Ordinal);var ids=new int[vertices.Length];
            for(int i=0;i<vertices.Length;i++)
            {
                var v=vertices[i];if(v==null||v.Length<3||float.IsNaN(v[0])||float.IsNaN(v[1])||float.IsNaN(v[2])||float.IsInfinity(v[0])||float.IsInfinity(v[1])||float.IsInfinity(v[2]))throw new InvalidDataException("Nonfinite mapped stone vertex.");
                string key=Math.Round(v[0]*100000d)+":"+Math.Round(v[1]*100000d)+":"+Math.Round(v[2]*100000d);
                if(!welded.TryGetValue(key,out int id)){id=welded.Count;welded.Add(key,id);}ids[i]=id;
            }
            var edges=new Dictionary<string,int[]>();double volume6=0;
            for(int i=0;i<indices.Length;i+=3)
            {
                int[] t={indices[i],indices[i+1],indices[i+2]};
                foreach(int v in t)if(v<0||v>=vertices.Length)throw new InvalidDataException("Mapped stone index out of bounds.");
                var x=vertices[t[0]];var y=vertices[t[1]];var z=vertices[t[2]];
                volume6+=(double)x[0]*(y[1]*z[2]-y[2]*z[1])+(double)x[1]*(y[2]*z[0]-y[0]*z[2])+(double)x[2]*(y[0]*z[1]-y[1]*z[0]);
                for(int j=0;j<3;j++)
                {
                    int a=ids[t[j]],b=ids[t[(j+1)%3]];if(a==b)throw new InvalidDataException("Collapsed mapped stone edge.");
                    string key=Math.Min(a,b)+":"+Math.Max(a,b);if(!edges.TryGetValue(key,out var edge)){edge=new int[2];edges.Add(key,edge);}edge[0]++;edge[1]+=a<b?1:-1;
                }
            }
            foreach(var edge in edges.Values)if(edge[0]!=2||edge[1]!=0)throw new InvalidDataException("Mapped rubble stone is not a closed consistently oriented block.");
            if(Math.Abs(volume6)<1e-9)throw new InvalidDataException("Mapped rubble source has no closed physical volume.");
        }
    }
}
