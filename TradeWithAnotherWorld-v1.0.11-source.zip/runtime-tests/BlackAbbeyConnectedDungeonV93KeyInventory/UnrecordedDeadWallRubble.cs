using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Rendering;
using Object=UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    internal struct UnrecordedDeadStonePart
    {
        internal Mesh Mesh;
        internal Material Material;
        internal Vector3 LocalCenter;
        internal bool RetainEligible;
    }

    // Local cosmetic bodies only. Persistent wall state is committed by the
    // owner before Emit; this component never spawns a native/network actor.
    internal sealed class UnrecordedDeadWallRubble:MonoBehaviour
    {
        sealed class Fragment
        {
            internal GameObject Node;
            internal MeshRenderer Renderer;
            internal Rigidbody Body;
            internal BoxCollider Collider;
            internal Material FadeMaterial;
            internal Color SourceColor;
            internal string ColorProperty;
            internal readonly MaterialPropertyBlock Block=new MaterialPropertyBlock();
            internal UnrecordedDeadRubbleRelease Release;
            internal bool Fading,Frozen,Hidden;
        }
        struct IgnoredPlayerPair{internal Collider Fragment,Player;}
        readonly List<Material> privateMaterials=new List<Material>();
        readonly List<IgnoredPlayerPair> ignoredPlayers=new List<IgnoredPlayerPair>();
        Fragment[] fragments;
        Transform roomRoot;
        Action<string> log;
        bool configured,emitted;
        float emittedAt;
        internal bool HasPresentation{get;private set;}

        static bool Finite(float f)=>!float.IsNaN(f)&&!float.IsInfinity(f);
        static bool Finite(Vector3 p)=>Finite(p.x)&&Finite(p.y)&&Finite(p.z);
        static Vector3 V(float[] p)=>new Vector3(p[0],p[1],p[2]);

        internal void Configure(LoadedRoom room,UnrecordedDeadStonePart[] parts,GameObject authoredFallback,bool alreadyBroken,Action<string> log)
        {
            if(configured)throw new InvalidOperationException("Wall rubble cannot be rebound to another room.");
            configured=true;this.log=log;enabled=false;
            try
            {
                bool rebuilt=KitArchitectureProfile.Find(room?.Manifest?.sourceSha256)?.assetId=="R06-UD";
                if(room==null||!room.Root||parts==null||(!rebuilt&&parts.Length!=UnrecordedDeadRubblePolicy.StoneCount)||(rebuilt&&(parts.Length<1||parts.Length>64)))
                    throw new InvalidDataException("Wall rubble needs its room and all eleven checked source stones.");
                if(authoredFallback&&(gameObject==authoredFallback||transform.IsChildOf(authoredFallback.transform)))
                    throw new InvalidDataException("Rubble controller must remain outside the toggled fallback role.");
                roomRoot=room.Root.transform;
                int seed=(room.InstanceId??"R06").GetStableHashCode();
                if(!alreadyBroken)seed=unchecked(seed^Environment.TickCount^GetInstanceID());
                var releases=rebuilt?UnrecordedDeadRubblePolicy.BuildMapped(seed,Array.ConvertAll(parts,p=>p.RetainEligible)):UnrecordedDeadRubblePolicy.Build(seed);
                fragments=new Fragment[parts.Length];var fades=new Dictionary<Material,Material>();
                int layer=LayerMask.NameToLayer("piece");if(layer<0)layer=0;
                for(int i=0;i<parts.Length;i++)
                {
                    var part=parts[i];if(!part.Mesh||!part.Material||!Finite(part.LocalCenter)||!Finite(part.Mesh.bounds.size))
                        throw new InvalidDataException("A source rubble stone is missing its mesh/material/finite pose.");
                    if(!fades.TryGetValue(part.Material,out var fade))
                    {
                        fade=CreateFade(part.Material);fades.Add(part.Material,fade);privateMaterials.Add(fade);room.Resources.Add(fade);
                    }
                    var node=new GameObject("Unrecorded Dead | source wall stone "+i);node.SetActive(false);node.layer=layer;
                    string sourceColor=ColorProperty(part.Material);
                    var f=new Fragment{Node=node,Release=releases[i],FadeMaterial=fade,ColorProperty=ColorProperty(fade),SourceColor=sourceColor!=null?part.Material.GetColor(sourceColor):Color.white};
                    fragments[i]=f;node.transform.SetParent(roomRoot,false);node.transform.localPosition=part.LocalCenter;
                    node.AddComponent<MeshFilter>().sharedMesh=part.Mesh;
                    f.Renderer=node.AddComponent<MeshRenderer>();f.Renderer.sharedMaterial=part.Material;
                    f.Renderer.shadowCastingMode=ShadowCastingMode.Off;
                    f.Collider=node.AddComponent<BoxCollider>();f.Collider.center=part.Mesh.bounds.center;
                    var size=part.Mesh.bounds.size*.90f;
                    f.Collider.size=new Vector3(Mathf.Max(.04f,size.x),Mathf.Max(.04f,size.y),Mathf.Max(.04f,size.z));f.Collider.enabled=false;
                    f.Body=node.AddComponent<Rigidbody>();f.Body.isKinematic=true;f.Body.useGravity=false;f.Body.detectCollisions=false;
                    f.Body.mass=Mathf.Clamp(size.x*size.y*size.z*450f,.4f,4f);
                    f.Body.linearDamping=.12f;f.Body.angularDamping=.35f;f.Body.maxDepenetrationVelocity=1.5f;f.Body.maxAngularVelocity=3f;
                    f.Body.interpolation=RigidbodyInterpolation.Interpolate;f.Body.collisionDetectionMode=CollisionDetectionMode.ContinuousSpeculative;
                    node.AddComponent<UnrecordedDeadRubblePush>().Configure(f.Body);
                }
                if(alreadyBroken)RestoreDecorativeRemnants(authoredFallback);
                HasPresentation=true;
                log?.Invoke("UNRECORDED_DEAD_RUBBLE_READY: eleven exact source stones precreated; "+(alreadyBroken?"three static remnants restored; no break replay.":"gravity release awaits committed wall break."));
            }
            catch(Exception ex)
            {
                ClearPrivatePresentation();HasPresentation=false;
                log?.Invoke("UNRECORDED_DEAD_RUBBLE_UNAVAILABLE: "+ex.Message+"; authored fallback retained.");
            }
        }

        Material CreateFade(Material source)
        {
            // The game's player build can strip Shader.Find's registry entry
            // while a fully supported shader remains on native materials.
            // Borrow that shader only; retain the stone's own maps/properties.
            var native=WaterPresentation.FindLoadedTransparentStandard();
            var shader=native?native.shader:source.shader&&source.shader.isSupported?source.shader:Shader.Find("Standard");
            if(!shader||!shader.isSupported)throw new InvalidOperationException("Supported source/native fade shader unavailable.");
            var fade=new Material(source){name="Black Abbey | private source-stone fade",shader=shader};
            if(fade.HasProperty("_Mode"))fade.SetFloat("_Mode",2);fade.SetOverrideTag("RenderType","Transparent");
            if(fade.HasProperty("_SrcBlend"))fade.SetInt("_SrcBlend",(int)BlendMode.SrcAlpha);
            if(fade.HasProperty("_DstBlend"))fade.SetInt("_DstBlend",(int)BlendMode.OneMinusSrcAlpha);
            if(fade.HasProperty("_ZWrite"))fade.SetInt("_ZWrite",0);
            fade.DisableKeyword("_ALPHATEST_ON");fade.DisableKeyword("_ALPHAPREMULTIPLY_ON");fade.EnableKeyword("_ALPHABLEND_ON");fade.renderQueue=3000;
            return fade;
        }
        static string ColorProperty(Material material)=>material.HasProperty("_Color")?"_Color":material.HasProperty("_Colour")?"_Colour":material.HasProperty("_BaseColor")?"_BaseColor":null;

        internal void Emit(HitData hit)
        {
            if(!HasPresentation||emitted||fragments==null)return;
            emitted=true;emittedAt=Time.time;Vector3 push=hit!=null&&Finite(hit.m_dir)?Vector3.ProjectOnPlane(hit.m_dir,Vector3.up):Vector3.zero;
            push=push.sqrMagnitude>.0001f?push.normalized*.6f:Vector3.zero;
            foreach(var f in fragments)
            {
                f.Node.SetActive(true);f.Collider.enabled=true;f.Body.detectCollisions=true;
                // These are the original standing stone poses. All subsequent
                // positions and rotations come from real rigidbody integration.
                f.Body.position=f.Node.transform.position;f.Body.rotation=f.Node.transform.rotation;
                f.Body.isKinematic=false;f.Body.useGravity=true;f.Body.collisionDetectionMode=CollisionDetectionMode.ContinuousDynamic;
                f.Body.linearVelocity=roomRoot.TransformDirection(V(f.Release.LinearVelocity))+push;
                f.Body.angularVelocity=roomRoot.TransformDirection(V(f.Release.AngularVelocity));f.Body.WakeUp();
            }
            IgnorePlayersAtRelease();enabled=true;
            log?.Invoke("UNRECORDED_DEAD_RUBBLE_EMIT: all11source stones released with bounded gravity/rotation; eight fade, three retain physical landing poses; no network bodies.");
        }

        void IgnorePlayersAtRelease()
        {
            foreach(var player in Player.GetAllPlayers())
            {
                if(!player)continue;
                foreach(var shape in player.GetComponentsInChildren<Collider>(true))
                {
                    if(!shape||shape.isTrigger)continue;
                    foreach(var f in fragments)
                    {Physics.IgnoreCollision(f.Collider,shape,true);ignoredPlayers.Add(new IgnoredPlayerPair{Fragment=f.Collider,Player=shape});}
                }
            }
        }
        void RestorePlayerCollisions(float elapsed)
        {
            if(elapsed<.25f)return;
            for(int i=ignoredPlayers.Count-1;i>=0;i--)
            {
                var pair=ignoredPlayers[i];
                if(!pair.Fragment||!pair.Player){ignoredPlayers.RemoveAt(i);continue;}
                // Do not re-enable contact while a player is inside a release
                // shape. Once separated, these low-mass stones can be pushed.
                if(pair.Fragment.enabled&&pair.Fragment.bounds.Intersects(pair.Player.bounds))continue;
                Physics.IgnoreCollision(pair.Fragment,pair.Player,false);ignoredPlayers.RemoveAt(i);
            }
        }
        void Update()
        {
            if(!emitted||!HasPresentation)return;
            float elapsed=Mathf.Max(0,Time.time-emittedAt);RestorePlayerCollisions(elapsed);
            foreach(var f in fragments)
            {
                if(f.Hidden||!f.Node)continue;
                float opacity=UnrecordedDeadRubblePolicy.Opacity(f.Release,elapsed);
                if(!f.Release.Retain&&elapsed>=f.Release.FadeStart)
                {
                    if(!f.Fading){Freeze(f);f.Fading=true;f.Renderer.sharedMaterial=f.FadeMaterial;}
                    f.Block.Clear();var color=f.SourceColor;color.a*=opacity;if(f.ColorProperty!=null)f.Block.SetColor(f.ColorProperty,color);f.Renderer.SetPropertyBlock(f.Block);
                    if(opacity<=0){f.Node.SetActive(false);f.Hidden=true;}
                }
                if(!UnrecordedDeadRubblePolicy.PhysicsActive(elapsed))Freeze(f);
            }
            if(!UnrecordedDeadRubblePolicy.PhysicsActive(elapsed))enabled=false;
        }
        static void Freeze(Fragment f)
        {
            if(f.Frozen)return;f.Frozen=true;
            f.Collider.enabled=false;f.Body.detectCollisions=false;
            if(!f.Body.isKinematic){f.Body.linearVelocity=Vector3.zero;f.Body.angularVelocity=Vector3.zero;}
            f.Body.useGravity=false;f.Body.isKinematic=true;
            // Deliberately do not assign Transform, Rigidbody.position or
            // Rigidbody.rotation here. Keep the actual settled/falling pose.
        }

        void RestoreDecorativeRemnants(GameObject authoredFallback)
        {
            if(!authoredFallback)throw new InvalidDataException("Broken-wall reload needs the authored rubble floor reference.");
            bool first=true;Bounds footprint=default;
            foreach(var filter in authoredFallback.GetComponentsInChildren<MeshFilter>(true))
            {
                if(!filter.sharedMesh)continue;var b=filter.sharedMesh.bounds;
                for(int corner=0;corner<8;corner++)
                {
                    var p=b.center+Vector3.Scale(b.extents,new Vector3((corner&1)==0?-1:1,(corner&2)==0?-1:1,(corner&4)==0?-1:1));
                    p=roomRoot.InverseTransformPoint(filter.transform.TransformPoint(p));
                    if(first){footprint=new Bounds(p,Vector3.zero);first=false;}else footprint.Encapsulate(p);
                }
            }
            if(first||!Finite(footprint.center)||!Finite(footprint.size))throw new InvalidDataException("Authored rubble has no finite source bounds.");
            int index=0;
            foreach(var f in fragments)
            {
                if(!f.Release.Retain)continue;
                var rotation=Quaternion.AngleAxis(index*19f-17f,Vector3.up)*Quaternion.AngleAxis(90,Vector3.forward);
                var mesh=f.Node.GetComponent<MeshFilter>().sharedMesh;float lowest=float.PositiveInfinity;var b=mesh.bounds;
                for(int corner=0;corner<8;corner++)
                {
                    var p=b.center+Vector3.Scale(b.extents,new Vector3((corner&1)==0?-1:1,(corner&2)==0?-1:1,(corner&4)==0?-1:1));
                    lowest=Mathf.Min(lowest,(rotation*p).y);
                }
                var point=footprint.center+new Vector3(index==1?.19f:-.05f,0,(index-1)*.43f);point.y=footprint.min.y-lowest+.006f;
                f.Node.transform.localPosition=point;f.Node.transform.localRotation=rotation;f.Node.SetActive(true);Freeze(f);index++;
            }
            emitted=true;enabled=false;
        }

        void ClearPrivatePresentation()
        {
            foreach(var pair in ignoredPlayers)if(pair.Fragment&&pair.Player)Physics.IgnoreCollision(pair.Fragment,pair.Player,false);
            ignoredPlayers.Clear();
            if(fragments!=null)foreach(var f in fragments)if(f!=null&&f.Node)Object.Destroy(f.Node);
            fragments=null;
            foreach(var material in privateMaterials)if(material)Object.Destroy(material);privateMaterials.Clear();
        }
        void OnDestroy()=>ClearPrivatePresentation();
    }

    // Native melee can nudge a sleeping fragment during its short dynamic
    // lifetime. There is no health, loot, RPC, or effect on saved wall state.
    internal sealed class UnrecordedDeadRubblePush:MonoBehaviour,IDestructible
    {
        Rigidbody body;
        internal void Configure(Rigidbody body){this.body=body;}
        public DestructibleType GetDestructibleType()=>DestructibleType.Default;
        public void Damage(HitData hit)
        {
            if(!body||body.isKinematic||!body.detectCollisions||hit==null||!AbbeyBreakablePew.PositiveFiniteDamage(hit.GetTotalDamage()))return;
            var direction=hit.m_dir;
            if(float.IsNaN(direction.x)||float.IsInfinity(direction.x)||float.IsNaN(direction.y)||float.IsInfinity(direction.y)||float.IsNaN(direction.z)||float.IsInfinity(direction.z))return;
            direction=Vector3.ProjectOnPlane(direction,Vector3.up);if(direction.sqrMagnitude<.0001f)return;
            body.WakeUp();body.linearVelocity=Vector3.ClampMagnitude(body.linearVelocity+direction.normalized*.3f+Vector3.up*.06f,1.8f);
        }
    }
}
