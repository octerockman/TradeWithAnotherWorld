using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeySixRooms
{
    internal sealed class PewRoomState
    {
        private readonly HashSet<string> broken = new HashSet<string>(StringComparer.Ordinal);
        internal Action Changed;
        internal bool IsBroken(string id) => broken.Contains(id);
        internal bool TryBreak(string id)
        { if (string.IsNullOrWhiteSpace(id)) throw new ArgumentException("A pew requires a stable identity.", nameof(id)); bool added=broken.Add(id);if(added)Changed?.Invoke();return added; }
        internal int BrokenCount => broken.Count;
        internal string[] BrokenIds => broken.OrderBy(id=>id,StringComparer.Ordinal).ToArray();
        internal void Restore(string[] ids)
        {
            if(ids==null||broken.Count>0||ids.Any(string.IsNullOrWhiteSpace)||ids.Distinct(StringComparer.Ordinal).Count()!=ids.Length)
                throw new ArgumentException("Invalid saved broken pews.");
            foreach(string id in ids)broken.Add(id);
        }
    }
    internal sealed class PewRunState
    {
        private readonly Dictionary<string, PewRoomState> rooms = new Dictionary<string, PewRoomState>(StringComparer.Ordinal);
        internal KeyValuePair<string,PewRoomState>[] ExistingRooms => rooms.ToArray();
        internal PewRoomState ForRoom(string instanceId)
        {
            if (string.IsNullOrWhiteSpace(instanceId)) throw new ArgumentException("A pew room requires a concrete instance identity.", nameof(instanceId));
            if (!rooms.TryGetValue(instanceId, out var state)) rooms.Add(instanceId, state = new PewRoomState());
            return state;
        }
    }
}
