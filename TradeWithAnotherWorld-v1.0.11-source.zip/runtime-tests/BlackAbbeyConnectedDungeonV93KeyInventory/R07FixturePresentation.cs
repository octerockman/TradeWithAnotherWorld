using System;

namespace BlackAbbeySixRooms
{
    internal static class R07FixturePresentation
    {
        internal static string CandleHover(bool lit) => "[<color=yellow><b>$KEY_Use</b></color>] " + (lit ? "Extinguish" : "Light");

        internal static string LightName(string roomInstanceId, int serial)
        {
            if (string.IsNullOrWhiteSpace(roomInstanceId)) throw new ArgumentException("A shrine light requires its concrete room instance ID.");
            if (serial < 1) throw new ArgumentOutOfRangeException(nameof(serial));
            // The serial is deliberately monotonic within this controller:
            // inactive clones pending Unity's deferred Destroy also keep unique IDs.
            return "BA_" + roomInstanceId + "_PuzzleFixtureLight | " + serial;
        }
    }
}
