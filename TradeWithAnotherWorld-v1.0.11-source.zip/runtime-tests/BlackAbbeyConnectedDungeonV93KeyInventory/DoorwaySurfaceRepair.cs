using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // Source-pinned, local render corrections. Original BAR1 and room collision stay untouched.
    internal static class DoorwaySurfaceRepair
    {
#pragma warning disable 0649
        private sealed class Map { public int schemaVersion; public float maxDelta_m; public RoomMap[] rooms; }
        private sealed class RoomMap { public string roomId, sourceSha256, meshName, meshSha256; public int vertexCount, indexCount; public PortMap[] ports; }
        private sealed class PortMap { public string id; public TriangleMap[] triangles; }
        private sealed class TriangleMap { public int triangle; public int[] indices; public float[][] expected, delta; }
#pragma warning restore 0649
        internal static void Restore(LoadedRoom room)
        {
            if (!room?.Root) return;
            var state = room.Root.GetComponent<DoorwayRepairState>();
            if (state) state.Restore();
        }
        internal static void Apply(LoadedRoom room, string mapPath, IEnumerable<string> linkedPortIds, Action<string> log)
        {
            Restore(room);
            var wanted = new HashSet<string>(linkedPortIds, StringComparer.Ordinal);
            if (wanted.Count == 0) return;
            var file = new FileInfo(mapPath);
            if (!file.Exists || file.Length > 1024 * 1024) throw new InvalidDataException("Missing/oversized doorway repair map.");
            var map = JsonConvert.DeserializeObject<Map>(File.ReadAllText(file.FullName), new JsonSerializerSettings {
                TypeNameHandling = TypeNameHandling.None, MetadataPropertyHandling = MetadataPropertyHandling.Ignore, MaxDepth = 24 });
            if (map == null || map.schemaVersion != 1 || map.rooms == null || map.rooms.Length != 7 ||
                !RoomPackage.Finite(map.maxDelta_m) || map.maxDelta_m <= 0 || map.maxDelta_m > .030002f)
                throw new InvalidDataException("Invalid doorway repair schema/bound.");
            var data = map.rooms.Single(r => r.roomId == room.Manifest.roomId);
            var record = room.Manifest.meshes.Single(m => m.name == "architecture_floor");
            if (data.sourceSha256 != UnrecordedDeadSourceBindings.Canonical(room.Manifest.roomId,room.Manifest.sourceSha256) || data.meshName != record.name || data.meshSha256 != record.sha256)
                throw new InvalidDataException("Doorway repair differs from the loaded source/buffer.");
            var filter = room.Root.GetComponentsInChildren<MeshFilter>(true).Single(f => f.name == record.name);
            var original = filter.sharedMesh;
            if (original.vertexCount != data.vertexCount || original.triangles.Length != data.indexCount)
                throw new InvalidDataException("Doorway repair count differs.");
            var ports = data.ports.Where(p => wanted.Contains(p.id)).ToArray();
            if (ports.Length != wanted.Count) throw new InvalidDataException("Unknown linked doorway repair port.");
            var rows = ports.SelectMany(p => p.triangles).ToArray();
            if (rows.Length == 0) { log("DOORWAY_BACKING: " + room.Manifest.roomId + ": no near-coincident structural intrados; missing R03 reveals are supplied by the fitted join."); return; }
            if (rows.Length > 2048) throw new InvalidDataException("Too many doorway repairs.");
            var positions = original.vertices; var indices = original.triangles;
            var touched = new HashSet<int>();
            // Validate every selected position before constructing or assigning a candidate.
            foreach (var row in rows)
            {
                if (row.triangle < 0 || row.triangle >= indices.Length / 3 || !touched.Add(row.triangle) ||
                    row.indices?.Length != 3 || row.expected?.Length != 3 || row.delta?.Length != 3)
                    throw new InvalidDataException("Invalid/duplicate doorway triangle.");
                for (int j = 0; j < 3; j++)
                {
                    int index = indices[row.triangle * 3 + j];
                    var expected = RoomPackage.Vector(row.expected[j], "doorway expected");
                    var delta = RoomPackage.Vector(row.delta[j], "doorway delta");
                    if (row.indices[j] != index || Vector3.Distance(positions[index], expected) > .000002f ||
                        delta.magnitude > map.maxDelta_m || expected.y < -.00001f || Math.Abs(delta.y) > .030002f || expected.y < .03f && Math.Abs(delta.y) > .000001f)
                        throw new InvalidDataException("Doorway repair position/bound differs from its frozen render buffer.");
                }
            }
            var vertices = positions.ToList(); var normals = original.normals.ToList();
            var uvs = original.uv.ToList(); var tangents = original.tangents.ToList(); var colors = original.colors32.ToList();
            foreach (var row in rows) for (int j = 0; j < 3; j++)
            {
                int old = row.indices[j], next = vertices.Count;
                vertices.Add(positions[old] + RoomPackage.Vector(row.delta[j], "doorway delta"));
                normals.Add(normals[old]); uvs.Add(uvs[old]); tangents.Add(tangents[old]); colors.Add(colors[old]);
                indices[row.triangle * 3 + j] = next;
            }
            var candidate = new Mesh { name = original.name + " | linked aperture backing separated", indexFormat = IndexFormat.UInt32 };
            candidate.SetVertices(vertices); candidate.SetNormals(normals); candidate.SetUVs(0, uvs); candidate.SetTangents(tangents);
            candidate.SetColors(colors); candidate.SetTriangles(indices, 0, true);
            var state = room.Root.GetComponent<DoorwayRepairState>() ?? room.Root.AddComponent<DoorwayRepairState>();
            state.Assign(filter, original, candidate);
            log("DOORWAY_BACKING: " + room.Manifest.roomId + ": " + rows.Length + " exact-buffer structural triangles recessed 30mm into stone at linked ports only; arch stones/maps/room colliders unchanged.");
        }

        // Called after the existing connector clone has its rotation and Z=gap/1.5 scale.
        // Replace that compressed circular arch with a small, correctly fitted seam.
        internal static void FitJoin(GameObject connectorClone, LoadedRoom roomA, PortRecord a, LoadedRoom roomB, PortRecord b, float gap, Material r06StoneMaterial, Action<string> log)
        {
            if (!connectorClone || gap < .005f || gap > .05f || Math.Abs(connectorClone.transform.localScale.z - gap / 1.5f) > .00001f)
                throw new InvalidDataException("Fitted doorway requires the measured small outer joint.");
            if (Math.Abs(a.width - 3f) > .001f || Math.Abs(b.width - 3f) > .001f || a.apertureProfileWidthHeight == null || b.apertureProfileWidthHeight == null)
                throw new InvalidDataException("Fitted doorway requires the source port profiles.");
            bool extendA = roomA.Manifest.roomId.StartsWith("R03", StringComparison.Ordinal);
            bool extendB = roomB.Manifest.roomId.StartsWith("R03", StringComparison.Ordinal);
            float scale = gap / 1.5f;
            var geometry = DoorwayProfileGeometry.Build(a, b, gap, extendA, extendB);
            var mesh = new Mesh { name = "BA fitted 2cm joint and missing R03 reveal", indexFormat = IndexFormat.UInt32 };
            mesh.vertices = geometry.Positions.Select(p => new Vector3(p[0], p[1], p[2])).ToArray();
            mesh.normals = geometry.Normals.Select(p => new Vector3(p[0], p[1], p[2])).ToArray();
            mesh.uv = geometry.UV.Select(p => new Vector2(p[0], p[1])).ToArray();
            mesh.SetTriangles(geometry.Indices, 0, true); mesh.RecalculateTangents();
            Material material = null;
            try
            {
                if (!r06StoneMaterial || !r06StoneMaterial.HasProperty("_MainTex") || !r06StoneMaterial.GetTexture("_MainTex"))
                    throw new InvalidOperationException("The shared R06 tileable stone seam material is unavailable.");
                material = new Material(r06StoneMaterial) { name = "BA fitted joint | shared R06 stone" };
                // The caller supplies only the dedicated R06_STONE_SURFACE
                // asset, never a room atlas. Its private maps must repeat for
                // physical-metre sleeve UVs; do not change any room atlas.
                foreach (string property in new[] { "_MainTex", "_BumpMap", "_MetallicGlossMap" })
                {
                    if (!material.HasProperty(property)) continue;
                    var texture = material.GetTexture(property); if (texture) texture.wrapMode = TextureWrapMode.Repeat;
                    material.SetTextureScale(property, Vector2.one); material.SetTextureOffset(property, Vector2.zero);
                }
                foreach (var renderer in connectorClone.GetComponentsInChildren<MeshRenderer>(true)) renderer.enabled = false;
                foreach (var collider in connectorClone.GetComponentsInChildren<Collider>(true)) collider.enabled = false;
                var child = new GameObject("Fitted seam | source aperture envelope"); child.transform.SetParent(connectorClone.transform, false); child.transform.localScale = new Vector3(1, 1, 1 / scale); child.layer = LayerMask.NameToLayer("static_solid");
                child.AddComponent<MeshFilter>().sharedMesh = mesh;
                var rendererNew = child.AddComponent<MeshRenderer>(); rendererNew.sharedMaterial = material; rendererNew.shadowCastingMode = ShadowCastingMode.On; rendererNew.receiveShadows = true;
                child.AddComponent<MeshCollider>().sharedMesh = mesh;
                var state = child.AddComponent<DoorwayJoinResources>(); state.Mesh = mesh; state.Material = material;
                log("DOORWAY_JOIN: " + roomA.Manifest.roomId + "/" + a.id + " -> " + roomB.Manifest.roomId + "/" + b.id + ": shared R06 stone seam, " + (geometry.Indices.Length / 3) + " triangles, " + gap.ToString("F3") + "m gap; R03 reveal extensions=" + extendA + "/" + extendB + "; old compressed circular skin/collider disabled on this clone only.");
            }
            catch { Object.Destroy(mesh); if (material) Object.Destroy(material); throw; }
        }
        internal static GameObject FillBarredReturn(LoadedRoom room, PortRecord port, Material r06StoneMaterial, Action<string> log)
        {
            if (!room?.Root || !room.Manifest.roomId.StartsWith("R03", StringComparison.Ordinal))
                throw new InvalidDataException("A missing barred return is specific to the R03 sources.");
            var geometry = DoorwayProfileGeometry.BuildReturn(port);
            var mesh = new Mesh { name = "BA R03 barred port | roof and jamb return only", indexFormat = IndexFormat.UInt32 };
            mesh.vertices = geometry.Positions.Select(p => new Vector3(p[0], p[1], p[2])).ToArray();
            mesh.normals = geometry.Normals.Select(p => new Vector3(p[0], p[1], p[2])).ToArray();
            mesh.uv = geometry.UV.Select(p => new Vector2(p[0], p[1])).ToArray();
            mesh.SetTriangles(geometry.Indices, 0, true); mesh.RecalculateTangents();
            Material material = null; GameObject child = null;
            try
            {
                if (!r06StoneMaterial || !r06StoneMaterial.HasProperty("_MainTex") || !r06StoneMaterial.GetTexture("_MainTex"))
                    throw new InvalidOperationException("The shared R06 tileable stone return material is unavailable.");
                material = new Material(r06StoneMaterial) { name = "BA barred return | shared R06 stone" };
                foreach (string property in new[] { "_MainTex", "_BumpMap", "_MetallicGlossMap" })
                {
                    if (!material.HasProperty(property)) continue;
                    var texture = material.GetTexture(property); if (texture) texture.wrapMode = TextureWrapMode.Repeat;
                    material.SetTextureScale(property, Vector2.one); material.SetTextureOffset(property, Vector2.zero);
                }
                var outward = RoomPackage.Vector(port.outward, "barred return outward");
                child = new GameObject("R03 missing barred return | " + port.id); child.transform.SetParent(room.Root.transform, false);
                child.transform.localPosition = RoomPackage.Vector(port.position, "barred return threshold") + outward * port.depth;
                child.transform.localRotation = Quaternion.LookRotation(outward, Vector3.up); child.layer = LayerMask.NameToLayer("static_solid");
                child.AddComponent<MeshFilter>().sharedMesh = mesh;
                var renderer = child.AddComponent<MeshRenderer>(); renderer.sharedMaterial = material; renderer.shadowCastingMode = ShadowCastingMode.On; renderer.receiveShadows = true;
                child.AddComponent<MeshCollider>().sharedMesh = mesh;
                var resources = child.AddComponent<DoorwayJoinResources>(); resources.Mesh = mesh; resources.Material = material;
                var state = room.Root.GetComponent<DoorwayRepairState>() ?? room.Root.AddComponent<DoorwayRepairState>(); state.Returns.Add(child);
                log("DOORWAY_BARRED_RETURN: " + room.Manifest.roomId + "/" + port.id + ": " + port.depth.ToString("F3") + "m roof/jamb return plus2cm outer seam; zero floor triangles; shared R06 stone.");
                return child;
            }
            catch { if (child) { child.SetActive(false); Object.Destroy(child); } Object.Destroy(mesh); if (material) Object.Destroy(material); throw; }
        }
    }

    internal sealed class DoorwayRepairState : MonoBehaviour
    {
        private MeshFilter filter; private Mesh original, candidate;
        internal readonly List<GameObject> Returns = new List<GameObject>();
        internal void Assign(MeshFilter target, Mesh source, Mesh replacement) { filter = target; original = source; candidate = replacement; filter.sharedMesh = candidate; }
        internal void Restore() { if (filter && original) filter.sharedMesh = original; if (candidate) Object.Destroy(candidate); candidate = null; foreach (var item in Returns) if (item) { item.SetActive(false); Object.Destroy(item); } Returns.Clear(); }
        private void OnDestroy() { if (candidate) Object.Destroy(candidate); }
    }
    internal sealed class DoorwayJoinResources : MonoBehaviour
    {
        internal Mesh Mesh; internal Material Material;
        private void OnDestroy() { if (Mesh) Object.Destroy(Mesh); if (Material) Object.Destroy(Material); }
    }
}
