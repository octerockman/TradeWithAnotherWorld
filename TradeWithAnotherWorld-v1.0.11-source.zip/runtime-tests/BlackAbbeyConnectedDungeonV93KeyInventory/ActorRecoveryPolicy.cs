using System;
namespace BlackAbbeySixRooms
{
    internal static class ActorRecoveryPolicy
    {
        internal enum Decision { Wait,Reuse,Recreate,Blocked }
        internal static bool MayRecover(string state,float? health)=>(state=="Spawned"||state=="Lost")&&health.HasValue&&!float.IsNaN(health.Value)&&!float.IsInfinity(health.Value)&&health.Value>0;
        internal static Decision Choose(bool complete,int matches,bool alive,bool collision)
        {if(!alive||collision||matches>1)return Decision.Blocked;if(!complete)return Decision.Wait;return matches==1?Decision.Reuse:Decision.Recreate;}
    }
}
