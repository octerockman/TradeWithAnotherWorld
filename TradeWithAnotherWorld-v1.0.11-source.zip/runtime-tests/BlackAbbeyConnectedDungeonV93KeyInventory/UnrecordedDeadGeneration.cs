using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Variant asset identity is separate from the unchanged source-family
    // identity consumed by candles, doors, actors and room-specific shaders.
    internal static class UnrecordedDeadGeneration
    {
        internal const string Route = "unrecorded-dead", FalseVowsRoute = "false-vows";
        internal static readonly string[] Sources = { "R02", "R06", "R08", "R09" };
        internal static bool WantsRoute(int seed) => new Random(unchecked(seed ^ 0x68714B3)).Next(2) == 0;
        internal static string AssetFor(string source) => source=="R09-A2"?source:source + "-UD";
        internal static readonly string[] SplitSources={"R02","R06","R08","R09-A2"};
        internal static DungeonRoomSpec VariantSpec(PackageManifest manifest, string assetId, double[][] reservations = null)
        {
            var spec = DungeonRoomSpecFactory.FromManifest(manifest,assetId);
            if (!SplitSources.Contains(spec.SourceId) || assetId != AssetFor(spec.SourceId))
                throw new InvalidDataException("Unrecorded Dead asset identity does not match its canonical room family.");
            spec.AssetId = assetId;
            if(reservations!=null)
            {
                if(spec.KitConnectedExteriorCollar&&(spec.Reservations.Length!=reservations.Length||spec.Reservations.Where((b,i)=>reservations[i]==null||!b.SequenceEqual(reservations[i])).Any()))
                    throw new InvalidDataException("Rebuilt variant reservations differ from the sealed complete-source planning proof.");
                spec.Reservations = reservations.Select(b => b?.ToArray()).ToArray();
            }
            ValidateVariant(spec);
            return spec;
        }
        internal static void ValidateVariant(DungeonRoomSpec spec)
        {
            if (spec == null || !SplitSources.Contains(spec.SourceId) || spec.Id != spec.SourceId || spec.AssetId != AssetFor(spec.SourceId) ||
                spec.Bounds?.Length != 4 || spec.BoundsY?.Length != 2 || spec.Ports == null)
                throw new InvalidDataException("Incomplete Unrecorded Dead variant definition.");
            if (spec.SourceId == "R08" && (spec.Ports.Length != 3 || spec.Reservations == null || spec.Reservations.Length == 0 ||
                !spec.Ports.Any(p => (p.id == "D01" || p.id == "SOUTH") && Math.Abs(p.position[1]) < .001) ||
                !spec.Ports.Any(p => (p.id == "D02" || p.id == "NORTH") && Math.Abs(p.position[1] - 10.8) < .001) ||
                !spec.Ports.Any(p => (p.id == "D03" || p.id == "KNIGHT-RETURN") && Math.Abs(p.position[1]) < .001)))
                throw new InvalidDataException("The alternate stair requires its two original levels, knight exit and complete measured 3D reservations.");
            ValidateReservations(spec);
        }
        internal static void ValidateReservations(DungeonRoomSpec spec)
        {
            if (spec.Reservations == null) return;
            if (spec.Reservations.Length == 0 || spec.Reservations.Length > 4096 || spec.Reservations.Any(b => b == null || b.Length != 6 ||
                b.Any(v => double.IsNaN(v) || double.IsInfinity(v)) || b[0] >= b[3] || b[1] >= b[4] || b[2] >= b[5] ||
                b[0] < spec.Bounds[0] - .001 || b[3] > spec.Bounds[2] + .001 || b[2] < spec.Bounds[1] - .001 || b[5] > spec.Bounds[3] + .001 ||
                b[1] < spec.BoundsY[0] - .001 || b[4] > spec.BoundsY[1] + .001))
                throw new InvalidDataException("Variant reservations must be finite positive boxes inside the complete authored source envelope.");
        }
        internal static Dictionary<string, DungeonRoomSpec> VariantSet(IEnumerable<DungeonRoomSpec> input)
        {
            var values = input?.ToArray() ?? Array.Empty<DungeonRoomSpec>();
            if (values.Length != 4 || values.Any(v => v == null) || values.Select(v => v.SourceId).Distinct().Count() != 4 ||
                !new HashSet<string>(values.Select(v => v.SourceId), StringComparer.Ordinal).SetEquals(SplitSources))
                throw new InvalidDataException("The alternate boss route requires all four exact room variants together.");
            foreach (var value in values) ValidateVariant(value);
            return values.ToDictionary(v => v.SourceId, StringComparer.Ordinal);
        }
        internal static bool Complete(IEnumerable<DungeonRoomSpec> input)
        {
            try { VariantSet(input); return true; }
            catch (InvalidDataException) { return false; }
        }
        internal static DungeonRoomSpec[] ApplyVariants(DungeonRoomSpec[] roster, IReadOnlyDictionary<string, DungeonRoomSpec> variants)
        {
            if (variants == null) return roster;
            var result = roster.ToArray();
            foreach (var source in Sources)
            {
                if (!variants.TryGetValue(source, out var variant)) throw new InvalidDataException("Missing alternate route room " + source);
                int index = Array.FindIndex(result, s => s.SourceId == source);
                if (index < 0) throw new InvalidDataException("Selected roster has no required alternate route room " + source);
                result[index] = new DungeonRoomSpec { Id = result[index].Id, SourceId = source, AssetId = variant.AssetId,
                    Ports = variant.Ports.ToArray(), Bounds = variant.Bounds.ToArray(), BoundsY = variant.BoundsY.ToArray(),
                    Reservations = variant.Reservations?.Select(b => b.ToArray()).ToArray(),KitConnectedExteriorCollar=variant.KitConnectedExteriorCollar,SplitBossProxy=variant.SplitBossProxy };
            }
            return result;
        }
        internal static void ValidatePlan(DungeonPlan plan)
        {
            if (plan == null || plan.BossUnlockRoute != Route || plan.Mode != "natural")
                throw new InvalidDataException("The alternate route must be explicitly bound to a natural dungeon.");
            if(plan.Rooms.Count(p=>p.Spec.SourceId=="R09-B")!=1||plan.Rooms.Count(p=>p.Spec.SourceId=="R09-A2")!=1||
                plan.Rooms.Any(p=>p.Spec.SourceId=="R09-A1"||p.Spec.SourceId=="R09"))
                throw new InvalidDataException("The alternate route requires exactly one A2 hall and one shared chamber, without another path hall.");
            foreach (var source in SplitSources)
                if (plan.Rooms.Count(p => p.Spec.AssetId == AssetFor(source)) != 1)
                    throw new InvalidDataException("Each alternate route room must appear exactly once: " + source);
            if (plan.Rooms.Any(p => p.Spec.AssetId != p.Spec.SourceId && !SplitSources.Any(s => p.Spec.AssetId == AssetFor(s))))
                throw new InvalidDataException("Unexpected alternate room asset identity.");
            int entrance = Array.FindIndex(plan.Rooms, p => p.Spec.Id == "R01"), boss = Array.FindIndex(plan.Rooms, p => p.Spec.SourceId == "R09-B");
            if (entrance < 0 || boss < 0) throw new InvalidDataException("Missing entrance or boss identity.");
            var gates = plan.Links.Where(l => l.A == boss || l.B == boss).ToArray();
            if (gates.Length != 1) throw new InvalidDataException("The sealed boss chamber must have one actual approach.");
            var reached = new HashSet<int> { entrance }; var queue = new Queue<int>(); queue.Enqueue(entrance);
            while (queue.Count > 0)
            {
                int from = queue.Dequeue();
                foreach (var edge in plan.Links)
                {
                    if (ReferenceEquals(edge, gates[0])) continue;
                    int to = edge.A == from ? edge.B : edge.B == from ? edge.A : -1;
                    if (to >= 0 && reached.Add(to)) queue.Enqueue(to);
                }
            }
            if (reached.Contains(boss) || plan.Rooms.Select((p, i) => new { p, i }).Where(x => (x.p.Spec.AssetId.EndsWith("-UD", StringComparison.Ordinal)||x.p.Spec.SourceId=="R09-A2") && x.i != boss).Any(x => !reached.Contains(x.i)))
                throw new InvalidDataException("Every clue and Edrin's key must be reachable before the sealed boss gate, without a bypass.");
            var stair = plan.Rooms.Single(p => p.Spec.AssetId == AssetFor("R08"));
            int stairIndex = Array.IndexOf(plan.Rooms, stair);
            if (stair.Spec.Ports.Any(p => !plan.IsLinked(stairIndex, p.id)))
                throw new InvalidDataException("The original stair landings and the knight return must all connect to the dungeon.");
        }
    }
}
