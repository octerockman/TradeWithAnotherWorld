using System;
using System.Globalization;
using System.IO;

namespace BlackAbbeySixRooms
{
    internal static class DungeonRegeneratePathPolicy
    {
        internal const string Command="twa_test_regenerate_path";
        internal const string Usage="Use twa_test_regenerate_path <false-vows|unrecorded-dead|random> [integer seed].";
        internal static bool TryParse(string[] args,out string route,out int? seed,out string error)
        {
            route=null;seed=null;error=null;
            if(args==null||args.Length<1||args.Length>2){error=Usage;return false;}
            string choice=args[0]?.Trim().ToLowerInvariant();
            if(choice==UnrecordedDeadGeneration.Route||choice==UnrecordedDeadGeneration.FalseVowsRoute)route=choice;
            else if(choice!="random"){error=Usage;return false;}
            if(args.Length==2)
            {
                if(!int.TryParse(args[1],NumberStyles.Integer,CultureInfo.InvariantCulture,out int value))
                {route=null;error="The dungeon seed must be an integer. "+Usage;return false;}
                seed=value;
            }
            return true;
        }
        internal static string GenerationRoute(bool hasSavedRun,bool showcase,string savedRoute,string forcedRoute)
        {
            if(forcedRoute!=null&&forcedRoute!=UnrecordedDeadGeneration.Route&&forcedRoute!=UnrecordedDeadGeneration.FalseVowsRoute)
                throw new InvalidDataException("Unknown requested boss-unlock path; current dungeon retained.");
            if(forcedRoute!=null&&(hasSavedRun||showcase))
                throw new InvalidOperationException("A chosen path applies only to a fresh natural dungeon after safe retirement.");
            return hasSavedRun?savedRoute:forcedRoute;
        }
    }
}
