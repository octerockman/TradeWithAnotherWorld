using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading;
using Newtonsoft.Json;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // An embedded presentation derivative of the exact current R09 source.
    // Catalog, manifests, source indices/counts and collision stay authoritative.
    internal static class BossPresentationRepair
    {
        internal const string ResourceName = "BlackAbbey.BossPresentationV80.json";
        internal const string PayloadSha256 = "12bb72a63cbef1133c3bff26113d0a94831f4d22cc08289c9fc8f5444e102195";
#pragma warning disable 0649
        internal sealed class ScopePin { public string assetId, sourceSha256, manifestSha256; }
        internal sealed class TexturePin { public string relative, originalSha256, resource, sha256; public bool linear; }
        internal sealed class Payload
        {
            public ScopePin[] rooms;
            public MeshRecord sourceMesh;
            public string originalFrameSha256, replacementResource, replacementSha256;
            public int[] waxVertices;
            public TexturePin[] textures;
        }
#pragma warning restore 0649
        private static readonly Lazy<Payload> payload = new Lazy<Payload>(ReadPayload, LazyThreadSafetyMode.ExecutionAndPublication);
        private static byte[] Resource(string name, string hash, int maximum)
        {
            using (var stream = typeof(BossPresentationRepair).Assembly.GetManifestResourceStream(name))
            {
                if (stream == null || stream.Length < 1 || stream.Length > maximum) throw new InvalidDataException("Checked boss presentation resource is missing or oversized.");
                byte[] bytes; using (var memory = new MemoryStream()) { stream.CopyTo(memory); bytes = memory.ToArray(); }
                if (BarMeshReader.Hash(bytes) != hash) throw new InvalidDataException("Checked boss presentation resource changed.");
                return bytes;
            }
        }
        private static Payload ReadPayload()
        {
            var p = JsonConvert.DeserializeObject<Payload>(System.Text.Encoding.UTF8.GetString(Resource(ResourceName, PayloadSha256, 2 * 1024 * 1024)), ManifestReader.Settings());
            if (p?.rooms?.Length != 2 || p.textures?.Length != 3 || p.sourceMesh == null || p.waxVertices == null || p.waxVertices.Length != 0)
                throw new InvalidDataException("Invalid checked boss presentation contract.");
            return p;
        }
        private static string Asset(string directory) => string.IsNullOrWhiteSpace(directory) ? "" : Path.GetFileName(Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
        private static bool SameDirectory(string a, string b) => !string.IsNullOrWhiteSpace(a) && !string.IsNullOrWhiteSpace(b) && string.Equals(Path.GetFullPath(a).TrimEnd('\\', '/'), Path.GetFullPath(b).TrimEnd('\\', '/'), StringComparison.OrdinalIgnoreCase);
        private static ScopePin Scope(string directory)
        {
            string asset = Asset(directory); if (asset != "R09" && asset != "R09-UD") return null;
            var pin = payload.Value.rooms.SingleOrDefault(p => p.assetId == asset);
            if (pin == null || CatalogReader.HashFile(Path.Combine(directory, "manifest.json")) != pin.manifestSha256)
                throw new InvalidDataException("Boss presentation requires its exact original room manifest.");
            return pin;
        }
        private static ScopePin Scope(string directory, LoadedRoom room)
        {
            if (room?.Record == null || room.Manifest == null || !SameDirectory(directory, room.PackageDirectory)) return null;
            string asset = room.Record.packageDirectory; if (asset != "R09" && asset != "R09-UD") return null;
            var pin = payload.Value.rooms.SingleOrDefault(p => p.assetId == asset);
            if (pin == null || Asset(directory) != asset || room.Record.sourceSha256 != pin.sourceSha256 || room.Record.manifestSha256 != pin.manifestSha256 || room.Manifest.sourceSha256 != pin.sourceSha256 || room.Manifest.roomId != "R09")
                throw new InvalidDataException("Boss presentation room/source owner differs from its checked original.");
            return pin;
        }
        private static bool MeshScope(string directory, MeshRecord record, bool collider)
        {
            if (collider || record == null || record.name != "bake-props_fixtures" || Asset(directory) != "R09" && Asset(directory) != "R09-UD") return false;
            if (Scope(directory) == null) return false; var expected = payload.Value.sourceMesh;
            if (record.meshFile != expected.meshFile || record.sha256 != expected.sha256 || record.materialIndex != expected.materialIndex || record.vertices != expected.vertices || record.indices != expected.indices || record.triangles != expected.triangles)
                throw new InvalidDataException("Boss presentation mesh differs from its checked original record.");
            return true;
        }
        internal static string MeshCacheToken(string directory, MeshRecord record, bool collider) => MeshScope(directory, record, collider) ? "|boss-presentation-v80|" + PayloadSha256 : "";
        internal static BarMeshData Apply(string directory, MeshRecord record, bool collider, BarMeshData source)
        {
            if (!MeshScope(directory, record, collider)) return source;
            if (FrameHash(source) != payload.Value.originalFrameSha256) throw new InvalidDataException("Boss presentation requires the decoded original BAR1 frame.");
            BarMeshData replacement; var p = payload.Value;
            using (var compressed = new MemoryStream(Resource(p.replacementResource, p.replacementSha256, 64 * 1024 * 1024), false))
            using (var gzip = new GZipStream(compressed, CompressionMode.Decompress)) replacement = BarMeshReader.Decode(gzip, record, false);
            ValidateReplacement(source, replacement, p.waxVertices); return replacement;
        }
        internal static string FrameHash(BarMeshData data)
        {
            if (data?.Positions == null || data.Normals?.Length != data.Positions.Length || data.UV?.Length != data.Positions.Length || data.Tangents?.Length != data.Positions.Length || data.Indices == null)
                throw new InvalidDataException("Boss presentation requires a complete render frame.");
            using (var memory = new MemoryStream())
            {
                using (var writer = new BinaryWriter(memory, System.Text.Encoding.UTF8, true))
                {
                    for (int i = 0; i < data.Positions.Length; i++)
                    {
                        var p = data.Positions[i]; var n = data.Normals[i]; var uv = data.UV[i]; var t = data.Tangents[i];
                        writer.Write(p.x); writer.Write(p.y); writer.Write(p.z); writer.Write(n.x); writer.Write(n.y); writer.Write(n.z); writer.Write(uv.x); writer.Write(uv.y); writer.Write(t.x); writer.Write(t.y); writer.Write(t.z); writer.Write(t.w);
                    }
                    foreach (int index in data.Indices) writer.Write(index);
                }
                return BarMeshReader.Hash(memory.ToArray());
            }
        }
        private static bool Exact(float a, float b) => BitConverter.SingleToInt32Bits(a) == BitConverter.SingleToInt32Bits(b);
        private static bool Exact(Vector3 a, Vector3 b) => Exact(a.x, b.x) && Exact(a.y, b.y) && Exact(a.z, b.z);
        internal static void ValidateReplacement(BarMeshData original, BarMeshData replacement, int[] waxVertices)
        {
            if (waxVertices == null || waxVertices.Length != 0) throw new InvalidDataException("The base atlas adapter cannot admit a wax geometry morph; the separate source-owned wax stage owns it.");
            if (original.Positions.Length != replacement.Positions.Length || original.Indices.Length != replacement.Indices.Length || !original.Indices.SequenceEqual(replacement.Indices)) throw new InvalidDataException("Boss presentation changed source indices/counts.");
            var wax = new bool[original.Positions.Length]; foreach (int i in waxVertices) { if (i < 0 || i >= wax.Length || wax[i]) throw new InvalidDataException("Invalid checked wax vertex ownership."); wax[i] = true; }
            for (int i = 0; i < wax.Length; i++)
            {
                if (!wax[i] && (!Exact(original.Positions[i], replacement.Positions[i]) || !Exact(original.Normals[i], replacement.Normals[i]))) throw new InvalidDataException("Boss presentation moved an unrelated source position/normal.");
                var n = replacement.Normals[i]; var t = replacement.Tangents[i]; var uv = replacement.UV[i];
                float ns = n.sqrMagnitude, ts = t.x * t.x + t.y * t.y + t.z * t.z, dot = n.x * t.x + n.y * t.y + n.z * t.z;
                if (float.IsNaN(ns + ts + uv.x + uv.y + t.w) || float.IsInfinity(ns + ts + uv.x + uv.y + t.w) || ns < .8f || ns > 1.2f || ts < .8f || ts > 1.2f || Math.Abs(dot) > .025f || Math.Abs(Math.Abs(t.w) - 1) > .0001f || uv.x < 0 || uv.y < 0 || uv.x > 1 || uv.y > 1)
                    throw new InvalidDataException("Boss presentation has an invalid tangent frame or UV.");
            }
        }
        private static TexturePin Texture(string directory, string relative, bool linear, LoadedRoom room)
        {
            if (relative != "textures/props_fixtures_albedo.png" && relative != "textures/props_fixtures_normal.png" && relative != "textures/props_fixtures_metal_smooth.png") return null;
            if (Scope(directory, room) == null) return null;
            var pin = payload.Value.textures.SingleOrDefault(p => p.relative == relative);
            if (pin == null || pin.linear != linear) throw new InvalidDataException("Boss presentation texture color-space role differs from its checked source.");
            return pin;
        }
        // Discovery is pure managed work: it prevents prefetch from uploading
        // the retired atlas before this exact replacement can be selected.
        internal static bool HandlesTexture(string directory, string relative, bool linear, LoadedRoom room) => Texture(directory, relative, linear, room) != null;
        internal static bool TryTexture(string directory, string relative, bool linear, LoadedRoom room, TextureSamplerRecord sampler, out Texture2D texture)
        {
            texture = null; var pin = Texture(directory, relative, linear, room); if (pin == null) return false;
            string path = Path.Combine(directory, relative.Replace('/', Path.DirectorySeparatorChar));
            string alias = "boss-presentation-v80|" + Path.GetFullPath(path) + "|" + pin.sha256 + (linear ? "|linear" : "|srgb") + TextureSamplerPolicy.Key(sampler);
            if (room.R09Textures.TryGetValue(alias, out texture)) { room.Diagnostic?.Event("texture-room-local-hit"); return true; }
            if (SharedRoomResources.TryAcquireAlias(alias, room, out texture)) { room.ResidentTextureHits++; room.R09Textures.Add(alias, texture); return true; }
            var source = new VerifiedResourceFile(path, pin.originalSha256, 256L * 1024 * 1024, room.Diagnostic, "texture"); room.PendingSources.Add(source);
            try
            {
                source.Read(); // Verify/lock provenance, discard original PNG; no old GPU copy.
                room.ColdResourceReads++; room.ColdEncodedBytes += source.BytesRead;
                string key = RoomTextureIdentity.Key(pin.sha256, linear, sampler);
                if (SharedRoomResources.TryAcquire<Texture2D>(key, room, out texture))
                { SharedRoomResources.BindAlias(alias, key, source, room); room.R09Textures.Add(alias, texture); return true; }
                var bytes = Resource(pin.resource, pin.sha256, 64 * 1024 * 1024);
                texture = new Texture2D(2, 2, TextureFormat.RGBA32, true, linear); room.Resources.Add(texture);
                if (!ImageConversion.LoadImage(texture, bytes, true) || texture.width != 4096 || texture.height != 4096) throw new InvalidDataException("Boss presentation texture dimensions/codec differ from checked 4K PNG.");
                texture.name = "V80 R09 checked source finish " + relative;
                texture.filterMode = TextureSamplerPolicy.Filter(sampler) == "point" ? FilterMode.Point : TextureSamplerPolicy.Filter(sampler) == "bilinear" ? FilterMode.Bilinear : FilterMode.Trilinear;
                texture.wrapMode = TextureSamplerPolicy.Wrap(sampler) == "repeat" ? TextureWrapMode.Repeat : TextureWrapMode.Clamp; texture.anisoLevel = 8;
                SharedRoomResources.Retain(key, texture, room, source); SharedRoomResources.BindAlias(alias, key, source, room); room.R09Textures.Add(alias, texture); return true;
            }
            catch { if (room.PendingSources.Remove(source)) source.Dispose(); throw; }
        }
    }
}
