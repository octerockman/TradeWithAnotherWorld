using System;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;

namespace BlackAbbeySixRooms
{
    /// <summary>Room-owned water presentation and live isolation controls.</summary>
    internal static class WaterPresentation
    {
        internal const float FadeColorAlpha = .25f, FadeSmoothness = .65f;
        internal static bool IsSurface(PackageManifest manifest, MeshRecord mesh)
        {
            if (manifest?.materials == null || mesh == null || mesh.materialIndex < 0 ||
                mesh.materialIndex >= manifest.materials.Length || !manifest.materials[mesh.materialIndex].transparent) return false;
            return mesh.name == "water" || mesh.name == "bake-water" && KitArchitectureProfile.Matches(manifest.sourceSha256);
        }

        internal static Material FindLoadedTransparentStandard()
        {
            return Resources.FindObjectsOfTypeAll<Material>()
                .Where(m => m && m.shader && m.shader.name == "Standard" && m.shader.isSupported &&
                    !m.name.StartsWith("BA test |", StringComparison.Ordinal) &&
                    (m.IsKeywordEnabled("_ALPHABLEND_ON") || m.IsKeywordEnabled("_ALPHAPREMULTIPLY_ON")) &&
                    m.HasProperty("_MainTex") && m.HasProperty("_BumpMap") && m.HasProperty("_MetallicGlossMap") && m.HasProperty("_Glossiness"))
                .OrderByDescending(m => m.IsKeywordEnabled("_ALPHABLEND_ON"))
                .ThenBy(m => m.name, StringComparer.Ordinal).FirstOrDefault();
        }

        internal static void LogNativeTransparency(Action<string> log)
        {
            var materials = Resources.FindObjectsOfTypeAll<Material>()
                .Where(m => m && m.shader && !m.name.StartsWith("BA test |", StringComparison.Ordinal) &&
                    (m.renderQueue >= 3000 || m.GetTag("RenderType", false) == "Transparent"))
                .OrderBy(m => m.shader.name, StringComparer.Ordinal).ThenBy(m => m.name, StringComparer.Ordinal).ToArray();
            log($"BA TRANSPARENCY_PREFLIGHT: loaded native transparent materials={materials.Length}; inventory limited to30. This is material state, not proof that a requested shader variant renders correctly.");
            foreach (var m in materials.Take(30))
                log($"BA NATIVE_TRANSPARENT: material={m.name}; shader={m.shader.name}; supported={m.shader.isSupported}; queue={m.renderQueue}; keywords={string.Join(",", m.shaderKeywords)}; _Color={m.HasProperty("_Color")}; _TintColor={m.HasProperty("_TintColor")}; _MainTex={m.HasProperty("_MainTex")}.");
            var selected = FindLoadedTransparentStandard();
            log(selected ? $"BA NATIVE_TRANSPARENT_STANDARD: {selected.name}; shader={selected.shader.name}; activeKeywords={string.Join(",", selected.shaderKeywords)}." : "BA NATIVE_TRANSPARENT_STANDARD: none loaded. Standard transparency variant remains unverified.");
        }

        internal static void Bind(LoadedRoom room, MeshRenderer renderer, Action<string> log)
        {
            if (room.WaterRenderer) throw new InvalidOperationException("Only one BA water renderer is expected.");
            room.WaterRenderer = renderer;
            room.WaterMaterial = renderer.sharedMaterial;
            room.WaterOriginal = new Material(room.WaterMaterial) { name = "BA test | original water diagnostic snapshot" };
            room.Resources.Add(room.WaterOriginal);
            Fade(room, log);
        }

        private static void Require(LoadedRoom room)
        {
            if (room == null || !room.Root || !room.WaterRenderer || !room.WaterMaterial || !room.WaterOriginal)
                throw new InvalidOperationException("Load BA before changing its water presentation.");
        }
        internal static void Hide(LoadedRoom room, Action<string> log)
        {
            Require(room); room.WaterRenderer.enabled = false;
            log("BA WATER_DIAGNOSTIC: water renderer hidden only. Stone, other room meshes, colliders and candles are unchanged. Use twa_test_water_show to restore it.");
        }
        internal static void Show(LoadedRoom room, Action<string> log)
        {
            Require(room); room.WaterRenderer.enabled = true;
            log("BA WATER_DIAGNOSTIC: water renderer shown with its current material."); LogState(room, log);
        }
        internal static void Original(LoadedRoom room, Action<string> log)
        {
            Require(room); room.WaterMaterial.CopyPropertiesFromMaterial(room.WaterOriginal);
            room.WaterRenderer.enabled = true;
            log("BA WATER_DIAGNOSTIC: restored loaded premultiplied-water baseline for comparison;2mm water clearance is retained."); LogState(room, log);
        }
        internal static void Fade(LoadedRoom room, Action<string> log)
        {
            Require(room);
            var m = room.WaterMaterial; m.CopyPropertiesFromMaterial(room.WaterOriginal);
            m.DisableKeyword("_ALPHATEST_ON"); m.DisableKeyword("_ALPHAPREMULTIPLY_ON"); m.EnableKeyword("_ALPHABLEND_ON");
            if (m.HasProperty("_Mode")) m.SetFloat("_Mode", 2f);
            if (m.HasProperty("_SrcBlend")) m.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
            if (m.HasProperty("_DstBlend")) m.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            if (m.HasProperty("_ZWrite")) m.SetInt("_ZWrite", 0);
            if (m.HasProperty("_Color")) m.SetColor("_Color", new Color(.35f, .4f, .35f, FadeColorAlpha));
            // The entire water normal map is flat and its occupied metallic
            // pixels are zero. Avoid requesting needless extra shader variants.
            m.DisableKeyword("_NORMALMAP"); m.DisableKeyword("_METALLICGLOSSMAP");
            if (m.HasProperty("_BumpMap")) m.SetTexture("_BumpMap", null);
            if (m.HasProperty("_MetallicGlossMap")) m.SetTexture("_MetallicGlossMap", null);
            if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", 0f);
            if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", FadeSmoothness);
            m.SetOverrideTag("RenderType", "Transparent"); m.renderQueue = 3000;
            room.WaterRenderer.enabled = true;
            log("BA WATER_DIAGNOSTIC: near-clear Fade candidate applied, color(0.35,0.4,0.35,0.25), effective atlas alpha~0.063, scalar smoothness0.65 and metallic0. Flat water normal and constant metallic/smoothness textures are unbound to avoid unnecessary shader variants; files/geometry/UV unchanged. Live appearance and shader variant remain to be checked."); LogState(room, log);
        }
        internal static void LogState(LoadedRoom room, Action<string> log)
        {
            if (room == null || !room.WaterRenderer || !room.WaterMaterial) { log("BA WATER_STATE: no loaded water renderer."); return; }
            var m = room.WaterMaterial;
            var albedo = m.GetTexture("_MainTex") as Texture2D;
            log($"BA WATER_STATE: enabled={room.WaterRenderer.enabled}; localY={room.WaterRenderer.transform.localPosition.y:F4}; shader={m.shader.name}; mode={(m.HasProperty("_Mode") ? m.GetFloat("_Mode").ToString() : "missing")}; srcBlend={(m.HasProperty("_SrcBlend") ? m.GetFloat("_SrcBlend").ToString() : "missing")}; dstBlend={(m.HasProperty("_DstBlend") ? m.GetFloat("_DstBlend").ToString() : "missing")}; color={(m.HasProperty("_Color") ? m.GetColor("_Color").ToString() : "missing")}; smoothness={(m.HasProperty("_Glossiness") ? m.GetFloat("_Glossiness").ToString() : "missing")}; glossScale={(m.HasProperty("_GlossMapScale") ? m.GetFloat("_GlossMapScale").ToString() : "missing")}; normalBound={(m.HasProperty("_BumpMap") && m.GetTexture("_BumpMap"))}; metallicSmoothnessBound={(m.HasProperty("_MetallicGlossMap") && m.GetTexture("_MetallicGlossMap"))}; albedoFormat={(albedo ? albedo.format.ToString() : "missing")}; keywords={string.Join(",",m.shaderKeywords)}.");
        }
    }
}
