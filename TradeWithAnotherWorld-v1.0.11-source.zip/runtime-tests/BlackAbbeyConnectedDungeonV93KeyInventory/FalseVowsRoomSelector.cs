using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    internal sealed class FalseVowsRoomNode
    {
        internal string InstanceId, SourceId;
        internal FalseVowsRoomNode(string instanceId, string sourceId) { InstanceId = instanceId; SourceId = sourceId; }
    }
    internal sealed class FalseVowsRoomEdge
    {
        internal string A, B;
        internal FalseVowsRoomEdge(string a, string b) { A = a; B = b; }
    }
    // Select stable instance IDs AFTER the real full-bounds planner succeeds.
    // This does not shrink geometry or modify an existing saved layout.
    internal static class FalseVowsRoomSelector
    {
        internal static FalseVowsRoomBinding Select(IEnumerable<FalseVowsRoomNode> input, IEnumerable<FalseVowsRoomEdge> edges,
            string entryId, string bossId, string gateA, string gateB)
            => Select(input,edges,entryId,bossId,gateA,gateB,0);
        internal static FalseVowsRoomBinding Select(IEnumerable<FalseVowsRoomNode> input, IEnumerable<FalseVowsRoomEdge> edges,
            string entryId, string bossId, string gateA, string gateB,int minimumHops)
        {
            if(!TrySelect(input,edges,entryId,bossId,gateA,gateB,minimumHops,out var result))
                throw new InvalidDataException("The quest rooms need at least three intervening rooms along every available pre-boss route.");
            return result;
        }
        internal static bool TrySelect(IEnumerable<FalseVowsRoomNode> input, IEnumerable<FalseVowsRoomEdge> edges,
            string entryId,string bossId,string gateA,string gateB,int minimumHops,out FalseVowsRoomBinding result)
        {
            var nodes = input?.ToArray(); var links = edges?.ToArray();
            var depths = Graph(nodes, links, entryId, bossId, gateA, gateB);
            if(minimumHops!=0&&minimumHops!=4)throw new ArgumentOutOfRangeException(nameof(minimumHops));
            result=null;
            if(minimumHops>0)
            {
                // Use actual shortest paths with the closed boss gate removed.
                // Entry depth differences alone are insufficient on loops.
                var available=nodes.Where(n=>depths.ContainsKey(n.InstanceId)).OrderBy(n=>depths[n.InstanceId]).ThenBy(n=>n.InstanceId,StringComparer.Ordinal).ToArray();
                var distance=new Dictionary<string,Dictionary<string,int>>(StringComparer.Ordinal);
                foreach(var n in available.Where(n=>n.SourceId=="R02"||n.SourceId=="R06"||n.SourceId=="R03"))
                    distance[n.InstanceId]=Distances(links,n.InstanceId,gateA,gateB);
                foreach(var s in available.Where(n=>n.SourceId=="R02"))
                foreach(var v in available.Where(n=>n.SourceId=="R06"))
                foreach(var a in available.Where(n=>n.SourceId=="R03"))
                {
                    if(distance[s.InstanceId][v.InstanceId]<minimumHops||distance[s.InstanceId][a.InstanceId]<minimumHops||distance[v.InstanceId][a.InstanceId]<minimumHops)continue;
                    result=new FalseVowsRoomBinding{scriptorium=s.InstanceId,vestry=v.InstanceId,saint=a.InstanceId,boss=bossId,gateA=gateA,gateB=gateB};
                    Validate(result,nodes,links,entryId);return true;
                }
                return false;
            }
            string Pick(string source) => nodes.Where(n => n.SourceId == source && depths.ContainsKey(n.InstanceId))
                .OrderBy(n => depths[n.InstanceId]).ThenBy(n => n.InstanceId, StringComparer.Ordinal).Select(n => n.InstanceId).FirstOrDefault()
                ?? throw new InvalidDataException("Selected boss-door route lacks a reachable " + source + " before its closed gate.");
            result = new FalseVowsRoomBinding { scriptorium = Pick("R02"), vestry = Pick("R06"), saint = Pick("R03"), boss = bossId, gateA = gateA, gateB = gateB };
            Validate(result, nodes, links, entryId); return true;
        }
        internal static Dictionary<string,int> Distances(IEnumerable<FalseVowsRoomEdge> edges,string start,string gateA,string gateB)
        {
            var links=edges.ToArray();var result=new Dictionary<string,int>(StringComparer.Ordinal){{start,0}};var queue=new Queue<string>();queue.Enqueue(start);
            while(queue.Count>0)
            {
                var current=queue.Dequeue();foreach(var e in links)
                {
                    if(e.A==gateA&&e.B==gateB||e.A==gateB&&e.B==gateA)continue;
                    string next=e.A==current?e.B:e.B==current?e.A:null;
                    if(next!=null&&!result.ContainsKey(next)){result.Add(next,result[current]+1);queue.Enqueue(next);}
                }
            }
            return result;
        }
        internal static void Validate(FalseVowsRoomBinding bindings, IEnumerable<FalseVowsRoomNode> input, IEnumerable<FalseVowsRoomEdge> edges, string entryId)
        {
            if (!FalseVowsState.BindingValid(bindings)) throw new InvalidDataException("Invalid saved quest-room bindings.");
            var nodes = input?.ToArray(); var links = edges?.ToArray();
            var depths = Graph(nodes, links, entryId, bindings.boss, bindings.gateA, bindings.gateB);
            foreach (var pair in new[] { new[] { bindings.scriptorium, "R02" }, new[] { bindings.vestry, "R06" }, new[] { bindings.saint, "R03" } })
                if (!nodes.Any(n => n.InstanceId == pair[0] && n.SourceId == pair[1]) || !depths.ContainsKey(pair[0]))
                    throw new InvalidDataException("Saved quest-room identity/source/reachability changed: " + pair[0]);
        }
        internal static bool UsesQuestVariant(FalseVowsRoomBinding rooms, string instanceId) => rooms != null &&
            (instanceId == rooms.scriptorium || instanceId == rooms.vestry || instanceId == rooms.saint || instanceId == rooms.boss);
        internal static bool UseCompleteSaint(FalseVowsRoomBinding rooms, string instanceId, string baseSourceId) => rooms != null &&
            (baseSourceId == "R03" || baseSourceId == "R03_complete") && instanceId != rooms.saint;
        private static Dictionary<string, int> Graph(FalseVowsRoomNode[] nodes, FalseVowsRoomEdge[] edges, string entry, string boss, string gateA, string gateB)
        {
            if (nodes == null || edges == null || nodes.Length < 4 || nodes.Length > 128 || edges.Length > 256 || nodes.Any(n => n == null ||
                string.IsNullOrWhiteSpace(n.InstanceId) || string.IsNullOrWhiteSpace(n.SourceId)) || nodes.Select(n => n.InstanceId).Distinct(StringComparer.Ordinal).Count() != nodes.Length ||
                !nodes.Any(n => n.InstanceId == entry && n.SourceId == "R01") || !nodes.Any(n => n.InstanceId == boss && (n.SourceId == "R09"||n.SourceId==R09SplitIdentity.FalseVowsHall)) || entry == boss || gateA == gateB)
                throw new InvalidDataException("Complete unique planned rooms and entrance/boss identities are required.");
            bool split=nodes.Single(n=>n.InstanceId==boss).SourceId==R09SplitIdentity.FalseVowsHall;
            var arenas=nodes.Where(n=>n.SourceId==R09SplitIdentity.Chamber).ToArray();
            string arena=boss;
            if(split)
            {
                if(arenas.Length!=1||nodes.Count(n=>R09SplitIdentity.IsHall(n.SourceId))!=1||
                    !((gateA==boss&&gateB==arenas[0].InstanceId)||(gateB==boss&&gateA==arenas[0].InstanceId)))
                    throw new InvalidDataException("False Vows requires one A1 hall and its one explicit A1/B boundary.");
                arena=arenas[0].InstanceId;
            }
            var ids = new HashSet<string>(nodes.Select(n => n.InstanceId), StringComparer.Ordinal);
            bool IsGate(FalseVowsRoomEdge e) => e.A == gateA && e.B == gateB || e.A == gateB && e.B == gateA;
            if (edges.Any(e => e == null || e.A == e.B || !ids.Contains(e.A) || !ids.Contains(e.B)) || edges.Count(IsGate) != 1)
                throw new InvalidDataException("The selected progression gate must identify one actual planned connection.");
            var result = new Dictionary<string, int>(StringComparer.Ordinal) { [entry] = 0 }; var queue = new Queue<string>(); queue.Enqueue(entry);
            while (queue.Count > 0)
            {
                string current = queue.Dequeue();
                foreach (var e in edges.Where(e => !IsGate(e)))
                {
                    string next = e.A == current ? e.B : e.B == current ? e.A : null;
                    if (next != null && !result.ContainsKey(next)) { result.Add(next, result[current] + 1); queue.Enqueue(next); }
                }
            }
            if (result.ContainsKey(arena)) throw new InvalidDataException("Boss gate has an alternate unlocked bypass.");
            if(split&&!result.ContainsKey(boss))throw new InvalidDataException("The scale hall must be reachable before its own closed boss gate.");
            // A disconnected boss is not a meaningful gate either.
            if (!result.ContainsKey(gateA) && !result.ContainsKey(gateB)) throw new InvalidDataException("The boss gate cannot be approached from the entrance.");
            var connected = new HashSet<string>(StringComparer.Ordinal) { entry }; queue.Enqueue(entry);
            while (queue.Count > 0)
            {
                string current = queue.Dequeue();
                foreach (var e in edges)
                {
                    string next = e.A == current ? e.B : e.B == current ? e.A : null;
                    if (next != null && connected.Add(next)) queue.Enqueue(next);
                }
            }
            if (!connected.Contains(arena)) throw new InvalidDataException("The planned boss is disconnected even with its gate open.");
            return result;
        }
    }
}
