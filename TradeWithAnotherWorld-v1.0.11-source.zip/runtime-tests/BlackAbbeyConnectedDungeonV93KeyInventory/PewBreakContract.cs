using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace BlackAbbeySixRooms
{
#pragma warning disable 0649
    internal sealed class PewOwnershipManifest { public int schemaVersion; public PewRoomRecord[] rooms; }
    internal sealed class PewRoomRecord
    {
        public string assetId, roomId, sourceSha256, manifestSha256;
        public PewRecord[] pews;
    }
    internal sealed class PewRecord
    {
        public string id;
        public float[] boundsMin, boundsMax;
        public PewMeshRecord[] meshes;
    }
    internal sealed class PewMeshRecord
    {
        public string purpose, name, sourceMeshSha256;
        public int sourceVertexCount, sourceIndexCount;
        public PewIndexRange[] ranges;
    }
    internal sealed class PewIndexRange
    {
        public int startIndex, indexCount;
        public string sourceObject;
        public bool suppressDebris;
    }
#pragma warning restore 0649

    internal static class PewBreakContract
    {
        internal const string RelativePath = "breakable-pews/manifest.json";
        internal const string ManifestSha256 = "21e720e190cafbd61cacfe4eb0a7845fe9aa01bc0d2a483bd2544cc61d05370f";
        internal static bool Available(string roomId) => roomId == "R04" || roomId == "R09" || R09SplitIdentity.IsPiece(roomId);
        internal static PewRoomRecord Read(string dataRoot, PackageManifest room, string roomManifestHash)
        {
            string path = Path.GetFullPath(Path.Combine(dataRoot, RelativePath));
            long maximumBytes=(KitArchitectureProfile.IsKitRoot(dataRoot)?2L:1L)*1024*1024;
            if (!File.Exists(path) || new FileInfo(path).Length > maximumBytes || CatalogReader.HashFile(path) != KitArchitectureProfile.ExpectedHash(dataRoot,RelativePath,ManifestSha256))
                throw new InvalidDataException("Missing or changed source-bound pew ownership data.");
            return Validate(JsonConvert.DeserializeObject<PewOwnershipManifest>(File.ReadAllText(path)), room, roomManifestHash);
        }
        internal static PewRoomRecord Validate(PewOwnershipManifest data, PackageManifest room, string roomManifestHash)
        {
            if (data == null || data.schemaVersion != 1 || data.rooms == null || data.rooms.Any(r => r == null) ||
                room == null || !Available(room.roomId)) throw new InvalidDataException("Invalid pew ownership room inventory.");
            var rebuilt=KitArchitectureProfile.Find(room.sourceSha256,roomManifestHash);
            if(rebuilt!=null)
            {
                if(data.rooms.Length!=4||!data.rooms.Select(r=>r.assetId).OrderBy(x=>x).SequenceEqual(new[]{"R04","R09-A1","R09-A2","R09-B"})||
                    data.rooms.Any(r=>{var binding=KitArchitectureProfile.Find(r.sourceSha256,r.manifestSha256);return binding==null||binding.assetId!=r.assetId||binding.roomId!=r.roomId;}))
                    throw new InvalidDataException("Rebuilt pew inventory requires three exact normal/variant asset bindings.");
            }
            else if(data.rooms.Length!=2||!data.rooms.Select(r=>r.roomId).OrderBy(x=>x).SequenceEqual(new[]{"R04","R09"}))
                throw new InvalidDataException("Invalid legacy pew ownership inventory.");
            var selected = rebuilt!=null?data.rooms.Single(r=>r.assetId==rebuilt.assetId&&r.sourceSha256==room.sourceSha256&&r.manifestSha256==roomManifestHash):data.rooms.Single(r=>r.roomId==room.roomId);
            int count = rebuilt!=null?rebuilt.breakablePews:room.roomId == "R04" ? 4 : 8;
            if (selected.sourceSha256 != (rebuilt!=null?room.sourceSha256:UnrecordedDeadSourceBindings.Canonical(room.roomId,room.sourceSha256)) || selected.manifestSha256 != (rebuilt!=null?roomManifestHash:UnrecordedDeadSourceBindings.CanonicalManifest(roomManifestHash)) ||
                selected.pews == null || selected.pews.Length != count || selected.pews.Any(p => p == null) ||
                selected.pews.Select(p => p.id).Distinct(StringComparer.Ordinal).Count() != count)
                throw new InvalidDataException("Pews differ from the exact loaded room source.");
            var owned = new Dictionary<string, HashSet<int>>(StringComparer.Ordinal);
            foreach (var pew in selected.pews)
            {
                if (string.IsNullOrWhiteSpace(pew.id) || pew.id.Length > 96 || !Bounds(pew.boundsMin, pew.boundsMax) ||
                    pew.meshes == null || pew.meshes.Length < 2 || pew.meshes.Length > 12 || pew.meshes.Any(m => m == null) ||
                    pew.meshes.Select(m => m.purpose + "|" + m.name).Distinct(StringComparer.Ordinal).Count() != pew.meshes.Length ||
                    !pew.meshes.Any(m => m.purpose == "render") || !pew.meshes.Any(m => m.purpose == "collider"))
                    throw new InvalidDataException("Invalid individual pew ownership.");
                foreach (var mesh in pew.meshes)
                {
                    if (mesh.purpose != "render" && mesh.purpose != "collider") throw new InvalidDataException("Unknown pew mesh role.");
                    var source = (mesh.purpose == "render" ? room.meshes : room.colliderMeshes).SingleOrDefault(m => m.name == mesh.name);
                    if (source == null || source.sha256 != mesh.sourceMeshSha256 || source.vertices != mesh.sourceVertexCount ||
                        source.indices != mesh.sourceIndexCount || mesh.ranges == null || mesh.ranges.Length == 0 || mesh.ranges.Length > 512)
                        throw new InvalidDataException("Pew mask differs from the exact source BAR1 mesh.");
                    string key = mesh.purpose + "|" + mesh.name;
                    if (!owned.TryGetValue(key, out var indices)) owned.Add(key, indices = new HashSet<int>());
                    foreach (var range in mesh.ranges)
                    {
                        if (range == null || range.startIndex < 0 || range.startIndex % 3 != 0 || range.indexCount <= 0 || range.indexCount % 3 != 0 ||
                            (long)range.startIndex + range.indexCount > mesh.sourceIndexCount || string.IsNullOrWhiteSpace(range.sourceObject))
                            throw new InvalidDataException("Invalid pew source-object triangle range.");
                        for (int triangle = range.startIndex / 3; triangle < (range.startIndex + range.indexCount) / 3; triangle++)
                            if (!indices.Add(triangle)) throw new InvalidDataException("Overlapping pew triangle ownership.");
                    }
                }
            }
            return selected;
        }
        private static bool Bounds(float[] min, float[] max) => min != null && max != null && min.Length == 3 && max.Length == 3 &&
            min.Concat(max).All(v => !float.IsNaN(v) && !float.IsInfinity(v)) && Enumerable.Range(0, 3).All(i => max[i] > min[i]);
    }
}
