using System;

namespace BlackAbbeySixRooms
{
    internal static class TrimMeshIdentity
    {
        // The original Unity mesh identity captures any already-applied
        // source-bound backing repairs. Exact map/source/BAR1 hashes prevent
        // another revision or room from reusing the derived mesh.
        internal static string Key(int originalInstance, string mapHash, string sourceHash, string meshHash, int vertices, int indices)
        {
            if (originalInstance == 0 || !Hash(mapHash) || !Hash(sourceHash) || !Hash(meshHash) || vertices < 3 || indices < 3 || indices % 3 != 0)
                throw new ArgumentException("Expected an exact source/trim identity.");
            return "trim-mesh-v30|" + originalInstance + "|" + mapHash + "|" + sourceHash + "|" + meshHash + "|" + vertices + "|" + indices;
        }
        private static bool Hash(string value)
        {
            if (value == null || value.Length != 64) return false;
            foreach (char c in value) if (!(c >= '0' && c <= '9') && !(c >= 'a' && c <= 'f')) return false;
            return true;
        }
    }
}
