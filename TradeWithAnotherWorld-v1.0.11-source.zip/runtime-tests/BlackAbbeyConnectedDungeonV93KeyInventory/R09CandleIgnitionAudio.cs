using System;
using System.Linq;
using Jotunn.Managers;
using UnityEngine;
using UnityEngine.Audio;

namespace BlackAbbeySixRooms
{
    // Borrow only a native clip and native SFX mixer. Do not instantiate its
    // whole candle-on prefab, particle flash, toggle script, or network object.
    internal sealed class R09CandleIgnitionAudio : MonoBehaviour
    {
        private readonly AudioSource[] voices = new AudioSource[4];
        private readonly R09CandleIgnitionPolicy policy = new R09CandleIgnitionPolicy();
        private readonly System.Random variation = new System.Random(34022);
        private AudioClip clip;
        private AudioMixerGroup mixer;
        private float minVolume, maxVolume, minPitch, maxPitch;
        private double nextResolve;
        private Action<string> log;
        private string lastFailure;
        internal static R09CandleIgnitionAudio Attach(GameObject root, Action<string> write)
        {
            var owner = root.AddComponent<R09CandleIgnitionAudio>(); owner.log = write;
            for (int i = 0; i < owner.voices.Length; ++i)
            {
                var child = new GameObject("BA candle ignition voice " + i); child.transform.SetParent(root.transform, false);
                var source = child.AddComponent<AudioSource>(); source.playOnAwake = false; source.loop = false;
                source.spatialBlend = 1; source.dopplerLevel = 0; source.rolloffMode = AudioRolloffMode.Linear;
                source.minDistance = 4; source.maxDistance = 42; source.priority = 112;
                owner.voices[i] = source;
            }
            return owner;
        }
        internal void Warmup()
        {
            // Resolve and request native audio data before the visible wave.
            // No source is played and no delayed ignition is queued here.
            if (Resolve() && clip && (clip.loadState == AudioDataLoadState.Unloaded || clip.loadState == AudioDataLoadState.Failed))
                clip.LoadAudioData();
        }
        private bool Resolve()
        {
            if (clip && mixer) return true;
            double now = Time.realtimeSinceStartup;
            if (now < nextResolve) return false; nextResolve = now + 1;
            try
            {
                var candle = PrefabManager.Instance.GetPrefab(TradeWithAnotherWorld.ResinCandleFlame.SourcePrefab);
                var fireplace = candle ? candle.GetComponent<Fireplace>() : null;
                var effects = fireplace?.m_toggleOnEffects?.m_effectPrefabs;
                var effect = effects?.Where(e => e.m_enabled && e.m_prefab && e.m_prefab.name == "fx_candle_on").Select(e => e.m_prefab).Distinct().SingleOrDefault();
                if (!effect) throw new InvalidOperationException("Native Candle_resin ignition effect is not available.");
                var sounds = effect.GetComponentsInChildren<ZSFX>(true).Where(s => s.m_audioClips != null && s.m_audioClips.Any(c => c && c.name == "sfx_lightcandle")).ToArray();
                if (sounds.Length != 1) throw new InvalidOperationException("Native candle ignition sound is missing or ambiguous.");
                var native = sounds[0]; clip = native.m_audioClips.Single(c => c && c.name == "sfx_lightcandle");
                if (clip.channels != 2 || clip.frequency != 44100 || Math.Abs(clip.length - .85f) > .02f)
                    throw new InvalidOperationException("Native candle ignition clip differs from inspected source.");
                if (native.m_minPitch < 1 || native.m_maxPitch > 1.13f || native.m_minPitch > native.m_maxPitch ||
                    native.m_minVol < 0 || native.m_maxVol > 1 || native.m_minVol > native.m_maxVol)
                    throw new InvalidOperationException("Native candle ignition ranges differ from inspected source.");
                minVolume = native.m_minVol * .8f; maxVolume = native.m_maxVol * .8f;
                minPitch = native.m_minPitch; maxPitch = native.m_maxPitch;
                // The prefab's output group is null. Deliberately borrow the
                // same verified SFX group used by this helper's audible effects.
                foreach (var name in new[] { R07StoneAudio.SlidePrefab, R07StoneAudio.ImpactPrefab })
                {
                    var prefab = PrefabManager.Instance.GetPrefab(name);
                    var source = prefab ? prefab.GetComponentInChildren<AudioSource>(true) : null;
                    var candidate = source ? source.outputAudioMixerGroup : null;
                    if (candidate && AbbeyAmbiencePolicy.IsDungeonOutputGroup(candidate.name)) { mixer = candidate; break; }
                }
                var ambient = AudioMan.instance ? AudioMan.instance.m_ambientMixer : null;
                if (!mixer && ambient && ambient.audioMixer)
                    mixer = ambient.audioMixer.FindMatchingGroups("SFX").FirstOrDefault(g => g && AbbeyAmbiencePolicy.IsDungeonOutputGroup(g.name));
                if (!mixer) throw new InvalidOperationException("Native SFX mixer is not ready.");
                lastFailure = null;
                log?.Invoke("R09_CANDLE_IGNITION_READY: native Candle_resin/fx_candle_on/sfx_lightcandle;0.85s; SFX=" + mixer.name +
                    "; authoredGain0.8*native; pitch=" + minPitch + ".." + maxPitch + ";4voices; nearest new fixture batch; no setup/re-enable/completion bursts.");
                return true;
            }
            catch (Exception error)
            {
                clip = null; mixer = null;
                if (lastFailure != error.Message) log?.Invoke("R09_CANDLE_IGNITION_WAITING: " + error.Message + "; candle visuals/music continue.");
                lastFailure = error.Message; return false;
            }
        }
        internal void Play(Vector3 position)
        {
            if (!isActiveAndEnabled || !gameObject.activeInHierarchy) return;
            try
            {
                if (!Resolve()) return;
                // A native decoder still loading must not play an old cue late.
                // Later genuine off-to-on events may try again; no backlog.
                if (clip.loadState != AudioDataLoadState.Loaded) return;
                var voice = voices.FirstOrDefault(s => s && !s.isPlaying);
                if (!voice || !policy.TryEmit(Time.realtimeSinceStartup)) return;
                voice.transform.position = position; voice.clip = clip; voice.outputAudioMixerGroup = mixer;
                voice.volume = Mathf.Lerp(minVolume, maxVolume, (float)variation.NextDouble());
                voice.pitch = Mathf.Lerp(minPitch, maxPitch, (float)variation.NextDouble());
                voice.Play();
            }
            catch (Exception error) { StopVoices(); log?.Invoke("R09 candle ignition skipped safely: " + error.Message); }
        }
        internal void StopVoices() { foreach (var voice in voices) if (voice) voice.Stop(); }
        internal void ResetWave() { StopVoices(); policy.Reset(); }
        private void OnDisable() => StopVoices();
        private void OnDestroy() => StopVoices();
    }
}
