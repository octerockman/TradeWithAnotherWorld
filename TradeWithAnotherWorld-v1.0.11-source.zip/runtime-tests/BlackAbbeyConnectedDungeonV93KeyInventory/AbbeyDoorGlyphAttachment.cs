using System;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Optional ornament has no collider, light, or interaction authority.
    // The whole two-sided chunk follows its owning original leaf pivot.
    internal static class AbbeyDoorGlyphAttachment
    {
        internal static void Attach(Transform root, Transform leftHinge, Transform rightHinge, bool barred)
        {
            AttachLeaf(root, leftHinge, "opening_symbol_left", barred);
            AttachLeaf(root, rightHinge, "opening_symbol_right", barred);
        }

        private static void AttachLeaf(Transform root, Transform hinge, string name, bool barred)
        {
            Transform visual = root.Find(name);
            if (!visual || !hinge) throw new InvalidOperationException("Missing leaf-bound opening rift ornament: " + name);
            visual.SetParent(hinge, false);
            visual.localPosition = -hinge.localPosition;
            visual.localRotation = Quaternion.identity;
            visual.localScale = Vector3.one;
            visual.gameObject.SetActive(!barred);
        }
    }
}
