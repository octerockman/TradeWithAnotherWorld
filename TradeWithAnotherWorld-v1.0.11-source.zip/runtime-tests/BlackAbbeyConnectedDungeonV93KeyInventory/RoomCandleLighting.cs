using System;
using System.Linq;
using System.IO;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    internal static class RoomCandleLighting
    {
        internal const float Intensity = 2.8f, Range = 5.5f;
        internal const int ShadowResolution = 512;
        internal const float ShadowStrength = .85f, ShadowBias = .025f, ShadowNormalBias = .05f, ShadowNearPlane = .05f;
        internal static int Attach(LoadedRoom room, Action<string> log)
        {
            if (room == null || !room.Root || room.Root.GetComponentsInChildren<Light>(true).Length != 0) throw new InvalidOperationException("Candle fixtures require a loaded room without light clones.");
            var sockets = R09CandleSocketOverrides.ForRoom(room.Manifest);
            var points = sockets.Select((socket, index) => {
                if (socket == null) throw new InvalidOperationException("A source candle socket is missing.");
                var p = RoomPackage.Vector(socket.position, "candle socket");
                return new CandleWickGrouping.Wick { Index = index, Name = socket.name, X = p.x, Y = p.y, Z = p.z };
            });
            var groups = CandleWickGrouping.Build(points);
            if (groups.Length > 0)
            {
                var source = NativeCandleFixture.Resolve(log);
                for (int i = 0; i < groups.Length; i++)
                {
                    var group = groups[i]; var anchor = group.Anchor;
                    // Exactly the canonical source light-to-flame offset.
                    // The anchor is an actual wick, never an empty stair center.
                    Vector3 position = new Vector3((float)anchor.X, (float)anchor.Y, (float)anchor.Z) + Vector3.up * TradeWithAnotherWorld.ResinCandleFlame.LightAboveFlame;
                    var host = NativeCandleFixture.Attach(room.Root, source, "BA_" + room.InstanceId + "_FixtureLight | " + (i + 1), position, CandleLightProfile.Intensity(room.Record.roomId, group), CandleLightProfile.Range(room.Record.roomId, group), log);
                    if (R09SplitIdentity.IsPiece(room.Manifest.roomId))
                    {
                        if (group.Wicks.Any(w => w.Z < 0) && group.Wicks.Any(w => w.Z >= 0))
                            throw new InvalidOperationException("R09 chamber/approach candle group crosses its source threshold.");
                        host.AddComponent<R09CandleGroupBinding>().Configure(room.Root, group.Wicks.Select(w => w.Name), (float)group.Wicks.Max(w => w.Z), room.Manifest.sourceSha256, group.Anchor.Name);
                    }
                    log($"CANDLE_GROUP: light={i + 1}; sourceWicks={group.Wicks.Count}; actualAnchor={anchor.Name}; diameter={group.Diameter:F4}m; maximumAllowed={CandleWickGrouping.MaxDiameter:F2}m; no empty-space light.");
                }
            }
            int windows = WindowFixtureLighting.Attach(room, log);
            if (R09SplitIdentity.IsPiece(room.Manifest.roomId)) BossCandleDaylight.Attach(room, log);
            log($"CANDLE_BUDGET: source-wicks={sockets.Length}; native-flicker fixtureLights={groups.Length}; windowSpots={windows}; all wicks covered; no five-light/k-means cap or room-center displacement.");
            return groups.Length + windows;
        }
    }
    internal static class WindowFixtureLighting
    {
        internal static int Attach(LoadedRoom room, Action<string> log)
        {
            var records = room.Manifest.windowLights ?? Array.Empty<WindowLightRecord>();
            WindowProjectionContract.Validate(room.Manifest);
            // Jesse removed distracting boss-room glass projection. Preserve
            // the window models/maps and all other rooms' window lighting.
            if (!WindowLightingPolicy.Enabled(room.Manifest.roomId))
            { log("WINDOW_PROJECTION_DISABLED: R09 by user direction; stained-glass art remains."); return 0; }
            int glassLayer = WindowProjectionShadowScope.Prepare(room, log);
            foreach (var record in records)
            {
                Vector3 position = RoomPackage.Vector(record.position, "window position"), direction = RoomPackage.Vector(record.direction, "window direction");
                Vector3 up = record.up == null ? (Mathf.Abs(Vector3.Dot(direction.normalized, Vector3.up)) > .99f ? Vector3.forward : Vector3.up) : RoomPackage.Vector(record.up, "window up");
                var host = new GameObject("BA_" + room.InstanceId + "_WindowLight | " + record.name); host.transform.SetParent(room.Root.transform, false); host.transform.localPosition = position;
                host.transform.localRotation = Quaternion.LookRotation(direction.normalized, up);
                var light = host.AddComponent<Light>(); light.type = LightType.Spot; light.color = new Color(record.color[0], record.color[1], record.color[2]);
                light.intensity = record.intensity; light.range = DungeonLightReachPolicy.AuxiliaryRange(record.range); light.spotAngle = record.spotAngle; light.innerSpotAngle = record.innerSpotAngle; light.renderMode = LightRenderMode.ForcePixel;
                light.shadows = LightShadows.Soft; light.shadowCustomResolution = record.shadowResolution; light.shadowStrength = record.shadowStrength;
                light.shadowBias = record.shadowBias; light.shadowNormalBias = record.shadowNormalBias; light.shadowNearPlane = record.shadowNearPlane; light.bounceIntensity = 0; light.enabled = true;
                if (WindowProjectionContract.HasCookie(record))
                {
                    light.cookie = LoadCookie(room, record);
                    light.cullingMask = WindowProjectionReceiverPolicy.Mask(LayerMask.NameToLayer("static_solid"),glassLayer);
                }
                host.AddComponent<BudgetedFixture>().Configure(light, record.intensity, true);
                log($"WINDOW_FIXTURE: {record.name}; local={position}; direction={direction.normalized}; intensity={light.intensity:F3}; range={light.range:F2}; spot={light.spotAngle:F1}; inner={light.innerSpotAngle:F1}; color={light.color}; Soft{light.shadowCustomResolution}; cookie={record.cookie ?? "none"}; channel={record.channel ?? "ordinary"}; receiverMask={light.cullingMask}; cookie projection receives on authored static surfaces only.");
            }
            return records.Length;
        }
        static Texture2D LoadCookie(LoadedRoom room, WindowLightRecord record)
        {
            string path = RoomPackage.FilePath(room.PackageDirectory, record.cookie);
            var info = new FileInfo(path);
            if (info.Length > 16 * 1024 * 1024 || CatalogReader.HashFile(path) != record.cookieSha256)
                throw new InvalidDataException("Window cookie differs from its declared source-bound texture.");
            byte[] bytes = File.ReadAllBytes(path);
            if (bytes.Length < 33 || !bytes.Take(8).SequenceEqual(new byte[] { 137,80,78,71,13,10,26,10 }) || bytes[24] != 8 || bytes[25] != 6)
                throw new InvalidDataException("Window cookie requires an RGBA8 PNG with an actual alpha channel.");
            // Alpha is linear transmission generated from the actual glass/lead.
            // No mip chain or sRGB conversion should smear the opaque lead mask.
            var texture = new Texture2D(2, 2, TextureFormat.RGBA32, false, true) { name = "BA window cookie | " + record.name };
            room.Resources.Add(texture);
            if (!ImageConversion.LoadImage(texture, bytes, true) || texture.width < 16 || texture.height < 16 || texture.width > 2048 || texture.height > 2048 || texture.width != texture.height)
                throw new InvalidDataException("Window cookie must be a square16..2048px PNG.");
            texture.wrapMode = TextureWrapMode.Clamp; texture.filterMode = FilterMode.Bilinear; texture.anisoLevel = 0;
            return texture;
        }
    }
}
