using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Jotunn.Managers;
using UnityEngine;
using UnityEngine.Rendering;

namespace BlackAbbeySixRooms
{
    // Constant-valued axes still use equal TwoConstants endpoints. Mixing a
    // float/Constant Y with TwoConstants X/Z makes Unity reject every update.
    // This managed-only factory is exercised against the installed Unity SDK.
    internal readonly struct AbbeyCenserVelocityCurves
    {
        internal readonly ParticleSystem.MinMaxCurve X,Y,Z,Radial,Zero,SpeedModifier;
        internal static AbbeyCenserVelocityCurves Create(bool floor,float downSpeed,float drop,float offsetX,float offsetZ)
        {
            float seconds=Math.Max(.1f,drop/downSpeed);
            float dx=floor?0:offsetX/seconds,dz=floor?0:offsetZ/seconds;
            return new AbbeyCenserVelocityCurves(dx,dz,floor?0:-downSpeed,floor?.12f:0);
        }
        AbbeyCenserVelocityCurves(float dx,float dz,float y,float radial)
        {
            X=new ParticleSystem.MinMaxCurve(dx-.07f,dx+.07f);
            Y=new ParticleSystem.MinMaxCurve(y,y);
            Z=new ParticleSystem.MinMaxCurve(dz-.07f,dz+.07f);
            Radial=new ParticleSystem.MinMaxCurve(radial,radial);
            Zero=new ParticleSystem.MinMaxCurve(0,0);
            SpeedModifier=new ParticleSystem.MinMaxCurve(1,1);
        }
    }
    internal static class AbbeyCenserParticleBounds
    {
        internal static bool Adjust(float x,float y,float z,float remainingLifetime,float sourceY,float floorY,bool floor,float radius,out float adjustedY,out float adjustedLifetime)
        {
            adjustedY=y;adjustedLifetime=remainingLifetime;float roomY=sourceY+y;
            if(floor)
            {
                adjustedY=AbbeyCenserContract.FloorParticleY(roomY,floorY)-sourceY;
                if(x*x+z*z>radius*radius) adjustedLifetime=0;
            }
            else if(AbbeyCenserContract.BodyParticleExpired(roomY,floorY)) adjustedLifetime=0;
            return adjustedY!=y || adjustedLifetime!=remainingLifetime;
        }
    }
    // Own loops/lights only. Native materials/textures are borrowed read-only;
    // no native smoke prefab, fireplace, network object or sound is instantiated.
    internal static class AbbeyCenserEffects
    {
        internal static bool RequiresSmoke(AbbeyCenserRecord[] records)
        {
            if(records==null) return false;
            for(int i=0;i<records.Length;i++) if(records[i].smoke.enabled) return true;
            return false;
        }
        internal static void Attach(LoadedRoom room,AbbeyCenserRecord[] records,Action<string> log)
        {
            AbbeyCenserContract.Validate(records);
            if(records==null || records.Length==0) return;
            var cookies=new Dictionary<string,Texture2D>(StringComparer.Ordinal);
            Material smoke=RequiresSmoke(records)?ResolveSmoke(room,log):null;
            var presentation=smoke?new SmokePresentation():null;
            int systems=0;
            foreach(var r in records)
            {
                var body=new GameObject("BA_R09_Censer | "+r.id);body.transform.SetParent(room.Root.transform,false);body.transform.localPosition=V(r.position);
                var glow=body.AddComponent<Light>();glow.type=LightType.Point;glow.color=new Color(1,.018f,.008f);glow.intensity=r.glowIntensity;glow.range=DungeonLightReachPolicy.AuxiliaryRange(r.glowRange);Setup(glow);
                var spotNode=new GameObject("Censer vent diamonds | "+r.id);spotNode.transform.SetParent(body.transform,false);spotNode.transform.localRotation=Quaternion.LookRotation(V(r.wallDirection),Vector3.up);
                var spot=spotNode.AddComponent<Light>();spot.type=LightType.Spot;spot.color=new Color(1,.012f,.004f);spot.intensity=r.wallIntensity;spot.range=DungeonLightReachPolicy.AuxiliaryRange(r.wallRange);
                spot.spotAngle=r.wallSpotAngle;spot.innerSpotAngle=r.wallSpotAngle*.9f;Setup(spot);
                string key=r.cookie+"|"+r.cookieSha256;
                if(!cookies.TryGetValue(key,out var cookie)) { cookie=LoadCookie(room,r);cookies.Add(key,cookie); }
                spot.cookie=cookie;
                if(smoke && r.smoke.enabled)
                {
                    MakeSmoke(body.transform,r,smoke,presentation,false);
                    MakeSmoke(body.transform,r,smoke,presentation,true);systems+=2;
                }
                log?.Invoke("CENSER_FIXTURE: "+r.id+"; roomLocal="+V(r.position)+"; wallDirection="+V(r.wallDirection)+"; floorY="+r.floorY+"; two short red shadowless lights; cookie="+r.cookie+"; smoke="+(smoke && r.smoke.enabled)+"; independent of candle gate.");
            }
            log?.Invoke("CENSER_EFFECT_BUDGET: fixtures="+records.Length+"; lights="+(records.Length*2)+"; shadowMaps=0; sharedCookies="+cookies.Count+"; particleSystems="+systems+"; particleMaximum="+(smoke?AbbeyCenserContract.MaximumParticles(records):0)+"; smokeMaterials="+(smoke?1:0)+"; owned children/resources disposed with room; no shader/game appearance claim.");
        }
        static Vector3 V(float[] p)=>new Vector3(p[0],p[1],p[2]);
        static void Setup(Light l) { l.shadows=LightShadows.None;l.renderMode=LightRenderMode.ForcePixel;l.bounceIntensity=0;l.enabled=true; }
        static Texture2D LoadCookie(LoadedRoom room,AbbeyCenserRecord r)
        {
            string path=RoomPackage.FilePath(room.PackageDirectory,r.cookie);var bytes=File.ReadAllBytes(path);
            if(bytes.Length<33 || bytes.Length>4*1024*1024 || CatalogReader.HashFile(path)!=r.cookieSha256 ||
                !bytes.Take(8).SequenceEqual(new byte[]{137,80,78,71,13,10,26,10}) || bytes[24]!=8 || bytes[25]!=6)
                throw new InvalidDataException("Censer diamond cookie must be its exact contained RGBA8 PNG.");
            var t=new Texture2D(2,2,TextureFormat.RGBA32,false,true){name="BA censer vent diamond alpha"};room.Resources.Add(t);
            if(!ImageConversion.LoadImage(t,bytes,true) || t.width<16 || t.width>1024 || t.width!=t.height) throw new InvalidDataException("Censer diamond cookie must be square16..1024 pixels.");
            t.wrapMode=TextureWrapMode.Clamp;t.filterMode=FilterMode.Bilinear;t.anisoLevel=0;return t;
        }
        static Material ResolveSmoke(LoadedRoom room,Action<string> log)
        {
            var candidates=new List<ParticleSystemRenderer>();
            foreach(string id in new[]{"piece_brazierceiling01","piece_brazierfloor01","fire_pit","bonfire","piece_groundtorch"})
            {
                var p=PrefabManager.Instance.GetPrefab(id);
                if(p) candidates.AddRange(p.GetComponentsInChildren<ParticleSystemRenderer>(true));
            }
            var greyling=PrefabManager.Instance.GetPrefab("Greyling");
            var effects=greyling?greyling.GetComponent<Character>()?.m_deathEffects?.m_effectPrefabs:null;
            if(effects!=null) foreach(var e in effects) if(e?.m_prefab) candidates.AddRange(e.m_prefab.GetComponentsInChildren<ParticleSystemRenderer>(true));
            var source=candidates.FirstOrDefault(p=>p && p.sharedMaterial && p.sharedMaterial.shader && p.sharedMaterial.shader.isSupported &&
                (p.name.IndexOf("smoke",StringComparison.OrdinalIgnoreCase)>=0 || p.sharedMaterial.name.IndexOf("smoke",StringComparison.OrdinalIgnoreCase)>=0) &&
                p.sharedMaterial.HasProperty("_MainTex") && p.sharedMaterial.mainTexture && (p.sharedMaterial.shader.name.IndexOf("particle",StringComparison.OrdinalIgnoreCase)>=0 || p.sharedMaterial.shader.name.IndexOf("smoke",StringComparison.OrdinalIgnoreCase)>=0));
            if(!source) { log?.Invoke("CENSER_SMOKE_UNAVAILABLE: no supported actual textured native smoke material found; smoke omitted without missing-shader/opaque-quad substitute. Red glow/diamond lights remain.");return null; }
            var material=new Material(source.sharedMaterial){name="BA own censer dark smoke (shared room material)"};
            if(material.HasProperty("_TintColor")) material.SetColor("_TintColor",Color.white);
            if(material.HasProperty("_Color")) material.SetColor("_Color",Color.white);
            room.Resources.Add(material);
            log?.Invoke("CENSER_SMOKE_MATERIAL: borrowed native "+source.name+"/"+source.sharedMaterial.name+"; shader="+material.shader.name+"; texture="+material.mainTexture.name+"; one owned room clone; source unchanged; actual shader appearance pending.");return material;
        }
        sealed class SmokePresentation
        {
            internal readonly ParticleSystem.MinMaxCurve BodyGrowth,FloorGrowth;
            internal readonly ParticleSystem.MinMaxGradient Fade;
            internal SmokePresentation()
            {
                BodyGrowth=Growth(1.5f);FloorGrowth=Growth(2.2f);
                var fade=new Gradient();fade.SetKeys(new[]{new GradientColorKey(Color.white,0),new GradientColorKey(Color.white,1)},new[]{new GradientAlphaKey(0,0),new GradientAlphaKey(1,.12f),new GradientAlphaKey(.75f,.65f),new GradientAlphaKey(0,1)});Fade=new ParticleSystem.MinMaxGradient(fade);
            }
            static ParticleSystem.MinMaxCurve Growth(float end)=>new ParticleSystem.MinMaxCurve(1,new AnimationCurve(new Keyframe(0,.45f),new Keyframe(.3f,1),new Keyframe(1,end)));
        }
        static void ConfigureVelocity(ParticleSystem p,AbbeyCenserVelocityCurves curves)
        {
            var velocity=p.velocityOverLifetime;velocity.enabled=false;velocity.space=ParticleSystemSimulationSpace.Local;
            velocity.x=curves.X;velocity.y=curves.Y;velocity.z=curves.Z;velocity.radial=curves.Radial;
            velocity.orbitalX=curves.Zero;velocity.orbitalY=curves.Zero;velocity.orbitalZ=curves.Zero;
            velocity.orbitalOffsetX=curves.Zero;velocity.orbitalOffsetY=curves.Zero;velocity.orbitalOffsetZ=curves.Zero;
            velocity.speedModifier=curves.SpeedModifier;velocity.enabled=true;
        }
        static void MakeSmoke(Transform host,AbbeyCenserRecord r,Material material,SmokePresentation presentation,bool floor)
        {
            var s=r.smoke;var node=new GameObject(floor?"Censer floor spill":"Censer downward body wisps");node.SetActive(false);node.transform.SetParent(host,false);
            node.transform.localPosition=floor?(r.floorPosition!=null?V(r.floorPosition)-V(r.position):new Vector3(0,r.floorY-r.position[1]+.12f,0)):Vector3.zero;
            var p=node.AddComponent<ParticleSystem>();p.Stop(true,ParticleSystemStopBehavior.StopEmittingAndClear);
            var main=p.main;main.loop=true;main.playOnAwake=false;main.duration=8;main.simulationSpace=ParticleSystemSimulationSpace.Local;
            main.cullingMode=ParticleSystemCullingMode.PauseAndCatchup;main.maxParticles=floor?s.floorMaxParticles:s.maxParticles;
            main.startLifetime=floor?new ParticleSystem.MinMaxCurve(s.floorLifetime*.7f,s.floorLifetime):new ParticleSystem.MinMaxCurve(s.lifetime*.85f,s.lifetime);
            main.startSpeed=0;main.gravityModifier=0;main.startRotation3D=false;main.startSize3D=false;main.startRotation=new ParticleSystem.MinMaxCurve(0,Mathf.PI*2);
            main.startSize=new ParticleSystem.MinMaxCurve(s.startSize*.65f,s.startSize*(floor?1.25f:1));
            main.startColor=new ParticleSystem.MinMaxGradient(new Color(.11f,.065f,.07f,floor?.28f:.55f),new Color(.23f,.13f,.14f,floor?.4f:.7f));
            var emission=p.emission;emission.rateOverTime=floor?s.floorRate:s.rate;emission.rateOverDistance=0;emission.SetBursts(Array.Empty<ParticleSystem.Burst>());
            var shape=p.shape;shape.enabled=true;shape.shapeType=floor?ParticleSystemShapeType.Circle:ParticleSystemShapeType.Sphere;
            shape.radius=floor?s.floorRadius*.35f:s.bodyRadius;shape.randomDirectionAmount=0;if(floor)shape.rotation=new Vector3(90,0,0);
            var curves=AbbeyCenserVelocityCurves.Create(floor,s.downSpeed,r.position[1]-r.floorY,r.floorPosition==null?0:r.floorPosition[0]-r.position[0],r.floorPosition==null?0:r.floorPosition[2]-r.position[2]);
            ConfigureVelocity(p,curves);
            var noise=p.noise;noise.separateAxes=false;noise.enabled=true;noise.strength=floor?.07f:.17f;noise.frequency=.45f;noise.scrollSpeed=.18f;noise.damping=true;noise.octaveCount=1;noise.quality=ParticleSystemNoiseQuality.Low;
            var size=p.sizeOverLifetime;size.separateAxes=false;size.enabled=true;size.size=floor?presentation.FloorGrowth:presentation.BodyGrowth;
            var color=p.colorOverLifetime;color.enabled=true;color.color=presentation.Fade;
            var renderer=p.GetComponent<ParticleSystemRenderer>();renderer.sharedMaterial=material;renderer.renderMode=ParticleSystemRenderMode.Billboard;renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;
            node.AddComponent<AbbeyCenserFloorLimit>().Configure(p,r.floorY,node.transform.localPosition.y+r.position[1],floor,main.maxParticles,s.floorRadius);
            // OnEnable starts the fully configured loop once; no play-on-awake
            // window or partially configured active particle module is exposed.
            node.SetActive(true);
        }
    }
    internal sealed class AbbeyCenserFloorLimit:MonoBehaviour
    {
        ParticleSystem system;ParticleSystem.Particle[] particles;float floorY,sourceY,radius;bool floor;
        internal void Configure(ParticleSystem p,float floorY,float sourceY,bool floor,int max,float radius){system=p;this.floorY=floorY;this.sourceY=sourceY;this.floor=floor;this.radius=radius;if(particles==null || particles.Length<max)particles=new ParticleSystem.Particle[max];}
        void OnEnable(){if(system)system.Play(true);}
        void OnDisable(){if(system)system.Stop(true,ParticleSystemStopBehavior.StopEmittingAndClear);}
        void LateUpdate()
        {
            if(!system || particles==null || !system.IsAlive()) return;
            int count=system.GetParticles(particles);
            if(count==0) return;
            bool changed=false;
            for(int i=0;i<count;i++)
            {
                var p=particles[i];var position=p.position;
                if(!AbbeyCenserParticleBounds.Adjust(position.x,position.y,position.z,p.remainingLifetime,sourceY,floorY,floor,radius,out float y,out float lifetime)) continue;
                position.y=y;p.position=position;p.remainingLifetime=lifetime;changed=true;
                particles[i]=p;
            }
            if(changed) system.SetParticles(particles,count);
        }
    }
}
