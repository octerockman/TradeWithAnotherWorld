using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // Owns presentation only. It never moves a player, changes teleport flags,
    // pauses the world/network, unloads resources or creates a replacement UI.
    internal sealed class DoorPortalLoadingScreen : IDisposable
    {
        private const string HarmonyId = "studio.otherworld.blackabbeyroomtest.door-loading-presentation";
        private static readonly FieldInfo LoadingScreen = AccessTools.Field(typeof(Hud), "m_loadingScreen");
        private static readonly FieldInfo LoadingProgress = AccessTools.Field(typeof(Hud), "m_loadingProgress");
        private static readonly FieldInfo SleepingProgress = AccessTools.Field(typeof(Hud), "m_sleepingProgress");
        private static readonly FieldInfo TeleportingProgress = AccessTools.Field(typeof(Hud), "m_teleportingProgress");
        private static readonly FieldInfo WorldCamera = AccessTools.Field(typeof(GameCamera), "m_camera");
        private static readonly FieldInfo SkyCamera = AccessTools.Field(typeof(GameCamera), "m_skyCamera");
        private static Harmony hooks;
        private static DoorPortalLoadingScreen current;

        private readonly Player player;
        private readonly Hud hud;
        private readonly GameCamera gameCamera;
        private readonly ZNet network;
        private readonly ZNetScene scene;
        private readonly CanvasGroup loading;
        private readonly GameObject progress, sleeping, portal;
        private readonly Canvas canvas;
        private readonly UnityEngine.UI.Graphic[] portalGraphics;
        private readonly List<CanvasGroup> opacityGroups = new List<CanvasGroup>(8);
        private readonly List<CanvasGroup> opacityScratch = new List<CanvasGroup>(8);
        private readonly List<Transform> parentChain = new List<Transform>(16);
        private readonly Camera world, sky;
        private readonly PlayerController controller;
        private readonly Action<string> log;
        private readonly bool oldWorldEnabled, oldSkyEnabled, oldControllerEnabled;
        private readonly bool oldLoadingActive, oldProgressActive, oldSleepingActive, oldPortalActive;
        private readonly bool oldBlocksRaycasts, oldInteractable;
        private readonly float oldAlpha;
        private DoorPortalLoadingDriver driver;
        private bool requested, worldSuppressed, worldWritten, skyWritten, fading, disposed;

        internal bool Active => !disposed && ReferenceEquals(current, this) && ContextValid();
        internal bool CoverReady { get; private set; }
        internal int RestorationErrors { get; private set; }
        internal bool RevealCompleted { get; private set; }
        internal static bool IsShowing => current != null && current.Active && current.requested && !current.fading;

        internal static void Install()
        {
            if (hooks != null) return;
            var target = AccessTools.Method(typeof(Hud), "UpdateBlackScreen", new[] { typeof(Player), typeof(float) });
            if (target == null || LoadingScreen == null || LoadingProgress == null || SleepingProgress == null ||
                TeleportingProgress == null || WorldCamera == null || SkyCamera == null)
                throw new MissingMemberException("The native portal loading presentation is unavailable.");
            var candidate = new Harmony(HarmonyId);
            try
            {
                candidate.Patch(target, postfix: new HarmonyMethod(typeof(DoorPortalLoadingScreen), nameof(HudBlackScreenPostfix)) { priority = Priority.Last });
                hooks = candidate;
            }
            catch { candidate.UnpatchSelf(); throw; }
        }

        internal static DoorPortalLoadingScreen Begin(Player owner, Action<string> writeLog)
        {
            if (current != null) throw new InvalidOperationException("A portal loading presentation is already owned.");
            Install();
            var lease = new DoorPortalLoadingScreen(owner, writeLog);
            GameObject root = null;
            try
            {
                root = new GameObject("Black Abbey | portal loading presentation lease");
                root.hideFlags = HideFlags.HideAndDontSave; Object.DontDestroyOnLoad(root);
                lease.driver = root.AddComponent<DoorPortalLoadingDriver>(); lease.driver.Owner = lease;
                current = lease;
                lease.SafeLog("ABBEY_PORTAL_COVER_BEGIN nativeUI=true; no world/simulation unload.");
                return lease;
            }
            catch { lease.Dispose(); if (root) Object.Destroy(root); throw; }
        }

        private DoorPortalLoadingScreen(Player owner, Action<string> writeLog)
        {
            player = owner; log = writeLog; hud = Hud.instance; gameCamera = GameCamera.instance;
            network = ZNet.instance; scene = ZNetScene.instance;
            if (!player || player != Player.m_localPlayer || !hud || !gameCamera || !network || !scene ||
                player.IsDead() || player.IsSleeping() || player.IsTeleporting() || NativeShutdownOrRespawn())
                throw new InvalidOperationException("Normal local player/HUD/camera state is required before covering entry.");
            loading = LoadingScreen.GetValue(hud) as CanvasGroup;
            progress = LoadingProgress.GetValue(hud) as GameObject;
            sleeping = SleepingProgress.GetValue(hud) as GameObject;
            portal = TeleportingProgress.GetValue(hud) as GameObject;
            world = WorldCamera.GetValue(gameCamera) as Camera; sky = SkyCamera.GetValue(gameCamera) as Camera;
            controller = player.GetComponent<PlayerController>();
            if (!loading || !progress || !sleeping || !portal || !world || !world.enabled || !controller)
                throw new InvalidOperationException("The native portal UI or local world camera is incomplete.");
            canvas = loading.GetComponentInParent<Canvas>(true)?.rootCanvas;
            ValidateCanvas();
            loading.GetComponentsInParent(true, opacityGroups);
            for (var parent = loading.transform; parent; parent = parent.parent) parentChain.Add(parent);
            portalGraphics = portal.GetComponentsInChildren<UnityEngine.UI.Graphic>(true);
            if (portalGraphics.Length == 0)
                throw new InvalidOperationException("The native portal progress subtree contains no UI graphics.");
            oldWorldEnabled = world.enabled; oldSkyEnabled = sky && sky.enabled; oldControllerEnabled = controller.enabled;
            oldLoadingActive = loading.gameObject.activeSelf; oldAlpha = loading.alpha;
            oldProgressActive = progress.activeSelf; oldSleepingActive = sleeping.activeSelf; oldPortalActive = portal.activeSelf;
            oldBlocksRaycasts = loading.blocksRaycasts; oldInteractable = loading.interactable;
        }

        private void ValidateCanvas()
        {
            if (!canvas || !canvas.enabled || !canvas.gameObject.activeInHierarchy)
                throw new InvalidOperationException("The native portal Canvas must be active before covering entry.");
            if (canvas.renderMode == RenderMode.ScreenSpaceOverlay) return;
            var uiCamera = canvas.worldCamera;
            if (canvas.renderMode == RenderMode.ScreenSpaceCamera && uiCamera && uiCamera.enabled &&
                !ReferenceEquals(uiCamera, world) && !ReferenceEquals(uiCamera, sky)) return;
            throw new InvalidOperationException("The native portal Canvas cannot remain visible while local world cameras are suppressed.");
        }

        private static bool NativeShutdownOrRespawn() => Game.instance && (Game.instance.IsShuttingDown() || Game.instance.WaitingForRespawn());
        private bool ContextValid() => player && player == Player.m_localPlayer && !player.IsDead() && !player.IsSleeping() &&
            ReferenceEquals(network, ZNet.instance) && ReferenceEquals(scene, ZNetScene.instance) && network && scene &&
            ReferenceEquals(hud, Hud.instance) && hud && ReferenceEquals(gameCamera, GameCamera.instance) && gameCamera &&
            loading && progress && sleeping && portal && world && controller && !NativeShutdownOrRespawn() &&
            ReferenceEquals(LoadingScreen.GetValue(hud), loading) && ReferenceEquals(LoadingProgress.GetValue(hud), progress) &&
            ReferenceEquals(SleepingProgress.GetValue(hud), sleeping) && ReferenceEquals(TeleportingProgress.GetValue(hud), portal) &&
            ReferenceEquals(WorldCamera.GetValue(gameCamera), world) && ReferenceEquals(SkyCamera.GetValue(gameCamera), sky) &&
            ReferenceEquals(player.GetComponent<PlayerController>(), controller);

        private void RequireActive()
        {
            if (!Active) throw new InvalidOperationException("The owned portal loading context changed.");
            ValidateCanvas();
            ValidateAncestry();
        }

        private void ValidateAncestry()
        {
            var parent = loading.transform;
            for (int i = 0; i < parentChain.Count; i++)
            {
                if (!ReferenceEquals(parent, parentChain[i]))
                    throw new InvalidOperationException("The native portal UI parent hierarchy changed.");
                parent = parent.parent;
            }
            if (parent) throw new InvalidOperationException("The native portal UI gained an unexpected parent.");
            // Reuse this bounded list. No per-frame array allocation is needed
            // to detect inserted/replaced opacity components on the same chain.
            opacityScratch.Clear(); loading.GetComponentsInParent(true, opacityScratch);
            if (opacityScratch.Count != opacityGroups.Count)
                throw new InvalidOperationException("The native portal UI opacity ancestry changed.");
            for (int i = 0; i < opacityGroups.Count; i++)
            {
                var group = opacityGroups[i];
                if (!ReferenceEquals(group, opacityScratch[i]) || !group)
                    throw new InvalidOperationException("The native portal UI opacity owner changed.");
                if (!ReferenceEquals(group, loading) && group.enabled && group.alpha < .999f)
                    throw new InvalidOperationException("A native parent CanvasGroup prevents an opaque portal cover.");
            }
        }

        private void ValidateVisiblePortal(bool afterPresentationFrame)
        {
            foreach (var graphic in portalGraphics)
                if (graphic && graphic.enabled && graphic.gameObject.activeInHierarchy && graphic.color.a > .001f &&
                    graphic.canvas && ReferenceEquals(graphic.canvas.rootCanvas, canvas) &&
                    graphic.canvasRenderer && graphic.canvasRenderer.GetAlpha() > .001f &&
                    (!afterPresentationFrame || graphic.canvasRenderer.GetInheritedAlpha() > .001f)) return;
            throw new InvalidOperationException("The native portal progress has no active nontransparent UI graphic.");
        }

        // Ready means the qualified native UI has had a presentation-frame
        // opportunity. Actual native pixels/frame pacing remain Jesse's test.
        internal IEnumerator Cover()
        {
            bool complete = false;
            try
            {
                RequireActive(); requested = true; ApplyOwnedPresentation();
                yield return new WaitForEndOfFrame();
                RequireActive();
                if (!loading.gameObject.activeInHierarchy || loading.alpha < .999f)
                    throw new InvalidOperationException("The native portal screen is not opaque and active.");
                ValidateVisiblePortal(true);
                worldSuppressed = true; SuppressWorld();
                yield return null;
                RequireActive();
                if (world.enabled || sky && sky.enabled)
                    throw new InvalidOperationException("Local world drawing was not suppressed.");
                CoverReady = true; complete = true;
                SafeLog("ABBEY_PORTAL_COVER_READY native opaque frame yielded; local world+sky cameras disabled; heavy work may start.");
            }
            finally { if (!complete) Dispose(); }
        }

        private void ApplyOwnedPresentation()
        {
            if (!requested || fading || disposed) return;
            loading.gameObject.SetActive(true); loading.alpha = 1f;
            if (!loading.gameObject.activeInHierarchy)
                throw new InvalidOperationException("The native portal UI is hidden by an inactive parent.");
            loading.blocksRaycasts = true; loading.interactable = false;
            progress.SetActive(false); sleeping.SetActive(false); portal.SetActive(true);
            ValidateVisiblePortal(CoverReady);
            controller.enabled = false;
            player.SetControls(Vector3.zero, false, false, false, false, false, false, false, false, false, false, false);
            if (worldSuppressed) SuppressWorld();
        }

        private void SuppressWorld()
        {
            if (!worldWritten && !world.enabled)
                throw new InvalidOperationException("The local world camera changed before the cover owned it.");
            world.enabled = false; worldWritten = true;
            if (sky && sky.enabled) { sky.enabled = false; skyWritten = true; }
        }

        internal void Tick()
        {
            if (disposed) return;
            try { RequireActive(); ApplyOwnedPresentation(); }
            catch (Exception error) { SafeLog("ABBEY_PORTAL_COVER_CANCEL " + error.Message); Dispose(); }
        }

        private static void HudBlackScreenPostfix(Hud __instance, Player __0)
        {
            var lease = current;
            if (lease == null || !ReferenceEquals(lease.hud, __instance)) return;
            lease.Tick();
        }

        internal IEnumerator ReleaseReady()
        {
            try
            {
                RequireActive();
                if (!CoverReady || player.IsTeleporting())
                    throw new InvalidOperationException("Portal cover cannot reveal an unfinished native arrival.");
                ApplyOwnedPresentation(); RestoreWorld();
                // Show the actual ready dungeon behind an opaque native cover
                // for one presentation frame, then let native Hud own its fade.
                yield return new WaitForEndOfFrame();
                RequireActive(); fading = true;
                float until = Time.unscaledTime + 3f;
                while (HasNormalRevealAuthority() && loading.alpha > .001f && Time.unscaledTime < until)
                    yield return null;
                if (!HasNormalRevealAuthority()) yield break;
                RequireActive();
                if (!(loading.alpha <= .001f))
                {
                    // Native Hud fades with scaled deltaTime. Pausing or slow
                    // time must not release controls behind an opaque screen.
                    // After a grace period, only this same normal-play HUD may
                    // receive a short unscaled fallback; native death/sleep/
                    // teleport/shutdown or replacement always takes priority.
                    float from = loading.alpha;
                    if (float.IsNaN(from) || float.IsInfinity(from) || from > 1f) from = 1f;
                    float started = Time.unscaledTime;
                    SafeLog("ABBEY_PORTAL_COVER_FADE_FALLBACK native fade delayed; owned unscaled fade started.");
                    while (true)
                    {
                        if (!HasNormalRevealAuthority()) yield break;
                        RequireActive();
                        if (loading.alpha <= .001f) break;
                        float fraction = (Time.unscaledTime - started) / .25f;
                        if (fraction < 0f) fraction = 0f;
                        if (fraction > 1f) fraction = 1f;
                        loading.alpha = from * (1f - fraction);
                        if (loading.alpha <= .001f) break;
                        yield return null;
                    }
                }
                if (!HasNormalRevealAuthority()) yield break;
                RequireActive();
                // Normal completion requires a genuinely cleared owned cover,
                // not merely expiration of a timeout or iterator completion.
                loading.alpha = 0f; loading.gameObject.SetActive(false);
                if (!HasNormalRevealAuthority()) yield break;
                RevealCompleted = true;
                SafeLog("ABBEY_PORTAL_COVER_RELEASE native portal cover cleared; normal reveal completed; no FPS claim.");
            }
            finally { Dispose(); }
        }

        private bool HasNormalRevealAuthority() => Active && MayRestoreHud();

        private void RestoreWorld()
        {
            worldSuppressed = false;
            Exception failure = null;
            try
            {
                if (worldWritten && world && !world.enabled) world.enabled = oldWorldEnabled;
                worldWritten = false;
            }
            catch (Exception error) { failure = error; }
            try
            {
                if (skyWritten && sky && !sky.enabled) sky.enabled = oldSkyEnabled;
                skyWritten = false;
            }
            catch (Exception error) { if (failure == null) failure = error; }
            if (failure != null) throw failure;
        }

        private bool MayRestoreHud() => player && player == Player.m_localPlayer && !player.IsDead() && !player.IsSleeping() &&
            !player.IsTeleporting() && !NativeShutdownOrRespawn() && ReferenceEquals(network, ZNet.instance) &&
            ReferenceEquals(scene, ZNetScene.instance) && ReferenceEquals(hud, Hud.instance) && hud;

        public void Dispose()
        {
            if (disposed) return;
            disposed = true; CoverReady = false;
            bool ownedCurrent = ReferenceEquals(current, this);
            if (ownedCurrent) current = null;
            TryRestore(RestoreWorld, "cameras");
            TryRestore(() =>
            {
                if (controller && player && ReferenceEquals(player.GetComponent<PlayerController>(), controller) && !controller.enabled)
                    controller.enabled = oldControllerEnabled;
            }, "local controls");
            // A death/sleep/real teleport/new session now has native authority
            // over this screen. Never restore an old normal-play HUD over it.
            TryRestore(() =>
            {
                if (ownedCurrent && requested && loading)
                {
                    // Native UpdateBlackScreen never owns these fields. Undo
                    // them even when native death/teleport takes visual control.
                    if (loading.blocksRaycasts) loading.blocksRaycasts = oldBlocksRaycasts;
                    if (!loading.interactable) loading.interactable = oldInteractable;
                }
            }, "UI interaction");
            TryRestore(() =>
            {
                if (ownedCurrent && requested && MayRestoreHud())
                {
                    if (loading && (!fading || !RevealCompleted))
                    {
                        if (fading || Mathf.Abs(loading.alpha - 1f) < .001f) loading.alpha = oldAlpha;
                        if (loading.gameObject.activeSelf) loading.gameObject.SetActive(oldLoadingActive);
                    }
                    if (progress && !progress.activeSelf) progress.SetActive(oldProgressActive);
                    if (sleeping && !sleeping.activeSelf) sleeping.SetActive(oldSleepingActive);
                    if (portal && portal.activeSelf) portal.SetActive(oldPortalActive);
                }
            }, "native UI presentation");
            var host = driver; driver = null;
            TryRestore(() => { if (host) { host.Owner = null; Object.Destroy(host.gameObject); } }, "lease host");
            SafeLog("ABBEY_PORTAL_COVER_END restorationErrors=" + RestorationErrors + "; native HUD ownership respected.");
        }

        internal static void Shutdown()
        {
            try { current?.Dispose(); }
            finally { hooks?.UnpatchSelf(); hooks = null; }
        }
        private void TryRestore(Action restore, string label)
        { try { restore(); } catch (Exception error) { RestorationErrors++; SafeLog("ABBEY_PORTAL_COVER_RESTORE_FAILED " + label + ": " + error.Message); } }
        private void SafeLog(string message) { try { log?.Invoke(message); } catch { } }
    }

    [DefaultExecutionOrder(32000)]
    internal sealed class DoorPortalLoadingDriver : MonoBehaviour
    {
        internal DoorPortalLoadingScreen Owner;
        private void LateUpdate() => Owner?.Tick();
        private void OnDestroy() => Owner?.Dispose();
        private void OnApplicationQuit() => DoorPortalLoadingScreen.Shutdown();
    }
}
