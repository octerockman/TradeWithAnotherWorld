using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json.Linq;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        WardingSpawnerAssets wardingAssets;
        WardingSpawnerActors wardingActors;
        WardingSpawnerSnapshot wardingSaved;
        readonly WardingSpawnerSettings wardingSettings=new WardingSpawnerSettings();
        readonly List<WardingSpawnerPlacement> wardingPlacements=new List<WardingSpawnerPlacement>();
        readonly List<WardingSourceView> wardingViews=new List<WardingSourceView>();
        readonly HashSet<Character> wardingDirected=new HashSet<Character>();
        float nextWardingTick;int wardingVisit;
        sealed class WardingSourceView
        {
            internal WardingSpawnerPlacement Placement;
            internal WardingSpawnerState State;
            internal WardingSpawnerArt Art;
            internal WardingDoorMotion Motion;
            internal Character ReopeningMonk;
            internal float NextAlarm,WorkerHealth,WorkerHurtUntil;
            internal bool Contested;
            internal string PendingKey,PendingPrefab;
        }
        JObject CaptureWardingState()
        {
            if(wardingSaved==null)return null;
            if(wardingActors!=null)wardingSaved.actors=wardingActors.Capture();
            return WardingSpawnerPersistence.ToJson(wardingSaved);
        }
        void RestoreWardingState(JObject value,string run,int seed)
        {wardingSaved=WardingSpawnerPersistence.Read(value,WorldKey(),run,seed);}
        bool IsWardingPort(string room,string port)=>wardingPlacements.Any(s=>s.RoomId==room&&s.PortId==port);
        IEnumerator PrepareWardingSpawners(DungeonPlan plan)
        {
            if(plan.Mode!="natural")yield break;
            string directory=Path.Combine(DataPath,"warding-spawners");
            var metadata=RoomLoadScheduling.Worker(()=>WardingSpawnerAssets.ReadMounts(directory).ToArray());
            while(!metadata.IsCompleted)yield return null;
            var fits=metadata.GetAwaiter().GetResult().Select(m=>new WardingSpawnerFit{SourceId=m.sourceId,PortId=m.portId,Kind=m.kind,
                SourceSha256=m.sourceSha256,MountDepth=m.depth,Min=m.boundsMin.Select(v=>(double)v).ToArray(),Max=m.boundsMax.Select(v=>(double)v).ToArray()}).ToArray();
            foreach(var fit in fits)
                if(catalog.rooms.Single(r=>r.roomId==fit.SourceId).sourceSha256!=fit.SourceSha256)
                    throw new InvalidDataException("Spawner mount belongs to another source room: "+fit.SourceId+"/"+fit.PortId);
            string hash=CatalogReader.HashFile(Path.Combine(directory,"manifest.json"));
            wardingPlacements.Clear();
            if(wardingSaved==null)
            {
                wardingPlacements.AddRange(WardingSpawnerSelection.Select(plan,fits));
                wardingSaved=new WardingSpawnerSnapshot{worldKey=WorldKey(),runId=naturalRunId,seed=plan.Seed,assetSha256=hash,
                    sources=wardingPlacements.Select(p=>new WardingSpawnerState{id=p.Id,roomId=p.RoomId,portId=p.PortId}).ToList()};
            }
            else
            {
                WardingSpawnerPersistence.Validate(wardingSaved,WorldKey(),naturalRunId,plan.Seed);
                if(!WardingAssetRevision.Compatible(wardingSaved.assetSha256,hash))throw new InvalidDataException("Saved warding sources require their matching asset revision; current run retained.");
                wardingPlacements.AddRange(WardingSpawnerSelection.Restore(plan,fits,wardingSaved.sources));
                if(wardingSaved.assetSha256!=hash){wardingSaved.assetSha256=hash;Logger.LogInfo("WARD_ART_REVISION: compatible V47-to-V51 art; exact saved source IDs, mounts, state and native actor identities retained; floor support checked anew before travel.");}
            }
            Logger.LogInfo("WARD_SOURCE_SELECTION: seed="+plan.Seed+"; sources="+wardingPlacements.Count+"; ceiling="+
                WardingSpawnerPolicy.MaximumSources(plan.Rooms.Length,plan.Rooms.Count(p=>p.Spec.SourceId=="R09-B"),1)+
                "; chance-only; first two rooms, connected ports, shrine/boss/stairs excluded; full bay reservations.");
            if(wardingPlacements.Count==0)yield break;
            yield return WardingSpawnerAssets.LoadSteps(directory,a=>wardingAssets=a,s=>Logger.LogInfo(s),wardingPlacements.Select(p=>p.Kind).Distinct());
            if(wardingAssets==null)throw new InvalidDataException("Warding source art was not prepared.");
            WardingSpawnerAudio.Initialize(gameObject,Path.Combine(SharedDataPath,"spawner-audio"),s=>Logger.LogInfo(s));
            WardingMechanismAudio.Initialize(Path.Combine(SharedDataPath,"spawner-mechanism-audio"),Logger.LogInfo);
            yield return null;
        }
        IEnumerator PlaceWardingSpawners(DungeonPlan plan)
        {
            foreach(var placement in wardingPlacements)
            {
                var room=rooms[placement.RoomId];var source=plan.Rooms[placement.RoomIndex];var port=source.Spec.Ports.Single(p=>p.id==placement.PortId);
                var art=wardingAssets.Create(dungeonArt.transform,placement.Kind);
                art.Root.name="Unhallowed Threshold | "+placement.Id;
                art.Root.AddComponent<PortalVisualOwners>().Configure(placement.RoomId);
                art.Root.transform.localPosition=V(placement.Position,(float)placement.Elevation);
                art.Root.transform.localRotation=Quaternion.Euler(0,placement.QuarterTurns*90,0);
                art.SetWardMountDepth((float)placement.MountDepth);
                var state=wardingSaved.sources.Single(s=>s.id==placement.Id);art.Snap(state.progress,state.locked);
                WardingMechanismAudio.Attach(placement.Id,art);
                if(KitArchitectureProfile.Matches(room.Manifest.sourceSha256,room.Record.manifestSha256))
                {
                    if(!wardingAssets.TryGetMount(room.Manifest.roomId,port.id,out var mount)||mount.sourceSha256!=room.Manifest.sourceSha256||
                        mount.kind!="p"||mount.floorPolicy!="rebuilt-clearance-checked-no-runtime-trim"||Math.Abs(mount.depth-placement.MountDepth)>.00001)
                        throw new InvalidDataException("The rebuilt warding mount lost its checked source/threshold clearance binding.");
                    // New room floors and the0.8m pointed module are checked
                    // offline in their current shared datum. Old floor masks,
                    // source hashes and the old shallow-mount clip do not apply.
                }
                else WardingSpawnerFloorRepair.Apply(room,port,(float)placement.MountDepth,room.Manifest.sourceSha256);
                var view=new WardingSourceView{Placement=placement,State=state,Art=art,Motion=new WardingDoorMotion(state.progress)};wardingViews.Add(view);
                var pin=new GameObject("Locking pin interaction");pin.transform.SetParent(art.Root.transform,false);pin.transform.position=art.PinPoint;
                pin.layer=LayerMask.NameToLayer("piece");if(pin.layer<0)pin.layer=0;
                var pinTarget=pin.AddComponent<SphereCollider>();pinTarget.radius=.19f;pinTarget.isTrigger=true;
                pin.AddComponent<WardingPinHandle>().Bind(()=>PinText(view),user=>PinWardingSource(view,user));
                // The existing solid leaf colliders receive the same E action.
                // The pin's extra aiming target never obstructs an emerging actor.
                foreach(var target in art.MovingColliders.Select(c=>c.gameObject).Distinct())
                    (target.GetComponent<WardingPinHandle>()??target.AddComponent<WardingPinHandle>()).Bind(()=>PinText(view),user=>PinWardingSource(view,user));
                yield return null;
            }
            // The ward straddles the original threshold and its new alcove
            // floor. Instantiate every source first, then enable the completed
            // shell before asking PhysX for support on either side of that seam.
            // No source actor is reconciled or produced until successful travel.
            if(wardingViews.Count>0)
            {
                dungeonArt.SetActive(true);Physics.SyncTransforms();
                foreach(var view in wardingViews)yield return view.Art.ConformWardSteps();
                Logger.LogInfo("WARD_FLOOR_SUPPORT: projected onto active room and alcove collision surfaces before travel.");
            }
        }
        void ReconcileWardingActors()
        {
            if(wardingSaved==null||wardingSaved.sources.Count==0||wardingActors!=null)return;
            wardingActors=new WardingSpawnerActors(naturalRunId,WorldKey(),dungeonPlan.Seed,s=>Logger.LogInfo(s),snapshot=>{
                wardingSaved.actors=snapshot;return SavePersistentRun(true);},WardingRecoveryAnchor);
            wardingActors.Restore(wardingSaved.actors);
            nextWardingTick=Time.time;
            if(!SavePersistentRun(true))throw new InvalidOperationException("Spawner source ledger could not be committed before production.");
        }
        string PinText(WardingSourceView source)
        {
            if(source.State.locked)return "Unhallowed Threshold\nLocked";
            if(WardingSpawnerPolicy.CanPin(source.State))return "Unhallowed Threshold\n[<color=yellow><b>$KEY_Use</b></color>] Set locking pin";
            return "Unhallowed Threshold\n"+(source.State.unbarring?"Rebar the doors before setting the pin":"Stand within the ward to bar the doors");
        }
        bool PinWardingSource(WardingSourceView source,Humanoid user)
        {
            if(busy||!persistentRunBound||!ZNet.instance||!ZNet.instance.IsServer()||!(user is Player player)||!Matches(Player.m_localPlayer)||
                !source.Art.MovingColliders.Any(c=>c&&Vector3.Distance(user.transform.position,c.ClosestPoint(user.transform.position))<=3.2f))return false;
            var before=source.State.Clone();if(!WardingSpawnerPolicy.TryPin(source.State))return false;
            if(!SavePersistentRun(true))
            {
                int i=wardingSaved.sources.FindIndex(s=>s.id==before.id);wardingSaved.sources[i]=before;source.State=before;
                player.Message(MessageHud.MessageType.Center,"The lock could not be saved. The doors remain unpinned.");return false;
            }
            player.Message(MessageHud.MessageType.Center,"The locking pin seats firmly.");
            source.Motion.Snap(1);source.Art.Apply(1,true);
            Logger.LogInfo("WARD_PIN_SET: "+source.State.id+"; fully barred; saved before presentation.");return true;
        }
        static bool PointInFloor(float[][] poly,float x,float z)
        {
            if(poly==null||poly.Length<3)return false;bool inside=false;
            for(int i=0,j=poly.Length-1;i<poly.Length;j=i++)
            {var a=poly[i];var b=poly[j];if((a[1]>z)!=(b[1]>z)&&x<(b[0]-a[0])*(z-a[1])/(b[1]-a[1])+a[0])inside=!inside;}
            return inside;
        }
        int WardingRoomAt(Vector3 point)
        {
            if(dungeonPlan==null||point.y<HighAltitudeGuard)return -1;
            for(int i=0;i<dungeonPlan.Rooms.Length;i++)
            {
                var room=rooms[dungeonPlan.Rooms[i].Spec.Id];var local=room.Root.transform.InverseTransformPoint(point);var m=room.Manifest;
                if(local.y>=m.boundsMin[1]-.2&&local.y<=m.boundsMax[1]+.2&&PointInFloor(m.floorPolygonXZ??m.footprint,local.x,local.z))return i;
            }
            return -1;
        }
        bool WardingActivation(WardingSourceView source,Player[] players)
        {
            int host=source.Placement.RoomIndex;
            foreach(var player in players)
            {
                int at=WardingRoomAt(player.transform.position);
                if(at==host||at>=0&&dungeonPlan.Links.Any(l=>l.A==host&&l.B==at||l.B==host&&l.A==at))return true;
                var local=player.transform.position-gridOrigin.Value;
                foreach(var l in dungeonPlan.Links.Where(l=>l.A==host||l.B==host))
                {var b=l.Envelope();if(local.x>=b[0]&&local.x<=b[2]&&local.z>=b[1]&&local.z<=b[3]&&Mathf.Abs(local.y-(float)l.Elevation)<2.5f)return true;}
            }
            return false;
        }
        bool WardingSight(Character actor,WardingSourceView source)
        {
            Vector3 from=actor.transform.position+Vector3.up*1.5f,to=source.Art.ActorMouth+Vector3.up*1.5f;
            Vector3 delta=to-from;if(delta.sqrMagnitude>35*35||Vector3.Dot(actor.transform.forward,Vector3.ProjectOnPlane(delta,Vector3.up).normalized)<0)return false;
            // Closed source leaves previously hid their own pin from the
            // sight test. Ignore only this mechanism; room walls still block.
            return !Physics.RaycastAll(from,delta.normalized,Mathf.Max(0,delta.magnitude-.15f),LayerMask.GetMask("static_solid"),QueryTriggerInteraction.Ignore)
                .Any(h=>h.collider&&!h.collider.transform.IsChildOf(source.Art.Root.transform));
        }
        bool WardingObstruction(WardingSourceView source,IEnumerable<Character> actors,float proposedProgress)
        {
            foreach(var actor in actors)
            {
                if(source.Art.Obstructed(actor,proposedProgress))return true;
            }
            return false;
        }
        void TickWardingSpawners()
        {
            if(wardingViews.Count==0||wardingActors==null||busy||!persistentRunBound||!ZNet.instance||!ZNet.instance.IsServer()||!MonkWorldMatches(wardingSaved.worldKey))return;
            foreach(var view in wardingViews)
            {
                float presented=view.Motion.Advance(Time.deltaTime);
                view.Art.Apply(presented,view.State.locked);view.Art.SetWardFeedback(presented,view.Contested);
            }
            if(Time.time<nextWardingTick)return;float dt=Mathf.Min(.25f,Time.time-(nextWardingTick-.15f));nextWardingTick=Time.time+.15f;
            try
            {
                var players=Player.GetAllPlayers().Where(p=>p&&!p.IsDead()&&p.transform.position.y>HighAltitudeGuard).ToArray();
                wardingActors.Tick(dt,id=>wardingViews.Any(v=>v.State.id==id&&v.State.progress<=.00001f&&!v.State.locked),(id,commit)=>{
                    var found=wardingViews.Single(v=>v.State.id==id);
                    if(!WardingSpawnerRetrieval.CommitSourceReturn(found.State,commit))return false;
                    Logger.LogInfo("WARD_GUARD_REINFORCEMENTS: "+id+"; same monk returned alive; closed/pinned source remains unable to produce.");return true;},(id,actor)=>{
                    var source=wardingViews.FirstOrDefault(v=>v.State.id==id);
                    return source!=null&&!source.State.locked&&!source.State.initialSequenceCompleted&&
                        (source.State.progress>0||players.Any(p=>source.Art.ContainsWard(p.transform.position)))?
                        source.Art.HallYieldPoint(actor):null;});
                var actors=Character.GetAllCharacters().Where(c=>c&&c.transform.position.y>HighAltitudeGuard&&WardingSpawnerActors.IsHostOwned(c)).Take(256).ToArray();
                var enemies=actors.Where(c=>!c.IsPlayer()).ToArray();var directed=new HashSet<Character>();
                var contestedMonks=new HashSet<Character>(enemies.Where(c=>WardingSpawnerActors.IsMonk(c)&&wardingViews.Any(v=>v.Art.ContainsWard(c.transform.position)&&players.Any(p=>v.Art.ContainsWard(p.transform.position)))));
                foreach(var view in wardingViews)
                {
                    var wardPlayers=players.Where(p=>view.Art.ContainsWard(p.transform.position)).ToArray();
                    var wardEnemies=enemies.Where(c=>view.Art.ContainsWard(c.transform.position)).ToArray();
                    var monks=wardEnemies.Where(WardingSpawnerActors.IsMonk).ToArray();
                    var input=new WardingSpawnerInput {Players=wardPlayers.Length,Enemies=wardEnemies.Length,Monks=monks.Length,
                        Activation=WardingActivation(view,players),ProductionBlocked=false,BossDead=persistentRun.bossCompleted,
                        LivingLocal=wardingActors.LivingLocal(view.State.id),LivingGlobal=wardingActors.LivingTotal};
                    // Forecast through the same policy on a private copy. This
                    // covers both closing and empty-ward initial reversal without
                    // consuming a reservation or changing the saved source.
                    var proposed=view.State.Clone();WardingSpawnerPolicy.Tick(proposed,input,dt,wardingSettings);
                    if(!view.State.locked&&view.State.progress<1&&wardPlayers.Length>0&&wardEnemies.Length==0)
                        foreach(var actor in actors.Concat(players.Cast<Character>()).Distinct())
                            if(view.Art.Obstructed(actor,proposed.progress)&&
                                !(wardingActors.CanYieldToDoor(view.State.id,actor)&&view.Art.HallYieldPoint(actor).HasValue))
                                WardingDoorClearance.Nudge(view.Art.Root.transform,actor);
                    bool obstructed=WardingObstruction(view,actors.Concat(players.Cast<Character>()).Distinct(),proposed.progress);
                    input.Obstructed=obstructed;
                    var step=WardingSpawnerPolicy.Tick(view.State,input,dt,wardingSettings);
                    view.Contested=step.Contested;
                    view.Motion.Target(view.State.progress,.15f);
                    foreach(var enemy in wardEnemies)
                        if(step.Contested&&WardingSpawnerActors.IsMonk(enemy)){WardingSpawnerActors.SetFrantic(enemy,true);directed.Add(enemy);}
                    if(step.PlayerWorking&&Time.time>=view.NextAlarm)
                    {
                        view.NextAlarm=Time.time+4;
                        foreach(var enemy in enemies.Where(c=>WardingSpawnerActors.IsWardResponder(c)&&!contestedMonks.Contains(c)&&!WardingSpawnerActors.IsTravelling(c)&&Vector3.Distance(c.transform.position,view.Art.WardCentre)<30&&RoomWithinWardingHearing(WardingRoomAt(c.transform.position),view.Placement.RoomIndex,2)))
                        {WardingSpawnerActors.Alert(new[]{enemy},view.Art.WardCentre);directed.Add(enemy);}
                    }
                    if(view.State.progress>=.72f)foreach(var monk in enemies.Where(c=>WardingSpawnerActors.IsMonk(c)&&!WardingSpawnerActors.IsTravelling(c)&&WardingRoomAt(c.transform.position)==view.Placement.RoomIndex&&WardingSight(c,view)))WardingSpawnerAudio.Distress(monk);
                    if(view.State.progress>0&&!view.State.locked&&view.State.initialSequenceCompleted&&wardPlayers.Length==0)
                    {
                        var worker=view.ReopeningMonk;
                        if(worker&&worker.GetHealth()<view.WorkerHealth-.01f)view.WorkerHurtUntil=Time.time+3f;
                        if(worker)view.WorkerHealth=worker.GetHealth();
                        if(!WardingCanReopen(view,worker,enemies,players))worker=null;
                        if(!worker&&Time.time>=view.WorkerHurtUntil)
                            worker=enemies.Where(c=>WardingCanReopen(view,c,enemies,players)&&!wardingViews.Any(v=>v!=view&&v.ReopeningMonk==c))
                                .OrderBy(c=>(c.transform.position-view.Art.WardCentre).sqrMagnitude).FirstOrDefault();
                        if(worker)
                        {
                            if(worker!=view.ReopeningMonk)view.WorkerHealth=worker.GetHealth();
                            WardingSpawnerActors.SetFrantic(worker,false);WardingSpawnerAudio.Distress(worker);
                            WardingSpawnerActors.ApproachWard(worker,WardingWorkPoint(view,worker,enemies));directed.Add(worker);
                        }
                        view.ReopeningMonk=worker;
                    }
                    else view.ReopeningMonk=null;
                    // Starting the trip can fail temporarily, or the first
                    // fetcher can die. Retry with an existing eligible monk;
                    // never manufacture an actor to release this source.
                    if(view.State.awaitingReturn&&view.State.progress<=.00001f&&!view.State.locked&&!wardingActors.HasRetrieval(view.State.id))
                    {
                        foreach(var monk in enemies.Where(c=>WardingCanReopen(view,c,enemies,players)&&!wardingViews.Any(v=>v!=view&&v.ReopeningMonk==c))
                            .OrderBy(c=>(c.transform.position-view.Art.WardCentre).sqrMagnitude))
                            if(wardingActors.BeginRetrieval(view.State.id,monk,view.Art.ActorMouth,view.Art.ActorStaging,view.Art.InnerDoor,view.Art.ActorExit,8))
                            {directed.Add(monk);break;}
                    }
                    if(step.BecameFullyBarred||step.BecameFullyOpen)SavePersistentRun(true);
                    if(step.SpawnRequested||view.PendingKey!=null&&WardingActivation(view,players)&&!obstructed&&
                        WardingSpawnerPolicy.CanProduce(view.State,wardingActors.LivingLocal(view.State.id),wardingActors.LivingTotal,true,wardingSettings))TryWardingSpawn(view);
                }
                foreach(var actor in wardingDirected.Where(a=>a&&!directed.Contains(a)&&!WardingSpawnerActors.IsTravelling(a)).ToArray())
                {WardingSpawnerActors.SetFrantic(actor,false);WardingSpawnerActors.Release(actor);}
                wardingDirected.Clear();foreach(var actor in directed)wardingDirected.Add(actor);
            }
            catch(Exception ex){Logger.LogError("Warding source tick suspended safely: "+ex);SuspendWardingSpawners();}
        }
        bool WardingCanReopen(WardingSourceView view,Character monk,Character[] enemies,Player[] players)
        {
            if(!WardingSpawnerActors.IsHostOwned(monk)||!WardingSpawnerActors.IsMonk(monk)||WardingSpawnerActors.IsTravelling(monk)||
                WardingRoomAt(monk.transform.position)!=view.Placement.RoomIndex||monk!=view.ReopeningMonk&&!WardingSight(monk,view))return false;
            var ai=monk.GetComponent<BaseAI>();var target=ai?ai.GetTargetCreature():null;
            float nearest=players.Length==0?float.PositiveInfinity:players.Min(p=>Vector3.Distance(p.transform.position,monk.transform.position));
            bool occupied=enemies.Any(other=>other!=monk&&!WardingSpawnerActors.IsTravelling(other)&&players.Any(p=>
                Vector3.Distance(p.transform.position,other.transform.position)<5f)&&other.GetComponent<BaseAI>()?.GetTargetCreature() is Player);
            return WardingCombatPriority.MayReopen(monk.InAttack(),Time.time<view.WorkerHurtUntil,target&&WardingSpawnerActors.IsAlive(target),occupied,nearest);
        }
        Vector3 WardingWorkPoint(WardingSourceView view,Character actor,Character[] enemies)
        {
            var workers=enemies.Where(c=>WardingSpawnerActors.IsMonk(c)&&WardingRoomAt(c.transform.position)==view.Placement.RoomIndex).OrderBy(c=>c.GetInstanceID()).ToArray();
            int index=System.Array.IndexOf(workers,actor);float side=index<0?0:index%3==0?-.82f:index%3==1?.82f:0;
            return view.Art.WardCentre+view.Art.Root.transform.right*side;
        }
        bool RoomWithinWardingHearing(int start,int target,int hops)
        {
            if(start<0)return false;var seen=new HashSet<int>{start};var layer=new List<int>{start};
            for(int h=0;h<=hops;h++)
            {if(layer.Contains(target))return true;var next=new List<int>();foreach(int i in layer)foreach(var l in dungeonPlan.Links.Where(l=>l.A==i||l.B==i)){int j=l.A==i?l.B:l.A;if(seen.Add(j))next.Add(j);}layer=next;}
            return false;
        }
        void TryWardingSpawn(WardingSourceView source)
        {
            // Native reconciliation can consume/cancel the view's old pending
            // reservation. Clear only this transient pointer, never its ledger.
            if(source.PendingKey!=null&&wardingActors.PendingKey(source.State.id)!=source.PendingKey)
            {source.PendingKey=null;source.PendingPrefab=null;}
            if(!WardingSpawnerPolicy.CanProduce(source.State,wardingActors.LivingLocal(source.State.id),wardingActors.LivingTotal,source.PendingKey!=null,wardingSettings))return;
            if(source.PendingKey==null)
            {
                var kind=WardingSpawnerPolicy.ChooseRoster(dungeonPlan.Seed,source.State,wardingSettings);
                string prefab=kind==WardingSpawnerKind.Monk?AbbeyMonkSpawnPolicy.Monk:kind==WardingSpawnerKind.Guard?AbbeyMonkSpawnPolicy.Guard:AbbeyMonkSpawnPolicy.Censer;
                string key=source.State.id+"/spawn/"+source.State.nextActorSequence;
                var before=source.State.Clone();
                // Reserve checkpoints the JOINT actor/source journal. Advance
                // the source first so a crash cannot strand this key forever.
                WardingSpawnerPolicy.CommitSpawn(dungeonPlan.Seed,source.State,wardingSettings);
                bool reserved;
                try{reserved=wardingActors.Reserve(source.State.id,key,prefab);}
                catch{RestoreWardingWork(source,before);throw;}
                if(!reserved)
                {
                    // V47-V50 may have saved the reservation before advancing
                    // its source. A completed exact native scan can consume a
                    // proven uncreated/dead key without ever recreating it.
                    if(wardingActors.IsCancelledReservation(source.State.id,key)&&SavePersistentRun(true))return;
                    RestoreWardingWork(source,before);return;
                }
                source.PendingKey=key;source.PendingPrefab=prefab;
                if(!SavePersistentRun(true))return;
            }
            if(runWriteFailure!=null||!SavePersistentRun(true))return;
            if(wardingActors.TrySpawn(source.State.id,source.PendingKey,source.PendingPrefab,source.Art.ActorStaging,
                Quaternion.LookRotation(-source.Art.Root.transform.forward),out var actor))
            {
                source.PendingKey=null;source.PendingPrefab=null;
                wardingActors.BeginEmergence(source.State.id,actor,source.Art.ActorMouth,source.Art.ActorStaging,source.Art.InnerDoor,source.Art.ActorExit);
                SavePersistentRun(true);
            }
            else if(wardingActors.PendingKey(source.State.id)==null){source.PendingKey=null;source.PendingPrefab=null;}
        }
        void RestoreWardingWork(WardingSourceView view,WardingSpawnerState before)
        {int at=wardingSaved.sources.FindIndex(s=>s.id==before.id);wardingSaved.sources[at]=before;view.State=before;}
        void SuspendWardingSpawners()
        {
            if(wardingActors!=null){if(wardingSaved!=null)wardingSaved.actors=wardingActors.Capture();wardingActors.Suspend();wardingActors=null;}
            foreach(var c in wardingDirected.Where(c=>c)){WardingSpawnerActors.SetFrantic(c,false);WardingSpawnerActors.Release(c);}wardingDirected.Clear();
            WardingSpawnerAudio.Shutdown();WardingMechanismAudio.Shutdown();
        }
        void ClearWardingArt()
        {
            SuspendWardingSpawners();wardingViews.Clear();wardingPlacements.Clear();wardingAssets?.Dispose();wardingAssets=null;
        }
        IEnumerator PrepareWardingRetirement()
        {
            if(persistentRun?.spawners==null)yield break;
            if(wardingSaved==null||wardingSaved.runId!=persistentRun.runId||wardingSaved.worldKey!=persistentRun.worldKey)
            {wardingPlacements.Clear();RestoreWardingState(persistentRun.spawners,persistentRun.runId,persistentRun.seed);}
            if(legacyRetirementVolumes==null&&wardingPlacements.Count==0&&wardingSaved.sources.Count>0)
            {
                string directory=Path.Combine(DataPath,"warding-spawners");
                var metadata=RoomLoadScheduling.Worker(()=>WardingSpawnerAssets.ReadMounts(directory).ToArray());
                while(!metadata.IsCompleted)yield return null;
                var fits=metadata.GetAwaiter().GetResult().Select(m=>new WardingSpawnerFit{SourceId=m.sourceId,PortId=m.portId,Kind=m.kind,
                    SourceSha256=m.sourceSha256,MountDepth=m.depth,Min=m.boundsMin.Select(v=>(double)v).ToArray(),Max=m.boundsMax.Select(v=>(double)v).ToArray()}).ToArray();
                string hash=CatalogReader.HashFile(Path.Combine(directory,"manifest.json"));
                if(!WardingAssetRevision.Compatible(wardingSaved.assetSha256,hash))
                    throw new InvalidDataException("Saved spawner bay bounds require matching assets before grave ejection.");
                wardingPlacements.AddRange(WardingSpawnerSelection.Restore(dungeonPlan??retirementEnvelope,fits,wardingSaved.sources));
                wardingSaved.assetSha256=hash;
            }
            if(wardingSaved.actors==null)yield break;
            if(wardingActors==null)
            {
                wardingActors=new WardingSpawnerActors(wardingSaved.runId,wardingSaved.worldKey,wardingSaved.seed,s=>Logger.LogInfo(s));
                wardingActors.Restore(wardingSaved.actors);
            }
            var pending=wardingActors.PrepareRetirement();
            while(pending.MoveNext())yield return pending.Current;
        }
        void RetireWardingSpawners()
        {
            if(wardingActors!=null){wardingActors.Retire();wardingActors=null;}
            wardingSaved=null;WardingSpawnerAudio.Shutdown();WardingMechanismAudio.Shutdown();
        }
        void InitializeWardingCommands()
        {
            Add("twa_test_spawners","List saved warding source locations, bars, pins, roster and actor counts.",false,()=>LogWardingStatus(Print));
            Add("twa_test_spawner_next","Travel to the next selected warding source inside the current dungeon (local host).",true,()=>{
                if(busy||wardingViews.Count==0||!LocalPlayer(out var player)||!Matches(player)){Print("Enter a natural dungeon containing selected warding sources first.");return;}
                var view=wardingViews[wardingVisit++%wardingViews.Count];Vector3 point=view.Art.WardCentre-view.Art.Root.transform.forward*.7f;
                if(Physics.Raycast(point+Vector3.up*2,Vector3.down,out var ground,4,LayerMask.GetMask("static_solid")))point=ground.point+Vector3.up*.08f;
                player.TeleportTo(point,Quaternion.LookRotation(view.Art.Root.transform.forward),true);Print(view.State.id+"; E sets the pin only after full barring.");});
        }
        void LogWardingStatus(Action<string> log)
        {
            log("WARD_SOURCES: selected="+(wardingSaved?.sources.Count??0)+"; livingOwned="+(wardingActors?.LivingTotal??0)+"; intervals="+wardingSettings.MinimumSpawnInterval+"-"+wardingSettings.MaximumSpawnInterval+"s; fully open only; activation exit pauses production; boss completion does not disable sources.");
            foreach(var view in wardingViews)log(view.State.id+"; bars="+view.State.progress.ToString("P0")+"; pin="+view.State.locked+"; partlyUnbarred="+view.State.unbarring+"; waitingForReturn="+view.State.awaitingReturn+"; guardOnly="+view.State.reinforced+"; world="+view.Art.WardCentre);
        }
    }
    public sealed class WardingPinHandle:MonoBehaviour,Hoverable,Interactable
    {
        Func<string> text;Func<Humanoid,bool> interact;
        internal void Bind(Func<string> label,Func<Humanoid,bool> use){text=label;interact=use;}
        public string GetHoverName()=>"Unhallowed Threshold";
        public float GetHoverOffset()=>.2f;
        public string GetHoverText()=>Localization.instance.Localize(text?.Invoke()??"");
        public bool Interact(Humanoid user,bool hold,bool alt)=>!hold&&(interact?.Invoke(user)??false);
        public bool UseItem(Humanoid user,ItemDrop.ItemData item)=>false;
    }
}
