using System;
using System.Linq;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    internal static class AbbeyKeyDiagnostics
    {
        // Read-only, deliberately limited to the quest's own prefab/name. No
        // inventory mutation, key adoption, grant, removal or token rewriting.
        internal static void Report(Player player,UnrecordedDeadState unrecordedDead,BepInEx.Logging.ManualLogSource logger,string reason)
        {
            if(!player||unrecordedDead==null)return;
            var rows=player.GetInventory().GetAllItems().Where(i=>i!=null&&
                (FalseVowsItems.Id(i)==UnrecordedDeadState.Key||i.m_shared?.m_name=="Old Order Key")).ToArray();
            int matching=0,stale=0,untagged=0,aliases=0;
            foreach(var item in rows)
            {
                if(FalseVowsItems.Id(item)!=UnrecordedDeadState.Key){aliases++;continue;}
                if(FalseVowsItems.Matches(item,UnrecordedDeadState.Key,unrecordedDead.RunId,unrecordedDead.KeyToken)){matching++;continue;}
                if(item.m_customData!=null&&item.m_customData.ContainsKey(FalseVowsItemIdentity.RunKey)&&
                    item.m_customData.ContainsKey(FalseVowsItemIdentity.TokenKey))stale++;else untagged++;
            }
            logger.LogInfo("UNRECORDED_DEAD_KEY_INVENTORY: reason="+reason+"; durableClaim="+unrecordedDead.KeyClaimed+
                "; currentMatching="+matching+"; staleOrWrongToken="+stale+"; untagged="+untagged+
                "; sameDisplayNameOtherPrefab="+aliases+"; grid="+string.Join("|",rows.Select(i=>i.m_gridPos.x+","+i.m_gridPos.y))+"; visibleRows="+QuestVisibleInventory.Rows(player.GetInventory())+"; readOnly=true.");
        }
    }
}
