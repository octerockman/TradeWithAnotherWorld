using System;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // The actual exported key's atlas albedo is uniform bronze; its authored
    // normal and metallic/smoothness samples carry the retained surface detail.
    // This definition is private to that source-bound quest key, never vanilla
    // CryptKey or the shared R02 atlas material.
    internal static class FalseVowsKeyAppearance
    {
        internal const string KeyId = "abbey_scriptorium_key";
        internal const float Silver = .78f;
        internal const float Smoothness = .78f;
        internal const float SourceSmoothness = 66f / 255f;
        internal const float GlossMapScale = Smoothness / SourceSmoothness;
        internal static bool AppliesTo(string id) => string.Equals(id, KeyId, StringComparison.Ordinal);

        internal static Material Create(Material source)
        {
            if (!source) throw new ArgumentNullException(nameof(source));
            foreach (string property in new[] { "_MainTex", "_Color", "_BumpMap", "_MetallicGlossMap", "_Glossiness", "_GlossMapScale" })
                if (!source.HasProperty(property)) throw new InvalidOperationException("The source-bound silver key material requires " + property + ".");
            var material = new Material(source) { name = "BA False Vows | polished silver cabinet key" };
            // Built-in white is borrowed, not generated or disposed. Replacing
            // the uniform bronze albedo only changes this cloned key material.
            material.SetTexture("_MainTex", Texture2D.whiteTexture);
            material.SetColor("_Color", new Color(Silver, Silver, Silver, 1));
            material.SetFloat("_Glossiness", Smoothness);
            // Standard multiplies the authored map's alpha by this scale. The
            // checked key sample is66/255, yielding.78without rebaking its map.
            material.SetFloat("_GlossMapScale", GlossMapScale);
            return material;
        }
    }
}
