using UnityEngine;
namespace BlackAbbeySixRooms
{
    public sealed class FalseVowsLetterReader:MonoBehaviour
    {
        internal static bool Open(Player player)=>SharedParchmentReader.Open(player,FalseVowsLetterText.Title,FalseVowsLetterText.Body,"BlackAbbey.FalseVows.Letter.png");
        internal static void Shutdown()=>SharedParchmentReader.Shutdown();
    }
}
