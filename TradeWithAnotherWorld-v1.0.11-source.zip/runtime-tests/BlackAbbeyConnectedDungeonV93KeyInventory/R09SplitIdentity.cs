using System;
using System.IO;

namespace BlackAbbeySixRooms
{
    // Explicit identities are routing predicates, never source aliases. Each
    // component still requires its new sealed native+manifest tuple.
    internal static class R09SplitIdentity
    {
        internal const string FalseVowsHall="R09-A1", UnrecordedDeadHall="R09-A2", Chamber="R09-B";
        internal static bool IsHall(string id)=>id==FalseVowsHall||id==UnrecordedDeadHall;
        internal static bool IsChamber(string id)=>id==Chamber;
        internal static bool IsPiece(string id)=>IsHall(id)||IsChamber(id);
        internal static bool IsBossAudioScope(string id)=>id=="R09"||IsPiece(id);
        internal static KitRoomBinding RequireSealed(string id,string source,string manifest)
        {
            var binding=KitArchitectureProfile.Find(source,manifest);
            if(!IsPiece(id)||binding==null||binding.roomId!=id||binding.assetId!=id)
                throw new InvalidDataException("Split R09 requires its exact component/native/manifest seal: "+id);
            return binding;
        }
    }
}
