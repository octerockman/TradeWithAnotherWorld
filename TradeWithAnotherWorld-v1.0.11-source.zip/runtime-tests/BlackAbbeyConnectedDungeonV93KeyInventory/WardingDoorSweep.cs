using System;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Query the authored moving collider at prospective poses without moving
    // scene bodies. Broad bay membership is only a cheap prefilter, not a veto.
    internal static class WardingDoorSweep
    {
        internal static void Pose(float[][] samples,float progress,bool lockingPin,float pin,
            out Vector3 position,out Quaternion rotation,out Vector3 scale)
        {
            float frame=lockingPin&&progress>=1?151+14*pin:1+132*Mathf.Clamp01(progress);
            float at=Mathf.Clamp(frame-1,0,191);int a=(int)at,b=Mathf.Min(a+1,191);float t=at-a;
            var p=samples[a];var q=samples[b];
            position=Vector3.Lerp(new Vector3(p[0],p[1],p[2]),new Vector3(q[0],q[1],q[2]),t);
            rotation=Quaternion.Slerp(new Quaternion(p[3],p[4],p[5],p[6]),new Quaternion(q[3],q[4],q[5],q[6]),t);
            scale=Vector3.Lerp(new Vector3(p[7],p[8],p[9]),new Vector3(q[7],q[8],q[9]),t);
        }
        internal static bool Blocked(Transform source,Collider moving,float[][] samples,
            float from,float to,bool lockingPin,float pin,Collider actor)
        {
            if(!source||!moving||!actor||!actor.enabled||actor.isTrigger||Mathf.Approximately(from,to))return false;
            // These source colliders are direct identity children of their
            // motion roots, with unit authored scale (validated at Configure).
            int steps=Math.Max(1,Mathf.CeilToInt(Mathf.Abs(to-from)*132*4));
            for(int i=0;i<=steps;i++)
            {
                Pose(samples,Mathf.Lerp(from,to,(float)i/steps),lockingPin,pin,out var p,out var q,out _);
                if(Physics.ComputePenetration(moving,source.TransformPoint(p),source.rotation*q,
                    actor,actor.transform.position,actor.transform.rotation,out _,out float depth)&&depth>.0001f)return true;
            }
            return false;
        }
    }
}
