using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // Exact reusable masonry modules. No compressed smooth connector is used.
    internal static class StoneDoorwayKit
    {
#pragma warning disable 0649
        private sealed class TrimMap { public int schemaVersion; public TrimRoom[] rooms; }
        private sealed class TrimRoom { public string roomId, sourceSha256; public TrimMesh[] meshes; }
        private sealed class TrimMesh { public string name, meshSha256; public int vertices, indices; public int[] removeTriangles; public TrimReplacement[] replacementTriangles; }
        private sealed class TrimReplacement { public int sourceTriangle; public float[][] vertices; }
#pragma warning restore 0649
        // Parsed records stay captured privately by Apply. Callers can lease a
        // validated map but cannot mutate its source masks/replacement arrays.
        internal sealed class PreparedTrimMap
        {
            internal readonly string Path, Sha256, SourceKey;
            internal readonly Action<LoadedRoom, Action<string>> Apply;
            internal PreparedTrimMap(string path, string sha256, string sourceKey, Action<LoadedRoom, Action<string>> apply)
            { Path = path; Sha256 = sha256; SourceKey = sourceKey; Apply = apply; }
        }
        private sealed class CachedTrimMap { internal PreparedTrimMap Data; internal int References; }
        internal sealed class TrimMapLease : IDisposable
        {
            private Action release;
            internal TrimMapLease(Action release) { this.release = release; }
            public void Dispose() { var action = System.Threading.Interlocked.Exchange(ref release, null); action?.Invoke(); }
        }
        private static readonly object TrimGate = new object();
        private static readonly Dictionary<string, CachedTrimMap> TrimMaps = new Dictionary<string, CachedTrimMap>(StringComparer.OrdinalIgnoreCase);

        // Pure file/hash/JSON/source validation. No Unity calls on the worker.
        internal static PreparedTrimMap PrepareTrimMap(string trimPath, string expectedHash, RoomCatalog catalog)
        {
            var file = new FileInfo(trimPath);
            if (!file.Exists || !AssemblyPartPolicy.TrimFileLengthAllowed(file.Length) || !CatalogReader.Hash(expectedHash))
                throw new InvalidDataException("Missing/oversized or unhashed masonry trim map.");
            byte[] bytes = File.ReadAllBytes(file.FullName);
            string hash;
            using (var algorithm = SHA256.Create()) hash = BitConverter.ToString(algorithm.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
            if (hash != expectedHash || !AssemblyPartPolicy.TrimFileLengthAllowed(bytes.Length)) throw new InvalidDataException("Doorway trim map changed.");
            string json;
            using (var stream = new MemoryStream(bytes)) using (var reader = new StreamReader(stream, Encoding.UTF8, true)) json = reader.ReadToEnd();
            if (json.Length > 16 * 1024 * 1024 || catalog?.rooms == null) throw new InvalidDataException("Missing or oversized source-bound trim inventory.");
            var map = JsonConvert.DeserializeObject<TrimMap>(json, new JsonSerializerSettings {
                TypeNameHandling = TypeNameHandling.None, MetadataPropertyHandling = MetadataPropertyHandling.Ignore, MaxDepth = 24 });
            if (map == null || map.schemaVersion != 1 || map.rooms == null || !CatalogReader.ValidRoomInventory(map.rooms.Select(r => r?.roomId)) ||
                !new HashSet<string>(map.rooms.Select(r => r.roomId), StringComparer.Ordinal).SetEquals(catalog.rooms.Select(r => r.roomId)))
                throw new InvalidDataException("Trim inventory differs from the actual room catalog.");
            foreach (var row in map.rooms)
                if (!CatalogReader.Hash(row.sourceSha256) || row.sourceSha256 != catalog.rooms.Single(r => r.roomId == row.roomId).sourceSha256)
                    throw new InvalidDataException("Trim inventory is bound to another room source: " + row.roomId);
            string sourceKey = string.Join("|", map.rooms.OrderBy(r => r.roomId, StringComparer.Ordinal).Select(r => r.roomId + ":" + r.sourceSha256));
            return new PreparedTrimMap(file.FullName, hash, sourceKey, (room, log) => ApplyPreparedRoomTrim(room, map, hash, log));
        }
        internal static TrimMapLease AcquireTrimMap(PreparedTrimMap prepared)
        {
            if (prepared == null) throw new ArgumentNullException(nameof(prepared));
            lock (TrimGate)
            {
                if (!TrimMaps.TryGetValue(prepared.Path, out var cache))
                    TrimMaps.Add(prepared.Path, cache = new CachedTrimMap { Data = prepared });
                else if (cache.Data.Sha256 != prepared.Sha256 || cache.Data.SourceKey != prepared.SourceKey)
                    throw new InvalidDataException("An active masonry trim lease belongs to a different pinned source.");
                cache.References++;
                return new TrimMapLease(() => {
                    lock (TrimGate)
                    {
                        if (TrimMaps.TryGetValue(prepared.Path, out var current) && ReferenceEquals(current, cache) && --cache.References == 0)
                            TrimMaps.Remove(prepared.Path);
                    }
                });
            }
        }
        internal static void RestoreRoom(LoadedRoom room)
        {
            if (!room?.Root) return;
            var state = room.Root.GetComponent<StoneDoorwayRoomState>();
            if (state) state.Restore();
        }
        internal static void ApplyRoomTrim(LoadedRoom room, string trimPath, Action<string> log)
        {
            if(KitArchitectureProfile.Matches(room?.Manifest?.sourceSha256,room?.Record?.manifestSha256)){log?.Invoke("KIT_JOIN: authored thin room mouths; historical triangle trim/lining repairs deliberately skipped.");return;}
            RestoreRoom(room);
            if (!room?.Root) throw new InvalidDataException("Missing source room for masonry trim.");
            PreparedTrimMap prepared;
            lock (TrimGate)
            {
                if (!TrimMaps.TryGetValue(Path.GetFullPath(trimPath), out var cache))
                    throw new InvalidDataException("Masonry trim requires the owned, hash-validated shared asset lease.");
                prepared = cache.Data;
            }
            prepared.Apply(room, log);
        }
        private static void ApplyPreparedRoomTrim(LoadedRoom room, TrimMap map, string mapHash, Action<string> log)
        {
            var data = map.rooms.Single(r => r.roomId == room.Manifest.roomId);
            if (data.sourceSha256 != UnrecordedDeadSourceBindings.Canonical(room.Manifest.roomId,room.Manifest.sourceSha256) || data.meshes == null || data.meshes.Length > 8)
                throw new InvalidDataException("Masonry trim differs from the loaded room source.");
            var prepared = new List<StoneDoorwayRoomState.MeshState>();
            try
            {
                int removed = 0, reused = 0, built = 0;
                foreach (var target in data.meshes)
                {
                    var record = room.Manifest.meshes.Single(r => r.name == target.name);
                    if (record.sha256 != target.meshSha256 || record.vertices != target.vertices || record.indices != target.indices)
                        throw new InvalidDataException("Masonry trim differs from the exact source BAR1 record.");
                    var filter = room.Root.GetComponentsInChildren<MeshFilter>(true).Single(f => f.name == target.name);
                    var original = filter.sharedMesh;
                    if (!original || original.vertexCount != target.vertices || original.GetIndexCount(0) != target.indices)
                        throw new InvalidDataException("Source mesh was modified before masonry trim.");
                    string cacheKey = TrimMeshIdentity.Key(original.GetInstanceID(), mapHash, data.sourceSha256, record.sha256, target.vertices, target.indices);
                    if (SharedRoomResources.TryAcquireLease<Mesh>(cacheKey, out var shared, out var sharedLease))
                    {
                        prepared.Add(new StoneDoorwayRoomState.MeshState { Filter = filter, Original = original, Candidate = shared, Lease = sharedLease });
                        removed += target.removeTriangles.Length; reused++; continue;
                    }
                    var indices = original.triangles;
                    if (target.removeTriangles == null || target.removeTriangles.Length > 100000)
                        throw new InvalidDataException("Masonry trim mask is invalid.");
                    var remove = new HashSet<int>(target.removeTriangles);
                    if (remove.Count != target.removeTriangles.Length || remove.Any(i => i < 0 || i >= indices.Length / 3))
                        throw new InvalidDataException("Duplicate/out-of-range masonry trim triangle.");
                    var replacements = target.replacementTriangles ?? Array.Empty<TrimReplacement>();
                    if (replacements.Length > 100000 || replacements.Any(r => r == null || !remove.Contains(r.sourceTriangle) || r.vertices == null || r.vertices.Length != 3 || r.vertices.Any(v => v == null || v.Length != 12 || v.Any(x => !RoomPackage.Finite(x)))))
                        throw new InvalidDataException("Invalid source-bound retained reveal triangle.");
                    if (remove.Count == 0 && replacements.Length == 0) continue;
                    var retained = new List<int>(indices.Length - remove.Count * 3);
                    for (int i = 0; i < indices.Length / 3; i++) if (!remove.Contains(i))
                    { retained.Add(indices[i * 3]); retained.Add(indices[i * 3 + 1]); retained.Add(indices[i * 3 + 2]); }
                    if (retained.Count == 0) throw new InvalidDataException("Masonry trim cannot remove an entire source mesh.");
                    // Instantiate preserves every original position/UV/normal/
                    // tangent/color. Only the named old-frame index mask changes.
                    var candidate = Object.Instantiate(original); candidate.name = original.name + " | source-pinned structural reveal clipping";
                    IDisposable candidateLease = null;
                    try
                    {
                        if (replacements.Length > 0)
                        {
                            var positions = new List<Vector3>(original.vertices); var normals = new List<Vector3>(original.normals);
                            var uv = new List<Vector2>(original.uv); var tangents = new List<Vector4>(original.tangents);
                            foreach (var replacement in replacements) foreach (var v in replacement.vertices)
                            {
                                retained.Add(positions.Count); positions.Add(new Vector3(v[0],v[1],v[2])); normals.Add(new Vector3(v[3],v[4],v[5]));
                                uv.Add(new Vector2(v[6],v[7])); tangents.Add(new Vector4(v[8],v[9],v[10],v[11]));
                            }
                            if (positions.Count > 65535) candidate.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
                            candidate.SetVertices(positions); candidate.SetNormals(normals); candidate.SetUVs(0,uv); candidate.SetTangents(tangents);
                        }
                        candidate.SetTriangles(retained, 0, true);
                        candidateLease = SharedRoomResources.RetainLease(cacheKey, candidate);
                        prepared.Add(new StoneDoorwayRoomState.MeshState { Filter = filter, Original = original, Candidate = candidate, Lease = candidateLease });
                    }
                    catch { if (candidateLease != null) candidateLease.Dispose(); else if (candidate) Object.Destroy(candidate); throw; }
                    built++;
                    removed += remove.Count;
                }
                var state = room.Root.GetComponent<StoneDoorwayRoomState>() ?? room.Root.AddComponent<StoneDoorwayRoomState>();
                foreach (var row in prepared) { row.Filter.sharedMesh = row.Candidate; state.Meshes.Add(row); }
                log("STONE_REVEAL_CLIP: " + room.Manifest.roomId + ": " + removed + " source-bound structural reveal triangles clipped; immutable derived meshes built=" + built + ", reused=" + reused + "; exact source/map identities and state leases; decorative arches, original floor and source colliders retained.");
            }
            catch
            {
                var state = room.Root ? room.Root.GetComponent<StoneDoorwayRoomState>() : null;
                foreach (var row in prepared)
                {
                    if (row.Filter && row.Original && row.Filter.sharedMesh == row.Candidate) row.Filter.sharedMesh = row.Original;
                    if (state) state.Meshes.Remove(row);
                    row.Lease?.Dispose(); row.Lease = null;
                }
                throw;
            }
        }
        internal static GameObject CreateJoin(Transform parent, Vector3 innerA, Quaternion outward, PortRecord portA, PortRecord portB, float gap, LoadedRoom kit, Action<string> log)
        {
            if(kit?.Manifest?.roomId==KitPointedArchitecture.KitId)
            {StoneDoorwayJoinPolicy.Select(portA,portB,gap);return KitPointedArchitecture.CreateModule(parent,innerA+outward*(Vector3.forward*(portA.depth-KitPointedArchitecture.HalfReach)),outward,"pointed_080",kit);}
            string module = StoneDoorwayJoinPolicy.Select(portA,portB,gap);
            float depthA = portA.depth, depthB = portB.depth;
            float length = depthA + depthB + gap;
            var root = CreateModule(parent, innerA, outward, module, kit);
            StoneDoorwayPortFitRepair.ApplyJoin(root,kit,module,portA,portB);
            root.name = "Passage | Stone masonry " + module;
            string collarName = StoneDoorwayJoinPolicy.IsCircle(portA) || StoneDoorwayJoinPolicy.IsCircle(portB) ? "joint_mortar_c" : "joint_mortar_e";
            if (AssemblyPartPolicy.HasMasonryCollars(kit.Manifest))
            {
                var collarSource = kit.Root.transform.Find(collarName);
                if (!collarSource) { Object.Destroy(root); throw new InvalidDataException("The declared masonry contact collar is missing."); }
                var collar = Object.Instantiate(collarSource.gameObject, root.transform, false); collar.name = collarName;
                collar.transform.localPosition = new Vector3(0, 0, depthA); collar.transform.localRotation = Quaternion.identity; collar.transform.localScale = Vector3.one; collar.SetActive(true);
            }
            log("STONE_RECESSED_JOIN: " + module + "; stone-block throat between retained room arches, matching original end profiles; inside depth=" + length.ToString("F3") + "m; no covering fascia or axial scaling.");
            return root;
        }
        internal static GameObject CreateBarredReturn(LoadedRoom room, PortRecord port, LoadedRoom kit, Action<string> log)
        {
            if(kit?.Manifest?.roomId==KitPointedArchitecture.KitId)
            {if(!KitPointedArchitecture.Pointed(port))throw new InvalidDataException("Unknown pointed branch mouth.");var q=Quaternion.LookRotation(RoomPackage.Vector(port.outward,"pointed return normal"),Vector3.up);return KitPointedArchitecture.CreateModule(room.Root.transform,RoomPackage.Vector(port.position,"pointed return floor")+q*(Vector3.forward*(port.depth-KitPointedArchitecture.HalfReach)),q,"pointed_080_return",kit);}
            if (!room?.Root) throw new InvalidDataException("Missing masonry barred-port frame.");
            string module = StoneDoorwayJoinPolicy.ReturnModule(port);
            var root = CreateModule(room.Root.transform, RoomPackage.Vector(port.position, "masonry threshold"), Quaternion.LookRotation(RoomPackage.Vector(port.outward, "masonry outward"), Vector3.up), module, kit);
            StoneDoorwayPortFitRepair.ApplyReturn(root,kit,module,port);
            root.name = "Stone masonry barred return | " + port.id;
            var state = room.Root.GetComponent<StoneDoorwayRoomState>() ?? room.Root.AddComponent<StoneDoorwayRoomState>(); state.Returns.Add(root);
            log("STONE_MASONRY_BARRED: " + room.Manifest.roomId + "/" + port.id + "; complete blocked-port stone return and supported threshold, " + module + ".");
            return root;
        }
        private static GameObject CreateModule(Transform parent, Vector3 position, Quaternion rotation, string module, LoadedRoom kit)
        {
            if (!kit?.Root || kit.Manifest.roomId != "STONE_DOORWAY_KIT_V5") throw new InvalidDataException("The checked stone doorway kit is unavailable.");
            var names = new[] { module + "_blocks", module + "_backing", "Collider | " + module };
            var sources = names.Select(name => kit.Root.transform.Find(name)).ToArray();
            if (sources.Any(t => !t)) throw new InvalidDataException("Stone doorway module chunks are incomplete.");
            var root = new GameObject("Stone masonry " + module); root.SetActive(false);
            root.transform.SetParent(parent, false); root.transform.localPosition = position; root.transform.localRotation = rotation; root.transform.localScale = Vector3.one;
            try
            {
                foreach (var source in sources)
                {
                    var child = Object.Instantiate(source.gameObject, root.transform, false); child.name = source.name;
                    child.transform.localPosition = Vector3.zero; child.transform.localRotation = Quaternion.identity; child.transform.localScale = Vector3.one; child.SetActive(true);
                }
                StoneDoorwayBackingRepair.Apply(root, kit, module);
                root.SetActive(true); return root;
            }
            catch { root.SetActive(false); Object.Destroy(root); throw; }
        }
    }
    internal sealed class StoneDoorwayRoomState : MonoBehaviour
    {
        internal sealed class MeshState { internal MeshFilter Filter; internal Mesh Original, Candidate; internal IDisposable Lease; }
        internal readonly List<MeshState> Meshes = new List<MeshState>();
        internal readonly List<GameObject> Returns = new List<GameObject>();
        internal void Restore()
        {
            foreach (var row in Meshes) { if (row.Filter && row.Original) row.Filter.sharedMesh = row.Original; row.Lease?.Dispose(); row.Lease = null; }
            Meshes.Clear();
            foreach (var root in Returns) if (root) { root.SetActive(false); Object.Destroy(root); }
            Returns.Clear();
        }
        private void OnDestroy() { foreach (var row in Meshes) { row.Lease?.Dispose(); row.Lease = null; } Meshes.Clear(); }
    }
}
