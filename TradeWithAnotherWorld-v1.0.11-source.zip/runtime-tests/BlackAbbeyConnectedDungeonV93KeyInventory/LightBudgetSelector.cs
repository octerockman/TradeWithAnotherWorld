using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeySixRooms
{
    internal static class LightBudgetSelector
    {
        internal const int MaxActive = int.MaxValue, MaxShadows = 1;
        internal sealed class Candidate
        {
            internal string Id;
            internal double DistanceSquared, Intensity, Range;
            internal bool Eligible, IsWindow;
        }
        internal sealed class Selection
        {
            internal HashSet<string> ActiveIds = new HashSet<string>(StringComparer.Ordinal);
            internal HashSet<string> ShadowIds = new HashSet<string>(StringComparer.Ordinal);
        }
        private static bool Finite(double n) => !double.IsNaN(n) && !double.IsInfinity(n);
        internal static bool ShouldEnable(bool playerInTestSpace, bool anyRoomActive) => playerInTestSpace && anyRoomActive;
        internal static bool ShouldCastShadow(bool enabled, bool isWindow) => enabled && isWindow;
        internal static Selection Select(IEnumerable<Candidate> input)
        {
            var all = input.ToArray();
            if (all.Any(c => c == null || string.IsNullOrEmpty(c.Id) || !Finite(c.DistanceSquared) || c.DistanceSquared < 0 || !Finite(c.Range) || c.Range <= 0 || !Finite(c.Intensity) || c.Intensity < 0) || all.Select(c => c.Id).Distinct().Count() != all.Length)
                throw new ArgumentException("Budget fixtures need unique IDs and finite physical values.");
            var eligible = all.Where(c => c.Eligible).ToArray();
            var chosen = eligible.ToList();
            var window = eligible.Where(c => c.IsWindow).OrderBy(c => c.DistanceSquared).ThenBy(c => c.Id, StringComparer.Ordinal).FirstOrDefault();
            if (window != null && !chosen.Contains(window)) { if (chosen.Count == MaxActive) chosen.RemoveAt(chosen.Count - 1); chosen.Add(window); }
            var result = new Selection(); foreach (var c in chosen) result.ActiveIds.Add(c.Id);
            if (window != null) result.ShadowIds.Add(window.Id);
            // Only the independent window spotlight may cast shadows. Every
            // candle remains a real light, with no distance/source-count cap.
            return result;
        }
    }
}
