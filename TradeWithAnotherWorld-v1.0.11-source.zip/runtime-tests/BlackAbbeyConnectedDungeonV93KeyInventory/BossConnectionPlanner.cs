using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Keep the boss on the furthest usable doorway's route. A blocked direct
    // footprint can be cleared by a short authored-room chain before trying a
    // nearer anchor. Every accepted extra is on that one terminal chain.
    internal static class BossConnectionPlanner
    {
        private sealed class Anchor{internal int Room,Depth;internal PortRecord Port;}
        private sealed class Search
        {
            internal DungeonRoomSpec Boss;
            internal DungeonRoomSpec[] Options;
            internal List<DungeonPlacement> Placed;
            internal List<DungeonLink> Links;
            internal HashSet<string> Assigned=new HashSet<string>(StringComparer.Ordinal);
            internal Random Random;
            internal DungeonPlanningDiagnostics Diagnostics;
            internal int Budget,NormalTarget,ThirdExtras,KnightExtras;
        }
        private static bool Used(List<DungeonLink> links,int room,PortRecord port)=>links.Any(l=>l.A==room&&l.PortA.id==port.id||l.B==room&&l.PortB.id==port.id);
        private static void Shuffle<T>(IList<T> values,Random random){for(int i=values.Count-1;i>0;i--){int j=random.Next(i+1);T v=values[i];values[i]=values[j];values[j]=v;}}
        private static bool AllStairsConnected(List<DungeonPlacement> placed,List<DungeonLink> links)=>
            placed.Select((p,i)=>new{p,i}).Where(x=>x.p.Spec.SourceId=="R08").All(x=>x.p.Spec.Ports.All(p=>Used(links,x.i,p)));
        private static bool TryBoss(Search search,int from,PortRecord port,int depth,int extras,bool route)
        {
            if(depth+1<NaturalDungeonRoster.MinimumBossDepth||route&&!BossConnectionExtensionPolicy.Accepts(search.NormalTarget,search.ThirdExtras,extras,search.KnightExtras))return false;
            if(route&&--search.Budget<=0){search.Budget=0;return false;}
            search.Diagnostics.BossDirectAttempts++;
            if(!DungeonLayoutPlanner.TryPlacement(search.Boss,from,port,search.Boss.Ports[0],search.Placed,search.Links,search.Diagnostics,out var boss,out var edge))return false;
            search.Placed.Add(boss);search.Links.Add(edge);
            if(AllStairsConnected(search.Placed,search.Links)&&depth+1<search.Placed.Count)return true;
            search.Links.RemoveAt(search.Links.Count-1);search.Placed.RemoveAt(search.Placed.Count-1);return false;
        }
        private static bool Grow(Search search,int from,PortRecord open,int depth,int remaining,int total)
        {
            if(search.Budget<=0)return false;
            if(remaining==0)return TryBoss(search,from,open,depth,total,true);
            var choices=new List<Tuple<DungeonRoomSpec,PortRecord>>();
            foreach(var group in search.Options.GroupBy(s=>s.SourceId))
            {
                var source=group.FirstOrDefault(s=>!search.Assigned.Contains(s.Id));if(source==null)continue;
                foreach(var entry in source.Ports)choices.Add(Tuple.Create(source,entry));
            }
            Shuffle(choices,search.Random);var seen=new HashSet<string>(StringComparer.Ordinal);
            foreach(var choice in choices)
            {
                if(--search.Budget<=0){search.Budget=0;return false;}
                if(!DungeonLayoutPlanner.TryPlacement(choice.Item1,from,open,choice.Item2,search.Placed,search.Links,search.Diagnostics,out var room,out var edge))continue;
                string pose=choice.Item1.SourceId+"|"+string.Join(",",room.Envelope().Select(x=>x.ToString("R",CultureInfo.InvariantCulture)))+"|"+room.Elevation.ToString("R",CultureInfo.InvariantCulture);
                if(!seen.Add(pose))continue;
                int next=search.Placed.Count;search.Placed.Add(room);search.Links.Add(edge);search.Assigned.Add(choice.Item1.Id);
                var exits=room.Spec.Ports.Where(p=>p.id!=choice.Item2.id).ToList();Shuffle(exits,search.Random);
                var forward=search.Placed[from].Normal(open);
                exits=exits.OrderByDescending(p=>{var n=room.Normal(p);return n.X*forward.X+n.Z*forward.Z;}).ToList();
                foreach(var exit in exits)if(Grow(search,next,exit,depth+1,remaining-1,total))return true;
                search.Assigned.Remove(choice.Item1.Id);search.Links.RemoveAt(search.Links.Count-1);search.Placed.RemoveAt(search.Placed.Count-1);
            }
            return false;
        }
        private static DungeonRoomSpec[] Options(DungeonRoomSpec[] canonical,DungeonRoomSpec[] normalSpecs,DungeonRoomSpec[] third,Random random,bool oneBrokenSaint)
        {
            var counts=normalSpecs.Concat(third).GroupBy(s=>NaturalDungeonRoster.Family(s.SourceId)).ToDictionary(g=>g.Key,g=>g.Count(),StringComparer.Ordinal);
            var options=new List<DungeonRoomSpec>();
            foreach(var family in canonical.Where(s=>ThirdLoopExtensionPolicy.EligibleSource(s.SourceId,s.Ports.Length)&&(!oneBrokenSaint||s.SourceId!="R03")).GroupBy(s=>NaturalDungeonRoster.Family(s.SourceId)).OrderBy(g=>g.Key,StringComparer.Ordinal))
            {
                int existing=counts.TryGetValue(family.Key,out int n)?n:0;
                int allowance=Math.Min(BossConnectionExtensionPolicy.MaximumApproachRooms,NaturalDungeonRoster.MaximumOrdinaryRepeats-existing);
                var sources=family.OrderBy(s=>s.SourceId,StringComparer.Ordinal).ToArray();int offset=random.Next(sources.Length);var ordinals=new Dictionary<string,int>(StringComparer.Ordinal);
                for(int i=0;i<allowance;i++)
                {
                    var source=sources[(offset+i)%sources.Length];int ordinal=ordinals.TryGetValue(source.SourceId,out int old)?old+1:1;ordinals[source.SourceId]=ordinal;
                    options.Add(new DungeonRoomSpec{Id=source.SourceId+"_boss_extra_"+ordinal.ToString("00",CultureInfo.InvariantCulture),SourceId=source.SourceId,
                        Ports=source.Ports.ToArray(),Bounds=source.Bounds.ToArray(),BoundsY=source.BoundsY.ToArray(),Reservations=source.Reservations?.Select(v=>v.ToArray()).ToArray(),KitConnectedExteriorCollar=source.KitConnectedExteriorCollar});
                }
            }
            return options.ToArray();
        }
        internal static bool TryConnect(DungeonRoomSpec[] canonical,DungeonRoomSpec[] normalSpecs,DungeonRoomSpec boss,List<DungeonPlacement> placed,List<DungeonLink> links,string entrance,Random random,ref int budget,DungeonPlanningDiagnostics diagnostics,bool oneBrokenSaint=false,bool knightLoop=false)
        {
            if(canonical==null||normalSpecs==null||boss==null||placed==null||links==null||random==null||diagnostics==null||boss.SourceId!="R09"||boss.Ports.Length!=1||placed.Count==0)return false;
            var ids=new HashSet<string>(normalSpecs.Select(s=>s.Id),StringComparer.Ordinal);var third=placed.Where(p=>ThirdLoopExtensionPolicy.IsExtraId(p.Spec.Id)).Select(p=>p.Spec).ToArray();
            var knight=knightLoop?placed.Where(p=>R08KnightReturnPolicy.IsExtraId(p.Spec.Id)).Select(p=>p.Spec).ToArray():Array.Empty<DungeonRoomSpec>();
            int missing=normalSpecs.Count(s=>s.SourceId!="R09"&&!placed.Any(p=>p.Spec.Id==s.Id));
            if(ids.Count!=normalSpecs.Length||normalSpecs.Count(s=>s.SourceId=="R09"&&s.Id==boss.Id)!=1||
                placed.Any(p=>!ids.Contains(p.Spec.Id)&&!ThirdLoopExtensionPolicy.IsExtraId(p.Spec.Id)&&!knight.Any(k=>k.Id==p.Spec.Id))||
                placed.Select(p=>p.Spec.Id).Distinct(StringComparer.Ordinal).Count()!=placed.Count||
                !BossConnectionExtensionPolicy.Eligible(normalSpecs.Length,normalSpecs.Length,placed.Count(p=>p.Spec.SourceId=="R09"),missing,third.Length,placed.Count,knight.Length))return false;
            NaturalDungeonRoster.ValidateCanonical(canonical);
            if(normalSpecs.Concat(third).Concat(knight).GroupBy(s=>NaturalDungeonRoster.Family(s.SourceId)).Where(g=>g.Key!="R08"&&g.Key!="R09").Any(g=>g.Count()>NaturalDungeonRoster.MaximumOrdinaryRepeats))return false;
            var stairPorts=placed.SelectMany((p,i)=>p.Spec.SourceId=="R08"?p.Spec.Ports.Where(port=>!Used(links,i,port)).Select(port=>Tuple.Create(i,port.id)):Enumerable.Empty<Tuple<int,string>>()).ToArray();
            if(stairPorts.Length>1)return false;
            var anchors=new List<Anchor>();
            for(int i=0;i<placed.Count;i++)
            {
                int depth=DungeonRouteClosure.Distance(0,i,placed.Count,links);if(depth<0)return false;
                foreach(var port in placed[i].Spec.Ports)if(!(i==0&&port.id==entrance)&&!Used(links,i,port)&&
                    (stairPorts.Length==0||stairPorts[0].Item1==i&&stairPorts[0].Item2==port.id))anchors.Add(new Anchor{Room=i,Port=port,Depth=depth});
            }
            var entry=placed[0].Spec.Ports.Single(p=>p.id==entrance);double entryHeight=placed[0].Height(entry.position);
            var order=BossPlacementPolicy.Order(anchors.Count,i=>anchors[i].Depth+1,i=>Math.Abs(placed[anchors[i].Room].Height(anchors[i].Port.position)-entryHeight)>.01,random);
            var search=new Search{Boss=boss,Placed=placed,Links=links,Random=random,Diagnostics=diagnostics,NormalTarget=normalSpecs.Length,ThirdExtras=third.Length,KnightExtras=knight.Length};
            int originalRooms=placed.Count,originalEdges=links.Count,totalRouteBudget=BossConnectionExtensionPolicy.PlacementBudget;bool success=false;
            try
            {
                foreach(int ai in order)
                {
                    var anchor=anchors[ai];diagnostics.BossAnchorAttempts++;
                    success=TryBoss(search,anchor.Room,anchor.Port,anchor.Depth,0,false);
                    if(!success)
                    {
                        diagnostics.BossNormalFailures++;
                        if(totalRouteBudget<=0)continue;
                        if(search.Options==null)search.Options=Options(canonical,normalSpecs,third.Concat(knight).ToArray(),random,oneBrokenSaint);
                        if(search.Options.Length==0)continue;
                        diagnostics.BossExtensionAttempts++;
                        search.Budget=Math.Min(BossConnectionExtensionPolicy.PerAnchorBudget,totalRouteBudget);int offered=search.Budget;
                        int max=Math.Min(BossConnectionExtensionPolicy.MaximumApproachRooms,BossConnectionExtensionPolicy.MaximumRooms-normalSpecs.Length-third.Length-knight.Length);
                        for(int count=1;count<=max&&search.Budget>0;count++)
                        {
                            if(anchor.Depth+count+1<NaturalDungeonRoster.MinimumBossDepth)continue;
                            if(Grow(search,anchor.Room,anchor.Port,anchor.Depth,count,count)){success=true;break;}
                        }
                        totalRouteBudget-=offered-search.Budget;
                    }
                    if(success)
                    {
                        diagnostics.BossExtensionRooms=placed.Count(p=>BossConnectionExtensionPolicy.IsExtraId(p.Spec.Id));
                        diagnostics.BossExtensionReason=diagnostics.BossExtensionRooms>0?BossConnectionExtensionPolicy.Reason:"none";
                        diagnostics.BossAnchorRoomId=placed[anchor.Room].Spec.Id;diagnostics.BossAnchorPortId=anchor.Port.id;diagnostics.BossAnchorDepth=anchor.Depth;
                        diagnostics.MaximumPlaced=Math.Max(diagnostics.MaximumPlaced,placed.Count);budget=Math.Max(Math.Max(0,budget),totalRouteBudget);return true;
                    }
                }
                return false;
            }
            finally
            {
                // Options never enter the ordinary filler inventory. Failed
                // chains leave the original rooms, ports and links untouched.
                if(!success){if(links.Count>originalEdges)links.RemoveRange(originalEdges,links.Count-originalEdges);if(placed.Count>originalRooms)placed.RemoveRange(originalRooms,placed.Count-originalRooms);}
            }
        }
    }
}
