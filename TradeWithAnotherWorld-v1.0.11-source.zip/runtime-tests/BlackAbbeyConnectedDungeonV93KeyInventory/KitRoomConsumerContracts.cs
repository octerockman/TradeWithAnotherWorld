using System.IO;

namespace BlackAbbeySixRooms
{
    // Pure metadata consumers also used later by placed room setup. Run them
    // against every sealed variant before retirement, construction or travel.
    internal static class KitRoomConsumerContracts
    {
        internal static void Validate(string directory, KitRoomBinding binding, PackageManifest room)
        {
            WindowProjectionContract.Validate(room);
            if (room.roomId == "R02")
                ScriptoriumParchmentSourcePolicy.Require(room.roomId, room.sourceSha256,
                    binding.sourceSha256, binding.manifestSha256);
            if (room.roomId == "R07")
                R07InteractionReader.Read(File.ReadAllText(RoomPackage.FilePath(directory, room.interactionFile)), room);
            if (room.roomId == "R08" && (room.bottomMist == null ||
                !UnrecordedDeadFallPolicy.Allows(room.sourceSha256, room.bottomMist.recoveryBelow)))
                throw new InvalidDataException("Rebuilt stair catch plane differs from its checked source.");
            if (R09SplitIdentity.IsPiece(room.roomId)) R09RuntimeContract.Read(directory, room);
        }
    }
}
