using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // The search reserves both pieces atomically. R09 exists only as an
    // in-memory search proxy; no retired manifest, mesh or identity is loaded.
    internal static class R09SplitPlanning
    {
        internal const string ThresholdKind="R09BossThreshold", Boundary="BOSS_BOUNDARY";
        internal static bool IsThreshold(DungeonLink edge)=>edge?.Kind==ThresholdKind;
        internal static void RequireSearchProxy(DungeonRoomSpec spec)
        {
            if(spec==null||!spec.SplitBossProxy||spec.Id!="R09"||spec.SourceId!="R09"||
                (spec.AssetId!="R09"&&spec.AssetId!="R09-UD")||spec.Ports?.Length!=1||spec.Ports[0].id!="SOUTH"||
                (spec.Ports[0].SourceRoomId!="R09-A1"&&spec.Ports[0].SourceRoomId!="R09-A2")||
                spec.Reservations==null||spec.Reservations.Length<2||!spec.KitConnectedExteriorCollar)
                throw new InvalidDataException("Only the source-checked atomic pair may use the private search proxy.");
        }
        internal static bool IsBoundary(PortRecord port)=>port?.id==Boundary &&
            (port.SourceRoomId=="R09-A1"||port.SourceRoomId=="R09-A2"||port.SourceRoomId=="R09-B");
        static double[][] Boxes(DungeonRoomSpec s)=>s.Reservations??new[]{new[]{s.Bounds[0],s.BoundsY[0],s.Bounds[1],s.Bounds[2],s.BoundsY[1],s.Bounds[3]}};
        static DungeonRoomSpec Proxy(DungeonRoomSpec hall,DungeonRoomSpec chamber)
        {
            var arrival=hall.Ports.Single(p=>p.id=="SOUTH");
            if(hall.Ports.Length!=2||chamber.Ports.Length!=1||!hall.Ports.Any(IsBoundary)||!chamber.Ports.All(IsBoundary))
                throw new InvalidDataException("The split boss requires one hall arrival and one exclusive shared threshold.");
            return new DungeonRoomSpec{Id="R09",SourceId="R09",AssetId=hall.SourceId=="R09-A2"?"R09-UD":"R09",
                Ports=new[]{arrival},Bounds=new[]{Math.Min(hall.Bounds[0],chamber.Bounds[0]),Math.Min(hall.Bounds[1],chamber.Bounds[1]),Math.Max(hall.Bounds[2],chamber.Bounds[2]),Math.Max(hall.Bounds[3],chamber.Bounds[3])},
                BoundsY=new[]{Math.Min(hall.BoundsY[0],chamber.BoundsY[0]),Math.Max(hall.BoundsY[1],chamber.BoundsY[1])},
                Reservations=Boxes(hall).Concat(Boxes(chamber)).Select(b=>b.ToArray()).ToArray(),
                KitConnectedExteriorCollar=true,SplitBossProxy=true};
        }
        internal static DungeonPlan Generate(IEnumerable<DungeonRoomSpec> input,int seed,bool broken,int spacing,
            IEnumerable<DungeonRoomSpec> variants,string route,bool showcase=false)
            =>GenerateCore(input,seed,broken,spacing,variants,route,showcase,false);
        internal static DungeonPlan GenerateKnightLoop(IEnumerable<DungeonRoomSpec> input,int seed,IEnumerable<DungeonRoomSpec> variants)
        {
            var sources=input.ToArray();var actual=variants.ToArray();
            for(int retry=0;retry<4;retry++)
                try{return GenerateCore(sources,unchecked(seed+retry),false,0,actual,UnrecordedDeadGeneration.Route,false,true);}
                catch(InvalidOperationException e)when(e.Message.StartsWith("Could not fit a natural source roster without overlap;",StringComparison.Ordinal)){if(retry==3)throw;}
            throw new InvalidOperationException("No admitted knight return loop.");
        }
        private static DungeonPlan GenerateCore(IEnumerable<DungeonRoomSpec> input,int seed,bool broken,int spacing,IEnumerable<DungeonRoomSpec> variants,string route,bool showcase,bool knightLoop)
        {
            var sources=input?.ToArray()??Array.Empty<DungeonRoomSpec>();
            if(sources.Length!=11||sources.Select(s=>s.SourceId).Distinct().Count()!=11||sources.Any(s=>s.SourceId=="R09"||s.SourceId=="R09-A2"))
                throw new InvalidDataException("Revision4 requires eleven current canonical room sources without retired combined rooms.");
            var a1=sources.Single(s=>s.SourceId=="R09-A1");var chamber=sources.Single(s=>s.SourceId=="R09-B");
            var hall=a1;
            Dictionary<string,DungeonRoomSpec> normalized=null;
            if(route==UnrecordedDeadGeneration.Route)
            {
                var actual=UnrecordedDeadGeneration.VariantSet(variants);
                hall=actual["R09-A2"];
                normalized=actual.Where(p=>p.Key!="R09-A2").ToDictionary(p=>p.Key,p=>p.Value,StringComparer.Ordinal);
                normalized.Add("R09",Proxy(hall,chamber));
            }
            var canonical=sources.Where(s=>s.SourceId!="R09-A1"&&s.SourceId!="R09-B").Concat(new[]{Proxy(a1,chamber)}).ToArray();
            var plan=showcase?DungeonLayoutPlanner.Generate(canonical,seed):knightLoop?DungeonLayoutPlanner.GenerateNaturalKnightLoop(canonical,seed,normalized):DungeonLayoutPlanner.GenerateNatural(canonical,seed,
                route==UnrecordedDeadGeneration.Route?false:broken,route==UnrecordedDeadGeneration.Route?0:spacing,normalized);
            int at=Array.FindIndex(plan.Rooms,p=>p.Spec.SourceId=="R09");
            if(at<0||plan.Rooms.Count(p=>p.Spec.SourceId=="R09")!=1)throw new InvalidDataException("The whole split pair must be reserved once before expansion.");
            var old=plan.Rooms[at];int arena=plan.Rooms.Length;
            var placedHall=new DungeonPlacement{Spec=hall,QuarterTurns=old.QuarterTurns,Position=old.Position,Elevation=old.Elevation};
            var placedChamber=new DungeonPlacement{Spec=chamber,QuarterTurns=old.QuarterTurns,Position=old.Position,Elevation=old.Elevation};
            plan.Rooms[at]=placedHall;plan.Rooms=plan.Rooms.Concat(new[]{placedChamber}).ToArray();
            foreach(var edge in plan.Links){if(edge.A==at)edge.PortA=hall.Ports.Single(p=>p.id==edge.PortA.id);if(edge.B==at)edge.PortB=hall.Ports.Single(p=>p.id==edge.PortB.id);}
            var pa=hall.Ports.Single(IsBoundary);var pb=chamber.Ports.Single(IsBoundary);
            var joint=new DungeonLink{A=at,B=arena,PortA=pa,PortB=pb,Start=placedHall.Point(pa.position),End=placedChamber.Point(pb.position),Elevation=old.Elevation,Kind=ThresholdKind};
            plan.Links=plan.Links.Concat(new[]{joint}).ToArray();plan.GenerationRevision=4;plan.BossUnlockRoute=route;
            ValidateThreshold(plan,joint);
            return plan;
        }
        internal static void ValidateThreshold(DungeonPlan plan,DungeonLink edge)
        {
            if(plan==null||plan.GenerationRevision!=4||!IsThreshold(edge)||edge.A<0||edge.B<0||edge.A>=plan.Rooms.Length||edge.B>=plan.Rooms.Length)
                throw new InvalidDataException("Invalid split boss threshold identity.");
            var a=plan.Rooms[edge.A];var b=plan.Rooms[edge.B];
            if(!((a.Spec.SourceId=="R09-A1"||a.Spec.SourceId=="R09-A2")&&b.Spec.SourceId=="R09-B")||
                !IsBoundary(edge.PortA)||!IsBoundary(edge.PortB)||a.QuarterTurns!=b.QuarterTurns||
                edge.PortA.SourceRoomId!=a.Spec.SourceId||edge.PortB.SourceRoomId!=b.Spec.SourceId||
                !a.Spec.Ports.Contains(edge.PortA)||!b.Spec.Ports.Contains(edge.PortB)||
                (a.Position-b.Position).Length>1e-6||Math.Abs(a.Elevation-b.Elevation)>1e-6||
                (a.Point(edge.PortA.position)-b.Point(edge.PortB.position)).Length>1e-5||
                (edge.Start-a.Point(edge.PortA.position)).Length>1e-5||
                (edge.End-b.Point(edge.PortB.position)).Length>1e-5||
                Math.Abs(edge.Elevation-a.Height(edge.PortA.position))>1e-5||
                Math.Abs(a.Height(edge.PortA.position)-b.Height(edge.PortB.position))>1e-5||
                (a.Normal(edge.PortA)+b.Normal(edge.PortB)).Length>1e-5||
                Math.Abs(edge.PortA.width-5)>.001||Math.Abs(edge.PortB.width-5)>.001||
                Math.Abs(edge.PortA.height-7)>.001||Math.Abs(edge.PortB.height-7)>.001||
                (edge.End-edge.Start).Length>1e-5||plan.Links.Count(IsThreshold)!=1)
                throw new InvalidDataException("Split pieces must share the exact original threshold, opposing ports and one frame-owned door; no extra passage is allowed.");
        }
    }
}
