namespace BlackAbbeySixRooms
{
    // Native authoring contains the quest pieces for inspection. Only the
    // selected saved instance receives interactive replacements. Ordinary
    // scriptoriums and the other boss route must not display that embedded art.
    internal static class FalseVowsRouteVisibilityPolicy
    {
        internal static bool NeedsInactiveMasks(bool activeQuestInstance,string roomId)
            =>!activeQuestInstance&&(roomId=="R02"||roomId=="R09"||roomId==R09SplitIdentity.FalseVowsHall);
    }
}
