using System;
using System.Linq;
using Jotunn.Managers;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Native game clip/mixer data only: no effect prefab, network object,
    // enemy, destruction component or randomized concurrent source is cloned.
    public sealed class R07StoneAudio : MonoBehaviour
    {
        internal const string SlidePrefab = "sfx_stonedoor_sliding_open";
        internal const string SlideClip = "Scrape_HeavyStone_Loop4";
        internal const string ImpactPrefab = "sfx_stonegolem_attack_hit";
        internal const string ImpactClip = "Smash_RockShatter";
        private AudioSource scrape, impact;
        private bool moving, impacted;
        private Action<string> log;
        private string part;

        internal static R07StoneAudio Attach(GameObject host, string partId, Action<string> write)
        {
            if (partId != "statue-slide" && partId != "coffin-lid") return null;
            if (!host) throw new ArgumentNullException(nameof(host));
            var owner = host.AddComponent<R07StoneAudio>(); owner.part = partId; owner.log = write;
            owner.scrape = Create(host.transform, "R07 native stone scrape", SlidePrefab, SlideClip, true, 1f, 1f);
            if (partId == "coffin-lid")
                owner.impact = Create(host.transform, "R07 native stone floor impact", ImpactPrefab, ImpactClip, false, 1f, .85f);
            write?.Invoke("R07_STONE_AUDIO: part=" + partId + "; scrape=" + SlidePrefab + "/" + SlideClip +
                "; loopGain=1; roomAudibleLinearFalloff=3..30m; impact=" + (owner.impact ? ImpactPrefab + "/" + ImpactClip + "; impactGain=1; linearFalloff=3..35m" : "none") +
                "; native clips and mixer borrowed; actual-pose advancement only.");
            return owner;
        }

        private static AudioSource Create(Transform parent, string name, string prefabName, string clipName, bool loop, float gain, float pitch)
        {
            var prefab = PrefabManager.Instance.GetPrefab(prefabName);
            if (!prefab) throw new InvalidOperationException("The inspected native stone audio prefab is unavailable: " + prefabName);
            var clips = prefab.GetComponentsInChildren<ZSFX>(true).SelectMany(z => z.m_audioClips ?? Array.Empty<AudioClip>())
                .Where(c => c && c.name == clipName).Distinct().ToArray();
            if (clips.Length != 1 || clips[0].length <= 0 || clips[0].channels != 1)
                throw new InvalidOperationException("Native stone clip differs from inspected mono source: " + clipName);
            var source = prefab.GetComponentInChildren<AudioSource>(true);
            if (!source) throw new InvalidOperationException("Native stone effect lost its audio/mixer source: " + prefabName);
            var child = new GameObject(name); child.SetActive(false); child.transform.SetParent(parent, false);
            var audio = child.AddComponent<AudioSource>();
            audio.playOnAwake = false; audio.clip = clips[0]; audio.outputAudioMixerGroup = source.outputAudioMixerGroup;
            audio.loop = loop; audio.volume = gain; audio.pitch = pitch; audio.spatialBlend = 1;
            // The former .42 gain with a1.5m logarithmic near distance made
            // grinding barely audible from the far candle shelves. Keep3D
            // direction and the native SFX mixer, but sustain it across R07.
            audio.rolloffMode = AudioRolloffMode.Linear;
            audio.minDistance = 3f; audio.maxDistance = loop ? 30f : 35f;
            audio.dopplerLevel = 0; audio.spread = 0; audio.priority = loop ? 64 : 48;
            child.SetActive(true); return audio;
        }

        internal void SetMoving(bool value)
        {
            value &= isActiveAndEnabled && gameObject.activeInHierarchy;
            if (moving == value) return;
            moving = value;
            if (!scrape) return;
            if (value) scrape.Play(); else scrape.Stop();
        }

        internal void ImpactOnce()
        {
            if (impacted || !impact || !isActiveAndEnabled || !gameObject.activeInHierarchy) return;
            impacted = true; SetMoving(false); impact.Play();
            log?.Invoke("R07_STONE_IMPACT: part=" + part + "; nativeClip=" + ImpactClip + "; once=true; actual lid floor-contact phase.");
        }

        internal void ImpactOnce(Vector3 worldPosition)
        {
            if (!impacted && impact) impact.transform.position = worldPosition;
            ImpactOnce();
        }

        private void OnDisable()
        {
            moving = false;
            if (scrape) scrape.Stop();
            if (impact) impact.Stop();
        }
    }
}
