using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    internal sealed class FalseVowsRoomBinding
    {
        public string scriptorium, vestry, saint, boss, gateA, gateB;
    }
    internal sealed class FalseVowsReceipt
    {
        public string itemId, actorId, token;
    }
    internal sealed class FalseVowsSnapshot
    {
        public int schemaVersion = 1;
        public string routeId, runId;
        public long revision;
        public FalseVowsRoomBinding rooms;
        public int collectedMask, solvedMask;
        public bool noteReleased, cabinetsUnlocked, bookPlaced;
        public int[] releaseSeeds = new int[3];
        public List<FalseVowsReceipt> deliveries = new List<FalseVowsReceipt>();
        public List<FalseVowsReceipt> consumptions = new List<FalseVowsReceipt>();
    }
    internal enum FalseVowsResult
    {
        Applied, AlreadyResolved, InventoryFull, MissingItem, WrongItem, WrongRun,
        Locked, Unavailable, PersistenceFailed, DeliveryPending, ConsumptionPending, RecoveryHeld
    }

    // Pure source/quest ownership. Native inventory, ground items and world save
    // remain external. Durable receipts explicitly bridge their save boundary.
    internal sealed class FalseVowsState
    {
        internal const string Route = "three_false_vows";
        internal const string Book = "abbey_oath_tome", Letter = "abbey_hasty_note", Key = "abbey_scriptorium_key";
        internal const string Deposition = "abbey_bellkeeper_deposition", Purse = "abbey_hidden_tithe_purse", Seal = "abbey_broken_chapter_seal";
        private static readonly string[] Items = { Book, Letter, Key, Deposition, Purse, Seal };
        private FalseVowsSnapshot state;
        private bool transacting;
        private FalseVowsState(FalseVowsSnapshot state) { this.state = state; }
        internal string RunId => state.runId;
        internal bool NoteReleased => state.noteReleased;
        internal bool CabinetsUnlocked => state.cabinetsUnlocked;
        internal bool BookPlaced => state.bookPlaced;
        internal int SolvedMask => state.solvedMask;
        internal bool DoorUnlocked => state.solvedMask == 7;
        internal long Revision => state.revision;
        internal FalseVowsRoomBinding Rooms => Clone(state.rooms);
        internal FalseVowsSnapshot Capture() => Clone(state);
        internal static bool SelectedForNewRun(bool isNewRun, string mode) => isNewRun && mode == "natural";

        internal static FalseVowsState CreateNew(string runId, FalseVowsRoomBinding rooms)
        {
            var snapshot = new FalseVowsSnapshot { routeId = Route, runId = runId, rooms = Clone(rooms) };
            Validate(snapshot, runId); return new FalseVowsState(snapshot);
        }
        internal static FalseVowsState Restore(FalseVowsSnapshot snapshot, string expectedRunId)
        {
            // Null belongs to legacy/nonselected runs; never inject a new gate.
            if (snapshot == null) return null;
            Validate(snapshot, expectedRunId); return new FalseVowsState(Clone(snapshot));
        }
        internal string Token(string itemId)
        { if (Index(itemId) < 0) throw new ArgumentException("Unknown Abbey evidence item.", nameof(itemId)); return state.runId + ":" + itemId; }
        internal bool Collected(string itemId) { int index = Index(itemId); return index >= 0 && (state.collectedMask & (1 << index)) != 0; }
        internal bool Consumed(string itemId)
        { int seal = EvidenceIndex(itemId); return itemId == Book ? state.bookPlaced : seal >= 0 && (state.solvedMask & (1 << seal)) != 0; }
        internal int ReleaseSeed(string evidenceId)
        { int index = EvidenceIndex(evidenceId); if (index < 0 || (state.solvedMask & (1 << index)) == 0) throw new InvalidOperationException("Seal has not been released."); return state.releaseSeeds[index]; }
        internal static int EvidenceIndex(string id) => id == Deposition ? 0 : id == Purse ? 1 : id == Seal ? 2 : -1;
        internal string SourceRoom(string id) => id == Purse ? state.rooms.saint : id == Seal ? state.rooms.vestry : Index(id) >= 0 ? state.rooms.scriptorium : null;
        private static int Index(string id) => Array.IndexOf(Items, id);
        private bool SameToken(string id, string token) => Index(id) >= 0 && string.Equals(Token(id), token, StringComparison.Ordinal);
        private static bool Actor(string id) => long.TryParse(id, NumberStyles.Integer, CultureInfo.InvariantCulture, out long value) && value != 0 && id == value.ToString(CultureInfo.InvariantCulture);

        // persist must atomically save the whole candidate (including receipt)
        // or return false/throw without publishing it. Its native-store adapter
        // must restore the outer saved-run reference on failed commits.
        private bool Commit(FalseVowsSnapshot candidate, Func<FalseVowsSnapshot, bool> persist)
        {
            if (persist == null) throw new ArgumentNullException(nameof(persist));
            if (transacting) throw new InvalidOperationException("Reentrant quest commit refused.");
            candidate.revision = checked(state.revision + 1); Validate(candidate, state.runId);
            transacting = true;
            try
            {
                if (!persist(Clone(candidate))) return false;
                state = Clone(candidate); return true;
            }
            finally { transacting = false; }
        }
        private bool ReleaseNote(Func<FalseVowsSnapshot, bool> persist)
        { if (state.noteReleased) return true; var next = Capture(); next.noteReleased = true; return Commit(next, persist); }

        internal FalseVowsResult TryPickup(string itemId, string actorId, string sourceRoomId, Func<bool> canReceive,
            Func<FalseVowsSnapshot, bool> persist, Func<FalseVowsReceipt, bool> deliver)
        {
            int index = Index(itemId);
            if (index < 0) return FalseVowsResult.WrongItem;
            if (!Actor(actorId) || sourceRoomId != SourceRoom(itemId)) return FalseVowsResult.Unavailable;
            if (Collected(itemId)) return FalseVowsResult.AlreadyResolved;
            if (itemId == Letter && !state.noteReleased || itemId == Deposition && !state.cabinetsUnlocked) return FalseVowsResult.Locked;
            if (canReceive == null || deliver == null) throw new ArgumentNullException("Pickup adapters are required.");
            if (!canReceive()) return FalseVowsResult.InventoryFull;
            var receipt = new FalseVowsReceipt { itemId = itemId, actorId = actorId, token = Token(itemId) };
            var next = Capture(); next.collectedMask |= 1 << index; next.deliveries.Add(Clone(receipt));
            if (!Commit(next, persist)) return FalseVowsResult.PersistenceFailed;
            if (!deliver(Clone(receipt))) return FalseVowsResult.DeliveryPending;
            // Book claims whose live AddItem unexpectedly failed never release
            // a letter. A durable successful-delivery/recovery event does.
            if (itemId == Book && !ReleaseNote(persist)) return FalseVowsResult.DeliveryPending;
            return FalseVowsResult.Applied;
        }

        internal FalseVowsResult TryUnlockCabinets(string actorId, string roomId, string keyToken, Func<bool> ownsKey,
            Func<FalseVowsSnapshot, bool> persist)
        {
            if (!Actor(actorId) || roomId != state.rooms.scriptorium) return FalseVowsResult.Unavailable;
            if (state.cabinetsUnlocked) return FalseVowsResult.AlreadyResolved;
            if (!SameToken(Key, keyToken)) return FalseVowsResult.WrongRun;
            if (!Collected(Key) || ownsKey == null || !ownsKey()) return FalseVowsResult.MissingItem;
            var next = Capture(); next.cabinetsUnlocked = true;
            return Commit(next, persist) ? FalseVowsResult.Applied : FalseVowsResult.PersistenceFailed;
        }

        internal FalseVowsResult TryPlaceBook(string actorId, string roomId, string bookToken, Func<bool> ownsBook,
            Func<FalseVowsSnapshot, bool> persist, Func<FalseVowsReceipt, bool> consume)
        {
            if (!Actor(actorId) || roomId != state.rooms.boss) return FalseVowsResult.Unavailable;
            if (state.bookPlaced) return FalseVowsResult.AlreadyResolved;
            if (!SameToken(Book, bookToken)) return FalseVowsResult.WrongRun;
            if (!Collected(Book) || ownsBook == null || !ownsBook()) return FalseVowsResult.MissingItem;
            if (consume == null) throw new ArgumentNullException(nameof(consume));
            var next = Capture(); next.bookPlaced = true; next.noteReleased = true;
            var receipt = ConsumeReceipt(next, Book, actorId);
            if (!Commit(next, persist)) return FalseVowsResult.PersistenceFailed;
            return consume(Clone(receipt)) ? FalseVowsResult.Applied : FalseVowsResult.ConsumptionPending;
        }

        internal FalseVowsResult TryOfferEvidence(string actorId, string roomId, string itemId, string itemToken,
            Func<bool> ownsItem, Func<int> releaseSeed, Func<FalseVowsSnapshot, bool> persist, Func<FalseVowsReceipt, bool> consume)
        {
            if (!Actor(actorId) || roomId != state.rooms.boss) return FalseVowsResult.Unavailable;
            int index = EvidenceIndex(itemId); if (index < 0) return FalseVowsResult.WrongItem;
            if ((state.solvedMask & (1 << index)) != 0) return FalseVowsResult.AlreadyResolved;
            if (!state.bookPlaced) return FalseVowsResult.Locked;
            if (!SameToken(itemId, itemToken)) return FalseVowsResult.WrongRun;
            if (!Collected(itemId) || ownsItem == null || !ownsItem()) return FalseVowsResult.MissingItem;
            if (releaseSeed == null || consume == null) throw new ArgumentNullException("Evidence adapters are required.");
            var next = Capture(); next.solvedMask |= 1 << index; next.releaseSeeds[index] = releaseSeed();
            var receipt = ConsumeReceipt(next, itemId, actorId);
            if (!Commit(next, persist)) return FalseVowsResult.PersistenceFailed;
            return consume(Clone(receipt)) ? FalseVowsResult.Applied : FalseVowsResult.ConsumptionPending;
        }
        private FalseVowsReceipt ConsumeReceipt(FalseVowsSnapshot next, string id, string actor)
        {
            string token = Token(id); next.deliveries.RemoveAll(r => r.token == token);
            var receipt = new FalseVowsReceipt { itemId = id, actorId = actor, token = token };
            next.consumptions.Add(receipt); return receipt;
        }

        // Presence is TRUE for a verified token anywhere in native ownership,
        // FALSE only after a complete inventory/ground/tombstone absence scan,
        // and NULL when that scan/participant save is incomplete. Live AddItem
        // success alone does not acknowledge native file persistence.
        internal FalseVowsResult TryRecoverDelivery(string token, string actorId, Func<string, bool?> authoritativePresence,
            Func<bool> canReceive, Func<FalseVowsSnapshot, bool> persist, Func<FalseVowsReceipt, bool> deliver)
        {
            var receipt = state.deliveries.SingleOrDefault(r => r.token == token);
            if (receipt == null || Consumed(receipt.itemId)) return FalseVowsResult.AlreadyResolved;
            if (receipt.actorId != actorId || !Actor(actorId)) return FalseVowsResult.Unavailable;
            if (authoritativePresence == null || canReceive == null || deliver == null) throw new ArgumentNullException("Recovery adapters are required.");
            bool? present = authoritativePresence(token);
            if (!present.HasValue) return FalseVowsResult.RecoveryHeld;
            if (present.Value)
            {
                if (receipt.itemId == Book && !ReleaseNote(persist)) return FalseVowsResult.DeliveryPending;
                return FalseVowsResult.AlreadyResolved;
            }
            if (!canReceive()) return FalseVowsResult.InventoryFull;
            if (!deliver(Clone(receipt))) return FalseVowsResult.DeliveryPending;
            if (receipt.itemId == Book && !ReleaseNote(persist)) return FalseVowsResult.DeliveryPending;
            return FalseVowsResult.Applied;
        }
        internal FalseVowsResult RetryConsumption(string token, Func<FalseVowsReceipt, bool> consume)
        {
            var receipt = state.consumptions.SingleOrDefault(r => r.token == token);
            if (receipt == null) return FalseVowsResult.AlreadyResolved;
            if (consume == null) throw new ArgumentNullException(nameof(consume));
            return consume(Clone(receipt)) ? FalseVowsResult.Applied : FalseVowsResult.ConsumptionPending;
        }
        internal FalseVowsResult AcknowledgeDelivery(string token, Func<FalseVowsSnapshot, bool> persist)
        {
            var receipt = state.deliveries.SingleOrDefault(r => r.token == token);
            if (receipt == null) return FalseVowsResult.AlreadyResolved;
            var next = Capture(); next.deliveries.RemoveAll(r => r.token == token);
            if (receipt.itemId == Book) next.noteReleased = true;
            return Commit(next, persist) ? FalseVowsResult.Applied : FalseVowsResult.PersistenceFailed;
        }
        internal FalseVowsResult AcknowledgeConsumption(string token, Func<FalseVowsSnapshot, bool> persist)
        {
            if (!state.consumptions.Any(r => r.token == token)) return FalseVowsResult.AlreadyResolved;
            var next = Capture(); next.consumptions.RemoveAll(r => r.token == token);
            return Commit(next, persist) ? FalseVowsResult.Applied : FalseVowsResult.PersistenceFailed;
        }

        internal static void Validate(FalseVowsSnapshot value, string expectedRunId)
        {
            if (value == null || value.schemaVersion != 1 || value.routeId != Route ||
                !Guid.TryParseExact(value.runId, "N", out _) || value.runId != expectedRunId || value.revision < 0 || value.revision == long.MaxValue ||
                value.collectedMask < 0 || (value.collectedMask & ~63) != 0 || value.solvedMask < 0 || (value.solvedMask & ~7) != 0 ||
                value.rooms == null || !BindingValid(value.rooms) || value.releaseSeeds == null || value.releaseSeeds.Length != 3 ||
                value.deliveries == null || value.deliveries.Count > 6 || value.consumptions == null || value.consumptions.Count > 4)
                throw new InvalidDataException("Invalid Three False Vows route identity or envelope; retain the saved run.");
            bool collected(string id) => (value.collectedMask & (1 << Index(id))) != 0;
            bool consumed(string id) => id == Book ? value.bookPlaced : EvidenceIndex(id) >= 0 && (value.solvedMask & (1 << EvidenceIndex(id))) != 0;
            if (value.noteReleased && !collected(Book) || collected(Letter) && !value.noteReleased || value.cabinetsUnlocked && !collected(Key) ||
                collected(Deposition) && !value.cabinetsUnlocked || value.bookPlaced && (!collected(Book) || !value.noteReleased) ||
                value.solvedMask != 0 && !value.bookPlaced ||
                Enumerable.Range(0, 3).Any(i => (value.solvedMask & (1 << i)) != 0 && !collected(Items[i + 3]) || (value.solvedMask & (1 << i)) == 0 && value.releaseSeeds[i] != 0))
                throw new InvalidDataException("Three False Vows progress is causally inconsistent.");
            foreach (var list in new[] { value.deliveries, value.consumptions })
            {
                if (list.Any(r => r == null || Index(r.itemId) < 0 || !Actor(r.actorId) || r.token != value.runId + ":" + r.itemId || !collected(r.itemId)) ||
                    list.Select(r => r.token).Distinct(StringComparer.Ordinal).Count() != list.Count)
                    throw new InvalidDataException("Invalid/duplicate Three False Vows transaction receipt.");
            }
            if (value.deliveries.Any(r => consumed(r.itemId)) || value.consumptions.Any(r => !consumed(r.itemId)) ||
                value.deliveries.Select(r => r.token).Intersect(value.consumptions.Select(r => r.token), StringComparer.Ordinal).Any())
                throw new InvalidDataException("Three False Vows delivery and consumption ownership conflict.");
        }
        internal static bool BindingValid(FalseVowsRoomBinding rooms)
        {
            if (rooms == null) return false;
            var ids = new[] { rooms.scriptorium, rooms.vestry, rooms.saint, rooms.boss, rooms.gateA, rooms.gateB };
            return ids.All(s => !string.IsNullOrWhiteSpace(s) && s.Length <= 128 && !s.Any(char.IsControl)) &&
                new[] { rooms.scriptorium, rooms.vestry, rooms.saint, rooms.boss }.Distinct(StringComparer.Ordinal).Count() == 4 && rooms.gateA != rooms.gateB;
        }
        private static FalseVowsRoomBinding Clone(FalseVowsRoomBinding r) => r == null ? null : new FalseVowsRoomBinding { scriptorium = r.scriptorium, vestry = r.vestry, saint = r.saint, boss = r.boss, gateA = r.gateA, gateB = r.gateB };
        private static FalseVowsReceipt Clone(FalseVowsReceipt r) => new FalseVowsReceipt { itemId = r.itemId, actorId = r.actorId, token = r.token };
        private static FalseVowsSnapshot Clone(FalseVowsSnapshot s) => new FalseVowsSnapshot { schemaVersion = s.schemaVersion, routeId = s.routeId, runId = s.runId, revision = s.revision,
            rooms = Clone(s.rooms), collectedMask = s.collectedMask, solvedMask = s.solvedMask, noteReleased = s.noteReleased, cabinetsUnlocked = s.cabinetsUnlocked,
            bookPlaced = s.bookPlaced, releaseSeeds = (int[])s.releaseSeeds.Clone(), deliveries = s.deliveries.Select(Clone).ToList(), consumptions = s.consumptions.Select(Clone).ToList() };
    }
}
