using System;
using System.Collections.Generic;

namespace BlackAbbeySixRooms
{
    internal static class FalseVowsItemIdentity
    {
        internal const string RunKey = "twa.falsevows.run", TokenKey = "twa.falsevows.token";
        internal static bool Valid(string runId, string token)
            => !string.IsNullOrWhiteSpace(runId) && runId.Length <= 128 && !string.IsNullOrWhiteSpace(token) && token.Length <= 256;
        internal static void Tag(IDictionary<string, string> data, string runId, string token)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (!Valid(runId, token)) throw new ArgumentException("Quest item identity is invalid.");
            data[RunKey] = runId; data[TokenKey] = token;
        }
        internal static bool Matches(IDictionary<string, string> data, string runId, string token)
            => Valid(runId, token) && data != null && data.TryGetValue(RunKey, out var run) && data.TryGetValue(TokenKey, out var value)
                && string.Equals(run, runId, StringComparison.Ordinal) && string.Equals(value, token, StringComparison.Ordinal);
    }
}
