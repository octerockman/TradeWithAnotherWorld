using System;
using System.Collections.Generic;
using System.IO;
using Jotunn.Managers;
using UnityEngine;
using UnityEngine.Audio;
using Object=UnityEngine.Object;
namespace BlackAbbeySixRooms
{
    // Two local voices per selected writing-desk room. Native prefab/effect
    // data is read only; no door, network effect or clip is cloned/modified.
    internal sealed class FalseVowsCabinetAudio:MonoBehaviour
    {
        internal const string NativeHalfDoor="wood_fence_gate";
        internal const string UnlockResource="BlackAbbey.FalseVows.CabinetUnlock.wav";
        private sealed class Cue
        {
            internal AudioClip[] Clips;internal AudioMixerGroup Mixer;
            internal float MinVolume,MaxVolume,MinPitch,MaxPitch,MinDelay,MaxDelay;
            internal int Priority;
        }
        private readonly AudioSource[] voices=new AudioSource[2];
        private readonly long[] order=new long[2];
        private readonly double[] busyUntil=new double[2];
        private long played;
        private Cue[] opening,closing;
        private AudioClip unlock;
        private Action<string> log;
        private string lastFailure;
        private float nextResolve;
        internal void Configure(Action<string> write)
        {
            log=write;
            for(int i=0;i<voices.Length;i++)
            {
                var child=new GameObject("Writing-desk cabinet sound "+i);child.transform.SetParent(transform,false);
                var source=child.AddComponent<AudioSource>();source.playOnAwake=false;source.loop=false;
                source.spatialBlend=1;source.minDistance=1;source.maxDistance=12;source.rolloffMode=AudioRolloffMode.Linear;source.dopplerLevel=0;voices[i]=source;
            }
        }
        internal void PlayDoor(Vector3 point,bool open)
        {
            try
            {
                if(!Resolve())return;
                foreach(var cue in open?opening:closing)
                {
                    var source=Voice(point,cue.Mixer,cue.Priority);if(!source)continue;
                    source.clip=cue.Clips[UnityEngine.Random.Range(0,cue.Clips.Length)];
                    source.volume=UnityEngine.Random.Range(cue.MinVolume,cue.MaxVolume);source.pitch=UnityEngine.Random.Range(cue.MinPitch,cue.MaxPitch);
                    Schedule(source,UnityEngine.Random.Range(cue.MinDelay,cue.MaxDelay));
                }
            }
            catch(Exception ex){Failure(ex);}
        }
        internal void PlayUnlock(Vector3 point)
        {
            try
            {
                if(!Resolve())return;
                if(!unlock)
                {
                    using(var stream=typeof(FalseVowsCabinetAudio).Assembly.GetManifestResourceStream(UnlockResource))
                    {
                        if(stream==null||stream.Length>100000)throw new InvalidDataException("Embedded cabinet unlock sound missing or oversized.");
                        using(var buffer=new MemoryStream())
                        {
                            stream.CopyTo(buffer);var pcm=PcmWave.Read(buffer.ToArray());
                            if(pcm.Channels!=1||pcm.SampleRate!=48000||pcm.Frames<4800||pcm.Frames>48000)throw new InvalidDataException("Invalid cabinet unlock sound format.");
                            unlock=AudioClip.Create("Abbey cabinet | original key and lock release",pcm.Frames,1,48000,false);unlock.SetData(pcm.Samples,0);
                        }
                    }
                }
                var cue=opening[0];var source=Voice(point,cue.Mixer,cue.Priority);if(!source)return;
                source.clip=unlock;source.volume=.85f;source.pitch=1;Schedule(source,0);
            }
            catch(Exception ex){Failure(ex);}
        }
        private AudioSource Voice(Vector3 point,AudioMixerGroup mixer,int priority)
        {
            int selected=order[0]<=order[1]?0:1;
            for(int i=0;i<voices.Length;i++)if(voices[i]&&busyUntil[i]<=AudioSettings.dspTime){selected=i;break;}
            var source=voices[selected];if(!source)return null;
            source.Stop();source.transform.position=point;source.outputAudioMixerGroup=mixer;source.priority=priority;source.mute=false;source.loop=false;order[selected]=++played;return source;
        }
        private void Schedule(AudioSource source,float delay)
        {
            int index=Array.IndexOf(voices,source);if(index<0||!source.clip)return;
            busyUntil[index]=AudioSettings.dspTime+delay+source.clip.length/Mathf.Max(.01f,source.pitch);
            source.PlayDelayed(delay);
        }
        private bool Resolve()
        {
            if(opening!=null&&closing!=null)return true;
            if(Time.unscaledTime<nextResolve)return false;nextResolve=Time.unscaledTime+2;
            try
            {
                var prefab=PrefabManager.Instance.GetPrefab(NativeHalfDoor);
                var door=prefab?prefab.GetComponent<Door>():null;
                if(!door)throw new InvalidOperationException("Native half-height wooden door is not ready.");
                var a=Read(door.m_openEffects);var b=Read(door.m_closeEffects);
                if(a.Length==0||b.Length==0||a.Length>2||b.Length>2)throw new InvalidDataException("Native half-door sound budget changed.");
                opening=a;closing=b;lastFailure=null;
                log?.Invoke("FALSE_VOWS_CABINET_AUDIO_BOUND: native="+NativeHalfDoor+"; exact native open/close clips, mixer, pitch, volume and delays; local12m range;2voices.");
                return true;
            }
            catch(Exception ex){Failure(ex);return false;}
        }
        private static Cue[] Read(EffectList effects)
        {
            var result=new List<Cue>();
            if(effects?.m_effectPrefabs==null)return result.ToArray();
            foreach(var e in effects.m_effectPrefabs)
            {
                if(!e.m_enabled||!e.m_prefab)continue;
                foreach(var sound in e.m_prefab.GetComponentsInChildren<ZSFX>(true))
                {
                    if(!sound||sound.m_audioClips==null)continue;
                    var source=sound.GetComponent<AudioSource>();if(!source)continue;
                    var clips=new List<AudioClip>();foreach(var clip in sound.m_audioClips)if(clip&&clip.length>0)clips.Add(clip);
                    if(clips.Count==0)continue;
                    if(!Finite(sound.m_minVol)||!Finite(sound.m_maxVol)||sound.m_minVol<0||sound.m_maxVol<sound.m_minVol||!Finite(sound.m_minPitch)||!Finite(sound.m_maxPitch)||sound.m_minPitch<=0||sound.m_maxPitch<sound.m_minPitch||!Finite(sound.m_minDelay)||!Finite(sound.m_maxDelay)||sound.m_minDelay<0||sound.m_maxDelay<sound.m_minDelay)throw new InvalidDataException("Native cabinet cue ranges are invalid.");
                    result.Add(new Cue{Clips=clips.ToArray(),Mixer=source.outputAudioMixerGroup,Priority=source.priority,MinVolume=sound.m_minVol,MaxVolume=sound.m_maxVol,MinPitch=sound.m_minPitch,MaxPitch=sound.m_maxPitch,MinDelay=sound.m_minDelay,MaxDelay=sound.m_maxDelay});
                }
            }
            return result.ToArray();
        }
        private static bool Finite(float v)=>!float.IsNaN(v)&&!float.IsInfinity(v);
        private void Failure(Exception ex)
        {
            string message=ex.GetType().Name+": "+ex.Message;if(lastFailure==message)return;lastFailure=message;
            log?.Invoke("FALSE_VOWS_CABINET_AUDIO_WAITING: "+message+"; sound retries on later accepted use; quest interaction retained.");
        }
        private void OnDisable(){foreach(var source in voices)if(source)source.Stop();}
        private void OnDestroy(){foreach(var source in voices)if(source)source.Stop();if(unlock)Object.Destroy(unlock);unlock=null;opening=closing=null;}
    }
}
