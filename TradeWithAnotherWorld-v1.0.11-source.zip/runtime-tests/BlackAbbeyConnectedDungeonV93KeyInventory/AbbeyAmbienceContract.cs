using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlackAbbeySixRooms
{
    [Serializable] internal sealed class AbbeyAmbienceManifest
    {
        public int schemaVersion;
        public string sourcePackageSha256;
        public AbbeyAmbienceClip[] clips;
    }
    [Serializable] internal sealed class AbbeyAmbienceClip
    {
        public string id, file, sha256, family;
        public int sampleRate, channels, frames;
        public long bytes;
        public float gain;
    }

    // Shared by the local runtime and offline tests; reading metadata performs no disk I/O.
    internal static class AbbeyAmbienceCatalog
    {
        internal const int MaxManifestBytes = 64 * 1024;
        internal const int MaxFileBytes = 8 * 1024 * 1024;
        internal const int MaxFrames = 48000 * 64;
        internal const long MaxDecodedBytes = 80L * 1024 * 1024;
        static readonly Dictionary<string, string> Approved = new Dictionary<string, string>(StringComparer.Ordinal)
        {
            ["abbey_sparse_air_loop"] = "bed", ["bell_shaft_sparse_draft_loop"] = "shaft",
            ["distant_dark_chant_a"] = "chant", ["distant_dark_chant_b"] = "chant", ["distant_dark_chant_c"] = "chant",
            ["ominous_bell_cathedral_01"] = "bell", ["ominous_bell_distant_02"] = "bell", ["ominous_bell_cracked_03"] = "bell",
            ["ominous_bell_funeral_04"] = "bell", ["ominous_bell_double_05"] = "bell", ["ominous_bell_corrupted_06"] = "bell",
            ["old_timber_creak_01"] = "wood", ["old_timber_creak_02"] = "wood",
            ["vault_water_drip_01"] = "water", ["vault_water_drip_02"] = "water",
            ["strained_chain_01"] = "chain", ["strained_chain_02"] = "chain",
            ["mortar_fall_01"] = "mortar", ["mortar_fall_02"] = "mortar"
        };
        static readonly UTF8Encoding Utf8 = new UTF8Encoding(false, true);

        internal static AbbeyAmbienceManifest Read(string json)
        {
            if (json == null || json.Length > MaxManifestBytes || Utf8.GetByteCount(json) > MaxManifestBytes)
                throw new InvalidDataException("Ambience manifest is missing or exceeds64KiB.");
            JObject root;
            using (var text = new StringReader(json))
            using (var reader = new JsonTextReader(text) { MaxDepth = 8, DateParseHandling = DateParseHandling.None })
            {
                root = JObject.Load(reader, new JsonLoadSettings { DuplicatePropertyNameHandling = DuplicatePropertyNameHandling.Error });
                if (reader.Read()) throw new InvalidDataException("Ambience manifest has trailing content.");
            }
            Fields(root, "schemaVersion", "sourcePackageSha256", "clips");
            if (Integer(root["schemaVersion"], 1, 1) != 1 || !Hash(String(root["sourcePackageSha256"])))
                throw new InvalidDataException("Unsupported ambience schema or source package hash.");
            var entries = root["clips"] as JArray;
            if (entries == null || entries.Count != Approved.Count) throw new InvalidDataException("Ambience requires the exact19 approved clips.");
            var manifest = new AbbeyAmbienceManifest { schemaVersion = 1, sourcePackageSha256 = (string)root["sourcePackageSha256"], clips = new AbbeyAmbienceClip[entries.Count] };
            var ids = new HashSet<string>(StringComparer.Ordinal);
            long decodedBytes = 0;
            for (int i = 0; i < entries.Count; i++)
            {
                var item = entries[i] as JObject;
                Fields(item, "id", "file", "sha256", "family", "sampleRate", "channels", "frames", "bytes", "gain");
                string id = String(item["id"]), file = String(item["file"]), family = String(item["family"]), hash = String(item["sha256"]);
                if (!Approved.TryGetValue(id, out string expectedFamily) || !ids.Add(id) || family != expectedFamily || file != "wav/" + id + ".wav" || !Hash(hash))
                    throw new InvalidDataException("Ambience clip identity, family, path or hash differs from the approved bank.");
                int frames = (int)Integer(item["frames"], 1, MaxFrames);
                long bytes = Integer(item["bytes"], 44L + frames * 2L, MaxFileBytes);
                float gain = Number(item["gain"]);
                if (gain <= 0 || gain > 1) throw new InvalidDataException("Ambience gain is outside(0,1].");
                var clip = new AbbeyAmbienceClip { id = id, file = file, sha256 = hash, family = family, frames = frames,
                    sampleRate = (int)Integer(item["sampleRate"], 48000, 48000), channels = (int)Integer(item["channels"], 1, 1), bytes = bytes, gain = gain };
                decodedBytes += frames * 4L;
                if (decodedBytes > MaxDecodedBytes) throw new InvalidDataException("Ambience exceeds its80MiB decoded-sample budget.");
                manifest.clips[i] = clip;
            }
            return manifest;
        }

        internal static string ValidatePath(string ambiencePath, string file)
        {
            if (string.IsNullOrWhiteSpace(ambiencePath) || !Path.IsPathRooted(ambiencePath) || string.IsNullOrEmpty(file) ||
                !Approved.Keys.Any(id => file == "wav/" + id + ".wav"))
                throw new InvalidDataException("Ambience requires an absolute bank directory and an approved relative WAV path.");
            string directory = Path.GetFullPath(ambiencePath), prefix = directory.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string full = Path.GetFullPath(Path.Combine(directory, file.Replace('/', Path.DirectorySeparatorChar)));
            if (!full.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Ambience path escapes its bank.");
            string wavDirectory = Path.Combine(directory, "wav");
            if ((Directory.Exists(wavDirectory) && (File.GetAttributes(wavDirectory) & FileAttributes.ReparsePoint) != 0) ||
                (File.Exists(full) && (File.GetAttributes(full) & FileAttributes.ReparsePoint) != 0))
                throw new InvalidDataException("Ambience WAV dependencies cannot be filesystem links.");
            return full;
        }
        internal static void ValidateClipBytes(AbbeyAmbienceClip clip, byte[] bytes)
        {
            if (clip == null || bytes == null || bytes.LongLength != clip.bytes || bytes.Length > MaxFileBytes || !Hash(clip.sha256))
                throw new InvalidDataException("Ambience WAV length differs from its manifest.");
            using (var sha = SHA256.Create())
            {
                string actual = BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
                if (!string.Equals(actual, clip.sha256, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Ambience WAV hash differs from its approved manifest.");
            }
        }
        internal static void ValidateDecoded(AbbeyAmbienceClip clip, PcmWaveData data)
        {
            if (clip == null || data == null || data.SampleRate != clip.sampleRate || data.Channels != clip.channels || data.Frames != clip.frames ||
                data.Samples == null || data.Samples.LongLength != (long)clip.frames * clip.channels)
                throw new InvalidDataException("Decoded ambience differs from its manifest.");
        }
        internal static void ValidatePathsAndFiles(string ambiencePath, AbbeyAmbienceManifest manifest)
        {
            if (manifest == null || manifest.clips == null) throw new InvalidDataException("Missing ambience manifest.");
            foreach (var clip in manifest.clips)
            {
                string path = ValidatePath(ambiencePath, clip.file);
                if (new FileInfo(path).Length != clip.bytes) throw new InvalidDataException("Ambience file length differs from its manifest.");
                ValidateClipBytes(clip, File.ReadAllBytes(path));
            }
        }
        static bool Hash(string text) => text != null && text.Length == 64 && text.All(c => c >= '0' && c <= '9' || c >= 'a' && c <= 'f' || c >= 'A' && c <= 'F');
        static string String(JToken token)
        {
            if (token?.Type != JTokenType.String) throw new InvalidDataException("Ambience text field has the wrong type.");
            return (string)token;
        }
        static long Integer(JToken token, long minimum, long maximum)
        {
            if (token?.Type != JTokenType.Integer || !long.TryParse(token.ToString(Formatting.None), NumberStyles.Integer, CultureInfo.InvariantCulture, out long value) || value < minimum || value > maximum)
                throw new InvalidDataException("Ambience integer is outside its declared format or memory bounds.");
            return value;
        }
        static float Number(JToken token)
        {
            if (token == null || token.Type != JTokenType.Integer && token.Type != JTokenType.Float ||
                !float.TryParse(token.ToString(Formatting.None), NumberStyles.Float, CultureInfo.InvariantCulture, out float value) || float.IsNaN(value) || float.IsInfinity(value))
                throw new InvalidDataException("Ambience gain must be a finite number.");
            return value;
        }
        static void Fields(JObject item, params string[] fields)
        {
            if (item == null || item.Count != fields.Length || item.Properties().Any(p => !fields.Contains(p.Name, StringComparer.Ordinal)))
                throw new InvalidDataException("Ambience manifest fields do not match its schema.");
        }
    }
}
