using System;

namespace BlackAbbeySixRooms
{
    // A ground marking follows the actual first surface, including a stone's
    // worn bevel. This is not an actor walkability/slope decision. A single
    // MeshCollider query need not return its flatter backing behind that bevel.
    internal static class WardingWardSurface
    {
        internal const float Reach=.22f;
        internal static bool Accept(float normalY,float surfaceY,float authoredY)
        {
            if(float.IsNaN(normalY)||float.IsInfinity(normalY)||float.IsNaN(surfaceY)||float.IsInfinity(surfaceY)||
               float.IsNaN(authoredY)||float.IsInfinity(authoredY))return false;
            return normalY>=.001f&&normalY<=1.001f&&Math.Abs(surfaceY-authoredY)<=Reach;
        }
    }
}
