using System;
using System.Collections.Generic;

namespace BlackAbbeySixRooms
{
    internal static class RuntimeRoomMaintenance
    {
        // Collect before removing so dictionary iteration and disposal order
        // remain unchanged. The caller retains this buffer between frames.
        internal static void CollectMissing<T>(Dictionary<string, T> rooms, List<string> missing, Predicate<T> alive)
        {
            missing.Clear();
            foreach (var pair in rooms)
                if (!alive(pair.Value)) missing.Add(pair.Key);
        }
    }
}
