using System;

namespace BlackAbbeySixRooms
{
    // Rank actual doorway anchors by shortest graph distance from the entry.
    // Within equal-distance groups, a seeded weighted permutation gives a
    // modest preference to another floor. Every nearer option remains in the
    // result for use if both direct placement and a route from farther doors
    // cannot fit. Geometry and the shared room allowance are checked elsewhere.
    internal static class LegacyBossPlacementPolicy
    {
        internal const double DifferentLevelWeight = 1.20;
        private sealed class Choice
        {
            internal int Index, Distance;
            internal double Key;
        }

        internal static int[] Order(int count, Func<int, int> distance, Func<int, bool> differentLevel, Random random)
        {
            if (count < 0) throw new ArgumentOutOfRangeException(nameof(count));
            if (distance == null) throw new ArgumentNullException(nameof(distance));
            if (differentLevel == null) throw new ArgumentNullException(nameof(differentLevel));
            if (random == null) throw new ArgumentNullException(nameof(random));
            var choices = new Choice[count];
            for (int i = 0; i < count; i++)
            {
                int depth = distance(i);
                if (depth < 0) throw new ArgumentException("A boss approach anchor must be reachable from the entry.");
                double weight = differentLevel(i) ? DifferentLevelWeight : 1.0;
                choices[i] = new Choice { Index = i, Distance = depth, Key = -Math.Log(1.0 - random.NextDouble()) / weight };
            }
            Array.Sort(choices, (a, b) =>
            {
                int order = b.Distance.CompareTo(a.Distance);
                if (order != 0) return order;
                order = a.Key.CompareTo(b.Key);
                return order != 0 ? order : a.Index.CompareTo(b.Index);
            });
            var output = new int[count];
            for (int i = 0; i < count; i++) output[i] = choices[i].Index;
            return output;
        }
    }
}
