using System;
using System.Linq;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        // Called only after confirmed ordinary-gate/post-boss-bell travel.
        // Keep both items on every pre-boss exit. The legacy return-pose
        // parameters remain private ABI compatibility only; no shelf transfer.
        private bool CleanupFalseVowsExit(Player player, string runId, Vector3 keyReturnPosition, Quaternion keyReturnRotation)
        {
            if (!player || player != Player.m_localPlayer || falseVows == null || !persistentRunBound || falseVows.RunId != runId ||
                persistentRun == null || persistentRun.runId != runId || persistentRun.worldKey != WorldKey()) return true;
            // A pending retry must obey the same boss/exit policy as its first
            // attempt. Death, logout and emergency return never grant this flag.
            if (!persistentRun.bossCompleted || RunContains(player.transform.position) ||
                !persistentRun.participants.Any(p => p.playerId == player.GetPlayerID().ToString() && p.exitedProperly)) return true;
            if (!ZNet.instance || !ZNet.instance.IsServer() || retiringPersistentRun) return false;
            if (dungeonPlan?.Mode != "natural" || !gridOrigin.HasValue) return false;
            // The boss-completed and proper-exit checkpoint must succeed before
            // retiring receipts or touching the native carried items. A failed
            // checkpoint keeps them and enters the existing bounded retry.
            if (!SavePersistentRun(true)) return false;
            if (!persistentRun.bossCompleted) return true;
            bool success = true;
            string keyToken = falseVows.Token(FalseVowsState.Key);
            var keys = player.GetInventory().GetAllItems().Where(i => FalseVowsItems.Matches(i, FalseVowsState.Key, runId, keyToken)).ToArray();
            if (keys.Length > 0)
            {
                // After the defeated-boss exit, retire the current-run claim
                // before removing the key. Never create a drop in a retiring run.
                var retired = falseVows.AcknowledgeDelivery(keyToken, CommitFalseVows);
                if (retired == FalseVowsResult.Applied || retired == FalseVowsResult.AlreadyResolved)
                {
                    falseVowsFailedLiveDeliveries.Remove(keyToken);
                    foreach (var item in keys)
                        if (!FalseVowsItems.RemoveExact(player, FalseVowsState.Key, runId, keyToken, item)) success = false;
                }
                else success = false;
            }
            string letterToken = falseVows.Token(FalseVowsState.Letter);
            var letters = player.GetInventory().GetAllItems().Where(i => FalseVowsItems.Matches(i, FalseVowsState.Letter, runId, letterToken)).ToArray();
            if (letters.Length > 0)
            {
                // A confirmed defeated-boss exit retires this letter's claim. This is NOT an
                // acknowledgement inferred from native absence/live saves.
                // Collected remains set, so source/recovery cannot reissue it.
                var retired = falseVows.AcknowledgeDelivery(letterToken, CommitFalseVows);
                if (retired == FalseVowsResult.Applied || retired == FalseVowsResult.AlreadyResolved)
                {
                    falseVowsFailedLiveDeliveries.Remove(letterToken);
                    foreach (var item in letters)
                        if (!FalseVowsItems.RemoveExact(player, FalseVowsState.Letter, runId, letterToken, item)) success = false;
                }
                else success = false;
            }
            falseVowsPresence?.Invalidate(); RefreshFalseVowsRooms();
            Logger.LogInfo(success ? "FALSE_VOWS_EXIT_CLEANUP: defeated-boss exit; current-run carried key and letter retired." :
                "FALSE_VOWS_EXIT_CLEANUP_PENDING: a native removal or durable retirement failed; retained items need a retry.");
            return success;
        }
    }
}
