using System;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        private bool encounterSetupReady;
        private bool WardingControllersRequired => wardingSaved != null && wardingSaved.sources.Count > 0;
        private bool ResidentEncountersReady() => DungeonEntrySetupPolicy.CanUseResident(dungeonPlan?.Mode == "natural" && persistentRunBound,
            encounterSetupReady,actorGeometryReady,monkRun?.Ready==true,WardingControllersRequired,wardingActors!=null);
        private void FailedEncounterSetup()
        {
            encounterSetupReady=false;actorGeometryReady=false;
            // Preserve owned UIDs, health and consumed/dead slots. Cleanup
            // failure must not prevent the existing surface-return path.
            try { ParkDungeonActors(); } catch(Exception error) { Logger.LogWarning("Encounter parking remains pending: "+error.Message); }
            try { SuspendWardingSpawners(); } catch(Exception error) { Logger.LogWarning("Spawner suspension remains pending: "+error.Message); }
            try { DisposeMonkRun(); } catch(Exception error) { Logger.LogWarning("Monk suspension remains pending: "+error.Message); }
        }
        private void InitializePlacedEncounters(DungeonPlan plan)
        {
            DungeonEntrySetupPolicy.Initialize(
                ()=>{encounterSetupReady=false;actorGeometryReady=true;},
                ()=>ReconcileMonkRun(plan),()=>ReconcileWardingActors(),
                ()=>{ObserveRunPlayers();return SavePersistentRun(true);},
                ()=>{
                    if(monkRun?.Ready!=true||WardingControllersRequired&&wardingActors==null)
                        throw new InvalidOperationException("Required encounter controllers were not initialized.");
                    encounterSetupReady=true;
                },FailedEncounterSetup);
        }
    }
}
