using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using Jotunn.Managers;
using UnityEngine;
using UnityEngine.Audio;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // Client-owned emitters only. Loaded room roots are placement data, never
    // authority that a player has entered the abbey. The plugin supplies that
    // authority every Tick after its character/world/return guards succeed.
    internal sealed class AbbeyAmbienceRuntime : MonoBehaviour
    {
        private sealed class Voice
        {
            internal AudioSource Source;
            internal AudioLowPassFilter LowPass;
            internal LoadedRoom Room;
            internal AbbeyAmbienceClip Record;
            internal int FixtureIndex = -1;
            internal float BellLocalPresentation;
            internal bool DistantBellLane;
            internal float Fade = 1;
            internal bool Leaving;
        }

        private sealed class Cue
        {
            internal LoadedRoom Room;
            internal AbbeyAmbienceClip Record;
            internal Vector3 Position;
            internal int FixtureIndex = -1;
            internal bool DistantBell;
            internal double Expires;
        }

        // Bells have a persistent, loaded-fixture clock. Other event families
        // retain their existing room policy, interval ranges and chance rolls.
        private static readonly string[] EventFamilies = { "chant", "wood", "chain", "water", "mortar" };
        private const string R04FixtureSource = "6bdaa821b318ecee6ae959908273551fd5ffca860126267ba31e719b1fcef9da";
        private const string R08FixtureSource = "bdbeef3956ab6e9d51e2d03c283874d83b869400280cfc74e28902f6ecebaa41";
        // The constant custom curve has no distance cutoff. Bell position still
        // supplies direction, while room-aware gain/filtering supplies distance.
        private static readonly AnimationCurve BellRolloff = AnimationCurve.Linear(0, AbbeyAmbienceBalance.BellRolloffFloor, 1, AbbeyAmbienceBalance.BellRolloffFloor);
        private const float BellPresentationFadeSeconds = .6f;
        // Exact bell body centres from R08 detail-v8 fixtures.json, converted
        // from authoring XYZ to the runtime's XZY metre axes. These are retained
        // by runtime V4. Chain contacts are just above these real suspensions.
        private static readonly Vector3[] R08Bells = {
            new Vector3(-1.200f, 11.332f, -1.802f), new Vector3(-.001f, 5.731f, -1.798f),
            new Vector3(1.196f, -3.824f, -1.799f), new Vector3(-1.201f, 8.409f, -.600f),
            new Vector3(-.002f, 2.775f, -.600f), new Vector3(1.200f, -8.468f, -.600f),
            new Vector3(-1.199f, -1.513f, .601f), new Vector3(0, 10.098f, .599f),
            new Vector3(1.229f, -6.213f, .602f), new Vector3(-1.199f, -10.601f, 1.799f),
            new Vector3(.001f, .653f, 1.799f), new Vector3(1.190f, -13.357f, 1.803f),
            new Vector3(-2.100f, 4.088f, -1.200f), new Vector3(-2.099f, -2.557f, .001f),
            new Vector3(-2.106f, -9.290f, 1.195f), new Vector3(2.100f, 7.066f, -1.199f),
            new Vector3(2.100f, -.013f, .001f), new Vector3(2.105f, -11.990f, 1.203f)
        };

        private readonly Dictionary<string, AudioClip> clips = new Dictionary<string, AudioClip>(StringComparer.Ordinal);
        private readonly Dictionary<string, List<AbbeyAmbienceClip>> families = new Dictionary<string, List<AbbeyAmbienceClip>>(StringComparer.Ordinal);
        private readonly Dictionary<string, double> due = new Dictionary<string, double>(StringComparer.Ordinal);
        private readonly HashSet<string> requested = new HashSet<string>(StringComparer.Ordinal);
        private readonly HashSet<string> failed = new HashSet<string>(StringComparer.Ordinal);
        private readonly Queue<AbbeyAmbienceClip> loadQueue = new Queue<AbbeyAmbienceClip>();
        private readonly Dictionary<LoadedRoom, Vector3[]> waterPoints = new Dictionary<LoadedRoom, Vector3[]>();
        private readonly System.Random random = new System.Random();
        private readonly BellOpportunityClock localBellClock = new BellOpportunityClock();
        private readonly BellOpportunityClock distantBellClock = new BellOpportunityClock();
        private AudioSource air, shaft;
        private AudioMixerGroup borrowedMixer;
        private readonly Voice[] voices = { new Voice(), new Voice() };
        private AbbeyAmbienceClip airRecord, shaftRecord;
        private LoadedRoom currentRoom, bellListenerRoom;
        private Vector3 lastListener;
        private Coroutine loader;
        private Cue pending, pendingLocalBell, pendingDistantBell;
        private Action<string> log;
        private string ambiencePath;
        private bool ready, configured = true, inside, disposed, mixerChecked, mixerPendingLogged, localBellAvailable, distantBellAvailable;
        private float volume = 1, envelope, shaftEnvelope;
        private double lastTick, nextEvent, nextMixerProbe;
        private int played, loadFailures;
        private bool outputStatusLogged;
        private static double Now => Time.realtimeSinceStartup;

        internal void Initialize(string dataPath, Action<string> write)
        {
            DisposeAudio(); disposed = false; log = write;
            try
            {
                ambiencePath = Path.Combine(Path.GetFullPath(dataPath), "ambience");
                string path = Path.Combine(ambiencePath, "manifest.json");
                var file = new FileInfo(path);
                if (!file.Exists || file.Length < 2 || file.Length > AbbeyAmbienceCatalog.MaxManifestBytes)
                    throw new InvalidDataException("Ambience manifest is missing or outside its metadata budget.");
                // Metadata only: no WAV reading, decoding or AudioClip creation
                // is done during dungeon construction/entry.
                var manifest = AbbeyAmbienceCatalog.Read(File.ReadAllText(path));
                foreach (var record in manifest.clips)
                {
                    if (!families.TryGetValue(record.family, out var list))
                        families.Add(record.family, list = new List<AbbeyAmbienceClip>());
                    list.Add(record);
                    if (record.id == "abbey_sparse_air_loop") airRecord = record;
                    if (record.id == "bell_shaft_sparse_draft_loop") shaftRecord = record;
                }
                if (airRecord == null) throw new InvalidDataException("Approved sparse air bed is absent.");
                localBellClock.Reset(AbbeyAmbienceBalance.FirstBellDelay(random.NextDouble()));
                distantBellClock.Reset(AbbeyAmbienceBalance.FirstDistantBellDelay(random.NextDouble()));
                ready = true;
                Write("BA_AMBIENCE_READY: approved V3 manifest; lazy client cache; maximum4 owned sources; air x2, shaft x1.4, bell x1.25; local bell first12-22/repeat60-105, distant bell first20-35/repeat80-130 eligible seconds; real fixed-tone fixtures across every dungeon room; own-room and other-room bells have independent opportunities; no whispers; native SFX output is borrowed read-only. Game mixing/listening remains unverified.");
            }
            catch (Exception ex) { ready = false; Write("BA_AMBIENCE_UNAVAILABLE: " + ex.Message + "; room travel remains available."); }
        }

        internal void Configure(bool enabled, float gain)
        {
            configured = enabled;
            volume = float.IsNaN(gain) || float.IsInfinity(gain) ? 1 : Mathf.Clamp01(gain);
            if (!configured || volume == 0) Suspend(true);
        }

        internal void Tick(bool eligible, LoadedRoom[] allRooms, LoadedRoom containing, Vector3 listener, float deltaTime)
        {
            if (!ready || disposed || !configured || volume == 0 || !isActiveAndEnabled || !eligible ||
                containing == null || !containing.Root || !containing.Root.activeInHierarchy ||
                containing.Manifest == null || allRooms == null || Array.IndexOf(allRooms, containing) < 0)
            { Suspend(); return; }
            try
            {
                lastTick = Now; lastListener = listener;
                EnsureSources();
                if (mixerChecked && !borrowedMixer)
                {
                    // A destroyed/replaced native audio owner must not leave
                    // these sources silently falling back to the master output.
                    mixerChecked = false; nextMixerProbe = 0; envelope = 0;
                    air.Stop(); shaft.Stop();
                    foreach (var voice in voices) StopVoice(voice);
                }
                if (!inside)
                {
                    inside = true; envelope = 0; outputStatusLogged = false; currentRoom = containing;
                    ResetSchedule(containing.Manifest.roomId, lastTick);
                    QueueClip(airRecord);
                }
                else if (!ReferenceEquals(currentRoom, containing))
                {
                    currentRoom = containing;
                    // Reclassify queued opportunities for the new room while
                    // retaining both due clocks. Already playing bells keep
                    // their exact source/clip and ease to the new presentation.
                    pending = pendingLocalBell = pendingDistantBell = null;
                    // Distant chant/bell/Foley tails keep their source location
                    // and normal 3D falloff through a doorway. Water alone must
                    // fade promptly when entering a room that forbids it.
                    foreach (var voice in voices)
                        if (voice.Record?.family == "water" && !AbbeyAmbiencePolicy.AllowsEvent(containing.Manifest.roomId, "water")) voice.Leaving = true;
                }
                // Integration uses activeRoom as a safe containment owner while
                // in a real connecting passage. A passage is still distant
                // from the bell: only actual room containment gives local tone.
                var actualBellRoom = HasBellFixture(containing) && ListenerInsideRoom(containing, listener) ? containing : null;
                if (!ReferenceEquals(bellListenerRoom, actualBellRoom)) pendingLocalBell = pendingDistantBell = null;
                bellListenerRoom = actualBellRoom;
                // The optional second loop exists once and is eligible only in
                // the actual R08 shaft, never because that room is loaded.
                bool hasShaft = HasShaftFixture(containing);
                if (hasShaft) QueueClip(shaftRecord);
                if (!mixerChecked && lastTick >= nextMixerProbe) BorrowMixer();
                if (mixerChecked) SetLoop(air, airRecord);
                if (hasShaft && shaft)
                {
                    shaft.transform.position = containing.Root.transform.TransformPoint(new Vector3(0, 5.4f, 0));
                    if (mixerChecked) SetLoop(shaft, shaftRecord);
                }
                localBellAvailable = TryBellFixture(bellListenerRoom, listener, out var localPosition, out var localFixture);
                distantBellAvailable = TryNearestDistantBell(allRooms, bellListenerRoom, listener, out var distantRoom, out var distantPosition, out var distantFixture);
                localBellClock.Advance(deltaTime, inside && mixerChecked, localBellAvailable);
                distantBellClock.Advance(deltaTime, inside && mixerChecked, distantBellAvailable);
                // Either due bell lane wins over a newly queued chant. A chant
                // already playing keeps its tail; both opportunities stay due.
                bool bellWaiting = localBellClock.IsDue && localBellAvailable || distantBellClock.IsDue && distantBellAvailable;
                if (bellWaiting && pending?.Record.family == "chant") pending = null;
                if (pendingLocalBell == null && localBellClock.IsDue && localBellAvailable)
                    pendingLocalBell = ScheduleBell(bellListenerRoom, localPosition, localFixture, false, lastTick);
                if (pendingDistantBell == null && distantBellClock.IsDue && distantBellAvailable)
                    pendingDistantBell = ScheduleBell(distantRoom, distantPosition, distantFixture, true, lastTick);
                if (mixerChecked)
                {
                    // Both lanes may use the existing two pooled event voices.
                    // Their long independent clocks, not the Foley cooldown,
                    // determine whether the two real bells can overlap.
                    if (pendingLocalBell != null && TryPlayCue(pendingLocalBell, allRooms, listener, lastTick)) pendingLocalBell = null;
                    if (pendingDistantBell != null && TryPlayCue(pendingDistantBell, allRooms, listener, lastTick)) pendingDistantBell = null;
                    if (pending != null && TryPlayCue(pending, allRooms, listener, lastTick)) pending = null;
                }
                if (pending == null && lastTick >= nextEvent)
                    ScheduleDue(containing, listener, lastTick, bellWaiting);
            }
            catch (Exception ex)
            {
                // Optional audio cannot invalidate a successful load/teleport.
                Suspend(true); ready = false;
                Write("BA_AMBIENCE_DISABLED: " + ex.GetType().Name + ": " + ex.Message + "; no room or return state changed.");
            }
        }

        private void ResetSchedule(string roomId, double now)
        {
            due.Clear();
            foreach (string family in EventFamilies)
                due[family] = now + AbbeyAmbiencePolicy.NextIntervalSeconds(family, random.NextDouble());
            due["chant"] = now + 30 + random.NextDouble() * 25;
            var small = new List<string>();
            foreach (string family in new[] { "wood", "chain", "water", "mortar" })
                if (AbbeyAmbiencePolicy.AllowsEvent(roomId, family)) small.Add(family);
            if (small.Count > 0) due[small[random.Next(small.Count)]] = now + 15 + random.NextDouble() * 15;
            nextEvent = now + 10;
        }

        private void ScheduleDue(LoadedRoom room, Vector3 listener, double now, bool bellWaiting)
        {
            string family = null; double earliest = double.MaxValue;
            foreach (string candidate in EventFamilies)
            {
                if (candidate == "chant" && bellWaiting) continue;
                if (due.TryGetValue(candidate, out var at) && at <= now && at < earliest) { family = candidate; earliest = at; }
            }
            if (family == null) return;
            due[family] = now + AbbeyAmbiencePolicy.NextIntervalSeconds(family, random.NextDouble());
            // A due timer is an opportunity, not a guaranteed dungeon event.
            if (!AbbeyAmbiencePolicy.AllowsEvent(room.Manifest.roomId, family) || random.NextDouble() > (family == "chant" ? .65 : .75)) return;
            if (family == "chant" && VocalActive()) return;
            if (!families.TryGetValue(family, out var candidates) || candidates.Count == 0) return;
            var record = candidates[random.Next(candidates.Count)];
            if (failed.Contains(record.id) || !TryEmitter(room, family, listener, out var position)) return;
            pending = new Cue { Room = room, Record = record, Position = position, Expires = now + 8 };
            QueueClip(record);
        }

        private Cue ScheduleBell(LoadedRoom room, Vector3 position, int fixtureIndex, bool distant, double now)
        {
            var clock = distant ? distantBellClock : localBellClock;
            if (!clock.IsDue || ChantActive() || !families.TryGetValue("bell", out var candidates)) return null;
            string signature = AbbeyAmbienceBalance.BellClipId(room.Manifest.roomId, fixtureIndex);
            foreach (var candidate in candidates)
            {
                if (candidate.id != signature || failed.Contains(candidate.id)) continue;
                QueueClip(candidate);
                return new Cue { Room = room, Record = candidate, Position = position, FixtureIndex = fixtureIndex, DistantBell = distant, Expires = now + 8 };
            }
            return null;
        }

        // True means this specific cue played or became invalid. False keeps
        // it pending; neither clock is ever spent by a failed/busy attempt.
        private bool TryPlayCue(Cue cue, LoadedRoom[] allRooms, Vector3 listener, double now)
        {
            string family = cue.Record.family;
            bool bell = family == "bell";
            // Expiring/loading/failing a bell never spends its clock. It can
            // requeue at the nearest eligible fixture on a subsequent tick.
            if (now > cue.Expires || failed.Contains(cue.Record.id) ||
                (bell ? !BellCueValid(cue, allRooms) ||
                    (cue.DistantBell ? ReferenceEquals(cue.Room, bellListenerRoom) : !ReferenceEquals(cue.Room, bellListenerRoom)) : !ReferenceEquals(cue.Room, currentRoom))) return true;
            if (!clips.TryGetValue(cue.Record.id, out var clip) || !clip || !bell && now < nextEvent) return false;
            if (!bell && !AbbeyAmbiencePolicy.AllowsEvent(currentRoom.Manifest.roomId, family)) return true;
            if (bell && (ChantActive() || BellFixtureActive(cue.Room, cue.FixtureIndex))) return false;
            if (family == "chant" && VocalActive()) return true;
            foreach (var voice in voices)
            {
                if (!voice.Source || voice.Source.isPlaying) continue;
                voice.Room = cue.Room; voice.Record = cue.Record; voice.Leaving = false; voice.Fade = 1;
                voice.FixtureIndex = cue.FixtureIndex; voice.DistantBellLane = cue.DistantBell;
                var source = voice.Source;
                source.transform.position = cue.Position; source.clip = clip; source.pitch = 1;
                source.minDistance = bell ? AbbeyAmbienceBalance.BellMinDistance : family == "chant" ? 3 : 1.8f;
                source.maxDistance = bell ? AbbeyAmbienceBalance.BellMaxDistance : family == "chant" ? 32 : family == "water" ? 12 : 16;
                source.rolloffMode = bell ? AudioRolloffMode.Custom : AudioRolloffMode.Linear;
                if (bell) source.SetCustomCurve(AudioSourceCurveType.CustomRolloff, BellRolloff);
                voice.LowPass.enabled = bell;
                voice.BellLocalPresentation = bell && ReferenceEquals(voice.Room, bellListenerRoom) ? 1 : 0;
                if (bell) SetBellPresentation(voice);
                else source.spatialBlend = 1;
                source.volume = volume * envelope * voice.Record.gain * (bell ? AbbeyAmbienceBalance.BellGain * BellRoomGain(voice) : 1);
                source.Play();
                // Play is void; isPlaying confirms that Unity actually accepted
                // this cue before the persistent bell opportunity is committed.
                if (bell && !source.isPlaying) { StopVoice(voice); return false; }
                ++played; nextEvent = now + 10;
                if (bell)
                {
                    var clock = cue.DistantBell ? distantBellClock : localBellClock;
                    clock.MarkPlayed(cue.DistantBell ? AbbeyAmbienceBalance.NextDistantBellDelay(random.NextDouble()) : AbbeyAmbienceBalance.NextBellDelay(random.NextDouble()));
                    Write("BA_AMBIENCE_BELL_PLAYED: lane=" + (cue.DistantBell ? "distant" : "local") + "; cue=" + cue.Record.id + "; emitter=" + cue.Room.Manifest.roomId +
                        "; fixtureIndex=" + cue.FixtureIndex + "; fixedSignature=" + cue.Record.id + "; fixture=" + cue.Position.ToString("F2") +
                        "; presentation=" + (ReferenceEquals(cue.Room, bellListenerRoom) ? "local" : "distant/muffled") + "; distance=" + Vector3.Distance(cue.Position, listener).ToString("F1") +
                        "m; laneBellCount=" + clock.PlayedCount + "; nextEligibleSeconds=" + clock.Remaining.ToString("F1") +
                        "; source.Play accepted; perception remains unverified.");
                }
                return true;
            }
            return false;
        }

        private bool TryNearestDistantBell(LoadedRoom[] allRooms, LoadedRoom containing, Vector3 listener, out LoadedRoom room, out Vector3 world, out int fixtureIndex)
        {
            room = null; world = Vector3.zero; fixtureIndex = -1;
            // The distant lane always excludes the containing bell ROOM. Its
            // own fixture has a separate lane, so both rooms can still toll.
            float nearest = float.MaxValue;
            foreach (var candidate in allRooms)
            {
                if (ReferenceEquals(candidate, containing)) continue;
                if (!TryBellFixture(candidate, listener, out var position, out var index)) continue;
                float distance = (position - listener).sqrMagnitude;
                if (distance < nearest) { nearest = distance; room = candidate; world = position; fixtureIndex = index; }
            }
            return room != null;
        }

        private static bool TryBellFixture(LoadedRoom room, Vector3 listener, out Vector3 world, out int fixtureIndex)
        {
            world = Vector3.zero; fixtureIndex = -1;
            if (!HasBellFixture(room)) return false;
            var root = room.Root.transform;
            var rebuilt=KitArchitectureProfile.Find(room.Manifest.sourceSha256,room.Record.manifestSha256);
            if(rebuilt!=null)
            {
                float best=float.MaxValue;
                for(int i=0;i<rebuilt.bellFixturePositions.Length;i++)
                {
                    var p=rebuilt.bellFixturePositions[i];var at=root.TransformPoint(new Vector3(p[0],p[1],p[2]));
                    float distance=(at-listener).sqrMagnitude;if(distance<best){best=distance;world=at;fixtureIndex=i;}
                }
                return fixtureIndex>=0;
            }
            if (room.Manifest.roomId == "R04")
            {
                // Canonical shell centre, unchanged from the source-bound V21
                // fixture datum. R04 always uses the cathedral toll.
                fixtureIndex = 0; world = root.TransformPoint(new Vector3(0, 4.65f, 12)); return true;
            }
            float nearest = float.MaxValue;
            for (int i = 0; i < R08Bells.Length; ++i)
            {
                var position = root.TransformPoint(R08Bells[i]);
                float distance = (position - listener).sqrMagnitude;
                if (distance < nearest) { nearest = distance; world = position; fixtureIndex = i; }
            }
            return fixtureIndex >= 0;
        }

        private static bool HasBellFixture(LoadedRoom room)
        {
            if(room!=null&&room.Root&&room.Root.activeInHierarchy&&room.Manifest!=null&&
                KitArchitectureProfile.Find(room.Manifest.sourceSha256,room.Record.manifestSha256) is KitRoomBinding rebuilt)
                return (room.Manifest.roomId=="R04"||room.Manifest.roomId=="R08")&&rebuilt.bellFixturePositions?.Length>0;
            return room != null && room.Root && room.Root.activeInHierarchy && room.Manifest != null &&
                (room.Manifest.roomId == "R04" && room.Manifest.sourceSha256 == R04FixtureSource ||
                 room.Manifest.roomId == "R08" && UnrecordedDeadSourceBindings.OriginalStairFixtures(room.Manifest.sourceSha256));
        }

        private static bool HasShaftFixture(LoadedRoom room)=>room?.Manifest?.roomId=="R08"&&
            (KitArchitectureProfile.Find(room.Manifest.sourceSha256,room.Record.manifestSha256)!=null||UnrecordedDeadSourceBindings.OriginalStairFixtures(room.Manifest.sourceSha256));

        private static bool ListenerInsideRoom(LoadedRoom room, Vector3 listener)
        {
            var p = room.Root.transform.InverseTransformPoint(listener);
            var low = room.Manifest.boundsMin; var high = room.Manifest.boundsMax;
            if (low?.Length != 3 || high?.Length != 3 || p.x < low[0] || p.x > high[0] || p.z < low[2] || p.z > high[2] ||
                p.y < low[1] - .2f || p.y > high[1] + .2f) return false;
            var polygon = room.Manifest.floorPolygonXZ ?? room.Manifest.footprint;
            if (polygon == null || polygon.Length < 3) return false;
            bool contained = false;
            for (int i = 0, j = polygon.Length - 1; i < polygon.Length; j = i++)
            {
                var a = polygon[i]; var b = polygon[j];
                if ((a[1] > p.z) != (b[1] > p.z) && p.x < (b[0] - a[0]) * (p.z - a[1]) / (b[1] - a[1]) + a[0]) contained = !contained;
            }
            return contained;
        }

        private static bool BellCueValid(Cue cue, LoadedRoom[] allRooms)
        {
            var room = cue.Room;
            return HasBellFixture(room) && Array.IndexOf(allRooms, room) >= 0 &&
                cue.Record.id == AbbeyAmbienceBalance.BellClipId(room.Manifest.roomId, cue.FixtureIndex);
        }

        private static float BellRoomGain(Voice voice)
            => Mathf.Lerp(AbbeyAmbienceBalance.RoomBellGain(false), AbbeyAmbienceBalance.RoomBellGain(true), voice.BellLocalPresentation);

        private static void SetBellPresentation(Voice voice)
        {
            voice.Source.spatialBlend = Mathf.Lerp(AbbeyAmbienceBalance.RoomBellBlend(false), AbbeyAmbienceBalance.RoomBellBlend(true), voice.BellLocalPresentation);
            voice.LowPass.cutoffFrequency = Mathf.Lerp(AbbeyAmbienceBalance.RoomBellCutoff(false), AbbeyAmbienceBalance.RoomBellCutoff(true), voice.BellLocalPresentation);
        }

        private bool VocalActive()
        {
            foreach (var voice in voices)
                if (voice.Record != null && voice.Source && voice.Source.isPlaying &&
                    (voice.Record.family == "chant" || voice.Record.family == "bell")) return true;
            return false;
        }

        private bool ChantActive()
        {
            foreach (var voice in voices)
                if (voice.Record?.family == "chant" && voice.Source && voice.Source.isPlaying) return true;
            return false;
        }

        private bool BellFixtureActive(LoadedRoom room, int fixtureIndex)
        {
            foreach (var voice in voices)
                if (voice.Record?.family == "bell" && voice.Source && voice.Source.isPlaying &&
                    ReferenceEquals(voice.Room, room) && voice.FixtureIndex == fixtureIndex) return true;
            return false;
        }

        private bool TryEmitter(LoadedRoom room, string family, Vector3 listener, out Vector3 world)
        {
            world = Vector3.zero;
            var root = room.Root.transform;
            var localListener = root.InverseTransformPoint(listener);
            if (family == "chain")
            {
                Vector3 local;
                if(KitArchitectureProfile.Find(room.Manifest.sourceSha256,room.Record.manifestSha256)!=null)
                {
                    if(!TryBellFixture(room,listener,out world,out _))return false;
                    world+=root.up*(room.Manifest.roomId=="R04"?1f:.65f);return true;
                }
                else if (room.Manifest.roomId == "R04" && room.Manifest.sourceSha256 == R04FixtureSource)
                    // R04 canonical bell_revision.py: CX=0,CY=12; shell
                    // mouth/crown Z=3.690..5.392, yoke above the crown.
                    local = new Vector3(0, 5.65f, 12);
                else if (room.Manifest.roomId == "R08" && UnrecordedDeadSourceBindings.OriginalStairFixtures(room.Manifest.sourceSha256))
                {
                    local = R08Bells[0]; float best = float.MaxValue;
                    foreach (var point in R08Bells)
                    {
                        float distance = (point - localListener).sqrMagnitude;
                        if (distance < best) { best = distance; local = point; }
                    }
                    local += Vector3.up * .65f;
                }
                else return false;
                world = root.TransformPoint(local);
            }
            else if (family == "water")
            {
                // Sample the saved, actually loaded water surface. No invented
                // puddles and no water in R02/R07 even during a previous tail.
                if (!room.WaterRenderer) return false;
                if (!waterPoints.TryGetValue(room, out var points))
                {
                    var filter = room.WaterRenderer.GetComponent<MeshFilter>();
                    if (!filter || !filter.sharedMesh) return false;
                    var vertices = filter.sharedMesh.vertices;
                    if (vertices.Length == 0) return false;
                    int count = Math.Min(vertices.Length, 128); points = new Vector3[count];
                    for (int i = 0; i < count; ++i)
                        points[i] = root.InverseTransformPoint(filter.transform.TransformPoint(vertices[(int)((long)i * vertices.Length / count)]));
                    waterPoints.Add(room, points);
                }
                Vector3 point = points[0]; float best = float.MaxValue;
                foreach (var candidate in points)
                {
                    float distance = (candidate - localListener).sqrMagnitude;
                    if (distance < best) { best = distance; point = candidate; }
                }
                world = root.TransformPoint(point + Vector3.up * .12f);
            }
            else
            {
                // Source-owned port datums locate real oak leaves and their
                // adjacent masonry. A small inward offset keeps sounds on the
                // room side of the authored wall/door rather than outdoors.
                var ports = room.Manifest.ports;
                if (ports == null || ports.Length == 0) return false;
                PortRecord nearest = null; float best = float.MaxValue;
                foreach (var port in ports)
                {
                    if (port?.position?.Length != 3 || port.outward?.Length != 3) continue;
                    var point = RoomPackage.Vector(port.position, "ambience port");
                    float distance = (point - localListener).sqrMagnitude;
                    if (distance < best) { best = distance; nearest = port; }
                }
                if (nearest == null) return false;
                var origin = RoomPackage.Vector(nearest.position, "ambience port");
                var outward = RoomPackage.Vector(nearest.outward, "ambience port direction").normalized;
                var side = new Vector3(-outward.z, 0, outward.x);
                Vector3 local = origin - outward * .45f + Vector3.up * (family == "wood" ? 1.5f : 2.4f);
                if (family == "mortar" || family == "chant") local += side * (nearest.width * .5f + .1f);
                world = root.TransformPoint(local);
            }
            return (world - listener).sqrMagnitude <= 32 * 32;
        }

        private void EnsureSources()
        {
            if (air) return;
            if (AbbeyAmbiencePolicy.MaxSources != 4) throw new InvalidOperationException("Unexpected ambience source budget.");
            air = CreateSource("BA ambience | single room air", false, true);
            shaft = CreateSource("BA ambience | optional R08 shaft draft", true, true);
            shaft.minDistance = 3; shaft.maxDistance = 22;
            for (int i = 0; i < voices.Length; ++i)
            {
                voices[i].Source = CreateSource("BA ambience | sparse event " + i, true, false);
                voices[i].LowPass = voices[i].Source.gameObject.AddComponent<AudioLowPassFilter>();
                voices[i].LowPass.enabled = false;
                voices[i].LowPass.lowpassResonanceQ = 1;
            }
        }

        private AudioSource CreateSource(string sourceName, bool spatial, bool loop)
        {
            var child = new GameObject(sourceName); child.SetActive(false); child.transform.SetParent(transform, false);
            var source = child.AddComponent<AudioSource>();
            source.playOnAwake = false; source.loop = loop; source.volume = 0; source.pitch = 1;
            source.spatialBlend = spatial ? 1 : 0; source.rolloffMode = AudioRolloffMode.Linear;
            source.minDistance = 2; source.maxDistance = 16; source.dopplerLevel = 0; source.spread = 0;
            source.priority = loop ? 192 : 176;
            child.SetActive(true); return source;
        }

        private void BorrowMixer()
        {
            nextMixerProbe = Now + 15;
            try
            {
                // V28 accepted Play on the native Ambient group, but Jesse
                // heard none of it. Installed AudioMan IL confirms its master
                // mixer switches Default/Indoor/Menu snapshots. Borrow the
                // same SFX output used by audible native effects instead of
                // sharing the world bed; never alter snapshots or volumes.
                AudioMixerGroup group = null;
                string origin = null;
                foreach (string prefabName in new[] { R07StoneAudio.SlidePrefab, R07StoneAudio.ImpactPrefab })
                {
                    var prefab = PrefabManager.Instance.GetPrefab(prefabName);
                    var native = prefab ? prefab.GetComponentInChildren<AudioSource>(true) : null;
                    var candidate = native ? native.outputAudioMixerGroup : null;
                    if (candidate && AbbeyAmbiencePolicy.IsDungeonOutputGroup(candidate.name))
                    { group = candidate; origin = prefabName; break; }
                }
                // A prefab may be absent before registration. AudioMan's
                // ambient reference locates the existing mixer only; the
                // Ambient group itself is never assigned to our sources.
                var nativeOwner = AudioMan.instance;
                var ambient = nativeOwner ? nativeOwner.m_ambientMixer : null;
                if (!group && ambient && ambient.audioMixer)
                {
                    foreach (var candidate in ambient.audioMixer.FindMatchingGroups("SFX"))
                        if (candidate && AbbeyAmbiencePolicy.IsDungeonOutputGroup(candidate.name))
                        { group = candidate; origin = "AudioMan mixer exact SFX group"; break; }
                }
                if (!group)
                {
                    if (!mixerPendingLogged) Write("BA_AMBIENCE_MIXER_PENDING: native SFX output unavailable; retrying without falling back to the world Ambient group; room travel continues.");
                    mixerPendingLogged = true;
                    return;
                }
                air.outputAudioMixerGroup = group; shaft.outputAudioMixerGroup = group;
                foreach (var voice in voices) voice.Source.outputAudioMixerGroup = group;
                borrowedMixer = group; mixerChecked = true;
                Write("BA_AMBIENCE_MIXER: borrowed " + origin + " / " + group.name + "; custom emitters isolated from world Ambient; no mixer parameters, listeners, prefabs or scene audio changed.");
            }
            catch (Exception ex) { if (!mixerPendingLogged) Write("BA_AMBIENCE_MIXER_PENDING: " + ex.Message); mixerPendingLogged = true; }
        }

        private void SetLoop(AudioSource source, AbbeyAmbienceClip record)
        {
            if (!source || record == null || !clips.TryGetValue(record.id, out var clip) || !clip) return;
            if (!source.isPlaying) { source.clip = clip; source.pitch = 1; source.Play(); }
        }

        private void QueueClip(AbbeyAmbienceClip record)
        {
            if (record == null || clips.ContainsKey(record.id) || failed.Contains(record.id) || !requested.Add(record.id)) return;
            loadQueue.Enqueue(record);
            if (loader == null && isActiveAndEnabled) loader = StartCoroutine(LoadQueued());
        }

        private IEnumerator LoadQueued()
        {
            // A read/hash phase, decode phase and Unity creation phase occupy
            // separate frames. Only this coroutine creates clips, once per id.
            yield return null;
            while (inside && configured && !disposed && loadQueue.Count > 0)
            {
                var record = loadQueue.Dequeue();
                if (TryRead(record, out var bytes))
                {
                    yield return null;
                    if (TryDecode(record, bytes, out var decoded))
                    {
                        bytes = null;
                        yield return null;
                        TryCreate(record, decoded);
                    }
                }
                requested.Remove(record.id);
                yield return null;
            }
            loader = null;
        }

        private bool TryRead(AbbeyAmbienceClip record, out byte[] bytes)
        {
            bytes = null;
            try
            {
                string path = AbbeyAmbienceCatalog.ValidatePath(ambiencePath, record.file);
                var info = new FileInfo(path);
                if (!info.Exists || info.Length != record.bytes || info.Length > AbbeyAmbienceCatalog.MaxFileBytes)
                    throw new InvalidDataException("WAV length differs from approved manifest.");
                bytes = File.ReadAllBytes(path); AbbeyAmbienceCatalog.ValidateClipBytes(record, bytes); return true;
            }
            catch (Exception ex) { FailClip(record, ex); bytes = null; return false; }
        }

        private bool TryDecode(AbbeyAmbienceClip record, byte[] bytes, out PcmWaveData decoded)
        {
            decoded = null;
            try { decoded = PcmWave.Read(bytes); AbbeyAmbienceCatalog.ValidateDecoded(record, decoded); return true; }
            catch (Exception ex) { FailClip(record, ex); decoded = null; return false; }
        }

        private void TryCreate(AbbeyAmbienceClip record, PcmWaveData decoded)
        {
            AudioClip clip = null;
            try
            {
                // Unity's source volume is 0..1. Apply only this air boost to
                // the verified PCM cache, so .65 x2 is not capped at source
                // volume1. The approved WAV/manifest stay byte-identical; the
                // bank's existing headroom accommodates the twofold samples.
                if (record.id == "abbey_sparse_air_loop")
                    for (int i = 0; i < decoded.Samples.Length; ++i)
                        decoded.Samples[i] = AbbeyAmbienceBalance.BoostAirSample(decoded.Samples[i]);
                clip = AudioClip.Create("BA V3 | " + record.id, decoded.Frames, decoded.Channels, decoded.SampleRate, false);
                if (!clip || !clip.SetData(decoded.Samples, 0)) throw new InvalidDataException("Unity rejected approved PCM samples.");
                clips.Add(record.id, clip);
            }
            catch (Exception ex) { if (clip) Object.Destroy(clip); FailClip(record, ex); }
        }

        private void FailClip(AbbeyAmbienceClip record, Exception ex)
        {
            if (failed.Add(record.id)) { ++loadFailures; Write("BA_AMBIENCE_CLIP_SKIPPED: " + record.id + ": " + ex.Message); }
        }

        private void Update()
        {
            if (disposed) return;
            // A stale eligibility heartbeat cannot leave a cached 2D bed alive.
            if (inside && Now - lastTick > .5) Suspend(true);
            float dt = Mathf.Min(Time.unscaledDeltaTime, .1f);
            envelope = Mathf.MoveTowards(envelope, inside ? 1 : 0, dt / (inside ? 1.8f : .35f));
            bool inShaft = inside && currentRoom != null && currentRoom.Root && HasShaftFixture(currentRoom);
            shaftEnvelope = Mathf.MoveTowards(shaftEnvelope, inShaft ? 1 : 0, dt / .4f);
            if (air) { air.volume = volume * envelope * (airRecord?.gain ?? 0); if (envelope == 0 && !inside) air.Stop(); }
            if (shaft) { shaft.volume = volume * envelope * shaftEnvelope * (shaftRecord?.gain ?? 0) * AbbeyAmbienceBalance.ShaftGain; if (shaftEnvelope == 0 || envelope == 0 && !inside) shaft.Stop(); }
            // One source-state record after the bed has faded in makes a
            // silent output diagnosable without treating Play as listening.
            if (!outputStatusLogged && inside && envelope >= .99f && air && air.isPlaying)
            { outputStatusLogged = true; LogOutputState(log); }
            foreach (var voice in voices)
            {
                if (!voice.Source || voice.Record == null) continue;
                bool bell = voice.Record.family == "bell";
                if (!voice.Room?.Root || !voice.Room.Root.activeInHierarchy ||
                    !bell && (voice.Source.transform.position - lastListener).sqrMagnitude > voice.Source.maxDistance * voice.Source.maxDistance ||
                    voice.Record.family == "water" && !AbbeyAmbiencePolicy.AllowsEvent(currentRoom?.Manifest?.roomId, "water")) voice.Leaving = true;
                voice.Fade = Mathf.MoveTowards(voice.Fade, voice.Leaving ? 0 : 1, dt / .18f);
                if (bell)
                {
                    voice.BellLocalPresentation = Mathf.MoveTowards(voice.BellLocalPresentation, ReferenceEquals(voice.Room, bellListenerRoom) ? 1 : 0, dt / BellPresentationFadeSeconds);
                    SetBellPresentation(voice);
                }
                voice.Source.volume = volume * envelope * voice.Fade * voice.Record.gain * (bell ? AbbeyAmbienceBalance.BellGain * BellRoomGain(voice) : 1);
                if (!voice.Source.isPlaying || voice.Fade == 0 || envelope == 0 && !inside) StopVoice(voice);
            }
        }

        internal void Suspend(bool immediate = false)
        {
            inside = false; localBellAvailable = distantBellAvailable = false; currentRoom = bellListenerRoom = null; pending = pendingLocalBell = pendingDistantBell = null;
            StopLoading();
            foreach (var voice in voices) voice.Leaving = true;
            if (!immediate) return;
            waterPoints.Clear();
            envelope = shaftEnvelope = 0;
            if (air) air.Stop(); if (shaft) shaft.Stop();
            foreach (var voice in voices) StopVoice(voice);
        }

        private void StopLoading()
        {
            if (loader != null) StopCoroutine(loader);
            loader = null; loadQueue.Clear(); requested.Clear();
        }

        private static void StopVoice(Voice voice)
        {
            if (voice.Source) { voice.Source.Stop(); voice.Source.clip = null; voice.Source.spatialBlend = 1; voice.Source.rolloffMode = AudioRolloffMode.Linear; }
            if (voice.LowPass) voice.LowPass.enabled = false;
            voice.Record = null; voice.Room = null; voice.FixtureIndex = -1; voice.BellLocalPresentation = 0; voice.DistantBellLane = false; voice.Fade = 1; voice.Leaving = false;
        }

        internal void DisposeAudio()
        {
            Suspend(true); ready = false; disposed = true;
            foreach (var pair in clips) if (pair.Value) Object.Destroy(pair.Value);
            clips.Clear(); families.Clear(); due.Clear(); failed.Clear(); waterPoints.Clear();
            if (air) Object.Destroy(air.gameObject); if (shaft) Object.Destroy(shaft.gameObject);
            foreach (var voice in voices) { if (voice.Source) Object.Destroy(voice.Source.gameObject); voice.Source = null; voice.LowPass = null; }
            air = shaft = null; airRecord = shaftRecord = null; borrowedMixer = null; mixerChecked = mixerPendingLogged = outputStatusLogged = false; nextMixerProbe = 0;
        }

        internal void LogStatus(Action<string> write)
        {
            int sources = (air ? 1 : 0) + (shaft ? 1 : 0), active = (air && air.isPlaying ? 1 : 0) + (shaft && shaft.isPlaying ? 1 : 0);
            foreach (var voice in voices) { if (voice.Source) ++sources; if (voice.Source && voice.Source.isPlaying) ++active; }
            write?.Invoke("BA_AMBIENCE_STATUS: ready=" + ready + "; enabled=" + configured + "; volume=" + volume.ToString("F2") +
                "; eligible=" + inside + "; room=" + (currentRoom?.Manifest?.roomId ?? "none") + "; ownedSources=" + sources +
                "/4; active=" + active + "; cachedClips=" + clips.Count + "; queued=" + loadQueue.Count + "; failed=" + loadFailures +
                "; playedEvents=" + played + "; nativeMixer=" + mixerChecked + "; no loaded-game auditory claim.");
            LogOutputState(write);
            write?.Invoke("BA_AMBIENCE_BELL_STATUS: localFixture=" + localBellAvailable + "; distantFixture=" + distantBellAvailable +
                "; localDue=" + localBellClock.IsDue + "; localRemainingEligibleSeconds=" + localBellClock.Remaining.ToString("F1") + "; localPlayed=" + localBellClock.PlayedCount +
                "; distantDue=" + distantBellClock.IsDue + "; distantRemainingEligibleSeconds=" + distantBellClock.Remaining.ToString("F1") + "; distantPlayed=" + distantBellClock.PlayedCount +
                "; pendingLocal=" + (pendingLocalBell?.Record.id ?? "none") + "; pendingDistant=" + (pendingDistantBell?.Record.id ?? "none") +
                "; all dungeon rooms; fixed fixture tones; local and other-room bells can overlap; distant gain.55 and cutoff900Hz; air x2; shaft x1.4; bell x1.25.");
            foreach (var voice in voices)
                if (voice.Source && voice.Source.isPlaying && voice.Record?.family == "bell")
                    write?.Invoke("BA_AMBIENCE_BELL_ACTIVE: emitter=" + voice.Room.Manifest.roomId + "; fixtureIndex=" + voice.FixtureIndex +
                        "; fixedSignature=" + voice.Record.id + "; startedLane=" + (voice.DistantBellLane ? "distant" : "local") + "; localPresentation=" + voice.BellLocalPresentation.ToString("F2") +
                        "; spatialBlend=" + voice.Source.spatialBlend.ToString("F2") + "; cutoffHz=" + voice.LowPass.cutoffFrequency.ToString("F0") + "; no distance cutoff.");
        }

        private void LogOutputState(Action<string> write)
        {
            float sfxDb;
            string sfx = borrowedMixer && borrowedMixer.audioMixer && borrowedMixer.audioMixer.GetFloat("SfxVol", out sfxDb)
                ? sfxDb.ToString("F1") : "unavailable";
            write?.Invoke("BA_AMBIENCE_OUTPUT: mixer=" + (borrowedMixer ? borrowedMixer.name : "pending") +
                "; nativeSfxDb=" + sfx + "; listenerVolume=" + AudioListener.volume.ToString("F2") +
                "; bed=" + SourceState(air) + "; shaft=" + SourceState(shaft) +
                "; event0=" + SourceState(voices[0].Source) + "; event1=" + SourceState(voices[1].Source) +
                "; states are read-only diagnostics, not an audibility pass.");
        }

        private static string SourceState(AudioSource source)
        {
            if (!source) return "absent";
            return "playing:" + source.isPlaying + ",mute:" + source.mute + ",virtual:" + source.isVirtual +
                ",gain:" + source.volume.ToString("F3") + ",sample:" + source.timeSamples +
                ",clip:" + (source.clip ? source.clip.name + ",load:" + source.clip.loadState : "none");
        }

        private void Write(string message) { log?.Invoke(message); }
        private void OnDisable() { Suspend(true); }
        private void OnDestroy() { DisposeAudio(); }
    }
}
