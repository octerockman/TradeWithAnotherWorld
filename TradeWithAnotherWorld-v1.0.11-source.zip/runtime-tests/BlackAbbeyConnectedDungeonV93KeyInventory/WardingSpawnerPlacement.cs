using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    internal sealed class WardingSpawnerFit
    {
        internal string SourceId, PortId, Kind, SourceSha256;
        internal double MountDepth;
        // Native module bounds after Blender-to-Unity conversion: X/Y/Z.
        internal double[] Min, Max;
    }
    internal sealed class WardingSpawnerPlacement
    {
        internal string Id, RoomId, PortId, Kind;
        internal int RoomIndex, Depth, QuarterTurns;
        internal double MountDepth, Elevation, LowY, HighY;
        internal PlanPoint Position;
        internal double[] Bounds;
    }
    internal static class WardingSpawnerSelection
    {
        internal static int[] Depths(DungeonPlan plan)
        {
            var depth=Enumerable.Repeat(int.MaxValue,plan.Rooms.Length).ToArray();depth[0]=0;
            var queue=new Queue<int>();queue.Enqueue(0);
            while(queue.Count>0)
            {
                int i=queue.Dequeue();
                foreach(var l in plan.Links.Where(l=>l.A==i||l.B==i))
                {int next=l.A==i?l.B:l.A;if(depth[next]>depth[i]+1){depth[next]=depth[i]+1;queue.Enqueue(next);}}
            }
            return depth;
        }
        internal static List<WardingSpawnerPlacement> Candidates(DungeonPlan plan,IEnumerable<WardingSpawnerFit> input)
        {
            var fits=input.ToDictionary(f=>f.SourceId+"/"+f.PortId,StringComparer.Ordinal);
            var depth=Depths(plan);var candidates=new List<WardingSpawnerPlacement>();
            for(int i=0;i<plan.Rooms.Length;i++)
            {
                var room=plan.Rooms[i];if(!WardingSpawnerPolicy.EligibleHost(room.Spec.SourceId,depth[i]))continue;
                // These one-off quest rooms have independently exported floors
                // and concealment. Ordinary unused branches keep their existing
                // chance; never apply old vertex-index repairs to a new floor.
                if(UnrecordedDeadGeneration.Sources.Contains(room.Spec.SourceId)&&room.Spec.AssetId==UnrecordedDeadGeneration.AssetFor(room.Spec.SourceId))continue;
                foreach(var port in room.Spec.Ports)
                {
                    if(plan.IsLinked(i,port.id)||i==0&&port.id==plan.EntryPort||!fits.TryGetValue(room.Spec.SourceId+"/"+port.id,out var f))continue;
                    if(f.Min==null||f.Max==null||f.Min.Length!=3||f.Max.Length!=3||f.Min.Concat(f.Max).Any(n=>double.IsNaN(n)||double.IsInfinity(n))||Enumerable.Range(0,3).Any(a=>f.Min[a]>=f.Max[a]))throw new InvalidDataException("Invalid complete spawner module reservation.");
                    int turn=port.outward[2]>.9?0:port.outward[0]>.9?1:port.outward[2]<-.9?2:3;
                    var position=room.Point(port.position)+room.Normal(port)*f.MountDepth;
                    var corners=new[]{new PlanPoint(f.Min[0],f.Min[2]),new PlanPoint(f.Min[0],f.Max[2]),new PlanPoint(f.Max[0],f.Min[2]),new PlanPoint(f.Max[0],f.Max[2])}
                        .Select(p=>position+PlanPoint.Rotate(p,room.QuarterTurns+turn)).ToArray();
                    var c=new WardingSpawnerPlacement{Id=room.Spec.Id+"/ward/"+port.id,RoomId=room.Spec.Id,PortId=port.id,Kind=f.Kind,RoomIndex=i,Depth=depth[i],
                        QuarterTurns=(room.QuarterTurns+turn)%4,Position=position,Elevation=room.Height(port.position),LowY=room.Height(port.position)+f.Min[1],HighY=room.Height(port.position)+f.Max[1],MountDepth=f.MountDepth,
                        Bounds=new[]{corners.Min(p=>p.X),corners.Min(p=>p.Z),corners.Max(p=>p.X),corners.Max(p=>p.Z)}};
                    // The source host is intentionally excluded: the bay meets
                    // its original aperture. Every OTHER full room envelope,
                    // including shafts/roofs, and every passage is reserved.
                    bool overlap=plan.Rooms.Where((_,j)=>j!=i).Any(r=>DungeonLayoutPlanner.Overlap3D(c.Bounds,c.LowY,c.HighY,r.Envelope(),r.LowY,r.HighY))||
                        plan.Links.Any(l=>DungeonLayoutPlanner.Overlap3D(c.Bounds,c.LowY,c.HighY,l.Envelope(),l.LowY,l.HighY));
                    if(!overlap)candidates.Add(c);
                }
            }
            return candidates;
        }
        internal static List<WardingSpawnerPlacement> Select(DungeonPlan plan,IEnumerable<WardingSpawnerFit> fits)
        {
            if(plan.Mode!="natural")return new List<WardingSpawnerPlacement>();
            int cap=WardingSpawnerPolicy.MaximumSources(plan.Rooms.Length,plan.Rooms.Count(r=>r.Spec.SourceId=="R09-B"),plan.Rooms.Count(r=>r.Spec.Id=="R01"));
            var random=new Random(unchecked(plan.Seed^0x41c7b135));
            var available=Candidates(plan,fits).OrderBy(c=>c.Id,StringComparer.Ordinal).ToList();
            for(int i=available.Count-1;i>0;i--){int j=random.Next(i+1);var t=available[i];available[i]=available[j];available[j]=t;}
            var selected=new List<WardingSpawnerPlacement>();
            foreach(var c in available)
            {
                if(selected.Count>=cap)break;
                // Chance and a hard ceiling, never a required minimum.
                if(random.NextDouble()>.55||selected.Any(s=>s.RoomId==c.RoomId||DungeonLayoutPlanner.Overlap3D(c.Bounds,c.LowY,c.HighY,s.Bounds,s.LowY,s.HighY)))continue;
                selected.Add(c);
            }
            return selected;
        }
        internal static List<WardingSpawnerPlacement> Restore(DungeonPlan plan,IEnumerable<WardingSpawnerFit> fits,IEnumerable<WardingSpawnerState> states)
        {
            var saved=states.ToArray();int cap=WardingSpawnerPolicy.MaximumSources(plan.Rooms.Length,plan.Rooms.Count(r=>r.Spec.SourceId=="R09-B"),1);
            if(saved.Length>cap)throw new InvalidDataException("Saved spawner count exceeds its room ceiling.");
            var by=Candidates(plan,fits).ToDictionary(c=>c.Id,StringComparer.Ordinal);var result=new List<WardingSpawnerPlacement>();
            foreach(var s in saved)
            {
                WardingSpawnerPolicy.Validate(s);
                if(!by.TryGetValue(s.id,out var c)||c.RoomId!=s.roomId||c.PortId!=s.portId||result.Any(x=>x.Id==c.Id||x.RoomId==c.RoomId||DungeonLayoutPlanner.Overlap3D(c.Bounds,c.LowY,c.HighY,x.Bounds,x.LowY,x.HighY)))
                    throw new InvalidDataException("Saved spawner is no longer a clear, eligible unused source port; run retained.");
                result.Add(c);
            }
            return result;
        }
    }
}
