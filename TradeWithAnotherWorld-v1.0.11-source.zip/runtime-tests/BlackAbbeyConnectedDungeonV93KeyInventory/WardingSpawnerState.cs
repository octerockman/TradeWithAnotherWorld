using System;

namespace BlackAbbeySixRooms
{
    // Run-owned state. No Unity references or presentation transforms are saved.
    internal sealed class WardingSpawnerState
    {
        public string id, roomId, portId;
        public float progress;
        public bool initialSequenceCompleted, unbarring, locked, reinforced, activatedEver;
        // Per reopening, independent of the permanent reinforced roster. Only
        // the existing fetching monk's durably saved return releases this.
        public bool awaitingReturn;
        public float spawnCooldown;
        public int nextActorSequence;

        internal WardingSpawnerState Clone() => (WardingSpawnerState)MemberwiseClone();
    }

    internal sealed class WardingSpawnerSettings
    {
        // Initial balance defaults; Jesse's specific speed/reversal/unbar rules
        // below are independent from these configurable encounter defaults.
        public float SealingSeconds = 20f;
        public float FirstSpawnDelay = 4f, MinimumSpawnInterval = 10f, MaximumSpawnInterval = 14f;
        public int MaximumLivingLocal = 3, MaximumLivingGlobal = 8;
        public int MonkWeight = 70, GuardWeight = 20, CenserWeight = 10;
    }

    internal struct WardingSpawnerInput
    {
        public int Players, Enemies, Monks, LivingLocal, LivingGlobal;
        public bool Activation, Obstructed, ProductionBlocked, BossDead;
    }

    internal struct WardingSpawnerStep
    {
        public bool Changed, SpawnRequested, BecameFullyBarred, BecameFullyOpen;
        public bool PlayerWorking, EnemyWorking, Contested;
    }

    internal enum WardingSpawnerKind { Monk, Guard, Censer }
}
