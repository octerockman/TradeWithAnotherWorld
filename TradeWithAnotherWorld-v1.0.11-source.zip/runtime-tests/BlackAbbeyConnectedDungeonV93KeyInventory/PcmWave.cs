using System;
using System.IO;

namespace BlackAbbeySixRooms
{
    internal sealed class PcmWaveData
    {
        internal int SampleRate { get; }
        internal int Channels { get; }
        internal int Frames { get; }
        internal float[] Samples { get; }
        internal PcmWaveData(int sampleRate, int channels, int frames, float[] samples)
        { SampleRate = sampleRate; Channels = channels; Frames = frames; Samples = samples; }
    }

    // A bounded decoder for this approved bank only; no codec/native plugin dependency.
    internal static class PcmWave
    {
        internal static PcmWaveData Read(byte[] bytes)
        {
            if (bytes == null || bytes.Length < 44 || bytes.Length > AbbeyAmbienceCatalog.MaxFileBytes || !Tag(bytes, 0, "RIFF") || !Tag(bytes, 8, "WAVE") || U32(bytes, 4) + 8L != bytes.LongLength)
                throw new InvalidDataException("Ambience WAV has an invalid or oversized RIFF envelope.");
            bool format = false, data = false;
            int dataOffset = 0, dataBytes = 0;
            long offset = 12;
            while (offset < bytes.LongLength)
            {
                if (offset + 8 > bytes.LongLength) throw new InvalidDataException("Truncated WAV chunk header.");
                int header = (int)offset;
                long count = U32(bytes, header + 4), start = offset + 8, end = start + count, paddedEnd = end + (count & 1);
                if (end > bytes.LongLength || paddedEnd > bytes.LongLength) throw new InvalidDataException("Truncated WAV chunk or missing odd-byte padding.");
                if (Tag(bytes, header, "fmt "))
                {
                    if (format || count != 16 && count != 18) throw new InvalidDataException("Duplicate or unsupported WAV format chunk.");
                    int p = (int)start;
                    if (U16(bytes, p) != 1 || U16(bytes, p + 2) != 1 || U32(bytes, p + 4) != 48000 || U32(bytes, p + 8) != 96000 ||
                        U16(bytes, p + 12) != 2 || U16(bytes, p + 14) != 16 || count == 18 && U16(bytes, p + 16) != 0)
                        throw new InvalidDataException("Ambience requires mono48000Hz little-endian PCM16 with coherent block/byte rates.");
                    format = true;
                }
                else if (Tag(bytes, header, "data"))
                {
                    if (data || count < 2 || (count & 1) != 0 || count > AbbeyAmbienceCatalog.MaxFrames * 2L)
                        throw new InvalidDataException("Duplicate, empty, partial or oversized WAV sample data.");
                    dataOffset = (int)start; dataBytes = (int)count; data = true;
                }
                offset = paddedEnd; // Unknown chunks are skipped, including their RIFF word padding.
            }
            if (!format || !data) throw new InvalidDataException("WAV requires both format and sample data.");
            int frames = dataBytes / 2;
            var samples = new float[frames];
            for (int i = 0, p = dataOffset; i < frames; i++, p += 2)
                samples[i] = unchecked((short)U16(bytes, p)) / 32768f;
            return new PcmWaveData(48000, 1, frames, samples);
        }
        static bool Tag(byte[] bytes, int offset, string text) => bytes[offset] == text[0] && bytes[offset + 1] == text[1] && bytes[offset + 2] == text[2] && bytes[offset + 3] == text[3];
        static ushort U16(byte[] bytes, int offset) => (ushort)(bytes[offset] | bytes[offset + 1] << 8);
        static uint U32(byte[] bytes, int offset) => (uint)(bytes[offset] | bytes[offset + 1] << 8 | bytes[offset + 2] << 16 | bytes[offset + 3] << 24);
    }
}
