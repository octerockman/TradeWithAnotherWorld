using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;

namespace BlackAbbeySixRooms
{
    internal sealed class JournalPageNarrationLease:IDisposable
    {
        internal readonly string Path;
        internal readonly JournalPageNarrationPage Page;
        FileStream input;
        internal JournalPageNarrationLease(string path,JournalPageNarrationPage page,string hash,long maximum,long? exact=null)
        {
            if(!JournalPageNarrationContract.IsHash(hash))throw new InvalidDataException("Narration source hash is invalid.");
            Path=System.IO.Path.GetFullPath(path);Page=page;
            try
            {
                input=new FileStream(Path,FileMode.Open,FileAccess.Read,FileShare.Read,65536,FileOptions.SequentialScan);
                if(input.Length<1||input.Length>maximum||exact.HasValue&&input.Length!=exact.Value)throw new InvalidDataException("Narration encoded size differs.");
                string actual;
                using(var sha=SHA256.Create())actual=BitConverter.ToString(sha.ComputeHash(input)).Replace("-","").ToLowerInvariant();
                if(actual!=hash)throw new InvalidDataException("Narration source hash differs: "+System.IO.Path.GetFileName(Path));
                input.Position=0;
            }
            catch{Dispose();throw;}
        }
        internal string ReadText()
        {
            if(input==null)throw new ObjectDisposedException(nameof(JournalPageNarrationLease));
            input.Position=0;using(var reader=new StreamReader(input,Encoding.UTF8,true,4096,true))return reader.ReadToEnd();
        }
        public void Dispose(){var value=input;input=null;value?.Dispose();}
    }
    internal sealed class JournalPageNarrationAssets:IDisposable
    {
#pragma warning disable 0649
        sealed class Catalog{public int schemaVersion;public Row[] pages;}
        sealed class Row{public string pageId,file,sha256;public long bytes;public double durationSeconds;}
#pragma warning restore 0649
        readonly string directory;
        readonly Dictionary<string,JournalPageNarrationPage> pages;
        JournalPageNarrationLease manifest;
        JournalPageNarrationAssets(string path,JournalPageNarrationLease source,JournalPageNarrationPage[] rows)
        {directory=path;manifest=source;pages=rows.ToDictionary(x=>x.PageId,StringComparer.Ordinal);}
        internal static JournalPageNarrationAssets Prepare(string directory,string expectedManifest)
        {
            string full=Path.GetFullPath(directory);
            var lease=new JournalPageNarrationLease(Path.Combine(full,"manifest.json"),null,expectedManifest,JournalPageNarrationContract.MaximumManifestBytes);
            try
            {
                var catalog=JsonConvert.DeserializeObject<Catalog>(lease.ReadText());
                var rows=catalog?.pages?.Select(x=>x==null?null:new JournalPageNarrationPage(x.pageId,x.file,x.sha256,x.bytes,x.durationSeconds)).ToArray();
                JournalPageNarrationContract.Validate(catalog?.schemaVersion??0,rows);
                return new JournalPageNarrationAssets(full,lease,rows);
            }
            catch{lease.Dispose();throw;}
        }
        internal JournalPageNarrationLease VerifyPage(string id)
        {
            if(manifest==null)throw new ObjectDisposedException(nameof(JournalPageNarrationAssets));
            if(!pages.TryGetValue(id,out var row))throw new InvalidDataException("Journal narration page is not approved.");
            // Only the requested page is opened/hashed. This read lease remains
            // held through native file decoding and the bounded clip lifetime.
            return new JournalPageNarrationLease(Path.Combine(directory,row.File),row,row.Sha256,JournalPageNarrationContract.MaximumPageBytes,row.Bytes);
        }
        public void Dispose(){var value=manifest;manifest=null;value?.Dispose();}
    }
}
