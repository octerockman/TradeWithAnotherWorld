using System;

namespace BlackAbbeySixRooms
{
    internal enum DoorEntryStage { Preparing, Covering, Loading, Revealing, Closed }

    // Reference identities prevent a replaced native Player/session/door from
    // inheriting an old worker or loading-screen lease, even with equal IDs.
    internal sealed class DoorEntryPolicy
    {
        internal readonly object Player, Network, Scene, Door;
        internal readonly string World, Character, Token;
        internal DoorEntryStage Stage { get; private set; }
        internal DoorEntryPolicy(object player,object network,object scene,object door,string world,string character)
        {
            if(player==null||network==null||scene==null||door==null||string.IsNullOrEmpty(world)||string.IsNullOrEmpty(character))throw new ArgumentException("A complete local door-entry identity is required.");
            Player=player;Network=network;Scene=scene;Door=door;World=world;Character=character;Token=Guid.NewGuid().ToString("N");
        }
        internal bool Context(object player,object network,object scene,object door,string world,string character)
            => Stage!=DoorEntryStage.Closed&&ReferenceEquals(Player,player)&&ReferenceEquals(Network,network)&&ReferenceEquals(Scene,scene)&&ReferenceEquals(Door,door)&&World==world&&Character==character;
        internal bool TokenOwner(object player,object door,string token)
            => Stage!=DoorEntryStage.Closed&&ReferenceEquals(Player,player)&&ReferenceEquals(Door,door)&&Token==token;
        internal bool Preparing => Stage==DoorEntryStage.Preparing;
        internal bool BeginCover()
        {if(!Preparing)return false;Stage=DoorEntryStage.Covering;return true;}
        internal void BeginLoad()
        {if(Stage!=DoorEntryStage.Covering)throw new InvalidOperationException("An entry must be covered before loading.");Stage=DoorEntryStage.Loading;}
        internal void BeginReveal()
        {if(Stage!=DoorEntryStage.Loading)throw new InvalidOperationException("An entry must finish loading before reveal.");Stage=DoorEntryStage.Revealing;}
        internal void Close()=>Stage=DoorEntryStage.Closed;
    }

    internal sealed class DoorPreparationAdmission
    {
        internal const int HealthyFramesRequired=4;
        int healthyFrames;
        internal bool Update(float frameSeconds,float timeScale,bool memoryKnown,uint memoryLoad,ulong availableBytes)
        {
            bool healthy=!float.IsNaN(frameSeconds)&&!float.IsInfinity(frameSeconds)&&frameSeconds>0&&frameSeconds<=1f/45f&&timeScale>0&&memoryKnown&&memoryLoad<=85&&availableBytes>=1024UL*1024*1024;
            healthyFrames=healthy?Math.Min(HealthyFramesRequired,healthyFrames+1):0;
            return healthyFrames>=HealthyFramesRequired;
        }
    }
}
