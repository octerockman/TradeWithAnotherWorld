using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Pure seeded policy. Actual support, clearance and route checks belong to
    // AbbeyMonkSpawns; a floor polygon is a rejection mask, never support proof.
    internal static class AbbeyMonkSpawnPolicy
    {
        internal const int MaximumPerRun = 12, CandidateAttempts = 80;
        internal const int MaximumMixedPerRun = 128;
        internal const string Monk="TWA_HushedMonk_Test",Guard="BA_ReliquaryGuard",Censer="BA_CenserBrother",Thrall="BA_BellThrall";
        internal static bool KnownPrefab(string name)=>name==Monk||name==Guard||name==Censer||name==Thrall||name==UnrecordedDeadKnightPolicy.Prefab;
        internal const double PortReserve = 3.1, ArrivalReserve = 5.0, SupportRadius = .48;
        internal readonly struct Point
        {
            internal readonly double X, Z;
            internal Point(double x, double z) { X = x; Z = z; }
            internal double Distance(Point p) => Math.Sqrt((X-p.X)*(X-p.X)+(Z-p.Z)*(Z-p.Z));
        }
        internal sealed class Room
        {
            internal string InstanceId, SourceRoomId, AssetId;
            internal int Depth;
            internal Point Entry;
            internal Point[] Ports, FloorPolygon;
        }
        internal sealed class Proposal
        {
            internal int Count;
            internal Point[] Candidates;
            internal float Yaw;
            internal string[] Prefabs;
        }
        internal enum SlotState { Reserved, Spawned, Dead, Lost, Failed }
        internal sealed class Ledger
        {
            internal readonly int Limit;
            internal Ledger(int limit=MaximumPerRun){if(limit<1||limit>MaximumMixedPerRun)throw new ArgumentOutOfRangeException(nameof(limit));Limit=limit;}
            readonly HashSet<string> rooms = new HashSet<string>(StringComparer.Ordinal);
            readonly Dictionary<string, SlotState> slots = new Dictionary<string, SlotState>(StringComparer.Ordinal);
            readonly HashSet<string> consumed = new HashSet<string>(StringComparer.Ordinal);
            internal sealed class Entry { internal string Key; internal SlotState State; internal bool Consumed; }
            internal string[] VisitedRooms => rooms.OrderBy(x=>x,StringComparer.Ordinal).ToArray();
            internal Entry[] Entries => slots.OrderBy(x=>x.Key,StringComparer.Ordinal).Select(x=>new Entry {Key=x.Key,State=x.Value,Consumed=consumed.Contains(x.Key)}).ToArray();
            internal int Consumed { get; private set; }
            internal int Dead => slots.Values.Count(s => s == SlotState.Dead);
            internal bool TryRoom(string instance) => !string.IsNullOrWhiteSpace(instance) && rooms.Add(instance);
            internal static string Key(string instance, int slot) => instance + "/monk/" + slot;
            internal bool Reserve(string key)
            {
                if (string.IsNullOrWhiteSpace(key) || Consumed >= Limit || slots.ContainsKey(key)) return false;
                slots.Add(key, SlotState.Reserved); return true;
            }
            internal void Spawned(string key)
            {
                if (!slots.TryGetValue(key, out var state) || state != SlotState.Reserved) throw new InvalidOperationException("Monk slot was not reserved.");
                slots[key] = SlotState.Spawned; consumed.Add(key); Consumed++;
            }
            internal void Mark(string key, SlotState state)
            {
                if (!slots.ContainsKey(key)) return;
                // Death cannot be undone by the native actor's later destroy.
                if (slots[key] == SlotState.Dead) return;
                slots[key] = state;
            }
            internal SlotState? State(string key) => slots.TryGetValue(key, out var value) ? value : (SlotState?)null;
            internal void Restore(IEnumerable<string> visited,IEnumerable<Entry> restored)
            {
                if(rooms.Count!=0||slots.Count!=0)throw new InvalidOperationException("Restore an actor ledger only once before reconciliation.");
                var names=visited?.ToArray();var entries=restored?.ToArray();
                if(names==null||names.Length>64||names.Any(string.IsNullOrWhiteSpace)||names.Distinct(StringComparer.Ordinal).Count()!=names.Length||
                    entries==null||entries.Length>128||entries.Any(e=>e==null||string.IsNullOrWhiteSpace(e.Key)||!Enum.IsDefined(typeof(SlotState),e.State))||
                    entries.Select(e=>e.Key).Distinct(StringComparer.Ordinal).Count()!=entries.Length||entries.Count(e=>e.Consumed)>Limit||
                    entries.Any(e=>(e.State==SlotState.Spawned||e.State==SlotState.Dead||e.State==SlotState.Lost)&&!e.Consumed||e.State==SlotState.Reserved&&e.Consumed))
                    throw new ArgumentException("Invalid saved actor ledger; no slots restored.");
                foreach(string name in names)rooms.Add(name);
                foreach(var entry in entries){slots.Add(entry.Key,entry.State);if(entry.Consumed)consumed.Add(entry.Key);}
                Consumed=consumed.Count;
            }
        }
        struct Seeded
        {
            uint value;
            internal Seeded(uint initial) { value = initial == 0 ? 0x9e3779b9u : initial; }
            internal uint Next() { uint n=value;n^=n<<13;n^=n>>17;n^=n<<5;return value=n; }
            internal double Unit() => Next() / 4294967296.0;
        }
        static uint Hash(int seed, string value)
        {
            unchecked { uint h=2166136261u ^ (uint)seed; foreach(char c in value ?? "") { h=(h^c)*16777619u; } return h; }
        }
        internal static string[] Order(int seed, IEnumerable<string> instances) => instances.OrderBy(id => Hash(seed, id)).ThenBy(id => id, StringComparer.Ordinal).ToArray();
        static double[] Region(string id)
        {
            switch(id)
            {
                case "R01": return new[] {-1.1, 1.1, 6.8, 8.9};
                case "R02": return new[] {-1.5, 1.5, 3.2, 4.8};
                case "R03": case "R03_complete": return new[] {-4.0, 4.0, 3.5, 9.8};
                case "R04": return new[] {-4.8, 4.8, 3.5, 12.5};
                case "R05": return new[] {-1.0, 3.2, 3.3, 6.8};
                case "R06": return new[] {-4.0, 1.2, 3.1, 6.8};
                case "R07": return new[] {-2.5, 2.5, 3.4, 4.8};
                case "R09": return new[] {-1.35, 1.35, -13.2, -6.2};
                default: return null; // R08 broken shaft/stairs are excluded.
            }
        }
        internal static Proposal Propose(int seed, Room room)
        {
            var bounds=Region(room?.SourceRoomId);
            if (bounds == null || string.IsNullOrWhiteSpace(room?.InstanceId)) return new Proposal {Count=0,Candidates=Array.Empty<Point>()};
            var random=new Seeded(Hash(seed, room.InstanceId+"|"+room.SourceRoomId));
            bool selected=random.Unit()<.8;
            int count=room.SourceRoomId=="R01" || room.SourceRoomId=="R07" ? 1 : random.Unit()<.42 ? 2 : 1;
            float yaw=(float)(random.Unit()*360);
            var points=new Point[CandidateAttempts];
            for(int i=0;i<points.Length;i++) points[i]=new Point(bounds[0]+random.Unit()*(bounds[1]-bounds[0]),bounds[2]+random.Unit()*(bounds[3]-bounds[2]));
            return new Proposal {Count=selected?count:0,Candidates=points,Yaw=yaw};
        }
        internal static Proposal ProposeMixed(int seed,Room room)
        {
            if(UnrecordedDeadKnightPolicy.Selected(room))return new Proposal{Count=1,
                Prefabs=new[]{UnrecordedDeadKnightPolicy.Prefab},Candidates=new[]{new Point(UnrecordedDeadKnightPolicy.X,UnrecordedDeadKnightPolicy.Z)},
                Yaw=UnrecordedDeadKnightPolicy.Yaw};
            var region=Region(room?.SourceRoomId);
            if(region==null||room.Depth<2||(room.SourceRoomId=="R09"||R09SplitIdentity.IsPiece(room.SourceRoomId)))return new Proposal{Count=0,Prefabs=Array.Empty<string>(),Candidates=Array.Empty<Point>()};
            var random=new Seeded(Hash(seed,"encounter-v2|"+room.InstanceId+"|"+room.SourceRoomId));
            double roll=random.Unit()*100;int count=roll<20?0:roll<44?1:roll<72?2:roll<92?3:4;
            // Preserve the bell crossing four-mob roll; other rooms cap at three.
            count=Math.Min(count,room.SourceRoomId=="R04"?4:3);
            bool hasCenser=false,hasThrall=false,large=room.SourceRoomId=="R01"||room.SourceRoomId=="R04";
            bool guarded=room.SourceRoomId=="R05"||room.SourceRoomId=="R07";int monks=guarded?30:45,guards=guarded?55:35;
            var prefabs=new string[count];
            for(int i=0;i<count;i++){
                int c=hasCenser?0:15,t=large&&!hasThrall?5:0;double pick=random.Unit()*(monks+guards+c+t);
                prefabs[i]=pick<monks?Monk:pick<monks+guards?Guard:pick<monks+guards+c?Censer:Thrall;
                hasCenser|=prefabs[i]==Censer;hasThrall|=prefabs[i]==Thrall;
            }
            var points=new Point[CandidateAttempts*3];
            for(int i=0;i<points.Length;i++)points[i]=new Point(region[0]+random.Unit()*(region[1]-region[0]),region[2]+random.Unit()*(region[3]-region[2]));
            return new Proposal{Count=count,Prefabs=prefabs,Candidates=points,Yaw=(float)(random.Unit()*360)};
        }
        static bool Finite(double n) => !double.IsNaN(n) && !double.IsInfinity(n);
        internal static bool Contains(Point[] polygon, Point p)
        {
            if (polygon == null || polygon.Length<3) return false;
            bool inside=false;
            for(int i=0,j=polygon.Length-1;i<polygon.Length;j=i++)
                if ((polygon[i].Z>p.Z)!=(polygon[j].Z>p.Z) && p.X < (polygon[j].X-polygon[i].X)*(p.Z-polygon[i].Z)/(polygon[j].Z-polygon[i].Z)+polygon[i].X) inside=!inside;
            return inside;
        }
        internal static bool Allowed(Room room, Point p, out string reason)
        {
            if(UnrecordedDeadKnightPolicy.Selected(room))
            {
                bool marker=Finite(p.X)&&Finite(p.Z)&&Math.Abs(p.X-UnrecordedDeadKnightPolicy.X)<.000001&&Math.Abs(p.Z-UnrecordedDeadKnightPolicy.Z)<.000001;
                reason=marker?null:"outside authored knight marker";return marker;
            }
            var b=Region(room?.SourceRoomId);
            if(b==null) {reason="excluded room/stairs";return false;}
            if(!Finite(p.X)||!Finite(p.Z)||p.X<b[0]||p.X>b[1]||p.Z<b[2]||p.Z>b[3]) {reason="outside bounded encounter area";return false;}
            if(room.Ports==null || room.Ports.Any(q=>p.Distance(q)<PortReserve)) {reason="doorway reserve";return false;}
            if(p.Distance(room.Entry)<(room.SourceRoomId=="R01"?ArrivalReserve:2.0)) {reason="arrival reserve";return false;}
            if(room.SourceRoomId=="R04"&&p.Distance(new Point(0,8))<3.25 ||
               (room.SourceRoomId=="R03"||room.SourceRoomId=="R03_complete")&&p.Distance(new Point(0,10))<2.4 ||
               room.SourceRoomId=="R07"&&p.Distance(new Point(0,8))<3.0) {reason="focal/interaction reserve";return false;}
            for(int i=0;i<9;i++)
            {
                var q=i==0?p:new Point(p.X+SupportRadius*Math.Cos((i-1)*Math.PI/4),p.Z+SupportRadius*Math.Sin((i-1)*Math.PI/4));
                if(!Contains(room.FloorPolygon,q)) {reason="outside floor containment";return false;}
            }
            reason=null;return true;
        }
    }
}
