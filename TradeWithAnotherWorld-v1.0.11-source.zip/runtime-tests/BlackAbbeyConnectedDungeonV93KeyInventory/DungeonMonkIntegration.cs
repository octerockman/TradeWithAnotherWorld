using System;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        private AbbeyMonkSpawns monkRun;
        private MonkRunSnapshot restoredMonkSnapshot;
        private Func<bool> monkCheckpointRequested;
        internal static bool MonkWorldMatches(string world)
        {
            try{return !string.IsNullOrEmpty(world)&&WorldKey()==world;}
            catch{return false;}
        }
        private JObject CaptureMonkState()=>MonkRunPersistence.ToJson(monkRun?.Capture()??restoredMonkSnapshot);
        private void RestoreMonkState(JObject snapshot,string runId,int seed)
        {restoredMonkSnapshot=MonkRunPersistence.Read(snapshot,WorldKey(),runId,seed);}
        private void RetireSavedMonkState(JObject snapshot,string runId,int seed)
        {AbbeyMonkSpawns.RetireSaved(MonkRunPersistence.Read(snapshot,WorldKey(),runId,seed),s=>Logger.LogInfo(s));}
        private void ReconcileMonkRun(DungeonPlan plan)
        {
            var depth=Enumerable.Repeat(int.MaxValue,plan.Rooms.Length).ToArray();depth[0]=0;var queue=new System.Collections.Generic.Queue<int>();queue.Enqueue(0);
            while(queue.Count>0){int i=queue.Dequeue();foreach(var link in plan.Links.Where(l=>l.A==i||l.B==i)){int next=link.A==i?link.B:link.A;if(depth[next]>depth[i]+1){depth[next]=depth[i]+1;queue.Enqueue(next);}}}
            var placements = plan.Rooms.Select((p,i) => new AbbeyMonkPlacement(p.Spec.Id, p.Spec.SourceId, rooms[p.Spec.Id]){
                Depth=depth[i],PlannedAssetId=p.Spec.AssetId,AssetId=plan.BossUnlockRoute==UnrecordedDeadState.RouteId?p.Spec.AssetId:null}).ToArray();
            if (monkRun == null) monkRun = AbbeyMonkSpawns.Begin(naturalRunId, plan.Seed,WorldKey(),placements,s=>Logger.LogInfo(s),restoredMonkSnapshot,
                snapshot=>{restoredMonkSnapshot=snapshot;return monkCheckpointRequested?.Invoke()??false;});
            else monkRun.Reconcile(placements);
            Print(monkRun.Status());
        }
        private void DisposeMonkRun(bool retire=false)
        {
            if(retire)
            {
                if(monkRun!=null)monkRun.Dispose();
                else if(restoredMonkSnapshot!=null)AbbeyMonkSpawns.RetireSaved(restoredMonkSnapshot,s=>Logger.LogInfo(s));
                restoredMonkSnapshot=null;
            }
            else if(monkRun!=null){monkRun.Suspend();restoredMonkSnapshot=monkRun.Capture();}
            monkRun = null;
        }
    }
}
