using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // One generated run can contain several shrines. Their physical candles,
    // opening history and inventories belong to the room instance, never its
    // shared source model. Keep the registry through same-run room reloads;
    // session unload saves this registry, then releases its local bindings.
    internal sealed class R07RoomStates<T> where T : class
    {
        private readonly int seed;
        private readonly Dictionary<string, R07RunState<T>> rooms = new Dictionary<string, R07RunState<T>>(StringComparer.Ordinal);
        internal R07RoomStates(int seed) { this.seed = seed; }
        internal KeyValuePair<string,R07RunState<T>>[] ExistingRooms => rooms.ToArray();
        internal int RoomSeed(string instanceId)
        {
            int roomSeed=seed;if(instanceId!="R07")unchecked{foreach(char c in instanceId)roomSeed=roomSeed*31+c;}return roomSeed;
        }
        internal void RestoreRoom(string instanceId,R07RunState<T> state)
        {
            if(string.IsNullOrWhiteSpace(instanceId)||state==null||state.Seed!=RoomSeed(instanceId)||rooms.ContainsKey(instanceId))
                throw new ArgumentException("Invalid or duplicate saved shrine room.");
            rooms.Add(instanceId,state);
        }

        internal R07RunState<T> ForRoom(string instanceId)
        {
            if (string.IsNullOrWhiteSpace(instanceId)) throw new ArgumentException("A shrine requires its concrete room instance ID.");
            if (!rooms.TryGetValue(instanceId, out var state))
            {
                // The original single R07 retains its previous loot seed.
                // Repeated instances use stable independent seeds without
                // consuming the dungeon or Unity random streams.
                int roomSeed = RoomSeed(instanceId);
                state = new R07RunState<T>(roomSeed);
                rooms.Add(instanceId, state);
            }
            return state;
        }
    }
}
