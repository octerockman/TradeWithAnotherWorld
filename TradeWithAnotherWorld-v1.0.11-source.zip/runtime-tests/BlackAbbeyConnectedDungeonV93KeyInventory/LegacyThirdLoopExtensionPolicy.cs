using System;

namespace BlackAbbeySixRooms
{
    internal static class LegacyThirdLoopExtensionPolicy
    {
        internal const int MaximumRooms=50;
        internal const int MaximumRouteExtras=2*LegacyDungeonRouteClosure.MaximumHalfRooms;
        internal const int PlacementBudget=8000;
        internal const string Reason="third-cycle normal route search exhausted; extra rooms used only by its closing route";
        internal static bool Eligible(int normalTarget,int wantedCycles,int existingCycles,bool normalClosureFailed,int normalInventoryCount)=>
            normalTarget>=LegacyNaturalDungeonRoster.MinimumRooms&&normalTarget<=LegacyNaturalDungeonRoster.MaximumRooms&&normalInventoryCount==normalTarget&&
            wantedCycles==3&&existingCycles==2&&normalClosureFailed;
        internal static bool IsExtraId(string id)=>id!=null&&id.IndexOf("_loop3_extra_",StringComparison.Ordinal)>=0;
        internal static bool EligibleSource(string sourceId,int ports)=>ports>=2&&
            (sourceId=="R01"||sourceId=="R02"||sourceId=="R03"||sourceId=="R03_complete"||sourceId=="R04"||sourceId=="R05"||sourceId=="R06");
        internal static bool Accepts(int normalTarget,int extras)=>normalTarget>=LegacyNaturalDungeonRoster.MinimumRooms&&normalTarget<=LegacyNaturalDungeonRoster.MaximumRooms&&
            extras>0&&extras<=MaximumRouteExtras&&normalTarget+extras<=MaximumRooms;
    }
}
