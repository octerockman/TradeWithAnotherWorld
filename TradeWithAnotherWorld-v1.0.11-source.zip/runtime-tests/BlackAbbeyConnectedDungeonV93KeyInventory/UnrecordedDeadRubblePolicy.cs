using System;
using System.IO;

namespace BlackAbbeySixRooms
{
    internal sealed class UnrecordedDeadRubbleRelease
    {
        internal readonly int StoneIndex,FirstIndex,IndexCount;
        internal readonly bool Retain;
        // Source room-local Unity axes; angular velocity is radians/second.
        internal readonly float[] LinearVelocity,AngularVelocity;
        internal readonly float FadeStart,FadeEnd;
        internal UnrecordedDeadRubbleRelease(int stone,bool retain,float[] linear,float[] angular,float start,float end,bool independentSource=false)
        {StoneIndex=stone;FirstIndex=independentSource?-1:stone*UnrecordedDeadRubblePolicy.IndicesPerStone;IndexCount=independentSource?0:UnrecordedDeadRubblePolicy.IndicesPerStone;
            Retain=retain;LinearVelocity=linear;AngularVelocity=angular;FadeStart=start;FadeEnd=end;}
    }

    // Exact source stones, not replacement wedges or mortar. This policy only
    // chooses releases/lifetimes. Real physics supplies every landed transform.
    internal static class UnrecordedDeadRubblePolicy
    {
        internal const string SourceMeshSha256="03ddb355ee15d026e90ae8f9563e26ac6f9ab72bf0e3121b51cef32750f15ec6";
        internal const int SourceVertexCount=1033,SourceIndexCount=1386;
        internal const int StoneCount=11,IndicesPerStone=90,StoneIndexCount=StoneCount*IndicesPerStone,RetainedCount=3;
        internal const float DynamicSeconds=8f,FadeSeconds=2f,FadeStaggerSeconds=.18f,MaximumPhysicsSeconds=12f;
        internal static void ValidateSource(string sha256,int vertices,int indices)
        {
            if(sha256!=SourceMeshSha256||vertices!=SourceVertexCount||indices!=SourceIndexCount)
                throw new InvalidDataException("Breakaway rubble requires the exact checked sealed-wall stone buffer.");
        }
        internal static bool EligibleToRetain(int stone)
        {RequireStone(stone);return stone!=8&&stone!=10;}
        static void RequireStone(int stone)
        {if(stone<0||stone>=StoneCount)throw new ArgumentOutOfRangeException(nameof(stone));}
        static float Between(Random random,float low,float high)=>(float)(low+(high-low)*random.NextDouble());
        internal static UnrecordedDeadRubbleRelease[] Build(int seed)
        {
            // A private stream cannot consume or reseed gameplay/Unity RNG.
            var random=new Random(unchecked(seed^0x5171B13));
            int[] eligible={0,1,2,3,4,5,6,7,9};
            for(int i=eligible.Length-1;i>0;i--)
            {int j=random.Next(i+1),swap=eligible[i];eligible[i]=eligible[j];eligible[j]=swap;}
            var retained=new bool[StoneCount];for(int i=0;i<RetainedCount;i++)retained[eligible[i]]=true;
            var result=new UnrecordedDeadRubbleRelease[StoneCount];int temporary=0;
            for(int stone=0;stone<StoneCount;stone++)
            {
                // A gentle +X release separates masonry from the west wall;
                // vertical motion remains predominantly gravity-driven.
                var linear=new[]{Between(random,.12f,.42f),Between(random,.05f,.35f),Between(random,-.3f,.3f)};
                var angular=new[]{Between(random,-1.1f,1.1f),Between(random,-1.1f,1.1f),Between(random,-1.1f,1.1f)};
                float start=retained[stone]?MaximumPhysicsSeconds:DynamicSeconds+temporary++*FadeStaggerSeconds;
                result[stone]=new UnrecordedDeadRubbleRelease(stone,retained[stone],linear,angular,start,retained[stone]?start:start+FadeSeconds);
            }
            return result;
        }
        internal static UnrecordedDeadRubbleRelease[] BuildMapped(int seed,bool[] eligibleToRetain)
        {
            if(eligibleToRetain==null||eligibleToRetain.Length<1||eligibleToRetain.Length>64)throw new ArgumentOutOfRangeException(nameof(eligibleToRetain));
            var random=new Random(unchecked(seed^0x5171B13));var eligible=new System.Collections.Generic.List<int>();
            for(int i=0;i<eligibleToRetain.Length;i++)if(eligibleToRetain[i])eligible.Add(i);
            for(int i=eligible.Count-1;i>0;i--){int j=random.Next(i+1),swap=eligible[i];eligible[i]=eligible[j];eligible[j]=swap;}
            var retained=new bool[eligibleToRetain.Length];for(int i=0;i<Math.Min(RetainedCount,eligible.Count);i++)retained[eligible[i]]=true;
            var result=new UnrecordedDeadRubbleRelease[eligibleToRetain.Length];int temporary=0;
            for(int i=0;i<result.Length;i++)
            {
                float start=retained[i]?MaximumPhysicsSeconds:DynamicSeconds+temporary++*FadeStaggerSeconds;
                result[i]=new UnrecordedDeadRubbleRelease(i,retained[i],new[]{Between(random,.12f,.42f),Between(random,.05f,.35f),Between(random,-.3f,.3f)},new[]{Between(random,-1.1f,1.1f),Between(random,-1.1f,1.1f),Between(random,-1.1f,1.1f)},start,retained[i]?start:start+FadeSeconds,true);
            }
            return result;
        }
        static void RequireElapsed(float elapsed)
        {if(float.IsNaN(elapsed)||float.IsInfinity(elapsed)||elapsed<0)throw new ArgumentOutOfRangeException(nameof(elapsed));}
        internal static bool PhysicsActive(float elapsed)
        {RequireElapsed(elapsed);return elapsed<MaximumPhysicsSeconds;}
        internal static float Opacity(UnrecordedDeadRubbleRelease release,float elapsed)
        {
            if(release==null)throw new ArgumentNullException(nameof(release));RequireElapsed(elapsed);
            if(release.Retain||elapsed<=release.FadeStart)return 1f;
            if(elapsed>=release.FadeEnd)return 0f;
            return 1f-(elapsed-release.FadeStart)/(release.FadeEnd-release.FadeStart);
        }
        internal static bool Visible(UnrecordedDeadRubbleRelease release,float elapsed)=>Opacity(release,elapsed)>0f;
    }
}
