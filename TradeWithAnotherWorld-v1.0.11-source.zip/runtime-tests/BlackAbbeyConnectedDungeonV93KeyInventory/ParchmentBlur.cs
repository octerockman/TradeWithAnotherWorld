using System;
namespace BlackAbbeySixRooms
{
    // Only an in-memory reading derivative; embedded artwork stays untouched.
    internal static class ParchmentBlur
    {
        internal sealed class Result { internal int Width,Height;internal byte[] Pixels; }
        internal const int MaximumDimension=768,Radius=7,Passes=3;
        internal static Result Create(byte[] source,int width,int height)
        {
            if(source==null||width<=0||height<=0||width>8192||height>8192||source.Length!=checked(width*height*4))throw new ArgumentException("Invalid parchment pixels.");
            double scale=Math.Min(1,MaximumDimension/(double)Math.Max(width,height));
            int w=Math.Max(1,(int)Math.Round(width*scale)),h=Math.Max(1,(int)Math.Round(height*scale)),count=checked(w*h);
            var current=new float[count*4];var next=new float[current.Length];var alpha=new byte[count];
            for(int y=0;y<h;y++)for(int x=0;x<w;x++)
            {
                int input=(Math.Min(height-1,(int)((y+.5)*height/h))*width+Math.Min(width-1,(int)((x+.5)*width/w)))*4,at=(y*w+x)*4;
                float a=source[input+3]/255f;alpha[y*w+x]=source[input+3];
                current[at]=source[input]*a;current[at+1]=source[input+1]*a;current[at+2]=source[input+2]*a;current[at+3]=a;
            }
            for(int pass=0;pass<Passes;pass++){Box(current,next,w,h,true);var swap=current;current=next;next=swap;Box(current,next,w,h,false);swap=current;current=next;next=swap;}
            var bytes=new byte[count*4];
            for(int i=0;i<count;i++){float a=current[i*4+3];for(int c=0;c<3;c++)bytes[i*4+c]=(byte)Math.Max(0,Math.Min(255,a>.00001f?(int)Math.Round(current[i*4+c]/a):0));bytes[i*4+3]=alpha[i];}
            return new Result{Width=w,Height=h,Pixels=bytes};
        }
        private static void Box(float[] input,float[] output,int width,int height,bool horizontal)
        {
            int lines=horizontal?height:width,length=horizontal?width:height,diameter=Radius*2+1;
            for(int line=0;line<lines;line++)for(int c=0;c<4;c++)
            {
                int Index(int p)=>horizontal?(line*width+p)*4+c:(p*width+line)*4+c;
                float sum=0;for(int k=-Radius;k<=Radius;k++)sum+=input[Index(Math.Max(0,Math.Min(length-1,k)))];
                for(int p=0;p<length;p++){output[Index(p)]=sum/diameter;sum-=input[Index(Math.Max(0,p-Radius))];sum+=input[Index(Math.Min(length-1,p+Radius+1))];}
            }
        }
    }
}
