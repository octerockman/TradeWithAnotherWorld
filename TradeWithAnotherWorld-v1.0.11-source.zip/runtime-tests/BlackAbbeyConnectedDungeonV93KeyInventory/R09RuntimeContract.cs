using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;

namespace BlackAbbeySixRooms
{
#pragma warning disable 0649
    // These records deliberately have no Unity dependency. The offline BAR1
    // probe uses exactly the same ownership and rest-pose contract as loading.
    internal sealed class R09InteractionData
    {
        public int schemaVersion;
        public string roomId, sourceSha256, coordinateMode;
        public R09PartRecord[] parts;
        public R09BossDoorRecord bossDoor;
        public R09BellRecord bell;
        public R09EncounterRecord encounter;
        public AbbeyCenserRecord[] censers;
    }
    internal sealed class R09PartRecord
    {
        public string id, sourcePivot, parentPart, coordinateMode;
        public float[][] sourceWorldMatrixBlender;
        public float[] pivot, parentRelativePivot, axis;
        public float minimumDegrees, maximumDegrees;
        public string[] sourceObjects, visualMeshes, colliderMeshes;
    }
    internal sealed class R09BossDoorRecord
    {
        public string leftPart, rightPart;
        public bool openOnE;
        public float maximumDegrees, durationSeconds, leftOpenDegrees, rightOpenDegrees;
    }
    internal sealed class R09BellRecord
    {
        public string castingPart, clapperPart;
        public float castingMaximumDegrees, clapperMaximumDegrees;
    }
    internal sealed class R09LightingData
    {
        public int schemaVersion;
        public string roomId, sourceSha256;
        public WindowLightRecord[] windowLights;
        public R09BellSpillRecord[] bellSpills;
        public R09CandlePolicy candlePolicy;
    }
    internal sealed class R09BellSpillRecord
    {
        public string id, type, parentPart, sourceSocket, sourceLight;
        public float[] position, worldRestPosition, color;
        public float intensity, range;
        public bool shadows, stationary;
    }
    internal sealed class R09CandlePolicy
    {
        public int fixtureCount;
        public bool shadows;
        public float movement, flickerSpeed, flickerAmplitude, groupMaximumDiameter;
    }
#pragma warning restore 0649

    internal sealed class R09RuntimeContract
    {
        internal const string NativeSourceSha256 = "923908f50a7adaf8a40d044a781519ac3190a56d7f6a9fed21ea70c8cf9fa422";
        internal const string StaticPartId = "static";
        private const int MaximumSidecarBytes = 2 * 1024 * 1024;
        private static readonly string[] PartIds = { "boss_left", "boss_right", "bell_casting", "bell_clapper" };
        private readonly Dictionary<string, R09PartRecord> parts;
        internal R09InteractionData Interactions { get; private set; }
        internal R09LightingData Lighting { get; private set; }
        internal R09EncounterRecord Encounter { get; private set; }
        internal int EffectiveFixtureCount { get; private set; }
        internal R09PartRecord[] Parts => Interactions.parts;
        internal bool IsHall=>R09SplitIdentity.IsHall(Interactions.roomId);
        internal bool IsChamber=>R09SplitIdentity.IsChamber(Interactions.roomId);

        private R09RuntimeContract(R09InteractionData interactions, R09LightingData lighting)
        {
            Interactions = interactions; Lighting = lighting;
            Encounter = R09EncounterState.Effective(interactions.encounter,interactions.sourceSha256);
            parts = interactions.parts.ToDictionary(p => p.id, StringComparer.Ordinal);
        }

        internal R09PartRecord Part(string id)
        {
            if (id == null || !parts.TryGetValue(id, out var part)) throw Invalid("Unknown R09 part: " + id);
            return part;
        }

        // BAR1 chunks are pivot-local, even for the nested clapper. These are
        // WORLD-REST Unity offsets, never the parent-relative runtime offsets.
        internal float[] RestOffsetForPart(string id)
        {
            if (string.IsNullOrEmpty(id) || id == StaticPartId) return new float[3];
            return (float[])Part(id).pivot.Clone();
        }
        internal IReadOnlyDictionary<string, float[]> PartRestOffsets =>
            parts.ToDictionary(p => p.Key, p => (float[])p.Value.pivot.Clone(), StringComparer.Ordinal);

        internal static R09RuntimeContract Read(string directory, PackageManifest room)
        {
            if (room == null || room.schemaVersion != 1 || room.roomId != "R09"&&!R09SplitIdentity.IsPiece(room.roomId) || !CatalogReader.Hash(room.sourceSha256))
                throw Invalid("R09 requires its exact checked native source.");
            if(R09SplitIdentity.IsPiece(room.roomId))
                R09SplitIdentity.RequireSealed(room.roomId,room.sourceSha256,CatalogReader.HashFile(RoomPackage.FilePath(directory,"manifest.json")));
            if (string.Equals(room.r09InteractionFile, room.r09LightingFile, StringComparison.OrdinalIgnoreCase))
                throw Invalid("R09 interaction and lighting resources must be distinct.");
            var interactions = ReadSidecar<R09InteractionData>(directory, room.r09InteractionFile, room.r09InteractionSha256);
            var lighting = ReadSidecar<R09LightingData>(directory, room.r09LightingFile, room.r09LightingSha256);
            if (interactions.encounter != null) R09EncounterState.Validate(interactions.encounter);
            AbbeyCenserContract.Validate(interactions.censers);
            if (room.sourceSha256 != NativeSourceSha256 && !R09SplitIdentity.IsHall(room.roomId) && interactions.encounter?.enabled != true)
                throw Invalid("A revised R09 source requires its explicit source-bound V25 encounter contract.");
            ValidateInteractions(interactions, room);
            var result = new R09RuntimeContract(interactions, lighting);
            result.ValidateLighting(room);
            result.EffectiveFixtureCount = R09CandleSocketOverrides.ForRoom(room).Length;
            return result;
        }

        internal static R09RuntimeContract Join(R09RuntimeContract hall,R09RuntimeContract chamber)
        {
            if(hall==null||chamber==null||!hall.IsHall||!chamber.IsChamber||
                hall.EffectiveFixtureCount!=42||chamber.EffectiveFixtureCount!=156)
                throw Invalid("A split encounter requires one checked42-wick hall and one checked156-wick chamber.");
            var a=hall.Interactions;var b=chamber.Interactions;
            var joined=new R09RuntimeContract(new R09InteractionData{schemaVersion=1,roomId=b.roomId,sourceSha256=b.sourceSha256,
                coordinateMode=b.coordinateMode,parts=a.parts.Concat(b.parts).ToArray(),bossDoor=a.bossDoor,bell=b.bell,
                encounter=b.encounter,censers=b.censers},chamber.Lighting);
            if(joined.parts.Count!=4)throw Invalid("Split moving part ownership overlaps.");
            joined.EffectiveFixtureCount=hall.EffectiveFixtureCount+chamber.EffectiveFixtureCount;
            return joined;
        }

        private static T ReadSidecar<T>(string directory, string relative, string hash) where T : class
        {
            if (!CatalogReader.Hash(hash) || string.IsNullOrWhiteSpace(directory) || string.IsNullOrWhiteSpace(relative) ||
                relative.Length > 240 || Path.IsPathRooted(relative) || relative.IndexOf(':') >= 0 ||
                relative.Replace('\\', '/').Split('/').Any(p => p.Length == 0 || p == "." || p == ".."))
                throw Invalid("Invalid R09 sidecar path/hash.");
            string root = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string path = Path.GetFullPath(Path.Combine(root, relative));
            if (!path.StartsWith(root, StringComparison.OrdinalIgnoreCase) || !File.Exists(path)) throw Invalid("Missing/outside R09 sidecar.");
            var info = new FileInfo(path);
            if (info.Length == 0 || info.Length > MaximumSidecarBytes) throw Invalid("R09 sidecar is absent or too large.");
            // Do not allow a package-internal symlink/junction to escape the
            // lexical path guard. No asset or directory is modified here.
            for (string item = path; item != null && item.StartsWith(root, StringComparison.OrdinalIgnoreCase); item = Path.GetDirectoryName(item))
                if ((File.GetAttributes(item) & FileAttributes.ReparsePoint) != 0) throw Invalid("R09 sidecars cannot follow package reparse points.");
            byte[] bytes = File.ReadAllBytes(path);
            if (bytes.Length == 0 || bytes.Length > MaximumSidecarBytes) throw Invalid("R09 sidecar size changed.");
            string actual;
            using (var sha = SHA256.Create()) actual = BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
            if (actual != hash) throw Invalid("R09 sidecar differs from its declared hash: " + relative);
            string json = new UTF8Encoding(false, true).GetString(bytes).TrimStart('\uFEFF');
            var value = JsonConvert.DeserializeObject<T>(json, ManifestReader.Settings());
            if (value == null) throw Invalid("Empty R09 sidecar.");
            return value;
        }

        private static void ValidateInteractions(R09InteractionData m, PackageManifest room)
        {
            bool hall=R09SplitIdentity.IsHall(room.roomId),chamber=R09SplitIdentity.IsChamber(room.roomId);
            var expectedParts=hall?new[]{"boss_left","boss_right"}:chamber?new[]{"bell_casting","bell_clapper"}:PartIds;
            if (m.schemaVersion != 1 || m.roomId != room.roomId || m.sourceSha256 != room.sourceSha256 ||
                m.coordinateMode == null || !m.coordinateMode.StartsWith("Unity x,z,y;", StringComparison.Ordinal) ||
                m.parts == null || m.parts.Length != expectedParts.Length || m.parts.Any(p => p == null || !expectedParts.Contains(p.id)) ||
                m.parts.Select(p => p.id).Distinct(StringComparer.Ordinal).Count() != expectedParts.Length ||
                hall&&(m.bell!=null||m.encounter!=null)||chamber&&m.bossDoor!=null)
                throw Invalid("R09 requires four canonical pivot-local parts and its Unity coordinate convention.");
            foreach (var p in m.parts)
            {
                if (!Name(p.sourcePivot) || !Vector(p.pivot) || !Vector(p.axis) ||
                    p.coordinateMode == null || !p.coordinateMode.StartsWith("pivot-local;", StringComparison.Ordinal) ||
                    !UniqueNames(p.sourceObjects) || !UniqueNames(p.visualMeshes) || !UniqueNames(p.colliderMeshes))
                    throw Invalid("Invalid R09 part source/mesh inventory: " + p.id);
                string expectedPivot = p.id == "boss_left" ? "R09V2 boss door left hinge pivot" :
                    p.id == "boss_right" ? "R09V2 boss door right hinge pivot" :
                    p.id == "bell_casting" ? "R09V5 bell | BELL_CASTING_ROCK_AXIS_X" : "R09V5 bell | SINGLE_CLAPPER_PIVOT_X";
                float[] expectedPosition = p.id == "boss_left" ? new[] { -2.4000000953674316f, 0f, .1899999976158142f } :
                    p.id == "boss_right" ? new[] { 2.4000000953674316f, 0f, .1899999976158142f } :
                    p.id == "bell_casting" ? new[] { 0f, 10.119999885559082f, 29.5f } : new[] { 0f, 9.220000267028809f, 29.5f };
                int expectedSources = p.id.StartsWith("boss_", StringComparison.Ordinal) ? 52 : p.id == "bell_casting" ? 16 : 3;
                if (!KitArchitectureProfile.Matches(room.sourceSha256)&& (p.sourcePivot != expectedPivot || !VectorNear(p.pivot, expectedPosition) || p.sourceObjects.Length != expectedSources))
                    throw Invalid("R09 canonical source pivot/complete source inventory changed: " + p.id);
                if((hall||chamber)&&(p.sourcePivot!=expectedPivot||!VectorNear(p.pivot,expectedPosition)))
                    throw Invalid("Split R09 retains its exact common-frame source pivot: "+p.id);
                var matrix = p.sourceWorldMatrixBlender;
                if (matrix == null || matrix.Length != 4 || matrix.Any(row => row == null || row.Length != 4 || row.Any(v => !Finite(v))))
                    throw Invalid("Invalid source rest matrix for " + p.id);
                for (int row = 0; row < 4; row++) for (int col = 0; col < 4; col++)
                    if (col != 3 || row == 3)
                        if (!Near(matrix[row][col], row == col ? 1 : 0, .000001f)) throw Invalid("R09 rest rotations/scales must be identity.");
                if (!VectorNear(p.pivot, new[] { matrix[0][3], matrix[2][3], matrix[1][3] }))
                    throw Invalid("R09 source matrix and Unity rest pivot differ: " + p.id);
                bool leaf = p.id.StartsWith("boss_", StringComparison.Ordinal);
                if (!VectorNear(p.axis, leaf ? new[] { 0f, 1f, 0f } : new[] { 1f, 0f, 0f })) throw Invalid("Invalid R09 local axis.");
                if (p.id == "bell_clapper")
                {
                    var parent = m.parts.Single(q => q.id == "bell_casting");
                    if (p.parentPart != parent.id || !Vector(p.parentRelativePivot) ||
                        !VectorNear(p.parentRelativePivot, p.pivot.Zip(parent.pivot, (a, b) => a - b).ToArray()))
                        throw Invalid("The single clapper must remain nested under the casting at its source rest pivot.");
                }
                else if (!string.IsNullOrEmpty(p.parentPart) || p.parentRelativePivot != null &&
                    (!Vector(p.parentRelativePivot) || p.parentRelativePivot.Any(v => Math.Abs(v) > .0001f)))
                    throw Invalid("Unexpected R09 pivot hierarchy.");
                float minimum = p.id == "boss_left" ? -90 : p.id == "boss_right" ? 0 : p.id == "bell_casting" ? -3 : -14.25f;
                float maximum = p.id == "boss_left" ? 0 : p.id == "boss_right" ? 90 : p.id == "bell_casting" ? 3 : 14.25f;
                if (!Near(p.minimumDegrees, minimum) || !Near(p.maximumDegrees, maximum)) throw Invalid("R09 checked motion bounds changed.");
            }
            var door = m.bossDoor;
            if (!chamber&&(door == null || door.leftPart != "boss_left" || door.rightPart != "boss_right" || !door.openOnE ||
                !Near(door.maximumDegrees, 90) || !Near(door.leftOpenDegrees, -90) || !Near(door.rightOpenDegrees, 90) || !Near(door.durationSeconds, 1.7f))
                )
                throw Invalid("R09 boss leaves require E, signed90degree endpoints and1.7second travel.");
            if (!hall&&(m.bell == null || m.bell.castingPart != "bell_casting" || m.bell.clapperPart != "bell_clapper" ||
                !Near(m.bell.castingMaximumDegrees, 3) || !Near(m.bell.clapperMaximumDegrees, 14.25f)))
                throw Invalid("R09 bell source bounds changed; runtime bell remains at rest.");
            CheckOwnership(room.meshes, m.parts, false);
            CheckOwnership(room.colliderMeshes, m.parts, true);
            if (m.parts.SelectMany(p => p.sourceObjects).Distinct(StringComparer.Ordinal).Count() != m.parts.Sum(p => p.sourceObjects.Length))
                throw Invalid("R09 source part ownership overlaps.");
            int socketCount = room.sockets?.Length ?? 0;
            if (room.sockets == null || (hall?socketCount!=42:chamber?socketCount!=156:socketCount < 150 || socketCount > 512 || m.encounter == null && socketCount != 150) || room.sockets.Any(s => s == null || !Name(s.name) ||
                s.name.IndexOf("FLAME_SOCKET", StringComparison.Ordinal) < 0 || !Vector(s.position)) ||
                room.sockets.Select(s => s.name).Distinct(StringComparer.Ordinal).Count() != socketCount)
                throw Invalid("R09 requires its complete distinct finite canonical candle socket inventory.");
            if(hall&&room.sockets.Any(s=>s.position[2]>=0)||chamber&&room.sockets.Any(s=>s.position[2]<0))
                throw Invalid("Split R09 wick ownership crossed its hall/chamber source boundary.");
            if(chamber&&(!Near(m.encounter.triggerZ,1.2f)||!Near(m.encounter.sequenceSeconds,5f)||!Near(m.encounter.slamDurationSeconds,.55f)))
                throw Invalid("Split R09 requires its explicit current1.2m trigger,5second wave and.55second slam.");
        }

        private static void CheckOwnership(MeshRecord[] records, R09PartRecord[] parts, bool collider)
        {
            if (records == null || records.Length == 0 || records.Any(r => r == null || !Name(r.name) ||
                r.partId != StaticPartId && !parts.Any(p=>p.id==r.partId)) || records.Select(r => r.name).Distinct(StringComparer.Ordinal).Count() != records.Length)
                throw Invalid("Invalid R09 " + (collider ? "collider" : "visual") + " part ownership.");
            foreach (var part in parts)
            {
                var declared = collider ? part.colliderMeshes : part.visualMeshes;
                var owned = records.Where(r => r.partId == part.id).Select(r => r.name).OrderBy(n => n, StringComparer.Ordinal);
                if (!owned.SequenceEqual(declared.OrderBy(n => n, StringComparer.Ordinal))) throw Invalid("R09 declared/actual chunks differ for " + part.id);
            }
        }

        private void ValidateLighting(PackageManifest room)
        {
            var m = Lighting;
            bool hall=R09SplitIdentity.IsHall(room.roomId);
            bool encounter = Interactions.encounter?.enabled == true;
            int expectedWindows = hall?0:encounter ? 16 : 8;
            if (m.schemaVersion != 1 || m.roomId != room.roomId || m.sourceSha256 != room.sourceSha256 ||
                m.windowLights == null || m.windowLights.Length != expectedWindows || room.windowLights == null || room.windowLights.Length != expectedWindows ||
                m.windowLights.Any(w => w == null || !Name(w.name)) || room.windowLights.Any(w => w == null || !Name(w.name)) ||
                m.windowLights.Select(w => w.name).Distinct(StringComparer.Ordinal).Count() != expectedWindows || room.windowLights.Select(w => w.name).Distinct(StringComparer.Ordinal).Count() != expectedWindows)
                throw Invalid("R09 requires its complete distinct window sidecar/manifest pairs.");
            WindowProjectionContract.Validate(room);
            if (encounter && (m.windowLights.Count(WindowProjectionContract.HasCookie) != 12 ||
                m.windowLights.Where(WindowProjectionContract.HasCookie).Select(w => w.projectionGroup).Distinct(StringComparer.Ordinal).Count() != 4 ||
                m.windowLights.Where(WindowProjectionContract.HasCookie).Any(w => w.position[0] <= 0 || w.position[2] < 0)))
                throw Invalid("V25 requires four right/main-room RGB glass projections plus four retained ordinary window lights.");
            foreach (var w in m.windowLights)
            {
                var actual = room.windowLights.SingleOrDefault(v => v.name == w.name);
                if (actual == null || !Vector(w.position) || !Vector(w.direction) || !Vector(w.up) || !Color(w.color) ||
                    !VectorNear(w.position, actual.position) || !VectorNear(w.direction, actual.direction) || !VectorNear(w.up, actual.up) || !VectorNear(w.color, actual.color) ||
                    w.direction.Sum(v => v * v) < .99f || Math.Abs(w.direction.Zip(w.up, (a, b) => a * b).Sum()) > .99f ||
                    !Near(w.intensity, actual.intensity) || !Near(w.range, actual.range) || !Near(w.spotAngle, actual.spotAngle) || !Near(w.innerSpotAngle, actual.innerSpotAngle) ||
                    !Near(w.shadowStrength, actual.shadowStrength) || !Near(w.shadowBias, actual.shadowBias) || !Near(w.shadowNormalBias, actual.shadowNormalBias) ||
                    !Near(w.shadowNearPlane, actual.shadowNearPlane) || w.shadowResolution != actual.shadowResolution ||
                    w.cookie != actual.cookie || w.cookieSha256 != actual.cookieSha256 || w.cookieColorSpace != actual.cookieColorSpace ||
                    w.channel != actual.channel || w.projectionGroup != actual.projectionGroup ||
                    !(w.shadowExcludeMeshes ?? Array.Empty<string>()).SequenceEqual(actual.shadowExcludeMeshes ?? Array.Empty<string>()) ||
                    !encounter && (!Near(w.intensity, 2.8f) || !Near(w.range, 18) || !Near(w.spotAngle, 75) || !Near(w.innerSpotAngle, 60) || w.shadowResolution != 512 ||
                    !Near(w.shadowStrength, .85f) || !Near(w.shadowBias, .01f) || !Near(w.shadowNormalBias, .02f) || !Near(w.shadowNearPlane, .05f) ||
                    !string.IsNullOrEmpty(w.cookie) || !string.IsNullOrEmpty(actual.cookie)))
                    throw Invalid("R09 window conversion/settings differ from the sole manifest spot: " + w.name);
            }
            var c = m.candlePolicy;
            if (c == null || c.fixtureCount != room.sockets.Length || c.shadows || !Near(c.movement, 0) || !Near(c.flickerSpeed, 1.5f) ||
                !Near(c.flickerAmplitude, .035f) || !Near(c.groupMaximumDiameter, .35f)) throw Invalid("Canonical R09 candle policy changed.");
            if(hall)
            {
                if(m.bellSpills==null||m.bellSpills.Length!=0)throw Invalid("An approach hall must not own chamber bell spills.");
                return;
            }
            if (m.bellSpills == null || m.bellSpills.Length != 3 || m.bellSpills.Any(s => s == null) ||
                m.bellSpills.Select(s => s.id).Distinct(StringComparer.Ordinal).Count() != 3 ||
                m.bellSpills.Select(s => s.sourceSocket).Distinct(StringComparer.Ordinal).Count() != 3 ||
                m.bellSpills.Select(s => s.sourceLight).Distinct(StringComparer.Ordinal).Count() != 3) throw Invalid("R09 requires three separate bell spills.");
            float[] intensities = { .2f, .14f, .1f }, ranges = { 1.6f, 1.35f, 1.05f };
            for (int i = 0; i < 3; i++)
            {
                var s = m.bellSpills.SingleOrDefault(v => v.id == "bell-crack-spill-" + (i + 1));
                if (s == null || s.type != "POINT" || s.parentPart != "bell_casting" || s.shadows || !s.stationary ||
                    s.sourceSocket != "R09V6 bell | CRACK_SPILL_SOCKET_" + (i + 1) || s.sourceLight != "R09V6 bell localized fracture spill" + (i + 1) ||
                    !Vector(s.position) || !Vector(s.worldRestPosition) ||
                    !VectorNear(s.color, new[] { 1f, .055f, .005f }) || !Near(s.intensity, intensities[i]) || !Near(s.range, ranges[i]) ||
                    !VectorNear(s.worldRestPosition, s.position.Zip(Part("bell_casting").pivot, (a, b) => a + b).ToArray()))
                    throw Invalid("Invalid bounded R09 fracture spill " + (i + 1));
            }
        }

        private static bool Name(string s) => !string.IsNullOrWhiteSpace(s) && s.Length <= 512 && !s.Any(char.IsControl);
        private static bool UniqueNames(string[] a) => a != null && a.Length > 0 && a.Length <= 4096 && a.All(Name) && a.Distinct(StringComparer.Ordinal).Count() == a.Length;
        private static bool Finite(float f) => !float.IsNaN(f) && !float.IsInfinity(f);
        private static bool Vector(float[] a) => a != null && a.Length == 3 && a.All(v => Finite(v) && Math.Abs(v) <= 256);
        private static bool Color(float[] a) => Vector(a) && a.All(v => v >= 0 && v <= 1);
        private static bool Near(float a, float b, float tolerance = .0001f) => Finite(a) && Finite(b) && Math.Abs(a - b) <= tolerance;
        private static bool VectorNear(float[] a, float[] b) => Vector(a) && Vector(b) && a.Zip(b, (x, y) => Near(x, y)).All(v => v);
        private static InvalidDataException Invalid(string text) => new InvalidDataException(text);
    }
}
