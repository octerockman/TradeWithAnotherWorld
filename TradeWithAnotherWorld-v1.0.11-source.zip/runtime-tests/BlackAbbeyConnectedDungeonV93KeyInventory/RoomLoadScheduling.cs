using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace BlackAbbeySixRooms
{
    internal sealed class RoomLoadSlice
    {
        private readonly Stopwatch clock = Stopwatch.StartNew();
        // An individual Unity texture upload / mesh cook cannot be preempted.
        // Yield between atomic operations once the slice is spent.
        internal bool Spent => clock.Elapsed.TotalMilliseconds >= 4;
        internal void Resume() => clock.Restart();
    }
    internal static class RoomLoadScheduling
    {
        [ThreadStatic] private static int diagnosticDepth;
        internal sealed class Result
        { internal Exception Error; internal double WallMilliseconds, MaximumMainStepMilliseconds; internal int Frames; }
        // Unity does not route exceptions in a yielded child iterator to its
        // parent's catch. Drive nested load iterators explicitly so failures
        // always reach our safe pre-travel rollback and busy-state cleanup.
        internal static IEnumerator Run(IEnumerator work, Result result)
        {
            var stack = new Stack<IEnumerator>(); stack.Push(work);
            var total = Stopwatch.StartNew();
            try
            {
                while (stack.Count > 0)
                {
                    bool moved = false; object current = null; var step = Stopwatch.StartNew();
                    bool outermost=diagnosticDepth++==0;
                    try { moved = stack.Peek().MoveNext(); if (moved) current = stack.Peek().Current; }
                    catch (Exception ex) { result.Error = ex; }
                    finally { diagnosticDepth--; }
                    result.MaximumMainStepMilliseconds = Math.Max(result.MaximumMainStepMilliseconds, step.Elapsed.TotalMilliseconds);
                    if(outermost)AbbeyLoadDiagnostics.SchedulerStep(step.Elapsed.TotalMilliseconds,false);
                    if (result.Error != null) break;
                    if (!moved) { (stack.Pop() as IDisposable)?.Dispose(); continue; }
                    if (current is IEnumerator child) { stack.Push(child); continue; }
                    result.Frames++; if(outermost)AbbeyLoadDiagnostics.CacheEvent("scheduler-yields");yield return current;
                }
            }
            finally
            {
                while (stack.Count > 0) (stack.Pop() as IDisposable)?.Dispose();
                result.WallMilliseconds = total.Elapsed.TotalMilliseconds;
            }
        }
        internal static Task<T> Worker<T>(Func<T> action)
        {
            var task = Task.Run(action);
            // Cancellation/logout can abandon an iterator while managed IO is
            // finishing; observe faults without touching any Unity objects.
            task.ContinueWith(t => { var observed = t.Exception; }, TaskContinuationOptions.OnlyOnFaulted);
            return task;
        }
    }
}
