namespace BlackAbbeySixRooms
{
    internal static class UnrecordedDeadFallPolicy
    {
        internal const string StairSource="4422b030492cb4698c108bca75484b3e8c51a2155e01e0dca09f1ad6c4ebc354";
        internal static bool Allows(string source,float recoveryBelow)
        {
            if(float.IsNaN(recoveryBelow)||float.IsInfinity(recoveryBelow))return false;
            var rebuilt=KitArchitectureProfile.Find(source);
            if(rebuilt!=null)return rebuilt.roomId=="R08"&&rebuilt.recoveryBelow.HasValue&&recoveryBelow==rebuilt.recoveryBelow.Value;
            if(recoveryBelow>=-35&&recoveryBelow<=-26)return true;
            // This exact deeper quest layout has a legitimate refuge at-18.4.
            // Its checked catch plane is-23; ordinary stairs keep old limits.
            return source==StairSource&&recoveryBelow==-23f;
        }
    }
}
