using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
#if !WARDING_FLOOR_TEST
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;
#endif

namespace BlackAbbeySixRooms
{
    // Exact difference clipping for the small port-owned floor overlay. All
    // source attributes travel with the edge interpolation; coordinates in Q
    // are the port-local clipping frame, Values remain source-mesh attributes.
    internal static class WardingSpawnerFloorClip
    {
        internal sealed class Vertex
        {
            internal readonly double X, Y, Z;
            internal readonly double[] Values;
            internal Vertex(double x,double y,double z,double[] values) { X=x;Y=y;Z=z;Values=values; }
            internal static Vertex Lerp(Vertex a,Vertex b,double t)
            {
                var values=new double[a.Values.Length];
                for(int i=0;i<values.Length;i++)values[i]=a.Values[i]+(b.Values[i]-a.Values[i])*t;
                return new Vertex(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t,a.Z+(b.Z-a.Z)*t,values);
            }
        }
        internal readonly struct Region
        {
            internal readonly double MinX,MaxX,MinZ,MaxZ,MinY,MaxY;
            internal Region(double minX,double maxX,double minZ,double maxZ,double minY=-.10,double maxY=.14)
            {
                if(new[]{minX,maxX,minZ,maxZ,minY,maxY}.Any(v=>double.IsNaN(v)||double.IsInfinity(v))||minX>=maxX||minZ>=maxZ||minY>=maxY)
                    throw new InvalidDataException("Invalid spawner floor clipping region.");
                MinX=minX;MaxX=maxX;MinZ=minZ;MaxZ=maxZ;MinY=minY;MaxY=maxY;
            }
        }
        static double Coordinate(Vertex v,int axis)=>axis==0?v.X:v.Z;
        static List<Vertex> Side(List<Vertex> polygon,int axis,double boundary,bool positive)
        {
            var result=new List<Vertex>();
            for(int i=0;i<polygon.Count;i++)
            {
                var a=polygon[i];var b=polygon[(i+1)%polygon.Count];
                double av=Coordinate(a,axis),bv=Coordinate(b,axis);
                bool ai=positive?av>=boundary:av<=boundary,bi=positive?bv>=boundary:bv<=boundary;
                if(ai)result.Add(a);
                if(ai!=bi)result.Add(Vertex.Lerp(a,b,(boundary-av)/(bv-av)));
            }
            return result;
        }
        internal static double Area(IReadOnlyList<Vertex> polygon)
        {
            if(polygon.Count<3)return 0;
            double sum=0;var a=polygon[0];
            for(int i=1;i+1<polygon.Count;i++)
            {
                var b=polygon[i];var c=polygon[i+1];
                double x=(b.Y-a.Y)*(c.Z-a.Z)-(b.Z-a.Z)*(c.Y-a.Y),
                    y=(b.Z-a.Z)*(c.X-a.X)-(b.X-a.X)*(c.Z-a.Z),
                    z=(b.X-a.X)*(c.Y-a.Y)-(b.Y-a.Y)*(c.X-a.X);
                sum+=Math.Sqrt(x*x+y*y+z*z)*.5;
            }
            return sum;
        }
        internal static bool Clip(Vertex a,Vertex b,Vertex c,Region r,out List<Vertex[]> retained,out double removedArea)
        {
            retained=null;removedArea=0;
            if(Math.Min(a.Y,Math.Min(b.Y,c.Y))<r.MinY||Math.Max(a.Y,Math.Max(b.Y,c.Y))>r.MaxY||
                Math.Max(a.X,Math.Max(b.X,c.X))<=r.MinX||Math.Min(a.X,Math.Min(b.X,c.X))>=r.MaxX||
                Math.Max(a.Z,Math.Max(b.Z,c.Z))<=r.MinZ||Math.Min(a.Z,Math.Min(b.Z,c.Z))>=r.MaxZ)return false;
            double nx=(b.Y-a.Y)*(c.Z-a.Z)-(b.Z-a.Z)*(c.Y-a.Y),
                ny=(b.Z-a.Z)*(c.X-a.X)-(b.X-a.X)*(c.Z-a.Z),
                nz=(b.X-a.X)*(c.Y-a.Y)-(b.Y-a.Y)*(c.X-a.X);
            double length=Math.Sqrt(nx*nx+ny*ny+nz*nz);
            if(length<1e-12||ny<.85*length)return false;
            var inside=new List<Vertex>{a,b,c};var outside=new List<Vertex[]>();
            foreach(var plane in new[]{(axis:0,bound:r.MinX,pos:true),(axis:0,bound:r.MaxX,pos:false),(axis:2,bound:r.MinZ,pos:true),(axis:2,bound:r.MaxZ,pos:false)})
            {
                if(inside.Count<3)break;
                var reject=Side(inside,plane.axis,plane.bound,!plane.pos);
                if(reject.Count>=3&&Area(reject)>1e-12)outside.Add(reject.ToArray());
                inside=Side(inside,plane.axis,plane.bound,plane.pos);
            }
            removedArea=Area(inside);
            if(removedArea<=1e-12)return false;
            retained=outside;
            return true;
        }
    }

#if !WARDING_FLOOR_TEST
    internal static class WardingSpawnerFloorRepair
    {
        readonly struct Witness
        {
            internal readonly string Source,Mesh;internal readonly int Vertices,Indices;
            internal Witness(string source,string mesh,int vertices,int indices){Source=source;Mesh=mesh;Vertices=vertices;Indices=indices;}
        }
        static readonly Dictionary<string,Witness> Sources=new Dictionary<string,Witness>(StringComparer.Ordinal)
        {
            ["R01"]=new Witness("d7e5834fd1b1d45c2f75e8b6c1b7425205c427be7e463508e37bc275247a6f94","9a524db37d5f9573d2ac019ba915be0223b0621d36869773343dd705c2855f49",440905,586650),
            ["R02"]=new Witness("c23c81a4ff07587a01eda582ec08bbd22dc2ec398b993b15330c15e3c3d7e951","6da4d730bc49ca0831e8ec726b96fc0f5916ae37a6367aa0cf451a3ea2effe53",113728,165750),
            ["R03"]=new Witness("e2f317d58dbebc201b91b00c64bee4c88a79aec891067fdbdbb96a5bf9d73cf0","819d0ba0177a1bc92349a22ba25787414f0e45056408a6323de7a9a5556748c4",287926,496812),
            ["R03_complete"]=new Witness("e4092f071c9f80b53d9afe6aef2590efa506fb1b0505e706ab132137c935c835","926bdf4e250d3467d6f690f3aff7ff82b4ae94ec6a9c99507ba97023674c9c27",287926,496812),
            ["R04"]=new Witness("6bdaa821b318ecee6ae959908273551fd5ffca860126267ba31e719b1fcef9da","e41abbdfee0b097f706ded5a291277fec171059b45f5628de2c251d2085aad04",137537,206256),
            ["R05"]=new Witness("a9af6999c6ddc49c7d0f15bb2fb96ba9057f1beeb3a660009a54367dd5291cbc","ea6c57b014195123d31a907a116c20aaddd708d56b32d9523aba3a4ca0657265",191810,332922),
            ["R06"]=new Witness("7fc31f189adb4b349a512264cf4ea5e11629a6693905071e342901e74631e323","e38cbbc035a600a3ec6402c268f24f7f708291d77a1dd76f45a1e692eca90ea8",223765,292050)
        };
        static bool Finite(float x)=>!float.IsNaN(x)&&!float.IsInfinity(x);
        static bool Same(float[] a,float[] b)=>a==null?b==null:b!=null&&a.SequenceEqual(b);
        static bool SamePort(PortRecord a,PortRecord b)=>a!=null&&b!=null&&a.id==b.id&&a.side==b.side&&a.SourceRoomId==b.SourceRoomId&&
            Same(a.position,b.position)&&Same(a.outward,b.outward)&&Same(a.outerThresholdPosition,b.outerThresholdPosition)&&
            a.width==b.width&&a.height==b.height&&a.depth==b.depth&&a.wallThickness==b.wallThickness&&a.springHeight==b.springHeight&&a.archRise==b.archRise&&
            (a.apertureProfileWidthHeight==null?b.apertureProfileWidthHeight==null:b.apertureProfileWidthHeight!=null&&a.apertureProfileWidthHeight.Length==b.apertureProfileWidthHeight.Length&&
                a.apertureProfileWidthHeight.Zip(b.apertureProfileWidthHeight,(x,y)=>Same(x,y)).All(v=>v));
        internal static void Apply(LoadedRoom room,PortRecord port,float mountDepth,string expectedSourceSha256)
        {
            if(room?.Manifest==null||!room.Root||room.Record==null||!Sources.TryGetValue(room.Manifest.roomId,out var witness)||
                expectedSourceSha256!=witness.Source||room.Manifest.sourceSha256!=witness.Source||room.Record.sourceSha256!=witness.Source||
                port==null||room.Manifest.ports==null||room.Manifest.ports.Count(p=>SamePort(p,port))!=1||port.SourceRoomId!=room.Manifest.roomId||
                !Finite(mountDepth)||mountDepth<0||!Finite(port.depth)||port.depth<mountDepth-.002f||port.depth>2)
                throw new InvalidDataException("Spawner floor repair requires its exact source room and unused port.");
            var record=room.Manifest.meshes.SingleOrDefault(m=>m.name=="architecture_floor");
            if(record==null||record.sha256!=witness.Mesh||record.vertices!=witness.Vertices||record.indices!=witness.Indices)
                throw new InvalidDataException("Spawner floor repair differs from its exact BAR1 floor witness.");
            var filters=room.Root.GetComponentsInChildren<MeshFilter>(true).Where(f=>f.name==record.name).ToArray();
            if(filters.Length!=1)throw new InvalidDataException("Spawner floor repair requires one named architecture mesh.");
            var filter=filters[0];var current=filter.sharedMesh;
            if(!current||filter.transform.parent!=room.Root.transform||filter.transform.localPosition.sqrMagnitude>1e-12f||
                Quaternion.Angle(filter.transform.localRotation,Quaternion.identity)>.00001f||(filter.transform.localScale-Vector3.one).sqrMagnitude>1e-12f)
                throw new InvalidDataException("Unexpected architecture floor transform.");
            var lifetime=room.Root.GetComponent<WardingSpawnerFloorLifetime>();
            string key=port.id+"|"+mountDepth.ToString("R",CultureInfo.InvariantCulture);
            if(lifetime&&lifetime.Original)
            {
                if(lifetime.Filter!=filter||lifetime.Current!=current||lifetime.Source!=expectedSourceSha256)
                    throw new InvalidDataException("Spawner floor derivative changed outside its owner.");
                if(lifetime.Ports.Contains(key))return;
                if(lifetime.Ports.Any(k=>k.StartsWith(port.id+"|",StringComparison.Ordinal)))throw new InvalidDataException("A port cannot silently move an existing floor override.");
            }
            else
            {
                Mesh source=current;
                var prior=room.Root.GetComponent<StoneDoorwayRoomState>();
                var trims=prior?prior.Meshes.Where(m=>m.Filter==filter).ToArray():Array.Empty<StoneDoorwayRoomState.MeshState>();
                if(trims.Length>0)
                {
                    if(trims.Length!=1||trims[0].Candidate!=current)throw new InvalidDataException("Unowned masonry derivative before spawner floor repair.");
                    source=trims[0].Original;
                }
                if(!source||source.vertexCount!=witness.Vertices||source.subMeshCount!=1||source.GetIndexCount(0)!=(uint)witness.Indices)
                    throw new InvalidDataException("Source architecture floor mesh was modified before ownership clipping.");
            }
            var origin=RoomPackage.Vector(port.position,"spawner floor port");var outward=RoomPackage.Vector(port.outward,"spawner floor outward");
            if(Math.Abs(outward.y)>.000001f||Math.Abs(outward.sqrMagnitude-1f)>.00001f)throw new InvalidDataException("Spawner floor clipping requires an unchanged horizontal unit port.");
            var right=Vector3.Cross(Vector3.up,outward);
            var region=new WardingSpawnerFloorClip.Region(-1.49,1.49,mountDepth-.002,port.depth+.10);
            var positions=current.vertices;var normals=current.normals;var uv=current.uv;var tangents=current.tangents;var colors=current.colors;
            if(normals.Length!=positions.Length||uv.Length!=positions.Length||tangents.Length!=positions.Length||colors.Length!=0&&colors.Length!=positions.Length||
                current.blendShapeCount!=0||Enumerable.Range(1,7).Any(channel=>current.HasVertexAttribute((VertexAttribute)((int)VertexAttribute.TexCoord0+channel))))
                throw new InvalidDataException("Unexpected source floor attributes; no lossy substitute was created.");
            var vertexList=new List<Vector3>(positions);var normalList=new List<Vector3>(normals);var uvList=new List<Vector2>(uv);var tangentList=new List<Vector4>(tangents);var colorList=colors.Length>0?new List<Color>(colors):null;
            var submeshes=new List<int[]>();int changed=0;
            WardingSpawnerFloorClip.Vertex Vertex(int index)
            {
                var p=positions[index];var q=p-origin;var n=normals[index];var t=tangents[index];var u=uv[index];var col=colors.Length>0?colors[index]:Color.white;
                return new WardingSpawnerFloorClip.Vertex(Vector3.Dot(q,right),q.y,Vector3.Dot(q,outward),new double[]{p.x,p.y,p.z,n.x,n.y,n.z,u.x,u.y,t.x,t.y,t.z,t.w,col.r,col.g,col.b,col.a});
            }
            int Append(WardingSpawnerFloorClip.Vertex v)
            {
                var a=v.Values;int index=vertexList.Count;
                vertexList.Add(new Vector3((float)a[0],(float)a[1],(float)a[2]));
                normalList.Add(new Vector3((float)a[3],(float)a[4],(float)a[5]).normalized);
                uvList.Add(new Vector2((float)a[6],(float)a[7]));var tangent=new Vector3((float)a[8],(float)a[9],(float)a[10]).normalized;
                tangentList.Add(new Vector4(tangent.x,tangent.y,tangent.z,a[11]<0?-1:1));
                colorList?.Add(new Color((float)a[12],(float)a[13],(float)a[14],(float)a[15]));return index;
            }
            for(int sub=0;sub<current.subMeshCount;sub++)
            {
                var indices=current.GetTriangles(sub);var kept=new List<int>(indices.Length);
                for(int i=0;i<indices.Length;i+=3)
                {
                    int ia=indices[i],ib=indices[i+1],ic=indices[i+2];
                    var pa=positions[ia]-origin;var pb=positions[ib]-origin;var pc=positions[ic]-origin;
                    double minY=Math.Min(pa.y,Math.Min(pb.y,pc.y)),maxY=Math.Max(pa.y,Math.Max(pb.y,pc.y));
                    double az=Vector3.Dot(pa,outward),bz=Vector3.Dot(pb,outward),cz=Vector3.Dot(pc,outward);
                    double ax=Vector3.Dot(pa,right),bx=Vector3.Dot(pb,right),cx=Vector3.Dot(pc,right);
                    if(minY<region.MinY||maxY>region.MaxY||Math.Max(ax,Math.Max(bx,cx))<=region.MinX||Math.Min(ax,Math.Min(bx,cx))>=region.MaxX||
                        Math.Max(az,Math.Max(bz,cz))<=region.MinZ||Math.Min(az,Math.Min(bz,cz))>=region.MaxZ||
                        !WardingSpawnerFloorClip.Clip(Vertex(ia),Vertex(ib),Vertex(ic),region,out var fragments,out _))
                    {kept.Add(ia);kept.Add(ib);kept.Add(ic);continue;}
                    changed++;
                    foreach(var polygon in fragments)for(int j=1;j+1<polygon.Length;j++)
                    {kept.Add(Append(polygon[0]));kept.Add(Append(polygon[j]));kept.Add(Append(polygon[j+1]));}
                }
                submeshes.Add(kept.ToArray());
            }
            Mesh candidate=null;
            if(changed>0)
            {
                try
                {
                    candidate=Object.Instantiate(current);candidate.name=current.name+" | warding floor owned port "+port.id;
                    if(vertexList.Count>65535)candidate.indexFormat=IndexFormat.UInt32;
                    candidate.SetVertices(vertexList);candidate.SetNormals(normalList);candidate.SetUVs(0,uvList);candidate.SetTangents(tangentList);
                    if(colorList!=null)candidate.SetColors(colorList);
                    for(int sub=0;sub<submeshes.Count;sub++)candidate.SetTriangles(submeshes[sub],sub,false);
                    candidate.RecalculateBounds();
                }
                catch{if(candidate)Object.Destroy(candidate);throw;}
            }
            lifetime=lifetime??room.Root.AddComponent<WardingSpawnerFloorLifetime>();
            if(!lifetime.Original){lifetime.Filter=filter;lifetime.Original=current;lifetime.Current=current;lifetime.Source=expectedSourceSha256;}
            lifetime.Ports.Add(key);
            if(candidate){lifetime.Owned.Add(candidate);lifetime.Current=candidate;filter.sharedMesh=candidate;}
        }
        internal static void Restore(LoadedRoom room)
        {
            if(!room?.Root)return;
            var lifetime=room.Root.GetComponent<WardingSpawnerFloorLifetime>();if(lifetime)lifetime.Restore();
        }
    }
    internal sealed class WardingSpawnerFloorLifetime:MonoBehaviour
    {
        internal MeshFilter Filter;internal Mesh Original,Current;internal string Source;
        internal readonly List<Mesh> Owned=new List<Mesh>();internal readonly HashSet<string> Ports=new HashSet<string>(StringComparer.Ordinal);
        internal void Restore()
        {
            if(Original&&Filter&&Filter.sharedMesh!=Current)throw new InvalidDataException("Spawner floor changed outside its owner before restoration.");
            if(Original&&Filter)Filter.sharedMesh=Original;
            Release();
        }
        void Release(){foreach(var mesh in Owned)if(mesh)Object.Destroy(mesh);Owned.Clear();Ports.Clear();Filter=null;Original=null;Current=null;Source=null;}
        void OnDestroy(){Release();}
    }
#endif
}
