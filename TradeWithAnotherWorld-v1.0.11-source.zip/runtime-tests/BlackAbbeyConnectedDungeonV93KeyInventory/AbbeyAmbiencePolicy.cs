using System;
using System.Collections.Generic;

namespace BlackAbbeySixRooms
{
    internal static class AbbeyAmbiencePolicy
    {
        internal const int MaxSources = 4;
        static readonly HashSet<string> Rooms = new HashSet<string>(StringComparer.Ordinal) { "R01", "R02", "R03", "R03_complete", "R04", "R05", "R06", "R07", "R08", "R09", "R09-A1", "R09-A2", "R09-B" };
        // Custom dungeon audio must not share the native world-ambient lane.
        // That lane follows AudioMan's indoor/menu snapshots. The native SFX
        // lane retains the user's normal master/SFX controls without changing
        // any mixer parameter, listener or other source.
        internal static bool IsDungeonOutputGroup(string groupName)
            => string.Equals(groupName, "SFX", StringComparison.Ordinal);
        internal static bool IsInside(bool localHost, bool worldMatches, bool ownerMatches, bool hasPlayer, bool transition, bool contained)
            => localHost && worldMatches && ownerMatches && hasPlayer && !transition && contained;
        internal static bool AllowsEvent(string roomId, string family)
        {
            if (roomId == null || !Rooms.Contains(roomId)) return false;
            switch (family)
            {
                case "bed": case "chant": case "mortar": return true;
                case "shaft": return roomId == "R08";
                case "bell": case "chain": return roomId == "R04" || roomId == "R08";
                case "wood": return roomId == "R02" || roomId == "R04" || roomId == "R06" || roomId == "R08";
                case "water": return roomId == "R01" || roomId == "R03" || roomId == "R03_complete" || roomId == "R05" || roomId == "R06";
                default: return false;
            }
        }
        // Intervals are start-to-start minimums; the runtime also permits only one voice per family.
        internal static double NextIntervalSeconds(string family, double random01)
        {
            if (double.IsNaN(random01) || double.IsInfinity(random01) || random01 < 0 || random01 > 1) throw new ArgumentOutOfRangeException(nameof(random01));
            switch (family)
            {
                case "chant": return 60 + 65 * random01;
                case "bell": return 80 + 100 * random01;
                case "chain": return 50 + 60 * random01;
                case "wood": return 45 + 55 * random01;
                case "water": return 35 + 50 * random01;
                case "mortar": return 50 + 70 * random01;
                default: throw new ArgumentException("This ambience family has no event timer.", nameof(family));
            }
        }
    }
}
