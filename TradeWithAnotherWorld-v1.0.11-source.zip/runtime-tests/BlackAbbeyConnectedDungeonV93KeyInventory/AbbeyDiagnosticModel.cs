using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;

namespace BlackAbbeySixRooms
{
    // Pure aggregation/timing only. A blocking scope MUST NOT survive a yield.
    // Exclusive wall subtracts instrumented children on the SAME thread only.
    // Worker work can overlap main work; summed work is not load elapsed/CPU.
    internal sealed class DiagnosticPhase
    {
        public string Phase, Category, Thread;
        public int Calls;
        public double InclusiveBlockingWallMs, ExclusiveBlockingWallMs, MaximumCallMs;
    }
    internal sealed class DiagnosticRoomReport
    {
        public string SourceId, DescriptiveName, InstanceId, Outcome,Role;
        public double InclusiveElapsedMs, ResourceCoroutineElapsedMs, LargestMainMoveNextMs;
        public int YieldedResourceFrames;
        public long EncodedBytesRead;
        public int LoadedVisualTriangles, LoadedColliderTriangles;
        public Dictionary<string, long> Events = new Dictionary<string, long>(StringComparer.Ordinal);
        public List<DiagnosticPhase> Phases = new List<DiagnosticPhase>();
        public double SharedBuildWorkMs => Phases.Where(p => p.Category == "shared-resource-build").Sum(p => p.ExclusiveBlockingWallMs);
        public double InstanceWorkMs => Phases.Where(p => p.Category == "placed-instance").Sum(p => p.ExclusiveBlockingWallMs);
    }
    internal sealed class DiagnosticSourceReport
    {
        public string SourceId, DescriptiveName;
        public int Instances;
        public double SummedInclusiveInstanceElapsedMs, SharedBuildWorkMs, PlacedInstanceWorkMs;
        public long EncodedBytesRead;
        public DiagnosticRoomReport[] InstancesSlowestFirst;
    }
    internal sealed class DiagnosticRoomContext
    {
        private readonly object gate = new object();
        private readonly long started = Stopwatch.GetTimestamp();
        private readonly int mainThread;
        private bool finished;
        internal volatile bool RecordingEnabled=true;
        internal readonly DiagnosticRoomReport Report;
        internal DiagnosticRoomContext(string source, string name, string instance, int mainThread,string role="placed-room")
        { this.mainThread=mainThread; Report=new DiagnosticRoomReport { SourceId=source, DescriptiveName=name, InstanceId=instance,Role=role }; }
        internal void Event(string key, long amount=1)
        { if(!RecordingEnabled)return;lock(gate) { Report.Events.TryGetValue(key,out long n); Report.Events[key]=n+amount; } }
        internal void Bytes(long count) { if(!RecordingEnabled)return;lock(gate) Report.EncodedBytesRead+=count; }
        internal void Record(string phase,string category,int thread,double inclusive,double exclusive)
        {
            if(!RecordingEnabled)return;
            lock(gate)
            {
                string threadName=thread==mainThread?"main":"managed-worker";
                var value=Report.Phases.FirstOrDefault(p=>p.Phase==phase&&p.Category==category&&p.Thread==threadName);
                if(value==null) { value=new DiagnosticPhase { Phase=phase,Category=category,Thread=threadName }; Report.Phases.Add(value); }
                value.Calls++; value.InclusiveBlockingWallMs+=inclusive; value.ExclusiveBlockingWallMs+=Math.Max(0,exclusive);
                value.MaximumCallMs=Math.Max(value.MaximumCallMs,inclusive);
            }
        }
        internal void Finish(string outcome)
        { lock(gate) { if(finished)return; finished=true; Report.Outcome=outcome; Report.InclusiveElapsedMs=DiagnosticMath.Milliseconds(started,Stopwatch.GetTimestamp()); } }
        internal DiagnosticRoomReport Snapshot()
        {
            lock(gate)
            {
                return new DiagnosticRoomReport {
                    SourceId=Report.SourceId,DescriptiveName=Report.DescriptiveName,InstanceId=Report.InstanceId,Outcome=Report.Outcome??"in-progress",Role=Report.Role,
                    InclusiveElapsedMs=finished?Report.InclusiveElapsedMs:DiagnosticMath.Milliseconds(started,Stopwatch.GetTimestamp()),
                    ResourceCoroutineElapsedMs=Report.ResourceCoroutineElapsedMs,LargestMainMoveNextMs=Report.LargestMainMoveNextMs,YieldedResourceFrames=Report.YieldedResourceFrames,
                    EncodedBytesRead=Report.EncodedBytesRead,LoadedVisualTriangles=Report.LoadedVisualTriangles,LoadedColliderTriangles=Report.LoadedColliderTriangles,
                    Events=new Dictionary<string,long>(Report.Events),Phases=Report.Phases.Select(p=>new DiagnosticPhase {
                        Phase=p.Phase,Category=p.Category,Thread=p.Thread,Calls=p.Calls,InclusiveBlockingWallMs=p.InclusiveBlockingWallMs,
                        ExclusiveBlockingWallMs=p.ExclusiveBlockingWallMs,MaximumCallMs=p.MaximumCallMs }).ToList()
                };
            }
        }
    }
    internal static class DiagnosticMath
    {
        internal static double Milliseconds(long start,long end) => (end-start)*1000.0/Stopwatch.Frequency;
        internal static double Exclusive(double inclusive,double child) => Math.Max(0,inclusive-child);
        internal static DiagnosticSourceReport[] BySource(IEnumerable<DiagnosticRoomReport> rooms)
            => rooms.GroupBy(r=>r.SourceId,StringComparer.Ordinal).Select(g=>new DiagnosticSourceReport {
                SourceId=g.Key,DescriptiveName=g.First().DescriptiveName,Instances=g.Count(),
                SummedInclusiveInstanceElapsedMs=g.Sum(r=>r.InclusiveElapsedMs),SharedBuildWorkMs=g.Sum(r=>r.SharedBuildWorkMs),
                PlacedInstanceWorkMs=g.Sum(r=>r.InstanceWorkMs),EncodedBytesRead=g.Sum(r=>r.EncodedBytesRead),
                InstancesSlowestFirst=g.OrderByDescending(r=>r.InclusiveElapsedMs).ToArray()
            }).OrderByDescending(s=>s.SummedInclusiveInstanceElapsedMs).ToArray();
        internal static double Percentile(IEnumerable<double> input,double percentile)
        { var a=input.OrderBy(x=>x).ToArray(); return a.Length==0?0:a[(int)Math.Round((a.Length-1)*Math.Max(0,Math.Min(1,percentile)))]; }
    }
    internal sealed class DiagnosticBlockingScope : IDisposable
    {
        [ThreadStatic] private static DiagnosticBlockingScope top;
        private readonly DiagnosticBlockingScope parent;
        private readonly DiagnosticRoomContext room;
        private readonly string phase,category;
        private readonly int thread;
        private readonly long start;
        private readonly Action<string,string,int,double,double> record;
        private double children;
        private bool disposed;
        internal DiagnosticBlockingScope(DiagnosticRoomContext room,string phase,string category,Action<string,string,int,double,double> record=null)
        {
            this.room=room;this.phase=phase;this.category=category;this.record=record;
            thread=Thread.CurrentThread.ManagedThreadId; parent=top;top=this;start=Stopwatch.GetTimestamp();
        }
        public void Dispose()
        {
            if(disposed)return;disposed=true;
            double inclusive=DiagnosticMath.Milliseconds(start,Stopwatch.GetTimestamp());
            // A mismatch indicates invalid use across yield/threads; don't
            // corrupt a different stack or silently claim exclusive timing.
            if(thread!=Thread.CurrentThread.ManagedThreadId||!ReferenceEquals(top,this))
            { room?.Event("invalid-timing-scope");return; }
            top=parent;if(parent!=null)parent.children+=inclusive;
            double exclusive=DiagnosticMath.Exclusive(inclusive,children);
            room?.Record(phase,category,thread,inclusive,exclusive);record?.Invoke(phase,category,thread,inclusive,exclusive);
        }
    }
}
