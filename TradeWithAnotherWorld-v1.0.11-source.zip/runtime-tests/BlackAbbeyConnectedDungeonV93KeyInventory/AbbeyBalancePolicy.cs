using System;

namespace BlackAbbeySixRooms
{
    // Pure approved balance data. A generated dungeon owns its saved tier;
    // looking up these values never queries live world progression.
    internal static class AbbeyBalancePolicy
    {
        internal const int Revision = 1, LegacyTier = 2;
        internal const float ThrallHeadMultiplier = 1.5f;
        internal const string Monk = "TWA_HushedMonk_Test", Guard = "BA_ReliquaryGuard",
            Profaned = "BA_CenserBrother", Thrall = "BA_BellThrall",
            Knight = "BA_ReliquaryKnight", Abbot = "BA_BlindAbbot";

        // Indices: no boss, Eikthyr, Elder, Bonemass, Moder, Yagluth, Queen, Fader.
        static readonly float[][] Health = {
            new[] { .6f, .8f, 1f, 1.35f, 1.8f, 2.4f, 3.1f, 4f },
            new[] { .6f, .8f, 1f, 1.5f, 2.2f, 3.1f, 4.3f, 6f },
            new[] { .6f, .8f, 1f, 1.35f, 1.8f, 2.4f, 3.1f, 4f },
            new[] { .6f, .8f, 1f, 1.35f, 1.8f, 2.4f, 3.1f, 4f },
            new[] { .6f, .8f, 1f, 1.4f, 1.9f, 2.6f, 3.5f, 4.5f },
            new[] { .6f, .8f, 1f, 1.4f, 2f, 2.8f, 3.8f, 5f }
        };
        static readonly float[][] Damage = {
            new[] { .7f, .85f, 1f, 1.4f, 2f, 2.8f, 4f, 5.5f },
            new[] { .7f, .85f, 1f, 1.3f, 1.7f, 2.3f, 3f, 4f },
            new[] { .7f, .85f, 1f, 1.35f, 1.8f, 2.5f, 3.4f, 4.5f },
            new[] { .7f, .85f, 1f, 1.2f, 1.5f, 1.9f, 2.4f, 3f },
            new[] { .7f, .85f, 1f, 1.3f, 1.75f, 2.4f, 3.3f, 4.5f },
            new[] { .7f, .85f, 1f, 1.2f, 1.5f, 1.9f, 2.4f, 3f }
        };
        // Blunt, slash, pierce, fire, frost, lightning, poison, spirit.
        static readonly float[][] Resistance = {
            new[] { 1f, 1f, 1f, 1.25f, 1f, 1f, .75f, 1.25f },
            new[] { 1.25f, .75f, .75f, 1f, 1f, 1f, .5f, 1.25f },
            new[] { 1f, 1f, 1f, .5f, 1.25f, 1f, 0f, 1.25f },
            new[] { .75f, 1f, 1f, 1f, 1f, 1f, .5f, 1.25f },
            new[] { 1.25f, .75f, .75f, 1f, 1f, 1f, .5f, 1.25f },
            new[] { 1f, 1f, 1f, .75f, 1.25f, 1f, .5f, 1.25f }
        };
        static readonly float[] Base = { 100f, 140f, 160f, 600f, 650f, 4000f };
        static readonly float[] Choking = { 1.75f, 2.125f, 2.5f, 3f, 4f, 5.5f, 7f, 9f };

        internal static bool Known(string prefab) => Index(prefab, false) >= 0;
        internal static float BaseHealth(string prefab) => Base[Index(prefab, true)];
        internal static float HealthMultiplier(string prefab, int tier)
        { RequireTier(tier); return Health[Index(prefab, true)][tier]; }
        internal static float DamageMultiplier(string prefab, int tier)
        { RequireTier(tier); return Damage[Index(prefab, true)][tier]; }
        internal static float[] Resistances(string prefab) => (float[])Resistance[Index(prefab, true)].Clone();
        internal static float ChokeDps(int tier) { RequireTier(tier); return Choking[tier]; }

        internal static void Validate(int revision, int tier)
        {
            // The missing legacy pair is distinguishable from a new no-boss tier.
            // Migration uses a fixed Elder baseline, never today's world flags.
            if (revision == 0 && tier == 0) return;
            if (revision != Revision) throw new ArgumentOutOfRangeException(nameof(revision));
            RequireTier(tier);
        }
        internal static int EffectiveTier(int revision, int tier)
        { Validate(revision, tier); return revision == 0 ? LegacyTier : tier; }
        internal static void RequireTier(int tier)
        { if (tier < 0 || tier > 7) throw new ArgumentOutOfRangeException(nameof(tier)); }
        static int Index(string prefab, bool required)
        {
            switch (prefab)
            {
                case Monk: return 0; case Guard: return 1; case Profaned: return 2;
                case Thrall: return 3; case Knight: return 4; case Abbot: return 5;
                default:
                    if (required) throw new ArgumentException("Unknown Abbey balance actor.", nameof(prefab));
                    return -1;
            }
        }
    }
}
