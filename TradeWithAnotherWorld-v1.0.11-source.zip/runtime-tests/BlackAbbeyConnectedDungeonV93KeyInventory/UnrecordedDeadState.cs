using System;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlackAbbeySixRooms
{
    internal sealed class UnrecordedDeadRooms
    {
        public string vestry, scriptorium, stair, boss;
    }
    internal sealed class UnrecordedDeadSnapshot
    {
        public int schemaVersion = 1;
        public long revision;
        public string routeId = UnrecordedDeadState.RouteId, runId, keyActor;
        public UnrecordedDeadRooms rooms;
        public bool wallBroken, cabinetOpen, panelRemoved, keyClaimed, bossUnlocked;
    }
    internal sealed class UnrecordedDeadState
    {
        internal const string RouteId = "unrecorded-dead", Key = "abbey_old_order_key";
        private UnrecordedDeadSnapshot current;
        internal string RunId => current.runId;
        internal UnrecordedDeadRooms Rooms => new UnrecordedDeadRooms { vestry=current.rooms.vestry, scriptorium=current.rooms.scriptorium, stair=current.rooms.stair, boss=current.rooms.boss };
        internal bool WallBroken => current.wallBroken;
        internal bool CabinetOpen => current.cabinetOpen;
        internal bool PanelRemoved => current.panelRemoved;
        internal bool KeyClaimed => current.keyClaimed;
        internal bool BossUnlocked => current.bossUnlocked;
        internal string KeyToken => current.runId + ":" + Key;
        internal string KeyActor => current.keyActor;
        internal UnrecordedDeadSnapshot Capture() => Copy(current);
        internal UnrecordedDeadState(UnrecordedDeadSnapshot snapshot, string runId)
        { Validate(snapshot, runId); current = Copy(snapshot); }
        internal static UnrecordedDeadSnapshot New(string run, UnrecordedDeadRooms rooms)
        { var value = new UnrecordedDeadSnapshot { runId = run, rooms = rooms }; Validate(value, run); return value; }
        private static UnrecordedDeadSnapshot Copy(UnrecordedDeadSnapshot value)
            => JsonConvert.DeserializeObject<UnrecordedDeadSnapshot>(JsonConvert.SerializeObject(value));
        private bool Change(Action<UnrecordedDeadSnapshot> edit, Func<UnrecordedDeadSnapshot, bool> commit)
        {
            if (current.revision == long.MaxValue) return false;
            var next = Copy(current); edit(next); next.revision++;
            Validate(next, current.runId);
            if (!commit(next)) return false;
            current = next; return true;
        }
        internal bool BreakWall(string room, Func<UnrecordedDeadSnapshot, bool> commit)
            => room == Rooms.vestry && (WallBroken || Change(s => s.wallBroken = true, commit));
        internal bool ToggleCabinet(string room, Func<UnrecordedDeadSnapshot, bool> commit)
            => room == Rooms.scriptorium && Change(s => s.cabinetOpen = !s.cabinetOpen, commit);
        internal bool RemovePanel(string room, Func<UnrecordedDeadSnapshot, bool> commit)
            => room == Rooms.scriptorium && CabinetOpen && (PanelRemoved || Change(s => s.panelRemoved = true, commit));
        internal bool ClaimKey(string room, string actor, Func<UnrecordedDeadSnapshot, bool> commit)
            => room == Rooms.stair && !KeyClaimed && !string.IsNullOrEmpty(actor) && Change(s => { s.keyClaimed = true; s.keyActor = actor; }, commit);
        internal bool UnlockBoss(string room, bool holdsMatchingKey, Func<UnrecordedDeadSnapshot, bool> commit)
            => room == Rooms.boss && (BossUnlocked || KeyClaimed && holdsMatchingKey && Change(s => s.bossUnlocked = true, commit));
        internal static UnrecordedDeadSnapshot Read(JObject data, string run)
        {
            if (data == null) return null;
            var allowed = typeof(UnrecordedDeadSnapshot).GetFields().Select(f => f.Name).ToArray();
            if (data.Properties().Any(p => !allowed.Contains(p.Name)) || allowed.Any(n => data.Property(n) == null))
                throw new InvalidDataException("Unrecognised or incomplete Unrecorded Dead progress; saved run retained.");
            foreach (var n in new[] { "wallBroken", "cabinetOpen", "panelRemoved", "keyClaimed", "bossUnlocked" })
                if (data[n].Type != JTokenType.Boolean) throw new InvalidDataException("Invalid Unrecorded Dead state flag.");
            if (data["schemaVersion"].Type != JTokenType.Integer || data["revision"].Type != JTokenType.Integer ||
                data["runId"].Type != JTokenType.String || data["routeId"].Type != JTokenType.String ||
                !(data["rooms"] is JObject rooms) || rooms.Properties().Count() != 4 ||
                new[] { "vestry", "scriptorium", "stair", "boss" }.Any(n => rooms[n]?.Type != JTokenType.String) ||
                data["keyActor"].Type != JTokenType.Null && data["keyActor"].Type != JTokenType.String)
                throw new InvalidDataException("Invalid Unrecorded Dead progress envelope.");
            var result = data.ToObject<UnrecordedDeadSnapshot>(); Validate(result, run); return result;
        }
        internal static void Validate(UnrecordedDeadSnapshot value, string run)
        {
            if (value == null || value.schemaVersion != 1 || value.routeId != RouteId || value.runId != run ||
                !Guid.TryParseExact(run, "N", out _) || value.revision < 0 || value.revision == long.MaxValue || value.rooms == null)
                throw new InvalidDataException("Invalid Unrecorded Dead identity or revision.");
            var rooms = new[] { value.rooms.vestry, value.rooms.scriptorium, value.rooms.stair, value.rooms.boss };
            if (rooms.Any(s => string.IsNullOrWhiteSpace(s) || s.Length > 128 || s.Any(char.IsControl)) || rooms.Distinct().Count() != 4 ||
                value.bossUnlocked && !value.keyClaimed || value.keyClaimed &&
                (!long.TryParse(value.keyActor, out long actor) || actor == 0) || !value.keyClaimed && value.keyActor != null)
                throw new InvalidDataException("Invalid Unrecorded Dead room binding or key claim.");
        }
    }
}
