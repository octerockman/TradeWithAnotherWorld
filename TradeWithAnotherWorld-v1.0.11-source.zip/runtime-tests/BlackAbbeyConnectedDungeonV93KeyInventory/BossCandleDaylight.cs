using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // R09 candle intensity only. Native CustomUpdate retains its waveform,
    // fade, accessibility multiplier and stationary flame origins. Never
    // multiply the current rendered intensity or the already-scaled cache.
    internal sealed class BossCandleDaylight : MonoBehaviour
    {
        private sealed class Binding
        {
            internal BudgetedFixture Fixture;
            internal LightFlicker Flicker;
            internal float AuthoredBase;
        }
        private static bool accessChecked;
        private static AccessTools.FieldRef<LightFlicker, float> cachedBase;
        private static AccessTools.FieldRef<LightFlicker, Light> awakeLight;
        private static string accessFailure;
        private Binding[] bindings = Array.Empty<Binding>();
        private Action<string> log;
        private bool configured, environmentWarning;
        private float gain = BossCandleDaylightPolicy.NightGain;

        internal static void Attach(LoadedRoom room, Action<string> log)
        {
            if (room == null || !room.Root || !BossCandleDaylightPolicy.Applies(room.Manifest?.roomId)) return;
            var controller = room.Root.GetComponent<BossCandleDaylight>() ?? room.Root.AddComponent<BossCandleDaylight>();
            controller.Configure(log);
        }
        private void Configure(Action<string> write)
        {
            log = write;
            if (!TryAccess())
            {
                log?.Invoke("R09_DAYLIGHT_LIGHTING_UNAVAILABLE: native cache access changed: " + accessFailure + "; ordinary candle brightness retained; travel remains available.");
                enabled = false; return;
            }
            var found = new List<Binding>();
            foreach (var fixture in GetComponentsInChildren<BudgetedFixture>(true))
            {
                if (!fixture || fixture.IsWindow || !fixture.Light) continue;
                var flicker = fixture.GetComponent<LightFlicker>();
                if (!flicker || flicker.GetComponent<Light>() != fixture.Light) continue;
                // BaseIntensity is the fixed authored profile, never a
                // previously dimmed native cache or sampled light output.
                BossCandleDaylightPolicy.BaseIntensity(fixture.BaseIntensity, 1);
                found.Add(new Binding { Fixture = fixture, Flicker = flicker, AuthoredBase = fixture.BaseIntensity });
            }
            bindings = found.ToArray();
            configured = true; gain = BossCandleDaylightPolicy.Target(ReadDay()); Apply();
            log?.Invoke("R09_DAYLIGHT_LIGHTING: fixtures=" + bindings.Length + "; currentGain=" + gain.ToString("F2") +
                "; dayGain=0.85; nightGain=1.10; transitionGameSeconds=5; authored baselines retained; native waveform/accessibility and unlit-group activation unchanged; flames/windows/censers/rift unaffected.");
        }
        private static bool TryAccess()
        {
            if (accessChecked) return cachedBase != null && awakeLight != null;
            accessChecked = true;
            try
            {
                cachedBase = AccessTools.FieldRefAccess<LightFlicker, float>("m_baseIntensity");
                awakeLight = AccessTools.FieldRefAccess<LightFlicker, Light>("m_light");
                return cachedBase != null && awakeLight != null;
            }
            catch (Exception error) { cachedBase = null; awakeLight = null; accessFailure = error.GetType().Name + ": " + error.Message; return false; }
        }
        private bool? ReadDay()
        {
            try { var environment = EnvMan.instance; if (environment) return EnvMan.IsDay(); }
            catch (Exception error)
            {
                if (!environmentWarning) log?.Invoke("R09_DAYLIGHT_ENVIRONMENT_UNAVAILABLE: " + error.Message + "; normal-brightness target retained.");
                environmentWarning = true; return null;
            }
            if (!environmentWarning) log?.Invoke("R09_DAYLIGHT_ENVIRONMENT_UNAVAILABLE: EnvMan is not ready; normal-brightness target retained.");
            environmentWarning = true; return null;
        }
        private void OnEnable()
        {
            if (!configured) return;
            gain = BossCandleDaylightPolicy.Target(ReadDay()); Apply();
        }
        private void LateUpdate()
        {
            if (!configured) return;
            gain = BossCandleDaylightPolicy.Step(gain, ReadDay(), Time.deltaTime); Apply();
        }
        private void Apply()
        {
            foreach (var row in bindings)
            {
                if (!row.Fixture || !row.Fixture.Light || !row.Flicker) continue;
                float desired = BossCandleDaylightPolicy.BaseIntensity(row.AuthoredBase, gain);
                if (!awakeLight(row.Flicker))
                {
                    // Initially dark wave groups may not run Awake until much
                    // later. Seed the live day gain BEFORE native Awake reads
                    // intensity; later cache enforcement uses the fixed base.
                    row.Fixture.Light.intensity = desired;
                }
                if (cachedBase(row.Flicker) != desired) cachedBase(row.Flicker) = desired;
            }
        }
        private void OnDisable()
        {
            if (!configured) return;
            // Release only our base gain. Native light enable/particle/wave
            // state is owned by the existing encounter and render policy.
            gain = BossCandleDaylightPolicy.NightGain; Apply();
        }
    }
}
