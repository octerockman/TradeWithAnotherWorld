using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Pure geometry shared by the Unity adapter and offline, actual-output ray tests.
    internal sealed class DoorwayGeometry
    {
        internal float[][] Positions, Normals, UV;
        internal int[] Indices;
    }
    internal static class DoorwayProfileGeometry
    {
        internal static DoorwayGeometry BuildReturn(PortRecord port)
        {
            var full = Build(port, port, .02f, true, false);
            // The first quad is exclusively the free-gap floor. A barred
            // return supplies only missing walls/roof over the existing floor.
            return new DoorwayGeometry { Positions = full.Positions.Skip(4).ToArray(), Normals = full.Normals.Skip(4).ToArray(), UV = full.UV.Skip(4).ToArray(), Indices = full.Indices.Skip(6).Select(i => i - 4).ToArray() };
        }
        internal static DoorwayGeometry Build(PortRecord a, PortRecord b, float gap, bool extendA, bool extendB)
        {
            if (gap < .005f || gap > .05f || Math.Abs(a.width - 3) > .001 || Math.Abs(b.width - 3) > .001 ||
                a.depth < .1f || a.depth > 1 || b.depth < .1f || b.depth > 1 || a.apertureProfileWidthHeight == null || b.apertureProfileWidthHeight == null)
                throw new InvalidDataException("Unsupported fitted doorway contract.");
            var positions = new List<float[]>(); var normals = new List<float[]>(); var uv = new List<float[]>(); var indices = new List<int>();
            float z0 = extendA ? -a.depth : 0, z1 = extendB ? gap + b.depth : gap;
            void Quad(float[] p, float[] q, float[] r, float[] s, float[] normal, float u0, float u1)
            {
                int start = positions.Count; double length = Math.Sqrt(normal.Sum(x => (double)x * x));
                if (length < 1e-12) throw new InvalidDataException("Degenerate fitted doorway normal.");
                normal = normal.Select(x => (float)(x / length)).ToArray();
                positions.AddRange(new[] { p, q, r, s }); normals.AddRange(new[] { normal, normal, normal, normal });
                uv.AddRange(new[] { new[] { u0, p[2] }, new[] { u1, q[2] }, new[] { u1, r[2] }, new[] { u0, s[2] } });
                var v = new[] { q[0] - p[0], q[1] - p[1], q[2] - p[2] }; var w = new[] { r[0] - p[0], r[1] - p[1], r[2] - p[2] };
                double dot = (v[1] * w[2] - v[2] * w[1]) * normal[0] + (v[2] * w[0] - v[0] * w[2]) * normal[1] + (v[0] * w[1] - v[1] * w[0]) * normal[2];
                indices.AddRange(dot > 0 ? new[] { start, start + 1, start + 2, start, start + 2, start + 3 } : new[] { start, start + 2, start + 1, start, start + 3, start + 2 });
            }
            const float half = 1.53f;
            Quad(new[] { -half, 0f, 0f }, new[] { half, 0f, 0f }, new[] { half, 0f, gap }, new[] { -half, 0f, gap }, new[] { 0f, 1f, 0f }, 0, half * 2);
            var xs = new SortedSet<float>(new[] { -1.5f, 1.5f });
            foreach (var p in a.apertureProfileWidthHeight.Concat(b.apertureProfileWidthHeight))
                if (p?.Length == 2 && p[0] >= -1.5f && p[0] <= 1.5f) xs.Add(p[0]);
            for (int i = 0; i <= 32; i++) xs.Add(-1.5f + 3f * i / 32f);
            // Source arc samples include near-zero sin/cos residues. Coalesce
            // sub-10um X intervals so they cannot create zero-area sliver faces.
            var clean = new List<float>();
            foreach (float x in xs)
            {
                if (clean.Count == 0 || x - clean[clean.Count - 1] >= .00001f) clean.Add(x);
                else if (Math.Abs(x) < Math.Abs(clean[clean.Count - 1])) clean[clean.Count - 1] = x;
            }
            var profile = clean.Select(x => new[] { x * (half / 1.5f), Math.Max(Height(a, x), Height(b, x)) + .03f }).ToArray();
            float distance = 0;
            for (int i = 0; i + 1 < profile.Length; i++)
            {
                var p = profile[i]; var q = profile[i + 1]; float dx = q[0] - p[0], dy = q[1] - p[1];
                float next = distance + (float)Math.Sqrt(dx * dx + dy * dy);
                Quad(new[] { p[0], p[1], z0 }, new[] { q[0], q[1], z0 }, new[] { q[0], q[1], z1 }, new[] { p[0], p[1], z1 }, new[] { dy, -dx, 0f }, distance, next); distance = next;
            }
            float left = profile[0][1], right = profile[profile.Length - 1][1];
            Quad(new[] { -half, 0f, z0 }, new[] { -half, left, z0 }, new[] { -half, left, z1 }, new[] { -half, 0f, z1 }, new[] { 1f, 0f, 0f }, 0, left);
            Quad(new[] { half, 0f, z0 }, new[] { half, right, z0 }, new[] { half, right, z1 }, new[] { half, 0f, z1 }, new[] { -1f, 0f, 0f }, 0, right);
            return new DoorwayGeometry { Positions = positions.ToArray(), Normals = normals.ToArray(), UV = uv.ToArray(), Indices = indices.ToArray() };
        }
        internal static float Height(PortRecord port, float x)
        {
            float result = float.NegativeInfinity; var p = port.apertureProfileWidthHeight;
            for (int i = 0; i < p.Length; i++)
            {
                int next = (i + 1) % p.Length;
                if (p[i]?.Length != 2 || p[next]?.Length != 2) throw new InvalidDataException("Invalid aperture coordinate.");
                float x0 = p[i][0], x1 = p[next][0];
                if (x < Math.Min(x0, x1) - .00001f || x > Math.Max(x0, x1) + .00001f) continue;
                float y = Math.Abs(x1 - x0) < .00001f ? Math.Max(p[i][1], p[next][1]) : p[i][1] + (p[next][1] - p[i][1]) * ((x - x0) / (x1 - x0));
                result = Math.Max(result, y);
            }
            if (float.IsNaN(result) || float.IsInfinity(result) || result < 1.9f || result > 3.6f) throw new InvalidDataException("Invalid port roof profile.");
            return result;
        }
    }
}
