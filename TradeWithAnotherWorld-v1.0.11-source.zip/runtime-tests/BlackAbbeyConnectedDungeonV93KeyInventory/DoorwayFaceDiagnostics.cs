using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Newtonsoft.Json;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Read-only evidence. No repair is guessed from an ambiguous screenshot.
    // Snapshot happens before E prewarm or door motion, so hidden presentation
    // state cannot be concealed by the interaction itself. Never throws into E.
    internal static class DoorwayFaceDiagnostics
    {
        internal static Action<AbbeyDoor> Capture;
        internal static void Observe(AbbeyDoor door)
        {try{Capture?.Invoke(door);}catch(Exception e){Debug.LogWarning("DOORWAY_FACE_DIAGNOSTIC_FAILED: "+e.GetType().Name+": "+e.Message);}}
        internal const int MaximumHashedVertices=65536;
        internal static float[] V(Vector3 v)=>new[]{v.x,v.y,v.z};
        internal static object Box(Bounds b)=>new{center=V(b.center),size=V(b.size),min=V(b.min),max=V(b.max)};
        private static string Digest(Action<BinaryWriter> write)
        {using(var memory=new MemoryStream()){using(var w=new BinaryWriter(memory,System.Text.Encoding.UTF8,true)){write(w);w.Flush();}memory.Position=0;using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(memory)).Replace("-","").ToLowerInvariant();}}
        private static object MaterialState(Material m)
        {
            if(!m)return null;
            var properties=new Dictionary<string,float>();foreach(var p in new[]{"_Mode","_Cull","_CullMode","_ZWrite","_SrcBlend","_DstBlend","_Cutoff","_Glossiness","_Metallic"})if(m.HasProperty(p))properties[p]=m.GetFloat(p);
            var colors=new Dictionary<string,float[]>();foreach(var p in new[]{"_Color","_EmissionColor"})if(m.HasProperty(p)){var c=m.GetColor(p);colors[p]=new[]{c.r,c.g,c.b,c.a};}
            var textures=new Dictionary<string,object>();foreach(var p in new[]{"_MainTex","_BumpMap","_MetallicGlossMap","_EmissionMap"})if(m.HasProperty(p)){var t=m.GetTexture(p);textures[p]=t?new{name=t.name,width=t.width,height=t.height,offset=new[]{m.GetTextureOffset(p).x,m.GetTextureOffset(p).y},scale=new[]{m.GetTextureScale(p).x,m.GetTextureScale(p).y}}:null;}
            return new{name=m.name,shader=m.shader?m.shader.name:null,supported=m.shader&&m.shader.isSupported,m.renderQueue,renderType=m.GetTag("RenderType",false,""),keywords=m.shaderKeywords,properties,colors,textures};
        }
        internal static object MeshState(MeshFilter f,MeshRecord source=null)
        {
            var r=f?f.GetComponent<MeshRenderer>():null;var m=f?f.sharedMesh:null;if(!f||!m)return new{missingMesh=true};
            var remainder=f.GetComponent<PewSourceRemainder>();
            string indexHash=null,frameHash=null,error=null;int? normalRows=null,uvRows=null,tangentRows=null,colorRows=null,opposed=null,degenerate=null;
            try
            {
                // Every actual index stream is hashed, including large room
                // batches with quest/pew masks. Full mapped frames are bounded
                // to avoid a diagnostic allocation spike during an E press.
                var indices=m.triangles;indexHash=Digest(w=>{w.Write(indices.Length);foreach(var i in indices)w.Write(i);});
                if(m.vertexCount<=MaximumHashedVertices)
                {
                    var p=m.vertices;var n=m.normals;var uv=m.uv;var t=m.tangents;var c=m.colors32;normalRows=n.Length;uvRows=uv.Length;tangentRows=t.Length;colorRows=c.Length;
                    frameHash=Digest(w=>{w.Write(p.Length);foreach(var v in p){w.Write(v.x);w.Write(v.y);w.Write(v.z);}w.Write(n.Length);foreach(var v in n){w.Write(v.x);w.Write(v.y);w.Write(v.z);}w.Write(uv.Length);foreach(var v in uv){w.Write(v.x);w.Write(v.y);}w.Write(t.Length);foreach(var v in t){w.Write(v.x);w.Write(v.y);w.Write(v.z);w.Write(v.w);}w.Write(c.Length);foreach(var v in c){w.Write(v.r);w.Write(v.g);w.Write(v.b);w.Write(v.a);}w.Write(indices.Length);foreach(var i in indices)w.Write(i);});
                    int bad=0,flat=0;for(int k=0;k<indices.Length;k+=3){int a=indices[k],b=indices[k+1],d=indices[k+2];var cross=Vector3.Cross(p[b]-p[a],p[d]-p[a]);if(cross.sqrMagnitude<1e-16f)flat++;if(n.Length==p.Length&&Vector3.Dot(cross,(n[a]+n[b]+n[d])/3)<-1e-7f)bad++;}opposed=bad;degenerate=flat;
                }
            }catch(Exception e){error=e.GetType().Name+": "+e.Message;}
            return new{name=f.name,mesh=m.name,m.vertexCount,indexCount=m.GetIndexCount(0),localBounds=Box(m.bounds),worldBounds=r?Box(r.bounds):null,
                active=f.gameObject.activeInHierarchy,enabled=r&&r.enabled,forceRenderingOff=r&&r.forceRenderingOff,
                namedQuestSourceMask=m.name.IndexOf("false-vows source mask",StringComparison.OrdinalIgnoreCase)>=0,
                position=V(f.transform.position),scale=V(f.transform.lossyScale),forward=V(f.transform.forward),indexHash,frameHash,
                frameHashScope=frameHash==null?"Not sampled: above bounded vertex count or read error; actual index hash and frozen source SHA provided":"positions, normals, UV0, tangents, colors32, index stream; length-prefixed little-endian",
                normalRows,uvRows,tangentRows,colorRows,trianglesOpposedToAuthoredNormals=opposed,degenerateTriangles=degenerate,error,
                source=source==null?null:new{name=source.name,source.sha256,source.vertices,source.indices,source.meshFile},
                remainder=remainder?new{remainder.OriginalMeshSha256,remainder.OriginalIndexCount,remainder.DerivedSourceIndexCount,retainedOriginalTriangles=remainder.OriginalTriangles?.Length,hasRepairProof=remainder.RepairProof!=null}:null,
                materials=r?r.sharedMaterials.Select(MaterialState).ToArray():null};
        }
    }
    public sealed partial class RuntimeTestPlugin
    {
        private float nextDoorwayFaceDiagnostic=-1;
        private Action<AbbeyDoor> doorwayFaceCapture;
        private void ShutdownDoorwayFaceDiagnostics()
        {if(ReferenceEquals(DoorwayFaceDiagnostics.Capture,doorwayFaceCapture))DoorwayFaceDiagnostics.Capture=null;doorwayFaceCapture=null;}
        private void InitializeDoorwayFaceDiagnostics()
        {
            doorwayFaceCapture=door=>{if(this&&enabled)CaptureDoorwayFaces(door,false);};DoorwayFaceDiagnostics.Capture=doorwayFaceCapture;
            Add("twa_test_door_faces","Save read-only live mesh/material/visibility evidence for the nearest great oak door. No changes.",false,()=>{
                var player=Player.m_localPlayer;var door=player?dungeonDoors.Values.Where(d=>d).OrderBy(d=>(d.transform.position-player.transform.position).sqrMagnitude).FirstOrDefault():null;
                try{if(!door||!CaptureDoorwayFaces(door,true))Print("Stand near a loaded Abbey great oak door first.");}catch(Exception e){Logger.LogWarning("DOORWAY_FACE_DIAGNOSTIC_FAILED: "+e.Message);Print("Door evidence could not be written; see the log. No changes.");}
            });
        }
        private bool CaptureDoorwayFaces(AbbeyDoor door,bool manual)
        {
            var player=Player.m_localPlayer;if(!door||!player||dungeonPlan==null||(player.transform.position-door.transform.position).sqrMagnitude>36||(!manual&&Time.unscaledTime<nextDoorwayFaceDiagnostic))return false;
            var edge=dungeonDoors.FirstOrDefault(p=>p.Value==door).Key;
            string a=edge!=null?dungeonPlan.Rooms[edge.A].Spec.Id:null,b=edge!=null?dungeonPlan.Rooms[edge.B].Spec.Id:null;
            if(a==null){var owner=rooms.Values.FirstOrDefault(r=>r.Root&&door.transform.IsChildOf(r.Root.transform));a=owner?.InstanceId;}
            if(a==null)return false;nextDoorwayFaceDiagnostic=Time.unscaledTime+20;
            var bounds=new Bounds(door.transform.position+Vector3.up*2,new Vector3(6,6,6));var camera=Camera.main;
            var roots=new List<object>();
            foreach(var id in new[]{a,b}.Where(x=>x!=null).Distinct())if(rooms.TryGetValue(id,out var room)&&room.Root)
            {
                var records=new List<object>();foreach(var rec in room.Manifest.meshes){var child=room.Root.transform.Find(rec.name);var filter=child?child.GetComponent<MeshFilter>():null;var renderer=filter?filter.GetComponent<MeshRenderer>():null;if(renderer&&renderer.bounds.Intersects(bounds))records.Add(new{sourceRanges=StairCollarRepair.DescribeRanges(room,rec),runtime=DoorwayFaceDiagnostics.MeshState(filter,rec)});}
                roots.Add(new{role="room",instance=id,room.Manifest.roomId,room.Manifest.sourceSha256,room.Record.manifestSha256,room.Record.packageDirectory,active=room.Root.activeInHierarchy,localBounds=new{min=room.Manifest.boundsMin,max=room.Manifest.boundsMax},position=DoorwayFaceDiagnostics.V(room.Root.transform.position),forward=DoorwayFaceDiagnostics.V(room.Root.transform.forward),sourceRangePayload=StairCollarRepair.PayloadSha256,meshes=records});
            }
            if(dungeonArt)foreach(var owner in dungeonArt.GetComponentsInChildren<PortalVisualOwners>(true).Where(o=>o.A==a||o.A==b||o.B==a||o.B==b))
                roots.Add(new{role="shared-art",name=owner.name,owner.A,owner.B,active=owner.gameObject.activeInHierarchy,meshes=owner.GetComponentsInChildren<MeshFilter>(true).Where(f=>f.GetComponent<MeshRenderer>()).Select(f=>DoorwayFaceDiagnostics.MeshState(f)).ToArray()});
            var report=new{schema="black-abbey-live-doorway-faces-v91",version=Version,utc=DateTime.UtcNow.ToString("O"),trigger=manual?"manual-nearest-door":"before-E-prewarm-and-motion",seed=dungeonPlan.Seed,
                door=new{name=door.name,door.IsBarred,door.IsOpen,door.IsMoving,door.VisibleThrough,position=DoorwayFaceDiagnostics.V(door.transform.position),forward=DoorwayFaceDiagnostics.V(door.transform.forward)},
                link=edge==null?null:new{a,b,portA=edge.PortA.id,portB=edge.PortB.id,edge.Kind,start=new[]{edge.Start.X,edge.Start.Z},end=new[]{edge.End.X,edge.End.Z},edge.Elevation},
                playerPosition=DoorwayFaceDiagnostics.V(player.transform.position),camera=camera?new{position=DoorwayFaceDiagnostics.V(camera.transform.position),forward=DoorwayFaceDiagnostics.V(camera.transform.forward),camera.nearClipPlane,camera.farClipPlane,camera.cullingMask}:null,
                presentation=renderBudget?renderBudget.DescribeOwners(a,b):null,roots,notes=new[]{"Read-only diagnostic, not a geometry fix or game validation.","Index hashes include current runtime masks. Frame hashes are bounded to65536vertices; large batches retain exact source SHA and actual index hash.","Snapshot is taken before door E prewarm; renderer.enabled and forceRenderingOff are recorded independently.","No world/run, inventory, transform, collider, renderer, material, culling or quality state changed."}};
            string directory=Path.Combine(Path.GetDirectoryName(PluginStoragePaths.WorldDoorDirectory(AssemblyPath,BepInEx.Paths.PluginPath)),"diagnostics");Directory.CreateDirectory(directory);
            string path=Path.Combine(directory,"doorway-faces-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmssfff")+".json");File.WriteAllText(path,JsonConvert.SerializeObject(report,Formatting.Indented));
            Logger.LogInfo("DOORWAY_FACE_DIAGNOSTIC: "+a+"/"+(edge?.PortA?.id??"unlinked")+" -> "+(b??"closed branch")+"; captured before prewarm/motion; report="+path+"; render state/actual mesh indices/facing/materials only; no changes.");return true;
        }
    }
}
