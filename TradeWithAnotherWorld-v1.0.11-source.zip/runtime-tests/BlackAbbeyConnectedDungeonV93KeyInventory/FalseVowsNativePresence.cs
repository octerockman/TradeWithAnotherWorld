using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Read-only reconciliation of native inventories and native ZDO records.
    // At most six token witnesses are retained; the world result batch clears
    // every step. No scene-wide search, native save, spawn or state write.
    internal sealed class FalseVowsNativePresence : IDisposable
    {
        private const int MaxBatch = 4096, MaxQueries = 2048, MaxInventoryBytes = 8 * 1024 * 1024;
        private static readonly HashSet<FalseVowsNativePresence> instances = new HashSet<FalseVowsNativePresence>();
        private static Harmony containerHook;
        private readonly Action<string> log;
        private readonly RuntimeWorldIdentity worldReader = new RuntimeWorldIdentity(typeof(ZNet), (t, n) => AccessTools.Method(t, n), (t, n) => AccessTools.Field(t, n));
        private readonly FalseVowsPresenceWindow window = new FalseVowsPresenceWindow();
        private readonly List<ZDO> batch = new List<ZDO>();
        private readonly Dictionary<Inventory, Action> subscriptions = new Dictionary<Inventory, Action>();
        private readonly Dictionary<string, Witness> witnesses = new Dictionary<string, Witness>(StringComparer.Ordinal);
        private ZNet network; private ZDOMan manager; private ZNetScene scene; private Player local;
        private string worldKey, runId, localId; private string[] participants = Array.Empty<string>();
        private Query[] queries = Array.Empty<Query>(); private int queryIndex, cursor, lastFrame = -1, registryCount;
        private float nextBatch, finishedAt;
        private bool scanning, disposed, catalogValid;
        private sealed class Query { internal string Name; internal int Hash, Width, Height; internal bool Container; }
        private sealed class Witness { internal ZDOID Id; internal Query Query; }

        // Must report true/false only after checking the complete saved local
        // R07 inventories (including unloaded rooms). null means hold. Native
        // ZDO absence alone does not cover those unnetworked local containers.
        internal Func<string, string, bool?> AdditionalPresence { get; set; }

        internal FalseVowsNativePresence(Action<string> write)
        {
            log = write; instances.Add(this);
            if (containerHook == null)
            {
                containerHook = new Harmony("studio.otherworld.blackabbeyroomtest.false-vows-presence");
                containerHook.Patch(AccessTools.Method(typeof(Container), "Save"), postfix: new HarmonyMethod(typeof(FalseVowsNativePresence), nameof(ContainerSaved)));
            }
        }
        private static void ContainerSaved() { foreach (var item in instances.ToArray()) item.Invalidate(); }
        internal void Begin(string currentRunId, string[] possibleParticipantIds)
        {
            if (disposed) throw new ObjectDisposedException(nameof(FalseVowsNativePresence));
            if (string.IsNullOrWhiteSpace(currentRunId) || currentRunId.Length > 128 || possibleParticipantIds == null || possibleParticipantIds.Length > 128 || possibleParticipantIds.Any(string.IsNullOrWhiteSpace))
                throw new ArgumentException("A bounded run and complete possible participant identities are required.");
            Unsubscribe(); runId = currentRunId; participants = possibleParticipantIds.Distinct(StringComparer.Ordinal).ToArray();
            network = ZNet.instance; manager = ZDOMan.instance; scene = ZNetScene.instance; local = Player.m_localPlayer;
            localId = local ? local.GetPlayerID().ToString(CultureInfo.InvariantCulture) : null;
            try { worldKey = network ? worldReader.Read(network) : null; } catch { worldKey = null; }
            Invalidate(); BuildQueries(); RefreshPlayers();
        }
        internal void Invalidate()
        {
            if (disposed) return;
            window.Invalidate(); scanning = false; queryIndex = cursor = 0;
            batch.Clear(); witnesses.Clear(); nextBatch = 0; finishedAt = 0;
        }
        private bool Scope()
        {
            if (disposed || string.IsNullOrEmpty(runId) || !network || network != ZNet.instance || !network.IsServer() || manager == null || manager != ZDOMan.instance || !scene || scene != ZNetScene.instance || !local || local != Player.m_localPlayer || string.IsNullOrEmpty(localId) || localId == "0" || local.GetPlayerID().ToString(CultureInfo.InvariantCulture) != localId || !FalseVowsItems.Ready || string.IsNullOrEmpty(worldKey)) return false;
            try { return worldReader.Read(network) == worldKey; } catch { return false; }
        }
        private Dictionary<int, GameObject> Registry()
            => scene ? AccessTools.Field(typeof(ZNetScene), "m_namedPrefabs")?.GetValue(scene) as Dictionary<int, GameObject> : null;
        private void BuildQueries()
        {
            catalogValid = false; queries = Array.Empty<Query>();
            try
            {
                var registry = Registry(); if (registry == null) return;
                registryCount = registry.Count;
                var values = new Dictionary<int, Query>();
                foreach (var definition in FalseVowsItemCatalog.All)
                {
                    int hash = definition.Id.GetStableHashCode();
                    if (!registry.TryGetValue(hash, out var prefab) || !prefab || !prefab.GetComponent<ItemDrop>()) return;
                    if (prefab.name.GetStableHashCode() != hash) return;
                    values.Add(hash, new Query { Name = prefab.name, Hash = hash });
                }
                foreach (var pair in registry)
                {
                    if (!pair.Value) continue;
                    var containers = pair.Value.GetComponentsInChildren<Container>(true);
                    if (containers.Length == 0) continue;
                    var first = containers[0];
                    if (pair.Value.name.GetStableHashCode() != pair.Key) return;
                    values[pair.Key] = new Query { Name = pair.Value.name, Hash = pair.Key, Container = true, Width = Math.Max(1, first.m_width), Height = Math.Max(1, first.m_height) };
                    if (values.Count > MaxQueries) { log?.Invoke("FALSE_VOWS_PRESENCE_HELD: registered container catalog exceeds bounded scan capacity."); return; }
                }
                if (values.Count > MaxQueries) { log?.Invoke("FALSE_VOWS_PRESENCE_HELD: registered container catalog exceeds bounded scan capacity."); return; }
                queries = values.Values.OrderBy(q => q.Container).ThenBy(q => q.Name, StringComparer.Ordinal).ToArray();
                catalogValid = true;
            }
            catch (Exception e) { log?.Invoke("FALSE_VOWS_PRESENCE_HELD: cannot inspect registered native containers: " + e.Message); }
        }
        private Player[] RefreshPlayers()
        {
            var players = Player.GetAllPlayers().Where(p => p).ToList();
            if (Player.m_localPlayer && !players.Contains(Player.m_localPlayer)) players.Add(Player.m_localPlayer);
            var inventories = new HashSet<Inventory>(players.Select(p => p.GetInventory()).Where(i => i != null));
            bool changed = false;
            foreach (var old in subscriptions.Keys.Where(i => !inventories.Contains(i)).ToArray()) { old.m_onChanged -= subscriptions[old]; subscriptions.Remove(old); changed = true; }
            foreach (var inventory in inventories)
                if (!subscriptions.ContainsKey(inventory)) { Action callback = Invalidate; inventory.m_onChanged += callback; subscriptions.Add(inventory, callback); changed = true; }
            if (changed) Invalidate();
            return players.ToArray();
        }
        private bool ProfilesChecked(Player[] players, Player owner)
        {
            if (!owner || owner != local || owner != Player.m_localPlayer || participants.Length == 0 || !participants.Contains(owner.GetPlayerID().ToString(CultureInfo.InvariantCulture), StringComparer.Ordinal)) return false;
            foreach (string id in participants)
            {
                var player = players.FirstOrDefault(p => p.GetPlayerID().ToString(CultureInfo.InvariantCulture) == id);
                // A remote Player proxy does not promise a complete native
                // player profile inventory, even if that proxy is online.
                if (!player || player != Player.m_localPlayer || player.GetInventory() == null || player.IsDead()) return false;
            }
            return players.All(p => p == Player.m_localPlayer);
        }
        private static bool Tagged(ItemDrop.ItemData item, string id, string run, string token)
            => item != null && item.m_stack > 0 && FalseVowsItems.Id(item) == id && FalseVowsItemIdentity.Matches(item.m_customData, run, token);
        private bool InventoryHas(Inventory inventory, string id, string token)
            => inventory != null && inventory.GetAllItems().Any(i => Tagged(i, id, runId, token));
        private void Observe(Inventory inventory, Query query, ZDOID uid)
        {
            if (inventory == null) { window.Uncertain(); return; }
            foreach (var item in inventory.GetAllItems())
            {
                var id = FalseVowsItems.Id(item); if (id == null) continue;
                string token = runId + ":" + id;
                if (Tagged(item, id, runId, token)) witnesses[token] = new Witness { Id = uid, Query = query };
            }
        }
        private bool Read(ZDO zdo, Query query, string onlyId = null, string onlyToken = null)
        {
            if (zdo == null || zdo.GetPrefab() != query.Hash) return false;
            try
            {
                var live = scene.FindInstance(zdo.m_uid);
                if (query.Container)
                {
                    // Loaded native inventories are fresher than serialized
                    // bytes during a transfer's current callback chain.
                    var containers = live ? live.GetComponentsInChildren<Container>(true) : Array.Empty<Container>();
                    if (containers.Length > 0)
                    {
                        bool found = false;
                        foreach (var container in containers)
                        {
                            var inventory = container.GetInventory();
                            if (onlyId != null) { if (inventory == null) window.Uncertain(); else found |= InventoryHas(inventory, onlyId, onlyToken); }
                            else Observe(inventory, query, zdo.m_uid);
                        }
                        return found;
                    }
                    var bytes = zdo.GetByteArray(ZDOVars.s_items, null);
                    // Native Container.Load explicitly treats no s_items as
                    // an empty inventory. Corrupt/nonempty data is uncertain.
                    if (bytes == null) return false;
                    if (bytes.Length == 0 || bytes.Length > MaxInventoryBytes) { window.Uncertain(); return false; }
                    var decoded = new Inventory("False Vows native presence scan", null, Math.Min(64, query.Width), Math.Min(64, query.Height));
                    decoded.Load(new ZPackage(bytes));
                    if (onlyId != null) return InventoryHas(decoded, onlyId, onlyToken);
                    Observe(decoded, query, zdo.m_uid); return false;
                }
                var data = zdo.GetByteArray(ZDOVars.s_itemData, null);
                if (data == null || data.Length < 3 || data.Length > MaxInventoryBytes) { window.Uncertain(); return false; }
                FalseVowsItems.TryReadWorldItem(zdo, out var item);
                if (item == null) { window.Uncertain(); return false; }
                var id = FalseVowsItems.Id(item);
                if (onlyId != null) return Tagged(item, onlyId, runId, onlyToken);
                if (id != null && Tagged(item, id, runId, runId + ":" + id)) witnesses[runId + ":" + id] = new Witness { Id = zdo.m_uid, Query = query };
                return false;
            }
            catch (Exception e) { window.Uncertain(); log?.Invoke("FALSE_VOWS_PRESENCE_HELD: unreadable native item/container record " + zdo.m_uid + ": " + e.Message); return false; }
        }
        internal bool? Presence(Player owner, string itemId, string token)
        {
            if (!Scope() || !owner || owner != local || FalseVowsItemCatalog.Find(itemId) == null || token != runId + ":" + itemId) return null;
            var players = RefreshPlayers();
            if (players.Any(p => InventoryHas(p.GetInventory(), itemId, token))) return true;
            bool? external = null;
            try { external = AdditionalPresence?.Invoke(itemId, token); } catch { external = null; }
            if (external == true) return true;
            if (witnesses.TryGetValue(token, out var witness))
            {
                if (Read(manager.GetZDO(witness.Id), witness.Query, itemId, token)) return true;
                // A stale positive may have moved elsewhere since our scan.
                // Revoke absence and rescan; never turn its disappearance into
                // a negative answer in the same call.
                Invalidate(); return null;
            }
            return window.Absence(Scope(), ProfilesChecked(players, owner), external == false, window.Complete && Time.unscaledTime - finishedAt <= 2f);
        }
        internal void Tick()
        {
            if (disposed) return;
            if (!Scope()) { Invalidate(); return; }
            RefreshPlayers();
            var registry = Registry();
            if (registry == null) { Invalidate(); catalogValid = false; return; }
            if (registry.Count != registryCount) { Invalidate(); BuildQueries(); }
            if (!catalogValid) return;
            if (window.Complete)
            {
                if (Time.unscaledTime - finishedAt <= 2f) return;
                Invalidate();
            }
            if (Time.frameCount == lastFrame || Time.unscaledTime < nextBatch) return;
            lastFrame = Time.frameCount; nextBatch = Time.unscaledTime + .1f;
            if (!scanning) { scanning = true; queryIndex = cursor = 0; window.Start(); }
            var query = queries[queryIndex];
            try
            {
                batch.Clear();
                bool done = manager.GetAllZDOsWithPrefabIterative(query.Name, batch, ref cursor);
                if (batch.Count > MaxBatch) window.Uncertain();
                for (int i = 0; i < Math.Min(batch.Count, MaxBatch); i++) Read(batch[i], query);
                batch.Clear();
                if (done) { queryIndex++; cursor = 0; }
                if (queryIndex == queries.Length) { scanning = false; finishedAt = Time.unscaledTime; window.Finish(); }
            }
            catch (Exception e) { batch.Clear(); window.Uncertain(); scanning = false; finishedAt = Time.unscaledTime; window.Finish(); log?.Invoke("FALSE_VOWS_PRESENCE_HELD: native scan incomplete: " + e.Message); }
        }
        private void Unsubscribe() { foreach (var pair in subscriptions) pair.Key.m_onChanged -= pair.Value; subscriptions.Clear(); }
        public void Dispose()
        {
            if (disposed) return;
            Unsubscribe(); witnesses.Clear(); batch.Clear(); queries = Array.Empty<Query>(); disposed = true;
            instances.Remove(this); if (instances.Count == 0) { containerHook?.UnpatchSelf(); containerHook = null; }
        }
    }
}
