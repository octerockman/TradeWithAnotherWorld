using System;
using System.Collections;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    internal sealed class RuntimeExtraAssets : IDisposable
    {
#pragma warning disable 0649
        private sealed class Config
        {
            public int schemaVersion;
            public string doorDirectory, doorManifestSha256, doorwayDirectory, doorwayManifestSha256, trimFile, trimSha256;
        }
#pragma warning restore 0649
        internal AbbeyDoorAssets Doors;
        internal LoadedRoom DoorwayKit;
        internal string TrimPath;
        private StoneDoorwayKit.TrimMapLease trimLease;
        private sealed class Prepared
        {
            internal StoneDoorwayKit.PreparedTrimMap Trim;
            internal AbbeyDoorAssets.Prepared Doors;
            internal string StoneDirectory;
            internal CatalogRoomRecord StoneRecord;
        }
        internal static RuntimeExtraAssets Load(string root, RoomCatalog catalog, Action<string> log)
        {
            var data = Prepare(root, catalog);
            var result = new RuntimeExtraAssets();
            try
            {
                if(data.Trim!=null){result.TrimPath = data.Trim.Path; result.trimLease = StoneDoorwayKit.AcquireTrimMap(data.Trim);}
                result.Doors = AbbeyDoorAssets.Load(data.Doors.Directory, data.Doors.Record.manifestSha256, log);
                result.DoorwayKit = RoomPackage.Load(data.StoneDirectory, data.StoneRecord, log);
                return result;
            }
            catch { result.Dispose(); throw; }
        }
        internal static IEnumerator LoadSteps(string root, RoomCatalog catalog, Action<string> log,
            Action<RuntimeExtraAssets> completed, Action<RuntimeExtraAssets> created = null)
        {
            var result = new RuntimeExtraAssets(); bool succeeded = false; IEnumerator nested = null;
            try
            {
                // The caller can own/cancel the partial aggregate from before
                // any Unity asset starts loading. Worker work is managed only.
                created?.Invoke(result);
                var task = RoomLoadScheduling.Worker(() => Prepare(root, catalog));
                while (!task.IsCompleted) yield return null;
                var data = task.GetAwaiter().GetResult();
                if(data.Trim!=null){result.TrimPath = data.Trim.Path; result.trimLease = StoneDoorwayKit.AcquireTrimMap(data.Trim);}
                nested = AbbeyDoorAssets.LoadPreparedSteps(data.Doors, log,
                    value => result.Doors = value, value => result.Doors = value);
                while (nested.MoveNext()) yield return nested.Current;
                (nested as IDisposable)?.Dispose(); nested = null;
                nested = RoomPackage.LoadSteps(data.StoneDirectory, data.StoneRecord, log,
                    value => result.DoorwayKit = value, value => result.DoorwayKit = value);
                while (nested.MoveNext()) yield return nested.Current;
                completed(result); succeeded = true;
            }
            finally { (nested as IDisposable)?.Dispose(); if (!succeeded) result.Dispose(); }
        }
        // Preflight hashes, source bindings and JSON are all checked off the
        // Unity thread. In particular, the16MB trim is parsed once per owner,
        // not once for every placed/repeated source room.
        private static Prepared Prepare(string root, RoomCatalog catalog)
        {
            var config = JsonConvert.DeserializeObject<Config>(File.ReadAllText(RoomPackage.FilePath(root, "runtime-assets.json")), ManifestReader.Settings());
            bool pointed=KitArchitectureProfile.IsKitRoot(root);
            if (config == null || config.schemaVersion != (pointed?3:2) || !pointed&&!CatalogReader.Hash(config.trimSha256)) throw new InvalidDataException("Invalid extra Abbey assets contract.");
            var trim=pointed?null:StoneDoorwayKit.PrepareTrimMap(RoomPackage.FilePath(root,config.trimFile),config.trimSha256,catalog);
            string doorManifest = RoomPackage.FilePath(root, config.doorDirectory + "/manifest.json");
            var doors = AbbeyDoorAssets.Prepare(Path.GetDirectoryName(doorManifest), config.doorManifestSha256);
            if(pointed&&doors.Manifest.roomId!=KitPointedArchitecture.DoorId)throw new InvalidDataException("Rebuilt rooms cannot load the old arch door geometry.");
            var sources = catalog.rooms.Select(record => {
                string path = RoomPackage.FilePath(CatalogReader.PackagePath(root, record), "manifest.json");
                if (!string.IsNullOrEmpty(record.manifestSha256) && CatalogReader.HashFile(path) != record.manifestSha256)
                    throw new InvalidDataException("Room manifest changed before shared-door binding: " + record.roomId);
                var source = ManifestReader.Read(File.ReadAllText(path));
                if (source.roomId != record.roomId || source.sourceSha256 != record.sourceSha256)
                    throw new InvalidDataException("Wrong source room for shared-door binding.");
                return source;
            }).ToArray();
            RuntimeCatalogBindings.ValidateDoorVariants(doors.Manifest, sources);
            string stoneManifest = RoomPackage.FilePath(root, config.doorwayDirectory + "/manifest.json");
            var manifest = ReadDoorwayManifest(root);
            return new Prepared { Trim = trim, Doors = doors, StoneDirectory = Path.GetDirectoryName(stoneManifest),
                StoneRecord = new CatalogRoomRecord { roomId = manifest.roomId, sourceSha256 = manifest.sourceSha256, manifestSha256 = config.doorwayManifestSha256 } };
        }
        internal static PackageManifest ReadDoorwayManifest(string root)
        {
            var config=JsonConvert.DeserializeObject<Config>(File.ReadAllText(RoomPackage.FilePath(root,"runtime-assets.json")),ManifestReader.Settings());
            bool pointed=KitArchitectureProfile.IsKitRoot(root);
            if(config==null || config.schemaVersion!=(pointed?3:2) || !CatalogReader.Hash(config.doorwayManifestSha256))throw new InvalidDataException("Missing masonry manifest binding.");
            string path=RoomPackage.FilePath(root,config.doorwayDirectory+"/manifest.json");
            if(CatalogReader.HashFile(path)!=config.doorwayManifestSha256)throw new InvalidDataException("Stone doorway kit manifest changed.");
            var manifest=ManifestReader.Read(File.ReadAllText(path));
            if(manifest?.roomId!=(pointed?KitPointedArchitecture.KitId:"STONE_DOORWAY_KIT_V5") || !CatalogReader.Hash(manifest.sourceSha256))throw new InvalidDataException("Wrong shared stone doorway source.");
            if(!pointed){AssemblyPartPolicy.HasMasonryCollars(manifest);AssemblyPartPolicy.HasDoorRebates(manifest);}
            return manifest;
        }
        public void Dispose()
        {
            try { Doors?.Dispose(); }
            finally
            {
                Doors = null;
                try { DoorwayKit?.Dispose(); }
                finally { DoorwayKit = null; trimLease?.Dispose(); trimLease = null; TrimPath = null; }
            }
        }
    }
}
