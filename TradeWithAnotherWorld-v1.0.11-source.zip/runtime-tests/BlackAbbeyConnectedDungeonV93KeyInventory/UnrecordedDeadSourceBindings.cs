namespace BlackAbbeySixRooms
{
    // These exact composed packages preserve the canonical buffer layouts
    // consumed by the named legacy handlers. Their export receipt proves
    // every affected mesh hash/count; arbitrary new sources never alias.
    internal static class UnrecordedDeadSourceBindings
    {
        internal static bool OriginalStairFixtures(string source)
            =>source=="bdbeef3956ab6e9d51e2d03c283874d83b869400280cfc74e28902f6ecebaa41"||source==UnrecordedDeadFallPolicy.StairSource;
        internal static string Canonical(string room,string source)
        {
            if(room=="R02"&&source=="27c48eca7d56e6c31e3583ae33ce9e5cefbb84178d7005359e3eeef6343a814c")
                return "c23c81a4ff07587a01eda582ec08bbd22dc2ec398b993b15330c15e3c3d7e951";
            if(room=="R09"&&source=="12686a0c6393a6187ccb60f46a71fbace98f309eabcbe8ac7b7d300f08ab4d18")
                return "869bac079de49440aebe2c2dd5cabbbce2e0040173eb65977d0f1ae57fd8efb4";
            return source;
        }
        internal static string CanonicalManifest(string hash)
        {
            if(hash=="dd175d2701bfb0bcfa9cdfa0510d5845ab1fc1ca41f12d55f499ea2359fc0c5d")return "ecc7b72cd1f64c94d2ea81e13968a3dc659595fc5dfd6cc19238acc551ad5fe8";
            if(hash=="d96032b1e8a38720502cda0b85302e44928851251087db41fb4f172f0c0a213e")return "5cde66736e87e218de1cfa47127604f73f075964164c9cdc98ae5b15d3e6e57a";
            return hash;
        }
    }
}
