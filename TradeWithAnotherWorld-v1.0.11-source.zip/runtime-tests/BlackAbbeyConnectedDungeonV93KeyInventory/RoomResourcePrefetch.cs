using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BlackAbbeySixRooms
{
    // A bounded managed-only look-ahead. Uploads and every Unity API remain
    // on the caller's main thread. Disposal never schedules another item;
    // at most two already-started reads finish with no Unity ownership.
    internal sealed class RoomResourcePrefetch<T> : IDisposable
    {
        private readonly int count;
        private readonly Func<int, Task<T>> prepare;
        private readonly Queue<Task<T>> pending = new Queue<Task<T>>();
        private int started;
        private bool disposed;
        internal const int Capacity = 2;
        internal RoomResourcePrefetch(int count, Func<int, Task<T>> prepare)
        {
            if (count < 0 || prepare == null) throw new ArgumentException("Invalid resource preparation inventory.");
            this.count = count; this.prepare = prepare; Fill();
        }
        internal Task<T> Current
        {
            get {
                if (disposed || pending.Count == 0) throw new InvalidOperationException("Resource preparation has no current item.");
                return pending.Peek();
            }
        }
        internal void Advance()
        {
            if (!Current.IsCompleted) throw new InvalidOperationException("Cannot advance an unfinished resource.");
            pending.Dequeue(); Fill();
        }
        private void Fill()
        {
            while (!disposed && pending.Count < Capacity && started < count)
            {
                var task = prepare(started++);
                if (task == null) throw new InvalidOperationException("A resource preparation task is missing.");
                // A cancelled owner may never consume the task. Observe a
                // managed fault without touching Unity or reporting success.
                task.ContinueWith(t => { var observed = t.Exception; }, TaskContinuationOptions.OnlyOnFaulted);
                pending.Enqueue(task);
            }
        }
        public void Dispose() { disposed = true; pending.Clear(); }
    }
    internal static class TextureSamplerPolicy
    {
        internal static string Wrap(TextureSamplerRecord value)
        {
            string wrap = value?.wrap ?? "clamp";
            if (wrap != "clamp" && wrap != "repeat") throw new ArgumentException("Unsupported texture wrap policy.");
            return wrap;
        }
        internal static string Filter(TextureSamplerRecord value)
        {
            string filter = value?.filter ?? "trilinear";
            if (filter != "point" && filter != "bilinear" && filter != "trilinear") throw new ArgumentException("Unsupported texture filter policy.");
            return filter;
        }
        internal static string Key(TextureSamplerRecord value)
        {
            string wrap = Wrap(value);
            if (value != null && (!value.mipmaps || value.anisotropy != 8))
                throw new ArgumentException("Room textures require mipmaps and anisotropy8.");
            return "|mips|" + Filter(value) + "|" + wrap + "|aniso8";
        }
        internal static TextureSamplerRecord For(MaterialRecord material, int channel)
        {
            if (material == null) throw new ArgumentNullException(nameof(material));
            var selected = channel == 0 ? material.albedoSampler : channel == 1 ? material.normalSampler :
                channel == 2 ? material.metallicSmoothnessSampler : channel == 3 ? material.emissionSampler :
                throw new ArgumentOutOfRangeException(nameof(channel));
            selected = selected ?? material.sampler; Key(selected); return selected;
        }
    }
    internal static class RoomTextureIdentity
    {
        // Exact encoded PNG bytes, colour-space role and identical sampler /
        // upload settings. Paths are deliberately not an identity: unchanged
        // maps shared by two room packages should only upload once.
        internal static string Key(string hash, bool linear, TextureSamplerRecord sampler = null)
        {
            if (hash == null || hash.Length != 64) throw new ArgumentException("Expected a SHA256 texture identity.");
            foreach (char c in hash)
                if (!(c >= '0' && c <= '9') && !(c >= 'a' && c <= 'f')) throw new ArgumentException("Invalid texture identity.");
            return "texture-v27|" + hash + (linear ? "|linear" : "|srgb") + TextureSamplerPolicy.Key(sampler);
        }
    }
}
