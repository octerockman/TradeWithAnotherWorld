using System;
using System.Linq;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    internal sealed partial class AbbeyMonkSpawns
    {
        bool ResumeOnReadyFloor(ActorSlot slot,ZDO zdo,GameObject actor)
        {
            if(!actor||!Owned(zdo,slot))return false;
            if(!DungeonActorResidency.Held(actor)&&actor.activeSelf&&RuntimeTestPlugin.DungeonActorPositionValid(worldKey,runId,actor.transform.position))return true;
            DungeonActorResidency.Park(actor,zdo);
            if(!TryRestorationLanding(slot,zdo,actor,out var landing))return false;
            var rotation=slot.Rotation!=null?new Quaternion(slot.Rotation[0],slot.Rotation[1],slot.Rotation[2],slot.Rotation[3]).normalized:zdo.GetRotation();
            bool resumed=DungeonActorResidency.Resume(actor,zdo,worldKey,runId,landing,rotation,true);
            if(resumed){slot.Position=Position(landing);slot.Rotation=Rotation(rotation);log?.Invoke("ABBEY_ACTOR_FLOOR_RESUME: "+slot.Key+"; exact UID="+slot.Id+"; position="+landing.ToString("F3")+"; health/consumed state retained.");}
            return resumed;
        }
        bool TryRestorationLanding(ActorSlot slot,ZDO zdo,GameObject actor,out Vector3 landing)
        {
            bool supported=RuntimeTestPlugin.TryDungeonActorLanding(worldKey,runId,actor,zdo.GetPosition(),out landing);
            if(!supported&&slot.Position!=null)supported=RuntimeTestPlugin.TryDungeonActorLanding(worldKey,runId,actor,new Vector3(slot.Position[0],slot.Position[1],slot.Position[2]),out landing);
            if(!supported&&placed!=null&&placed.TryGetValue(slot.InstanceId,out var room)&&room.Room.Root)
            {
                // Old checkpoints may already contain a surface position. Try
                // the same XZ at the source room's actual floor, then its bounded
                // original spawn candidates. No new actor/health/slot is made.
                var root=room.Room.Root.transform;float y=room.Room.Manifest.ports.Min(p=>p.position[1]);
                if(slot.Position!=null)
                {
                    var local=root.InverseTransformPoint(new Vector3(slot.Position[0],slot.Position[1],slot.Position[2]));
                    supported=RuntimeTestPlugin.TryDungeonActorLanding(worldKey,runId,actor,root.TransformPoint(new Vector3(local.x,y+.1f,local.z)),out landing);
                }
                if(!supported)
                {
                    var policy=Policy(room);var proposal=legacy?AbbeyMonkSpawnPolicy.Propose(seed,policy):AbbeyMonkSpawnPolicy.ProposeMixed(seed,policy);
                    foreach(var p in proposal.Candidates)
                    {
                        if(!AbbeyMonkSpawnPolicy.Allowed(policy,p,out _))continue;
                        if(RuntimeTestPlugin.TryDungeonActorLanding(worldKey,runId,actor,root.TransformPoint(new Vector3((float)p.X,y+.1f,(float)p.Z)),out landing)){supported=true;break;}
                    }
                }
            }
            return supported;
        }

    }
}
