using System;
using System.Collections;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using Newtonsoft.Json;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        private sealed class DoorEntryAttempt
        {
            internal DoorEntryPolicy Policy;
            internal Player Player;
            internal WorldDoorState Door;
            internal CinematicEncodedPreparation Preparation;
            internal DoorPortalLoadingScreen Screen;
            internal readonly DoorPreparationAdmission Admission=new DoorPreparationAdmission();
            internal float Deadline,NextMemoryRead;
            internal bool MemoryKnown,Disposed,LoaderAccepted,LoaderFinished,LoaderSucceeded;
            internal Exception LoaderFailure;
            internal uint MemoryLoad;
            internal ulong AvailableBytes;
        }
        private DoorEntryAttempt doorEntryAttempt;
        [StructLayout(LayoutKind.Sequential)]
        private struct DoorHostMemory
        {
            internal uint Length,Load;
            internal ulong Physical,AvailablePhysical,PageFile,AvailablePageFile,Virtual,AvailableVirtual,Extended;
        }
        [DllImport("kernel32.dll",SetLastError=true)]
        [return:MarshalAs(UnmanagedType.Bool)]
        private static extern bool GlobalMemoryStatusEx(ref DoorHostMemory status);

        private DoorEntryAttempt CreateDoorEntry(Player player,WorldDoorState state,bool prepare)
        {
            if(doorEntryAttempt!=null||busy||!isActiveAndEnabled||!player||player!=Player.m_localPlayer||player.IsDead()||player.IsTeleporting()||!ZNet.instance||!ZNet.instance.IsServer()||!ZNetScene.instance||state!=savedWorldDoor||state.worldKey!=WorldKey()||!worldPortal||player.transform.position.y>=HighAltitudeGuard)
                throw new InvalidOperationException("Wait for normal local gameplay at the saved Mysterious Door.");
            if(prepare&&!ReadCatalog())throw new InvalidOperationException("The checked dungeon catalog is unavailable.");
            var attempt=new DoorEntryAttempt { Player=player,Door=state,Deadline=Time.unscaledTime+45,
                Policy=new DoorEntryPolicy(player,ZNet.instance,ZNetScene.instance,state,state.worldKey,player.GetPlayerID().ToString(CultureInfo.InvariantCulture)) };
            doorEntryAttempt=attempt;busy=true;
            try
            {
                bool resident=dungeonPlan!=null&&(!state.dungeonSeed.HasValue||state.dungeonSeed==dungeonPlan.Seed)&&rooms.TryGetValue("R01",out var room)&&room.Root;
                if(prepare&&!resident)
                {
                    var packages=catalog.rooms.Concat(new[]{catalog.connector,catalog.endCap}.Where(r=>r!=null)).ToArray();
                    attempt.Preparation=CinematicEncodedPreparation.BeginPackages(DataPath,packages);
                    attempt.Preparation.BindCurrent();
                }
                Logger.LogInfo("ABBEY_DOOR_PREPARE: token="+attempt.Policy.Token+"; encodedWorker="+(attempt.Preparation!=null)+"; resident="+resident+"; no Unity construction or travel during cinematic.");
                return attempt;
            }
            catch { FinishDoorEntry(attempt,"Preparation could not start");throw; }
        }
        private string BeginDoorPreparation(Player player,WorldDoorState state)=>CreateDoorEntry(player,state,true).Policy.Token;
        private void CancelDoorPreparation(Player player,WorldDoorState state,string token)
        {
            var attempt=doorEntryAttempt;
            if(attempt==null||!attempt.Policy.TokenOwner(player,state,token))return;
            if(attempt.Policy.Preparing)FinishDoorEntry(attempt,"Cinematic cancelled");
            else CancelRoomLoading();
        }
        private void RejectDoorPreparation(Player player,WorldDoorState state,string reason)
        {
            var attempt=doorEntryAttempt;
            if(attempt!=null&&attempt.Policy.Preparing&&ReferenceEquals(attempt.Player,player)&&ReferenceEquals(attempt.Door,state))FinishDoorEntry(attempt,reason);
        }
        private bool DoorEntryContext(DoorEntryAttempt attempt)
        {
            var player=attempt.Player;
            if(attempt.Disposed||!isActiveAndEnabled||!player||player!=Player.m_localPlayer||player.IsDead()||!ZNet.instance||!ZNet.instance.IsServer()||!ZNetScene.instance||!worldPortal)return false;
            try{return attempt.Policy.Context(player,ZNet.instance,ZNetScene.instance,savedWorldDoor,WorldKey(),player.GetPlayerID().ToString(CultureInfo.InvariantCulture));}
            catch{return false;}
        }
        private void TickDoorLoading(Player player)
        {
            var attempt=doorEntryAttempt;if(attempt==null)return;
            if(!DoorEntryContext(attempt)||Time.unscaledTime>attempt.Deadline||attempt.Policy.Preparing&&player.IsTeleporting())
            {
                if(attempt.Policy.Preparing)FinishDoorEntry(attempt,"Preparation context expired");
                else CancelRoomLoading();
                return;
            }
            if(!attempt.Policy.Preparing){busy=true;return;}
            if(attempt.Preparation==null)return;
            if(Time.unscaledTime>=attempt.NextMemoryRead)
            {
                attempt.NextMemoryRead=Time.unscaledTime+.5f;attempt.MemoryKnown=false;
                try
                {
                    if(Environment.OSVersion.Platform==PlatformID.Win32NT)
                    {
                        var memory=new DoorHostMemory{Length=(uint)Marshal.SizeOf(typeof(DoorHostMemory))};
                        attempt.MemoryKnown=GlobalMemoryStatusEx(ref memory);
                        attempt.MemoryLoad=memory.Load;attempt.AvailableBytes=memory.AvailablePhysical;
                    }
                }
                catch { attempt.MemoryKnown=false; }
            }
            attempt.Preparation.SetAdmission(attempt.Admission.Update(Time.unscaledDeltaTime,Time.timeScale,attempt.MemoryKnown,attempt.MemoryLoad,attempt.AvailableBytes));
        }
        private void RequireDoorEntry(DoorEntryAttempt attempt)
        {
            if(!ReferenceEquals(doorEntryAttempt,attempt)||!DoorEntryContext(attempt)||Time.unscaledTime>attempt.Deadline)
                throw new InvalidOperationException("The loading player, world or doorway changed; the existing recovery record is retained.");
        }
        private void BeginCoveredDoorEntry(Player player,WorldDoorState state)
        {
            var attempt=doorEntryAttempt;
            if(attempt==null)attempt=CreateDoorEntry(player,state,false);
            if(!ReferenceEquals(attempt.Player,player)||!ReferenceEquals(attempt.Door,state)||!attempt.Policy.BeginCover())
            {player.Message(MessageHud.MessageType.Center,"Please wait for the current entry to finish.");return;}
            attempt.Deadline=Time.unscaledTime+300;
            attempt.Preparation?.Complete();
            try
            {
                if(StartCoroutine(CoveredDoorEntry(attempt))==null)throw new InvalidOperationException("Door entry could not be scheduled.");
            }
            catch { FinishDoorEntry(attempt,"Door entry scheduling failed");throw; }
        }
        private void NotifyDoorEntryLoaderStarted(bool accepted)
        {var attempt=doorEntryAttempt;if(attempt!=null&&attempt.Policy.Stage==DoorEntryStage.Loading)attempt.LoaderAccepted=accepted;}
        private void NotifyDoorEntryOutcome(Player player,bool succeeded)
        {var attempt=doorEntryAttempt;if(attempt!=null&&attempt.Policy.Stage==DoorEntryStage.Loading&&ReferenceEquals(attempt.Player,player))attempt.LoaderSucceeded=succeeded;}
        private IEnumerator ObserveDoorEntryLoader(IEnumerator original)
        {
            var attempt=doorEntryAttempt;
            return attempt!=null&&attempt.Policy.Stage==DoorEntryStage.Loading?ObserveDoorEntryLoaderCore(original,attempt):original;
        }
        private IEnumerator ObserveDoorEntryLoaderCore(IEnumerator original,DoorEntryAttempt attempt)
        {
            var result=new RoomLoadScheduling.Result();
            try
            {
                yield return RoomLoadScheduling.Run(original,result);
                attempt.LoaderFailure=result.Error;
            }
            finally { attempt.LoaderFinished=true; }
        }
        private IEnumerator CoveredDoorEntry(DoorEntryAttempt attempt)
        {
            var result=new RoomLoadScheduling.Result();bool ready=false;
            try
            {
                yield return RoomLoadScheduling.Run(CoveredDoorEntryCore(attempt,()=>ready=true),result);
                if(result.Error!=null)
                {
                    DoorEntryWarning("ABBEY_DOOR_LOAD_FAILED: "+result.Error);
                    try { Print("Door loading stopped. Your saved dungeon and return record are retained."); } catch { }
                    // Stop the separately running original loader as well as
                    // the UI owner. The cancellation method explicitly cleans
                    // both even if Unity does not dispose stopped iterators.
                    if(ReferenceEquals(doorEntryAttempt,attempt))CancelRoomLoading();
                }
            }
            finally { FinishDoorEntry(attempt,ready?"Ready":"Stopped before reveal"); }
        }
        private IEnumerator CoveredDoorEntryCore(DoorEntryAttempt attempt,Action ready)
        {
            RequireDoorEntry(attempt);
            attempt.Screen=DoorPortalLoadingScreen.Begin(attempt.Player,s=>Logger.LogInfo(s));
            yield return attempt.Screen.Cover();
            RequireDoorEntry(attempt);
            if(!attempt.Screen.Active||!attempt.Screen.CoverReady)throw new InvalidOperationException("A visible portal cover is required before loading.");
            if(attempt.Player.IsTeleporting()||attempt.Player.transform.position.y>=HighAltitudeGuard)
                throw new InvalidOperationException("The surface player began other travel before dungeon loading.");
            attempt.Policy.BeginLoad();
            Logger.LogInfo("ABBEY_DOOR_COVERED: token="+attempt.Policy.Token+"; heavy loading begins after covered presentation; native world simulation retained.");
            busy=false; // The unchanged entry method takes its normal own reservation.
            EnterThroughPortal(attempt.Player,attempt.Door.dungeonSeed);
            if(!attempt.LoaderAccepted)throw new InvalidOperationException("The original doorway loader could not start.");
            // Completion is explicit rather than inferred from a transient busy
            // value: a nested iterator can start later, or fail synchronously.
            busy=true;
            while(!attempt.LoaderFinished)
            {RequireDoorEntry(attempt);if(!attempt.Screen.Active)throw new InvalidOperationException("The native portal screen was lost.");yield return null;}
            RequireDoorEntry(attempt);
            if(attempt.LoaderFailure!=null)throw new InvalidOperationException("The original doorway loader failed.",attempt.LoaderFailure);
            if(!attempt.LoaderSucceeded)throw new InvalidOperationException("The original entry did not confirm successful setup and arrival.");
            // Keep input reserved during the native teleport's final frames.
            busy=true;
            while(attempt.Player.IsTeleporting())
            {RequireDoorEntry(attempt);if(!attempt.Screen.Active)throw new InvalidOperationException("The native portal screen was lost.");yield return null;}
            if(!DoorArrivalReady(attempt))throw new InvalidOperationException("The entry floor, arrival or required encounter setup was not ready.");
            RefreshRenderBudget();
            yield return null;RequireDoorEntry(attempt);
            if(!DoorArrivalReady(attempt))throw new InvalidOperationException("The ready dungeon entry changed before reveal.");
            attempt.Policy.BeginReveal();
            yield return attempt.Screen.ReleaseReady();
            RequireDoorEntry(attempt);
            if(!attempt.Screen.RevealCompleted||attempt.Screen.RestorationErrors!=0||!DoorArrivalReady(attempt))throw new InvalidOperationException("The ready entry changed or its presentation could not fully restore.");
            ready();
        }
        private bool DoorArrivalReady(DoorEntryAttempt attempt)
        {
            var player=attempt.Player;
            if(!attempt.LoaderSucceeded||!DoorEntryContext(attempt)||!Matches(player)||player.IsTeleporting()||dungeonPlan==null||dungeonPlan.Mode!="natural"||!actorGeometryReady||monkRun==null||!rooms.TryGetValue("R01",out var first)||!first.Root||activeRoom!=first)return false;
            Vector3 target=first.Root.transform.TransformPoint(RoomPackage.Vector(first.Manifest.entryPosition,"covered entry"));
            return Vector3.Distance(player.transform.position,target)<=5&&Physics.Raycast(target+Vector3.up*2,Vector3.down,3f,LayerMask.GetMask("static_solid"),QueryTriggerInteraction.Ignore);
        }
        private void FinishDoorEntry(DoorEntryAttempt attempt,string reason)
        {
            if(attempt==null||attempt.Disposed)return;attempt.Disposed=true;
            bool owned=ReferenceEquals(doorEntryAttempt,attempt);
            if(owned){doorEntryAttempt=null;busy=false;}
            attempt.Policy.Close();
            try
            {
                var snapshot=attempt.Preparation?.Snapshot();
                Logger.LogInfo("ABBEY_DOOR_LOAD_END: token="+attempt.Policy.Token+"; reason="+reason+"; preparation="+JsonConvert.SerializeObject(snapshot)+"; no FPS improvement claim.");
            }
            catch { }
            // Teardown must never prevent CancelRoomLoading from stopping its
            // separately scheduled original loader and disposing inflight data.
            try { attempt.Preparation?.Dispose(); }
            catch(Exception error) { DoorEntryWarning("ABBEY_DOOR_PREPARATION_CLEANUP_FAILED: "+error.Message); }
            try { attempt.Screen?.Dispose(); }
            catch(Exception error) { DoorEntryWarning("ABBEY_DOOR_SCREEN_CLEANUP_FAILED: "+error.Message); }
        }
        private void CancelDoorLoading(string reason)
        {var attempt=doorEntryAttempt;if(attempt!=null)FinishDoorEntry(attempt,reason);}
        private void ShutdownDoorLoading()
        {
            try { if(doorEntryAttempt!=null)CancelRoomLoading(); }
            catch(Exception error) { DoorEntryWarning("ABBEY_DOOR_SHUTDOWN_CANCEL_FAILED: "+error.Message); }
            try { DoorPortalLoadingScreen.Shutdown(); }
            catch(Exception error) { DoorEntryWarning("ABBEY_DOOR_SHUTDOWN_PRESENTATION_FAILED: "+error.Message); }
        }
        private void DoorEntryWarning(string message) { try { Logger.LogWarning(message); } catch { } }
    }
}
