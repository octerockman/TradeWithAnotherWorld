using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace BlackAbbeySixRooms
{
    // Owns only each source's mute bit. The caller owns eligibility and source discovery.
    // Identity must remain stable even for Unity objects whose equality changes on destruction.
    internal sealed class ReversibleAudioMuteLease<T> : IDisposable where T : class
    {
        sealed class ReferenceComparer : IEqualityComparer<T>
        {
            internal static readonly ReferenceComparer Instance = new ReferenceComparer();
            public bool Equals(T first, T second) => ReferenceEquals(first, second);
            public int GetHashCode(T source) => RuntimeHelpers.GetHashCode(source);
        }

        readonly Func<T, bool> isAlive;
        readonly Func<T, bool> readMute;
        readonly Action<T, bool> writeMute;
        readonly Dictionary<T, bool> originals = new Dictionary<T, bool>(ReferenceComparer.Instance);
        readonly HashSet<T> retained = new HashSet<T>(ReferenceComparer.Instance);
        readonly List<T> removals = new List<T>();
        bool disposed;

        internal ReversibleAudioMuteLease(Func<T, bool> isAlive, Func<T, bool> readMute, Action<T, bool> writeMute)
        {
            this.isAlive = isAlive ?? throw new ArgumentNullException(nameof(isAlive));
            this.readMute = readMute ?? throw new ArgumentNullException(nameof(readMute));
            this.writeMute = writeMute ?? throw new ArgumentNullException(nameof(writeMute));
        }

        internal int Count => originals.Count;

        internal void Acquire(T source)
        {
            if (disposed || ReferenceEquals(source, null) || !isAlive(source)) return;
            if (!originals.ContainsKey(source)) originals.Add(source, readMute(source));
            writeMute(source, true);
        }

        // Reconcile against exact native ownership, restoring sources removed or replaced.
        // Scratch collections are reused; discovery may supply its own reusable set.
        internal void RetainOnly(IEnumerable<T> sources)
        {
            if (sources == null) throw new ArgumentNullException(nameof(sources));
            if (disposed) return;
            retained.Clear();
            foreach (T source in sources)
                if (!ReferenceEquals(source, null) && isAlive(source)) retained.Add(source);
            removals.Clear();
            foreach (var entry in originals)
                if (!retained.Contains(entry.Key) || !isAlive(entry.Key)) removals.Add(entry.Key);
            foreach (T source in removals)
            {
                if (isAlive(source)) writeMute(source, originals[source]);
                originals.Remove(source);
            }
            retained.Clear();
            removals.Clear();
        }

        // Native updates may reset mute between discovery passes; preserve the first baseline.
        internal void Enforce()
        {
            if (disposed) return;
            removals.Clear();
            foreach (var entry in originals)
                if (isAlive(entry.Key)) writeMute(entry.Key, true);
                else removals.Add(entry.Key);
            foreach (T source in removals) originals.Remove(source);
            removals.Clear();
        }

        internal void RestoreAll()
        {
            foreach (var entry in originals)
                if (isAlive(entry.Key)) writeMute(entry.Key, entry.Value);
            originals.Clear();
            retained.Clear();
            removals.Clear();
        }

        public void Dispose()
        {
            if (disposed) return;
            RestoreAll();
            disposed = true;
        }
    }
}
