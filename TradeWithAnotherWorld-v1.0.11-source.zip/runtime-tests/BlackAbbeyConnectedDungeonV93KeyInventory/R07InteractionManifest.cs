using System;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace BlackAbbeySixRooms
{
#pragma warning disable 0649
    internal sealed class R07InteractionManifest
    {
        public int schemaVersion, startIndex;
        public string sourceSha256, pattern, statuePartId;
        public R07CandleRecord[] candles;
        public R07PartRecord[] movingParts;
        public R07ContainerRecord[] containers;
    }
    internal sealed class R07CandleRecord
    {
        public string id, socketName;
        public int clockwiseIndex;
        public float[] interactionCenter, interactionSize;
    }
    internal sealed class R07PartRecord
    {
        public string id;
        public string[] visualNames, colliderNames;
        public float[] pivot, axis, slideDelta;
        public float openAngle, durationSeconds;
    }
    internal sealed class R07ContainerRecord
    {
        public string id, partId;
        public float[] interactionCenter, interactionSize;
        public int width, height;
    }
#pragma warning restore 0649
    internal static class R07InteractionReader
    {
        private static bool Vector(float[] a) => a?.Length == 3 && a.All(v => !float.IsNaN(v) && !float.IsInfinity(v));
        private static bool Finite(float a) => !float.IsNaN(a) && !float.IsInfinity(a);
        private static bool Box(float[] a) => Vector(a) && a.All(v => v > 0 && v <= 4);
        internal static R07InteractionManifest Read(string json, PackageManifest room)
        {
            if (json == null || json.Length > 1024 * 1024 || room?.roomId != "R07") throw new InvalidDataException("Invalid shrine interaction package.");
            var m = JsonConvert.DeserializeObject<R07InteractionManifest>(json, ManifestReader.Settings());
            if (m == null || m.schemaVersion != 1 || m.sourceSha256 != room.sourceSha256 || m.pattern != R07PuzzleState.Pattern || m.startIndex != 0 ||
                m.candles?.Length != 12 || !m.candles.Select(c => c?.clockwiseIndex ?? -1).OrderBy(i => i).SequenceEqual(Enumerable.Range(0, 12)) ||
                m.candles.Any(c => c == null || string.IsNullOrWhiteSpace(c.id) || string.IsNullOrWhiteSpace(c.socketName) || !Vector(c.interactionCenter) || !Box(c.interactionSize)) ||
                m.candles.Select(c => c.id).Distinct().Count() != 12 || m.candles.Select(c => c.socketName).Distinct().Count() != 12 ||
                room.sockets?.Length != 18 || m.candles.Any(c => !room.sockets.Any(s => s.name == c.socketName)))
                throw new InvalidDataException("R07 requires twelve uniquely indexed source shelf wicks, six separate ambient wicks and the agreed pattern/start.");
            if (m.movingParts?.Length != 4 || m.movingParts.Any(p => p == null || string.IsNullOrWhiteSpace(p.id) || p.visualNames == null || p.visualNames.Length == 0 || p.colliderNames == null || p.colliderNames.Length == 0 ||
                    !Vector(p.pivot) || !Vector(p.axis) || !Vector(p.slideDelta) || !Finite(p.openAngle) || Math.Abs(p.openAngle) > 120 || Math.Abs(p.openAngle) > .01f && p.axis.Sum(v => v*v) < .1f || !Finite(p.durationSeconds) || p.durationSeconds < .25f || p.durationSeconds > 8 ||
                    p.visualNames.Any(n => !room.meshes.Any(v => v.name == n)) || p.colliderNames.Any(n => !room.colliderMeshes.Any(v => v.name == n))))
                throw new InvalidDataException("Shrine moving-part source meshes/pivots are invalid.");
            if (m.movingParts.Select(p => p.id).Distinct().Count() != 4 || m.movingParts.SelectMany(p => p.visualNames).Distinct().Count() != m.movingParts.Sum(p => p.visualNames.Length) ||
                m.movingParts.SelectMany(p => p.colliderNames).Distinct().Count() != m.movingParts.Sum(p => p.colliderNames.Length) || !m.movingParts.Any(p => p.id == m.statuePartId))
                throw new InvalidDataException("Shrine moving-part ownership is ambiguous.");
            if (m.containers?.Length != 3 || !m.containers.Select(c => c?.id).OrderBy(n => n).SequenceEqual(new[] { "chest", "coffin", "secret-box" }) ||
                m.containers.Select(c => c.partId).Distinct().Count() != 3 || m.containers.Any(c => !m.movingParts.Any(p => p.id == c.partId) || !Vector(c.interactionCenter) || !Box(c.interactionSize) || c.width < 2 || c.width > 8 || c.height < 1 || c.height > 4))
                throw new InvalidDataException("Shrine containers require source-bound lid parts and bounded native inventories.");
            var statue = m.movingParts.Single(p => p.id == m.statuePartId);
            if (m.containers.Any(c => c.partId == statue.id) || statue.slideDelta[0] >= -.1f || Math.Abs(statue.slideDelta[1]) > .001f || Math.Abs(statue.slideDelta[2]) > .001f || Math.Abs(statue.openAngle) > .001f)
                throw new InvalidDataException("The shrine statue must slide left independently of the three container lids.");
            return m;
        }
    }
}
