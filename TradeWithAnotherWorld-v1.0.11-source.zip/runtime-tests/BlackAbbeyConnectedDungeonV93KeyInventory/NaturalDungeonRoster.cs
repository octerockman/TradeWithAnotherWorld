using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Pure seeded selection. Source definitions and their port owners are never
    // edited; each selected instance gets its own identity and exact bounds.
    internal static class NaturalDungeonRoster
    {
        internal const int MinimumRooms=25,MaximumRooms=35,MaximumOrdinaryRepeats=8;
        internal const int MaximumRosterAttempts=16,MaximumLayoutAttempts=12,PlacementBudget=30000;
        internal const int MinimumBossDepth=6;
        private static readonly string[] OrdinaryFamilies={"R01","R02","R03","R04","R05","R06","R07"};
        private static readonly int[] Weights={4,4,3,2,3,4,2};
        internal static string Family(string sourceId)=>sourceId=="R03_complete"?"R03":sourceId;
        // The requested size is a seed property, never reduced by an easier
        // retry roster. This prevents successful retries biasing every run
        // toward the minimum room count.
        internal static int TargetRoomCount(int seed)=>new Random(unchecked(seed^0x271035B)).Next(MinimumRooms,MaximumRooms+1);
        internal static bool WantsLoop(int seed)=>true;
        private static bool WantsMultipleLoops(int seed)=>new Random(unchecked(seed^0x27C1C1E)).NextDouble()<.65;
        // Preserve the old larger-cycle roll; former zero-cycle outcomes now request one.
        internal static int LoopCount(int seed)=>!WantsMultipleLoops(seed)?1:TargetRoomCount(seed)>=30&&new Random(unchecked(seed^0x31C1C1E)).NextDouble()<.5?3:2;
        internal static int StairCount(int seed)=>1+new Random(unchecked(seed^0x3108B17)).Next(TargetRoomCount(seed)>=28?3:2);

        internal static void ValidateCanonical(IEnumerable<DungeonRoomSpec> input)
        {
            var specs=input?.ToArray()??Array.Empty<DungeonRoomSpec>();
            var allowed=new HashSet<string>(new[]{"R01","R02","R03","R03_complete","R04","R05","R06","R07","R08","R09"},StringComparer.Ordinal);
            if(specs.Any(s=>s==null||s.Id!=s.SourceId||!allowed.Contains(s.SourceId)||s.BoundsY==null||s.BoundsY.Length!=2)||specs.Select(s=>s.SourceId).Distinct().Count()!=specs.Length)
                throw new ArgumentException("Natural generation requires unique canonical source specs with their complete vertical bounds.");
            if(!allowed.SetEquals(specs.Select(s=>s.SourceId)))
                throw new ArgumentException("Every current Black Abbey room source is required by the complete natural roster, including both R03 variants, R07 and R08.");
            if(specs.Count(s=>s.SourceId=="R01")!=1||specs.Count(s=>s.SourceId=="R09")!=1||specs.Single(s=>s.SourceId=="R09").Ports.Length!=1)
                throw new ArgumentException("Natural generation requires one R01 entry and one single-port R09 boss source.");
            if(specs.Any(s=>s.SourceId=="R07"&&s.Ports.Length!=1)||specs.Where(s=>s.SourceId!="R07"&&OrdinaryFamilies.Contains(Family(s.SourceId))).Any(s=>s.Ports.Length<2))
                throw new ArgumentException("Natural ordinary rooms must connect onward; the retained R07 shrine remains a one-port leaf.");
            if(2+specs.Select(s=>Family(s.SourceId)).Distinct().Count(f=>OrdinaryFamilies.Contains(f))*MaximumOrdinaryRepeats+(specs.Any(s=>s.SourceId=="R07")?1:0)+(specs.Any(s=>s.SourceId=="R08")?1:0)<MinimumRooms)
                throw new ArgumentException("Not enough canonical ordinary room families for a bounded natural roster.");
        }
        private static DungeonRoomSpec Instance(DungeonRoomSpec source,string id)=>new DungeonRoomSpec
        {
            Id=id,SourceId=source.SourceId,Ports=source.Ports.ToArray(),
            Bounds=source.Bounds.ToArray(),BoundsY=source.BoundsY.ToArray(),Reservations=source.Reservations?.Select(v=>v.ToArray()).ToArray(),KitConnectedExteriorCollar=source.KitConnectedExteriorCollar,SplitBossProxy=source.SplitBossProxy
        };
        internal static DungeonRoomSpec[] Select(IEnumerable<DungeonRoomSpec> input,int seed,int rosterAttempt=0)
            => Select(input,seed,rosterAttempt,false);
        internal static DungeonRoomSpec[] Select(IEnumerable<DungeonRoomSpec> input,int seed,int rosterAttempt,bool oneBrokenSaint)
        {
            var canonical=input.OrderBy(s=>s.SourceId,StringComparer.Ordinal).ToArray();ValidateCanonical(canonical);
            if(rosterAttempt<0||rosterAttempt>=MaximumRosterAttempts)throw new ArgumentOutOfRangeException(nameof(rosterAttempt));
            var random=new Random(unchecked(seed^((rosterAttempt+1)*32452843)^0x25A9B31));
            var families=OrdinaryFamilies.Select((id,i)=>new{Id=id,Weight=Weights[i],Sources=canonical.Where(s=>Family(s.SourceId)==id&&(!oneBrokenSaint||s.SourceId!="R03")).ToArray()}).Where(f=>f.Sources.Length>0).ToArray();
            int count=TargetRoomCount(seed)-(canonical.Any(s=>s.SplitBossProxy)?1:0),stairs=StairCount(seed),ordinaryCount=count-stairs-1;
            if(ordinaryCount>families.Length*MaximumOrdinaryRepeats)return null;
            var chosen=new List<DungeonRoomSpec>{Instance(canonical.Single(s=>s.SourceId=="R01"),"R01")};
            var familyCounts=new Dictionary<string,int>(StringComparer.Ordinal){{"R01",1}};var sourceCounts=new Dictionary<string,int>(StringComparer.Ordinal){{"R01",1}};
            int loops=LoopCount(seed);
            // Every authored ordinary source is present before random repeats.
            // The broken and complete R03 statues are separate mandatory source
            // variants, while their repeat cap is still shared by the family.
            foreach(var source in canonical.Where(s=>OrdinaryFamilies.Contains(Family(s.SourceId))))
            {
                if(sourceCounts.ContainsKey(source.SourceId))continue;
                string family=Family(source.SourceId);
                familyCounts[family]=familyCounts.TryGetValue(family,out int previous)?previous+1:1;
                sourceCounts[source.SourceId]=1;
                chosen.Add(Instance(source,source.SourceId=="R07"?"R07":source.SourceId+"_01"));
            }
            // R01's source is also an ordinary cloister. Its original ID alone
            // owns the entrance/return; at least one separate instance repeats.
            chosen.Add(Instance(canonical.Single(s=>s.SourceId=="R01"),"R01_02"));
            familyCounts["R01"]=sourceCounts["R01"]=2;
            // Geometry-driven routes need turns and spare junction sockets.
            // These modest topology reserves are separate from the relative
            // random weights; no sequence or rectangle is reserved.
            if(loops>0)
            {
                foreach(var reserve in new[]{Tuple.Create("R03",loops==3?4:3),Tuple.Create("R04",2),Tuple.Create("R05",loops==3?3:2),Tuple.Create("R06",loops==3?3:2),Tuple.Create("R02",2)})
                    while(familyCounts[reserve.Item1]<reserve.Item2)
                    {
                        var source=canonical.Where(s=>Family(s.SourceId)==reserve.Item1&&(!oneBrokenSaint||s.SourceId!="R03")).OrderBy(s=>sourceCounts.TryGetValue(s.SourceId,out int n)?n:0).First();
                        int occurrence=sourceCounts.TryGetValue(source.SourceId,out int old)?old+1:1;sourceCounts[source.SourceId]=occurrence;
                        familyCounts[reserve.Item1]++;chosen.Add(Instance(source,source.SourceId+"_"+occurrence.ToString("00",CultureInfo.InvariantCulture)));
                    }
            }
            while(chosen.Count<ordinaryCount)
            {
                var available=families.Where(f=>!familyCounts.TryGetValue(f.Id,out int n)||n<MaximumOrdinaryRepeats).ToArray();
                if(available.Length==0)return null;
                int roll=random.Next(available.Sum(f=>f.Weight));var selected=available[0];
                foreach(var candidate in available){roll-=candidate.Weight;if(roll<0){selected=candidate;break;}}
                var source=selected.Sources[random.Next(selected.Sources.Length)];
                familyCounts[selected.Id]=familyCounts.TryGetValue(selected.Id,out int previous)?previous+1:1;
                int occurrence=sourceCounts.TryGetValue(source.SourceId,out int old)?old+1:1;sourceCounts[source.SourceId]=occurrence;
                chosen.Add(Instance(source,source.SourceId+"_"+occurrence.ToString("00",CultureInfo.InvariantCulture)));
            }
            for(int i=1;i<=stairs;i++)chosen.Add(Instance(canonical.Single(s=>s.SourceId=="R08"),i==1?"R08":"R08_"+i.ToString("00",CultureInfo.InvariantCulture)));
            chosen.Add(Instance(canonical.Single(s=>s.SourceId=="R09"),"R09"));
            // Reserve R01's south return and enough ports for the optional
            // actual cycle. The one-port shrine and boss remain terminal.
            if(chosen.Count!=count||chosen.Sum(s=>s.Ports.Length)-1<2*(chosen.Count-1+loops))return null;
            return chosen.ToArray();
        }
    }
}
