using System;
using BepInEx.Configuration;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        private AbbeyAmbienceRuntime ambience;
        private NativeDungeonBackgroundScope nativeBackground;
        private ConfigEntry<bool> ambienceEnabled;
        private ConfigEntry<float> ambienceVolume;
        private LoadedRoom[] ambienceRooms = System.Array.Empty<LoadedRoom>();
        private bool ambienceFaulted;

        private void InitializeAbbeyAmbience()
        {
            AbbeyDoorAudio.Initialize(gameObject, text => Logger.LogInfo(text));
            try
            {
                nativeBackground = gameObject.AddComponent<NativeDungeonBackgroundScope>();
                nativeBackground.Initialize(text => Logger.LogInfo(text));
            }
            catch (Exception error)
            {
                nativeBackground?.Restore();
                Logger.LogWarning("Black Abbey native background scope unavailable: " + error.Message);
            }
            ambienceEnabled = Config.Bind("Ambience", "Enabled", true, "Play the approved Black Abbey ambience only while inside this helper's dungeon.");
            ambienceVolume = Config.Bind("Ambience", "Volume", 1f,
                new ConfigDescription("Multiplier for the approved ambience mix. The native game sound mixer still applies.", new AcceptableValueRange<float>(0f, 1f)));
            try
            {
                ambience = gameObject.AddComponent<AbbeyAmbienceRuntime>();
                ambience.Initialize(SharedDataPath, text => Logger.LogInfo(text));
                ambience.Configure(ambienceEnabled.Value, ambienceVolume.Value);
                Add("twa_test_audio_status", "Report Black Abbey ambience readiness, active sources and native background suppression.", false, () => { ambience?.LogStatus(Print); nativeBackground?.LogStatus(Print); });
                Add("twa_test_audio_toggle", "Mute/unmute this dungeon's ambience only.", false, () => {
                    ambienceEnabled.Value = !ambienceEnabled.Value;
                    ambience.Configure(ambienceEnabled.Value, ambienceVolume.Value);
                    Print("Black Abbey ambience " + (ambienceEnabled.Value ? "enabled." : "muted."));
                });
            }
            catch (Exception error)
            {
                ambienceFaulted = true;
                if (ambience) ambience.Suspend(true);
                Logger.LogWarning("Black Abbey ambience unavailable; room travel remains available: " + error.Message);
            }
        }

        private void UpdateAbbeyAmbience(Player player)
        {
            try
            {
                bool host = ZNet.instance && ZNet.instance.IsServer();
                bool matching = player && Matches(player);
                bool owner = player && player == returnPlayer;
                LoadedRoom containing = null;
                if (player && matching && owner)
                    foreach (var room in ambienceRooms)
                        if (AudioContains(room, player.transform.position)) { containing = room; break; }
                bool passage = player && containing == null && InsideDungeonPassage(player.transform.position);
                bool eligible = AbbeyAmbiencePolicy.IsInside(host, matching, owner, player && !player.IsDead(), busy, containing != null || passage);
                // Native background replacement follows dungeon containment,
                // even when the user mutes the custom bank or loading fails.
                nativeBackground?.SetInside(eligible);
                TickBossMusic(eligible && R09SplitIdentity.IsBossAudioScope(containing?.Manifest.roomId));
                if (!ambience || ambienceFaulted) return;
                ambience.Configure(ambienceEnabled.Value, ambienceVolume.Value * (bossMusic ? bossMusic.AmbienceGain : 1f));
                ambience.Tick(eligible, ambienceRooms, containing ?? (passage ? activeRoom : null),
                    player ? player.transform.position : Vector3.zero, Time.unscaledDeltaTime);
            }
            catch (Exception error)
            {
                bossMusic?.Suspend();
                nativeBackground?.Restore();
                ambienceFaulted = true; if (ambience) ambience.Suspend(true);
                Logger.LogWarning("Black Abbey ambience stopped safely; room travel remains available: " + error.Message);
            }
        }

        private static bool AudioContains(LoadedRoom room, Vector3 position)
        {
            if (room == null || !room.Root || !room.Root.activeInHierarchy) return false;
            var p = room.Root.transform.InverseTransformPoint(position);
            var low = room.Manifest.boundsMin; var high = room.Manifest.boundsMax;
            if (p.x < low[0] || p.x > high[0] || p.z < low[2] || p.z > high[2] || p.y < low[1] - .2f || p.y > high[1] + .2f) return false;
            var polygon = room.Manifest.floorPolygonXZ ?? room.Manifest.footprint;
            if (polygon == null || polygon.Length < 3) return false;
            bool inside = false;
            for (int i = 0, j = polygon.Length - 1; i < polygon.Length; j = i++)
            {
                var a = polygon[i]; var b = polygon[j];
                if ((a[1] > p.z) != (b[1] > p.z) && p.x < (b[0] - a[0]) * (p.z - a[1]) / (b[1] - a[1]) + a[0]) inside = !inside;
            }
            return inside;
        }
    }
}
