using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Logical identity drives planning, encounter RNG and saved topology.
    // Presentation identity describes only the checked art actually loaded.
    internal sealed class RoomPresentationBinding
    {
        internal readonly int SchemaVersion = 1;
        internal readonly string InstanceId, PlannedSourceId, PlannedAssetId, PlannedSourceSha256, PlannedManifestSha256;
        internal readonly string PresentationSourceId, PresentationAssetId, PresentationSourceSha256, PresentationManifestSha256, PresentationPackageDirectory;
        internal readonly bool IsSaintSwap;
        internal RoomPresentationBinding(DungeonRoomSpec spec, CatalogRoomRecord planned, CatalogRoomRecord presentation, bool swap)
        {
            InstanceId = spec.Id; PlannedSourceId = spec.SourceId; PlannedAssetId = spec.AssetId;
            PlannedSourceSha256 = planned.sourceSha256; PlannedManifestSha256 = planned.manifestSha256;
            PresentationSourceId = presentation.roomId; PresentationAssetId = swap ? presentation.roomId : spec.AssetId;
            PresentationSourceSha256 = presentation.sourceSha256; PresentationManifestSha256 = presentation.manifestSha256;
            PresentationPackageDirectory = presentation.packageDirectory; IsSaintSwap = swap;
        }
    }
    internal static class RoomPresentationIdentity
    {
        private static bool Record(CatalogRoomRecord record, PackageManifest manifest, string actualManifestHash) => record != null && manifest != null &&
            record.roomId == manifest.roomId && record.sourceSha256 == manifest.sourceSha256 && CatalogReader.Hash(record.sourceSha256) &&
            CatalogReader.Hash(record.manifestSha256) && record.manifestSha256 == actualManifestHash && !string.IsNullOrWhiteSpace(record.packageDirectory);
        internal static RoomPresentationBinding Create(DungeonRoomSpec spec, CatalogRoomRecord planned, PackageManifest plannedManifest, string plannedFileHash,
            CatalogRoomRecord presentation, PackageManifest presentationManifest, string presentationFileHash, bool boundNaturalRun, string route, string selectedSaint)
        {
            if (spec == null || string.IsNullOrWhiteSpace(spec.Id) || spec.Id.Length > 96 || string.IsNullOrWhiteSpace(spec.SourceId) || string.IsNullOrWhiteSpace(spec.AssetId) ||
                !Record(planned, plannedManifest, plannedFileHash) || !Record(presentation, presentationManifest, presentationFileHash) || spec.SourceId != planned.roomId)
                throw new InvalidDataException("Placed room requires complete exact logical and presentation source identities.");
            var sourceBinding = KitArchitectureProfile.Find(planned.sourceSha256, planned.manifestSha256);
            if (sourceBinding != null && sourceBinding.assetId != spec.AssetId)
                throw new InvalidDataException("Planned room asset differs from its sealed source binding.");
            var presentationBinding = KitArchitectureProfile.Find(presentation.sourceSha256, presentation.manifestSha256);
            if (sourceBinding != null && (presentationBinding == null || presentationBinding.assetId != (spec.SourceId == presentation.roomId ? spec.AssetId : presentation.roomId)))
                throw new InvalidDataException("Loaded room presentation differs from its sealed asset/source binding.");
            string chosen = SaintRoutePresentationPolicy.Source(boundNaturalRun, route, selectedSaint, spec.Id, spec.SourceId);
            if (chosen != presentation.roomId) throw new InvalidDataException("Loaded room presentation differs from its checked route/instance selection.");
            bool swap = spec.SourceId != presentation.roomId;
            if (swap)
            {
                if (spec.SourceId != "R03" || spec.AssetId != "R03" || presentation.roomId != "R03_complete" || presentation.packageDirectory != "R03_complete")
                    throw new InvalidDataException("Only the checked intact-saint presentation may differ from its planned room source.");
                SaintRoutePresentationPolicy.RequireSameInterface(plannedManifest, presentationManifest);
            }
            else if (planned.roomId != presentation.roomId || planned.sourceSha256 != presentation.sourceSha256 || planned.manifestSha256 != presentation.manifestSha256 || planned.packageDirectory != presentation.packageDirectory)
                throw new InvalidDataException("An ordinary placed room cannot silently change its source package.");
            return new RoomPresentationBinding(spec, planned, presentation, swap);
        }
        // Read-only reflection boundary for the separately versioned map.
        // No native object, disk, run, actor or exploration state is touched.
        internal static RoomPresentationBinding Read(LoadedRoom room, string instanceId, string plannedSourceId, string plannedAssetId)
        {
            var binding = room?.PresentationBinding;
            if (binding == null || binding.SchemaVersion != 1 || binding.InstanceId != instanceId || room.InstanceId != instanceId || binding.PlannedSourceId != plannedSourceId || binding.PlannedAssetId != plannedAssetId ||
                room.Record == null || room.Manifest == null || binding.PresentationSourceId != room.Record.roomId || binding.PresentationSourceId != room.Manifest.roomId ||
                binding.PresentationSourceSha256 != room.Record.sourceSha256 || binding.PresentationSourceSha256 != room.Manifest.sourceSha256 ||
                binding.PresentationManifestSha256 != room.Record.manifestSha256 || binding.PresentationPackageDirectory != room.Record.packageDirectory)
                throw new InvalidDataException("Placed room presentation no longer matches its exact logical instance/source binding.");
            return binding;
        }
        internal static bool Matches(LoadedRoom room, string instanceId, string plannedSourceId, string plannedAssetId)
        {
            if (room?.Manifest == null || room.Record == null || room.InstanceId != instanceId) return false;
            if (room.PresentationBinding == null)
                return plannedSourceId == room.Manifest.roomId && room.Record.roomId == room.Manifest.roomId && room.Record.sourceSha256 == room.Manifest.sourceSha256;
            try { Read(room, instanceId, plannedSourceId, plannedAssetId); return true; }
            catch (InvalidDataException) { return false; }
        }
        internal static void RequireUnique(string[] instanceIds)
        {
            if (instanceIds == null || instanceIds.Length == 0 || instanceIds.Length > 64 || instanceIds.Any(id => string.IsNullOrWhiteSpace(id) || id.Length > 96) || instanceIds.Distinct(StringComparer.Ordinal).Count() != instanceIds.Length)
                throw new ArgumentException("Complete unique placed room instances are required for encounter bindings.");
        }
    }
}
