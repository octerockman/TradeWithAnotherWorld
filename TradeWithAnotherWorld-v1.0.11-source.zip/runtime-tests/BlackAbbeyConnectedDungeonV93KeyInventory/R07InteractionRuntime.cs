using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    public sealed class R07InteractionHandle : MonoBehaviour, Hoverable, Interactable
    {
        internal R07InteractionRuntime Owner;
        internal string ContainerId;
        internal int CandleIndex = -1;
        public string GetHoverName() => CandleIndex >= 0 ? "" : ContainerId == "coffin" ? "Stone coffin" : ContainerId == "secret-box" ? "Hidden box" : "Ironbound chest";
        public float GetHoverOffset() => .15f;
        public string GetHoverText()
        {
            if (!Owner) return "";
            string text = CandleIndex >= 0 ? R07FixturePresentation.CandleHover(Owner.CandleLit(CandleIndex)) :
                GetHoverName() + "\n[<color=yellow><b>$KEY_Use</b></color>] " + (Owner.CanOpen(ContainerId) ? "Open" : "Locked");
            return Localization.instance != null ? Localization.instance.Localize(text) : text;
        }
        public bool Interact(Humanoid user, bool hold, bool alt)
        {
            if (hold || !Owner || !(user is Player player) || player != Player.m_localPlayer || !ZNet.instance || !ZNet.instance.IsServer() ||
                (player.transform.position - transform.position).sqrMagnitude > 20.25f) return false;
            return CandleIndex >= 0 ? Owner.ToggleCandle(CandleIndex, player) : Owner.Open(ContainerId, player);
        }
        public bool UseItem(Humanoid user, ItemDrop.ItemData item) => false;
    }

    internal sealed class R07PartMotion : MonoBehaviour
    {
        private Transform room;
        private R07PartRecord spec;
        private Bounds[] bodies;
        private Rigidbody body;
        private R07StoneAudio stoneAudio;
        private R07ChestAudio chestAudio;
        private bool impactPlayed;
        private Action<string> log;
        private bool wasPlayerBlocked;
        private Vector3 lastRoomPosition;
        private Quaternion lastRoomRotation;
        internal Action FirstOpeningAdvance;
        private float phase, target;
        internal bool Opened => phase >= .9999f;
        internal bool OpeningBegan => phase > .00001f;
        internal bool Moving => Mathf.Abs(phase - target) > .0001f;
        internal float Phase => phase;
        internal float Target => target;
        internal bool PlayerBlocked => Moving && SweepBlocked(Player.m_localPlayer, target > .5f);
        internal void Configure(Transform room, R07PartRecord spec, Bounds[] bodies, Action<string> log)
        {
            this.room = room; this.spec = spec; this.bodies = bodies; this.log = log;
            // Host is inactive until all exact concave child colliders and the
            // kinematic body have been configured. No transient dynamic body.
            body = gameObject.AddComponent<Rigidbody>(); body.isKinematic = true; body.useGravity = false;
            stoneAudio = R07StoneAudio.Attach(gameObject, spec.id, log);
            chestAudio = R07ChestAudio.Attach(transform, spec.id, log);
            body.interpolation = RigidbodyInterpolation.None; Apply(true);
        }
        private void PoseAt(float candidate, out Vector3 localPosition, out Quaternion localRotation)
        {
            Vector3 pivot = RoomPackage.Vector(spec.pivot, "part pivot");
            if (spec.id == "coffin-lid")
            {
                R07CoffinLidMotion.Evaluate(candidate, pivot, out localPosition, out localRotation);
                return;
            }
            float t = candidate * candidate * (3 - 2 * candidate);
            localPosition = pivot + RoomPackage.Vector(spec.slideDelta, "part slide") * t;
            localRotation = Mathf.Abs(spec.openAngle) < .001f ? Quaternion.identity : Quaternion.AngleAxis(spec.openAngle * t, RoomPackage.Vector(spec.axis, "part axis").normalized);
        }
        private void Apply(bool teleport)
        {
            PoseAt(phase, out var localPosition, out var localRotation);
            Vector3 position = room.TransformPoint(localPosition); Quaternion rotation = room.rotation * localRotation;
            if (teleport) { body.position = position; body.rotation = rotation; }
            else { body.MovePosition(position); body.MoveRotation(rotation); }
            lastRoomPosition = room.position; lastRoomRotation = room.rotation;
        }
        internal void SyncToRoom() { if (body && room) Apply(true); }
        internal void Set(bool open, bool immediate = false)
        {
            target = open ? 1 : 0;
            if (immediate)
            {
                phase = target; impactPlayed = open; stoneAudio?.SetMoving(false); chestAudio?.Restored(open); Apply(true);
            }
        }
        internal bool SweepBlocked(Player player, bool open)
        {
            if (!player) return false;
            Vector3 pivot = RoomPackage.Vector(spec.pivot, "part pivot");
            float next = open ? 1 : 0;
            for (int i = 0; i <= 20; i++)
            {
                float p = Mathf.Lerp(phase, next, i / 20f);
                PoseAt(p, out var posePosition, out var q);
                Quaternion world = room.rotation * q;
                foreach (var b in bodies)
                {
                    Vector3 center = room.TransformPoint(posePosition + q * (b.center - pivot));
                    foreach (float height in new[] { .35f, .95f, 1.55f })
                    {
                        Vector3 point = Quaternion.Inverse(world) * (player.transform.position + Vector3.up * height - center);
                        Vector3 d = new Vector3(Mathf.Max(0, Mathf.Abs(point.x) - b.extents.x), Mathf.Max(0, Mathf.Abs(point.y) - b.extents.y), Mathf.Max(0, Mathf.Abs(point.z) - b.extents.z));
                        if (d.sqrMagnitude < .34f * .34f) return true;
                    }
                }
            }
            return false;
        }
        private void FixedUpdate()
        {
            if (room.position != lastRoomPosition || room.rotation != lastRoomRotation) SyncToRoom();
            if (!Moving) { wasPlayerBlocked = false; stoneAudio?.SetMoving(false); return; }
            // Stop before advancing into the local participant. Resuming after
            // they clear the sweep does not create a new opening/loot event.
            if (SweepBlocked(Player.m_localPlayer, target > .5f))
            {
                stoneAudio?.SetMoving(false);
                if (!wasPlayerBlocked)
                {
                    wasPlayerBlocked = true;
                    log?.Invoke("R07_MOTION_BLOCKED: part=" + spec.id + "; phase=" + phase.ToString("F4") + "; target=" + target + "; playerLocal=" + room.InverseTransformPoint(Player.m_localPlayer.transform.position).ToString("F3"));
                    if (spec.id == "statue-slide") Player.m_localPlayer.Message(MessageHud.MessageType.Center, "Stand clear of the statue. It will move when the path is clear.");
                }
                return;
            }
            if (wasPlayerBlocked) { wasPlayerBlocked = false; log?.Invoke("R07_MOTION_RESUMED: part=" + spec.id + "; phase=" + phase.ToString("F4")); }
            bool starting = phase <= .00001f && target > .5f;
            float previous = phase;
            float duration = spec.id == "coffin-lid" ? R07CoffinLidMotion.DurationSeconds : spec.durationSeconds;
            phase = Mathf.MoveTowards(phase, target, Time.fixedDeltaTime / duration); Apply(false);
            chestAudio?.Advanced(previous, phase);
            // Synchronous with the first real pose advance. Deactivating this
            // room before a coroutine resumes cannot erase opening history.
            if (starting && phase > .00001f) FirstOpeningAdvance?.Invoke();
            bool scraping = spec.id == "statue-slide" ? Moving : spec.id == "coffin-lid" && R07CoffinLidMotion.IsSliding(phase);
            stoneAudio?.SetMoving(scraping);
            if (spec.id == "coffin-lid" && !impactPlayed && previous < R07CoffinLidMotion.ImpactPhase && phase >= R07CoffinLidMotion.ImpactPhase)
            {
                impactPlayed = true; stoneAudio?.ImpactOnce(room.TransformPoint(R07CoffinLidMotion.ImpactPosition));
            }
        }
        private void OnDisable() { stoneAudio?.SetMoving(false); }
    }

    public sealed class R07InteractionRuntime : MonoBehaviour
    {
        private LoadedRoom room;
        private R07InteractionManifest spec;
        private R07RunState<Inventory> run;
        private Action changed;
        private Action<string> log;
        private R07CoffinSkeleton skeleton;
        private readonly Dictionary<string, R07PartMotion> parts = new Dictionary<string, R07PartMotion>();
        private readonly Dictionary<string, R07LocalInventory> containers = new Dictionary<string, R07LocalInventory>();
        private readonly Dictionary<string, R07InteractionHandle> containerHandles = new Dictionary<string, R07InteractionHandle>();
        private readonly Dictionary<string, GameObject> lights = new Dictionary<string, GameObject>(StringComparer.Ordinal);
        private int fixtureSerial;
        private readonly R07UseLifecycle use = new R07UseLifecycle();
        private float lastCandleUse = -10;
        internal static bool Available(PackageManifest m) => m.roomId == "R07" && !string.IsNullOrEmpty(m.interactionFile);
        internal static void Attach(LoadedRoom room, string directory, R07RunState<Inventory> run, Action changed, Action<string> log)
        {
            if (!Available(room.Manifest)) throw new InvalidDataException("R07 interactions were not declared by this source.");
            string path = RoomPackage.FilePath(directory, room.Manifest.interactionFile);
            if (!CatalogReader.Hash(room.Manifest.interactionSha256) || CatalogReader.HashFile(path) != room.Manifest.interactionSha256) throw new InvalidDataException("Shrine interaction resource changed.");
            var spec = R07InteractionReader.Read(File.ReadAllText(path), room.Manifest);
            var controller = room.Root.AddComponent<R07InteractionRuntime>();
            controller.room = room; controller.spec = spec; controller.run = run; controller.changed = changed; controller.log = log;
            R07InventoryPatches.Install(); controller.Build();
        }
        private void Build()
        {
            foreach (var p in spec.movingParts)
            {
                var owned = p.visualNames.Select(n => room.Root.transform.Find(n)).Concat(p.colliderNames.Select(n => room.Root.transform.Find("Collider | " + n))).ToArray();
                if (owned.Any(t => !t || t.parent != room.Root.transform || t.localPosition.sqrMagnitude > .000001f || Quaternion.Angle(t.localRotation, Quaternion.identity) > .001f || (t.localScale-Vector3.one).sqrMagnitude > .000001f))
                    throw new InvalidDataException("Moving shrine chunks must be direct source-coordinate meshes: " + p.id);
                var bodies = owned.Select(t => t.GetComponent<MeshFilter>()?.sharedMesh?.bounds ?? t.GetComponent<MeshCollider>()?.sharedMesh?.bounds).Where(b => b.HasValue).Select(b => b.Value).ToArray();
                var host = new GameObject("R07 moving part | " + p.id); host.SetActive(false); host.transform.SetParent(room.Root.transform, false);
                Vector3 pivot = RoomPackage.Vector(p.pivot, "part pivot"); host.transform.localPosition = pivot;
                foreach (var t in owned) { t.SetParent(host.transform, false); t.localPosition = -pivot; }
                var motion = host.AddComponent<R07PartMotion>(); motion.Configure(room.Root.transform, p, bodies, log); parts.Add(p.id, motion); host.SetActive(true);
            }
            foreach (var c in spec.candles)
                Handle("R07 candle use | " + c.id, c.interactionCenter, c.interactionSize).CandleIndex = c.clockwiseIndex;
            foreach (var c in spec.containers)
            {
                var inventory = run.Inventory(c.id, seed => R07LocalInventory.SeededInventory(c.id, c.width, c.height, seed));
                string id = c.id;
                // The fallen lid covers the former room-side coffin handle.
                // Keep its interaction over the actual hollow, above the rim.
                Vector3 useCenter = id == "coffin" ? R07CoffinLidMotion.UseCenter : RoomPackage.Vector(c.interactionCenter, "container use");
                Vector3 useSize = id == "coffin" ? R07CoffinLidMotion.UseSize : RoomPackage.Vector(c.interactionSize, "container use");
                var adapter = R07LocalInventory.Create(room.Root.transform, useCenter, inventory,
                    used => { if (!used && parts.TryGetValue(c.partId, out var lid)) lid.Set(id == "coffin" && run.Puzzle.CoffinUnlocked); log("R07_NATIVE_INVENTORY_USE: " + id + "; inUse=" + used + "; retainedItems=" + inventory.GetAllItems().Count + "; no network container."); });
                containers.Add(id, adapter);
                parts[c.partId].FirstOpeningAdvance = () => R07OpeningPolicy.RecordStart(run.Puzzle, id, true, true);
                var handle = Handle("R07 container use | " + id, useCenter, useSize); handle.ContainerId = id; containerHandles.Add(id, handle);
            }
            parts[spec.statuePartId].Set(run.Puzzle.SecretUnlocked, true);
            skeleton = R07CoffinSkeleton.Attach(room.Root.transform, log);
            ResumeEarnedCoffin(true);
            ApplyCandles(); UpdateHiddenBox();
            log("R07_INTERACTIONS: twelve freely toggled shelf candles; six ambient source wicks unchanged; exact clockwise coffin and counterclockwise unopened-container statue masks in any lighting order; automatic coffin lid opening; inert unarmed native Skeleton visual; native local InventoryGui, no ZNetView/ZDO.");
        }
        private R07InteractionHandle Handle(string name, float[] center, float[] size)
            => Handle(name, RoomPackage.Vector(center, name), RoomPackage.Vector(size, name));
        private R07InteractionHandle Handle(string name, Vector3 center, Vector3 size)
        {
            var host = new GameObject(name); host.transform.SetParent(room.Root.transform, false); host.transform.localPosition = center;
            host.layer = LayerMask.NameToLayer("static_solid");
            var handle = host.AddComponent<R07InteractionHandle>(); handle.Owner = this;
            var box = host.AddComponent<BoxCollider>(); box.size = size; return handle;
        }
        internal bool CandleLit(int i) => run.Puzzle.Lit[i];
        internal bool CanOpen(string id) => run.Puzzle.CanOpen(id) && (id != "secret-box" || parts[spec.statuePartId].Opened);
        internal bool ToggleCandle(int i, Player player)
        {
            if (use.Busy || Time.unscaledTime - lastCandleUse < .2f) return true;
            lastCandleUse = Time.unscaledTime;
            var result = run.Puzzle.Toggle(i); ApplyCandles();
            // Both puzzles compare the final lit/out masks. The coffin opens without
            // remotely taking over the player's inventory screen.
            if (result == R07PuzzleState.Result.CoffinSolved) { ResumeEarnedCoffin(); player.Message(MessageHud.MessageType.Center, "A stone lock releases."); }
            if (result == R07PuzzleState.Result.SecretSolved) { parts[spec.statuePartId].Set(true); player.Message(MessageHud.MessageType.Center, "Stone grinds behind the shrine."); }
            if (result == R07PuzzleState.Result.SecretDenied) player.Message(MessageHud.MessageType.Center, "The candle pattern is correct, but the shrine requires the chest and coffin to remain unopened in this run.");
            log("R07_PUZZLE: event=" + result + "; coffinMask=" + run.Puzzle.CoffinPatternMatches + "; statueMask=" + run.Puzzle.SecretPatternMatches + "; coffinUnlocked=" + run.Puzzle.CoffinUnlocked + "; secret=" + run.Puzzle.SecretUnlocked + "; chestEverOpened=" + run.Puzzle.ChestEverOpened + "; coffinEverOpened=" + run.Puzzle.CoffinEverOpened);
            LogPuzzleState(log);
            return true;
        }
        private void ApplyCandles()
        {
            var shelf = spec.candles.ToDictionary(c => c.socketName, c => c.clockwiseIndex, StringComparer.Ordinal); bool[] lit = run.Puzzle.Lit;
            foreach (var socket in room.Manifest.sockets)
            {
                var marker = room.Root.transform.Find(socket.name); var flame = marker ? marker.Find(TradeWithAnotherWorld.ResinCandleFlame.EffectRootName) : null;
                if (!flame) throw new InvalidDataException("A source shrine wick has no canonical flame effect.");
                bool enabled = !shelf.TryGetValue(socket.name, out int index) || lit[index];
                if (flame.gameObject.activeSelf != enabled)
                {
                    flame.gameObject.SetActive(enabled);
                    // Match the canonical binder's explicit native Play call;
                    // relighting must not depend on a prefab playOnAwake flag.
                    if (enabled) flame.GetComponentInChildren<ParticleSystem>(true).Play(true);
                }
            }
            var wicks = room.Manifest.sockets.Select((s, i) => new { s, i }).Where(x => !shelf.TryGetValue(x.s.name, out int index) || lit[index])
                .Select(x => new CandleWickGrouping.Wick { Index = x.i, Name = x.s.name, X = x.s.position[0], Y = x.s.position[1], Z = x.s.position[2] });
            var groups = CandleWickGrouping.Build(wicks);
            Func<CandleWickGrouping.Group, string> key = g => string.Join(",", g.Wicks.Select(w => w.Index).OrderBy(i => i));
            var wanted = new HashSet<string>(groups.Select(key), StringComparer.Ordinal);
            foreach (var stale in lights.Keys.Where(k => !wanted.Contains(k)).ToArray())
            {
                var host = lights[stale];
                if (host)
                {
                    foreach (var f in host.GetComponentsInChildren<BudgetedFixture>(true)) f.EmissionEnabled = false;
                    host.SetActive(false); Object.Destroy(host);
                }
                lights.Remove(stale);
            }
            // Keep every unchanged source group, including all six ambient
            // dais groups. Only a changed active-wick membership needs a new
            // native clone to refresh LightFlicker's cached base intensity.
            NativeCandleFixture.Source source = null;
            for (int i = 0; i < groups.Length; i++)
            {
                var g = groups[i]; string signature = key(g);
                if (lights.TryGetValue(signature, out var existing) && existing) continue;
                if (source == null) source = NativeCandleFixture.Resolve(log);
                string name = R07FixturePresentation.LightName(room.InstanceId, ++fixtureSerial);
                NativeCandleFixture.Attach(room.Root, source, name, new Vector3((float)g.Anchor.X, (float)g.Anchor.Y, (float)g.Anchor.Z) + Vector3.up * TradeWithAnotherWorld.ResinCandleFlame.LightAboveFlame,
                    CandleLightProfile.Intensity("R07", g), CandleLightProfile.Range("R07", g), log);
                lights[signature] = room.Root.transform.Find(name).gameObject;
            }
            changed?.Invoke();
        }
        internal bool Open(string id, Player player)
        {
            if (use.Busy) return true;
            if (!CanOpen(id)) { player.Message(MessageHud.MessageType.Center, "It's locked."); return true; }
            var c = spec.containers.Single(x => x.id == id); var part = parts[c.partId];
            if (!part.Opened && part.SweepBlocked(player, true)) { player.Message(MessageHud.MessageType.Center, "Stand clear of the lid."); return true; }
            if (!InventoryGui.instance) { player.Message(MessageHud.MessageType.Center, "The inventory is not ready."); return true; }
            StartCoroutine(OpenRoutine(id, part, player)); return true;
        }
        private IEnumerator OpenRoutine(string id, R07PartMotion part, Player player)
        {
            if (!use.Begin(id)) yield break;
            part.Set(true);
            while (part && !part.Opened && player && room.Root.activeInHierarchy) yield return null;
            if (!use.Complete(id)) yield break;
            if (part && part.Opened && player == Player.m_localPlayer && room.Root.activeInHierarchy && Vector3.Distance(player.transform.position, containers[id].transform.position) <= 4.5f)
            {
                containers[id].Show(); LogStatus(log);
            }
        }
        private void UpdateHiddenBox()
        {
            if (containerHandles.TryGetValue("secret-box", out var handle)) handle.gameObject.SetActive(run.Puzzle.SecretUnlocked && parts[spec.statuePartId].Opened);
        }
        private void Update() { if (room != null) UpdateHiddenBox(); }
        private void OnDisable()
        {
            StopAllCoroutines(); use.Disable();
            if (spec == null) return;
            foreach (var c in spec.containers)
                if (parts.TryGetValue(c.partId, out var part)) part.Set(c.id == "coffin" && run != null && run.Puzzle.CoffinEverOpened, true);
            foreach (var c in containers.Values) if (c && R07InventoryPatches.IsCurrent(c.Container) && InventoryGui.instance) InventoryGui.instance.Hide();
        }
        private void OnEnable()
        {
            SyncBodies();
            if (spec != null && run != null && parts.TryGetValue(spec.statuePartId, out var statue)) statue.Set(run.Puzzle.SecretUnlocked);
            ResumeEarnedCoffin(true);
            if (room != null)
                foreach (var socket in room.Manifest.sockets)
                {
                    var marker = room.Root.transform.Find(socket.name); var flame = marker ? marker.Find(TradeWithAnotherWorld.ResinCandleFlame.EffectRootName) : null;
                    if (!flame || !flame.gameObject.activeInHierarchy) continue;
                    var particle = flame.GetComponentInChildren<ParticleSystem>(true);
                    if (particle && !particle.isPlaying) particle.Play(true);
                }
        }
        private void ResumeEarnedCoffin(bool restoring = false)
        {
            if (run != null && run.Puzzle.CoffinUnlocked && parts.TryGetValue("coffin-lid", out var coffin)) coffin.Set(true, restoring && run.Puzzle.CoffinEverOpened);
        }
        internal void SyncBodies() { foreach (var p in parts.Values) if (p) p.SyncToRoom(); }
        internal void LogPuzzleState(Action<string> write)
        {
            if (room == null || spec == null || run == null) return;
            bool[] lit = run.Puzzle.Lit;
            int[] clockwise = Enumerable.Range(0, 12).ToArray();
            int[] counterclockwise = clockwise.Select(i => (12 - i) % 12).ToArray();
            Func<int[], string> pattern = order => new string(order.Select(i => lit[i] ? 'l' : 'o').ToArray());
            var desired = new HashSet<int>(run.Puzzle.CounterclockwiseSolution);
            Func<int, string> fixture = i => spec.candles.Single(c => c.clockwiseIndex == i).id + "(CW" + (i + 1) + "/CCW" + (((12 - i) % 12) + 1) + ")";
            string missing = string.Join(",", desired.Where(i => !lit[i]).OrderBy(i => i).Select(fixture));
            string extra = string.Join(",", clockwise.Where(i => lit[i] && !desired.Contains(i)).Select(fixture));
            write("R07_PUZZLE_STATE: clockwise=" + pattern(clockwise) + "; counterclockwise=" + pattern(counterclockwise) + "; required=" + R07PuzzleState.Pattern + "; statueMask=" + run.Puzzle.SecretPatternMatches + "; missingStatue=" + (missing.Length == 0 ? "none" : missing) + "; extraStatue=" + (extra.Length == 0 ? "none" : extra) + "; eligible=" + (!run.Puzzle.ChestEverOpened && !run.Puzzle.CoffinEverOpened) + "; secretEarned=" + run.Puzzle.SecretUnlocked);
            foreach (var pair in parts)
                write("R07_MOTION_STATE: part=" + pair.Key + "; phase=" + pair.Value.Phase.ToString("F4") + "; target=" + pair.Value.Target + "; moving=" + pair.Value.Moving + "; playerBlocked=" + pair.Value.PlayerBlocked);
        }
        internal void LogStatus(Action<string> write)
        {
            if (room == null) return;
            LogPuzzleState(write);
            write("R07_RUN: " + run.RunId + "; pendingUse=" + (use.Pending ?? "none") + "; shelfLit=" + run.Puzzle.Lit.Count(x => x) + "/12; ambientWicks=6; coffinUnlocked=" + run.Puzzle.CoffinUnlocked + "; secret=" + run.Puzzle.SecretUnlocked + "; chestEverOpened=" + run.Puzzle.ChestEverOpened + "; coffinEverOpened=" + run.Puzzle.CoffinEverOpened);
            foreach (var pair in containers)
            {
                var adapter = pair.Value; var c = spec.containers.Single(x => x.id == pair.Key);
                write("R07_NATIVE_UI: " + pair.Key + "; inventoryBound=" + ReferenceEquals(adapter.Inventory, adapter.Container.GetInventory()) + "; screenCurrent=" + R07InventoryPatches.IsCurrent(adapter.Container) + "; inUse=" + adapter.Container.IsInUse() + "; itemStacks=" + adapter.Inventory.GetAllItems().Count + "; emptySlots=" + adapter.Inventory.GetEmptySlots() + "; lidOpen=" + parts[c.partId].Opened + "; moving=" + parts[c.partId].Moving + "; networkView=" + (adapter.GetComponent<ZNetView>() != null));
            }
            if (skeleton) skeleton.LogStatus(write);
        }
    }
}
