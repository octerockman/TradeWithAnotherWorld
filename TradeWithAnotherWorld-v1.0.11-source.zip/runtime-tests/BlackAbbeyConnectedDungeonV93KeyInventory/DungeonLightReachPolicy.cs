using System;
namespace BlackAbbeySixRooms
{
    // Wider reach at the existing source fixtures: no new lights, shadowmaps,
    // ambient exposure or changes to encounter-controlled ignition.
    internal static class DungeonLightReachPolicy
    {
        internal static float CandleRange(string roomId, bool shrine, bool crown) =>
            crown ? 18f : shrine ? 10f : R09SplitIdentity.IsChamber(roomId) ? 10.5f : 7.5f;
        internal static float AuxiliaryRange(float source)
        {
            if (float.IsNaN(source) || float.IsInfinity(source) || source <= 0)
                throw new ArgumentOutOfRangeException(nameof(source));
            return Math.Min(50f, source * 1.35f);
        }
    }
}
