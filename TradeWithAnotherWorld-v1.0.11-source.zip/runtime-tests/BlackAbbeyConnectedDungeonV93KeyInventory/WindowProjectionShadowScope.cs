using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    internal static class WindowProjectionShadowScope
    {
        // A single glass-only layer serves every retained room. Our own earlier
        // panes are not foreign occupancy: reserving a new layer per room made
        // R09 fail once R08 had claimed the sole camera-visible unnamed layer.
        static readonly List<WindowProjectionGlassLease> Leases = new List<WindowProjectionGlassLease>();

        internal static int Prepare(LoadedRoom room, Action<string> log)
        {
            if (room == null || !room.Root) throw new InvalidOperationException("Window projection requires a retained room root.");
            var names = (room.Manifest.windowLights ?? Array.Empty<WindowLightRecord>()).Where(WindowProjectionContract.HasCookie)
                .SelectMany(r => r.shadowExcludeMeshes).Distinct(StringComparer.Ordinal).ToArray();
            if (names.Length == 0) return -1;
            var existing = room.Root.GetComponent<WindowProjectionGlassLease>();
            if (existing && existing.Configured) return existing.Layer;
            var renderers = new List<MeshRenderer>();
            foreach (string name in names)
            {
                var children = room.Root.transform.Cast<Transform>().Where(t => t.name == name).ToArray();
                if (children.Length != 1 || !children[0].GetComponent<MeshRenderer>() || children[0].GetComponent<Collider>() || children[0].childCount != 0)
                    throw new InvalidOperationException("Window shadow exclusion must name one separate visual-only stained-glass mesh.");
                renderers.Add(children[0].GetComponent<MeshRenderer>());
            }
            var cameras = Camera.allCameras.Where(c => c && c.enabled).ToArray();
            if (cameras.Length == 0) throw new InvalidOperationException("A visible game camera is required to reserve a glass-only render layer.");
            // Scan actual occupancy, including inactive/prefab renderers. Only
            // exact currently retained pane identities belonging to our leases
            // may share an occupied layer. Never claim an unrelated renderer.
            Leases.RemoveAll(lease => !lease || !lease.Configured);
            var owned = new HashSet<int>(Leases.SelectMany(lease => lease.OwnedRendererIds()));
            var foreign = Resources.FindObjectsOfTypeAll<Renderer>().Where(r => r && !owned.Contains(r.GetInstanceID()))
                .Select(r => r.gameObject.layer).Distinct().ToArray();
            var named = Enumerable.Range(8, 24).Where(value => !string.IsNullOrEmpty(LayerMask.LayerToName(value))).ToArray();
            int layer = WindowProjectionLayerPolicy.Select(renderers.Select(r => r.gameObject.layer), cameras.Select(c => c.cullingMask),
                foreign, named, Leases.Select(lease => lease.Layer));
            if (layer < 8) throw new InvalidOperationException("No safe unnamed render layer is camera-visible and free of foreign renderers; window projection cannot safely exclude its opaque panes.");

            var lease = existing ? existing : room.Root.AddComponent<WindowProjectionGlassLease>();
            lease.Configure(layer, renderers, Release);
            Leases.Add(lease);
            // A failed room may never have been active, so Unity OnDestroy is
            // not sufficient. LoadedRoom.Dispose always drains these releases.
            room.SharedResourceReleases.Add(lease.Release);
            log?.Invoke("WINDOW_SHADOW_SCOPE: shared glass-only layer=" + layer + "; leasedRooms=" + Leases.Count +
                "; exact visual chunks=" + string.Join(",", names) +
                "; named layers, camera masks, foreign renderers, colliders and global shadow settings unchanged.");
            return layer;
        }

        static void Release(WindowProjectionGlassLease lease) => Leases.Remove(lease);
    }

    // Root ownership also cleans up a room whose later preparation fails.
    // Restore only layers that still belong to this lease, not external edits.
    internal sealed class WindowProjectionGlassLease : MonoBehaviour
    {
        readonly List<MeshRenderer> panes = new List<MeshRenderer>();
        readonly List<int> originalLayers = new List<int>();
        Action<WindowProjectionGlassLease> released;
        internal int Layer { get; private set; } = -1;
        internal bool Configured { get; private set; }

        internal void Configure(int layer, IEnumerable<MeshRenderer> renderers, Action<WindowProjectionGlassLease> release)
        {
            if (Configured) throw new InvalidOperationException("A window glass lease cannot be configured twice.");
            var values = renderers.ToArray();
            if (layer < 8 || layer > 31 || values.Length == 0 || values.Any(r => !r) || values.Distinct().Count() != values.Length)
                throw new InvalidOperationException("A glass lease requires unique retained pane renderers and a valid private layer.");
            Layer = layer; released = release;
            foreach (var renderer in values) { panes.Add(renderer); originalLayers.Add(renderer.gameObject.layer); }
            foreach (var renderer in panes) renderer.gameObject.layer = layer;
            Configured = true;
        }

        internal IEnumerable<int> OwnedRendererIds()
        {
            for (int i = 0; i < panes.Count; i++)
                if (panes[i] && panes[i].gameObject.layer == Layer) yield return panes[i].GetInstanceID();
        }

        void OnDestroy() => Release();
        internal void Release()
        {
            if (!Configured) return;
            Configured = false;
            for (int i = 0; i < panes.Count; i++)
                if (panes[i] && panes[i].gameObject.layer == Layer) panes[i].gameObject.layer = originalLayers[i];
            panes.Clear(); originalLayers.Clear(); Layer = -1;
            var callback = released; released = null; callback?.Invoke(this);
        }
    }
}
