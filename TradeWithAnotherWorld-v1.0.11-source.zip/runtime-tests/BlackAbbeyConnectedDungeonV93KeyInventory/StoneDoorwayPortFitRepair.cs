using System;
using System.IO;
using System.Linq;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // R07's exact SOUTH source places its decorative arch40..225mm inside
    // the port; the reusable lining ends40mm outside it. Extend that existing
    // recessed stone course and its closed backing into the arch overlap.
    // No room wall, decorative arch, threshold, collider or deleted collar is
    // changed. Every other port retains the exact edited kit geometry.
    internal static class StoneDoorwayPortFitRepair
    {
        internal const float Extension=.28f;
        internal const float R09Extension=.10f;
        internal static void ApplyJoin(GameObject instance,LoadedRoom kit,string module,PortRecord a,PortRecord b)
        {
            bool near=IsR07(a),far=IsR07(b),sanctumNear=IsR09(a),sanctumFar=IsR09(b);
            if (sanctumNear || sanctumFar)
            {
                if (sanctumNear && sanctumFar || !(module.EndsWith("_ee",StringComparison.Ordinal) || sanctumNear && module.EndsWith("_ec",StringComparison.Ordinal) || sanctumFar && module.EndsWith("_ce",StringComparison.Ordinal)))
                    throw new InvalidDataException("R09 lining end fit requires its unchanged measured elliptical approach.");
                Apply(instance,kit,module,(float)(a.depth+b.depth+StoneDoorwayJoinPolicy.JointGap(a,b)),sanctumNear,R09Extension,"R09");
            }
            if (!near && !far) return;
            if (near && far || !(module.EndsWith("_ee",StringComparison.Ordinal) || near && module.EndsWith("_ec",StringComparison.Ordinal) || far && module.EndsWith("_ce",StringComparison.Ordinal)))
                throw new InvalidDataException("R07 lining end fit does not match its unchanged elliptical port.");
            Apply(instance,kit,module,(float)(a.depth+b.depth+StoneDoorwayJoinPolicy.JointGap(a,b)),near,Extension,"R07");
        }
        internal static void ApplyReturn(GameObject instance,LoadedRoom kit,string module,PortRecord port)
        {
            if (IsR07(port)) Apply(instance,kit,module,port.depth+.02f,true,Extension,"R07");
        }
        private static bool IsR09(PortRecord port)
        {
            if (port==null || port.SourceRoomId!="R09" || port.id!="SOUTH") return false;
            if (port.position==null || port.position.Length!=3 || Math.Abs(port.position[0])>.00001f || Math.Abs(port.position[1])>.00001f || Math.Abs(port.position[2]+18)>.00001f ||
                port.outward==null || port.outward.Length!=3 || Math.Abs(port.outward[0])>.00001f || Math.Abs(port.outward[1])>.00001f || Math.Abs(port.outward[2]+1)>.00001f ||
                Math.Abs(port.width-3)>.00001f || Math.Abs(port.height-3.515f)>.00001f || Math.Abs(port.depth-.5f)>.00001f || Math.Abs(port.springHeight-2.615f)>.00001f || Math.Abs(port.archRise-.9f)>.00001f)
                throw new InvalidDataException("R09 approach differs from its exact source-bound lining witness.");
            return true;
        }
        private static bool IsR07(PortRecord port)
        {
            if (port==null || port.SourceRoomId!="R07" || port.id!="SOUTH") return false;
            // Unique within the checked room inventory. The loaded room and
            // port schedule are already bound to the configured source SHA.
            if (port.position==null || port.position.Length!=3 || port.position.Any(x=>Math.Abs(x)>.00001f) ||
                port.outward==null || port.outward.Length!=3 || Math.Abs(port.outward[0])>.00001f || Math.Abs(port.outward[1])>.00001f || Math.Abs(port.outward[2]+1)>.00001f ||
                Math.Abs(port.width-3)>.00001f || Math.Abs(port.height-3.5f)>.00001f || Math.Abs(port.depth-.5f)>.00001f || Math.Abs(port.springHeight-2.6f)>.00001f || Math.Abs(port.archRise-.9f)>.00001f)
                throw new InvalidDataException("R07 source port differs from the measured lining end-fit witness.");
            return true;
        }
        private static void Apply(GameObject instance,LoadedRoom kit,string module,float length,bool near,float extension,string sourceRoom)
        {
            bool checkedLongKit=kit?.Manifest?.roomId=="STONE_DOORWAY_KIT_V5"&&kit.Manifest.sourceSha256=="4e00744dde1bc07674c66a7aca5a13ae150aec10e8f95cc2af4783522dcbc754";
            if (!StoneDoorwayBackingRepair.ExactSource(kit)&&!checkedLongKit)
                throw new InvalidDataException("R07 lining end fit requires the exact edited kit source.");
            foreach (string name in new[]{module+"_blocks",module+"_backing"})
            {
                var record=kit.Manifest.meshes.Single(r=>r.name==name);
                var filter=instance.transform.Find(name)?.GetComponent<MeshFilter>();
                if (!filter || filter.sharedMesh.vertexCount!=record.vertices || filter.sharedMesh.triangles.Length!=record.indices)
                    throw new InvalidDataException("R07 lining mesh differs from its loaded source record.");
                var original=filter.sharedMesh;var positions=original.vertices;
                float end=near ? .04f : length-.04f;
                for (int i=0;i<positions.Length;i++)
                {
                    float axial=Mathf.Clamp01((near?end+.12f-positions[i].z:positions[i].z-(end-.12f))/.12f);
                    float floor=Mathf.Clamp01((positions[i].y-.05f)/.1f);
                    positions[i].z+=(near?-extension:extension)*axial*floor;
                }
                var candidate=Object.Instantiate(original);candidate.name=original.name+" | "+sourceRoom+" recessed block-lining end fit";
                candidate.vertices=positions;candidate.RecalculateBounds();filter.sharedMesh=candidate;
                instance.AddComponent<StoneDoorwayBackingLifetime>().Candidate=candidate;
            }
        }
    }
}
