using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
namespace BlackAbbeySixRooms
{
    // Pure source-bound geometry data. Only the checked revision3 master loader
    // may register these; historical source factories keep their exact AABBs.
    internal static class KitPlanningReservationPolicy
    {
        private sealed class Entry { internal double[][] Volumes; }
        private static readonly Dictionary<string,Entry> sources=new Dictionary<string,Entry>(StringComparer.Ordinal);
        internal static void Register(string source,string asset,double[][] volumes)
        {
            if(!CatalogReader.Hash(source)||string.IsNullOrWhiteSpace(asset)||volumes==null||volumes.Length<1||volumes.Length>4096||
                volumes.Any(v=>v==null||v.Length!=6||v.Any(n=>double.IsNaN(n)||double.IsInfinity(n))||v[0]>=v[3]||v[1]>=v[4]||v[2]>=v[5]))
                throw new InvalidDataException("Invalid sealed rebuilt source reservations.");
            string key=source+"|"+asset;
            if(sources.TryGetValue(key,out var old))
            {
                if(old.Volumes.Length!=volumes.Length||old.Volumes.Where((v,i)=>!v.SequenceEqual(volumes[i])).Any())throw new InvalidDataException("Conflicting rebuilt reservation definitions.");
                return;
            }
            sources.Add(key,new Entry{Volumes=volumes.Select(v=>v.ToArray()).ToArray()});
        }
        internal static void Apply(DungeonRoomSpec spec,string source,string asset)
        {
            if(!sources.TryGetValue(source+"|"+asset,out var entry))return;
            spec.Reservations=entry.Volumes.Select(v=>v.ToArray()).ToArray();
            UnrecordedDeadGeneration.ValidateReservations(spec);
            spec.KitConnectedExteriorCollar=true;
        }
        internal static bool ConnectedRoomsOverlap(DungeonPlacement a,PortRecord ap,DungeonPlacement b,PortRecord bp)
        {
            if(!a.Spec.KitConnectedExteriorCollar||!b.Spec.KitConnectedExteriorCollar)return DungeonLayoutPlanner.RoomsOverlap(a,b);
            if(!KitPointedArchitecture.Pointed(ap)||!KitPointedArchitecture.Pointed(bp)||a.Spec.Reservations==null||b.Spec.Reservations==null)
                throw new InvalidDataException("Rebuilt collar overlap needs complete source volumes and two exact pointed fronts.");
            double floor=a.Height(ap.position);
            if(Math.Abs(floor-b.Height(bp.position))>.00001)throw new InvalidDataException("Connected rebuilt floor levels differ.");
            var pa=a.Point(ap.position);var pb=b.Point(bp.position);var normal=a.Normal(ap);
            if(((pb-pa)-normal*.8).Length>.00001||(normal+b.Normal(bp)).Length>.00001)
                throw new InvalidDataException("Rebuilt exterior collar must span the actual opposing0.8m front planes.");
            foreach(var x in a.Volumes())foreach(var y in b.Volumes())
            {
                if(!DungeonLayoutPlanner.Overlap3D(x.Item1,x.Item2,x.Item3,y.Item1,y.Item2,y.Item3))continue;
                var low=new[]{Math.Max(x.Item1[0],y.Item1[0]),Math.Max(x.Item1[1],y.Item1[1])};
                var high=new[]{Math.Min(x.Item1[2],y.Item1[2]),Math.Min(x.Item1[3],y.Item1[3])};
                // Only the direct anchor pair may share buried source supports.
                // All normal room/link tests retain these complete same volumes.
                if(Math.Min(x.Item3,y.Item3)<=floor-.04+1e-7)continue;
                double MinDot(PlanPoint p,PlanPoint n)=>
                    (n.X>=0?low[0]-p.X:high[0]-p.X)*n.X+(n.Z>=0?low[1]-p.Z:high[1]-p.Z)*n.Z;
                // Exterior surfaces may overlap only OUTSIDE BOTH protected
                // interiors, between the actual fronts of this one connection.
                if(MinDot(pa,normal)>=-1e-6&&MinDot(pb,normal*-1)>=-1e-6)continue;
                return true;
            }
            return false;
        }
    }
}
