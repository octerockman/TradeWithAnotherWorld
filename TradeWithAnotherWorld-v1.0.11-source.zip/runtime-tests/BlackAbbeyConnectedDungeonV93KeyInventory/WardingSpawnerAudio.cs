using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Audio;
using Object=UnityEngine.Object;
namespace BlackAbbeySixRooms
{
    // Scoped emitters inherit the live monk's native creature SFX mixer. They
    // are not under EnvMan/AudioMan's background roots and are never looped.
    internal sealed class WardingSpawnerAudio:IDisposable
    {
        sealed class Manifest {public string schema;public Clip[] clips;}
        sealed class Clip {public string path,sha256;public int frames,sampleRate,channels;}
        sealed class Voice {internal AudioSource source;internal float next;internal int sequence;}
        static WardingSpawnerAudio current;
        readonly Dictionary<string,Voice> voices=new Dictionary<string,Voice>(StringComparer.Ordinal);
        readonly List<AudioClip> clips=new List<AudioClip>();readonly List<VerifiedResourceFile> leases=new List<VerifiedResourceFile>();
        GameObject root;Action<string> log;bool disposed;
        internal static void Initialize(GameObject parent,string directory,Action<string> logger)
        {
            current?.Dispose();var next=new WardingSpawnerAudio{log=logger};current=next;
            try
            {
                string manifest=Path.Combine(directory,"manifest.json");if(!File.Exists(manifest)||new FileInfo(manifest).Length>32768)throw new InvalidDataException("Missing/oversized ward audio manifest.");
                var m=JsonConvert.DeserializeObject<Manifest>(File.ReadAllText(manifest));if(m?.schema!="black-abbey.warding-spawner-audio.v1"||m.clips==null||m.clips.Length!=3)throw new InvalidDataException("Invalid ward audio manifest.");
                next.root=new GameObject("BA Warding door cue voices");next.root.transform.SetParent(parent.transform,false);
                foreach(var row in m.clips)
                {
                    if(row.path==null||Path.GetFileName(row.path)!=row.path||row.frames<1||row.frames>48000*5||row.channels!=1||row.sampleRate!=48000)throw new InvalidDataException("Invalid ward cue resource.");
                    var lease=new VerifiedResourceFile(Path.GetFullPath(Path.Combine(directory,row.path)),row.sha256,48000*5*2+4096);next.leases.Add(lease);var pcm=PcmWave.Read(lease.Read());
                    if(pcm.Frames!=row.frames)throw new InvalidDataException("Ward cue frame binding differs.");
                    var clip=AudioClip.Create("BA "+row.path,pcm.Frames,1,48000,false);clip.SetData(pcm.Samples,0);next.clips.Add(clip);
                }
                logger?.Invoke("WARD_AUDIO_READY: three source-bound muffled oak/iron/monk-effort cues; native creature SFX routing; current listening pending.");
            }
            catch(Exception error){next.Dispose();logger?.Invoke("WARD_AUDIO_UNAVAILABLE: "+error.Message+"; spawner logic remains available.");}
        }
        internal static void Bang(string sourceId,Vector3 point,Character monk)
        {
            var own=current;if(own==null||own.disposed||!own.root||own.clips.Count==0||!WardingSpawnerActors.IsAlive(monk))return;
            if(!own.voices.TryGetValue(sourceId,out var voice))
            {
                if(own.voices.Count>=6)return;
                var mixer=monk.GetComponentsInChildren<AudioSource>(true).Select(s=>s.outputAudioMixerGroup).FirstOrDefault(m=>m);
                if(!mixer)return; // Never bypass the native Effects volume.
                var node=new GameObject("Returned Monk | "+sourceId);node.transform.SetParent(own.root.transform,false);var source=node.AddComponent<AudioSource>();
                source.playOnAwake=false;source.loop=false;source.outputAudioMixerGroup=mixer;source.spatialBlend=1;source.rolloffMode=AudioRolloffMode.Logarithmic;
                source.minDistance=2;source.maxDistance=27;source.dopplerLevel=0;source.priority=92;source.volume=.85f;
                own.voices.Add(sourceId,voice=new Voice{source=source});
            }
            if(Time.time<voice.next||voice.source.isPlaying)return;
            voice.source.transform.position=point;voice.source.clip=own.clips[voice.sequence%own.clips.Count];voice.sequence++;
            voice.source.pitch=1;voice.source.Play();voice.next=Time.time+7.1f+(voice.sequence%3)*1.3f;
        }
        internal static void Stop(string sourceId)
        {if(current!=null&&current.voices.TryGetValue(sourceId,out var voice)){if(voice.source)voice.source.Stop();voice.next=0;}}
        internal static void Distress(Character monk)
        {
            if(!WardingSpawnerActors.IsMonk(monk)||!WardingSpawnerActors.IsHostOwned(monk))return;
            var controller=monk.GetComponents<MonoBehaviour>().FirstOrDefault(x=>x&&x.GetType().FullName=="BlackAbbey.HushedMonk.MonkAudioController");
            try{controller?.GetType().GetMethod("OnAlert",Type.EmptyTypes)?.Invoke(controller,null);}catch(Exception error){current?.log?.Invoke("WARD_DISTRESS_CUE_DEFERRED: "+error.GetType().Name);}
        }
        public void Dispose()
        {
            if(disposed)return;disposed=true;foreach(var voice in voices.Values)if(voice.source)voice.source.Stop();voices.Clear();
            if(root)Object.Destroy(root);foreach(var clip in clips)if(clip)Object.Destroy(clip);clips.Clear();foreach(var lease in leases)lease.Dispose();leases.Clear();
            if(ReferenceEquals(current,this))current=null;
        }
        internal static void Shutdown()=>current?.Dispose();
    }
}
