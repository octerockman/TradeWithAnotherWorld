using System;
using System.IO;

namespace BlackAbbeySixRooms
{
    // The installed Abbot bridge reflects three legacy fields. This DTO owns
    // no room/resources and never substitutes for the helper's actual owner.
    internal sealed class R09LegacyArenaManifest
    {
        public readonly string roomId="R09";
        public readonly string sourceSha256=R09CandleSourceBinding.BaseSourceSha256;
    }
    internal sealed class R09LegacyArenaRoom
    {
        public readonly R09LegacyArenaManifest Manifest=new R09LegacyArenaManifest();
        public readonly object Root;
        public readonly string InstanceId;
        public readonly string ActualSourceSha256,ActualManifestSha256;
        internal R09LegacyArenaRoom(object root,string instance,string actualSource,string actualManifest)
        {Root=root;InstanceId=instance;ActualSourceSha256=actualSource;ActualManifestSha256=actualManifest;}
    }
    internal static class R09EncounterCompatibility
    {
        internal static object LegacyActorView(object actualOwner,object root,string instance,string roomId,
            string source,string recordSource,string declaredManifest,string actualManifest)
        {
            if(actualOwner==null)throw new ArgumentNullException(nameof(actualOwner));
            // Base and unrelated identities stay exactly as supplied. Unknown
            // sources remain subject to the installed actor's strict rejection.
            bool rebuilt=KitArchitectureProfile.Find(source,actualManifest)?.actorCompatibility==true;
            bool split=R09SplitIdentity.IsChamber(roomId);
            if(split&&!R09SplitIdentity.RequireSealed(roomId,source,actualManifest).actorCompatibility)
                throw new InvalidDataException("The split arena has no sealed installed-actor compatibility evidence.");
            if(roomId!="R09"&&!split||source!=R09CandleSourceBinding.AlternateSourceSha256&&!rebuilt)return actualOwner;
            if(recordSource!=source||!R09CandleSourceBinding.Matches(source,declaredManifest,actualManifest))
                throw new InvalidDataException("R09 legacy actor compatibility requires the exact alternate source and matching catalog/file manifest bytes.");
            if(root==null||string.IsNullOrWhiteSpace(instance))
                throw new InvalidDataException("R09 legacy actor compatibility requires the actual room root and instance identity.");
            return new R09LegacyArenaRoom(root,instance,source,actualManifest);
        }
    }
}
