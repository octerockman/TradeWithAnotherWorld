using System;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Presentation selection is deliberately separate from the persisted plan.
    // Its source IDs/transforms/links and fingerprint remain exactly unchanged.
    internal static class SaintRoutePresentationPolicy
    {
        internal static string Source(bool boundNaturalRun,string route,string selectedSaint,string instanceId,string plannedSource)
        {
            if(!boundNaturalRun||(plannedSource!="R03"&&plannedSource!="R03_complete"))return plannedSource;
            if(route!="false-vows"&&route!="unrecorded-dead")return plannedSource;
            if(route=="false-vows"&&string.IsNullOrEmpty(selectedSaint))
                throw new InvalidDataException("Three False Vows has no selected saint instance; the saved plan was retained.");
            return route=="false-vows"&&instanceId==selectedSaint?"R03":"R03_complete";
        }
        private static bool Same(float[] a,float[] b)=>a!=null&&b!=null&&a.SequenceEqual(b);
        private static bool Same(float[][] a,float[][] b)=>a!=null&&b!=null&&a.Length==b.Length&&a.Where((row,i)=>!Same(row,b[i])).Count()==0;
        internal static CatalogRoomRecord Replacement(bool boundNaturalRun,string route,string selectedSaint,DungeonRoomSpec spec,RoomCatalog catalog,string dataRoot)
        {
            if(spec==null)throw new InvalidDataException("Missing planned saint presentation identity.");
            string source=Source(boundNaturalRun,route,selectedSaint,spec.Id,spec.SourceId);
            if(source==spec.SourceId)return null;
            var planned=catalog.rooms.Single(r=>r.roomId==spec.SourceId);var intact=catalog.rooms.Single(r=>r.roomId==source);
            string plannedFile=Path.Combine(CatalogReader.PackagePath(dataRoot,planned),"manifest.json");
            string intactFile=Path.Combine(CatalogReader.PackagePath(dataRoot,intact),"manifest.json");
            if(CatalogReader.HashFile(plannedFile)!=planned.manifestSha256||CatalogReader.HashFile(intactFile)!=intact.manifestSha256)
                throw new InvalidDataException("Saint presentation source changed; no saved plan was modified.");
            RequireSameInterface(ManifestReader.Read(File.ReadAllText(plannedFile)),ManifestReader.Read(File.ReadAllText(intactFile)));
            return intact;
        }
        internal static void RequireSameInterface(PackageManifest planned,PackageManifest presentation)
        {
            if(planned==null||presentation==null||planned.roomId!="R03"||presentation.roomId!="R03_complete"||
                !Same(planned.boundsMin,presentation.boundsMin)||!Same(planned.boundsMax,presentation.boundsMax)||
                !Same(planned.floorPolygonXZ,presentation.floorPolygonXZ)||!Same(planned.entryPosition,presentation.entryPosition)||
                !Same(planned.entryForward,presentation.entryForward)||planned.ports==null||presentation.ports==null||planned.ports.Length!=presentation.ports.Length)
                throw new InvalidDataException("Intact-saint presentation differs from the saved room envelope or floor/entry contract.");
            for(int i=0;i<planned.ports.Length;i++)
            {
                var a=planned.ports[i];var b=presentation.ports[i];
                if(a==null||b==null||a.id!=b.id||a.side!=b.side||!Same(a.position,b.position)||!Same(a.outward,b.outward)||
                    !Same(a.outerThresholdPosition,b.outerThresholdPosition)||a.width!=b.width||a.height!=b.height||a.depth!=b.depth||
                    a.wallThickness!=b.wallThickness||a.springHeight!=b.springHeight||a.archRise!=b.archRise||!Same(a.apertureProfileWidthHeight,b.apertureProfileWidthHeight))
                    throw new InvalidDataException("Intact-saint presentation has another connection profile; the saved plan was retained.");
            }
        }
    }
}
