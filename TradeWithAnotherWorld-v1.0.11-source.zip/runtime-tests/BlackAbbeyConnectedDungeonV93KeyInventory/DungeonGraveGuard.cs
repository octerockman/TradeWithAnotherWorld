using System;
using System.Collections.Generic;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Run-local retirement guard. Uses the native incremental ZDO query so
    // unloaded graves still protect the rooms; never scans all scene objects.
    internal sealed class DungeonGraveGuard
    {
        const float StepInterval = .10f, ClearResultLifetime = 2f;
        readonly List<ZDO> batch = new List<ZDO>();
        readonly HashSet<ZDOID> found = new HashSet<ZDOID>();
        readonly List<ZDOID> stale = new List<ZDOID>();
        ZDOMan manager;
        string prefabName;
        int prefabHash, sectorIndex;
        float nextStep, nextScan;
        bool scanning, clearPass;

        internal bool BlockRetirement(Func<Vector3, bool> inside)
        {
            if (inside == null) throw new ArgumentNullException(nameof(inside));
            if (ZDOMan.instance == null) return true;
            if (!ReferenceEquals(manager, ZDOMan.instance))
            {
                manager = ZDOMan.instance; found.Clear(); batch.Clear();
                scanning = clearPass = false; sectorIndex = 0; nextStep = nextScan = 0;
            }
            if (prefabName == null)
            {
                // Read the actual native Player prefab reference, rather than
                // guessing a tombstone name or asking the asset loader for one.
                var player = Player.m_localPlayer;
                if (!player || !player.m_tombstone || string.IsNullOrWhiteSpace(player.m_tombstone.name)) return true;
                prefabName = player.m_tombstone.name; prefabHash = prefabName.GetStableHashCode();
            }

            stale.Clear();
            foreach (var id in found)
                if (!Matches(manager.GetZDO(id), inside)) stale.Add(id);
            foreach (var id in stale) found.Remove(id);
            if (found.Count != 0) return true;

            float now = Time.unscaledTime;
            if (!scanning)
            {
                if (clearPass && now < nextScan) return false;
                if (now < nextStep) return true;
                sectorIndex = 0; batch.Clear(); scanning = true; clearPass = false; nextStep = now;
            }
            if (now < nextStep) return true;
            nextStep = now + StepInterval;
            bool complete;
            try
            {
                // At most one native scan slice per call and per100ms. The
                // native method scans at most401 nonempty sectors per slice.
                // Clear each batch immediately, so no full-world result grows.
                complete = manager.GetAllZDOsWithPrefabIterative(prefabName, batch, ref sectorIndex);
                foreach (var zdo in batch)
                    if (Matches(zdo, inside)) { found.Add(zdo.m_uid); break; }
            }
            catch (Exception)
            {
                // An incomplete/failed query cannot establish an empty room.
                batch.Clear(); scanning = false; clearPass = false; return true;
            }
            batch.Clear();
            if (found.Count != 0)
            {
                // Query exact saved UIDs cheaply until recovered/destroyed.
                // Once those disappear, start a fresh complete native pass.
                scanning = false; clearPass = false; return true;
            }
            if (!complete) return true;
            scanning = false; clearPass = true; nextScan = now + ClearResultLifetime;
            return false;
        }

        bool Matches(ZDO zdo, Func<Vector3, bool> inside)
        {
            if (zdo == null || !zdo.IsValid() || zdo.GetPrefab() != prefabHash) return false;
            Vector3 current = zdo.GetPosition();
            // Native tombstones remember their original spawn point. A grave
            // that fell after an older build removed its floor still belongs
            // to that room, even if its present altitude is now outside it.
            return inside(current) || inside(zdo.GetVec3(ZDOVars.s_spawnPoint, current));
        }
    }
}
