using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace BlackAbbeySixRooms
{
    // Pure source contracts shared by the runtime and actual-package probe.
    // A new room adds a small port record; it never duplicates door artwork.
    internal static class RuntimeCatalogBindings
    {
        // R09's approach is an open landing; its large authored E door is
        // internal. Reuse ordinary oak only in the other checked room's arch.
        // A stair-to-approach join remains open, like existing seeded joins.
        internal static int SharedDoorEndpoint(string a, string b)
        {
            if ((!CatalogReader.RoomIds.Contains(a)&&a!="R09-A2") || (!CatalogReader.RoomIds.Contains(b)&&b!="R09-A2"))
                throw new InvalidDataException("Unknown shared-door endpoint room.");
            if (a != "R08" && !R09SplitIdentity.IsPiece(a)) return 0;
            if (b != "R08" && !R09SplitIdentity.IsPiece(b)) return 1;
            return -1;
        }
        internal static void ValidateDoorVariants(PackageManifest oak, IEnumerable<PackageManifest> source)
        {
            if (oak?.doorFit?.woodProfileMode != AssemblyPartPolicy.PerPortMode) return;
            AssemblyPartPolicy.ValidateVariants(oak);
            var rooms = source?.ToArray();
            if (rooms == null || rooms.Any(r => r == null || !CatalogReader.Hash(r.sourceSha256) || r.ports == null || r.ports.Length == 0) ||
                !CatalogReader.ValidRoomInventory(rooms.Select(r => r.roomId)))
                throw new InvalidDataException("Door profiles require the complete source-bound room catalog.");
            var expected = new HashSet<string>(StringComparer.Ordinal);
            foreach (var room in rooms)
            {
                if (room.roomId == "R07" && (room.ports.Length != 1 || room.ports[0]?.id != "SOUTH"))
                    throw new InvalidDataException("R07 is a one-south-port dead-end shrine.");
                if (room.roomId == "R09" && (room.ports.Length != 1 || room.ports[0]?.id != "SOUTH" ||
                    room.ports[0].position == null || room.ports[0].position.Length != 3 ||
                    Math.Abs(room.ports[0].position[2] + 18) > .002f || Math.Abs(room.ports[0].position[1]) > .002f))
                    throw new InvalidDataException("R09 retains its single source SOUTH arrival at Z-18/Y0; the larger boss door is internal.");
                if(room.roomId=="R08"&&(room.ports.Length!=2||Math.Abs(room.ports.Min(p=>p.position[1]))>.001||Math.Abs(room.ports.Max(p=>p.position[1])-10.8)>.001))
                    throw new InvalidDataException("R08 must retain both lower/upper source thresholds10.8m apart.");
                // R08 keeps its approved open arches: the first main tread
                // occupies the southern leaf sweep. Shared doors therefore
                // mount in the linked OTHER room's checked arch, never here.
                if(room.roomId=="R08" || R09SplitIdentity.IsPiece(room.roomId))continue;
                foreach (var port in room.ports)
                    if (port == null || string.IsNullOrWhiteSpace(port.id) || !expected.Add(room.roomId + "/" + port.id))
                        throw new InvalidDataException("Duplicate or missing source room port.");
            }
            var actual = new HashSet<string>(oak.doorFit.variants.Select(v => v.roomId + "/" + v.portId), StringComparer.Ordinal);
            if (!expected.SetEquals(actual)) throw new InvalidDataException("Oak port records differ from the actual room catalog.");
            foreach (var variant in oak.doorFit.variants)
            {
                var room = rooms.Single(r => r.roomId == variant.roomId);
                if (variant.sourceSha256 != room.sourceSha256)
                    throw new InvalidDataException("Oak port record is bound to another room source: " + variant.roomId + "/" + variant.portId);
            }
        }

#pragma warning disable 0649
        private sealed class TrimHeader { public int schemaVersion; public TrimSource[] rooms; }
        private sealed class TrimSource { public string roomId, sourceSha256; }
#pragma warning restore 0649
        internal static void ValidateTrimSources(string json, RoomCatalog catalog)
        {
            if (json == null || json.Length > 16 * 1024 * 1024 || catalog?.rooms == null)
                throw new InvalidDataException("Missing or oversized source-bound trim inventory.");
            var map = JsonConvert.DeserializeObject<TrimHeader>(json, ManifestReader.Settings());
            if (map == null || map.schemaVersion != 1 || map.rooms == null ||
                !CatalogReader.ValidRoomInventory(map.rooms.Select(r => r?.roomId)) ||
                !new HashSet<string>(map.rooms.Select(r => r.roomId), StringComparer.Ordinal).SetEquals(catalog.rooms.Select(r => r.roomId)))
                throw new InvalidDataException("Trim inventory differs from the actual room catalog.");
            foreach (var row in map.rooms)
                if (!CatalogReader.Hash(row.sourceSha256) || row.sourceSha256 != catalog.rooms.Single(r => r.roomId == row.roomId).sourceSha256)
                    throw new InvalidDataException("Trim inventory is bound to another room source: " + row.roomId);
        }
    }
}
