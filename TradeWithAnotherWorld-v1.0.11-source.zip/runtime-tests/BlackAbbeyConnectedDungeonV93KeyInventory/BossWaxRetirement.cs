using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Rendering;

namespace BlackAbbeySixRooms
{
    internal sealed class BossWaxPresentationBinding : MonoBehaviour
    {
        internal string PayloadSha256;
        internal Mesh Mesh;
    }
    internal static class BossWaxRetirement
    {
        internal const string ResourceName = "BlackAbbey.BossWaxRetirementV80.json";
        internal const string PayloadSha256 = "881718bd9094d78b02a5c194675a92dc5cd0ecd64de2f1fdde9eb4634a0dadbf";
        private sealed class Prepared
        {
            internal int[] OriginalTriangles;
            internal int Vertices, Indices, RemovedTriangles;
            internal string ProofHash;
            internal bool Attached;
        }
        private static readonly ConditionalWeakTable<LoadedRoom, Prepared> prepared = new ConditionalWeakTable<LoadedRoom, Prepared>();
        private static readonly Lazy<BossWaxRetirementFile> payload = new Lazy<BossWaxRetirementFile>(ReadPayload, LazyThreadSafetyMode.ExecutionAndPublication);
        private static byte[] Resource(string name, string hash, int maximum)
        {
            using (var stream = typeof(BossWaxRetirement).Assembly.GetManifestResourceStream(name))
            {
                if (stream == null || stream.Length < 1 || stream.Length > maximum) throw new InvalidDataException("Checked boss wax resource is absent or oversized.");
                byte[] bytes; using (var memory = new MemoryStream()) { stream.CopyTo(memory); bytes = memory.ToArray(); }
                if (BarMeshReader.Hash(bytes) != hash) throw new InvalidDataException("Checked boss wax resource changed.");
                return bytes;
            }
        }
        private static BossWaxRetirementFile ReadPayload()
        {
            var file = JsonConvert.DeserializeObject<BossWaxRetirementFile>(System.Text.Encoding.UTF8.GetString(Resource(ResourceName, PayloadSha256, 2 * 1024 * 1024)), ManifestReader.Settings());
            BossWaxRetirementPolicy.Require(file); return file;
        }
        private static BossWaxRoomPin Scope(LoadedRoom room)
        {
            string asset = room?.Record?.packageDirectory;
            if (asset != "R09" && asset != "R09-UD") return null;
            var pin = payload.Value.rooms.Single(p => p.assetId == asset);
            if (room.Manifest == null || room.Record.roomId != "R09" || room.Manifest.roomId != "R09" || room.Record.sourceSha256 != pin.sourceSha256 || room.Manifest.sourceSha256 != pin.sourceSha256 || room.Record.manifestSha256 != pin.manifestSha256)
                throw new InvalidDataException("Boss wax requires its exact original source/manifest owner.");
            return pin;
        }
        internal static string RemainderCacheToken(LoadedRoom room, PewMeshRecord source, bool collider)
        {
            if (collider || source == null || source.purpose != "render" || source.name != "bake-props_fixtures" || Scope(room) == null) return "";
            var expected = payload.Value.sourceMesh;
            if (source.sourceMeshSha256 != expected.sha256 || source.sourceVertexCount != expected.vertices || source.sourceIndexCount != expected.indices)
                throw new InvalidDataException("Boss wax pew remainder differs from its original source record.");
            return "|boss-wax-retirement-v80|" + PayloadSha256;
        }
        private static void ProtectedOwnership(string dataRoot, BossWaxRetirementFile file, PewRoomRecord pews)
        {
            if (pews?.pews == null) throw new InvalidDataException("Boss wax lacks the checked original pew ownership.");
            var protectedSets = new List<int[]>();
            protectedSets.Add(pews.pews.SelectMany(p => p.meshes).Where(m => m.purpose == "render" && m.name == file.sourceMesh.name)
                .SelectMany(m => m.ranges).SelectMany(r => Enumerable.Range(r.startIndex / 3, r.indexCount / 3)).ToArray());
            const string relative = "false-vows/false-vows-assets.json";
            string hash = KitArchitectureProfile.ExpectedHash(dataRoot, relative, FalseVowsAssetVersion.ManifestSha256);
            var bytes = BarMeshReader.ReadVerifiedBytes(RoomPackage.FilePath(dataRoot, relative), hash, 8L * 1024 * 1024);
            var quest = JsonConvert.DeserializeObject<FalseVowsAssetManifest>(System.Text.Encoding.UTF8.GetString(bytes), ManifestReader.Settings());
            var normal = file.rooms.Single(p => p.assetId == "R09");
            var active = quest?.rooms?.Where(r => r.id == "R09" && r.baseSourceSha256 == normal.sourceSha256 && r.baseManifestSha256 == normal.manifestSha256).ToArray();
            var inactive = quest?.routeVisibilityBindings?.Where(r => r.roomId == "R09" && file.rooms.Any(p => p.assetId == r.assetId && p.sourceSha256 == r.baseSourceSha256 && p.manifestSha256 == r.baseManifestSha256)).ToArray();
            if (active?.Length != 1 || inactive?.Length != 2) throw new InvalidDataException("Boss wax lacks both exact route visibility ownership records.");
            foreach (var masks in active.Select(r => r.masks).Concat(inactive.Select(r => r.masks)))
            {
                if (masks == null) throw new InvalidDataException("Boss wax route ownership is absent.");
                foreach (var mask in masks.Where(m => !m.collider && m.name == file.sourceMesh.name))
                {
                    if (mask.meshSha256 != file.sourceMesh.sha256 || mask.triangleIndices == null) throw new InvalidDataException("Boss wax route ownership changed its source batch.");
                    protectedSets.Add(mask.triangleIndices);
                }
            }
            BossWaxRetirementPolicy.RequireDisjoint(file, protectedSets.ToArray());
        }
        // Exact-count source/pew selections have already happened. Only the
        // managed non-pew remainder is filtered before its ONE existing upload.
        internal static PewMeshSection PrepareRemainder(LoadedRoom room, string dataRoot, PewRoomRecord pews, PewMeshRecord source, PewMeshSection section, Vector3[] sourcePositions)
        {
            if (RemainderCacheToken(room, source, false).Length == 0) return section;
            if (section == null || section.SourceVertices == null || section.Indices == null || section.SourceTriangles == null || sourcePositions == null || sourcePositions.Length != payload.Value.sourceMesh.vertices ||
                section.SourceVertices.Any(i => i < 0 || i >= sourcePositions.Length) || prepared.TryGetValue(room, out _))
                throw new InvalidDataException("Boss wax requires one exact current managed pew remainder.");
            var file = payload.Value; ProtectedOwnership(dataRoot, file, pews);
            var result = BossWaxRetirementPolicy.Retire(file, section.SourceVertices.Length, section.Indices, section.SourceTriangles, (v, axis) => {
                var p = sourcePositions[section.SourceVertices[v]]; return axis == 0 ? p.x : axis == 1 ? p.y : p.z;
            });
            if (result.Indices.Length < 3) throw new InvalidDataException("Boss wax cannot remove the entire non-pew room batch.");
            prepared.Add(room, new Prepared { OriginalTriangles = result.OriginalTriangles, Vertices = section.SourceVertices.Length, Indices = result.Indices.Length, RemovedTriangles = result.RemovedTriangles, ProofHash = BossWaxRetirementPolicy.ProofHash(result.OriginalTriangles) });
            return new PewMeshSection { SourceVertices = section.SourceVertices, SourceTriangles = result.OriginalTriangles, Indices = result.Indices };
        }
        private static MeshRecord Record(BossWaxMeshPin mesh) => new MeshRecord { name = mesh.name, meshFile = mesh.meshFile, sha256 = mesh.sha256, partId = mesh.partId, materialIndex = mesh.materialIndex, vertices = mesh.vertices, indices = mesh.indices, triangles = mesh.triangles, bytes = mesh.bytes };
        internal static BarMeshData DecodeExtra()
        {
            var file = payload.Value;
            using (var compressed = new MemoryStream(Resource(file.extraResource, file.extraSha256, 16 * 1024 * 1024), false))
            using (var gzip = new GZipStream(compressed, CompressionMode.Decompress))
            {
                var data = BarMeshReader.Decode(gzip, Record(file.extraMesh), false);
                for (int i = 0; i < data.Positions.Length; i++)
                {
                    var n = data.Normals[i]; var t = data.Tangents[i]; var uv = data.UV[i];
                    float ns = n.sqrMagnitude, ts = t.x * t.x + t.y * t.y + t.z * t.z, dot = n.x * t.x + n.y * t.y + n.z * t.z;
                    if (ns < .8f || ns > 1.2f || ts < .8f || ts > 1.2f || Math.Abs(dot) > .025f || Math.Abs(Math.Abs(t.w) - 1) > .0001f || uv.x < 0 || uv.y < 0 || uv.x > 1 || uv.y > 1)
                        throw new InvalidDataException("New boss wax has an invalid checked tangent frame or UV.");
                }
                return data;
            }
        }
        internal static void Attach(LoadedRoom room, Action<string> log)
        {
            if (Scope(room) == null) return;
            var file = payload.Value;
            if (!prepared.TryGetValue(room, out var state) || state.Attached) throw new InvalidDataException("Boss wax must attach exactly once after its checked pew remainder.");
            var child = room.Root.transform.Find(file.sourceMesh.name);
            var filter = child ? child.GetComponent<MeshFilter>() : null;
            var renderer = child ? child.GetComponent<MeshRenderer>() : null;
            var proof = child ? child.GetComponent<PewSourceRemainder>() : null;
            if (!filter || !renderer || !renderer.sharedMaterial || !proof || !filter.sharedMesh ||
                proof.OriginalMeshSha256 != file.sourceMesh.sha256 || proof.OriginalIndexCount != file.sourceMesh.indices)
                throw new InvalidDataException("Boss wax current mesh differs from the proven exact managed remainder.");
            BossWaxRetirementPolicy.RequireCurrentReference(filter.sharedMesh, proof.Remainder, filter.sharedMesh.vertexCount, (int)filter.sharedMesh.GetIndexCount(0), proof.OriginalTriangles, state.OriginalTriangles, state.Vertices, state.Indices, state.ProofHash);
            string key = "boss-new-wax-v80|" + file.extraSha256;
            if (!SharedRoomResources.TryAcquire<Mesh>(key, room, out var mesh))
            {
                var data = DecodeExtra();
                mesh = new Mesh { name = file.extraMesh.name, indexFormat = IndexFormat.UInt32 }; room.Resources.Add(mesh);
                mesh.vertices = data.Positions; mesh.normals = data.Normals; mesh.uv = data.UV; mesh.tangents = data.Tangents;
                var colors = new Color32[data.Positions.Length]; for (int i = 0; i < colors.Length; i++) colors[i] = new Color32(255, 255, 255, 255); mesh.colors32 = colors;
                mesh.SetIndices(data.Indices, MeshTopology.Triangles, 0, false); mesh.RecalculateBounds();
                SharedRoomResources.Retain(key, mesh, room);
            }
            var extra = new GameObject("BA_V80 checked new decorative wax"); extra.SetActive(false); extra.transform.SetParent(room.Root.transform, false); extra.layer = child.gameObject.layer;
            extra.AddComponent<MeshFilter>().sharedMesh = mesh;
            var surface = extra.AddComponent<MeshRenderer>(); surface.sharedMaterial = renderer.sharedMaterial; surface.shadowCastingMode = renderer.shadowCastingMode; surface.receiveShadows = renderer.receiveShadows;
            var marker = extra.AddComponent<BossWaxPresentationBinding>(); marker.PayloadSha256 = PayloadSha256; marker.Mesh = mesh;
            room.VisualTriangles = checked(room.VisualTriangles - state.RemovedTriangles + file.extraMesh.triangles);
            state.Attached = true; extra.SetActive(true);
            log?.Invoke("BOSS_WAX_PRESENTATION: sourceOwners=30; retiredTriangles=" + state.RemovedTriangles + "; newTriangles=" + file.extraMesh.triangles + "; one shared small render; existing props material/4K atlas; no new light/collider; source/Pew offsets and remaining attributes preserved.");
        }
    }
}
