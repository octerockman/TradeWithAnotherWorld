using System;

namespace BlackAbbeySixRooms
{
    // Present one simulation interval behind the saved work. Unlike a fast
    // MoveTowards followed by a hold, this moves for the whole interval.
    internal sealed class WardingDoorMotion
    {
        float from, target, elapsed, duration;
        internal float Value { get; private set; }
        internal WardingDoorMotion(float initial) { Snap(initial); }
        internal void Snap(float value)
        { Value=from=target=value; elapsed=duration=0; }
        internal void Target(float value,float seconds)
        {
            if(float.IsNaN(value)||float.IsInfinity(value)||value<0||value>1||seconds<=0)
                throw new ArgumentOutOfRangeException(nameof(value));
            from=Value;target=value;elapsed=0;duration=seconds;
        }
        internal float Advance(float seconds)
        {
            if(seconds<0||float.IsNaN(seconds)||float.IsInfinity(seconds))throw new ArgumentOutOfRangeException(nameof(seconds));
            elapsed=Math.Min(duration,elapsed+seconds);
            Value=duration<=0?target:from+(target-from)*(elapsed/duration);return Value;
        }
    }

    internal static class WardingCombatPriority
    {
        internal static bool MayReopen(bool attacking,bool recentlyHurt,bool hasCombatTarget,
            bool otherEnemyOccupiesPlayer,float nearestPlayerDistance)
        {
            // A stale native target can remain assigned throughout a room.
            // Do not make that reference a permanent veto, or require an
            // additional combatant in order for a lone monk to do its job.
            if(attacking||recentlyHurt||nearestPlayerDistance<2.5f)return false;
            return !hasCombatTarget||nearestPlayerDistance>=5f||otherEnemyOccupiesPlayer&&nearestPlayerDistance>=3.5f;
        }
    }
}
