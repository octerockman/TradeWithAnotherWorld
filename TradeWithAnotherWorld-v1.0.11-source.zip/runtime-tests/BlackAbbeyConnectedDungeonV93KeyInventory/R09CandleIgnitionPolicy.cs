using System;

namespace BlackAbbeySixRooms
{
    // Batch one audible fixture per frame, with no deferred ignition backlog.
    internal sealed class R09CandleIgnitionPolicy
    {
        internal const double MinimumIntervalSeconds = .22;
        private double next = double.NegativeInfinity;
        internal static bool IsLightingWave(R09EncounterState.Stage before, R09EncounterState.Stage after) =>
            before == R09EncounterState.Stage.Lighting || after == R09EncounterState.Stage.Lighting;
        internal static bool NewlyLit(bool previous, bool current) => !previous && current;
        internal bool TryEmit(double now)
        {
            if (double.IsNaN(now) || double.IsInfinity(now) || now < 0 || now + .000001 < next) return false;
            next = now + MinimumIntervalSeconds; return true;
        }
        internal void Reset() { next = double.NegativeInfinity; }
    }
}
