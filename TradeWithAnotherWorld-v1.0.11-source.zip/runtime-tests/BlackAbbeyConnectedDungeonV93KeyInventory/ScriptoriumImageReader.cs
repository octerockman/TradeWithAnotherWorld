using UnityEngine;
namespace BlackAbbeySixRooms
{
    public sealed class ScriptoriumImageReader:MonoBehaviour
    {
        internal static bool Open(Player player)=>SharedParchmentReader.Open(player,ScriptoriumClueText.Title,ScriptoriumClueText.Body,"BlackAbbey.TheVigilOfTwelve.png");
    }
}
