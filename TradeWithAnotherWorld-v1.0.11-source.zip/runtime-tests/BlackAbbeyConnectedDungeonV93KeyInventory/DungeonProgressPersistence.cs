using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        private Action progressCheckpoint;
        private readonly Dictionary<Inventory,Action> progressInventoryHooks=new Dictionary<Inventory,Action>();
        private void ConfigureProgressCheckpoint(Action checkpoint)
        {
            progressCheckpoint=checkpoint;HookPersistentProgress();
        }
        private void HookPersistentProgress()
        {
            if(r07Run!=null)
                foreach(var room in r07Run.ExistingRooms)
                {
                    room.Value.Puzzle.Changed=progressCheckpoint;
                    foreach(var pair in room.Value.ExistingInventories)
                        if(!progressInventoryHooks.ContainsKey(pair.Value))
                        {
                            Action changed=()=>progressCheckpoint?.Invoke();
                            pair.Value.m_onChanged+=changed;progressInventoryHooks.Add(pair.Value,changed);
                        }
                }
            if(pewRun!=null)foreach(var room in pewRun.ExistingRooms)room.Value.Changed=progressCheckpoint;
        }
        private void ReleaseProgressCheckpointHooks()
        {
            foreach(var pair in progressInventoryHooks)pair.Key.m_onChanged-=pair.Value;
            progressInventoryHooks.Clear();
            if(r07Run!=null)foreach(var room in r07Run.ExistingRooms)room.Value.Puzzle.Changed=null;
            if(pewRun!=null)foreach(var room in pewRun.ExistingRooms)room.Value.Changed=null;
            progressCheckpoint=null;
        }
        private void CapturePersistentProgress(DungeonRunSnapshot snapshot)
        {
            if(snapshot==null)throw new ArgumentNullException(nameof(snapshot));
            HookPersistentProgress();
            // An unloaded run still owns its last complete progress. Do not
            // replace it with empty registries during ordinary session unload.
            var current=snapshot.progress??new DungeonProgressSnapshot();
            var captured=new DungeonProgressSnapshot {shrines=current.shrines,pews=current.pews};
            if(r07Run!=null)
                captured.shrines=r07Run.ExistingRooms.OrderBy(p=>p.Key,StringComparer.Ordinal).Select(pair=>new SavedShrineRoom {
                    instanceId=pair.Key,runId=pair.Value.RunId,seed=pair.Value.Seed,puzzle=pair.Value.Puzzle.Capture(),
                    inventories=pair.Value.ExistingInventories.OrderBy(p=>p.Key,StringComparer.Ordinal).Select(inventory=>{
                        var package=new ZPackage();inventory.Value.Save(package);
                        return new SavedShrineInventory {id=inventory.Key,width=inventory.Value.GetWidth(),height=inventory.Value.GetHeight(),package=package.GetBase64()};
                    }).ToList()}).ToList();
            if(pewRun!=null)
                captured.pews=pewRun.ExistingRooms.OrderBy(p=>p.Key,StringComparer.Ordinal).Select(pair=>new SavedPewRoom {
                    instanceId=pair.Key,broken=pair.Value.BrokenIds}).ToList();
            DungeonRunStore.ValidateProgress(captured);snapshot.progress=captured;
        }
        private void RestorePersistentProgress(DungeonRunSnapshot snapshot)
        {
            if(snapshot==null)throw new ArgumentNullException(nameof(snapshot));DungeonRunStore.ValidateProgress(snapshot.progress);
            var shrines=new R07RoomStates<Inventory>(snapshot.seed);var pews=new PewRunState();
            foreach(var saved in snapshot.progress.shrines)
            {
                var room=new R07RunState<Inventory>(saved.seed,saved.runId,saved.puzzle);
                foreach(var savedInventory in saved.inventories)
                {
                    // Never call SeededInventory on restore: even an empty
                    // saved container must remain empty rather than rerolling.
                    var inventory=R07LocalInventory.EmptyInventory(savedInventory.id,savedInventory.width,savedInventory.height);
                    inventory.Load(new ZPackage(Convert.FromBase64String(savedInventory.package)));
                    room.RestoreInventory(savedInventory.id,inventory);
                }
                shrines.RestoreRoom(saved.instanceId,room);
            }
            foreach(var saved in snapshot.progress.pews)pews.ForRoom(saved.instanceId).Restore(saved.broken);
            // Publish only after every native package has restored. A bad item
            // dependency therefore cannot quietly erase existing progression.
            var checkpoint=progressCheckpoint;ReleaseProgressCheckpointHooks();r07Run=shrines;pewRun=pews;
            ConfigureProgressCheckpoint(checkpoint);
        }
    }
}
