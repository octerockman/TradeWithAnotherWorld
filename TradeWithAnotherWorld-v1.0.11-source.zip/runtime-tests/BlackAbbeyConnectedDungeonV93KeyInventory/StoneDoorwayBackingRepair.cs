using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // The edited117ec module has three measured sub1.5mm stone/backing
    // contacts at Y8000. Recess its existing CLOSED backing by20mm in a private
    // instance. A6/12mm study still left one contact;20mm clears every sampled
    // original profile at0/8000. Welded cap vertices follow the displacement, floor/contact
    // vertices remain exact, and no deleted collar or visible stone is restored.
    internal static class StoneDoorwayBackingRepair
    {
        internal const string Source = "605beeb53b608586a291cdd44ba3461f9a7b957250c78609b8b77ae18d8a5ed2";
        internal const string R08ExtensionSource = "2261cd50d6824034cc51e3b21a7027fa5d5d5f5ff460995d10fc01c5041424d6";
        internal const string NaturalPairsSource = "788bdad4b89cde7da4604ee966308bb5ba4d6cfce225df6b274de446207abd09";
        // V28 is additive: its new native owns only the two new pair modules;
        // all legacy mesh records/buffers are retained and pinned by the merged
        // manifest. The existing117ec per-mesh SHA/count guard still applies.
        internal static bool ExactSource(LoadedRoom kit) => kit != null && (kit.Manifest.sourceSha256 == Source || kit.Manifest.sourceSha256 == R08ExtensionSource || kit.Manifest.sourceSha256 == NaturalPairsSource);
        internal const string MeshSha = "a89c7a5bb744e1a45eb83b5f3f67d77c006413031d91e4a6423090dfaeb759bd";
        internal const float Recess = .020f;
        internal static void Apply(GameObject instance, LoadedRoom kit, string module)
        {
            if (module != "joined_117_ec") return;
            var record = kit.Manifest.meshes.Single(r => r.name == module + "_backing");
            if (!ExactSource(kit) || record.sha256 != MeshSha || record.vertices != 2342 || record.indices != 4680)
                throw new InvalidDataException("117ec backing repair requires the exact user-edited source.");
            var filter = instance.transform.Find(module + "_backing")?.GetComponent<MeshFilter>();
            if (!filter || filter.sharedMesh.vertexCount != 2342 || filter.sharedMesh.triangles.Length != 4680)
                throw new InvalidDataException("117ec backing repair source mesh differs from its witness.");
            var original = filter.sharedMesh; var points = original.vertices; var triangles = original.triangles;
            var weld = new Dictionary<Point, int>(); var vertexWeld = new int[points.Length];
            var positions = new List<Vector3>();
            for (int i = 0; i < points.Length; i++)
            {
                var key = new Point(points[i]);
                if (!weld.TryGetValue(key, out int index)) { index = positions.Count; weld.Add(key,index); positions.Add(points[i]); }
                vertexWeld[i] = index;
            }
            var sums = new Vector3[positions.Count];
            for (int i = 0; i < triangles.Length; i += 3)
            {
                int a=triangles[i], b=triangles[i+1], c=triangles[i+2];
                var centre=(points[a]+points[b]+points[c])/3f;
                var area=Vector3.Cross(points[b]-points[a],points[c]-points[a]);
                float magnitude=area.magnitude;
                if (magnitude<=1e-12f) continue;
                var normal=area/magnitude; var radial=centre-new Vector3(0,1,0); radial.z=0;
                if (Vector3.Dot(radial,normal)>=-.05f || Math.Abs(normal.z)>=.7f || centre.y<=.05f) continue;
                sums[vertexWeld[a]]+=area; sums[vertexWeld[b]]+=area; sums[vertexWeld[c]]+=area;
            }
            var shifts=new Vector3[positions.Count];
            for (int i=0;i<shifts.Length;i++)
            {
                sums[i].z=0;float magnitude=sums[i].magnitude;
                if (magnitude>1e-12f) shifts[i]=-sums[i]/magnitude*Recess*Mathf.Clamp01((positions[i].y-.05f)/.1f);
            }
            for (int i=0;i<points.Length;i++) points[i]+=shifts[vertexWeld[i]];
            var candidate=Object.Instantiate(original);candidate.name=original.name+" | closed117ec backing20mm recess";
            candidate.vertices=points;candidate.RecalculateBounds();filter.sharedMesh=candidate;
            instance.AddComponent<StoneDoorwayBackingLifetime>().Candidate=candidate;
        }
        private readonly struct Point : IEquatable<Point>
        {
            private readonly long x,y,z;
            internal Point(Vector3 p) { x=(long)Math.Round((double)p.x*1000000);y=(long)Math.Round((double)p.y*1000000);z=(long)Math.Round((double)p.z*1000000); }
            public bool Equals(Point other) => x==other.x && y==other.y && z==other.z;
            public override bool Equals(object obj) => obj is Point other && Equals(other);
            public override int GetHashCode() { unchecked { return (x.GetHashCode()*397^y.GetHashCode())*397^z.GetHashCode(); } }
        }
    }
    internal sealed class StoneDoorwayBackingLifetime : MonoBehaviour
    {
        internal Mesh Candidate;
        private void OnDestroy() { if (Candidate) Object.Destroy(Candidate); }
    }
}
