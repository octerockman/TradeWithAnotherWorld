using System;

namespace BlackAbbeySixRooms
{
    // Diagnostic samples only; no simulation, lighting or scheduling state.
    // Retains exactly the last Capacity accepted values without shifting them.
    internal sealed class FrameIntervalWindow
    {
        private readonly float[] values, sorted;
        private int next;
        internal int Count { get; private set; }
        internal FrameIntervalWindow(int capacity)
        {
            if (capacity < 1) throw new ArgumentOutOfRangeException(nameof(capacity));
            values = new float[capacity]; sorted = new float[capacity];
        }
        internal void Add(float value)
        {
            values[next] = value;
            next = (next + 1) % values.Length;
            if (Count < values.Length) Count++;
        }
        internal void Clear() { next = Count = 0; }
        internal float[] Sorted()
        {
            Array.Copy(values, sorted, Count);
            Array.Sort(sorted, 0, Count);
            return sorted;
        }
        internal static float Average(float[] sorted, int count)
        {
            double total = 0;
            for (int i = 0; i < count; i++) total += sorted[i];
            return (float)(total / count);
        }
    }
}
