using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Linq;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    public sealed class FalseVowsWorldHandle:MonoBehaviour,Hoverable,Interactable
    {
        internal string Label,Verb;
        internal Func<Player,bool> CanUse;
        internal Func<string> Extra;
        internal Action<Player> Use;
        internal Func<Player,ItemDrop.ItemData,bool> UsedItem;
        internal Collider Shape;
        private float lastUse=-10;
        public string GetHoverName()=>Label??"";
        public float GetHoverOffset()=>.1f;
        public string GetHoverText()
        {
            if(!Player.m_localPlayer||CanUse==null||!CanUse(Player.m_localPlayer))return "";
            string text=Label+"\n[<color=yellow><b>$KEY_Use</b></color>] "+(Extra?.Invoke()??Verb);
            return Localization.instance!=null?Localization.instance.Localize(text):text;
        }
        private bool Eligible(Humanoid user,out Player player)
        {
            player=user as Player;if(!player||player!=Player.m_localPlayer||CanUse==null||!CanUse(player))return false;
            var point=player.transform.position+Vector3.up;
            return Shape?(Shape.bounds.ClosestPoint(point)-point).sqrMagnitude<=20.25f:(transform.position-point).sqrMagnitude<=20.25f;
        }
        public bool Interact(Humanoid user,bool hold,bool alt)
        {if(hold||!Eligible(user,out var p))return false;if(Time.unscaledTime-lastUse<.3f)return true;lastUse=Time.unscaledTime;Use?.Invoke(p);return true;}
        public bool UseItem(Humanoid user,ItemDrop.ItemData item)=>Eligible(user,out var p)&&UsedItem!=null&&UsedItem(p,item);
    }

    internal sealed class FalseVowsCabinetMotion:MonoBehaviour
    {
        private Quaternion closed;
        private Vector3 axis;
        private float angle,target,openDegrees;
        private Bounds localBounds;
        private FalseVowsCabinetAudio audio;
        private readonly FalseVowsCabinetSoundGate soundGate=new FalseVowsCabinetSoundGate();
        internal void Configure(Vector3 axis,float degrees,Bounds bounds,FalseVowsCabinetAudio audio)
        {
            closed=transform.localRotation;this.axis=axis.normalized;openDegrees=degrees;localBounds=bounds;this.audio=audio;
            var body=gameObject.AddComponent<Rigidbody>();body.isKinematic=true;body.useGravity=false;
        }
        internal void Toggle(Player player,double delay=0)
        {
            float proposed=target==0?openDegrees:0;
            if(Blocked(player,proposed)){player.Message(MessageHud.MessageType.Center,"Stand clear of the cabinet door.");return;}
            target=proposed;soundGate.Request(Time.unscaledTime,delay);
        }
        private bool Blocked(Player p,float proposed)
        {
            for(int i=0;i<=9;i++)
            {
                float a=Mathf.Lerp(angle,proposed,i/9f);var rotation=transform.parent.rotation*closed*Quaternion.AngleAxis(a,axis);
                var center=transform.parent.TransformPoint(transform.localPosition)+rotation*localBounds.center;
                foreach(float y in new[]{.25f,.65f,1.1f})
                {
                    var q=Quaternion.Inverse(rotation)*(p.transform.position+Vector3.up*y-center);
                    var d=new Vector3(Mathf.Max(0,Mathf.Abs(q.x)-localBounds.extents.x),Mathf.Max(0,Mathf.Abs(q.y)-localBounds.extents.y),Mathf.Max(0,Mathf.Abs(q.z)-localBounds.extents.z));
                    if(d.sqrMagnitude<.30f*.30f)return true;
                }
            }
            return false;
        }
        private void FixedUpdate()
        {
            if(Mathf.Abs(target-angle)<.01f)return;
            if(!soundGate.CanAdvance(Time.unscaledTime))return;
            float next=Mathf.MoveTowards(angle,target,100*Time.fixedDeltaTime);
            if(Player.m_localPlayer&&Blocked(Player.m_localPlayer,next))return;
            if(soundGate.BeginMotion(Time.unscaledTime))audio?.PlayDoor(transform.position,target!=0);
            angle=next;transform.localRotation=closed*Quaternion.AngleAxis(angle,axis);
        }
    }

    internal sealed class FalseVowsRoomRuntime:MonoBehaviour
    {
        private LoadedRoom room;
        private FalseVowsAssets assets;
        private FalseVowsAssetRoom data;
        private FalseVowsState state;
        private Func<Player,bool> canUse;
        private Action<Player,string,string> pickup;
        private Action<Player,string> unlock,placeBook;
        private Action<Player,string,ItemDrop.ItemData> offer;
        private Action<string> log;
        private Transform root,beam,leftPan,rightPan;
        private Vector3 beamRest,leftRest,rightRest;
        private Vector3 beamAxis;
        private Quaternion beamRotation,leftRotation,rightRotation;
        private float weighingAngle;
        private float leftDownSign;
        private bool observedBook;
        private int observedSolved;
        private FalseVowsPlacementAudio placementAudio;
        private FalseVowsCabinetAudio cabinetAudio;
        private readonly Dictionary<string,GameObject> pickupObjects=new Dictionary<string,GameObject>(StringComparer.Ordinal);
        private readonly Dictionary<string,GameObject> scaleProofs=new Dictionary<string,GameObject>(StringComparer.Ordinal);
        private readonly List<FalseVowsSealBreak> seals=new List<FalseVowsSealBreak>();
        private GameObject scaleBook;
        private bool firstRefresh=true,lastNoteReleased;

        internal static void Attach(LoadedRoom room,FalseVowsAssets assets,FalseVowsAssetRoom data,FalseVowsState state,Func<Player,bool> canUse,
            Action<Player,string,string> pickup,Action<Player,string> unlock,Action<Player,string> placeBook,Action<Player,string,ItemDrop.ItemData> offer,Action<string> log)
        {
            var x=room.Root.AddComponent<FalseVowsRoomRuntime>();x.room=room;x.assets=assets;x.data=data;x.state=state;x.canUse=canUse;x.pickup=pickup;x.unlock=unlock;x.placeBook=placeBook;x.offer=offer;x.log=log;
            var go=new GameObject("Three False Vows | "+room.InstanceId);go.transform.SetParent(room.Root.transform,false);x.root=go.transform;
            x.Build();x.Refresh();
        }
        private static FalseVowsAssetPose Pose(JToken value)=>value?.ToObject<FalseVowsAssetPose>();
        private static Vector3 Vector(JToken value,string label)=>RoomPackage.Vector(value?.ToObject<float[]>(),label);
        private static Bounds Bounds(FalseVowsAssetKit k)
        {var a=RoomPackage.Vector(k.boundsMin,"kit min");var b=RoomPackage.Vector(k.boundsMax,"kit max");return new Bounds((a+b)*.5f,b-a);}
        private GameObject Create(string id,bool collision=true)=>assets.CreateKit(id,root,true,collision);
        private FalseVowsWorldHandle Handle(GameObject obj,string label,string verb,Action<Player> action)
        {
            var h=obj.AddComponent<FalseVowsWorldHandle>();h.Label=label;h.Verb=verb;h.Use=action;h.CanUse=p=>state!=null&&canUse(p);
            h.Shape=obj.GetComponentInChildren<Collider>();return h;
        }
        private void Build()
        {
            foreach(var part in data.movedParts??Array.Empty<FalseVowsMovedPart>())
            {var kit=Create(part.kitId);if(part.position!=null)part.Pose.Apply(kit.transform);}
            if(state==null)return;
            if(room.Manifest.roomId=="R02")Create("R02_cabinet_static");
            foreach(var p in data.sockets?["pickups"] as JArray??new JArray())
            {
                string id=(string)p["itemId"],kitId=(string)p["kitId"];
                var obj=assets.CreateKit(kitId,root,false,false);Pose(p).Apply(obj.transform);
                var box=obj.AddComponent<BoxCollider>();var b=Bounds(assets.Kit(kitId));box.center=b.center;box.size=Vector3.Max(b.size+Vector3.one*.016f,new Vector3(.035f,.025f,.035f));
                var h=Handle(obj,FalseVowsItemCatalog.Find(id)?.Name??"Abbey evidence","Pick up",player=>pickup(player,id,room.InstanceId));h.Shape=box;
                pickupObjects.Add(id,obj);
            }
            foreach(var c in data.sockets?["cabinets"] as JArray??new JArray())
            {
                string kitId=(string)c["kitId"];var obj=Create(kitId);var spec=assets.Kit(kitId);
                if(!cabinetAudio){cabinetAudio=root.gameObject.AddComponent<FalseVowsCabinetAudio>();cabinetAudio.Configure(log);}
                var motion=obj.AddComponent<FalseVowsCabinetMotion>();motion.Configure(Vector(c["axis"],"cabinet axis"),(float)c["openDegrees"],Bounds(spec),cabinetAudio);
                Action<Player> open=player=>{bool before=state.CabinetsUnlocked;if(!before)unlock(player,room.InstanceId);bool newly= FalseVowsCabinetSoundGate.NewlyUnlocked(before,state.CabinetsUnlocked);if(newly)cabinetAudio.PlayUnlock(obj.transform.position);if(state.CabinetsUnlocked)motion.Toggle(player,newly?FalseVowsCabinetSoundGate.UnlockLeadSeconds:0);};
                var h=Handle(obj,"Writing-desk cabinet","Open",open);h.Extra=()=>state.CabinetsUnlocked?"Open / close":"Unlock";
                h.UsedItem=(player,item)=>
                {
                    if(FalseVowsItems.Id(item)!=FalseVowsState.Key)return false;
                    if(!FalseVowsItems.Matches(item,FalseVowsState.Key,state.RunId,state.Token(FalseVowsState.Key)))player.Message(MessageHud.MessageType.Center,"That key belongs to another reckoning.");else open(player);
                    return true;
                };
            }
            if(room.Manifest.roomId=="R09"||room.Manifest.roomId==R09SplitIdentity.FalseVowsHall)BuildScale();
        }
        private void BuildScale()
        {
            var rig=data.sockets["scaleRig"];Create((string)rig["fixedKitId"]);
            beam=Create((string)rig["beamKitId"]).transform;leftPan=Create((string)rig["leftPanKitId"]).transform;rightPan=Create((string)rig["rightPanKitId"]).transform;
            beamRest=beam.localPosition;leftRest=leftPan.localPosition;rightRest=rightPan.localPosition;
            beamRotation=beam.localRotation;leftRotation=leftPan.localRotation;rightRotation=rightPan.localRotation;
            beamAxis=Vector(rig["beamAxisLocal"],"scale axis");
            var axis=beamRotation*beamAxis.normalized;
            float leftVertical=Vector3.Cross(axis,leftRest-beamRest).y;
            if(Mathf.Abs(leftVertical)<.05f)throw new InvalidOperationException("Scale axis cannot lower the authored book pan.");
            leftDownSign=leftVertical<0?1:-1;
            weighingAngle=leftDownSign*FalseVowsScalePolicy.LeftDownDegrees(state.BookPlaced,state.SolvedMask);
            placementAudio=gameObject.AddComponent<FalseVowsPlacementAudio>();placementAudio.Configure(log);
            foreach(var t in new[]{beam,leftPan,rightPan}){var body=t.gameObject.AddComponent<Rigidbody>();body.isKinematic=true;body.useGravity=false;}
            PanHandle(leftPan,data.sockets["leftPan"],"The Abbey's Rule","Place book",player=>placeBook(player,room.InstanceId),true);
            PanHandle(rightPan,data.sockets["rightPan"],"Balance of witness","Offer evidence",player=>offer(player,room.InstanceId,null),false);
            scaleBook=assets.CreateKit(FalseVowsState.Book,root,false,false);Pose(data.sockets["bookOnPan"]).Apply(scaleBook.transform);scaleBook.transform.SetParent(leftPan,true);
            foreach(var p in data.sockets["evidenceOnPan"] as JArray??new JArray())
            {string id=(string)p["itemId"];var obj=assets.CreateKit(id,root,false,false);Pose(p).Apply(obj.transform);obj.transform.SetParent(rightPan,true);scaleProofs.Add(id,obj);}
            var boss=R09RoomRuntime.ForHall(room);
            if(!boss)throw new InvalidOperationException("The selected scale hall has no assembled shared boss-door service.");
            boss.ConfigureProgressionGate(()=>state.DoorUnlocked&&seals.All(s=>s.Finished));
            foreach(var s in data.sockets["seals"] as JArray??new JArray())
            {
                string evidence=(string)s["evidenceId"];var fragments=new List<GameObject>();
                foreach(string id in s["kits"].Values<string>())
                {
                    var obj=Create(id);string leaf=(string)s["attachmentLeafByKit"]?[id]??(string)s["leaf"];
                    var pivot=boss.QuestDoorAttachment(leaf=="left");if(!pivot)throw new InvalidOperationException("Boss seal lost its actual leaf attachment.");
                    obj.transform.SetParent(pivot,true);fragments.Add(obj);
                }
                var owner=new GameObject("Wax seal | "+evidence);owner.transform.SetParent(root,false);
                var effect=owner.AddComponent<FalseVowsSealBreak>();effect.Configure(room.Root.transform,fragments.ToArray(),state,evidence,log);seals.Add(effect);
            }
        }
        private void PanHandle(Transform pan,JToken socket,string label,string verb,Action<Player> action,bool book)
        {
            var go=new GameObject(label+" interaction");go.transform.SetParent(pan,false);
            go.transform.position=room.Root.transform.TransformPoint(Vector(socket["interactionCenter"],"pan interaction"));go.layer=LayerMask.NameToLayer("piece");
            var box=go.AddComponent<BoxCollider>();box.size=Vector(socket["interactionSize"],"pan use size");
            var h=Handle(go,label,verb,action);h.Shape=box;
            h.UsedItem=(player,item)=>
            {
                string id=FalseVowsItems.Id(item);if(id==null)return false;
                if(book&&id!=FalseVowsState.Book){player.Message(MessageHud.MessageType.Center,"This pan waits for the Abbey's Rule.");return true;}
                if(!book&&FalseVowsState.EvidenceIndex(id)<0){player.Message(MessageHud.MessageType.Center,"This pan waits for proof.");return true;}
                if(!FalseVowsItems.Matches(item,id,state.RunId,state.Token(id))){player.Message(MessageHud.MessageType.Center,"This belongs to another reckoning.");return true;}
                if(book)placeBook(player,room.InstanceId);else offer(player,room.InstanceId,item);return true;
            };
        }
        internal void Refresh()
        {
            if(state==null)return;
            bool initial=firstRefresh;
            foreach(var pair in pickupObjects)
            {
                bool show=!state.Collected(pair.Key)&&(pair.Key!=FalseVowsState.Letter||state.NoteReleased);
                if(pair.Key==FalseVowsState.Letter&&show)
                {
                    if(firstRefresh)Pose(data.sockets["letterLanding"]).Apply(pair.Value.transform);
                    else if(!lastNoteReleased&&state.NoteReleased)ReleaseLetter(pair.Value);
                }
                pair.Value.SetActive(show);
            }
            lastNoteReleased=state.NoteReleased;firstRefresh=false;
            if(scaleBook)scaleBook.SetActive(state.BookPlaced);
            foreach(var p in scaleProofs)p.Value.SetActive(state.Consumed(p.Key));
            foreach(var seal in seals)seal.Refresh();
            if(placementAudio&&!initial)
            {
                if(state.BookPlaced&&!observedBook)placementAudio.Play(FalseVowsState.Book,leftPan.position);
                string[] ids={FalseVowsState.Deposition,FalseVowsState.Purse,FalseVowsState.Seal};
                for(int i=0;i<ids.Length;i++)if((state.SolvedMask&(1<<i))!=0&&(observedSolved&(1<<i))==0)placementAudio.Play(ids[i],rightPan.position);
            }
            observedBook=state.BookPlaced;observedSolved=state.SolvedMask;
        }
        private void ReleaseLetter(GameObject obj)
        {
            Pose(data.sockets["letterRelease"]).Apply(obj.transform);obj.SetActive(true);
            // A thin readable paper can have a taller selection collider, but
            // its physics contact face must remain on the actual paper plane.
            var paperShape=obj.GetComponent<BoxCollider>();
            if(paperShape){var c=paperShape.center;c.y=paperShape.size.y*.5f+assets.Kit(FalseVowsState.Letter).boundsMin[1];paperShape.center=c;}
            var body=obj.GetComponent<Rigidbody>()??obj.AddComponent<Rigidbody>();body.isKinematic=false;body.useGravity=true;body.mass=.015f;body.linearDamping=.1f;body.angularDamping=2;
            body.collisionDetectionMode=CollisionDetectionMode.ContinuousDynamic;
            var target=room.Root.transform.TransformPoint(Vector(data.sockets["letterLanding"]["position"],"letter landing"));float flight=.65f;
            body.linearVelocity=(target-obj.transform.position)/flight-Physics.gravity*flight*.5f;
            body.angularVelocity=room.Root.transform.TransformDirection(new Vector3(.2f,.7f,.1f));
            log?.Invoke("FALSE_VOWS_LETTER_RELEASED: first successful book delivery; physical note; no replay on restore.");
        }
        private void FixedUpdate()
        {
            if(state==null||!beam||!leftPan||!rightPan)return;
            weighingAngle=Mathf.MoveTowards(weighingAngle,leftDownSign*FalseVowsScalePolicy.LeftDownDegrees(state.BookPlaced,state.SolvedMask),Time.fixedDeltaTime*22);
            var q=beamRotation*Quaternion.AngleAxis(weighingAngle,beamAxis)*Quaternion.Inverse(beamRotation);
            beam.localRotation=beamRotation*Quaternion.AngleAxis(weighingAngle,beamAxis);
            leftPan.localPosition=beamRest+q*(leftRest-beamRest);rightPan.localPosition=beamRest+q*(rightRest-beamRest);
            leftPan.localRotation=leftRotation;rightPan.localRotation=rightRotation;
        }
    }

    internal sealed class FalseVowsSealBreak:MonoBehaviour
    {
        private Transform room;
        private GameObject[] fragments;
        private FalseVowsState state;
        private string evidence;
        private Action<string> log;
        private bool released;
        internal bool Finished=>released;
        private float crackAt=-1;
        internal void Configure(Transform room,GameObject[] fragments,FalseVowsState state,string evidence,Action<string> log)
        {
            this.room=room;this.fragments=fragments;this.state=state;this.evidence=evidence;this.log=log;
            // Cosmetic debris is not replayed on reload. The durable seal bit
            // owns the unlocked gate independently of sleeping rigid bodies.
            if(state.Consumed(evidence)){released=true;foreach(var f in fragments)Object.Destroy(f);}
        }
        internal void Refresh(){if(!released&&crackAt<0&&state.Consumed(evidence))crackAt=Time.time;}
        private void Update()
        {
            if(released||crackAt<0)return;
            if(Time.time-crackAt<.22f)
            {foreach(var f in fragments)if(f)f.transform.position+=room.TransformDirection(new Vector3(0,0,-.004f))*Time.deltaTime/.22f;return;}
            released=true;var random=new System.Random(state.ReleaseSeed(evidence));
            foreach(var f in fragments)
            {
                if(!f)continue;f.transform.SetParent(room,true);
                foreach(var shape in f.GetComponentsInChildren<MeshCollider>())shape.convex=true;
                var body=f.AddComponent<Rigidbody>();body.isKinematic=false;body.useGravity=true;body.mass=.035f;
                body.linearDamping=.08f;body.angularDamping=.12f;body.collisionDetectionMode=CollisionDetectionMode.ContinuousDynamic;
                body.linearVelocity=room.TransformDirection(new Vector3((float)(random.NextDouble()-.5)*.22f,(float)random.NextDouble()*.06f,-.10f-(float)random.NextDouble()*.10f));
                body.angularVelocity=room.TransformDirection(new Vector3((float)(random.NextDouble()-.5)*2.4f,(float)(random.NextDouble()-.5)*2.4f,(float)(random.NextDouble()-.5)*2.4f));
                if(Player.m_localPlayer)foreach(var playerShape in Player.m_localPlayer.GetComponentsInChildren<Collider>())foreach(var shape in f.GetComponentsInChildren<Collider>())Physics.IgnoreCollision(playerShape,shape,true);
            }
            log?.Invoke("FALSE_VOWS_WAX_RELEASE: "+evidence+"; saved seed="+state.ReleaseSeed(evidence)+"; dynamic convex fragments; floor/door collision; no fixed landing animation.");
        }
    }
}
