using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    internal sealed class R09CandleGroupBinding : MonoBehaviour
    {
        internal float SourceZ;
        private Transform[] effects;
        private ParticleSystem[] particles;
        private ParticleSystemRenderer[] renderers;
        private BudgetedFixture[] fixtures;
        private bool active, stateApplied;
        internal int SocketCount => effects?.Length ?? 0;
        internal bool IsLit => stateApplied && active;
        internal Vector3 WickCenter
        {
            get
            {
                Vector3 sum = Vector3.zero; int count = 0;
                if (effects != null) foreach (var effect in effects) if (effect) { sum += effect.position; ++count; }
                return count > 0 ? sum / count : transform.position;
            }
        }
        internal void Configure(GameObject room, IEnumerable<string> socketNames, float sourceZ,string nativeSourceSha256=null,string anchorSocketName=null)
        {
            SourceZ = sourceZ;
            var names = new HashSet<string>(socketNames, StringComparer.Ordinal);
            var sockets = room.GetComponentsInChildren<Transform>(true).Where(t => names.Contains(t.name)).ToArray();
            if (sockets.Length != names.Count) throw new InvalidOperationException("R09 candle group socket binding is incomplete or ambiguous.");
            effects = sockets.Select(t => t.Find(TradeWithAnotherWorld.ResinCandleFlame.EffectRootName)).ToArray();
            if (effects.Any(t => !t)) throw new InvalidOperationException("R09 candle group is missing its native flame effect.");
            particles = effects.Select(t => t.GetComponentInChildren<ParticleSystem>(true)).ToArray();
            if (particles.Any(p => !p)) throw new InvalidOperationException("R09 candle group is missing its native flame particles.");
            renderers=particles.Select(p=>p.GetComponent<ParticleSystemRenderer>()).ToArray();
            if(renderers.Any(r=>!r)) throw new InvalidOperationException("R09 candle group is missing its native flame renderer.");
            // Renderer visibility must be restored before the render-budget
            // snapshot. Darkness is supplied by the complete inactive effect
            // host, not by persisting a false renderer baseline in that cache.
            foreach(var renderer in renderers) renderer.enabled=true;
            if(anchorSocketName!=null && !names.Contains(anchorSocketName)) throw new InvalidOperationException("R09 light anchor is outside its actual wick group.");
            // The saved V7c geometry witness proves all198 existing origins
            // clear; intentionally apply no speculative position/scale lift.
            fixtures = GetComponentsInChildren<BudgetedFixture>(true);
            if (fixtures.Length != 1 || fixtures[0].IsWindow) throw new InvalidOperationException("R09 group requires one canonical candle light.");
        }
        internal void SetLit(bool lit)
        {
            if (stateApplied && active == lit) return;
            active = lit; stateApplied = true;
            foreach (var fixture in fixtures)
            {
                fixture.EmissionEnabled = lit;
                // The shared budget also observes this flag; a native flicker
                // cannot bypass the initial off state on a later frame.
                if (!lit && fixture.Light) fixture.Light.enabled = false;
            }
            // Wax/iron remain visible; only the owned native light host and
            // complete particle/emission effect hosts change activation state.
            gameObject.SetActive(lit);
            for (int i = 0; i < effects.Length; i++) if (effects[i])
            {
                // A native flame that was stopped by deactivation need not
                // restart just because its GameObject becomes active. Match
                // the canonical binder/R07 explicit Play contract instead of
                // relying on the installed prefab's playOnAwake setting.
                if (!lit && particles[i]) particles[i].Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
                if(!lit && particles[i]) { var emission=particles[i].emission;emission.enabled=false; }
                effects[i].gameObject.SetActive(lit);
            }
            if (lit) RestoreLitEffects();
        }
        private void OnEnable() { if (stateApplied && active) RestoreLitEffects(); }
        internal void RestoreLitEffects()
        {
            // Attach and initial encounter setup occur under an inactive room.
            // Play only after actual room activation; later state transitions
            // restart once, while unchanged per-frame SetLit calls stay cheap.
            if (!active || particles == null) return;
            for(int i=0;i<particles.Length;i++)
            {
                var particle=particles[i];if(!particle)continue;
                if(renderers[i])renderers[i].enabled=true;
                var emission=particle.emission;emission.enabled=true;
                if(particle.gameObject.activeInHierarchy && !particle.isPlaying)particle.Play(true);
            }
        }
    }
}
