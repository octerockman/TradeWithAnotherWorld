using System;
using System.Globalization;
using System.IO;
using Newtonsoft.Json;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        readonly DungeonSessionLifetime sessionLifetime = new DungeonSessionLifetime();
        DungeonGraveGuard graveGuard = new DungeonGraveGuard();

        internal static long? SessionCharacterId(Player player)
        {
            if (player) return player.GetPlayerID();
            var profile = Game.instance ? Game.instance.GetPlayerProfile() : null;
            long id = profile == null ? 0L : profile.GetPlayerID();
            return id == 0L ? (long?)null : id;
        }

        private bool UpdateSessionLifetime(Player player)
        {
            var network = ZNet.instance;
            bool host = network && network.IsServer();
            string world = null;
            if (host)
                try { world = WorldKey(); }
                catch (Exception error) { Logger.LogDebug("World identity is temporarily unavailable during transition: " + error.Message); }
            long? character = host ? SessionCharacterId(player) : null;
            var decision = sessionLifetime.Observe(network, host, world, character?.ToString(CultureInfo.InvariantCulture));
            bool rebound = RoomLoadCancellationPolicy.OwnerChanged(player, observedPlayer);
            if (decision == DungeonSessionLifetime.Decision.Release || rebound)
            {
                AbbeyDoorAudio.StopAll(); bossMusic?.Release(); nativeBackground?.Restore(); ambience?.Suspend(true);
                CancelRoomLoading();
                bool release = decision == DungeonSessionLifetime.Decision.Release ||
                    decision == DungeonSessionLifetime.Decision.Unbound && !ReferenceEquals(observedPlayer, null);
                if (release)
                {
                    DisposeRooms(); DisposeWorldPortal();
                    checkpoint = null; returnPlayer = null; selectedCheckpointIdentity = null;
                    selectedPlayerId = null; selectedWorldKey = null; checkpointReadFailed = false;
                    Logger.LogInfo("ABBEY_SESSION_RELEASE: host session, character or world changed; owned rooms unloaded.");
                }
                else
                {
                    // In particular keep the exact room roots/positions, door,
                    // puzzle/pew/boss state and Monk ledger through death.
                    returnPlayer = player && Matches(player) ? player : null;
                    if (rooms.Count > 0)
                        Logger.LogInfo("ABBEY_RESPAWN_RETAIN: same character/world host session; rooms=" + rooms.Count + "; playerAvailable=" + (bool)player + "; seed=" + dungeonPlan?.Seed);
                }
                observedPlayer = player; recoveryAttempted = false;
            }
            return decision == DungeonSessionLifetime.Decision.Retain;
        }

        private void SaveDungeonRecovery(DungeonPlan plan)
        {
            if (checkpoint == null || !checkpoint.pending || !gridOrigin.HasValue)
                throw new InvalidOperationException("A matching return checkpoint is required before publishing dungeon recovery.");
            checkpoint.dungeonSeed = plan.Seed; checkpoint.dungeonMode = plan.Mode;
            checkpoint.persistentRunId=plan.Mode=="natural"?persistentRun?.runId:null;
            checkpointStore.Save(checkpoint.playerId, checkpoint.worldKey, JsonConvert.SerializeObject(checkpoint, Formatting.Indented));
            SaveWorldPortalLayout(plan);
            if(!SavePersistentRun(true))throw new IOException("The persistent run could not be saved before travel. Current rooms and return point are retained.");
            Logger.LogInfo("ABBEY_LAYOUT_RECOVERY_SAVED: seed=" + plan.Seed + "; mode=" + plan.Mode + "; origin=" + gridOrigin.Value + "; exact catalog=" + checkpoint.sourceSha256);
        }

        private int? CheckpointLayoutSeed(bool showcase)
        {
            if(!showcase&&persistentRun==null&&!string.IsNullOrEmpty(checkpoint?.persistentRunId))return null;
            if (checkpoint?.dungeonSeed == null || checkpoint.dungeonMode != (showcase ? "showcase" : "natural")) return null;
            if (!DungeonAssetRevision.CatalogMatches(checkpoint.sourceSha256, CatalogReader.HashFile(Path.Combine(DataPath, "catalog.json"))))
                throw new InvalidOperationException("The saved dungeon's room catalog has changed; its recovery record was retained. No replacement layout will hide the old grave.");
            return checkpoint.dungeonSeed;
        }
    }
}
