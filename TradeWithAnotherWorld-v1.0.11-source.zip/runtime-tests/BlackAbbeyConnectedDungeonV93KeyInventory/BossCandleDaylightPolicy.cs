using System;

namespace BlackAbbeySixRooms
{
    internal static class BossCandleDaylightPolicy
    {
        internal const float DayGain = .85f, NightGain = 1.1f, TransitionSeconds = 5f;
        internal static bool Applies(string roomId) => R09SplitIdentity.IsChamber(roomId);
        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        internal static float Target(bool? day) => day == true ? DayGain : NightGain;
        internal static float Step(float current, bool? day, float deltaTime)
        {
            float target = Target(day);
            if (!Finite(current)) current = target;
            current = Math.Max(DayGain, Math.Min(NightGain, current));
            if (!Finite(deltaTime) || deltaTime <= 0) return current;
            float step = (NightGain - DayGain) * deltaTime / TransitionSeconds;
            return current < target ? Math.Min(target, current + step) : Math.Max(target, current - step);
        }
        internal static float BaseIntensity(float authored, float gain)
        {
            if (!Finite(authored) || authored < 0 || !Finite(gain))
                throw new ArgumentException("Daylight requires a finite authored candle baseline and gain.");
            return authored * Math.Max(DayGain, Math.Min(NightGain, gain));
        }
    }
}
