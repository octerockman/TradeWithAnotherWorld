using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Newtonsoft.Json;

namespace BlackAbbeySixRooms
{
#pragma warning disable 0649
    internal sealed class BossMusicTrack
    {
        public string id, file, sha256;
        public long bytes, frames;
        public int sampleRate, channels;
        public double durationSeconds;
        public bool loop;
    }
    internal sealed class BossMusicManifest
    {
        public int schemaVersion;
        public BossMusicTrack[] tracks;
    }
#pragma warning restore 0649
    internal sealed class BossMusicAssets : IDisposable
    {
        internal const string ManifestSha = "03e67a4a67ba33729b046aac95726654da9bef8b94b3d1e5388c31fb8eb6df68";
        internal string DirectoryPath;
        internal BossMusicTrack[] Tracks;
        private readonly List<FileStream> leases = new List<FileStream>();
        internal static BossMusicAssets Prepare(string dataDirectory)
        {
            var result = new BossMusicAssets();
            try
            {
                result.DirectoryPath = Path.GetFullPath(Path.Combine(dataDirectory, "boss-music"));
                string manifest = Path.Combine(result.DirectoryPath, "manifest.json");
                var lease = result.Open(manifest, null, ManifestSha);
                if (lease.Length > 16384) throw new InvalidDataException("Oversized boss music manifest.");
                string json;
                using (var reader = new StreamReader(lease, System.Text.Encoding.UTF8, true, 4096, true)) json = reader.ReadToEnd();
                var spec = JsonConvert.DeserializeObject<BossMusicManifest>(json);
                if (spec?.schemaVersion != 1 || spec.tracks?.Length != 3) throw new InvalidDataException("Expected exact three-track boss music bank.");
                string[] ids = { "entrance", "combat", "victory" };
                long[] frames = { 882000, 22932000, 1356032 };
                for (int i = 0; i < ids.Length; ++i)
                {
                    var t = spec.tracks[i];
                    if (t == null || t.id != ids[i] || t.file != ids[i] + ".ogg" || t.sampleRate != 44100 || t.channels != 2 ||
                        t.frames != frames[i] || t.loop != (i == 1) || Math.Abs(t.durationSeconds - t.frames / 44100d) > .000001 ||
                        t.bytes < 10000 || t.bytes > 16000000 || t.sha256?.Length != 64 || t.sha256.Any(c => !Uri.IsHexDigit(c)))
                        throw new InvalidDataException("Unexpected boss music track contract.");
                    result.Open(Path.Combine(result.DirectoryPath, t.file), t.bytes, t.sha256);
                }
                result.Tracks = spec.tracks; return result;
            }
            catch { result.Dispose(); throw; }
        }
        private FileStream Open(string path, long? bytes, string expected)
        {
            // Keep read-only file leases through streamed clip lifetime. Files
            // cannot change between verification and the native decoder's read.
            var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            leases.Add(stream);
            if (bytes.HasValue && stream.Length != bytes.Value) throw new InvalidDataException("Boss music size differs: " + path);
            using (var hash = SHA256.Create())
            {
                string actual = BitConverter.ToString(hash.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
                if (!string.Equals(actual, expected, StringComparison.Ordinal)) throw new InvalidDataException("Boss music hash differs: " + path);
            }
            stream.Position = 0; return stream;
        }
        public void Dispose() { foreach (var stream in leases) stream.Dispose(); leases.Clear(); }
    }
}
