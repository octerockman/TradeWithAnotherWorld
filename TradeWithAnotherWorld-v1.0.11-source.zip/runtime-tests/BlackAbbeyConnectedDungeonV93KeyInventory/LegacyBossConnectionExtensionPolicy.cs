namespace BlackAbbeySixRooms
{
    internal static class LegacyBossConnectionExtensionPolicy
    {
        internal const int MaximumRooms=LegacyThirdLoopExtensionPolicy.MaximumRooms,MaximumApproachRooms=6;
        internal const int PlacementBudget=12000,PerAnchorBudget=3000;
        internal const string Reason="preferred far anchor direct fit failed; necessary terminal approach route";
        internal static bool IsExtraId(string id)=>id!=null&&id.IndexOf("_boss_extra_",System.StringComparison.Ordinal)>=0;
        internal static bool Eligible(int normalTarget,int inventory,int bossCount,int missingNormalRooms,int thirdExtras,int placedRooms)=>
            normalTarget>=LegacyNaturalDungeonRoster.MinimumRooms&&normalTarget<=LegacyNaturalDungeonRoster.MaximumRooms&&inventory==normalTarget&&
            bossCount==0&&missingNormalRooms==0&&thirdExtras>=0&&thirdExtras<=LegacyThirdLoopExtensionPolicy.MaximumRouteExtras&&
            placedRooms==normalTarget-1+thirdExtras&&normalTarget+thirdExtras<=MaximumRooms;
        internal static bool Accepts(int normalTarget,int thirdExtras,int bossExtras)=>normalTarget>=LegacyNaturalDungeonRoster.MinimumRooms&&normalTarget<=LegacyNaturalDungeonRoster.MaximumRooms&&
            thirdExtras>=0&&thirdExtras<=LegacyThirdLoopExtensionPolicy.MaximumRouteExtras&&bossExtras>0&&bossExtras<=MaximumApproachRooms&&normalTarget+thirdExtras+bossExtras<=MaximumRooms;
    }
}
