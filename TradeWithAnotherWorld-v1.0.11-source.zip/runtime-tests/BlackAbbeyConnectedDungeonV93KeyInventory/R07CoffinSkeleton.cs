using System;
using System.Collections.Generic;
using System.Linq;
using Jotunn.Managers;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // Borrow native mesh/material data only. Never instantiate the Skeleton
    // enemy, its Animator, equipment, Character, AI, collider or network view.
    public sealed class R07CoffinSkeleton : MonoBehaviour
    {
        internal const string PrefabName = "Skeleton";
        internal const string BodyPath = "Visual/_skeleton_base/Skeleton";
        internal const int SourceVertexCount = 2986;
        internal const int SourceBoneCount = 53;
        // Exact approved author's hollow, mapped (x,y,z) Blender -> (x,z,y).
        internal static readonly Vector3 CavityMin = new Vector3(-3.1949f, .1885f, 3.9626f);
        internal static readonly Vector3 CavityMax = new Vector3(-2.4051f, .6985f, 6.0374f);
        private Mesh ownedMesh;
        private Bounds placedBounds;
        private float uniformScale;
        private int vertices;

        internal static R07CoffinSkeleton Attach(Transform room, Action<string> log)
        {
            if (!room) throw new ArgumentNullException(nameof(room));
            var prefab = PrefabManager.Instance.GetPrefab(PrefabName);
            if (!prefab) throw new InvalidOperationException("The native Skeleton prefab is not loaded.");
            var sourceTransform = prefab.transform.Find(BodyPath);
            var source = sourceTransform ? sourceTransform.GetComponent<SkinnedMeshRenderer>() : null;
            if (!source || !source.sharedMesh || source.sharedMesh.name != "Skeleton" ||
                source.sharedMesh.vertexCount != SourceVertexCount || source.bones.Length != SourceBoneCount ||
                source.sharedMaterials.Length != 1 || !source.sharedMaterials[0] || source.sharedMaterials[0].name != "Skeleton")
                throw new InvalidOperationException("The native Skeleton body no longer matches the inspected unarmed model.");
            var eye = prefab.transform.Find("EyePos");
            if (!eye || Vector3.Dot(prefab.transform.InverseTransformDirection(eye.forward).normalized, Vector3.forward) < .999f)
                throw new InvalidOperationException("The inspected Skeleton facing datum changed.");

            GameObject rig = null, host = null;
            Mesh baked = null;
            try
            {
                rig = new GameObject("TEMP R07 native skeleton bones only");
                rig.SetActive(false); // Data-only skinning never enters a live enemy lifecycle.
                var map = new Dictionary<Transform, Transform> { [prefab.transform] = rig.transform };
                Func<Transform, Transform> copy = null;
                copy = original =>
                {
                    if (map.TryGetValue(original, out var existing)) return existing;
                    if (!original || !original.IsChildOf(prefab.transform)) throw new InvalidOperationException("Skeleton bone escapes its prefab.");
                    var parent = copy(original.parent);
                    var target = new GameObject(original.name).transform;
                    target.SetParent(parent, false); target.localPosition = original.localPosition;
                    target.localRotation = original.localRotation; target.localScale = original.localScale;
                    map.Add(original, target); return target;
                };
                var skinTransform = copy(source.transform);
                var skin = skinTransform.gameObject.AddComponent<SkinnedMeshRenderer>();
                skin.enabled = false; skin.sharedMesh = source.sharedMesh;
                skin.sharedMaterials = source.sharedMaterials;
                skin.bones = source.bones.Select(copy).ToArray(); skin.rootBone = copy(source.rootBone);
                // The body renderer is the actual VisEquipment.m_bodyModel,
                // not an equipment renderer. Only required bone ancestors are
                // copied: neither hand attachment nor a weapon mesh is copied.
                var bones = skin.bones.ToDictionary(b => b.name, StringComparer.Ordinal);
                Aim(bones["LeftArm"], bones["LeftForeArm"], new Vector3(-.07f, -1, 0));
                Aim(bones["LeftForeArm"], bones["LeftHand"], new Vector3(-.035f, -1, .035f));
                Aim(bones["RightArm"], bones["RightForeArm"], new Vector3(.07f, -1, 0));
                Aim(bones["RightForeArm"], bones["RightHand"], new Vector3(.035f, -1, .035f));
                Aim(bones["LeftUpLeg"], bones["LeftLeg"], new Vector3(-.035f, -1, 0));
                Aim(bones["LeftLeg"], bones["LeftFoot"], Vector3.down);
                Aim(bones["RightUpLeg"], bones["RightLeg"], new Vector3(.035f, -1, 0));
                Aim(bones["RightLeg"], bones["RightFoot"], Vector3.down);
                baked = new Mesh { name = "R07 inert native Skeleton body, arms at sides" };
                skin.BakeMesh(baked, false);
                if (baked.vertexCount != SourceVertexCount) throw new InvalidOperationException("Native skeleton skin bake is incomplete.");
                // Native EyePos is +Z forward and +Y upright. This proper
                // rotation puts the skull north (+Z) and its face upward (+Y).
                Quaternion supine = Quaternion.LookRotation(Vector3.up, Vector3.forward);
                Matrix4x4 bodyToRoom = Matrix4x4.Rotate(supine) * skinTransform.localToWorldMatrix;
                Vector3[] points = baked.vertices, normals = baked.normals;
                var bounds = new Bounds(bodyToRoom.MultiplyPoint3x4(points[0]), Vector3.zero);
                for (int i = 0; i < points.Length; i++) { points[i] = bodyToRoom.MultiplyPoint3x4(points[i]); bounds.Encapsulate(points[i]); }
                Vector3 available = CavityMax - CavityMin - new Vector3(.050f, .019f, .050f);
                if (bounds.size.x <= 0 || bounds.size.y <= 0 || bounds.size.z <= 0) throw new InvalidOperationException("Native skeleton posed bounds are invalid.");
                float scale = Mathf.Min(1.96f / bounds.size.z, available.x / bounds.size.x, available.y / bounds.size.y);
                if (!float.IsFinite(scale) || scale <= 0 || bounds.size.z * scale < 1.55f)
                    throw new InvalidOperationException("The native skeleton pose cannot fit the coffin at adult length.");
                Vector3 translation = new Vector3((CavityMin.x + CavityMax.x) * .5f, CavityMin.y + .004f, (CavityMin.z + CavityMax.z) * .5f) - new Vector3(bounds.center.x, bounds.min.y, bounds.center.z) * scale;
                Matrix4x4 normalMatrix = bodyToRoom.inverse.transpose;
                Bounds placed = new Bounds(points[0] * scale + translation, Vector3.zero);
                for (int i = 0; i < points.Length; i++)
                {
                    points[i] = points[i] * scale + translation; placed.Encapsulate(points[i]);
                    if (normals.Length == points.Length) normals[i] = normalMatrix.MultiplyVector(normals[i]).normalized;
                    if (points[i].x < CavityMin.x + .024f || points[i].x > CavityMax.x - .024f ||
                        points[i].y < CavityMin.y + .003f || points[i].y > CavityMax.y - .014f ||
                        points[i].z < CavityMin.z + .024f || points[i].z > CavityMax.z - .024f)
                        throw new InvalidOperationException("A posed skeleton vertex escapes the actual coffin hollow.");
                }
                baked.vertices = points;
                if (normals.Length == points.Length) baked.normals = normals;
                baked.RecalculateBounds(); baked.RecalculateTangents();
                host = new GameObject("R07 inert native unarmed Skeleton in coffin"); host.SetActive(false);
                host.transform.SetParent(room, false);
                var owner = host.AddComponent<R07CoffinSkeleton>(); owner.ownedMesh = baked;
                owner.placedBounds = placed; owner.uniformScale = scale; owner.vertices = baked.vertexCount;
                host.AddComponent<MeshFilter>().sharedMesh = baked;
                var renderer = host.AddComponent<MeshRenderer>(); renderer.sharedMaterials = source.sharedMaterials;
                renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On; renderer.receiveShadows = true;
                if (host.GetComponentsInChildren<Component>(true).Any(c => !(c is Transform) && !(c is MeshFilter) && !(c is MeshRenderer) && !(c is R07CoffinSkeleton)))
                    throw new InvalidOperationException("Inert skeleton contains an unexpected behaviour.");
                baked = null; host.SetActive(true); owner.LogStatus(log); return owner;
            }
            catch
            {
                if (host) { host.SetActive(false); Object.Destroy(host); }
                if (baked) Object.Destroy(baked);
                throw;
            }
            finally { if (rig) Object.Destroy(rig); }
        }
        private static void Aim(Transform bone, Transform tip, Vector3 direction)
        {
            Vector3 current = tip.position - bone.position;
            if (current.sqrMagnitude < .0000001f) throw new InvalidOperationException("Native skeleton limb has no usable length.");
            bone.rotation = Quaternion.FromToRotation(current, direction.normalized) * bone.rotation;
        }
        internal void LogStatus(Action<string> write)
        {
            write?.Invoke("R07_COFFIN_SKELETON: nativePrefab=Skeleton; body=" + BodyPath + "; vertices=" + vertices +
                "; boundsMin=" + placedBounds.min.ToString("F4") + "; boundsMax=" + placedBounds.max.ToString("F4") +
                "; size=" + placedBounds.size.ToString("F4") + "; uniformScale=" + uniformScale.ToString("F5") +
                "; skull=north; face=up; weapons=0; armor=0; ai=0; character=0; network=0; colliders=0; inert=true.");
        }
        private void OnDestroy() { if (ownedMesh) Object.Destroy(ownedMesh); }
    }
}
