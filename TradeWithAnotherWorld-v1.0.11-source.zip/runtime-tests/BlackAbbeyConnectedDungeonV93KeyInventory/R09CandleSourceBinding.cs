namespace BlackAbbeySixRooms
{
    // These two packages retain the same exact 198 canonical wick sockets and
    // alcove geometry. Keep raw catalog/file agreement before accepting either
    // source/manifest tuple; canonical aliases alone cannot prove that pairing.
    internal static class R09CandleSourceBinding
    {
        internal const string BaseSourceSha256="869bac079de49440aebe2c2dd5cabbbce2e0040173eb65977d0f1ae57fd8efb4";
        internal const string BaseManifestSha256="5cde66736e87e218de1cfa47127604f73f075964164c9cdc98ae5b15d3e6e57a";
        internal const string AlternateSourceSha256="12686a0c6393a6187ccb60f46a71fbace98f309eabcbe8ac7b7d300f08ab4d18";
        internal const string AlternateManifestSha256="d96032b1e8a38720502cda0b85302e44928851251087db41fb4f172f0c0a213e";

        internal static bool Matches(string source,string catalogManifest,string actualManifest)=>
            catalogManifest==actualManifest&&
            (KitArchitectureProfile.Matches(source,actualManifest)||source==BaseSourceSha256&&actualManifest==BaseManifestSha256||
             source==AlternateSourceSha256&&actualManifest==AlternateManifestSha256);
    }
}
