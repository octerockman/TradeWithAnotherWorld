using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Pure policy shared by the runtime and finite offline regression tests.
    // Unity supplies current renderer ownership, layer names and camera masks.
    internal static class WindowProjectionLayerPolicy
    {
        internal static int Select(IEnumerable<int> originalPaneLayers, IEnumerable<int> cameraMasks,
            IEnumerable<int> foreignOccupiedLayers, IEnumerable<int> namedLayers, IEnumerable<int> ownedLayers)
        {
            var originals = originalPaneLayers.Distinct().ToArray();
            var cameras = cameraMasks.ToArray();
            if (originals.Length == 0 || originals.Any(layer => layer < 0 || layer > 31) || cameras.Length == 0) return -1;
            var foreign = new HashSet<int>(foreignOccupiedLayers);
            var named = new HashSet<int>(namedLayers);
            // Prefer an existing safe reservation instead of consuming another
            // camera-visible layer for each repeated room or source package.
            var candidates = ownedLayers.Where(layer => layer >= 8 && layer <= 31).Distinct().OrderByDescending(layer => layer)
                .Concat(Enumerable.Range(8, 24).Reverse()).Distinct();
            foreach (int candidate in candidates)
                if (!named.Contains(candidate) && !foreign.Contains(candidate) && cameras.All(mask =>
                    originals.All(original => (mask & (1 << original)) == 0 || (mask & (1 << candidate)) != 0))) return candidate;
            return -1;
        }
    }
}
