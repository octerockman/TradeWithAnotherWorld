namespace BlackAbbeySixRooms
{
    internal static class WardingMechanismSource
    {
        internal const string ManifestSha256="1046a6faf72d506562fa0f13e59c16e5e22d9e84e432abfaae100628f5a50d4f";
    }
}
