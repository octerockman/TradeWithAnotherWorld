using System;
using System.Collections.Generic;
using System.IO;

namespace BlackAbbeySixRooms
{
    // An absent saved marker is revision0, never permission to replay old runs
    // through a newer roster/route policy. The approved rules apply to new runs.
    internal static class DungeonGenerationPolicy
    {
        internal const int LegacyRevision = 0;
        internal const int PreviousRevision = 1;
        internal const int RouteRevision = 2;
        internal const int KitRevision = 3;
        internal const int CurrentRevision = 4;
        internal static DungeonPlan GenerateWithKnightReturnLoop(IEnumerable<DungeonRoomSpec> input,int seed,bool oneBrokenSaint,int minimumQuestHops,int revision,IEnumerable<DungeonRoomSpec> variants,string savedBossUnlockRoute=null)
        {
            RequireRevision(revision);
            string route=savedBossUnlockRoute??(UnrecordedDeadGeneration.WantsRoute(seed)&&UnrecordedDeadGeneration.Complete(variants)?UnrecordedDeadGeneration.Route:UnrecordedDeadGeneration.FalseVowsRoute);
            if(route!=UnrecordedDeadGeneration.Route)return Generate(input,seed,oneBrokenSaint,minimumQuestHops,revision,variants,savedBossUnlockRoute);
            if(revision!=CurrentRevision)throw new InvalidDataException("Knight return loop requires the current split-room architecture.");
            var plan=R09SplitPlanning.GenerateKnightLoop(input,seed,variants);
            plan.KnightReturnLoopRevision=R08KnightReturnPolicy.Revision;
            UnrecordedDeadGeneration.ValidatePlan(plan);R08KnightReturnPolicy.RequireLoop(plan);return plan;
        }
        internal static void RequireRevision(int revision)
        {
            if (revision != LegacyRevision && revision != PreviousRevision && revision != RouteRevision && revision != KitRevision && revision != CurrentRevision)
                throw new InvalidDataException("Unknown saved dungeon generation revision; the saved run was retained.");
        }
        internal static DungeonPlan Generate(IEnumerable<DungeonRoomSpec> input, int seed,
            bool oneBrokenSaint, int minimumQuestHops, int revision)
            => Generate(input, seed, oneBrokenSaint, minimumQuestHops, revision, null, null);
        internal static DungeonPlan Generate(IEnumerable<DungeonRoomSpec> input, int seed,
            bool oneBrokenSaint, int minimumQuestHops, int revision, IEnumerable<DungeonRoomSpec> variants, string savedBossUnlockRoute = null)
        {
            RequireRevision(revision);
            if (revision < RouteRevision && savedBossUnlockRoute != null)
                throw new InvalidDataException("Legacy runs cannot acquire a newer boss-route identity.");
            if (savedBossUnlockRoute != null && savedBossUnlockRoute != UnrecordedDeadGeneration.Route && savedBossUnlockRoute != UnrecordedDeadGeneration.FalseVowsRoute)
                throw new InvalidDataException("Unknown saved boss-unlock route; saved run retained.");
            string route = revision >= RouteRevision ? savedBossUnlockRoute ??
                (UnrecordedDeadGeneration.WantsRoute(seed) && UnrecordedDeadGeneration.Complete(variants) ? UnrecordedDeadGeneration.Route : UnrecordedDeadGeneration.FalseVowsRoute) : null;
            if(revision==CurrentRevision)
            {
                var split=R09SplitPlanning.Generate(input,seed,oneBrokenSaint,minimumQuestHops,variants,route);
                if(route==UnrecordedDeadGeneration.Route)UnrecordedDeadGeneration.ValidatePlan(split);
                return split;
            }
            var selected = route == UnrecordedDeadGeneration.Route ? UnrecordedDeadGeneration.VariantSet(variants) : null;
            var plan = revision == LegacyRevision ? LegacyDungeonLayoutPlanner.GenerateNatural(input, seed, oneBrokenSaint, minimumQuestHops) :
                DungeonLayoutPlanner.GenerateNatural(input, seed, route == UnrecordedDeadGeneration.Route ? false : oneBrokenSaint,
                    route == UnrecordedDeadGeneration.Route ? 0 : minimumQuestHops, selected);
            plan.GenerationRevision = revision;
            plan.BossUnlockRoute = route;
            if (route == UnrecordedDeadGeneration.Route) UnrecordedDeadGeneration.ValidatePlan(plan);
            return plan;
        }
    }
}
