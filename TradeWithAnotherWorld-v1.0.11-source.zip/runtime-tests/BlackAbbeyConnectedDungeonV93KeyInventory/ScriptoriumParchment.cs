using UnityEngine;

namespace BlackAbbeySixRooms
{
    // The visible parchment is already in the immutable R02 room atlas.
    // This child adds a tightly fitted interaction volume and image reader.
    public sealed class ScriptoriumParchment : MonoBehaviour, Hoverable, Interactable
    {
        internal const string RoomSource = "c23c81a4ff07587a01eda582ec08bbd22dc2ec398b993b15330c15e3c3d7e951";
        internal static void Attach(LoadedRoom room)
        {
            if (room.Manifest.roomId != "R02") return;
            ScriptoriumParchmentSourcePolicy.Require(room.Manifest.roomId, room.Manifest.sourceSha256,
                room.Record?.sourceSha256, room.Record?.manifestSha256);
            if (room.Root.GetComponentInChildren<ScriptoriumParchment>(true)) return;
            var host = new GameObject("BA_Scriptorium_Parchment_Clue");
            host.layer = LayerMask.NameToLayer("piece");
            host.transform.SetParent(room.Root.transform, false);
            host.transform.localPosition = new Vector3(-2.6534647f, .8416850f, .9199974f);
            var box = host.AddComponent<BoxCollider>();
            // One centimetre above/below the actual stack makes the thin paper
            // selectable above its tabletop without blocking the walking route.
            box.size = new Vector3(.283036f, .0600242f, .346634f);
            host.AddComponent<ScriptoriumParchment>();
        }
        public string GetHoverName() => "Stack of parchment";
        public string GetHoverText()
        {
            const string text = "Stack of parchment\n[<color=yellow><b>$KEY_Use</b></color>] Read";
            return Localization.instance != null ? Localization.instance.Localize(text) : text;
        }
        public float GetHoverOffset() => .1f;
        public bool Interact(Humanoid user, bool hold, bool alt)
        {
            if (hold || !(user is Player player) || player != Player.m_localPlayer ||
                (player.transform.position - transform.position).sqrMagnitude > 20.25f || !TextViewer.instance)
                return false;
            return ScriptoriumImageReader.Open(player);
        }
        public bool UseItem(Humanoid user, ItemDrop.ItemData item) => false;
    }
}
