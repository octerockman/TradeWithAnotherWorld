using System;using System.Collections.Generic;using System.Linq;using UnityEngine;using Object=UnityEngine.Object;
namespace BlackAbbeySixRooms
{
    internal sealed partial class AbbeyMonkSpawns
    {
        readonly List<ZDO> recoveryBatch=new List<ZDO>();
        readonly Dictionary<string,List<ZDOID>> recoveryMatches=new Dictionary<string,List<ZDOID>>(StringComparer.Ordinal);
        string[] recoveryPrefabs;int recoveryKind,recoveryCursor;bool recoveryComplete;
        float recoveryLogAt;
        void RecoverMissing()
        {
            var pending=actors.Values.Where(s=>s.RecoveryPending).ToArray();if(pending.Length==0||placed==null)return;
            if(recoveryPrefabs==null)recoveryPrefabs=pending.Select(s=>s.Prefab).Distinct().OrderBy(s=>s,StringComparer.Ordinal).ToArray();
            // Complete the bounded native query before concluding an old UID is
            // absent. Match run/world/room/slot/prefab, including unloaded ZDOs.
            if(!recoveryComplete){
                bool complete;
                try{
                    complete=ZDOMan.instance.GetAllZDOsWithPrefabIterative(recoveryPrefabs[recoveryKind],recoveryBatch,ref recoveryCursor);
                    foreach(var zdo in recoveryBatch)foreach(var slot in pending)if(Owned(zdo,slot)){
                        if(!recoveryMatches.TryGetValue(slot.Key,out var ids))recoveryMatches.Add(slot.Key,ids=new List<ZDOID>());
                        if(!ids.Contains(zdo.m_uid)&&ids.Count<3)ids.Add(zdo.m_uid);
                    }
                }catch(Exception error){RecoveryLog("Native record scan incomplete; no actor recreated: "+error.Message);return;}
                finally{recoveryBatch.Clear();}
                if(complete){recoveryCursor=0;recoveryKind++;recoveryComplete=recoveryKind>=recoveryPrefabs.Length;}
                if(!recoveryComplete)return;
            }
            foreach(var slot in pending){
                var original=ZDOMan.instance.GetZDO(slot.Id);
                if(!recoveryMatches.TryGetValue(slot.Key,out var matches))matches=new List<ZDOID>();
                var live=matches.Select(id=>ZDOMan.instance.GetZDO(id)).Where(z=>Owned(z,slot)).ToArray();
                // Recheck exact UID after the scan, before creating anything.
                if(Owned(original,slot)&&!live.Any(z=>z.m_uid==original.m_uid))live=live.Concat(new[]{original}).ToArray();
                var decision=ActorRecoveryPolicy.Choose(recoveryComplete,live.Length,ActorRecoveryPolicy.MayRecover(ledger.State(slot.Key)?.ToString(),slot.Health),original!=null&&!Owned(original,slot));
                if(decision==ActorRecoveryPolicy.Decision.Blocked){RecoveryLog("Ambiguous/dead saved slot left untouched: "+slot.Key);continue;}
                if(decision==ActorRecoveryPolicy.Decision.Reuse){
                    var zdo=live[0];float hp=zdo.GetFloat("health",float.NaN);
                    if(!float.IsNaN(hp)&&hp<=0){ledger.Mark(slot.Key,AbbeyMonkSpawnPolicy.SlotState.Dead);slot.RecoveryPending=false;SaveCheckpoint();continue;}
                    slot.Id=zdo.m_uid;zdo.SetOwner(ZDOMan.GetSessionID());zdo.Persistent=true;ledger.Mark(slot.Key,AbbeyMonkSpawnPolicy.SlotState.Spawned);slot.RecoveryPending=false;
                    slot.Actor=Find(slot);if(slot.Actor)slot.Actor.GetComponent<Character>().SetHealth(float.IsNaN(hp)?slot.Health.Value:Mathf.Min(hp,slot.Health.Value));
                    else zdo.Set("health",float.IsNaN(hp)?slot.Health.Value:Mathf.Min(hp,slot.Health.Value));
                    SaveCheckpoint();log?.Invoke("ABBEY_ENEMY_RECOVERY_REBOUND: "+slot.Key+"; existing native UID="+slot.Id);return;
                }
                if(slot.Position==null||slot.Rotation==null||!Player.m_localPlayer)continue;
                var position=new Vector3(slot.Position[0],slot.Position[1],slot.Position[2]);
                if((Player.m_localPlayer.transform.position-position).sqrMagnitude>45*45||Mathf.Abs(Player.m_localPlayer.transform.position.y-position.y)>4)continue;
                if(!TryPrefab(slot.Prefab,out var prefab))continue;
                Vector3 floor=default;bool supported=false;
                foreach(var room in placed.Values.OrderBy(p=>p.InstanceId==slot.InstanceId?0:1)){
                    var local=room.Room.Root.transform.InverseTransformPoint(position);var point=new AbbeyMonkSpawnPolicy.Point(local.x,local.z);
                    if(SupportAndClear(room,point,null,out floor,prefab)&&Mathf.Abs(floor.y+.05f-position.y)<.30f){supported=true;break;}
                }
                if(!supported){RecoveryLog("Saved position is not clear/supported yet; retrying: "+slot.Key);continue;}
                GameObject actor=null;
                try{
                    var rotation=new Quaternion(slot.Rotation[0],slot.Rotation[1],slot.Rotation[2],slot.Rotation[3]).normalized;
                    actor=Object.Instantiate(prefab,floor+Vector3.up*.05f,rotation);var view=actor.GetComponent<ZNetView>();
                    if(!view||!view.IsValid()||!view.IsOwner())throw new InvalidOperationException("Recovered actor has no valid host-owned native view");
                    var zdo=view.GetZDO();zdo.Set(RunKey,runId);zdo.Set(WorldKey,worldKey);zdo.Set(InstanceKey,slot.InstanceId);zdo.Set(SlotKey,slot.Key);
                    view.m_persistent=true;zdo.Persistent=true;actor.GetComponent<Character>().SetHealth(slot.Health.Value);
                    slot.Id=zdo.m_uid;slot.Actor=actor;slot.RecoveryPending=false;ledger.Mark(slot.Key,AbbeyMonkSpawnPolicy.SlotState.Spawned);Bind(actor,slot.Key);UpdateSnapshot(slot,zdo,actor);
                    // If sidecar writing fails, native tags let the next full
                    // query adopt this same actor rather than clone another.
                    SaveCheckpoint();log?.Invoke("ABBEY_ENEMY_RECOVERED: "+slot.Key+"; prefab="+slot.Prefab+"; health="+slot.Health+"; new UID="+slot.Id+"; consumed budget unchanged");
                }catch(Exception error){if(actor){var view=actor.GetComponent<ZNetView>();if(view&&view.IsValid()&&view.IsOwner())ZNetScene.instance.Destroy(actor);else Object.Destroy(actor);}slot.Actor=null;slot.RecoveryPending=true;if(ledger.State(slot.Key)!=AbbeyMonkSpawnPolicy.SlotState.Dead)ledger.Mark(slot.Key,AbbeyMonkSpawnPolicy.SlotState.Lost);RecoveryLog("Saved survivor recovery deferred: "+error.Message);}
                return; // At most one new/rebound actor per half-second tick.
            }
        }
        void RecoveryLog(string text){if(Time.unscaledTime<recoveryLogAt)return;recoveryLogAt=Time.unscaledTime+5;log?.Invoke("ABBEY_ENEMY_RECOVERY_WAIT: "+text);}
    }
}
