using System;
using System.Reflection;
using BepInEx.Bootstrap;
using Jotunn.Managers;
using Jotunn.Utils;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // This is an owned custom prefab, never a vanilla asset. GetPrefab's
    // fallback soft-asset lookup can throw when an earlier registration failed.
    internal static class AbbeyMonkDependency
    {
        internal const string PluginId = "studio.otherworld.hushedmonkingametest";
        internal const string PrefabName = "TWA_HushedMonk_Test";
        const string MarkerType = "BlackAbbey.HushedMonk.HushedMonkInstance";

        internal static bool TryGetReady(out GameObject prefab, out string reason)
        {
            prefab = null;
            if (!Chainloader.PluginInfos.TryGetValue(PluginId, out var plugin) || plugin?.Instance == null)
            { reason = "Install/enable the finished Hushed Monk 0.5.0 or newer package (" + PluginId + ")."; return false; }
            if (plugin.Metadata.Version < new System.Version(0, 5, 0))
            { reason = "The registered Hushed Monk package is older than 0.5.0."; return false; }
            var manager = PrefabManager.Instance;
            // ModQuery's public API reads only custom registrations, returning
            // null if absent. Its installed Jotunn IL has no asset-load fallback.
            var owned = manager == null ? null : ModQuery.GetPrefab(PrefabName);
            if (owned == null || !(prefab = owned.Prefab))
            {
                prefab = null;
                string failure = RegistrationFailure(plugin.Instance.GetType());
                reason = string.IsNullOrWhiteSpace(failure)
                    ? "Hushed Monk prefab is not registered yet; wait for its own registration, then retry."
                    : "Hushed Monk registration failed: " + failure;
                return false;
            }
            if (owned.SourceMod?.GUID != PluginId || !string.Equals(prefab.name, PrefabName, StringComparison.Ordinal))
            { prefab = null; reason = "Hushed Monk custom registration names a different prefab; no substitute will spawn."; return false; }
            var type = plugin.Instance.GetType().Assembly.GetType(MarkerType, false);
            if (type == null || !typeof(Component).IsAssignableFrom(type))
            { prefab = null; reason = "Finished monk instance marker type is unavailable."; return false; }
            var marker = prefab.GetComponent(type);
            if (!marker)
            { prefab = null; reason = "Registered monk prefab lacks its own finished character marker."; return false; }
            var payload = type.GetField("visualPayloadSha256", BindingFlags.Public | BindingFlags.Instance)?.GetValue(marker) as string;
            if (payload == null || payload.Length != 64 || !prefab.GetComponent<Character>() || !prefab.GetComponent<MonsterAI>() ||
                !prefab.GetComponent<ZNetView>() || !prefab.GetComponent<CapsuleCollider>() ||
                prefab.GetComponentsInChildren<SkinnedMeshRenderer>(true).Length == 0)
            { prefab = null; reason = "Registered prefab does not satisfy the finished monk visual/native lifecycle contract; no substitute will spawn."; return false; }
            reason = "Finished Hushed Monk " + plugin.Metadata.Version + " registered as " + PrefabName + "; payload=" + payload;
            return true;
        }

        static string RegistrationFailure(Type pluginType)
        {
            // Optional cross-plugin diagnostic; no dependency on a particular
            // Monk assembly revision and no unsafe fallback when it is absent.
            try
            {
                var property = pluginType.GetProperty("RegistrationFailure", BindingFlags.Public | BindingFlags.Static);
                return property?.PropertyType == typeof(string) ? property.GetValue(null, null) as string : null;
            }
            catch (Exception) { return null; }
        }

        internal static GameObject RequireReady()
        {
            if (!TryGetReady(out var prefab, out var reason))
                throw new InvalidOperationException("Hushed Monks are not ready: " + reason);
            return prefab;
        }
    }
}
