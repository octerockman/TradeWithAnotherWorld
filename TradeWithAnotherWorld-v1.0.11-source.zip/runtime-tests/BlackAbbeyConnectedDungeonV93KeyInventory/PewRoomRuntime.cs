using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    internal sealed class PewSourceRemainder:MonoBehaviour
    {
        internal string OriginalMeshSha256;
        internal int OriginalIndexCount;
        internal int DerivedSourceIndexCount;
        internal PewRepairProof RepairProof;
        // Prefix ordinals remain original IDs; a verified EOF tail has
        // separate derived ordinals bounded by DerivedSourceIndexCount.
        internal int[] OriginalTriangles;
        internal Mesh Remainder;
    }
    internal sealed class PewRoomBinding : MonoBehaviour
    {
        internal PewRoomState State;
        internal int Count;
        internal void LogStatus(Action<string> log) => log?.Invoke("PEW_STATE: room=" + name + "; total=" + Count + "; broken=" + State.BrokenCount + "; run-local damage/roll interaction; no loot or network replication.");
    }
    internal static class PewRoomRuntime
    {
        private sealed class RestBinding
        {
            internal MeshFilter Filter;
            internal MeshCollider Collider;
            internal Mesh Original, Rest;
            internal PewMeshRecord Source;
            internal int[] SourceTriangles;
            internal int DerivedSourceIndexCount;
            internal PewRepairProof RepairProof;
            internal PewSourceRemainder Provenance;
            internal void Assign(Mesh mesh) { if (Filter) Filter.sharedMesh = mesh; else if (Collider) Collider.sharedMesh = mesh; }
        }
        private sealed class FragmentChoice { internal PewMeshRecord Source; internal PewIndexRange Range; }
        private sealed class TemplateBinding
        {
            internal Mesh Mesh;
            internal bool Collision;
            internal Material[] Materials;
            internal ShadowCastingMode Shadows;
            internal bool ReceiveShadows;
        }
        internal static IEnumerator AttachSteps(LoadedRoom room, string dataRoot, PewRoomState state, Func<bool> authorized, Action<string> log)
        {
            if (!PewBreakContract.Available(room.Manifest.roomId)) yield break;
            if (!room.Root || room.Root.GetComponent<PewRoomBinding>() || state == null || authorized == null)
                throw new InvalidOperationException("Attach pew interaction once to a valid owned room.");
            var contract = PewBreakContract.Read(dataRoot, room.Manifest, room.Record.manifestSha256);
            var rows = room.Manifest.roomId == "R09"&&!KitArchitectureProfile.Matches(room.Manifest.sourceSha256,room.Record.manifestSha256) ? PewRowsContract.Read(dataRoot, room.Manifest, room.Record.manifestSha256, contract) : null;
            var rowSource = rows == null ? null : contract.pews.Single(p => p.id == rows.sourcePewId);
            float rowLengthScale = rows == null ? 1 : rows.instances[0].scale[2];
            if (rows != null && rows.instances.Any(r => Math.Abs(r.scale[2]-rowLengthScale) > .00001f))
                throw new InvalidDataException("Refined nave pews require one source-bound length scale.");
            var rowFragments = new List<PewDebrisPart>();
            var owners = new Dictionary<string, GameObject>(StringComparer.Ordinal);
            var fragments = new Dictionary<string, List<PewDebrisPart>>(StringComparer.Ordinal);
            var choices = new Dictionary<string, FragmentChoice[]>(StringComparer.Ordinal);
            var prepared = new List<RestBinding>(); bool committed = false;
            var template = new List<TemplateBinding>();
            try
            {
                foreach (var pew in contract.pews)
                {
                    var owner = new GameObject("BA_BREAKABLE_PEW | " + pew.id); owner.SetActive(false);
                    owner.transform.SetParent(room.Root.transform, false); owner.layer = LayerMask.NameToLayer("static_solid");
                    owners.Add(pew.id, owner); fragments.Add(pew.id, new List<PewDebrisPart>());
                    choices.Add(pew.id, pew.meshes.Where(m => m.purpose == "render")
                        .SelectMany(m => m.ranges.Where(r => !r.suppressDebris).Select(r => new FragmentChoice { Source = m, Range = r }))
                        .OrderByDescending(c => c.Range.indexCount).ThenBy(c => c.Source.name, StringComparer.Ordinal).ThenBy(c => c.Range.startIndex).Take(6).ToArray());
                }
                var groups = contract.pews.SelectMany(p => p.meshes.Select(m => new { Pew = p, Mask = m }))
                    .GroupBy(x => x.Mask.purpose + "|" + x.Mask.name, StringComparer.Ordinal);
                int selectedVisual = 0, selectedCollision = 0;
                foreach (var group in groups)
                {
                    var first = group.First().Mask; bool collision = first.purpose == "collider";
                    string objectName = collision ? "Collider | " + first.name : first.name;
                    var child = room.Root.transform.Find(objectName);
                    if (!child || child.localPosition != Vector3.zero || child.localRotation != Quaternion.identity || child.localScale != Vector3.one)
                        throw new InvalidDataException("Pew source lost its exact static room-space transform: " + objectName);
                    var filter = collision ? null : child.GetComponent<MeshFilter>();
                    var collider = collision ? child.GetComponent<MeshCollider>() : null;
                    var source = collision ? collider?.sharedMesh : filter?.sharedMesh;
                    if (!source || source.subMeshCount != 1)
                        throw new InvalidDataException("Pew source was altered before its exact partition: " + objectName);
                    PewRepairProof repairProof;int derivedSourceIndexCount=first.sourceIndexCount;
                    if(PewRepairProvenance.TryGet(source,out repairProof))
                        derivedSourceIndexCount=StairCollarRepair.RequirePewSource(room,first,collision,source.vertexCount,(int)source.GetIndexCount(0),repairProof,group.SelectMany(x=>x.Mask.ranges).ToArray(),dataRoot);
                    else if(source.GetIndexCount(0)!=first.sourceIndexCount||(!collision&&source.vertexCount!=first.sourceVertexCount)||source.vertexCount>first.sourceVertexCount)
                        throw new InvalidDataException("Pew source was altered before its exact partition: " + objectName);
                    // Read attributes once per affected batch, not once per pew.
                    var indices = source.triangles; var positions = source.vertices;
                    var normals = collision ? null : source.normals; var uv = collision ? null : source.uv;
                    var tangents = collision ? null : source.tangents;
                    if (!collision && (normals.Length != positions.Length || uv.Length != positions.Length || tangents.Length != positions.Length))
                        throw new InvalidDataException("Pew source is missing authored vertex attributes.");
                    string identity = "pew-partition-v1|" + PewBreakContract.ManifestSha256 + "|" + source.GetInstanceID() + "|" + group.Key;
                    var restSection = PewMeshPartition.Build(indices, positions.Length, group.SelectMany(x => x.Mask.ranges), true);
                    if (restSection.Indices.Length == 0) throw new InvalidDataException("A pew mask cannot remove its whole room batch.");
                    string waxToken = BossWaxRetirement.RemainderCacheToken(room, first, collision);
                    if (waxToken.Length > 0) restSection = BossWaxRetirement.PrepareRemainder(room, dataRoot, contract, first, restSection, positions);
                    var rest = MakeMesh(room, identity + "|rest" + waxToken, first.name + " | retained non-pew faces", restSection, positions, normals, uv, tangents, Vector3.zero);
                    prepared.Add(new RestBinding { Filter = filter, Collider = collider, Original = source, Rest = rest,Source=first,SourceTriangles=restSection.SourceTriangles,DerivedSourceIndexCount=derivedSourceIndexCount,RepairProof=repairProof });
                    foreach (var entry in group)
                    {
                        int count = entry.Mask.ranges.Sum(r => r.indexCount / 3);
                        if (collision) selectedCollision += count; else selectedVisual += count;
                        bool isTemplate = rows != null && entry.Pew.id == rows.sourcePewId;
                        // The template must exist even if the original alcove
                        // pew was broken earlier in this same run.
                        if (state.IsBroken(entry.Pew.id) && !isTemplate) continue;
                        var section = PewMeshPartition.Build(indices, positions.Length, entry.Mask.ranges);
                        var mesh = MakeMesh(room, identity + "|" + entry.Pew.id, entry.Pew.id + " | " + first.name,
                            section, positions, normals, uv, tangents, Vector3.zero);
                        var owner = owners[entry.Pew.id];
                        if (collision)
                        {
                            // Script and every exact solid are on the same object,
                            // so native damage lookup and collision callbacks agree.
                            if (!state.IsBroken(entry.Pew.id)) AddSolid(owner, mesh);
                            if (isTemplate) template.Add(new TemplateBinding { Mesh = RefineNave(room, identity, mesh, rowSource.boundsMin[2],rowSource.boundsMax[2],rowLengthScale), Collision = true });
                        }
                        else
                        {
                            var originalRenderer = child.GetComponent<MeshRenderer>();
                            if (!originalRenderer) throw new InvalidDataException("Missing pew source material renderer.");
                            var binding = new TemplateBinding { Mesh = mesh, Materials = originalRenderer.sharedMaterials,
                                Shadows = originalRenderer.shadowCastingMode, ReceiveShadows = originalRenderer.receiveShadows };
                            if (!state.IsBroken(entry.Pew.id)) AddVisual(owner, binding);
                            if (isTemplate) template.Add(new TemplateBinding {Mesh=RefineNave(room,identity,mesh,rowSource.boundsMin[2],rowSource.boundsMax[2],rowLengthScale),Materials=binding.Materials,Shadows=binding.Shadows,ReceiveShadows=binding.ReceiveShadows});
                            foreach (var choice in choices[entry.Pew.id].Where(c => ReferenceEquals(c.Source, entry.Mask)))
                            {
                                var part = PewMeshPartition.Build(indices, positions.Length, new[] { choice.Range });
                                string fragmentKey=identity+"|fracture-v2|"+choice.Range.startIndex+"|"+choice.Range.indexCount;
                                var board = MakeMesh(room, fragmentKey+"|board",entry.Pew.id+" | source board",part,positions,normals,uv,tangents,Vector3.zero);
                                AddFractures(room,fragmentKey,board,originalRenderer.sharedMaterial,fragments[entry.Pew.id]);
                                if(isTemplate)AddFractures(room,fragmentKey+"|nave",RefineNave(room,fragmentKey,board,rowSource.boundsMin[2],rowSource.boundsMax[2],rowLengthScale),originalRenderer.sharedMaterial,rowFragments);
                            }
                        }
                    }
                    // Collider cooking/upload occurs during loading only. A hit
                    // later toggles the existing pew colliders without recooking.
                    yield return null;
                }
                if (rows != null)
                {
                    if (template.Count != contract.pews.Single(p => p.id == rows.sourcePewId).meshes.Length ||
                        !template.Any(b => b.Collision) || !template.Any(b => !b.Collision) || fragments[rows.sourcePewId].Count == 0)
                        throw new InvalidDataException("The canonical nave pew template is incomplete.");
                    foreach (var row in rows.instances)
                    {
                        var owner = new GameObject("BA_BREAKABLE_PEW | " + row.id); owner.SetActive(false);
                        owner.transform.SetParent(room.Root.transform, false); owner.layer = LayerMask.NameToLayer("static_solid");
                        owner.transform.localPosition = new Vector3(row.position[0], row.position[1], row.position[2]);
                        owner.transform.localRotation = Quaternion.Euler(0, row.yawDegrees, 0);
                        owner.transform.localScale = new Vector3(row.scale[0], row.scale[1], row.scale[2]);
                        owners.Add(row.id, owner);
                        if (!state.IsBroken(row.id))
                        {
                            // Fresh owners share only immutable mesh/material
                            // references. No copied component delegates/ledger.
                            foreach (var binding in template)
                                if (binding.Collision) AddSolid(owner, binding.Mesh); else AddVisual(owner, binding);
                            fragments.Add(row.id, rowFragments);
                        }
                        yield return null;
                    }
                }
                foreach (var binding in prepared)
                {
                    binding.Assign(binding.Rest);
                    if(KitArchitectureProfile.Matches(room.Manifest.sourceSha256,room.Record.manifestSha256))
                    {
                        var child=binding.Filter?binding.Filter.gameObject:binding.Collider.gameObject;
                        if(child.GetComponent<PewSourceRemainder>())throw new InvalidDataException("Pew remainder provenance was already assigned.");
                        var proof=child.AddComponent<PewSourceRemainder>();binding.Provenance=proof;
                        proof.OriginalMeshSha256=binding.Source.sourceMeshSha256;proof.OriginalIndexCount=binding.Source.sourceIndexCount;
                        proof.DerivedSourceIndexCount=binding.DerivedSourceIndexCount;proof.RepairProof=binding.RepairProof;
                        proof.OriginalTriangles=binding.SourceTriangles;proof.Remainder=binding.Rest;
                    }
                }
                foreach (var entry in owners)
                {
                    var id = entry.Key; var owner = entry.Value;
                    if (state.IsBroken(id)) continue;
                    var target = owner.AddComponent<AbbeyBreakablePew>();
                    target.Configure(room.InstanceId, id, authorized, () => state.TryBreak(id), fragments[id].ToArray(), log);
                    owner.SetActive(true);
                }
                var marker = room.Root.AddComponent<PewRoomBinding>(); marker.State = state; marker.Count = owners.Count;
                committed = true;
                log?.Invoke("PEW_PARTITION: room=" + room.InstanceId + "; pews=" + owners.Count + "; addedNaveRows=" + (rows?.instances.Length ?? 0) + "; sourceVisualTriangles=" + selectedVisual +
                    "; sourceCollisionTriangles=" + selectedCollision + "; broken=" + state.BrokenCount + "; source attributes/rest geometry retained; shared immutable partitions; no break-time collider recook.");
            }
            finally
            {
                if (!committed)
                {
                    foreach (var binding in prepared){binding.Assign(binding.Original);if(binding.Provenance)Object.Destroy(binding.Provenance);}
                    foreach (var owner in owners.Values) if (owner) { owner.SetActive(false); Object.Destroy(owner); }
                }
            }
        }
        private static void AddSolid(GameObject owner, Mesh mesh)
        {
            var solid = owner.AddComponent<MeshCollider>(); solid.convex = false; solid.sharedMesh = mesh;
        }
        private static Mesh RefineNave(LoadedRoom room,string key,Mesh source,float min,float max,float scale)
        {
            key+="|slim-nave-v2|"+source.GetInstanceID();
            if(SharedRoomResources.TryAcquire<Mesh>(key,room,out var resident))return resident;
            var mesh=Object.Instantiate(source);mesh.name=source.name+" | thin-end nave v2";room.Resources.Add(mesh);
            var points=source.vertices;var normals=source.normals;var tangents=source.tangents;
            for(int i=0;i<points.Length;i++)
            {
                float derivative=PewRefinementPolicy.Derivative(points[i].z,min,max,scale);
                points[i].z=PewRefinementPolicy.Coordinate(points[i].z,min,max,scale);
                if(normals.Length==points.Length){var n=normals[i];n.z/=derivative;normals[i]=n.normalized;}
                if(tangents.Length==points.Length){var t=tangents[i];var direction=new Vector3(t.x,t.y,t.z*derivative).normalized;tangents[i]=new Vector4(direction.x,direction.y,direction.z,t.w);}
            }
            mesh.vertices=points;if(normals.Length==points.Length)mesh.normals=normals;if(tangents.Length==points.Length)mesh.tangents=tangents;
            mesh.RecalculateBounds();SharedRoomResources.Retain(key,mesh,room);return mesh;
        }
        private static void AddFractures(LoadedRoom room,string key,Mesh board,Material material,List<PewDebrisPart> destination)
        {
            // Meshes are built/cached during loading; subsequent breaks reuse
            // capped board segments, never recook physics or partition faces.
            var pieces=PewFractureGeometry.Build(board.vertices,board.normals,board.uv,board.tangents,board.triangles);
            for(int i=0;i<pieces.Length;i++)
            {
                string pieceKey=key+"|piece|"+i;var p=pieces[i];
                if(!SharedRoomResources.TryAcquire<Mesh>(pieceKey,room,out var mesh))
                {
                    mesh=new Mesh {name=board.name+" | broken wood "+i,indexFormat=p.Positions.Length>65535?IndexFormat.UInt32:IndexFormat.UInt16};
                    room.Resources.Add(mesh);mesh.vertices=p.Positions;mesh.normals=p.Normals;mesh.uv=p.Uv;mesh.tangents=p.Tangents;mesh.triangles=p.Indices;mesh.RecalculateBounds();SharedRoomResources.Retain(pieceKey,mesh,room);
                }
                destination.Add(new PewDebrisPart {Mesh=mesh,Material=material,LocalPosition=p.Pivot});
            }
        }
        private static void AddVisual(GameObject owner, TemplateBinding binding)
        {
            var visual = new GameObject(binding.Mesh.name); visual.transform.SetParent(owner.transform, false); visual.layer = owner.layer;
            visual.AddComponent<MeshFilter>().sharedMesh = binding.Mesh;
            var renderer = visual.AddComponent<MeshRenderer>(); renderer.sharedMaterials = binding.Materials;
            renderer.shadowCastingMode = binding.Shadows; renderer.receiveShadows = binding.ReceiveShadows;
        }
        private static Mesh MakeMesh(LoadedRoom room, string key, string name, PewMeshSection section, Vector3[] positions, Vector3[] normals,
            Vector2[] uv, Vector4[] tangents, Vector3 pivot)
        {
            if (SharedRoomResources.TryAcquire<Mesh>(key, room, out var resident)) return resident;
            var mesh = new Mesh { name = name, indexFormat = section.SourceVertices.Length > 65535 ? IndexFormat.UInt32 : IndexFormat.UInt16 };
            room.Resources.Add(mesh);
            var points = section.Copy(positions);
            if (pivot != Vector3.zero) for (int i = 0; i < points.Length; i++) points[i] -= pivot;
            mesh.vertices = points;
            if (normals != null) { mesh.normals = section.Copy(normals); mesh.uv = section.Copy(uv); mesh.tangents = section.Copy(tangents); }
            mesh.triangles = section.Indices; mesh.RecalculateBounds();
            SharedRoomResources.Retain(key, mesh, room); return mesh;
        }
    }
}
