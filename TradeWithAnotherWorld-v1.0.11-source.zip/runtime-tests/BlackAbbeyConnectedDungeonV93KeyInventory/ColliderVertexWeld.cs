using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Managed exact-position compaction AFTER the original source hash/BAR1
    // count validation. The caller must check the owning MeshCollider's actual
    // native WeldColocatedVertices flag before using this variant/cache key.
    // No Unity objects, epsilon, triangle edits or visual attributes are used.
    internal static class ColliderVertexWeld
    {
        [StructLayout(LayoutKind.Explicit)]
        private struct FloatBits
        {
            [FieldOffset(0)] internal float Value;
            [FieldOffset(0)] internal int Bits;
        }
        private readonly struct Point : IEquatable<Point>
        {
            private readonly int x,y,z;
            internal Point(Vector3 p)
            {
                x=new FloatBits{Value=p.x}.Bits;
                y=new FloatBits{Value=p.y}.Bits;
                z=new FloatBits{Value=p.z}.Bits;
            }
            public bool Equals(Point p)=>x==p.x&&y==p.y&&z==p.z;
            public override bool Equals(object value)=>value is Point p&&Equals(p);
            public override int GetHashCode(){unchecked{return ((x*397)^y)*397^z;}}
        }
        private static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
        internal static BarMeshData Compact(BarMeshData source)
        {
            if(source==null||source.Positions==null||source.Indices==null||source.Positions.Length<3||source.Indices.Length<3||source.Indices.Length%3!=0)
                throw new InvalidDataException("Exact collision compaction requires a complete triangulated source buffer.");
            if(source.Normals!=null||source.UV!=null||source.Tangents!=null)
                throw new InvalidDataException("Exact collision compaction cannot operate on visual attributes.");
            foreach(var p in source.Positions)
                if(!Finite(p.x)||!Finite(p.y)||!Finite(p.z))throw new InvalidDataException("Nonfinite collision position.");
            foreach(int i in source.Indices)
                if((uint)i>=(uint)source.Positions.Length)throw new InvalidDataException("Collision index outside validated source positions.");
            var lookup=new Dictionary<Point,int>();
            var positions=new List<Vector3>(Math.Min(source.Positions.Length,65536));
            var remap=new int[source.Positions.Length];
            for(int i=0;i<source.Positions.Length;i++)
            {
                var p=source.Positions[i];var key=new Point(p);
                if(!lookup.TryGetValue(key,out int index))
                {index=positions.Count;lookup.Add(key,index);positions.Add(p);}
                remap[i]=index;
            }
            if(positions.Count<3||positions.Count==source.Positions.Length)return source;
            var indices=new int[source.Indices.Length];
            for(int i=0;i<indices.Length;i++)indices[i]=remap[source.Indices[i]];
            return new BarMeshData{Positions=positions.ToArray(),Indices=indices};
        }
    }
}
