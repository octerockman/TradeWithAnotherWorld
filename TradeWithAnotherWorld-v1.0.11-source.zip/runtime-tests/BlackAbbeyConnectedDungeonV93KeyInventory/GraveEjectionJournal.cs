using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlackAbbeySixRooms
{
    internal sealed class GraveExitRecord
    {
        public long userId,ownerId;
        public uint objectId;
        public int prefabHash;
        public float[] original,destination;
    }
    // Journal first, native transform second, run retirement last. Replaying a
    // record is always a separate exact-native-grave ownership decision. This
    // store has no game/native/object-creation or inventory API dependencies.
    internal sealed class GraveEjectionJournal
    {
        internal const int MaximumRecords=1024,MaximumBytes=512*1024;
        static readonly UTF8Encoding Utf8=new UTF8Encoding(false,true);
        readonly string root;
        sealed class Document
        {
            public int schemaVersion=1;
            public string worldKey;
            public List<GraveExitRecord> records;
        }
        internal GraveEjectionJournal(string root)
        {if(string.IsNullOrWhiteSpace(root))throw new ArgumentException("A grave journal directory is required.");this.root=Path.GetFullPath(root);}
        string FileFor(string world)
        {
            if(string.IsNullOrWhiteSpace(world)||Utf8.GetByteCount(world)>4096)throw new ArgumentException("A bounded world identity is required for the grave journal.");
            using(var sha=SHA256.Create())return Path.Combine(root,BitConverter.ToString(sha.ComputeHash(Utf8.GetBytes(world))).Replace("-","").ToLowerInvariant()+".json");
        }
        static JsonSerializer Serializer()=>JsonSerializer.Create(new JsonSerializerSettings {TypeNameHandling=TypeNameHandling.None,
            MetadataPropertyHandling=MetadataPropertyHandling.Ignore,DateParseHandling=DateParseHandling.None,MaxDepth=12});
        static bool Finite(float n)=>!float.IsNaN(n)&&!float.IsInfinity(n);
        internal static void Validate(GraveExitRecord record)
        {
            if(record==null||record.userId==0||record.objectId==0||record.ownerId==0||record.prefabHash==0||
                record.original==null||record.original.Length!=3||record.original.Any(v=>!Finite(v)||Math.Abs(v)>100000)||
                record.destination==null||record.destination.Length!=3||record.destination.Any(v=>!Finite(v)||Math.Abs(v)>100000)||record.destination[1]>=7000)
                throw new InvalidDataException("Grave journal record identity/coordinates are invalid; existing data retained.");
        }
        static bool Same(GraveExitRecord a,GraveExitRecord b)=>a.userId==b.userId&&a.objectId==b.objectId&&a.ownerId==b.ownerId&&a.prefabHash==b.prefabHash&&
            a.original.SequenceEqual(b.original)&&a.destination.SequenceEqual(b.destination);
        static GraveExitRecord Copy(GraveExitRecord r)=>new GraveExitRecord {userId=r.userId,objectId=r.objectId,ownerId=r.ownerId,prefabHash=r.prefabHash,
            original=(float[])r.original.Clone(),destination=(float[])r.destination.Clone()};
        Document Read(string file,string world)
        {
            if(!File.Exists(file))return new Document {worldKey=world,records=new List<GraveExitRecord>()};
            byte[] buffer=new byte[MaximumBytes+1];int count=0,n;
            using(var stream=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.Read))
            {
                if(stream.Length>MaximumBytes)throw new InvalidDataException("Grave journal is oversized; retained unchanged.");
                while(count<buffer.Length&&(n=stream.Read(buffer,count,buffer.Length-count))>0)count+=n;
                if(count>MaximumBytes)throw new InvalidDataException("Grave journal is oversized; retained unchanged.");
            }
            using(var text=new StringReader(Utf8.GetString(buffer,0,count).TrimStart('\uFEFF')))
            using(var reader=new JsonTextReader(text) {MaxDepth=12,DateParseHandling=DateParseHandling.None})
            {
                var token=JObject.Load(reader,new JsonLoadSettings {DuplicatePropertyNameHandling=DuplicatePropertyNameHandling.Error});
                if(reader.Read())throw new InvalidDataException("Grave journal has trailing content; retained unchanged.");
                if(token["schemaVersion"]?.Type!=JTokenType.Integer||(int)token["schemaVersion"]!=1||token["worldKey"]?.Type!=JTokenType.String||
                    (string)token["worldKey"]!=world||token["records"]?.Type!=JTokenType.Array)
                    throw new InvalidDataException("Grave journal schema/world differs; retained unchanged.");
                var result=token.ToObject<Document>(Serializer());
                if(result.records==null||result.records.Count>MaximumRecords)throw new InvalidDataException("Grave journal count exceeds the bounded limit.");
                var ids=new HashSet<string>(StringComparer.Ordinal);
                foreach(var record in result.records)
                {
                    Validate(record);
                    if(!ids.Add(record.userId+":"+record.objectId))throw new InvalidDataException("Duplicate grave UID in journal; retained unchanged.");
                }
                return result;
            }
        }
        internal List<GraveExitRecord> Load(string world)=>Read(FileFor(world),world).records.Select(Copy).ToList();
        FileStream Lock(string file)
        {
            var elapsed=Stopwatch.StartNew();
            while(true)
            {
                try{return new FileStream(file+".lock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);}
                catch(IOException) {if(elapsed.ElapsedMilliseconds>=2000)throw new IOException("Another writer owns this world's grave journal; retry without retiring the run.");Thread.Sleep(25);}
            }
        }
        internal void Add(string world,GraveExitRecord record)
        {
            Validate(record);string file=FileFor(world);Directory.CreateDirectory(root);
            using(var guard=Lock(file))
            {
                var data=Read(file,world); // Malformed data is never overwritten.
                var existing=data.records.SingleOrDefault(r=>r.userId==record.userId&&r.objectId==record.objectId);
                if(existing!=null)
                {
                    if(!Same(existing,record))throw new InvalidDataException("Existing grave UID has another identity or destination; no journal entry changed.");
                    return; // Idempotent replay does not rotate the durable backup.
                }
                if(data.records.Count>=MaximumRecords)throw new InvalidDataException("Grave journal is full; do not retire the dungeon before safe ejection is recorded.");
                data.records.Add(Copy(record));byte[] bytes;
                using(var text=new StringWriter(System.Globalization.CultureInfo.InvariantCulture))
                using(var writer=new JsonTextWriter(text) {Formatting=Formatting.Indented})
                {Serializer().Serialize(writer,data);writer.Flush();bytes=Utf8.GetBytes(text.ToString());}
                if(bytes.Length>MaximumBytes)throw new InvalidDataException("Grave journal encoding exceeds the bounded limit.");
                string temp=file+"."+Guid.NewGuid().ToString("N")+".tmp";
                try
                {
                    using(var stream=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)) {stream.Write(bytes,0,bytes.Length);stream.Flush(true);}
                    if(File.Exists(file))File.Replace(temp,file,file+".bak");else File.Move(temp,file);
                }
                finally {if(File.Exists(temp))File.Delete(temp);}
            }
        }
    }
}
