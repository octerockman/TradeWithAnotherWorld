using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Generated from actual V7c wick upper-tip centroids + measured canonical
    // median gap25.919914mm. The original198 sockets/data/native are unchanged.
    internal static class R09CandleSocketOverrides
    {
        internal const string NativeSourceSha256=R09EncounterState.ScopedNativeSourceSha256;
        internal const string BaseManifestSha256="5cde66736e87e218de1cfa47127604f73f075964164c9cdc98ae5b15d3e6e57a";
        internal const string CandidateWitnessSha256="e15e1a1b4c5cdbdcdce398431e01dd177c91198aa965f76c4b3c929d74dffa8a";
        internal const string BaseSocketFingerprint="c2f9a43d714a85aa2e983f7a14184648160d75b1dd822dee0c3269ea4db6bf54";
        internal const int CanonicalCount=198,SupplementCount=48,EffectiveCount=246;
        private sealed class Measured
        {
            internal readonly string Name,SourceWick;
            internal readonly float X,Y,Z;
            internal Measured(string name,string source,float x,float y,float z){Name=name;SourceWick=source;X=x;Y=y;Z=z;}
            internal SocketRecord Copy()=>new SocketRecord{name=Name,position=new[]{X,Y,Z}};
        }
        private static readonly Measured[] measured={
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_01","R09V3 alcove east 1 -1 votive spent candle 0 | wick",12.3194523f,1.42219996f,1.90910995f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_02","R09V3 alcove east 1 -1 votive spent candle 1 | wick",12.6096296f,1.31484795f,1.88939714f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_03","R09V3 alcove east 1 -1 votive spent candle 2 | wick",12.4892635f,1.53721988f,2.1488018f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_04","R09V3 alcove east 1 1 votive spent candle 0 | wick",12.3194523f,1.26219988f,5.88911009f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_05","R09V3 alcove east 1 1 votive spent candle 1 | wick",12.6096296f,1.15484786f,5.86939716f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_06","R09V3 alcove east 1 1 votive spent candle 2 | wick",12.4892635f,1.37721992f,6.1288023f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_07","R09V3 alcove east 2 -1 votive spent candle 0 | wick",12.3194523f,1.52219987f,9.90911007f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_08","R09V3 alcove east 2 -1 votive spent candle 1 | wick",12.6096296f,1.41484797f,9.88939762f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_09","R09V3 alcove east 2 -1 votive spent candle 2 | wick",12.4892635f,1.63721991f,10.1488018f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_10","R09V3 alcove east 2 1 votive spent candle 0 | wick",12.3194523f,1.36219978f,13.8891106f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_11","R09V3 alcove east 2 1 votive spent candle 1 | wick",12.6096296f,1.25484788f,13.8693972f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_12","R09V3 alcove east 2 1 votive spent candle 2 | wick",12.4892635f,1.47721982f,14.1288023f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_13","R09V3 alcove east 3 -1 votive spent candle 0 | wick",12.3194523f,1.46219993f,17.909111f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_14","R09V3 alcove east 3 -1 votive spent candle 1 | wick",12.6096296f,1.35484791f,17.8893967f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_15","R09V3 alcove east 3 -1 votive spent candle 2 | wick",12.4892635f,1.57721984f,18.1488018f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_16","R09V3 alcove east 3 1 votive spent candle 0 | wick",12.3194523f,1.32219982f,21.8891106f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_17","R09V3 alcove east 3 1 votive spent candle 1 | wick",12.6096296f,1.21484792f,21.8693981f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_18","R09V3 alcove east 3 1 votive spent candle 2 | wick",12.4892635f,1.43721986f,22.1288013f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_19","R09V3 alcove east 4 -1 votive spent candle 0 | wick",12.3194523f,1.54219985f,25.909111f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_20","R09V3 alcove east 4 -1 votive spent candle 1 | wick",12.6096296f,1.43484795f,25.8893967f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_21","R09V3 alcove east 4 -1 votive spent candle 2 | wick",12.4892635f,1.65721989f,26.1488018f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_22","R09V3 alcove east 4 1 votive spent candle 0 | wick",12.3194523f,1.39219999f,29.8891087f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_23","R09V3 alcove east 4 1 votive spent candle 1 | wick",12.6096296f,1.28484797f,29.8694f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_24","R09V3 alcove east 4 1 votive spent candle 2 | wick",12.4892635f,1.50721991f,30.1288013f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_25","R09V3 alcove west 1 -1 votive spent candle 0 | wick",-12.6205473f,1.42219996f,1.90910995f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_26","R09V3 alcove west 1 -1 votive spent candle 1 | wick",-12.3303699f,1.31484795f,1.88939714f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_27","R09V3 alcove west 1 -1 votive spent candle 2 | wick",-12.450736f,1.53721988f,2.1488018f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_28","R09V3 alcove west 1 1 votive spent candle 0 | wick",-12.6205473f,1.26219988f,5.88911009f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_29","R09V3 alcove west 1 1 votive spent candle 1 | wick",-12.3303699f,1.15484786f,5.86939716f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_30","R09V3 alcove west 1 1 votive spent candle 2 | wick",-12.450736f,1.37721992f,6.1288023f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_31","R09V3 alcove west 2 -1 votive spent candle 0 | wick",-12.6205473f,1.52219987f,9.90911007f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_32","R09V3 alcove west 2 -1 votive spent candle 1 | wick",-12.3303699f,1.41484797f,9.88939762f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_33","R09V3 alcove west 2 -1 votive spent candle 2 | wick",-12.450736f,1.63721991f,10.1488018f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_34","R09V3 alcove west 2 1 votive spent candle 0 | wick",-12.6205473f,1.36219978f,13.8891106f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_35","R09V3 alcove west 2 1 votive spent candle 1 | wick",-12.3303699f,1.25484788f,13.8693972f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_36","R09V3 alcove west 2 1 votive spent candle 2 | wick",-12.450736f,1.47721982f,14.1288023f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_37","R09V3 alcove west 3 -1 votive spent candle 0 | wick",-12.6205473f,1.46219993f,17.909111f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_38","R09V3 alcove west 3 -1 votive spent candle 1 | wick",-12.3303699f,1.35484791f,17.8893967f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_39","R09V3 alcove west 3 -1 votive spent candle 2 | wick",-12.450736f,1.57721984f,18.1488018f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_40","R09V3 alcove west 3 1 votive spent candle 0 | wick",-12.6205473f,1.32219982f,21.8891106f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_41","R09V3 alcove west 3 1 votive spent candle 1 | wick",-12.3303699f,1.21484792f,21.8693981f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_42","R09V3 alcove west 3 1 votive spent candle 2 | wick",-12.450736f,1.43721986f,22.1288013f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_43","R09V3 alcove west 4 -1 votive spent candle 0 | wick",-12.6205473f,1.54219985f,25.909111f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_44","R09V3 alcove west 4 -1 votive spent candle 1 | wick",-12.3303699f,1.43484795f,25.8893967f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_45","R09V3 alcove west 4 -1 votive spent candle 2 | wick",-12.450736f,1.65721989f,26.1488018f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_46","R09V3 alcove west 4 1 votive spent candle 0 | wick",-12.6205473f,1.39219999f,29.8891087f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_47","R09V3 alcove west 4 1 votive spent candle 1 | wick",-12.3303699f,1.28484797f,29.8694f),
            new Measured("R09 runtime FLAME_SOCKET | R09_V27_ALCOVE_48","R09V3 alcove west 4 1 votive spent candle 2 | wick",-12.450736f,1.50721991f,30.1288013f),
        };
        internal static string Fingerprint(SocketRecord[] sockets)
        {
            using(var bytes=new MemoryStream())
            {
                using(var writer=new BinaryWriter(bytes,new UTF8Encoding(false,true),true))
                {
                    writer.Write(sockets.Length);
                    foreach(var s in sockets)
                    {
                        if(s==null || string.IsNullOrEmpty(s.name) || s.position==null || s.position.Length!=3 || s.position.Any(v=>float.IsNaN(v)||float.IsInfinity(v)))throw new InvalidDataException("Invalid R09 canonical candle source.");
                        writer.Write(s.name);foreach(float value in s.position)writer.Write(value);
                    }
                }
                using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(bytes.ToArray())).Replace("-","").ToLowerInvariant();
            }
        }
        internal static SocketRecord[] ForRoom(PackageManifest manifest)
        {
            if(manifest==null)throw new ArgumentNullException(nameof(manifest));
            var original=manifest.sockets??Array.Empty<SocketRecord>();
            if(manifest.roomId!="R09" || UnrecordedDeadSourceBindings.Canonical("R09",manifest.sourceSha256)!=NativeSourceSha256)return original;
            if(original.Length!=CanonicalCount || Fingerprint(original)!=BaseSocketFingerprint || measured.Length!=SupplementCount)
                throw new InvalidDataException("Measured R09 alcove sockets require the exact198-socket V7c source; do not transplant these bindings.");
            var result=new SocketRecord[EffectiveCount];
            for(int i=0;i<original.Length;i++)result[i]=new SocketRecord{name=original[i].name,position=(float[])original[i].position.Clone()};
            for(int i=0;i<measured.Length;i++)result[CanonicalCount+i]=measured[i].Copy();
            return result;
        }
        internal static int ApplyToRoom(LoadedRoom room)
        {
            if(room?.Manifest==null || !room.Root)throw new ArgumentException("Candle supplementation requires an inactive loaded room.");
            if(room.Manifest.roomId!="R09" || UnrecordedDeadSourceBindings.Canonical("R09",room.Manifest.sourceSha256)!=NativeSourceSha256)return 0;
            if(room.Root.activeSelf || room.Root.activeInHierarchy)throw new InvalidOperationException("Add measured R09 sockets before native flame attachment/activation.");
            string manifestPath=RoomPackage.FilePath(room.PackageDirectory,"manifest.json");
            if(!R09CandleSourceBinding.Matches(room.Manifest.sourceSha256,room.Record?.manifestSha256,CatalogReader.HashFile(manifestPath)))
                throw new InvalidDataException("R09 alcove supplementation requires its exact approved source/manifest pair and matching catalog/file bytes.");
            var expected=ForRoom(room.Manifest);var root=room.Root.transform;
            var all=root.GetComponentsInChildren<Transform>(true).GroupBy(t=>t.name,StringComparer.Ordinal).ToDictionary(g=>g.Key,g=>g.ToArray(),StringComparer.Ordinal);
            var names=new HashSet<string>(expected.Select(s=>s.name),StringComparer.Ordinal);
            if(all.Keys.Any(n=>n.Contains("FLAME_SOCKET") && !names.Contains(n)))throw new InvalidDataException("Unknown candle socket in the source-bound R09 instance.");
            // Preflight every existing marker before adding anything. An
            // interrupted valid prefix can be resumed; duplicates/drift fail.
            for(int i=0;i<expected.Length;i++)
            {
                var s=expected[i];
                if(!all.TryGetValue(s.name,out var found)){if(i<CanonicalCount)throw new InvalidDataException("Missing original R09 candle marker.");continue;}
                if(found.Length!=1 || found[0].parent!=root || (found[0].localPosition-new Vector3(s.position[0],s.position[1],s.position[2])).sqrMagnitude>1e-10f || (found[0].localScale-Vector3.one).sqrMagnitude>1e-10f || Quaternion.Angle(found[0].localRotation,Quaternion.identity)>.001f)
                    throw new InvalidDataException("Ambiguous or moved source-bound R09 candle marker: "+s.name);
            }
            int added=0;
            foreach(var s in expected.Skip(CanonicalCount))if(!all.ContainsKey(s.name))
            {
                var marker=new GameObject(s.name);marker.transform.SetParent(root,false);marker.transform.localPosition=new Vector3(s.position[0],s.position[1],s.position[2]);added++;
            }
            return added;
        }
    }
}
