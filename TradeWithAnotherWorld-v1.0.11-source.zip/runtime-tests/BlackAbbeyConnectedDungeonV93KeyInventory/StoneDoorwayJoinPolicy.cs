using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // The exact selection used by both pre-travel planning and Unity assembly.
    // Geometry validity alone does not imply an authored connector exists.
    internal static class StoneDoorwayJoinPolicy
    {
        private const float Tolerance = .0002f;
        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        private static bool Near(float a,float b) => Math.Abs(a-b) < Tolerance;
        internal static bool IsLongPort(PortRecord port)
        {
            if(port?.SourceRoomId!="R08"||port.position?.Length!=3||port.outward?.Length!=3||!Near(port.depth,2.05f)||
                !Near(port.position[0],0)||!Near(port.outward[0],0)||!Near(port.outward[1],0))return false;
            return (port.id=="D01"||port.id=="SOUTH")&&Near(port.position[1],0)&&Near(port.position[2],-5.75f)&&Near(port.outward[2],-1)||
                (port.id=="D02"||port.id=="NORTH")&&Near(port.position[1],10.8f)&&Near(port.position[2],5.75f)&&Near(port.outward[2],1);
        }
        internal static bool IsExtendedReturnPort(PortRecord port)=>port?.SourceRoomId=="R08"&&
            (port.id=="KNIGHT-RETURN"||port.id=="D03")&&port.position?.Length==3&&port.outward?.Length==3&&
            Near(port.depth,.5f)&&Near(port.position[0],0)&&Near(port.position[1],0)&&Near(port.position[2],15.7f)&&
            Near(port.outward[0],0)&&Near(port.outward[1],0)&&Near(port.outward[2],1);
        internal static bool IsLongJoin(PortRecord a,PortRecord b)=>IsLongPort(a)||IsLongPort(b)||IsExtendedReturnPort(a)||IsExtendedReturnPort(b);
        internal static double JointGap(PortRecord a,PortRecord b)=>IsExtendedReturnPort(a)||IsExtendedReturnPort(b)?3.42:.02;
        internal static bool IsCircle(PortRecord port)
        {
            if(KitPointedArchitecture.Pointed(port))return false;
            if (port == null || !new[] {port.width,port.height,port.depth,port.springHeight,port.archRise}.All(Finite) ||
                Math.Abs(port.width-3f)>.001f || Math.Abs(port.height-3.5f)>.03f ||
                Math.Abs(port.height-port.springHeight-port.archRise)>.001f ||
                !(Near(port.depth,.5f)||Near(port.depth,.65f)||Near(port.depth,.75f)||IsLongPort(port)))
                throw new InvalidDataException("Masonry port has unknown width, height or source depth.");
            if (Math.Abs(port.springHeight-2f)<.03f && Math.Abs(port.archRise-1.5f)<.03f && Near(port.depth,.5f)) return true;
            if (Math.Abs(port.springHeight-2.6f)<.03f && Math.Abs(port.archRise-.9f)<.03f) return false;
            throw new InvalidDataException("Unknown source arch profile/depth; refuse to substitute another shape.");
        }
        internal static string Select(PortRecord a,PortRecord b,float gap)
        {
            if(KitPointedArchitecture.Pointed(a)||KitPointedArchitecture.Pointed(b))
            {if(!KitPointedArchitecture.Pointed(a)||!KitPointedArchitecture.Pointed(b)||!Near(gap,KitPointedArchitecture.Gap))throw new InvalidDataException("Cannot mix old and pointed room apertures.");return "pointed_080";}
            bool ca=IsCircle(a),cb=IsCircle(b);
            if(!Finite(gap) || Math.Abs(gap-JointGap(a,b))>Tolerance)
                throw new InvalidDataException("Masonry join requires its source-bound free gap (2cm normally; authored3.42m knight-return extension).");
            float length=a.depth+b.depth+gap;
            string size=Near(length,1.02f)?"102":Near(length,1.17f)?"117":Near(length,1.27f)?"127":Near(length,1.32f)?"132":Near(length,1.42f)?"142":
                IsLongJoin(a,b)?Near(length,2.57f)?"257":Near(length,2.72f)?"272":Near(length,2.82f)?"282":
                    Near(length,4.42f)?"442":Near(length,4.57f)?"457":Near(length,4.67f)?"467":null:null;
            if(size==null)throw new InvalidDataException("No authored masonry module for length "+length.ToString("R",System.Globalization.CultureInfo.InvariantCulture)+"m.");
            return "joined_"+size+"_"+(ca?"c":"e")+(cb?"c":"e");
        }
        internal static string ReturnModule(PortRecord port)
        {
            if(IsLongPort(port)||IsExtendedReturnPort(port))throw new InvalidDataException("The alternate stair's three landings must connect, not receive a short barred-return module.");
            bool circle=IsCircle(port);
            return "barred_"+(Near(port.depth,.5f)?"052":Near(port.depth,.65f)?"067":"077")+"_"+(circle?"c":"e");
        }
        internal static void ValidatePlan(DungeonPlan plan,PackageManifest kit,PackageManifest longKit=null)
        {
            if(kit?.roomId==KitPointedArchitecture.KitId){KitPointedArchitecture.ValidatePlan(plan,kit);return;}
            if(plan?.Rooms==null || plan.Links==null || kit?.roomId!="STONE_DOORWAY_KIT_V5" || kit.meshes==null || kit.colliderMeshes==null || kit.materials==null)
                throw new InvalidDataException("Missing planned rooms or source-bound masonry inventory.");
            var required=new HashSet<string>(StringComparer.Ordinal);var longRequired=new HashSet<string>(StringComparer.Ordinal);
            foreach(var link in plan.Links)
            {
                if(link==null || link.A<0 || link.B<0 || link.A>=plan.Rooms.Length || link.B>=plan.Rooms.Length)
                    throw new InvalidDataException("Invalid masonry link endpoint.");
                string module=Select(link.PortA,link.PortB,(float)(link.End-link.Start).Length);
                if(IsLongJoin(link.PortA,link.PortB))
                {
                    bool validA=(IsLongPort(link.PortA)||IsExtendedReturnPort(link.PortA))&&plan.Rooms[link.A].Spec.AssetId=="R08-UD";
                    bool validB=(IsLongPort(link.PortB)||IsExtendedReturnPort(link.PortB))&&plan.Rooms[link.B].Spec.AssetId=="R08-UD";
                    if(plan.GenerationRevision<2||plan.BossUnlockRoute!=UnrecordedDeadGeneration.Route||validA==validB)
                        throw new InvalidDataException("Long masonry approaches are restricted to one exact alternate-stair source endpoint.");
                    longRequired.Add(module);
                }
                else required.Add(module);
            }
            for(int i=0;i<plan.Rooms.Length;i++)
            {
                if(plan.Rooms[i]?.Spec?.Ports==null)throw new InvalidDataException("Missing source port inventory.");
                foreach(var port in plan.Rooms[i].Spec.Ports.Where(p=>!plan.IsLinked(i,p.id)))required.Add(ReturnModule(port));
            }
            ValidateModules(kit,required);
            if(longRequired.Count>0)
            {
                if(longKit?.roomId!="STONE_DOORWAY_KIT_V5"||longKit.meshes==null||longKit.colliderMeshes==null||longKit.materials==null)
                    throw new InvalidDataException("The exact-depth alternate-stair masonry kit is missing; no travel occurred.");
                ValidateModules(longKit,longRequired);
            }
        }
        private static void ValidateModules(PackageManifest kit,IEnumerable<string> required)
        {
            foreach(string module in required)
            {
                foreach(string part in new[]{"_blocks","_backing"})
                {
                    var rows=kit.meshes.Where(m=>m?.name==module+part).ToArray();
                    if(rows.Length!=1 || !Complete(rows[0]) || rows[0].materialIndex<0 || rows[0].materialIndex>=kit.materials.Length)
                        throw new InvalidDataException("Masonry preflight missing/ambiguous visual module: "+module+part+".");
                }
                var bodies=kit.colliderMeshes.Where(m=>m?.name==module).ToArray();
                if(bodies.Length!=1 || !Complete(bodies[0]))throw new InvalidDataException("Masonry preflight missing/ambiguous collision module: "+module+".");
            }
        }
        private static bool Complete(MeshRecord row) => row.vertices>0 && row.indices>0 && row.indices%3==0 && row.triangles==row.indices/3 &&
            !string.IsNullOrWhiteSpace(row.meshFile) && CatalogReader.Hash(row.sha256);
    }
}
