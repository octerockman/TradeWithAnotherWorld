using System;
using System.Collections.Generic;
using System.Globalization;

namespace BlackAbbeySixRooms
{
    internal readonly struct FalseVowsBookPose : IEquatable<FalseVowsBookPose>
    {
        internal readonly float X,Y,Z,RX,RY,RZ;
        internal FalseVowsBookPose(float x,float y,float z,float rx,float ry,float rz)
        { X=Limit(x,.75f);Y=Limit(y,.75f);Z=Limit(z,.75f);RX=Limit(rx,360);RY=Limit(ry,360);RZ=Limit(rz,360); }
        private static float Limit(float v,float bound)
        { if(float.IsNaN(v)||float.IsInfinity(v))throw new ArgumentException("Grip values must be finite.");return Math.Max(-bound,Math.Min(bound,v)); }
        internal static FalseVowsBookPose Default=>new FalseVowsBookPose(.02f,.03f,.06f,90,0,90);
        internal float Get(int axis)=>axis==0?X:axis==1?Y:axis==2?Z:axis==3?RX:axis==4?RY:axis==5?RZ:throw new ArgumentOutOfRangeException(nameof(axis));
        internal FalseVowsBookPose With(int axis,float v)=>new FalseVowsBookPose(axis==0?v:X,axis==1?v:Y,axis==2?v:Z,axis==3?v:RX,axis==4?v:RY,axis==5?v:RZ);
        internal static bool TryParse(string[] text,out FalseVowsBookPose pose)
        {
            pose=Default;if(text==null||text.Length!=6)return false;var values=new float[6];
            for(int i=0;i<6;i++)if(!float.TryParse(text[i],NumberStyles.Float,CultureInfo.InvariantCulture,out values[i])||float.IsNaN(values[i])||float.IsInfinity(values[i]))return false;
            pose=new FalseVowsBookPose(values[0],values[1],values[2],values[3],values[4],values[5]);return true;
        }
        public bool Equals(FalseVowsBookPose p)=>X==p.X&&Y==p.Y&&Z==p.Z&&RX==p.RX&&RY==p.RY&&RZ==p.RZ;
        public override bool Equals(object value)=>value is FalseVowsBookPose p&&Equals(p);
        public override int GetHashCode()=>X.GetHashCode()^Y.GetHashCode()^Z.GetHashCode()^RX.GetHashCode()^RY.GetHashCode()^RZ.GetHashCode();
    }
    internal sealed class FalseVowsBookFitSession
    {
        private readonly Stack<FalseVowsBookPose> undo=new Stack<FalseVowsBookPose>();
        internal FalseVowsBookPose Current{get;private set;}
        internal FalseVowsBookPose Saved{get;private set;}
        internal bool Dirty=>!Current.Equals(Saved);
        internal FalseVowsBookFitSession(FalseVowsBookPose initial){Current=Saved=initial;}
        internal bool Change(FalseVowsBookPose next){if(Current.Equals(next))return false;undo.Push(Current);Current=next;return true;}
        internal bool Undo(){if(undo.Count==0)return false;Current=undo.Pop();return true;}
        internal void Reset()=>Change(FalseVowsBookPose.Default);
        internal void Discard(){Current=Saved;undo.Clear();}
        internal void Save(Action<FalseVowsBookPose> persist){persist(Current);Saved=Current;}
    }
    internal static class FalseVowsBookRules
    {
        internal const float BaseBluntDamage=5f;
        internal static bool BypassPlayerPvp(bool actualBookMelee,bool sameAttacker,bool otherPlayerTarget)=>actualBookMelee&&sameAttacker&&otherPlayerTarget;
    }
}
