using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Jotunn.Managers;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Rendering;
using Object=UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    [Serializable] internal sealed class WardingSpawnerMount
    {
        public string sourceId,portId,kind,sourceSha256,floorPolicy;
        public float depth;
        public float[] boundsMin,boundsMax;
    }
    [Serializable] internal sealed class WardingSpawnerResource
    {public string file,sha256;}
    [Serializable] internal sealed class WardingSpawnerMesh
    {public string name,file,sha256,motion,role;public int vertices,indices,triangles;}
    [Serializable] internal sealed class WardingSpawnerSockets
    {public float[] pinPoint,actorMouth,actorStaging,innerDoor,actorExit,wardCentre;public float wardRadius;}
    [Serializable] internal sealed class WardingSpawnerModule
    {
        public string kind,nativeSha256;
        public float clearWidth,clearHeight,springHeight;
        public WardingSpawnerMesh[] parts,colliders;
        public Dictionary<string,float[][]> motions;
        public Dictionary<string,WardingSpawnerResource> textures;
        public WardingSpawnerSockets sockets;
        public float[] boundsMin,boundsMax;
    }
    [Serializable] internal sealed class WardingSpawnerManifest
    {public int schemaVersion;public WardingSpawnerResource[] modules;public WardingSpawnerMount[] mounts;}

    // Shared immutable geometry/texture owner. Instances contain only a small
    // rigid-transform hierarchy and per-instance progress material blocks.
    internal sealed class WardingSpawnerAssets:IDisposable
    {
        internal const string ManifestSha256=WardingAssetRevision.Current;
        readonly Dictionary<string,WardingSpawnerModule> modules=new Dictionary<string,WardingSpawnerModule>(StringComparer.Ordinal);
        readonly Dictionary<string,GameObject> templates=new Dictionary<string,GameObject>(StringComparer.Ordinal);
        readonly Dictionary<string,WardingSpawnerMount> mounts=new Dictionary<string,WardingSpawnerMount>(StringComparer.Ordinal);
        readonly List<Object> resources=new List<Object>();
        readonly List<GameObject> instances=new List<GameObject>();
        internal IEnumerable<WardingSpawnerMount> Mounts=>mounts.Values;
        bool disposed;
        sealed class Prepared
        {
            internal WardingSpawnerManifest Manifest;
            internal WardingSpawnerModule[] Modules;
            internal Dictionary<string,BarMeshData> Meshes;
            internal Dictionary<string,byte[]> Images;
        }
        internal bool TryGetMount(string sourceId,string portId,out WardingSpawnerMount mount)=>mounts.TryGetValue(sourceId+"/"+portId,out mount);
        static bool Finite(float n)=>!float.IsNaN(n)&&!float.IsInfinity(n);
        static bool V(float[] a)=>a!=null&&a.Length==3&&a.All(Finite);
        static string Safe(string root,string relative)=>RoomPackage.FilePath(root,relative);
        static void Validate(WardingSpawnerModule m)
        {
            if(m==null||!new[]{"e","c","shouldered","stair","p"}.Contains(m.kind)||!CatalogReader.Hash(m.nativeSha256)||m.parts==null||m.parts.Length==0||m.parts.Length>48||m.colliders==null||m.colliders.Length>10||m.motions==null||m.motions.Count>8||!V(m.boundsMin)||!V(m.boundsMax)||m.sockets==null||m.textures==null)
                throw new InvalidDataException("Invalid warding-spawner module envelope.");
            if(m.kind=="p"&&(!Finite(m.clearWidth)||!Finite(m.clearHeight)||!Finite(m.springHeight)||Math.Abs(m.clearWidth-3)>.0002f||Math.Abs(m.clearHeight-4)>.0002f||Math.Abs(m.springHeight-2)>.0002f||m.boundsMax[1]<4))throw new InvalidDataException("Pointed warding derivative must retain its measured3m x4m aperture and full envelope.");
            var s=m.sockets;
            if(!new[]{s.pinPoint,s.actorMouth,s.actorStaging,s.innerDoor,s.actorExit,s.wardCentre}.All(V)||!Finite(s.wardRadius)||s.wardRadius<1||s.wardRadius>3)
                throw new InvalidDataException("Invalid warding-spawner socket.");
            foreach(var a in m.motions.Values)
                if(a==null||a.Length!=192||a.Any(p=>p==null||p.Length!=10||p.Any(x=>!Finite(x)||Mathf.Abs(x)>100)||p.Skip(3).Take(4).Sum(x=>x*x)<.99||p.Skip(3).Take(4).Sum(x=>x*x)>1.01))
                    throw new InvalidDataException("Invalid exact-native spawner motion.");
            foreach(var mesh in m.parts.Concat(m.colliders))
                if(mesh==null||!CatalogReader.Hash(mesh.sha256)||mesh.motion!="static"&&!m.motions.ContainsKey(mesh.motion)||mesh.vertices<3||mesh.vertices>250000||mesh.indices<3||mesh.indices>1000000||mesh.indices%3!=0||mesh.triangles!=mesh.indices/3)
                    throw new InvalidDataException("Invalid spawner mesh binding.");
        }
        static Prepared Prepare(string root,IEnumerable<string> requestedKinds=null,bool metadataOnly=false)
        {
            string manifestPath=Safe(root,"manifest.json");
            bool rebuilt=KitArchitectureProfile.ContainsDirectory(root);
            if(CatalogReader.HashFile(manifestPath)!=KitArchitectureProfile.ExpectedHash(root,"manifest.json",ManifestSha256))throw new InvalidDataException("Warding-spawner manifest differs from compiled source.");
            var manifest=JsonConvert.DeserializeObject<WardingSpawnerManifest>(File.ReadAllText(manifestPath),ManifestReader.Settings());
            if(manifest==null||manifest.schemaVersion!=1||manifest.modules==null||manifest.modules.Length<(rebuilt?1:3)||manifest.modules.Length>4||manifest.mounts==null||manifest.mounts.Length<(rebuilt?1:18)||manifest.mounts.Length>(rebuilt?64:20))
                throw new InvalidDataException("Incomplete warding-spawner manifest.");
            var modules=new List<WardingSpawnerModule>();var allModules=new List<WardingSpawnerModule>();var meshes=new Dictionary<string,BarMeshData>();var images=new Dictionary<string,byte[]>();
            var requested=requestedKinds==null?null:new HashSet<string>(requestedKinds,StringComparer.Ordinal);
            foreach(var source in manifest.modules)
            {
                string path=Safe(root,source.file);
                if(!CatalogReader.Hash(source.sha256)||CatalogReader.HashFile(path)!=source.sha256)throw new InvalidDataException("Changed warding-spawner module.");
                var module=JsonConvert.DeserializeObject<WardingSpawnerModule>(File.ReadAllText(path),ManifestReader.Settings());Validate(module);if(rebuilt&&module.kind!="p")throw new InvalidDataException("Rebuilt warding mounts require the pointed source derivative, not a legacy arch profile.");allModules.Add(module);
                if(metadataOnly||requested!=null&&!requested.Contains(module.kind))continue;
                modules.Add(module);
                foreach(var mesh in module.parts.Concat(module.colliders))
                {
                    string key=mesh.file;
                    if(meshes.ContainsKey(key))continue;
                    var record=new MeshRecord {meshFile=mesh.file,sha256=mesh.sha256,vertices=mesh.vertices,indices=mesh.indices,triangles=mesh.triangles};
                    meshes.Add(key,BarMeshReader.Read(Safe(root,key),record,false));
                }
                foreach(var role in new[]{"albedo","normal","metallic-smoothness"})
                {
                    if(!module.textures.TryGetValue(role,out var texture)||!CatalogReader.Hash(texture.sha256))throw new InvalidDataException("Missing spawner texture map.");
                    if(!images.ContainsKey(texture.file))images.Add(texture.file,BarMeshReader.ReadVerifiedBytes(Safe(root,texture.file),texture.sha256,32*1024*1024));
                }
            }
            if(allModules.Select(m=>m.kind).Distinct().Count()!=allModules.Count)throw new InvalidDataException("Repeated spawner profile.");
            if(requested!=null&&requested.Any(k=>!allModules.Any(m=>m.kind==k)))throw new InvalidDataException("Requested spawner profile is unavailable.");
            foreach(var mount in manifest.mounts)
                if(mount==null||string.IsNullOrWhiteSpace(mount.sourceId)||string.IsNullOrWhiteSpace(mount.portId)||!allModules.Any(m=>m.kind==mount.kind)||!CatalogReader.Hash(mount.sourceSha256)||!Finite(mount.depth)||mount.depth<-.5f||mount.depth>1||!V(mount.boundsMin)||!V(mount.boundsMax))
                    throw new InvalidDataException("Invalid spawner exact-port binding.");
                else if(rebuilt&&(mount.floorPolicy!="rebuilt-clearance-checked-no-runtime-trim"||!KitArchitectureProfile.Matches(mount.sourceSha256)))
                    throw new InvalidDataException("Rebuilt spawner mount needs its sealed exact-source floor/threshold clearance proof.");
            return new Prepared {Manifest=manifest,Modules=modules.ToArray(),Meshes=meshes,Images=images};
        }
        // Selection needs only the pinned metadata. Avoid uploading any mesh or
        // compressing 2K maps for a chance-only source that was not selected.
        internal static IEnumerable<WardingSpawnerMount> ReadMounts(string directory)=>Prepare(directory,null,true).Manifest.mounts;
        internal static IEnumerator LoadSteps(string directory,Action<WardingSpawnerAssets> completed,Action<string> log=null,IEnumerable<string> requestedKinds=null)
        {
            var asset=new WardingSpawnerAssets();bool success=false;
            try
            {
                var requested=requestedKinds?.Distinct(StringComparer.Ordinal).ToArray();
                var task=RoomLoadScheduling.Worker(()=>Prepare(directory,requested));while(!task.IsCompleted)yield return null;
                var data=task.GetAwaiter().GetResult();
                foreach(var mount in data.Manifest.mounts)asset.mounts.Add(mount.sourceId+"/"+mount.portId,mount);
                var uploaded=new Dictionary<string,Mesh>();
                foreach(var pair in data.Meshes)
                {
                    var m=new Mesh {name="BA spawner | "+pair.Key,indexFormat=IndexFormat.UInt32};asset.resources.Add(m);
                    m.vertices=pair.Value.Positions;m.normals=pair.Value.Normals;m.uv=pair.Value.UV;m.tangents=pair.Value.Tangents;m.triangles=pair.Value.Indices;m.RecalculateBounds();uploaded.Add(pair.Key,m);yield return null;
                }
                foreach(var module in data.Modules)
                {
                    var texture=new Dictionary<string,Texture2D>();
                    foreach(var key in new[]{"albedo","normal","metallic-smoothness"})
                    {
                        var t=new Texture2D(2,2,TextureFormat.RGBA32,true,key!="albedo");asset.resources.Add(t);
                        if(!ImageConversion.LoadImage(t,data.Images[module.textures[key].file],false))throw new InvalidDataException("Spawner texture decoding failed.");
                        t.name="BA spawner "+module.kind+" "+key;t.filterMode=key=="albedo"?FilterMode.Point:FilterMode.Trilinear;t.wrapMode=TextureWrapMode.Clamp;t.anisoLevel=4;
                        // Compress shared static maps once, then release their
                        // decoded CPU pixels. No per-instance texture copies.
                        t.Compress(true);t.Apply(true,true);texture.Add(key,t);yield return null;
                    }
                    var material=asset.Material(module.kind,texture);
                    log?.Invoke("WARDING_MATERIAL_READY: profile="+module.kind+"; shader="+material.shader.name+"; supported="+material.shader.isSupported+"; source="+material.GetTag("BA_ShaderSource",false));
                    var root=new GameObject("BA spawner template | "+module.kind);root.SetActive(false);asset.resources.Add(root);
                    int structuralLayer=LayerMask.NameToLayer("static_solid");root.layer=structuralLayer>=0?structuralLayer:0;
                    var motions=new Dictionary<string,Transform>();
                    foreach(var name in module.motions.Keys){var go=new GameObject(name);go.transform.SetParent(root.transform,false);motions.Add(name,go.transform);}
                    foreach(var part in module.parts)
                    {
                        var go=new GameObject(part.name);go.transform.SetParent(part.motion=="static"?root.transform:motions[part.motion],false);
                        go.AddComponent<MeshFilter>().sharedMesh=uploaded[part.file];var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=material;
                        renderer.shadowCastingMode=part.role=="ward"?ShadowCastingMode.Off:ShadowCastingMode.On;
                        int layer=LayerMask.NameToLayer("static_solid");go.layer=layer>=0?layer:0;
                        var role=go.AddComponent<WardingSpawnerArtRole>();role.Role=part.role;
                    }
                    foreach(var body in module.colliders)
                    {
                        var go=new GameObject("Body | "+body.name);go.transform.SetParent(body.motion=="static"?root.transform:motions[body.motion],false);
                        var collider=go.AddComponent<MeshCollider>();collider.sharedMesh=uploaded[body.file];collider.convex=body.motion!="static";
                        int layer=LayerMask.NameToLayer("static_solid");go.layer=layer>=0?layer:0;
                    }
                    var buffer=new GameObject("Hidden staging floor buffer");buffer.layer=root.layer;buffer.transform.SetParent(root.transform,false);buffer.transform.localPosition=new Vector3(0,-.045f,2.34f);
                    var bufferBody=buffer.AddComponent<BoxCollider>();bufferBody.size=new Vector3(2.98f,.07f,.44f);
                    float bottom=module.boundsMin[1],top=module.boundsMax[1],height=top-bottom;
                    var stop=new GameObject("Optical corridor boundary");stop.transform.SetParent(root.transform,false);stop.transform.localPosition=new Vector3((module.boundsMin[0]+module.boundsMax[0])*.5f,(bottom+top)*.5f,2.60f);
                    var barrier=stop.AddComponent<BoxCollider>();barrier.size=new Vector3(module.boundsMax[0]-module.boundsMin[0],height,.08f);stop.layer=root.layer;
                    foreach(int side in new[]{-1,1})
                    {
                        var wall=new GameObject("Hidden staging buffer side "+side);wall.layer=root.layer;wall.transform.SetParent(root.transform,false);wall.transform.localPosition=new Vector3(side*1.53f,(bottom+top)*.5f,2.38f);
                        wall.AddComponent<BoxCollider>().size=new Vector3(.08f,height,.52f);
                    }
                    asset.modules.Add(module.kind,module);asset.templates.Add(module.kind,root);yield return null;
                }
                log?.Invoke("WARDING_ASSETS_READY: profiles="+asset.modules.Count+"; shared meshes="+uploaded.Count+"; exact saved-native motion, source-bound port mounts and baked maps; gameplay appearance awaits Jesse.");
                completed(asset);success=true;
            }
            finally {if(!success)asset.Dispose();}
        }
        Material Material(string kind,Dictionary<string,Texture2D> t)
        {
            var material=WardingSpawnerMaterial.Create(kind,t,name=>PrefabManager.Instance.GetPrefab(name),Shader.Find);resources.Add(material);
            return material;
        }
        internal WardingSpawnerArt Create(Transform parent,string kind)
        {
            if(disposed||!templates.TryGetValue(kind,out var template))throw new InvalidOperationException("Spawner source profile is unavailable.");
            var root=Object.Instantiate(template,parent,false);root.name="BA Warding Spawner | "+kind;
            var art=root.AddComponent<WardingSpawnerArt>();art.Configure(modules[kind]);instances.Add(root);root.SetActive(true);return art;
        }
        public void Dispose()
        {
            if(disposed)return;disposed=true;
            foreach(var go in instances)if(go)Object.Destroy(go);instances.Clear();
            foreach(var resource in resources.AsEnumerable().Reverse())if(resource)Object.Destroy(resource);
            resources.Clear();templates.Clear();modules.Clear();mounts.Clear();
        }
    }
}
