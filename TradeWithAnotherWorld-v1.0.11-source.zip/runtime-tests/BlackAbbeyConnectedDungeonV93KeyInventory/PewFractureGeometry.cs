using System;
using System.Collections.Generic;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    internal sealed class PewFracturePiece
    {
        internal Vector3[] Positions, Normals;
        internal Vector2[] Uv;
        internal Vector4[] Tangents;
        internal int[] Indices;
        internal Vector3 Pivot;
    }
    // Loading-time clipped source boards with new closed cut faces. No
    // break-time triangle work, rigidbodies, colliders or procedural proxies.
    internal static class PewFractureGeometry
    {
        struct V
        {
            internal Vector3 p,n; internal Vector2 uv; internal Vector4 tangent;internal float q;
            internal static V Lerp(V a,V b,float t) => new V {p=Vector3.Lerp(a.p,b.p,t),n=Vector3.Lerp(a.n,b.n,t).normalized,
                uv=Vector2.Lerp(a.uv,b.uv,t),tangent=Vector4.Lerp(a.tangent,b.tangent,t),q=Mathf.Lerp(a.q,b.q,t)};
        }
        internal static PewFracturePiece[] Build(Vector3[] p,Vector3[] n,Vector2[] uv,Vector4[] tangents,int[] indices)
        {
            if(p==null||p.Length==0||n.Length!=p.Length||uv.Length!=p.Length||tangents.Length!=p.Length||indices.Length%3!=0)
                throw new ArgumentException("Invalid exact pew board attributes.");
            var bounds=new Bounds(p[0],Vector3.zero);foreach(var point in p)bounds.Encapsulate(point);
            int axis=bounds.size.z>=bounds.size.x&&bounds.size.z>=bounds.size.y?2:bounds.size.x>=bounds.size.y?0:1;
            float length=bounds.size[axis];
            // Four complete short pieces from a long board, whole chunks from
            // compact supports. Adjacent cuts use the same oblique plane.
            int count=length>.9f?4:1;var result=new List<PewFracturePiece>();
            var normal=axis==2?new Vector3(.075f,-.045f,1).normalized:axis==0?new Vector3(1,.06f,-.04f).normalized:new Vector3(.05f,1,.03f).normalized;
            float low=float.PositiveInfinity,high=float.NegativeInfinity;
            float Measure(Vector3 point)=>Vector3.Dot(normal,point)-.012f*(Mathf.Sin(point.x*53+point.y*31)+.4f*Mathf.Sin(point.y*71-point.x*23));
            foreach(var point in p){float d=Measure(point);low=Mathf.Min(low,d);high=Mathf.Max(high,d);}
            var original=new List<V>();foreach(int index in indices)original.Add(new V{p=p[index],n=n[index],uv=uv[index],tangent=tangents[index],q=Measure(p[index])});
            float largest=0;Vector2 cutUv=uv[indices[0]];
            for(int i=0;i<indices.Length;i+=3){int a=indices[i],b=indices[i+1],c=indices[i+2];float area=Vector3.Cross(p[b]-p[a],p[c]-p[a]).sqrMagnitude;
                if(area>largest){largest=area;cutUv=(uv[a]+uv[b]+uv[c])/3f;}}
            for(int part=0;part<count;part++)
            {
                var triangles=original;
                if(part>0)triangles=Clip(triangles,normal,Mathf.Lerp(low,high,part/(float)count),false,cutUv);
                if(part<count-1)triangles=Clip(triangles,normal,Mathf.Lerp(low,high,(part+1)/(float)count),true,cutUv);
                if(triangles.Count==0)continue;
                var b=new Bounds(triangles[0].p,Vector3.zero);foreach(var v in triangles)b.Encapsulate(v.p);
                var output=new PewFracturePiece {Pivot=b.center,Positions=new Vector3[triangles.Count],Normals=new Vector3[triangles.Count],
                    Uv=new Vector2[triangles.Count],Tangents=new Vector4[triangles.Count],Indices=new int[triangles.Count]};
                for(int i=0;i<triangles.Count;i++){var v=triangles[i];output.Positions[i]=v.p-b.center;output.Normals[i]=v.n;
                    output.Uv[i]=v.uv;output.Tangents[i]=v.tangent;output.Indices[i]=i;}
                result.Add(output);
            }
            return result.ToArray();
        }
        static List<V> Clip(List<V> input,Vector3 normal,float distance,bool below,Vector2 cutUv)
        {
            var output=new List<V>();var cut=new List<V>();
            for(int i=0;i<input.Count;i+=3)
            {
                var polygon=new List<V>{input[i],input[i+1],input[i+2]};var clipped=new List<V>();
                for(int edge=0;edge<polygon.Count;edge++)
                {
                    V a=polygon[edge],b=polygon[(edge+1)%polygon.Count];float da=a.q-distance,db=b.q-distance;
                    bool insideA=below?da<=0:da>=0,insideB=below?db<=0:db>=0;
                    if(insideA)clipped.Add(a);
                    if(insideA!=insideB){var v=V.Lerp(a,b,da/(da-db));clipped.Add(v);cut.Add(v);}
                }
                for(int t=1;t+1<clipped.Count;t++)Triangle(output,clipped[0],clipped[t],clipped[t+1]);
            }
            var unique=new List<V>();foreach(var v in cut){bool exists=false;foreach(var prior in unique)if((v.p-prior.p).sqrMagnitude<1e-10f){exists=true;break;}if(!exists)unique.Add(v);}
            if(unique.Count>=3)
            {
                Vector3 centre=Vector3.zero;Vector2 centreUv=Vector2.zero;foreach(var v in unique){centre+=v.p;centreUv+=v.uv;}centre/=unique.Count;centreUv/=unique.Count;
                var outward=below?normal:-normal;var u=Vector3.Cross(outward,Mathf.Abs(outward.y)<.9f?Vector3.up:Vector3.right).normalized;var vAxis=Vector3.Cross(outward,u);
                unique.Sort((a,b)=>Mathf.Atan2(Vector3.Dot(a.p-centre,vAxis),Vector3.Dot(a.p-centre,u)).CompareTo(Mathf.Atan2(Vector3.Dot(b.p-centre,vAxis),Vector3.Dot(b.p-centre,u))));
                var capCentre=new V {p=centre,n=outward,uv=cutUv,tangent=new Vector4(u.x,u.y,u.z,1),q=distance};
                for(int i=0;i<unique.Count;i++){var a=unique[i];var b=unique[(i+1)%unique.Count];var faceNormal=Vector3.Cross(a.p-centre,b.p-centre).normalized;
                    capCentre.n=a.n=b.n=faceNormal;a.uv=b.uv=cutUv;a.tangent=b.tangent=capCentre.tangent;
                    Triangle(output,capCentre,a,b);}
            }
            return output;
        }
        static void Triangle(List<V> output,V a,V b,V c)
        {
            if(Vector3.Cross(b.p-a.p,c.p-a.p).sqrMagnitude<1e-22f)return;
            output.Add(a);output.Add(b);output.Add(c);
        }
    }
}
