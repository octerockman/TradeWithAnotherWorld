using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    /// <summary>Source-bound render-only separation of overlapping hidden backing.</summary>
    internal static class RuntimeSurfaceRepair
    {
#pragma warning disable 0649
        private sealed class RepairMap
        {
            public string meshName, meshSha256;
            public float maxDelta_m;
            public VertexRepair[] vertices;
        }
        private sealed class VertexRepair
        {
            public int index;
            public float[] expected, delta;
            public string sourceObject, reason;
        }
#pragma warning restore 0649
        internal static void Apply(string directory, string repairFile, MeshRecord mesh, Vector3[] positions, Action<string> log)
        {
            if (mesh.name != "architecture_floor") return;
            string json = File.ReadAllText(RoomPackage.FilePath(directory, repairFile));
            if (json.Length > 8 * 1024 * 1024) throw new InvalidDataException("Reveal repair map exceeds the local test budget.");
            var map = JsonConvert.DeserializeObject<RepairMap>(json, new JsonSerializerSettings {
                TypeNameHandling = TypeNameHandling.None, MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
                MissingMemberHandling = MissingMemberHandling.Ignore, MaxDepth = 32 });
            if (map == null || map.meshName != mesh.name || map.meshSha256 != mesh.sha256 ||
                map.vertices == null || map.vertices.Length == 0 || map.vertices.Length > 50000 ||
                !RoomPackage.Finite(map.maxDelta_m) || map.maxDelta_m <= 0f || map.maxDelta_m > .003001f)
                throw new InvalidDataException("Reveal repair does not match the frozen BA buffer.");
            var indices = new HashSet<int>(); float maxShift = 0f;
            foreach (var vertex in map.vertices)
            {
                if (vertex == null || vertex.index < 0 || vertex.index >= positions.Length || !indices.Add(vertex.index))
                    throw new InvalidDataException("Invalid/duplicate reveal repair vertex.");
                var expected = RoomPackage.Vector(vertex.expected, "reveal expected position");
                var delta = RoomPackage.Vector(vertex.delta, "reveal separation delta");
                if (Vector3.Distance(positions[vertex.index], expected) > .000002f || delta.magnitude > map.maxDelta_m + .000001f)
                    throw new InvalidDataException("Reveal repair source position or movement bound differs.");
                positions[vertex.index] += delta; maxShift = Mathf.Max(maxShift, delta.magnitude);
            }
            log($"BA REVEAL_REPAIR: separated {indices.Count} source-bound hidden backing vertices by at most {maxShift:F4}m; visible arch stones, original BAR1 buffers and every collider are unchanged.");
        }
    }
}
