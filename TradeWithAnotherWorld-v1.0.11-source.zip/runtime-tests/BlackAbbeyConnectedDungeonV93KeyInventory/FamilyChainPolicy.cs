using System;
using System.Collections.Generic;

namespace BlackAbbeySixRooms
{
    // A chain is a simple route through linked rooms, including turns and loop joins.
    // R03 broken/complete variants belong to the same family. A branching group
    // is permitted when no simple path within that group contains four rooms.
    internal static class FamilyChainPolicy
    {
        internal const int MaximumRoomsInChain = 3;

        static string Family(DungeonPlacement room) => NaturalDungeonRoster.Family(room.Spec.SourceId);

        static List<int>[] Neighbours(List<DungeonPlacement> rooms, List<DungeonLink> links, int extraA = -1, int extraB = -1)
        {
            var neighbours = new List<int>[rooms.Count];
            for (int i = 0; i < rooms.Count; i++) neighbours[i] = new List<int>();
            foreach (var edge in links)
                if (Family(rooms[edge.A]) == Family(rooms[edge.B]))
                { neighbours[edge.A].Add(edge.B); neighbours[edge.B].Add(edge.A); }
            if (extraA >= 0) { neighbours[extraA].Add(extraB); neighbours[extraB].Add(extraA); }
            return neighbours;
        }

        static bool ReachesLength(List<int>[] neighbours, int node, int wanted, List<int> path)
        {
            if (path.Count >= wanted) return true;
            foreach (int next in neighbours[node])
            {
                if (path.Contains(next)) continue;
                path.Add(next);
                bool found = ReachesLength(neighbours, next, wanted, path);
                path.RemoveAt(path.Count - 1);
                if (found) return true;
            }
            return false;
        }

        internal static bool AllowsNewRoom(List<DungeonPlacement> rooms, List<DungeonLink> links, int parent, string nextSource)
        {
            if (Family(rooms[parent]) != NaturalDungeonRoster.Family(nextSource)) return true;
            // Attaching a new leaf adds one node to every same-family route from parent.
            return !ReachesLength(Neighbours(rooms, links), parent, MaximumRoomsInChain, new List<int> { parent });
        }

        internal static bool AllowsJoin(List<DungeonPlacement> rooms, List<DungeonLink> links, int a, int b)
        {
            if (Family(rooms[a]) != Family(rooms[b])) return true;
            var neighbours = Neighbours(rooms, links, a, b);
            for (int i = 0; i < rooms.Count; i++)
                if (Family(rooms[i]) == Family(rooms[a]) && ReachesLength(neighbours, i, MaximumRoomsInChain + 1, new List<int> { i })) return false;
            return true;
        }

        internal static bool IsValid(List<DungeonPlacement> rooms, List<DungeonLink> links)
        {
            var neighbours = Neighbours(rooms, links);
            for (int i = 0; i < rooms.Count; i++)
                if (ReachesLength(neighbours, i, MaximumRoomsInChain + 1, new List<int> { i })) return false;
            return true;
        }
    }
}
