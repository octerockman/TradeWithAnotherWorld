using System;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // The authored guard marker is a fixed exception to the ordinary R08
    // no-enemy policy. Physical floor/capsule/port-route checks still apply.
    internal static class UnrecordedDeadKnightPolicy
    {
        internal const string Source = "R08", Asset = "R08-UD";
        internal const string Prefab = "BA_ReliquaryKnight", Provider = "studio.otherworld.reliquaryknight";
        internal const double X = 0, Z = 13.5;
        internal const float Yaw = 180;
        internal static bool Selected(string source, string asset) => source == Source && asset == Asset;
        internal static bool Selected(AbbeyMonkSpawnPolicy.Room room) => room != null && Selected(room.SourceRoomId, room.AssetId);
        internal static string AssetIdentity(string source, string asset) => string.IsNullOrEmpty(asset) ? source : asset;
        internal static string SavedAsset(string source, string asset) => AssetIdentity(source, asset) == source ? null : asset;
        internal static bool AllowedAsset(string source, string asset)
            => string.IsNullOrEmpty(asset) || asset == source ||
               new[] { "R02", "R06", "R08", "R09" }.Contains(source) && asset == source + "-UD";
        internal static bool ValidPlan(EncounterRoomSnapshot plan)
        {
            if (!AllowedAsset(plan.sourceRoomId, plan.assetId)) return false;
            if (Selected(plan.sourceRoomId, plan.assetId))
                return plan.prefabs.Length == 1 && plan.prefabs[0] == Prefab && plan.yaw == Yaw;
            // No random mixture or ordinary room may acquire this guard.
            return !plan.prefabs.Contains(Prefab) &&
                !((plan.depth < 2 || plan.sourceRoomId == "R08" || plan.sourceRoomId == "R09"||R09SplitIdentity.IsPiece(plan.sourceRoomId)) && plan.prefabs.Length > 0) &&
                !(plan.sourceRoomId != "R01" && plan.sourceRoomId != "R04" && plan.prefabs.Contains(AbbeyMonkSpawnPolicy.Thrall)) &&
                plan.prefabs.Count(n => n == AbbeyMonkSpawnPolicy.Censer) <= 1 &&
                plan.prefabs.Count(n => n == AbbeyMonkSpawnPolicy.Thrall) <= 1;
        }
    }
}
