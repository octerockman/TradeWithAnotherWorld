namespace BlackAbbeySixRooms
{
    // Only the reviewed R02 pocket receives a larger interaction target. Its
    // furniture, moving leaf and concealed paper remain the actual source art.
    internal static class UnrecordedDeadCupboardPolicy
    {
        internal const string SourceSha256="27c48eca7d56e6c31e3583ae33ce9e5cefbb84178d7005359e3eeef6343a814c";
        internal const string ManifestSha256="dd175d2701bfb0bcfa9cdfa0510d5845ab1fc1ca41f12d55f499ea2359fc0c5d";
        internal const string DynamicsSha256="14b7626b499bb1a35aebb76294056054f6f3d307d42df0efc4c9a020a27901b7";
        internal const string RebuiltSourceSha256="f357143c63581438e7cdbdc8f323fa2fe04c426433ab0f2aa8ce980c1e24961d";
        internal const string RebuiltManifestSha256="5dc3e485c9b0a77198d422b82a4dd080464c66d00c4bbfd86ba8ba35ad3ea86c";
        internal const string RebuiltDynamicsSha256="d82851d2804acd05dc610b4464636ca675aa1e1b6481f1d802bdbbc8d7e1b3be";
        internal static bool Matches(string roomId,string source,string recordSource,string declaredManifest,
            string actualManifest,string actualDynamics,string anchorId,string kind)
            =>roomId=="R02"&&anchorId=="matthien-panel"&&kind=="panel"&&
                (source==SourceSha256&&recordSource==SourceSha256&&declaredManifest==ManifestSha256&&actualManifest==ManifestSha256&&actualDynamics==DynamicsSha256||
                 source==RebuiltSourceSha256&&recordSource==RebuiltSourceSha256&&declaredManifest==RebuiltManifestSha256&&actualManifest==RebuiltManifestSha256&&actualDynamics==RebuiltDynamicsSha256);
        // Fresh arrays prevent a caller from changing the shared definition.
        internal static float[] Position=>new[]{-3.2575f,1.18f,3.39f};
        internal static float[] Size=>new[]{.011f,.58f,.286f};
        // Rebuilt cabinet mouth X=-3.25; the target's back is2.5mm in front
        // of that face, with inset edges. It exists only while fully open and
        // disappears with panel removal, before the papers become selectable.
        internal static float[] PositionFor(string source)=>source==RebuiltSourceSha256?new[]{-3.23f,1.18f,3.39f}:Position;
        internal static float[] SizeFor(string source)=>source==RebuiltSourceSha256?new[]{.035f,.54f,.266f}:Size;
        internal static bool Available(bool cabinetOpen,bool fullyOpen,bool panelRemoved)
            =>cabinetOpen&&fullyOpen&&!panelRemoved;
    }
}
