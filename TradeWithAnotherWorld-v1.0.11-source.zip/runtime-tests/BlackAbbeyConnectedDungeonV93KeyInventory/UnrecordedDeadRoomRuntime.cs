using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Linq;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    internal sealed class UnrecordedDeadRoomRuntime:MonoBehaviour
    {
        private LoadedRoom room;
        private UnrecordedDeadAssets assets;
        private UnrecordedDeadState state;
        private Func<Player,bool> canUse;
        private Func<UnrecordedDeadSnapshot,bool> commit;
        private Action<Player> pickup,unlock;
        private Action changed;
        private Action<string> log;
        private readonly Dictionary<string,GameObject> kits=new Dictionary<string,GameObject>();
        private readonly List<Tuple<GameObject,Func<bool>>> handles=new List<Tuple<GameObject,Func<bool>>>();
        private UnrecordedDeadCabinetMotion cabinet;
        private FalseVowsCabinetAudio audio;
        private R09RoomRuntime boss;
        private UnrecordedDeadWallRubble rubble;
        private bool wasUnlocked;
        private Transform lowerWheel,upperWheel;
        private Vector3 wheelAxis;
        private float wheelPhase=-1;
        internal static void Attach(LoadedRoom room,UnrecordedDeadAssets assets,UnrecordedDeadState state,Func<Player,bool> canUse,
            Func<UnrecordedDeadSnapshot,bool> commit,Action<Player> pickup,Action<Player> unlock,Action changed,Action<string> log)
        {
            if(room.Root.GetComponent<UnrecordedDeadRoomRuntime>())return;
            var controller=room.Root.AddComponent<UnrecordedDeadRoomRuntime>();
            controller.room=room;controller.assets=assets;controller.state=state;controller.canUse=canUse;controller.commit=commit;
            controller.pickup=pickup;controller.unlock=unlock;controller.changed=changed;controller.log=log;controller.Build();controller.Refresh();
        }
        private GameObject Role(string role)=>assets.Role(role) is string id&&kits.TryGetValue(id,out var obj)?obj:null;
        private void Build()
        {
            foreach(var kit in assets.Manifest.kits)
                if(kit.kind!="item"&&kit.kind!="ref"&&kit.id!=assets.Role("keyItem"))kits.Add(kit.id,assets.CreateKit(kit.id,room.Root.transform));
            audio=gameObject.AddComponent<FalseVowsCabinetAudio>();audio.Configure(log);
            if(Role("cabinetDoor"))
            {
                var settings=assets.Manifest.cabinet??throw new System.IO.InvalidDataException("Cabinet pivot contract is missing.");
                cabinet=Role("cabinetDoor").AddComponent<UnrecordedDeadCabinetMotion>();
                cabinet.Configure(RoomPackage.Vector(settings["axis"].ToObject<float[]>(),"cabinet axis"),settings["openDegrees"].Value<float>(),()=>state.CabinetOpen,audio);
                var surfaces=Role("cabinetDoor").GetComponentsInChildren<Collider>(true);
                if(surfaces.Length==0)throw new System.IO.InvalidDataException("The cabinet door requires its actual moving collider.");
                foreach(var surface in surfaces)
                    Bind(surface.gameObject,surface,"Writing desk cabinet",()=>state.CabinetOpen?"Close":"Open",p=>{
                        if(!cabinet.CanToggle(p)){p.Message(MessageHud.MessageType.Center,"Stand clear of the cabinet door.");return;}
                        Apply(state.ToggleCabinet(room.InstanceId,commit),p);
                    });
            }
            if(Role("wallSealed"))
            {
                var wall=Role("wallSealed");
                if(wall.GetComponentsInChildren<Collider>(true).Length==0)throw new System.IO.InvalidDataException("Breakable masonry has no source collider.");
                // Native weapon hits resolve an attached Rigidbody's owner.
                // Keep every exact child collider on this stationary owner.
                var body=wall.AddComponent<Rigidbody>();body.isKinematic=true;body.useGravity=false;
                rubble=gameObject.AddComponent<UnrecordedDeadWallRubble>();
                rubble.Configure(room,assets.WallStoneParts(),Role("wallBroken"),state.WallBroken,log);
                wall.AddComponent<UnrecordedDeadBreakableWall>().Configure(
                    ()=>canUse(Player.m_localPlayer)&&state.BreakWall(room.InstanceId,commit),hit=>{
                        var point=VisualCenter(wall);
                        try{rubble.Emit(hit);}finally{changed();}
                        PlayStoneBreak(point);
                    },log);
            }
            boss=R09RoomRuntime.ForHall(room);
            if(room.Manifest.roomId==R09SplitIdentity.UnrecordedDeadHall&&!boss)
                throw new System.IO.InvalidDataException("The selected chain hall has no assembled shared boss-door service.");
            if(boss)
            {
                boss.ConfigureUnrecordedDeadGate(()=>state.BossUnlocked);wasUnlocked=state.BossUnlocked;
                var mechanism=assets.Manifest.@operator;
                if(mechanism!=null)
                {
                    wheelAxis=RoomPackage.Vector(mechanism["axis"].ToObject<float[]>(),"wheel axis").normalized;
                    lowerWheel=Wheel("lowerWheel",mechanism["lowerWheelPivot"].ToObject<float[]>());
                    upperWheel=Wheel("upperWheel",mechanism["upperWheelPivot"].ToObject<float[]>());
                }
            }
            foreach(var anchor in assets.Manifest.anchors)
            {
                // The cabinet label follows the real moving door, never an
                // invisible box left at its old closed position.
                if(anchor.kind=="cabinet"&&cabinet)continue;
                string label=anchor.label,verb="Read";Action<Player> use;Func<bool> visible=()=>true;
                switch(anchor.kind)
                {
                    case "panel":
                        label="Loose panel";verb="Remove";
                        visible=()=>UnrecordedDeadCupboardPolicy.Available(state.CabinetOpen,cabinet&&cabinet.FullyOpen,state.PanelRemoved);
                        use=p=>{if(canUse(p)&&visible())Apply(state.RemovePanel(room.InstanceId,commit),p);};break;
                    case "key":case "pickup":
                        label="Old Order Key";verb="Take";visible=()=>!state.KeyClaimed;use=pickup;break;
                    case "lock":
                        label="Old Order Padlock";verb="Unlock";visible=()=>!state.BossUnlocked;use=unlock;break;
                    case "operator":
                        label="Chain mechanism";verb="Pull chain";use=p=>{
                            if(!state.BossUnlocked){p.Message(MessageHud.MessageType.Center,"The padlock holds the chain. An old binding seals the doors.");return;}
                            boss?.OperateUnrecordedDeadChain(p);
                        };break;
                    case "document":case "journal":case "reading":
                        var doc=anchor.documentGroup??anchor.documentId;
                        if(string.IsNullOrEmpty(doc))throw new System.IO.InvalidDataException("A reading anchor has no approved document.");
                        label=label??DocumentLabel(doc);use=p=>UnrecordedDeadDocuments.Open(p,doc);
                        if(room.Manifest.roomId=="R02")visible=()=>state.PanelRemoved&&state.CabinetOpen&&cabinet&&cabinet.FullyOpen;
                        break;
                    default:continue;
                }
                var host=new GameObject("Unrecorded Dead interaction | "+anchor.id);host.layer=LayerMask.NameToLayer("piece");host.transform.SetParent(room.Root.transform,false);
                var position=anchor.position;var extent=anchor.size;
                if(anchor.kind=="panel"&&room.Manifest.roomId=="R02"&&
                    UnrecordedDeadCupboardPolicy.Matches(room.Manifest.roomId,room.Manifest.sourceSha256,room.Record?.sourceSha256,room.Record?.manifestSha256,
                        CatalogReader.HashFile(RoomPackage.FilePath(room.PackageDirectory,"manifest.json")),
                        CatalogReader.HashFile(RoomPackage.FilePath(room.PackageDirectory,"unrecorded-dead.json")),anchor.id,anchor.kind))
                {position=UnrecordedDeadCupboardPolicy.PositionFor(room.Manifest.sourceSha256);extent=UnrecordedDeadCupboardPolicy.SizeFor(room.Manifest.sourceSha256);}
                host.transform.localPosition=RoomPackage.Vector(position,"interaction position");
                var size=RoomPackage.Vector(extent,"interaction size");if(size.x<=0||size.y<=0||size.z<=0||size.magnitude>3)throw new System.IO.InvalidDataException("Invalid interaction extent.");
                var shape=host.AddComponent<BoxCollider>();shape.size=size;
                if(anchor.rotation!=null)new FalseVowsAssetPose{rotation=anchor.rotation,position=position}.Apply(host.transform);
                Bind(host,shape,label,()=>verb,use);
                if(anchor.kind=="panel")host.GetComponent<FalseVowsWorldHandle>().CanUse=p=>canUse(p)&&visible();
                handles.Add(Tuple.Create(host,visible));
            }
            assets.ApplyPaperFeedback(room,kits);
        }
        private static string DocumentLabel(string id)
        {
            if(id.StartsWith("01"))return "Search order";
            if(id.StartsWith("02"))return "Oswin's last journal";
            if(id.StartsWith("03"))return "Oswin's earlier journal";
            if(id.StartsWith("04"))return "A shared prayer";
            if(id.StartsWith("05"))return "Matthien's papers";
            if(id.StartsWith("06"))return "Edrin's folded pages";
            return "Journal";
        }
        private void Bind(GameObject host,Collider shape,string label,Func<string> verb,Action<Player> use)
        {
            var handle=host.AddComponent<FalseVowsWorldHandle>();handle.Label=label;handle.Extra=verb;handle.Shape=shape;handle.CanUse=canUse;handle.Use=use;
        }
        private void Apply(bool success,Player player)
        {
            if(!success)player.Message(MessageHud.MessageType.Center,"Your progress could not be recorded. Try again shortly.");
            changed();
        }
        internal void Refresh()
        {
            Set("wallSealed",!state.WallBroken);Set("wallBroken",state.WallBroken&&!(rubble&&rubble.HasPresentation));
            Set("panel",!state.PanelRemoved);Set("panelRemoved",state.PanelRemoved);
            Set("keyWorld",!state.KeyClaimed);Set("lockClosed",!state.BossUnlocked);Set("lockOpen",state.BossUnlocked);
            if(boss&&state.BossUnlocked&&!wasUnlocked){wasUnlocked=true;audio.PlayUnlock(Role("lockOpen")?VisualCenter(Role("lockOpen")):transform.position);}
            foreach(var handle in handles)if(handle.Item1)handle.Item1.SetActive(handle.Item2());
        }
        private void Set(string role,bool enabled){var obj=Role(role);if(obj&&obj.activeSelf!=enabled)obj.SetActive(enabled);}
        private static Vector3 VisualCenter(GameObject obj)
        {
            var renderers=obj.GetComponentsInChildren<Renderer>(true);if(renderers.Length==0)return obj.transform.position;
            var bounds=renderers[0].bounds;foreach(var renderer in renderers.Skip(1))bounds.Encapsulate(renderer.bounds);return bounds.center;
        }
        private Transform Wheel(string role,float[] point)
        {
            var wheel=Role(role);if(!wheel)return null;
            var pivot=new GameObject("Unrecorded Dead | wheel pivot | "+role).transform;pivot.SetParent(room.Root.transform,false);
            pivot.localPosition=RoomPackage.Vector(point,"wheel pivot");wheel.transform.SetParent(pivot,true);return pivot;
        }
        private void Update()
        {
            if(cabinet)foreach(var handle in handles)if(handle.Item1){bool visible=handle.Item2();if(handle.Item1.activeSelf!=visible)handle.Item1.SetActive(visible);}
            if(boss&&Mathf.Abs(wheelPhase-boss.DoorProgress)>.00001f)
            {wheelPhase=boss.DoorProgress;var rotation=Quaternion.AngleAxis(wheelPhase*180,wheelAxis);if(lowerWheel)lowerWheel.localRotation=rotation;if(upperWheel)upperWheel.localRotation=rotation;}
        }
        private void PlayStoneBreak(Vector3 point)
        {
            // Optional native foley does not own the quest transition. Never
            // instantiate an effect carrying a network view for local debris.
            var prefab=Jotunn.Managers.PrefabManager.Instance.GetPrefab("sfx_rock_destroyed");
            if(prefab&&!prefab.GetComponentInChildren<ZNetView>(true)){var effect=Object.Instantiate(prefab,point,Quaternion.identity);Object.Destroy(effect,8);}
        }
    }
    public sealed class UnrecordedDeadBreakableWall:MonoBehaviour,IDestructible
    {
        private Func<bool> commit;
        private Action<HitData> broken;
        private Action<string> log;
        private bool applied;
        internal void Configure(Func<bool> commit,Action<HitData> broken,Action<string> log){this.commit=commit;this.broken=broken;this.log=log;}
        public DestructibleType GetDestructibleType()=>DestructibleType.Default;
        public void Damage(HitData hit)
        {
            if(applied||hit==null||!AbbeyBreakablePew.PositiveFiniteDamage(hit.GetTotalDamage())||commit==null||!isActiveAndEnabled)return;
            if(!commit())return;
            applied=true;
            try{broken(hit);}catch(Exception ex){log?.Invoke("UNRECORDED_DEAD_RUBBLE_PRESENTATION_FAILED: "+ex.Message+"; saved opening retained.");}
            log?.Invoke("UNRECORDED_DEAD_WALL_BROKEN: native attack; source jagged edges retained; durable before presentation.");
        }
    }
    internal sealed class UnrecordedDeadCabinetMotion:MonoBehaviour
    {
        private Func<bool> desired;
        private Vector3 axis;
        private Quaternion rest;
        private Bounds bounds;
        private float angle,openDegrees;
        private bool moving;
        private FalseVowsCabinetAudio audio;
        internal bool FullyOpen=>desired()!=false&&Mathf.Abs(angle-openDegrees)<.1f;
        internal void Configure(Vector3 axis,float degrees,Func<bool> desired,FalseVowsCabinetAudio audio)
        {
            if(axis.sqrMagnitude<.9f||degrees<=0||degrees>110)throw new System.IO.InvalidDataException("Invalid cabinet movement contract.");
            this.axis=axis.normalized;openDegrees=degrees;this.desired=desired;this.audio=audio;rest=transform.localRotation;
            bool first=true;foreach(var filter in GetComponentsInChildren<MeshFilter>(true))
                foreach(var point in filter.sharedMesh.vertices)
                {var local=transform.InverseTransformPoint(filter.transform.TransformPoint(point));if(first){bounds=new Bounds(local,Vector3.zero);first=false;}else bounds.Encapsulate(local);}
            if(first)throw new System.IO.InvalidDataException("Cabinet has no source geometry.");
            var body=gameObject.AddComponent<Rigidbody>();body.isKinematic=true;body.useGravity=false;
            angle=desired()?openDegrees:0;transform.localRotation=rest*Quaternion.AngleAxis(angle,this.axis);
        }
        internal bool CanToggle(Player p)=>!Blocked(p,desired()?0:openDegrees);
        private bool Blocked(Player player,float proposed)
        {
            for(int i=0;i<=9;i++)
            {
                var rotation=transform.parent.rotation*rest*Quaternion.AngleAxis(Mathf.Lerp(angle,proposed,i/9f),axis);
                var origin=transform.parent.TransformPoint(transform.localPosition);
                foreach(float height in new[]{.25f,.65f,1.1f})
                {
                    var q=Quaternion.Inverse(rotation)*(player.transform.position+Vector3.up*height-origin)-bounds.center;
                    var d=new Vector3(Mathf.Max(0,Mathf.Abs(q.x)-bounds.extents.x),Mathf.Max(0,Mathf.Abs(q.y)-bounds.extents.y),Mathf.Max(0,Mathf.Abs(q.z)-bounds.extents.z));
                    if(d.sqrMagnitude<.09f)return true;
                }
            }
            return false;
        }
        private void FixedUpdate()
        {
            float target=desired()?openDegrees:0;
            if(Mathf.Abs(angle-target)<.01f){moving=false;return;}
            float next=Mathf.MoveTowards(angle,target,100*Time.fixedDeltaTime);
            if(Player.m_localPlayer&&Blocked(Player.m_localPlayer,next))return;
            if(!moving){audio.PlayDoor(transform.position,target!=0);moving=true;}
            angle=next;transform.localRotation=rest*Quaternion.AngleAxis(angle,axis);
        }
    }
}
