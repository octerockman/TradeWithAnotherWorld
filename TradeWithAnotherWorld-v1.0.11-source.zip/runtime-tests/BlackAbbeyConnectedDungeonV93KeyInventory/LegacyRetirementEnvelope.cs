using System;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using UnityEngine;
namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        private float[][] legacyRetirementVolumes;
        private void PrepareLegacyRetirementEnvelope()
        {
            EnsurePersistentRunWorld();
            string root=PlanningDataPath(true);
            if(!CatalogRetirementPolicy.NeedsEnvelope(persistentRun,CatalogReader.HashFile(Path.Combine(root,"catalog.json"))))return;
            var contract=KitArchitectureProfile.Load(root);
            if(contract.legacyRetirement==null)throw new InvalidDataException("This old Abbey needs its checked retirement envelope before safe regeneration; no save, grave or return point was changed.");
            string path=RoomPackage.FilePath(root,contract.legacyRetirement.path);
            if(new FileInfo(path).Length>1024*1024||CatalogReader.HashFile(path)!=contract.legacyRetirement.sha256)throw new InvalidDataException("Legacy retirement metadata changed.");
            var data=JsonConvert.DeserializeObject<LegacyRetirementFile>(File.ReadAllText(path),ManifestReader.Settings());
            var row=CatalogRetirementPolicy.RequireExact(data,persistentRun);
            legacyRetirementVolumes=row.volumes.Select(v=>(float[])v.Clone()).ToArray();retirementOrigin=RoomPackage.Vector(row.origin,"legacy retirement origin");
        }
        private bool InsideLegacyRetirement(Vector3 point)
        {
            if(legacyRetirementVolumes==null)return false;
            Vector3 p=point-retirementOrigin;
            return legacyRetirementVolumes.Any(v=>p.x>=v[0]-.15f&&p.x<=v[2]+.15f&&p.z>=v[1]-.15f&&p.z<=v[3]+.15f&&p.y>=v[4]-.5f&&p.y<=v[5]+.5f);
        }
    }
}
