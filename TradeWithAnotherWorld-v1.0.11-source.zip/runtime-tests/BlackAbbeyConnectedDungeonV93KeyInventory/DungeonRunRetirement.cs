using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        void RequestPersistentReset(int? nextSeed,bool removeDoor=false,string forcedBossUnlockRoute=null)
        {
            if(busy||!LocalPlayer(out var player))return;
            if(!removeDoor)
            {
                // Validate the exact new seed, route, source manifests and
                // masonry modules before returning players or retiring a run.
                // Fresh planning reads no old quest bindings and saves nothing.
                try
                {
                    if(!KitArchitectureProfile.IsKitRoot(PlanningDataPath(true))&&(catalog.connector==null||catalog.endCap==null))throw new InvalidDataException("The connected passage/branch assets are missing.");
                    if(!Jotunn.Managers.PrefabManager.Instance.GetPrefab("Candle_resin"))throw new InvalidOperationException("Wait for the vanilla candle prefabs to load.");
                    AbbeyMonkSpawns.CheckReady();
                    nextSeed=nextSeed??Guid.NewGuid().GetHashCode();
                    var prepared=MakeDungeon(nextSeed.Value,false,forcedBossUnlockRoute,true);
                    PrepareLegacyRetirementEnvelope();
                    Logger.LogInfo("DUNGEON_REGENERATE_PREFLIGHT: seed="+prepared.Seed+"; path="+prepared.BossUnlockRoute+"; current run unchanged; safe retirement follows.");
                }
                catch(Exception ex){Print("New dungeon could not be prepared; current dungeon retained: "+ex.Message);return;}
            }
            StartCoroutine(ResetAfterSafeReturn(player,nextSeed,removeDoor,forcedBossUnlockRoute));
        }
        IEnumerator ResetAfterSafeReturn(Player player,int? nextSeed,bool removeDoor,string forcedBossUnlockRoute)
        {
            if(player.transform.position.y>HighAltitudeGuard)
            {
                if(!Matches(player)){Print("No matching safe return point. Current dungeon remains intact.");yield break;}
                yield return ReturnRoutine(player,false,true);
                if(!player||player.transform.position.y>HighAltitudeGuard)yield break;
            }
            try
            {
                EnsurePersistentRunWorld();
                retirementEnvelope=null;
                if(persistentRun!=null&&dungeonPlan==null)
                {
                    if(CatalogRetirementPolicy.NeedsEnvelope(persistentRun,CatalogReader.HashFile(Path.Combine(PlanningDataPath(true),"catalog.json"))))PrepareLegacyRetirementEnvelope();
                    else{PersistentLayoutSeed();var plan=MakeDungeon(persistentRun.seed,false);VerifyPersistentPlan(plan);retirementEnvelope=plan;retirementOrigin=RoomPackage.Vector(persistentRun.origin,"retained dungeon origin");}
                }
            }
            catch(Exception ex){Print("Saved run reset refused; record retained: "+ex.Message);yield break;}
            if(Player.GetAllPlayers().Any(p=>p&&RunContains(p.transform.position)))
            {Print("Everyone must leave the dungeon before an explicit reset/remove. No rooms or graves were changed.");yield break;}
            yield return RetirePersistentDungeon(true,nextSeed,removeDoor,forcedBossUnlockRoute);
        }
        IEnumerator RetirePersistentDungeon(bool forced,int? nextSeed,bool removeDoor=false,string forcedBossUnlockRoute=null)
        {
            if(busy||retiringPersistentRun)yield break;
            if(pendingFalseVowsExitRun!=null&&pendingFalseVowsExitRun==persistentRun?.runId)
            {Print("The Abbey is still returning its key and papers. The current dungeon is retained until that finishes.");yield break;}
            var network=ZNet.instance;var manager=ZDOMan.instance;var scene=ZNetScene.instance;
            string world;
            try {world=WorldKey();}
            catch{yield break;}
            if(!network||!network.IsServer()||manager==null||!scene)yield break;
            if(Player.GetAllPlayers().Any(p=>p&&RunContains(p.transform.position)))yield break;
            if(!forced&&!DungeonExitPolicy.CanRetire(persistentRun,0))yield break;
            if(!SavePersistentRun(true)){Print("Dungeon checkpoint failed; retirement was cancelled.");yield break;}
            busy=retiringPersistentRun=true;
            bool success=false;
            try
            {
                var warding=PrepareWardingRetirement();
                while(true)
                {
                    bool more;
                    try {more=warding.MoveNext();}
                    catch(Exception ex){Print("Dungeon retained because spawner cleanup could not be reconciled: "+ex.Message);yield break;}
                    if(!more)break;
                    yield return warding.Current;
                }
                var result=new GraveExitResult();
                yield return EjectDungeonGraves(network,manager,scene,world,result);
                if(!result.Success){Print("Dungeon retained: "+result.Failure);yield break;}
                if(!SameRetirementWorld(network,manager,world)||Player.GetAllPlayers().Any(p=>p&&RunContains(p.transform.position)))yield break;
                if(pendingFalseVowsExitRun!=null&&pendingFalseVowsExitRun==persistentRun?.runId)yield break;
                if(!ResetWorldPortalLayout()){Print("Dungeon retained because the outside door could not save its new-run state.");yield break;}
                try
                {
                    if(persistentRun!=null)
                    {
                        RetireWardingSpawners();
                        DisposeMonkRun(true);
                        RetireSavedMonkState(persistentRun.actors,persistentRun.runId,persistentRun.seed);
                        DungeonActorResidency.Retire(world,persistentRun.runId,s=>Logger.LogInfo(s));
                        RunStore.Clear(world,persistentRun.runId,persistentRun.revision);
                    }
                    else {RetireWardingSpawners();DisposeMonkRun(true);}
                }
                catch(Exception ex){Print("Dungeon retirement stopped; saved run/floors retained: "+ex.Message);yield break;}
                persistentRunBound=false;persistentRun=null;runCheckpointDirty=false;runWriteFailure=null;
                ClearReturn();if(forced)AbbeyLoadDiagnostics.NoteRegeneration(rooms.Values);DisposeRooms();retirementEnvelope=null;legacyRetirementVolumes=null;
                if(removeDoor)RemoveWorldPortal();
                success=true;
                Logger.LogInfo("ABBEY_PERSISTENT_RUN_RETIRED: explicitReset="+forced+"; all players outside; graves moved="+result.Moved+"; native grave inventories untouched.");
                Print(forced?"Saved dungeon cleared safely; its tombstones are outside the Mysterious Door.":"The abbot is defeated and everyone left properly. Tombstones were placed outside the Mysterious Door; the next entry creates a new dungeon.");
            }
            finally {retiringPersistentRun=false;busy=false;}
            if(success&&forced&&!removeDoor)StartDungeon(nextSeed,false,false,forcedBossUnlockRoute);
        }
        bool SameRetirementWorld(ZNet network,ZDOMan manager,string world)
        {
            try{return network&&ReferenceEquals(network,ZNet.instance)&&network.IsServer()&&ReferenceEquals(manager,ZDOMan.instance)&&WorldKey()==world;}
            catch{return false;}
        }
        sealed class GraveExitResult{internal bool Success;internal string Failure;internal int Moved;}
        GraveEjectionJournal graveExitJournal;
        GraveEjectionJournal GraveJournal=>graveExitJournal??(graveExitJournal=new GraveEjectionJournal(Path.Combine(
            PluginStoragePaths.WorldDoorDirectory(AssemblyPath,BepInEx.Paths.PluginPath),"..","grave-exits")));
        IEnumerator EjectDungeonGraves(ZNet network,ZDOMan manager,ZNetScene scene,string world,GraveExitResult result)
        {
            var player=Player.m_localPlayer;
            if(!player||!player.m_tombstone){result.Failure="Native tombstone identity is unavailable.";yield break;}
            string prefab=player.m_tombstone.name;int hash=prefab.GetStableHashCode(),sector=0,slices=0;
            var batch=new List<ZDO>();var graves=new HashSet<ZDOID>();bool done=false;
            while(!done)
            {
                if(!SameRetirementWorld(network,manager,world)){result.Failure="World changed during grave scan.";yield break;}
                if(++slices>4096){result.Failure="Grave scan did not complete; rooms retained.";yield break;}
                try
                {
                    done=manager.GetAllZDOsWithPrefabIterative(prefab,batch,ref sector);
                    foreach(var zdo in batch)
                        if(zdo!=null&&zdo.IsValid()&&zdo.GetPrefab()==hash&&(RunContains(zdo.GetPosition())||RunContains(zdo.GetVec3(ZDOVars.s_spawnPoint,zdo.GetPosition()))))graves.Add(zdo.m_uid);
                    batch.Clear();
                }
                catch(Exception ex){result.Failure="Native grave scan failed: "+ex.Message;yield break;}
                yield return null;
            }
            if(graves.Count==0){result.Success=true;yield break;}
            WorldDoorState portal;
            try {portal=savedWorldDoor??DoorStore.Load(world);}
            catch(Exception ex){result.Failure="Outside door record is unavailable: "+ex.Message;yield break;}
            if(portal==null){result.Failure="Spawn a Mysterious Door outside before clearing a dungeon with tombstones.";yield break;}
            List<GraveExitRecord> journal;
            try {journal=GraveJournal.Load(world);}
            catch(Exception ex){result.Failure="Grave journal could not be read: "+ex.Message;yield break;}
            var reserved=journal.Select(r=>RoomPackage.Vector(r.destination,"reserved grave exit")).ToList();
            int index=0;
            foreach(var id in graves)
            {
                if(!SameRetirementWorld(network,manager,world)){result.Failure="World changed during grave transfer.";yield break;}
                var zdo=manager.GetZDO(id);if(zdo==null||!zdo.IsValid())continue;
                var existing=journal.SingleOrDefault(r=>r.userId==id.UserID&&r.objectId==id.ID);
                Vector3 target;
                if(existing!=null)
                {
                    if(existing.prefabHash!=hash||existing.ownerId!=zdo.GetLong(ZDOVars.s_owner,0)||
                        !GraveEjectionPolicy.AtOriginal(existing,Array(zdo.GetVec3(ZDOVars.s_spawnPoint,zdo.GetPosition()))))
                    {result.Failure="A journalled grave identity changed; existing records retained.";yield break;}
                    target=RoomPackage.Vector(existing.destination,"journalled grave exit");
                }
                else if(!TryGraveExitPoint(portal,index++,reserved,out target)){result.Failure="Clear supported ground is unavailable outside the door.";yield break;}
                var record=existing??new GraveExitRecord {userId=id.UserID,objectId=id.ID,prefabHash=hash,ownerId=zdo.GetLong(ZDOVars.s_owner,0),
                    original=Array(zdo.GetVec3(ZDOVars.s_spawnPoint,zdo.GetPosition())),destination=Array(target)};
                try {GraveJournal.Add(world,record);}
                catch(Exception ex){result.Failure="Grave exit could not be recorded durably: "+ex.Message;yield break;}
                if(!MoveExistingGrave(network,manager,scene,world,zdo,target)){result.Failure="A native grave could not be moved; dungeon retained.";yield break;}
                reserved.Add(target);
                result.Moved++;yield return null;
            }
            result.Success=true;
        }
        bool TryGraveExitPoint(WorldDoorState door,int index,List<Vector3> reserved,out Vector3 point)
        {
            point=default;if(!ZoneSystem.instance)return false;
            var origin=RoomPackage.Vector(door.position,"grave exit origin");var rotation=Rotation(door.rotation);
            for(int attempt=0;attempt<32;attempt++)
            {
                int slot=index+attempt;float side=(slot%7-3)*1.05f;float distance=2.2f+(slot/7)*1.15f;
                var sample=origin+rotation*new Vector3(side,0,-distance);
                if(!ZoneSystem.instance.GetGroundHeight(sample,out float h)||!RoomPackage.Finite(h))continue;
                sample.y=h+.12f;
                if(reserved.Any(p=>(p-sample).sqrMagnitude<.8f*.8f))continue;
                if(Physics.CheckCapsule(sample+Vector3.up*.35f,sample+Vector3.up*1.05f,.28f,LayerMask.GetMask("piece","static_solid","Default"),QueryTriggerInteraction.Ignore))continue;
                point=sample;return true;
            }
            return false;
        }
        bool MoveExistingGrave(ZNet network,ZDOMan manager,ZNetScene scene,string world,ZDO grave,Vector3 target)
        {
            try
            {
                if(!SameRetirementWorld(network,manager,world)||grave==null||!grave.IsValid())return false;
                var instance=scene.FindInstance(grave.m_uid);
                if(instance)
                {
                    var view=instance.GetComponent<ZNetView>();
                    if(!instance.GetComponent<TombStone>()||!view||!view.IsValid()||view.GetZDO()?.m_uid!=grave.m_uid)return false;
                    view.ClaimOwnership();if(!view.IsOwner())return false;
                    var body=instance.GetComponent<Rigidbody>();
                    if(body){body.position=target;body.linearVelocity=Vector3.zero;body.angularVelocity=Vector3.zero;body.WakeUp();}
                    instance.transform.position=target;
                }
                else {grave.SetOwner(ZDOMan.GetSessionID());if(!grave.IsOwner())return false;}
                grave.Set(ZDOVars.s_spawnPoint,target);grave.SetPosition(target);return true;
            }
            catch(Exception ex){Logger.LogWarning("Native grave exit refused: "+ex.Message);return false;}
        }
    }
}
