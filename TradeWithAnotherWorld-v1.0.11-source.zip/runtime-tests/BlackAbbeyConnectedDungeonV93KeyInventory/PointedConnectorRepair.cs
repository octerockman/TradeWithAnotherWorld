using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading;
using Newtonsoft.Json;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Presentation derivative only. The accepted catalog, aperture, collision,
    // generator identities and source files remain unchanged on disk.
    internal static class PointedConnectorRepair
    {
        internal const string PayloadHash="0cc446a49fd3cb10cf1f57347fe6ecd52487cf4b72776960fb7ada231b1acdd5";
#pragma warning disable 0649
        sealed class MeshPin { public MeshRecord source; public string originalFrameSha256,resource,sha256; }
        sealed class TexturePin { public string kind,resource,sha256; public bool linear; }
        sealed class Payload { public string manifestSha256,baseSourceSha256; public MeshPin[] meshes; public TexturePin[] textures; }
#pragma warning restore 0649
        static readonly Lazy<Payload> payload=new Lazy<Payload>(()=>JsonConvert.DeserializeObject<Payload>(System.Text.Encoding.UTF8.GetString(Resource("BlackAbbey.ConnectorRepairV90.payload.json",PayloadHash,65536)),ManifestReader.Settings()),LazyThreadSafetyMode.ExecutionAndPublication);
        static byte[] Resource(string name,string hash,int maximum)
        {
            using(var stream=typeof(PointedConnectorRepair).Assembly.GetManifestResourceStream(name))
            {
                if(stream==null||stream.Length<1||stream.Length>maximum)throw new InvalidDataException("Missing checked connector finish resource.");
                byte[] b;using(var memory=new MemoryStream()){stream.CopyTo(memory);b=memory.ToArray();}
                if(BarMeshReader.Hash(b)!=hash)throw new InvalidDataException("Connector repair resource hash differs.");return b;
            }
        }
        static bool Scope(string directory)
        {
            if(string.IsNullOrWhiteSpace(directory)||!string.Equals(Path.GetFileName(directory.TrimEnd('\\','/')),"pointed-connector",StringComparison.Ordinal))return false;
            if(CatalogReader.HashFile(Path.Combine(directory,"manifest.json"))!=payload.Value.manifestSha256)throw new InvalidDataException("Connector repair requires its exact accepted source manifest.");return true;
        }
        static MeshPin Pin(string directory,MeshRecord record,bool collider)
        {
            if(collider||record==null||!Scope(directory))return null;
            return payload.Value.meshes.SingleOrDefault(p=>p.source.sha256==record.sha256&&p.source.meshFile==record.meshFile&&p.source.materialIndex==record.materialIndex&&p.source.vertices==record.vertices&&p.source.indices==record.indices);
        }
        internal static string MeshCacheToken(string directory,MeshRecord record,bool collider)=>Pin(directory,record,collider)!=null?"|pointed-connector-v90|"+PayloadHash:"";
        internal static BarMeshData Apply(string directory,MeshRecord record,bool collider,BarMeshData data)
        {
            var pin=Pin(directory,record,collider);if(pin==null)return data;
            if(BossPresentationRepair.FrameHash(data)!=pin.originalFrameSha256)throw new InvalidDataException("Connector decoded source frame differs.");
            BarMeshData result;using(var memory=new MemoryStream(Resource(pin.resource,pin.sha256,1024*1024),false))using(var zip=new GZipStream(memory,CompressionMode.Decompress))result=BarMeshReader.Decode(zip,record,false);
            if(!result.Indices.SequenceEqual(data.Indices)||result.Positions.Length!=data.Positions.Length)throw new InvalidDataException("Connector finish cannot change topology.");
            for(int i=0;i<data.Positions.Length;i++)
            {
                if(result.Normals[i]!=data.Normals[i])throw new InvalidDataException("Connector finish cannot change authored normals.");
                if(record.materialIndex==0&&result.Positions[i]!=data.Positions[i])throw new InvalidDataException("Dressed connector silhouette moved.");
                if(record.materialIndex==1&&(result.Positions[i].x!=data.Positions[i].x||result.Positions[i].y!=data.Positions[i].y||Math.Abs(result.Positions[i].z-data.Positions[i].z)>.01101f))throw new InvalidDataException("Connector backing exceeded checked mouth extension.");
            }
            return result;
        }
        internal static void ApplyMaterial(string directory,MaterialRecord record,LoadedRoom room,Material material)
        {
            if(record?.name!="POINTED_CONNECTOR_KIT_V1 runtime BA KIT V1 | Worn Wall Masonry"||!Scope(directory))return;
            if(room.Manifest.sourceSha256!=payload.Value.baseSourceSha256)throw new InvalidDataException("Connector finish source owner differs.");
            foreach(var p in payload.Value.textures)
            {
                var t=new Texture2D(2,2,TextureFormat.RGBA32,true,p.linear);room.Resources.Add(t);
                if(!ImageConversion.LoadImage(t,Resource(p.resource,p.sha256,4*1024*1024),true)||t.width!=256||t.height!=256)throw new InvalidDataException("Connector source-fitted grain dimensions differ.");
                t.name="Abbey V90 source-fitted limestone | "+p.kind;t.wrapMode=TextureWrapMode.Clamp;t.filterMode=FilterMode.Trilinear;t.anisoLevel=8;
                string property=p.kind=="albedo"?"_MainTex":p.kind=="normal"?"_BumpMap":"_MetallicGlossMap";material.SetTexture(property,t);
            }
            material.SetColor("_Color",Color.white);if(material.HasProperty("_BumpScale"))material.SetFloat("_BumpScale",1f);
        }
    }
}
