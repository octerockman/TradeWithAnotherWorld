using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading;
using Newtonsoft.Json;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // V90 presentation derivative. Source manifest, saved bindings, collision and base files stay authoritative.
    internal static class R09HallRepairV90
    {
        internal const string ResourceName="BlackAbbey.R09RepairV90.json";
        internal const string PayloadSha256="a3060949cf974f8d5133dbdee8f280e95df40fe1fc82d0b8a013bf8cc8b52769";
#pragma warning disable 0649
        internal sealed class TexturePin{public string relative,originalSha256,resource,sha256;public bool linear;}
        internal sealed class MeshPin{public string name,originalFrameSha256,replacementResource,replacementSha256;public MeshRecord sourceMesh;public int vertices,indices,triangles;}
        internal sealed class SocketPin{public string name;public float[] before,delta;}
        internal sealed class RoomPin{public string assetId,sourceSha256,manifestSha256;public MeshPin[] meshes;public TexturePin[] textures;public SocketPin[] sockets;}
        internal sealed class Payload{public string schema;public RoomPin[] rooms;}
#pragma warning restore 0649
        private static byte[] Resource(string name,string hash,int limit)
        {
            using(var stream=typeof(R09HallRepairV90).Assembly.GetManifestResourceStream(name))
            {
                if(stream==null||stream.Length<1||stream.Length>limit)throw new InvalidDataException("Missing checked R09 V90 presentation resource.");
                byte[] bytes;using(var mem=new MemoryStream()){stream.CopyTo(mem);bytes=mem.ToArray();}
                if(BarMeshReader.Hash(bytes)!=hash)throw new InvalidDataException("R09 V90 presentation resource changed.");return bytes;
            }
        }
        private static readonly Lazy<Payload> payload=new Lazy<Payload>(()=>{
            var p=JsonConvert.DeserializeObject<Payload>(System.Text.Encoding.UTF8.GetString(Resource(ResourceName,PayloadSha256,4*1024*1024)),ManifestReader.Settings());
            if(p?.schema!="black-abbey.r09-repair-v90.v1"||p.rooms?.Length!=2||p.rooms.Any(r=>r.meshes?.Length!=5||r.textures?.Length!=3||r.sockets?.Length!=18))throw new InvalidDataException("Invalid checked R09 V90 payload.");
            return p;
        },LazyThreadSafetyMode.ExecutionAndPublication);
        private static string Asset(string directory)=>Path.GetFileName(Path.GetFullPath(directory).TrimEnd('\\','/'));
        private static RoomPin Scope(string directory)
        {
            if(string.IsNullOrEmpty(directory))return null;var id=Asset(directory);if(id!="R09-A1"&&id!="R09-A2")return null;
            var p=payload.Value.rooms.Single(r=>r.assetId==id);
            if(CatalogReader.HashFile(Path.Combine(directory,"manifest.json"))!=p.manifestSha256)throw new InvalidDataException("R09 V90 repair requires the exact approved base manifest.");return p;
        }
        private static RoomPin Scope(string directory,LoadedRoom room)
        {
            if(room?.Record==null||room.Manifest==null||string.IsNullOrEmpty(room.PackageDirectory)||!string.Equals(Path.GetFullPath(directory).TrimEnd('\\','/'),Path.GetFullPath(room.PackageDirectory).TrimEnd('\\','/'),StringComparison.OrdinalIgnoreCase))return null;
            var pin=Scope(directory);if(pin==null)return null;
            if(room.Record.packageDirectory!=pin.assetId||room.Record.sourceSha256!=pin.sourceSha256||room.Record.manifestSha256!=pin.manifestSha256||room.Manifest.sourceSha256!=pin.sourceSha256||room.Manifest.roomId!=pin.assetId)throw new InvalidDataException("R09 V90 repair source owner changed.");return pin;
        }
        private static MeshPin MeshScope(string directory,MeshRecord record,bool collider)
        {
            if(collider||record==null)return null;var room=Scope(directory);if(room==null)return null;var pin=room.meshes.SingleOrDefault(m=>m.name==record.name);if(pin==null)return null;
            var x=pin.sourceMesh;if(x.name!=record.name||x.meshFile!=record.meshFile||x.sha256!=record.sha256||x.vertices!=record.vertices||x.indices!=record.indices||x.triangles!=record.triangles||x.materialIndex!=record.materialIndex||x.partId!=record.partId)throw new InvalidDataException("R09 V90 repair source mesh record changed.");return pin;
        }
        internal static string MeshCacheToken(string directory,MeshRecord record,bool collider)=>MeshScope(directory,record,collider)==null?"":"|r09-hall-v90|"+PayloadSha256;
        internal static BarMeshData Apply(string directory,MeshRecord record,bool collider,BarMeshData source)
        {
            var pin=MeshScope(directory,record,collider);if(pin==null)return source;
            if(BossPresentationRepair.FrameHash(source)!=pin.originalFrameSha256)throw new InvalidDataException("R09 V90 source mesh frame differs from verified chart and mounting owners.");
            var rec=new MeshRecord{name=record.name,vertices=pin.vertices,indices=pin.indices,triangles=pin.triangles};BarMeshData result;
            using(var mem=new MemoryStream(Resource(pin.replacementResource,pin.replacementSha256,64*1024*1024),false))using(var zip=new GZipStream(mem,CompressionMode.Decompress))result=BarMeshReader.Decode(zip,rec,false);
            if(result.Positions.Length<source.Positions.Length||result.Indices.Length<source.Indices.Length||!result.Indices.Take(source.Indices.Length).SequenceEqual(source.Indices))throw new InvalidDataException("R09 V90 presentation altered base triangle ownership.");return result;
        }
        private static TexturePin Texture(string directory,string relative,bool linear,LoadedRoom room)
        {
            if(relative!="textures/architecture_floor_albedo.png"&&relative!="textures/architecture_floor_normal.png"&&relative!="textures/architecture_floor_metal_smooth.png")return null;
            var p=Scope(directory,room);if(p==null)return null;var pin=p.textures.Single(t=>t.relative==relative);if(pin.linear!=linear)throw new InvalidDataException("R09 V90 texture color space changed.");return pin;
        }
        internal static int VisualTriangleDelta(string directory,LoadedRoom room)
        {var p=Scope(directory,room);return p==null?0:checked(p.meshes.Sum(m=>m.triangles-m.sourceMesh.triangles));}
        internal static bool HandlesTexture(string directory,string relative,bool linear,LoadedRoom room)=>Texture(directory,relative,linear,room)!=null;
        internal static bool TryTexture(string directory,string relative,bool linear,LoadedRoom room,TextureSamplerRecord sampler,out Texture2D texture)
        {
            texture=null;var pin=Texture(directory,relative,linear,room);if(pin==null)return false;var path=Path.Combine(directory,relative.Replace('/',Path.DirectorySeparatorChar));
            string alias="r09-hall-v90|"+Path.GetFullPath(path)+"|"+pin.sha256+(linear?"|linear":"|srgb")+TextureSamplerPolicy.Key(sampler);
            if(room.R09Textures.TryGetValue(alias,out texture)){room.Diagnostic?.Event("texture-room-local-hit");return true;}
            if(SharedRoomResources.TryAcquireAlias(alias,room,out texture)){room.ResidentTextureHits++;room.R09Textures.Add(alias,texture);return true;}
            var source=new VerifiedResourceFile(path,pin.originalSha256,256L*1024*1024,room.Diagnostic,"texture");room.PendingSources.Add(source);
            try{
                source.Read();room.ColdResourceReads++;room.ColdEncodedBytes+=source.BytesRead;string key=RoomTextureIdentity.Key(pin.sha256,linear,sampler);
                if(SharedRoomResources.TryAcquire<Texture2D>(key,room,out texture)){SharedRoomResources.BindAlias(alias,key,source,room);room.R09Textures.Add(alias,texture);return true;}
                texture=new Texture2D(2,2,TextureFormat.RGBA32,true,linear);room.Resources.Add(texture);
                if(!ImageConversion.LoadImage(texture,Resource(pin.resource,pin.sha256,64*1024*1024),true)||texture.width!=4096||texture.height!=4096)throw new InvalidDataException("R09 V90 atlas dimensions/codec changed.");
                texture.name="R09 V90 scoped reveal/iron chart repair "+relative;texture.filterMode=TextureSamplerPolicy.Filter(sampler)=="point"?FilterMode.Point:TextureSamplerPolicy.Filter(sampler)=="bilinear"?FilterMode.Bilinear:FilterMode.Trilinear;texture.wrapMode=TextureSamplerPolicy.Wrap(sampler)=="repeat"?TextureWrapMode.Repeat:TextureWrapMode.Clamp;texture.anisoLevel=8;
                SharedRoomResources.Retain(key,texture,room,source);SharedRoomResources.BindAlias(alias,key,source,room);room.R09Textures.Add(alias,texture);return true;
            }catch{if(room.PendingSources.Remove(source))source.Dispose();throw;}
        }
        internal static Vector3 SocketPosition(string directory,LoadedRoom room,SocketRecord socket)
        {
            var original=RoomPackage.Vector(socket.position,socket.name);var p=Scope(directory,room);if(p==null)return original;var pin=p.sockets.SingleOrDefault(s=>s.name==socket.name);if(pin==null)return original;
            if(pin.before?.Length!=3||pin.delta?.Length!=3||socket.position.Length!=3||!socket.position.SequenceEqual(pin.before))throw new InvalidDataException("R09 V90 flame contact source differs.");
            return original+RoomPackage.Vector(pin.delta,"R09 V90 rigid fixture delta");
        }
    }
}
