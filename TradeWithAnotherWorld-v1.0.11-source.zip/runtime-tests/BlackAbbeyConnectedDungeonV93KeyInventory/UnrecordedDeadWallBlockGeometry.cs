using System;
using System.Collections.Generic;
using System.IO;

namespace BlackAbbeySixRooms
{
    internal sealed class UnrecordedDeadWallBlockData
    {
        // Room-local Unity frame; each row is XYZ,normalXYZ,UV,tangentXYZW.
        internal float[][] Vertices;
        internal int[] Indices;
        internal float[] Center;
        internal int PreservedFaceTriangles,RearCapTriangles,BodyTriangles;
    }

    // Extend the hidden back, never scale the worn front or its bevel fan.
    // Pure managed geometry: no Unity objects, RNG, source writes or gameplay.
    internal static class UnrecordedDeadWallBlockGeometry
    {
        internal const string SourceSha256="03ddb355ee15d026e90ae8f9563e26ac6f9ab72bf0e3121b51cef32750f15ec6";
        internal const int SourceVertices=1033,SourceIndices=1386,StoneCount=11,IndicesPerStone=90;
        internal const float OriginalRearX=-2.002f,BlockRearX=-2.46f;
        internal const int TrianglesPerBlock=38;

        static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
        static float[] Clone(float[] value)=>(float[])value.Clone();
        static float[] Point(float x,float y,float z)=>new[]{x,y,z};
        static float[] Minus(float[] a,float[] b)=>new[]{a[0]-b[0],a[1]-b[1],a[2]-b[2]};
        static float[] Cross(float[] a,float[] b)=>new[]{a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]};
        static float Dot(float[] a,float[] b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
        static float[] Unit(float[] value)
        {
            float length=(float)Math.Sqrt(Dot(value,value));
            if(!Finite(length)||length<1e-8f)throw new InvalidDataException("A block tangent frame is degenerate.");
            return new[]{value[0]/length,value[1]/length,value[2]/length};
        }
        internal static UnrecordedDeadWallBlockData Build(string sourceSha256,float[][] source,int[] indices,int stone)
        {
            if(sourceSha256!=SourceSha256||source==null||source.Length!=SourceVertices||indices==null||indices.Length!=SourceIndices)
                throw new InvalidDataException("Full wall blocks require the exact pinned source BAR buffer.");
            if(stone<0||stone>=StoneCount)throw new ArgumentOutOfRangeException(nameof(stone));
            int start=stone*IndicesPerStone;
            float lowY=float.PositiveInfinity,highY=float.NegativeInfinity,lowZ=float.PositiveInfinity,highZ=float.NegativeInfinity;
            for(int n=start;n<start+IndicesPerStone;n++)
            {
                int index=indices[n];
                if(index<0||index>=source.Length||source[index]==null||source[index].Length!=12)throw new InvalidDataException("Invalid source stone corner.");
                foreach(float value in source[index])if(!Finite(value))throw new InvalidDataException("Nonfinite source stone.");
                var v=source[index];lowY=Math.Min(lowY,v[1]);highY=Math.Max(highY,v[1]);lowZ=Math.Min(lowZ,v[2]);highZ=Math.Max(highZ,v[2]);
            }
            float height=highY-lowY,width=highZ-lowZ,depth=OriginalRearX-BlockRearX;
            if(height<.3f||height>.5f||width<.45f||width>.8f||depth<.4f||depth>.5f)throw new InvalidDataException("Pinned stone proportions changed.");
            // The first two source triangles form the rectangular hidden cap.
            // Keep its real atlas chart; do not magnify the 5mm bevel UV strip.
            var cap=new Dictionary<int,float[]>();
            for(int n=start;n<start+6;n++)
            {
                var row=source[indices[n]];
                if(row[0]!=OriginalRearX||row[3]!=-1||row[4]!=0||row[5]!=0)throw new InvalidDataException("The source hidden rear cap changed.");
                int corner=(row[1]==highY?1:row[1]==lowY?0:-4)+(row[2]==highZ?2:row[2]==lowZ?0:-8);
                if(corner<0||corner>3)throw new InvalidDataException("The source rear cap is not rectangular.");
                if(cap.TryGetValue(corner,out var old)&&(old[6]!=row[6]||old[7]!=row[7]))throw new InvalidDataException("Source cap chart has an unexpected seam.");
                cap[corner]=row;
            }
            if(cap.Count!=4)throw new InvalidDataException("The source cap must have four corners.");
            var origin=cap[0];var acrossY=cap[1];var acrossZ=cap[2];var diagonal=cap[3];
            for(int a=6;a<=7;a++)if(Math.Abs((acrossY[a]+acrossZ[a]-origin[a])-diagonal[a])>1e-6f)
                throw new InvalidDataException("The original cap UV chart is not affine.");
            Func<float,float,float[]> chart=(y,z)=>new[]{origin[6]+y*(acrossY[6]-origin[6])+z*(acrossZ[6]-origin[6]),origin[7]+y*(acrossY[7]-origin[7])+z*(acrossZ[7]-origin[7])};
            var output=new List<float[]>(TrianglesPerBlock*3);
            // Every surviving original corner remains byte-identical.
            for(int n=start+6;n<start+IndicesPerStone;n++)output.Add(Clone(source[indices[n]]));
            // Relocate only the old hidden cap; its UV/normal/tangent stay exact.
            for(int n=start;n<start+6;n++){var v=Clone(source[indices[n]]);v[0]=BlockRearX;output.Add(v);}
            float fitY=Math.Min(1,height/depth),fitZ=Math.Min(1,width/depth);
            Func<float[],float[]> ySideUv=p=>chart((OriginalRearX-p[0])*fitY/height,.5f+((p[2]-lowZ)/width-.5f)*fitY);
            Func<float[],float[]> zSideUv=p=>chart(.5f+((p[1]-lowY)/height-.5f)*fitZ,(OriginalRearX-p[0])*fitZ/width);
            AddQuad(output,new[]{Point(OriginalRearX,lowY,lowZ),Point(OriginalRearX,lowY,highZ),Point(BlockRearX,lowY,highZ),Point(BlockRearX,lowY,lowZ)},Point(0,-1,0),ySideUv);
            AddQuad(output,new[]{Point(OriginalRearX,highY,lowZ),Point(BlockRearX,highY,lowZ),Point(BlockRearX,highY,highZ),Point(OriginalRearX,highY,highZ)},Point(0,1,0),ySideUv);
            AddQuad(output,new[]{Point(OriginalRearX,lowY,lowZ),Point(BlockRearX,lowY,lowZ),Point(BlockRearX,highY,lowZ),Point(OriginalRearX,highY,lowZ)},Point(0,0,-1),zSideUv);
            AddQuad(output,new[]{Point(OriginalRearX,lowY,highZ),Point(OriginalRearX,highY,highZ),Point(BlockRearX,highY,highZ),Point(BlockRearX,lowY,highZ)},Point(0,0,1),zSideUv);
            float[] lo=Point(float.PositiveInfinity,float.PositiveInfinity,float.PositiveInfinity),hi=Point(float.NegativeInfinity,float.NegativeInfinity,float.NegativeInfinity);
            var final=output.ToArray();var triangles=new int[final.Length];
            for(int i=0;i<final.Length;i++){triangles[i]=i;for(int a=0;a<3;a++){lo[a]=Math.Min(lo[a],final[i][a]);hi[a]=Math.Max(hi[a],final[i][a]);}}
            return new UnrecordedDeadWallBlockData{Vertices=final,Indices=triangles,Center=Point((lo[0]+hi[0])*.5f,(lo[1]+hi[1])*.5f,(lo[2]+hi[2])*.5f),PreservedFaceTriangles=28,RearCapTriangles=2,BodyTriangles=8};
        }
        static void AddQuad(List<float[]> output,float[][] points,float[] normal,Func<float[],float[]> uv)
        {
            AddTriangle(output,points[0],points[1],points[2],normal,uv);
            AddTriangle(output,points[0],points[2],points[3],normal,uv);
        }
        static void AddTriangle(List<float[]> output,float[] a,float[] b,float[] c,float[] normal,Func<float[],float[]> uv)
        {
            var ta=uv(a);var tb=uv(b);var tc=uv(c);var ab=Minus(b,a);var ac=Minus(c,a);
            float du1=tb[0]-ta[0],dv1=tb[1]-ta[1],du2=tc[0]-ta[0],dv2=tc[1]-ta[1],det=du1*dv2-du2*dv1;
            if(!Finite(det)||Math.Abs(det)<1e-12f)throw new InvalidDataException("Generated block body UVs are degenerate.");
            var tangent=Unit(Point((ab[0]*dv2-ac[0]*dv1)/det,(ab[1]*dv2-ac[1]*dv1)/det,(ab[2]*dv2-ac[2]*dv1)/det));
            var bitangent=Point((ac[0]*du1-ab[0]*du2)/det,(ac[1]*du1-ab[1]*du2)/det,(ac[2]*du1-ab[2]*du2)/det);
            float sign=Dot(Cross(normal,tangent),bitangent)<0?-1:1;
            foreach(var row in new[]{new[]{a,ta},new[]{b,tb},new[]{c,tc}})
                output.Add(new[]{row[0][0],row[0][1],row[0][2],normal[0],normal[1],normal[2],row[1][0],row[1][1],tangent[0],tangent[1],tangent[2],sign});
        }
    }
}
