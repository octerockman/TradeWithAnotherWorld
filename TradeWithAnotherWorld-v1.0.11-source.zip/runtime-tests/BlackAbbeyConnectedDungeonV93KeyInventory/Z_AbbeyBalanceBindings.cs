using System;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        void InitializeBalanceStatus()
        {
            Add("twa_balance_status","Show the current dungeon difficulty tier and room spawn cap.",false,()=>Print(persistentRun==null?"No generated dungeon is bound yet.":"Dungeon difficulty tier="+AbbeyBalancePolicy.EffectiveTier(persistentRun.balanceRevision,persistentRun.balanceTier)+" (0:none, 1:Eikthyr, 2:Elder, 3:Bonemass, 4:Moder, 5:Yagluth, 6:Queen, 7:Fader). Fixed until regeneration. Ordinary room cap3; bell crossing4; Thrall head1.5x."));
        }
        internal static void BindRunBalance(Character actor,string prefab,string run,bool fresh)
        {
            var owner=persistentOwner;
            if(!owner||!owner.persistentRunBound||owner.persistentRun==null||owner.persistentRun.runId!=run)
                throw new InvalidOperationException("Generated dungeon balance snapshot is unavailable; actor spawn retained safely.");
            AbbeyBalanceRuntime.Bind(actor,prefab,run,AbbeyBalancePolicy.EffectiveTier(owner.persistentRun.balanceRevision,owner.persistentRun.balanceTier),fresh);
        }
        // Paired Abbot module calls this before binding its two-bar guard.
        public static float BindBossBalance(Character actor,float configuredMaximum)
        {
            var owner=persistentOwner;
            if(!owner||!owner.persistentRunBound||owner.persistentRun==null)return configuredMaximum;
            int tier=AbbeyBalancePolicy.EffectiveTier(owner.persistentRun.balanceRevision,owner.persistentRun.balanceTier);
            AbbeyBalanceRuntime.Bind(actor,AbbeyBalancePolicy.Abbot,owner.persistentRun.runId,tier,true,false);
            return configuredMaximum*AbbeyBalancePolicy.HealthMultiplier(AbbeyBalancePolicy.Abbot,tier);
        }
    }
}
