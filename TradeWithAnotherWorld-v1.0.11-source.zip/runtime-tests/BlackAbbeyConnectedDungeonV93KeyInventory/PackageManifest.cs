using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using Newtonsoft.Json;

namespace BlackAbbeySixRooms
{
#pragma warning disable 0649
    [Serializable] internal sealed class PackageManifest
    {
        public int schemaVersion;
        public string roomId, sourceSha256, repairFile, interactionFile, interactionSha256;
        public string r09InteractionFile, r09InteractionSha256, r09LightingFile, r09LightingSha256;
        public MeshRecord[] meshes, colliderMeshes;
        public MaterialRecord[] materials;
        public SocketRecord[] sockets;
        public LightGroupRecord[] lightGroups;
        public WindowLightRecord[] windowLights;
        public BottomMistRecord bottomMist;
        public DoorFitRecord doorFit;
        public PortRecord[] ports;
        public float[][] footprint, floorPolygonXZ, outerFootprintPolygonXZ, occupancyBoundsXZ;
        public float[] entryPosition, entryForward, boundsMin, boundsMax;
        public int triangles;
    }
    [Serializable] internal sealed class MeshRecord
    {
        public string name, meshFile, sha256, partId;
        public int materialIndex, vertices, indices, triangles;
        public long bytes;
    }
    [Serializable] internal sealed class MaterialRecord
    {
        public string name, albedo, normal, metallicSmoothness, emission;
        public bool cutout, transparent, unlit;
        public float roughness, metallic, emissionStrength;
        public float? alphaCutoff, normalStrength;
        public TextureSamplerRecord sampler, albedoSampler, normalSampler, metallicSmoothnessSampler, emissionSampler;
    }
    [Serializable] internal sealed class TextureSamplerRecord
    {
        public string wrap = "clamp", filter = "trilinear";
        public bool mipmaps = true;
        public int anisotropy = 8;
    }
    [Serializable] internal sealed class SocketRecord { public string name; public float[] position; }
    [Serializable] internal sealed class DoorFitRecord
    {
        public string assemblyStyle, woodProfileMode;
        public float mountDepth, clearWidth, clearHeight, openAngle;
        public float[] leftHinge, rightHinge;
        public float[] circleLeftHinge, circleRightHinge;
        public float circleClearWidth;
        public DoorVariantRecord[] variants;
    }
    [Serializable] internal sealed class DoorVariantRecord
    {
        public string roomId, portId, sourceSha256, prefix;
        public float mountDepth, clearWidth, clearHeight;
        public float[] leftHinge, rightHinge;
    }
    [Serializable] internal sealed class LightGroupRecord { public string name; public float[] position; public float intensity, range; }
    [Serializable] internal sealed class WindowLightRecord
    {
        public string name, projectionGroup, channel, cookie, cookieSha256, cookieColorSpace;
        public string[] shadowExcludeMeshes;
        public float[] position, direction, up, color;
        public float intensity = 2.8f, range = 12f, spotAngle = 50f, innerSpotAngle = 25f, shadowStrength = .85f;
        public float shadowBias = .025f, shadowNormalBias = .05f, shadowNearPlane = .05f;
        public int shadowResolution = 512;
    }
    [Serializable] internal sealed class BottomMistRecord
    {
        public float[] position, size, color, recoveryPosition;
        public float recoveryBelow, density = .06f, opacity = .65f;
    }
    [Serializable] internal sealed class PortRecord
    {
        public string id, side;
        [JsonIgnore] internal string SourceRoomId;
        public float[] position, outward, outerThresholdPosition;
        public float width, height, depth, wallThickness, springHeight, archRise;
        public float[][] apertureProfileWidthHeight;
    }
    [Serializable] internal sealed class RoomCatalog { public int schemaVersion; public CatalogRoomRecord[] rooms; public CatalogRoomRecord connector, endCap; public int? dungeonSeed; }
    [Serializable] internal sealed class CatalogRoomRecord
    {
        public string roomId, displayName, packageDirectory, sourceSha256, manifestSha256;
        [JsonIgnore] internal int Slot;
    }
#pragma warning restore 0649

    internal static class ManifestReader
    {
        internal static JsonSerializerSettings Settings() => new JsonSerializerSettings {
            TypeNameHandling = TypeNameHandling.None, MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore, MaxDepth = 32 };
        internal static PackageManifest Read(string json)
        {
            if (json == null || json.Length > 4 * 1024 * 1024) throw new InvalidDataException("Room manifest is absent or too large.");
            var manifest = JsonConvert.DeserializeObject<PackageManifest>(json, Settings());
            if (manifest?.ports != null) foreach (var port in manifest.ports) if (port != null) port.SourceRoomId = manifest.roomId;
            return manifest;
        }
    }
    internal static class CatalogReader
    {
        internal static readonly string[] LegacyRoomIds = { "R01", "R02", "R03", "R03_complete", "R04", "R05", "R06" };
        internal static readonly string[] RoomIds = LegacyRoomIds.Concat(new[] { "R07", "R08", "R09-A1", "R09-B" }).ToArray();
        internal static bool ValidRoomInventory(IEnumerable<string> source)
        {
            if (source == null) return false;
            var ids = source.ToArray();
            return ids.Length == LegacyRoomIds.Length + (ids.Contains("R07") ? 1 : 0) + (ids.Contains("R08") ? 1 : 0) + (ids.Contains("R09-A1") ? 1 : 0) + (ids.Contains("R09-B") ? 1 : 0) &&
                ids.Distinct(StringComparer.Ordinal).Count() == ids.Length &&
                ids.All(id => id != null && RoomIds.Contains(id)) && LegacyRoomIds.All(ids.Contains) && ids.Contains("R09-A1")==ids.Contains("R09-B");
        }
        internal static bool Hash(string value) => value != null && value.Length == 64 && value.All(c => c >= '0' && c <= '9' || c >= 'a' && c <= 'f');
        internal static string HashFile(string path)
        {
            using (var file = File.OpenRead(path)) using (var sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(file)).Replace("-", "").ToLowerInvariant();
        }
        internal static RoomCatalog Read(string json)
        {
            if (json == null || json.Length > 4 * 1024 * 1024) throw new InvalidDataException("Room catalog is absent or too large.");
            var catalog = JsonConvert.DeserializeObject<RoomCatalog>(json, ManifestReader.Settings());
            if (catalog == null || catalog.schemaVersion != 1 || catalog.rooms == null ||
                catalog.rooms.Any(r => r == null) || !ValidRoomInventory(catalog.rooms.Select(r => r.roomId)))
                throw new InvalidDataException("The catalog requires R01–R06 and the complete-saint R03 variant exactly once, with optional R07 shrine, R08 stair and R09 sanctum once each.");
            foreach (var room in catalog.rooms)
            {
                if (!Hash(room.sourceSha256) || (!string.IsNullOrEmpty(room.manifestSha256) && !Hash(room.manifestSha256)) ||
                    string.IsNullOrWhiteSpace(room.packageDirectory) || Path.IsPathRooted(room.packageDirectory) ||
                    room.packageDirectory.Replace('\\', '/').Split('/').Any(p => p == ".." || p == "." || p.Length == 0))
                    throw new InvalidDataException("Invalid catalog source hash or package directory for " + room.roomId + ".");
                room.Slot = Array.IndexOf(RoomIds, room.roomId);
            }
            if (catalog.connector != null)
            {
                var room = catalog.connector;
                if (room.roomId != "CONNECTOR" || !Hash(room.sourceSha256) || (!string.IsNullOrEmpty(room.manifestSha256) && !Hash(room.manifestSha256)) ||
                    string.IsNullOrWhiteSpace(room.packageDirectory) || Path.IsPathRooted(room.packageDirectory) ||
                    room.packageDirectory.Replace('\\', '/').Split('/').Any(p => p == ".." || p == "." || p.Length == 0))
                    throw new InvalidDataException("Invalid optional connector catalog record.");
                room.Slot = catalog.rooms.Length;
            }
            if (catalog.endCap != null)
            {
                var room = catalog.endCap;
                if (room.roomId != "ENDCAP" || !Hash(room.sourceSha256) || (!string.IsNullOrEmpty(room.manifestSha256) && !Hash(room.manifestSha256)) ||
                    string.IsNullOrWhiteSpace(room.packageDirectory) || Path.IsPathRooted(room.packageDirectory) ||
                    room.packageDirectory.Replace('\\', '/').Split('/').Any(p => p == ".." || p == "." || p.Length == 0))
                    throw new InvalidDataException("Invalid optional end-cap catalog record.");
                room.Slot = catalog.rooms.Length + 1;
            }
            return catalog;
        }
        internal static string PackagePath(string dataRoot, CatalogRoomRecord room)
        {
            string root = Path.GetFullPath(dataRoot).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string path = Path.GetFullPath(Path.Combine(root, room.packageDirectory));
            if (!path.StartsWith(root, StringComparison.OrdinalIgnoreCase) || !Directory.Exists(path)) throw new InvalidDataException("Missing/outside room package " + room.roomId + ".");
            return path;
        }
    }
}
