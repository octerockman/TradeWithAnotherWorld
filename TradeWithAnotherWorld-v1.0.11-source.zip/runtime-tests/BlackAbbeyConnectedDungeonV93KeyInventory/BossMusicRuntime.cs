using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

namespace BlackAbbeySixRooms
{
    // Local encounter soundtrack only. Never owns a native manager or modifies
    // its mixer, mute, clips, volume settings, snapshots, or gameplay audio.
    internal sealed class BossMusicRuntime : MonoBehaviour
    {
        private readonly BossMusicTimeline clock = new BossMusicTimeline();
        private readonly Dictionary<string, AudioClip> clips = new Dictionary<string, AudioClip>();
        private AudioSource entrance, combat, victory;
        private BossMusicAssets assets;
        private Task<BossMusicAssets> preparation;
        private UnityWebRequest request;
        private Coroutine loading;
        private string dataPath;
        private Action<string> log;
        private bool ready, faulted, eligible, enabledByUser = true, playbackScheduled;
        private float userGain = 1, ambienceGain = 1;
        private int loadEpoch;
        private double lastDsp;
        private double lastHeartbeat;
        internal float AmbienceGain => ambienceGain;
        private static double Now => AudioSettings.dspTime;

        internal void Initialize(string directory, Action<string> write) { dataPath = directory; log = write; }
        internal void Configure(bool enabled, float volume)
        {
            enabledByUser = enabled; userGain = Mathf.Clamp01(volume);
            if (!enabledByUser || userGain <= 0) Suspend();
        }
        internal void Prepare()
        {
            if (ready || faulted || loading != null || !isActiveAndEnabled || dataPath == null) return;
            int epoch = ++loadEpoch;
            preparation = Task.Run(() => BossMusicAssets.Prepare(dataPath));
            loading = StartCoroutine(Load(epoch, preparation));
        }
        private IEnumerator Load(int epoch, Task<BossMusicAssets> task)
        {
            while (!task.IsCompleted) yield return null;
            if (task.IsFaulted || task.IsCanceled)
            { Fail("Verified music source unavailable: " + task.Exception?.GetBaseException().Message); yield break; }
            if (epoch != loadEpoch) { task.Result.Dispose(); yield break; }
            assets = task.Result; preparation = null;
            foreach (var track in assets.Tracks)
            {
                string uri = new Uri(Path.Combine(assets.DirectoryPath, track.file)).AbsoluteUri;
                UnityWebRequest active = null;
                try
                {
                    active = UnityWebRequestMultimedia.GetAudioClip(uri, AudioType.OGGVORBIS);
                    ((DownloadHandlerAudioClip)active.downloadHandler).streamAudio = true;
                    active.timeout = 45; request = active; active.SendWebRequest();
                }
                catch (Exception error) { active?.Dispose(); Fail(error.Message); yield break; }
                while (!active.isDone && epoch == loadEpoch) yield return null;
                if (epoch != loadEpoch) yield break;
                AudioClip clip = null; string errorText = null;
                try
                {
                    if (active.result != UnityWebRequest.Result.Success) throw new IOException(active.error);
                    clip = DownloadHandlerAudioClip.GetContent(active);
                    if (!clip || clip.channels != track.channels || clip.frequency != track.sampleRate ||
                        Math.Abs((long)clip.samples - track.frames) > 2048)
                        throw new InvalidDataException("Native music decoder returned a different format/duration: " + track.id);
                    clip.name = "BA boss music | " + track.id; clips.Add(track.id, clip);
                }
                catch (Exception error) { if (clip) Destroy(clip); errorText = error.Message; }
                active.Dispose(); request = null;
                if (errorText != null) { Fail(errorText); yield break; }
            }
            ready = true; loading = null;
            Write("BA_BOSS_MUSIC_READY: verified OGG streams; entrance20s, combat520s, immediate victory30.749s; music/master sliders read natively; no game listening claim.");
            ScheduleCurrent();
        }
        private AudioSource Source(string name, AudioClip clip, bool loop)
        {
            var child = new GameObject("BA owned boss music | " + name); child.transform.SetParent(transform, false);
            var source = child.AddComponent<AudioSource>(); source.playOnAwake = false;
            source.clip = clip; source.loop = loop; source.spatialBlend = 0; source.pitch = 1;
            source.dopplerLevel = 0; source.reverbZoneMix = 0; source.priority = 32;
            source.outputAudioMixerGroup = MusicMan.instance.m_musicMixer;
            source.volume = Gain(); return source;
        }
        private float Gain() => (float)BossMusicTimeline.BusGain * userGain * Mathf.Clamp01(MusicMan.m_masterMusicVolume);
        private bool MixerReady => MusicMan.instance && MusicMan.instance.m_musicMixer;
        internal void BeginEncounter()
        {
            Prepare();
            if (!clock.Start(Now + .05)) return;
            Write("BA_BOSS_MUSIC_START: door/candle encounter event; once-only overture and DSP-scheduled combat.");
            ScheduleCurrent();
        }
        internal void CompleteEncounter()
        {
            double start = Now + .03;
            if (!clock.Complete(start)) return;
            Prepare();
            if (!eligible || !enabledByUser || userGain <= 0) { clock.Suspend(); StopSources(); return; }
            if (playbackScheduled)
            {
                // Retain a queued combat entry only when it crosses the fade
                // itself; cut it at the same fade end. Later scheduled loops
                // are cancelled, so they cannot restart after victory.
                if (entrance)
                {
                    if (clock.CombatStartDsp > Now) entrance.SetScheduledEndTime(Math.Min(clock.CombatStartDsp, clock.BattleStopDsp));
                    else Drop(ref entrance);
                }
                if (combat)
                {
                    if (clock.CombatMayStartDuringVictory) combat.SetScheduledEndTime(clock.BattleStopDsp);
                    else combat.Stop();
                }
            }
            Write("BA_BOSS_MUSIC_VICTORY: immediate baked-entry overlap; outgoing cos-squared1.15s; no additional victory fade; one-shot.");
            ScheduleVictory();
        }
        private void ScheduleCurrent()
        {
            if (!ready || !eligible || !enabledByUser || userGain <= 0 || !MixerReady || clock.Suspended) return;
            if (clock.Current == BossMusicTimeline.Phase.Victory) { ScheduleVictory(); return; }
            if (clock.Current != BossMusicTimeline.Phase.Fighting || playbackScheduled) return;
            entrance = Source("entrance", clips["entrance"], false); combat = Source("combat", clips["combat"], true);
            double now = Now, lead = now + .03;
            if (lead < clock.CombatStartDsp)
            {
                double introStart = Math.Max(lead, clock.EntranceStartDsp);
                entrance.timeSamples = (int)Math.Max(0, Math.Round((introStart - clock.EntranceStartDsp) * entrance.clip.frequency));
                entrance.PlayScheduled(introStart); entrance.SetScheduledEndTime(clock.CombatStartDsp);
                combat.PlayScheduled(clock.CombatStartDsp);
            }
            else
            {
                combat.timeSamples = (int)(clock.CombatOffsetSeconds(lead) * combat.clip.frequency);
                combat.PlayScheduled(lead);
            }
            playbackScheduled = true;
        }
        private void ScheduleVictory()
        {
            if (!ready || !eligible || !enabledByUser || userGain <= 0 || !MixerReady || victory || clock.Current != BossMusicTimeline.Phase.Victory) return;
            double start = Math.Max(Now + .03, clock.VictoryStartDsp);
            if (start >= clock.VictoryEndDsp) { clock.Tick(start); return; }
            victory = Source("victory", clips["victory"], false);
            victory.timeSamples = (int)Math.Round(Math.Max(0, start - clock.VictoryStartDsp) * victory.clip.frequency);
            victory.PlayScheduled(start); victory.SetScheduledEndTime(clock.VictoryEndDsp);
        }
        internal void Tick(bool insideBossRoom, float unscaledDelta)
        {
            lastHeartbeat = Time.realtimeSinceStartup;
            eligible = insideBossRoom;
            double now = Now;
            if (lastDsp > now) { StopSources(); clock.Suspend(); }
            lastDsp = now;
            if (!eligible || !enabledByUser || userGain <= 0) Suspend();
            else
            {
                if (clock.Suspended && clock.ResumeCombat(now + .05)) Write("BA_BOSS_MUSIC_RESUME: combat resumes without replaying overture after re-entry.");
                ScheduleCurrent();
            }
            clock.Tick(now);
            float gain = Gain(), battle = (float)clock.BattleGain(now);
            if (entrance) { entrance.volume = gain * battle; if (MixerReady) entrance.outputAudioMixerGroup = MusicMan.instance.m_musicMixer; }
            if (combat) { combat.volume = gain * battle; if (MixerReady) combat.outputAudioMixerGroup = MusicMan.instance.m_musicMixer; }
            if (victory) { victory.volume = gain; if (MixerReady) victory.outputAudioMixerGroup = MusicMan.instance.m_musicMixer; }
            if (clock.Current == BossMusicTimeline.Phase.Victory && now >= clock.BattleStopDsp) StopBattleSources();
            if (clock.Current == BossMusicTimeline.Phase.Finished) StopSources();
            bool playing = ready && eligible && enabledByUser && gain > .00001f && (playbackScheduled || victory) &&
                (clock.Current == BossMusicTimeline.Phase.Fighting && !clock.Suspended || clock.Current == BossMusicTimeline.Phase.Victory);
            ambienceGain = Mathf.MoveTowards(ambienceGain, playing ? .25f : 1f, Math.Max(0, unscaledDelta) / (playing ? .5f : 3f));
        }
        private void Update()
        {
            // The plugin can be disabled independently of this component or
            // fail before its authority heartbeat. Never keep stale 2D music.
            if (eligible && Time.realtimeSinceStartup - lastHeartbeat > .75)
            { eligible = false; Suspend(); ambienceGain = 1; }
        }
        internal void ResetEncounter() { StopSources(); clock.Reset(); ambienceGain = 1; }
        internal void Suspend() { clock.Suspend(); StopSources(); }
        private void StopBattleSources() { Drop(ref entrance); Drop(ref combat); playbackScheduled = false; }
        private void StopSources() { StopBattleSources(); Drop(ref victory); }
        private static void Drop(ref AudioSource source)
        { if (source) { source.Stop(); Destroy(source.gameObject); } source = null; }
        internal void Release()
        {
            ResetEncounter(); eligible = false; ready = false; faulted = false; ++loadEpoch;
            if (request != null) { request.Abort(); request.Dispose(); request = null; }
            if (loading != null) { StopCoroutine(loading); loading = null; }
            var pending = preparation; preparation = null;
            if (pending != null) pending.ContinueWith(t => { if (t.Status == TaskStatus.RanToCompletion) t.Result.Dispose(); else { var ignored = t.Exception; } });
            foreach (var clip in clips.Values) if (clip) Destroy(clip); clips.Clear();
            assets?.Dispose(); assets = null;
        }
        private void Fail(string reason)
        {
            Release(); faulted = true;
            Write("BA_BOSS_MUSIC_UNAVAILABLE: " + reason + "; no room, native music settings or game progression changed.");
        }
        internal void LogStatus(Action<string> write)
        {
            write?.Invoke("BA_BOSS_MUSIC_STATUS: ready=" + ready + "; loading=" + (loading != null) + "; eligible=" + eligible +
                "; phase=" + clock.Current + "; suspended=" + clock.Suspended + "; mixer=" + (MixerReady ? MusicMan.instance.m_musicMixer.name : "not ready") +
                "; nativeMusicMaster=" + MusicMan.m_masterMusicVolume + "; bus=" + BossMusicTimeline.BusGain + "; userGain=" + userGain + "; faulted=" + faulted);
        }
        private void Write(string text) => log?.Invoke(text);
        private void OnDisable() => Release();
        private void OnDestroy() => Release();
    }
}
