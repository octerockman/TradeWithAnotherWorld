using System;
using System.Collections.Generic;
using System.Text;
using Jotunn.Managers;
using UnityEngine;
using UnityEngine.Audio;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // Two client-only voices shared by all abbey doors. Native effect data is
    // read, never instantiated or changed; no network object or door is cloned.
    internal sealed class AbbeyDoorAudio : MonoBehaviour
    {
        internal const string NativeGatePrefab = "darkwood_gate";
        internal const string NativeGateAsset = "Assets/GameElements/Pieces/darkwood_gate.prefab";
        private const double ResolveRetrySeconds = 2;
        private static AbbeyDoorAudio current;

        private sealed class Cue
        {
            internal string Effect, Component;
            internal AudioClip[] Clips;
            internal AudioMixerGroup Mixer;
            internal bool NativeDefaultOutput;
            internal float MinVolume, MaxVolume, MinPitch, MaxPitch;
            internal float MinDistance, MaxDistance, SpatialBlend, Spread, Doppler;
            internal int Priority;
            internal AudioRolloffMode Rolloff;
            internal AnimationCurve RolloffCurve;
        }

        private sealed class Voice
        {
            internal AudioSource Source;
            internal long Order;
        }

        private readonly Voice[] voices = { new Voice(), new Voice() };
        private Cue[] openCues, closeCues;
        private Action<string> log;
        private string lastFailure;
        private double nextResolve;
        private long playOrder;
        private bool disposed;

        internal static void Initialize(GameObject host, Action<string> write)
        {
            Dispose();
            if (!host) { write?.Invoke("BA_DOOR_AUDIO_UNAVAILABLE: plugin host is absent."); return; }
            GameObject root = null;
            try
            {
                root = new GameObject("Black Abbey shared door audio");
                root.SetActive(false); root.transform.SetParent(host.transform, false);
                var owner = root.AddComponent<AbbeyDoorAudio>(); owner.log = write;
                for (int i = 0; i < owner.voices.Length; ++i)
                {
                    var child = new GameObject("Black Abbey door audio voice " + i);
                    child.transform.SetParent(root.transform, false);
                    var source = child.AddComponent<AudioSource>();
                    source.playOnAwake = false; source.loop = false; source.volume = 0;
                    owner.voices[i].Source = source;
                }
                current = owner; root.SetActive(true);
                owner.TryResolve();
            }
            catch (Exception ex)
            {
                if (root) Object.Destroy(root);
                current = null;
                write?.Invoke("BA_DOOR_AUDIO_UNAVAILABLE: " + ex.GetType().Name + ": " + ex.Message + "; door motion remains available.");
            }
        }

        internal static void Play(Vector3 worldPosition, bool opening)
        {
            var owner = current;
            if (!owner || owner.disposed || !owner.isActiveAndEnabled || !owner.gameObject.activeInHierarchy) return;
            try
            {
                if (!owner.TryResolve()) return;
                var cues = opening ? owner.openCues : owner.closeCues;
                // A second overlapping door reuses the oldest voice rather than
                // allocating emitters or allowing unbounded PlayOneShot voices.
                for (int i = 0; i < cues.Length && i < owner.voices.Length; ++i)
                    owner.PlayCue(cues[i], worldPosition);
            }
            catch (Exception ex)
            {
                owner.StopVoices(); owner.openCues = null; owner.closeCues = null;
                owner.nextResolve = Time.realtimeSinceStartup + ResolveRetrySeconds;
                owner.ReportFailure(ex.GetType().Name + ": " + ex.Message);
            }
        }

        private bool TryResolve()
        {
            if (openCues != null && closeCues != null && CuesAlive(openCues) && CuesAlive(closeCues)) return true;
            if (Time.realtimeSinceStartup < nextResolve) return false;
            nextResolve = Time.realtimeSinceStartup + ResolveRetrySeconds;
            try
            {
                var prefab = PrefabManager.Instance.GetPrefab(NativeGatePrefab);
                if (!prefab) throw new InvalidOperationException("Native " + NativeGatePrefab + " prefab is not ready; retry on a later door interaction.");
                var door = prefab.GetComponent<Door>();
                if (!door) throw new InvalidOperationException("Native " + NativeGatePrefab + " Door component is absent.");
                var opening = ReadCues(door.m_openEffects, "open");
                var closing = ReadCues(door.m_closeEffects, "close");
                if (opening.Length == 0 || closing.Length == 0)
                    throw new InvalidOperationException("Native darkwood gate must supply separate playable opening and closing effects.");
                openCues = opening; closeCues = closing; lastFailure = null;
                LogBindings("open", openCues); LogBindings("close", closeCues);
                return true;
            }
            catch (Exception ex)
            {
                openCues = null; closeCues = null;
                ReportFailure(ex.GetType().Name + ": " + ex.Message);
                return false;
            }
        }

        private static Cue[] ReadCues(EffectList effects, string action)
        {
            var result = new List<Cue>();
            if (effects == null || effects.m_effectPrefabs == null) return result.ToArray();
            foreach (var effect in effects.m_effectPrefabs)
            {
                if (!effect.m_enabled || !effect.m_prefab) continue;
                foreach (var component in effect.m_prefab.GetComponentsInChildren<ZSFX>(true))
                {
                    if (!component || component.m_audioClips == null || component.m_audioClips.Length == 0) continue;
                    var template = component.GetComponent<AudioSource>();
                    if (!template)
                        throw new InvalidOperationException("Native " + action + " effect has no AudioSource: " + effect.m_prefab.name + "/" + component.name);
                    var clips = new List<AudioClip>();
                    foreach (var clip in component.m_audioClips)
                        if (clip && clip.length > 0) clips.Add(clip);
                    if (clips.Count == 0) continue;
                    if (!Finite(component.m_minVol) || !Finite(component.m_maxVol) || !Finite(component.m_minPitch) || !Finite(component.m_maxPitch) ||
                        component.m_minVol < 0 || component.m_maxVol < component.m_minVol || component.m_minPitch <= 0 || component.m_maxPitch < component.m_minPitch)
                        throw new InvalidOperationException("Native darkwood gate volume/pitch range is invalid: " + effect.m_prefab.name);
                    result.Add(new Cue {
                        Effect = effect.m_prefab.name, Component = component.name, Clips = clips.ToArray(), Mixer = template.outputAudioMixerGroup,
                        NativeDefaultOutput = !template.outputAudioMixerGroup,
                        MinVolume = component.m_minVol, MaxVolume = component.m_maxVol, MinPitch = component.m_minPitch, MaxPitch = component.m_maxPitch,
                        MinDistance = template.minDistance, MaxDistance = template.maxDistance, SpatialBlend = template.spatialBlend,
                        Spread = template.spread, Doppler = template.dopplerLevel, Priority = template.priority, Rolloff = template.rolloffMode,
                        RolloffCurve = template.rolloffMode == AudioRolloffMode.Custom ? template.GetCustomCurve(AudioSourceCurveType.CustomRolloff) : null
                    });
                }
            }
            if (result.Count > 2)
                throw new InvalidOperationException("Native darkwood gate " + action + " exceeds the two-voice effect budget; native source data is left untouched.");
            return result.ToArray();
        }

        private static bool CuesAlive(Cue[] cues)
        {
            foreach (var cue in cues)
            {
                if (!cue.NativeDefaultOutput && !cue.Mixer) return false;
                foreach (var clip in cue.Clips) if (!clip) return false;
            }
            return true;
        }

        private void PlayCue(Cue cue, Vector3 position)
        {
            Voice selected = null;
            foreach (var voice in voices)
            {
                if (!voice.Source) continue;
                if (!voice.Source.isPlaying) { selected = voice; break; }
                if (selected == null || voice.Order < selected.Order) selected = voice;
            }
            if (selected == null) return;
            var source = selected.Source;
            source.Stop(); source.transform.position = position;
            source.outputAudioMixerGroup = cue.Mixer;
            source.clip = cue.Clips[UnityEngine.Random.Range(0, cue.Clips.Length)];
            // These are the same uniform ranges ZSFX.Play applies to the native
            // effect. No global volume is multiplied or set by this helper.
            source.volume = UnityEngine.Random.Range(cue.MinVolume, cue.MaxVolume);
            source.pitch = UnityEngine.Random.Range(cue.MinPitch, cue.MaxPitch);
            source.spatialBlend = cue.SpatialBlend; source.minDistance = cue.MinDistance; source.maxDistance = cue.MaxDistance;
            source.rolloffMode = cue.Rolloff;
            if (cue.RolloffCurve != null) source.SetCustomCurve(AudioSourceCurveType.CustomRolloff, cue.RolloffCurve);
            source.spread = cue.Spread; source.dopplerLevel = cue.Doppler; source.priority = cue.Priority;
            source.loop = false; source.mute = false; selected.Order = ++playOrder;
            source.Play();
        }

        private void LogBindings(string action, Cue[] cues)
        {
            foreach (var cue in cues)
            {
                var clips = new StringBuilder();
                foreach (var clip in cue.Clips)
                {
                    if (clips.Length > 0) clips.Append(',');
                    clips.Append(clip.name).Append('#').Append(clip.GetInstanceID());
                }
                log?.Invoke("BA_DOOR_AUDIO_BOUND: native-door=" + NativeGatePrefab + "; asset=" + NativeGateAsset + "; action=" + action +
                    "; native-effect=" + cue.Effect + "; ZSFX=" + cue.Component + "; clips=" + clips + "; mixer=" + (cue.Mixer ? cue.Mixer.name : "native-default-output") +
                    "; volume=" + cue.MinVolume + ".." + cue.MaxVolume + "; pitch=" + cue.MinPitch + ".." + cue.MaxPitch +
                    "; spatial=" + cue.SpatialBlend + "; distance=" + cue.MinDistance + ".." + cue.MaxDistance + "; shared-voice-budget=2.");
            }
        }

        private void ReportFailure(string message)
        {
            if (lastFailure == message) return;
            lastFailure = message;
            log?.Invoke("BA_DOOR_AUDIO_WAITING: " + message + "; retryable; door motion remains available.");
        }

        internal static void StopAll() { if (current) current.StopVoices(); }

        private void StopVoices()
        {
            foreach (var voice in voices)
                if (voice.Source) { voice.Source.Stop(); voice.Source.clip = null; }
        }

        internal static void Dispose()
        {
            var owner = current; current = null;
            if (!owner || owner.disposed) return;
            owner.disposed = true; owner.StopVoices(); owner.openCues = null; owner.closeCues = null;
            Object.Destroy(owner.gameObject);
        }

        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        private void OnDisable() { StopVoices(); }
        private void OnDestroy()
        {
            disposed = true; StopVoices(); openCues = null; closeCues = null;
            if (ReferenceEquals(current, this)) current = null;
        }
    }
}
