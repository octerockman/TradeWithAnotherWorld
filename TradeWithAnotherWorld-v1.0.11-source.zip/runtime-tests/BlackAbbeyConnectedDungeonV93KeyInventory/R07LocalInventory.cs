using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using Jotunn.Managers;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // The real InventoryGui accepts Container, but installed Container.Awake
    // dereferences ZNetView. These prefixes apply ONLY to this explicit marker.
    // No ZNetView, ZDO, RPC, game save record or vanilla container is modified.
    public sealed class R07LocalInventory : MonoBehaviour
    {
        internal Inventory Inventory;
        internal Container Container;
        internal Action<bool> Used;
        internal bool InUse;
        internal static R07LocalInventory Create(Transform parent, Vector3 position, Inventory inventory, Action<bool> used)
        {
            var host = new GameObject("R07 local native inventory | " + inventory.GetName()); host.SetActive(false);
            host.transform.SetParent(parent, false); host.transform.localPosition = position;
            var marker = host.AddComponent<R07LocalInventory>(); marker.Inventory = inventory; marker.Used = used;
            R07InventoryPatches.Register(inventory);
            marker.Container = host.AddComponent<Container>(); marker.Container.m_name = inventory.GetName();
            marker.Container.m_bkg = inventory.GetBkg();
            marker.Container.m_width = inventory.GetWidth(); marker.Container.m_height = inventory.GetHeight();
            marker.Container.m_checkGuardStone = false; marker.Container.m_autoDestroyEmpty = false;
            // Finish Awake (including other mods' postfixes) before publishing
            // the local Inventory. Native Container.Awake also leaves this
            // null for an invalid/unnetworked container. SmartContainers uses
            // that native null-inventory guard before dereferencing m_nview.
            // Binding it inside our Awake prefix made its postfix see a valid
            // inventory paired with no network view and throw on every box.
            host.SetActive(true);
            R07InventoryPatches.SetInventory(marker.Container, inventory);
            return marker;
        }
        internal void Show()
        {
            if (!InventoryGui.instance || !Container) throw new InvalidOperationException("The native inventory screen is not ready.");
            R07InventoryPatches.SetInventory(Container, Inventory);
            InventoryGui.instance.Show(Container, 1);
        }
        private void OnDisable()
        {
            if (Container && R07InventoryPatches.IsCurrent(Container) && InventoryGui.instance) InventoryGui.instance.Hide();
            InUse = false;
        }
        private void OnDestroy() { if (Inventory != null) R07InventoryPatches.Unregister(Inventory); }
        internal static Inventory SeededInventory(string id, int width, int height, int seed)
        {
            var inventory=EmptyInventory(id,width,height);
            var random = new System.Random(seed);
            // Provisional loot only. Roll once per container/run; ordinary native
            // item transfers mutate this retained Inventory without a refill.
            foreach (string item in new[] { "Coins", "Amber", "Resin", "BoneFragments" })
            {
                if (inventory.GetEmptySlots() == 0) break;
                if (item != "Coins" && random.Next(2) == 0) continue;
                var prefab = PrefabManager.Instance.GetPrefab(item);
                if (!prefab || !prefab.GetComponent<ItemDrop>()) throw new InvalidOperationException("Placeholder loot prefab is unavailable: " + item);
                if (!inventory.AddItem(prefab, item == "Coins" ? random.Next(3, 13) : random.Next(1, 4))) throw new InvalidOperationException("Placeholder loot exceeds the source container capacity.");
            }
            return inventory;
        }
        internal static Inventory EmptyInventory(string id,int width,int height)
        {
            if(!(id=="chest"||id=="coffin"||id=="secret-box")||width<2||width>8||height<1||height>4)
                throw new ArgumentException("Invalid source shrine inventory dimensions/identity.");
            var vanillaChest = PrefabManager.Instance.GetPrefab("piece_chest_wood");
            var nativeContainer = vanillaChest ? vanillaChest.GetComponent<Container>() : null;
            // Borrow the existing vanilla UI sprite, never clone/destroy it.
            // Current native grid paths do not require a nonnull background,
            // but retaining the source value also matches normal Container data.
            return new Inventory(id == "secret-box" ? "Hidden box" : id == "coffin" ? "Stone coffin" : "Ironbound chest", nativeContainer ? nativeContainer.m_bkg : null, width, height);
        }
    }

    internal static class R07InventoryPatches
    {
        private static Harmony harmony;
        private static readonly Dictionary<Inventory, int> owned = new Dictionary<Inventory, int>();
        internal static void Register(Inventory value) { owned.TryGetValue(value, out int count); owned[value] = count + 1; }
        internal static void Unregister(Inventory value) { if (owned.TryGetValue(value, out int count)) { if (count == 1) owned.Remove(value); else owned[value] = count - 1; } }
        private static readonly FieldInfo inventory = AccessTools.Field(typeof(Container), "m_inventory"), inUse = AccessTools.Field(typeof(Container), "m_inUse");
        private static readonly FieldInfo current = AccessTools.Field(typeof(InventoryGui), "m_currentContainer");
        internal static bool IsCurrent(Container value) => InventoryGui.instance && ReferenceEquals(current?.GetValue(InventoryGui.instance), value);
        internal static void SetInventory(Container container, Inventory value) => inventory.SetValue(container, value);
        internal static void Install()
        {
            if (harmony != null) return;
            if (inventory?.FieldType != typeof(Inventory) || inUse?.FieldType != typeof(bool) || current?.FieldType != typeof(Container)) throw new MissingFieldException("Installed Container local adapter contract changed.");
            harmony = new Harmony(RuntimeTestPlugin.Id + ".r07-local-inventory");
            foreach (var pair in new[] { new[] { "Awake", "Awake" }, new[] { "IsOwner", "Owner" }, new[] { "SetInUse", "Use" }, new[] { "StackAll", "Stack" }, new[] { "TakeAll", "Take" } })
                harmony.Patch(AccessTools.Method(typeof(Container), pair[0]), prefix: new HarmonyMethod(typeof(R07InventoryPatches), pair[1]));
            // Awake omits network subscriptions/invokes, but also guard these
            // private callbacks if another caller explicitly invokes one.
            foreach (string method in new[] { "OnContainerChanged", "Save", "Load", "CheckForChanges", "Interact", "OnDestroyed" })
                harmony.Patch(AccessTools.Method(typeof(Container), method), prefix: new HarmonyMethod(typeof(R07InventoryPatches), nameof(Ignore)));
            harmony.Patch(AccessTools.Method(typeof(Humanoid), "DropItem", new[] { typeof(Inventory), typeof(ItemDrop.ItemData), typeof(int) }), prefix: new HarmonyMethod(typeof(R07InventoryPatches), nameof(Drop)));
        }
        private static R07LocalInventory Marker(Container c) => c ? c.GetComponent<R07LocalInventory>() : null;
        private static bool Ignore(Container __instance) => !Marker(__instance);
        private static bool Drop(Humanoid __instance, Inventory __0, ref bool __result)
        {
            if (__0 == null || !owned.ContainsKey(__0)) return true;
            // Native drag-transfer remains available. Dropping directly from a
            // temporary test container must not spawn a persistent world item.
            __result = false;
            if (__instance == Player.m_localPlayer) __instance.Message(MessageHud.MessageType.Center, "Move the item into your inventory first.");
            return false;
        }
        private static bool Awake(Container __instance)
        {
            var marker = Marker(__instance); if (!marker) return true;
            if (marker.Inventory == null) throw new InvalidOperationException("Local shrine inventory must be configured before activation.");
            // Do not expose m_inventory until the complete Awake patch chain
            // has returned. Create binds the retained local inventory directly
            // afterward; no dummy ZNetView or persistent container is needed.
            __instance.enabled = false; return false;
        }
        private static bool Owner(Container __instance, ref bool __result)
        { if (!Marker(__instance)) return true; __result = true; return false; }
        private static bool Use(Container __instance, bool inUse)
        {
            var marker = Marker(__instance); if (!marker) return true;
            R07InventoryPatches.inUse.SetValue(__instance, inUse);
            if (marker.InUse != inUse) { marker.InUse = inUse; marker.Used?.Invoke(inUse); }
            return false;
        }
        private static bool Stack(Container __instance)
        {
            var marker = Marker(__instance); if (!marker) return true;
            if (Player.m_localPlayer) marker.Inventory.StackAll(Player.m_localPlayer.GetInventory(), true);
            return false;
        }
        private static bool Take(Container __instance, Humanoid character, ref bool __result)
        {
            var marker = Marker(__instance); if (!marker) return true;
            __result = character && character == Player.m_localPlayer;
            if (__result) character.GetInventory().MoveAll(marker.Inventory);
            return false;
        }
    }
}
