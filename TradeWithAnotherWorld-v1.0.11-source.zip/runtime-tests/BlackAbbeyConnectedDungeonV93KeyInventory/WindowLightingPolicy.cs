namespace BlackAbbeySixRooms
{
    internal static class WindowLightingPolicy
    {
        internal static bool Enabled(string sourceRoomId) => sourceRoomId != "R09" && !R09SplitIdentity.IsPiece(sourceRoomId);
    }
}
