namespace BlackAbbeySixRooms
{
    // Absence is a conclusion only after a complete fresh scan in the same
    // generation. Any uncertainty or inventory mutation revokes it.
    internal sealed class FalseVowsPresenceWindow
    {
        internal long Generation { get; private set; }
        private long scanningGeneration = -1;
        private bool complete, uncertain;
        internal bool Complete => complete;
        internal void Invalidate() { Generation++; scanningGeneration = -1; complete = false; uncertain = false; }
        internal void Start() { scanningGeneration = Generation; complete = false; uncertain = false; }
        internal void Uncertain() { uncertain = true; }
        internal void Finish() { complete = true; }
        internal bool? Absence(bool scopeValid, bool profilesChecked, bool externalAbsent, bool fresh)
            => scopeValid && profilesChecked && externalAbsent && fresh && complete && !uncertain && scanningGeneration == Generation ? false : (bool?)null;
    }
}
