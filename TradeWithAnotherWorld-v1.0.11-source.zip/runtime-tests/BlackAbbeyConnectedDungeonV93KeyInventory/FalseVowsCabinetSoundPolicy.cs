using System;
namespace BlackAbbeySixRooms
{
    internal sealed class FalseVowsCabinetSoundGate
    {
        internal const double UnlockLeadSeconds=.40;
        private bool pending;
        private double earliest;
        internal void Request(double now,double delay)
        {
            if(double.IsNaN(now)||double.IsInfinity(now)||double.IsNaN(delay)||double.IsInfinity(delay)||delay<0||delay>1)throw new ArgumentException("Invalid cabinet sound schedule.");
            pending=true;earliest=now+delay;
        }
        internal bool CanAdvance(double now)=>now>=earliest;
        internal bool BeginMotion(double now)
        {
            if(!pending||!CanAdvance(now))return false;
            pending=false;return true;
        }
        internal static bool NewlyUnlocked(bool before,bool after)=>!before&&after;
    }
}
