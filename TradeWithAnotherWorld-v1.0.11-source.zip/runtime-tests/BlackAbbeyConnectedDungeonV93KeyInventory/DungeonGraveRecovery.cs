using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        // Explicit user-run rescue for graves left below an older despawned
        // room. Never creates a grave, edits its inventory, or moves a player.
        private void RecoverDungeonGrave()
        {
            if (busy) { Print("Wait for the current dungeon transition before recovering a grave."); return; }
            if (!LocalPlayer(out var player) || !Matches(player) || player.IsDead() ||
                dungeonPlan == null || rooms.Count == 0 || rooms.Values.Any(r => !r.Root) ||
                ZDOMan.instance == null || !ZNetScene.instance || !player.m_tombstone)
            {
                Print("Rebuild/re-enter the original dungeon seed with this character first. No grave or items changed."); return;
            }
            var session = new GraveRecoverySession
            {
                Player = player, Network = ZNet.instance, Store = ZDOMan.instance, Scene = ZNetScene.instance,
                Plan = dungeonPlan, World = WorldKey(), PlayerId = player.GetPlayerID(),
                PrefabName = player.m_tombstone.name, Started = Time.unscaledTime
            };
            if (string.IsNullOrWhiteSpace(session.World) || session.PlayerId == 0 || string.IsNullOrWhiteSpace(session.PrefabName))
            { Print("Native grave or character/world identity is not ready. Nothing changed."); return; }
            session.PrefabHash = session.PrefabName.GetStableHashCode();
            busy = true;
            try { StartCoroutine(RecoverDungeonGraveRoutine(session)); }
            catch { busy = false; throw; }
        }

        private sealed class GraveRecoverySession
        {
            internal Player Player;
            internal ZNet Network;
            internal ZDOMan Store;
            internal ZNetScene Scene;
            internal DungeonPlan Plan;
            internal string World, PrefabName;
            internal long PlayerId;
            internal int PrefabHash;
            internal float Started;
        }

        private bool SameGraveRecoverySession(GraveRecoverySession session) =>
            session.Player && !session.Player.IsDead() && Player.m_localPlayer == session.Player &&
            ZNet.instance == session.Network && session.Network && session.Network.IsServer() &&
            ReferenceEquals(ZDOMan.instance, session.Store) && ZNetScene.instance == session.Scene && session.Scene &&
            ReferenceEquals(dungeonPlan, session.Plan) && rooms.Count != 0 && rooms.Values.All(r => r.Root) &&
            session.Player.GetPlayerID() == session.PlayerId && WorldKey() == session.World && Matches(session.Player);

        private bool InsideGraveRecoveryRun(Vector3 point) =>
            FindContainingRoom(point) != null || InsideDungeonPassage(point);

        private bool GraveRecoveryFloor(Vector3 spawn)
        {
            if (!RoomPackage.Finite(spawn.x) || !RoomPackage.Finite(spawn.y) || !RoomPackage.Finite(spawn.z) ||
                !InsideGraveRecoveryRun(spawn)) return false;
            int mask = LayerMask.GetMask("static_solid");
            if (mask == 0) return false;
            // A grave starts at the native dead player's centre. Verify actual
            // loaded room support under that original point and its footprint.
            var offsets = new[] { Vector3.zero, Vector3.right * .18f, Vector3.left * .18f,
                Vector3.forward * .18f, Vector3.back * .18f };
            float low = float.PositiveInfinity, high = float.NegativeInfinity;
            foreach (var offset in offsets)
            {
                if (!Physics.Raycast(spawn + offset + Vector3.up * .25f, Vector3.down, out var hit, 2.75f, mask, QueryTriggerInteraction.Ignore) ||
                    !hit.collider || hit.normal.y < .9f || hit.point.y >= spawn.y - .05f ||
                    !InsideGraveRecoveryRun(hit.point + Vector3.up * .05f) ||
                    !(rooms.Values.Any(r => r.Root && hit.collider.transform.IsChildOf(r.Root.transform)) ||
                      (dungeonArt && hit.collider.transform.IsChildOf(dungeonArt.transform)))) return false;
                low = Mathf.Min(low, hit.point.y); high = Mathf.Max(high, hit.point.y);
            }
            return high - low <= .25f;
        }

        private bool TryRestoreNativeDungeonGrave(GraveRecoverySession session, ZDO scanned, out string refusal)
        {
            refusal = null;
            try
            {
                if (!SameGraveRecoverySession(session)) { refusal = "session changed"; return false; }
                var grave = scanned == null ? null : session.Store.GetZDO(scanned.m_uid);
                if (grave == null || !grave.IsValid() || grave.GetPrefab() != session.PrefabHash ||
                    grave.GetLong(ZDOVars.s_owner, 0L) != session.PlayerId)
                { refusal = "not this character's existing native grave"; return false; }
                Vector3 original = grave.GetVec3(ZDOVars.s_spawnPoint, new Vector3(float.NaN, float.NaN, float.NaN));
                if (!RoomPackage.Finite(original.x) || !RoomPackage.Finite(original.y) || !RoomPackage.Finite(original.z))
                { refusal = "native original spawn point is unavailable"; return false; }
                if (!(InsideGraveRecoveryRun(grave.GetPosition()) || InsideGraveRecoveryRun(original)))
                { refusal = "grave belongs outside this loaded run"; return false; }
                if (!GraveRecoveryFloor(original))
                { refusal = "original spawn point has no verified room floor; rebuild the original layout seed"; return false; }
                if (!SameGraveRecoverySession(session)) { refusal = "session changed"; return false; }
                var instance = session.Scene.FindInstance(grave.m_uid);
                if (instance)
                {
                    var view = instance.GetComponent<ZNetView>();
                    if (!instance.GetComponent<TombStone>() || !view || !view.IsValid() ||
                        view.GetZDO() == null || !view.GetZDO().m_uid.Equals(grave.m_uid))
                    { refusal = "loaded grave identity is unavailable"; return false; }
                    view.ClaimOwnership();
                    if (!view.IsOwner() || !SameGraveRecoverySession(session))
                    { refusal = "host ownership or session changed"; return false; }
                    var body = instance.GetComponent<Rigidbody>();
                    if (body)
                    {
                        body.position = original; body.linearVelocity = Vector3.zero;
                        body.angularVelocity = Vector3.zero; body.WakeUp();
                    }
                    instance.transform.position = original;
                }
                else
                {
                    // Host authority is required for the already-existing saved
                    // ZDO. No object is instantiated to change its position.
                    grave.SetOwner(ZDOMan.GetSessionID());
                    if (!grave.IsOwner() || !SameGraveRecoverySession(session))
                    { refusal = "host ownership or session changed"; return false; }
                }
                grave.SetPosition(original);
                return true;
            }
            catch (Exception ex)
            { refusal = "native grave recovery refused: " + ex.Message; return false; }
        }

        private IEnumerator RecoverDungeonGraveRoutine(GraveRecoverySession session)
        {
            int cursor = 0, steps = 0, matching = 0, restored = 0, refused = 0;
            string lastRefusal = null;
            var batch = new List<ZDO>(); var seen = new HashSet<ZDOID>();
            try
            {
                Print("Checking existing native graves against loaded dungeon seed " + session.Plan.Seed + ". Only their own original supported positions can be restored.");
                while (true)
                {
                    if (!SameGraveRecoverySession(session))
                    { Print("Grave recovery stopped: player, world or loaded dungeon changed. Restored " + restored + "."); yield break; }
                    if (++steps > 4096 || Time.unscaledTime - session.Started > 60f)
                    { Print("Grave recovery reached its scan limit. Restored " + restored + "; retry when ready. No items or player position changed."); yield break; }
                    bool complete = false; string error = null;
                    try { complete = session.Store.GetAllZDOsWithPrefabIterative(session.PrefabName, batch, ref cursor); }
                    catch (Exception ex) { error = ex.Message; }
                    if (error != null) { Print("Native grave scan failed safely: " + error + ". Restored " + restored + "."); yield break; }
                    foreach (var grave in batch)
                    {
                        if (!SameGraveRecoverySession(session))
                        { Print("Grave recovery stopped after a session change. Restored " + restored + "."); yield break; }
                        if (grave == null || !grave.IsValid() || grave.GetPrefab() != session.PrefabHash ||
                            grave.GetLong(ZDOVars.s_owner, 0L) != session.PlayerId || !seen.Add(grave.m_uid)) continue;
                        if (seen.Count > 8192) { Print("Grave recovery saved-record limit reached; restored " + restored + "."); yield break; }
                        Vector3 current = grave.GetPosition(), original = grave.GetVec3(ZDOVars.s_spawnPoint, current);
                        if (!InsideGraveRecoveryRun(current) && !InsideGraveRecoveryRun(original)) continue;
                        if (++matching > 128) { Print("Grave recovery candidate limit reached; restored " + restored + "."); yield break; }
                        if (TryRestoreNativeDungeonGrave(session, grave, out var reason)) restored++;
                        else { refused++; lastRefusal = reason; }
                    }
                    batch.Clear();
                    if (complete) break;
                    yield return null; // Exactly one native scan slice per frame.
                }
                Print("Native grave recovery: restored " + restored + ", refused " + refused + ", matching existing graves " + matching +
                    "; current seed " + session.Plan.Seed + ". No inventory, player position or original grave spawn point changed." +
                    (lastRefusal == null ? "" : " Last refusal: " + lastRefusal + "."));
            }
            finally { batch.Clear(); busy = false; }
        }
    }
}
