using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlackAbbeySixRooms
{
    internal sealed class WardingActorLedger
    {
        public int schemaVersion=1,seed;
        public string runId,worldKey;
        public List<WardingActorRecord> actors=new List<WardingActorRecord>();
    }
    internal sealed class WardingActorRecord
    {
        public string key,sourceId,productionSourceId,prefab,state="Pending";
        public bool borrowed,returned;
        public long uidUser;
        public uint uidId;
        public float[] position,rotation,mouth,hidden,innerDoor,exit;
        public float? health;
        public string journey="None";
        public float journeyElapsed,journeySeconds=8;
        public List<WardingEffectRecord> effects=new List<WardingEffectRecord>();
    }
    internal sealed class WardingEffectRecord
    {
        public string name,type;
        public List<WardingEffectScalar> scalars=new List<WardingEffectScalar>();
    }
    internal sealed class WardingEffectScalar
    { public string declaringType,field,type,value; }
    internal static class WardingHallProjectionMath
    {
        internal static void Map(double virtualDepth,out double physicalDepth,out double scale)
        {
            if(double.IsNaN(virtualDepth)||double.IsInfinity(virtualDepth)||virtualDepth<0||virtualDepth>17.96)throw new ArgumentOutOfRangeException(nameof(virtualDepth));
            physicalDepth=virtualDepth;scale=1;
            if(virtualDepth>2.12){double u=(virtualDepth-2.12)/15.84;physicalDepth=2.12+1.57*(1-Math.Exp(-3*u))/(1-Math.Exp(-3));scale=(physicalDepth+4.2)/(virtualDepth+4.2);}
        }
    }

    // Separate ledger: source production never refills ordinary encounter slots.
    internal static class WardingSpawnerActorPersistence
    {
        internal const int MaximumActors=160,MaximumEffects=32,MaximumScalars=192;
        internal static readonly string[] States={"Pending","Alive","Dead","Missing"};
        internal static readonly string[] Journeys={"None","Entering","Away","Returning","Blocked","Exiting","Emerging","Clearing","Completed","Died"};
        static JsonSerializer Serializer()=>JsonSerializer.Create(new JsonSerializerSettings{
            TypeNameHandling=TypeNameHandling.None,MetadataPropertyHandling=MetadataPropertyHandling.Ignore,
            DateParseHandling=DateParseHandling.None,MaxDepth=24});
        internal static JObject ToJson(WardingActorLedger value)=>value==null?null:JObject.FromObject(value,Serializer());
        internal static WardingActorLedger Copy(WardingActorLedger value)=>value==null?null:ToJson(value).ToObject<WardingActorLedger>(Serializer());
        internal static WardingActorLedger Read(JObject value,string runId,string world,int seed)
        {
            if(value==null)return null;
            if(value.ToString(Formatting.None).Length>768*1024)throw new InvalidDataException("Spawner actor ledger exceeds its bounded save budget.");
            Envelope<WardingActorLedger>(value);
            if(!(value["actors"] is JArray actors))throw new InvalidDataException("Spawner actor array missing.");
            foreach(var token in actors)
            {
                if(!(token is JObject actor))throw new InvalidDataException("Invalid actor record object.");Envelope<WardingActorRecord>(actor);
                if(!(actor["effects"] is JArray effects))throw new InvalidDataException("Actor effects array missing.");
                foreach(var item in effects){if(!(item is JObject effect))throw new InvalidDataException("Invalid effect object.");Envelope<WardingEffectRecord>(effect);
                    if(!(effect["scalars"] is JArray scalars))throw new InvalidDataException("Status scalar array missing.");
                    foreach(var scalar in scalars){if(!(scalar is JObject field))throw new InvalidDataException("Invalid status scalar object.");Envelope<WardingEffectScalar>(field);}}
            }
            var result=value.ToObject<WardingActorLedger>(Serializer());Validate(result,runId,world,seed);return result;
        }
        static void Envelope<T>(JObject value)
        {var names=new HashSet<string>(typeof(T).GetFields().Select(f=>f.Name),StringComparer.Ordinal);if(value.Properties().Any(p=>!names.Contains(p.Name)))throw new InvalidDataException("Unrecognized "+typeof(T).Name+" field.");}
        static bool Text(string s,int maximum=128)=>!string.IsNullOrWhiteSpace(s)&&s.Length<=maximum&&!s.Any(char.IsControl);
        static bool Finite(float f)=>!float.IsNaN(f)&&!float.IsInfinity(f);
        static bool Vector(float[] v,int length)=>v!=null&&v.Length==length&&v.All(x=>Finite(x)&&Math.Abs(x)<=100000);
        internal static bool ValidPose(float[] position,float[] rotation)=>Vector(position,3)&&Vector(rotation,4)&&rotation.Sum(x=>(double)x*x)>=.9&&rotation.Sum(x=>(double)x*x)<=1.1;
        internal static bool AllowedPrefab(string n)=>n=="TWA_HushedMonk_Test"||n=="BA_ReliquaryGuard"||n=="BA_CenserBrother";
        // Only a completed exact-tag native query can resolve the crash window
        // between a durable reservation and native Instantiate. Consuming this
        // key does not spawn a replacement or revive a missing positive UID.
        internal static bool CancelUncreatedPending(WardingActorRecord actor,int exactMatches,bool scanComplete)=>
            scanComplete&&exactMatches==0&&actor!=null&&!actor.borrowed&&actor.state=="Pending"&&actor.uidUser==0&&actor.uidId==0;
        internal static void Validate(WardingActorLedger value,string runId,string world,int seed)
        {
            if(value==null||value.schemaVersion!=1||value.runId!=runId||!Text(runId,160)||value.worldKey!=world||!Text(world,4096)||value.seed!=seed||
                value.actors==null||value.actors.Count>MaximumActors||value.actors.Any(a=>a==null))throw new InvalidDataException("Spawner actor ledger identity/schema differs.");
            var keys=new HashSet<string>(StringComparer.Ordinal);var ids=new HashSet<string>(StringComparer.Ordinal);
            foreach(var a in value.actors)
            {
                if(!Text(a.key,192)||!keys.Add(a.key)||!Text(a.sourceId)||!a.borrowed&&!Text(a.productionSourceId)||!AllowedPrefab(a.prefab)||!States.Contains(a.state)||!Journeys.Contains(a.journey)||
                    (a.uidUser==0)!=(a.uidId==0)||!Finite(a.journeyElapsed)||a.journeyElapsed<0||a.journeyElapsed>86400||!Finite(a.journeySeconds)||a.journeySeconds<1||a.journeySeconds>120||
                    a.health.HasValue&&(!Finite(a.health.Value)||a.health.Value<0||a.health.Value>1000000))throw new InvalidDataException("Invalid spawner actor identity/state.");
                bool uid=a.uidUser!=0;
                if(uid&&(!ids.Add(a.uidUser+":"+a.uidId)||!Vector(a.position,3)||!Vector(a.rotation,4)||a.rotation.Sum(x=>(double)x*x)<.9||a.rotation.Sum(x=>(double)x*x)>1.1)||
                    !uid&&(a.state=="Alive"||a.borrowed)||a.borrowed&&a.prefab!="TWA_HushedMonk_Test")throw new InvalidDataException("Invalid or repeated spawner actor UID/transform.");
                bool travelling=a.journey!="None"&&a.journey!="Completed"&&a.journey!="Died";
                bool emergence=a.journey=="Emerging"||a.journey=="Clearing";
                if(emergence&&(a.borrowed||a.returned))throw new InvalidDataException("Only a produced actor may emerge from the source hall.");
                if(travelling&&(!uid||!Vector(a.mouth,3)||!Vector(a.hidden,3)||!Vector(a.innerDoor,3)||!Vector(a.exit,3)||!emergence&&a.prefab!="TWA_HushedMonk_Test"))
                    throw new InvalidDataException("Invalid fetching monk path.");
                if(a.returned&&a.journey!="Blocked"&&a.journey!="Exiting"&&a.journey!="Completed"&&a.journey!="Died")throw new InvalidDataException("Premature reinforcement return flag.");
                if(a.effects==null||a.effects.Count>MaximumEffects||a.effects.Any(e=>e==null||!Text(e.name,160)||!Text(e.type,256)||e.scalars==null||e.scalars.Count>MaximumScalars))
                    throw new InvalidDataException("Invalid spawner status-effect snapshot.");
                foreach(var effect in a.effects)
                {
                    var names=new HashSet<string>(StringComparer.Ordinal);
                    foreach(var f in effect.scalars)
                    {
                        if(f==null||!Text(f.declaringType,256)||!Text(f.field)||!names.Add(f.declaringType+"|"+f.field)||!Text(f.value,64)||f.type!="f"&&f.type!="i"&&f.type!="b")
                            throw new InvalidDataException("Invalid saved status scalar.");
                        if(f.type=="f"&&(!float.TryParse(f.value,NumberStyles.Float,CultureInfo.InvariantCulture,out float n)||!Finite(n)||Math.Abs(n)>100000000)||
                            f.type=="i"&&!int.TryParse(f.value,NumberStyles.Integer,CultureInfo.InvariantCulture,out _)||f.type=="b"&&!bool.TryParse(f.value,out _))
                            throw new InvalidDataException("Invalid saved status scalar value.");
                    }
                }
            }
        }
    }
}
