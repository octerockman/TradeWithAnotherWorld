using System;
using System.IO;

namespace BlackAbbeySixRooms
{
    // Counts only time inside the dungeon while a real bell fixture is loaded.
    // Every dungeon room can hear it; listener distance never gates this clock.
    // A due opportunity survives loading, busy voices and room
    // changes; only a successful source.Play may commit MarkPlayed.
    internal sealed class BellOpportunityClock
    {
        private bool started;
        private double remaining;
        private int playedCount;

        internal double Remaining => remaining;
        internal bool IsDue => started && remaining == 0;
        internal int PlayedCount => playedCount;

        internal void Reset(double firstDelay)
        {
            RequireDelay(firstDelay, nameof(firstDelay));
            remaining = firstDelay;
            started = true;
            playedCount = 0;
        }

        internal void Advance(double elapsed, bool inside, bool hasLoadedBell)
        {
            if (!started || !inside || !hasLoadedBell || IsDue ||
                double.IsNaN(elapsed) || double.IsInfinity(elapsed) || elapsed <= 0) return;
            remaining = elapsed >= remaining ? 0 : remaining - elapsed;
        }

        internal void MarkPlayed(double nextDelay)
        {
            RequireDelay(nextDelay, nameof(nextDelay));
            if (!IsDue) throw new InvalidOperationException("A bell opportunity is consumed only after a due cue plays.");
            remaining = nextDelay;
            ++playedCount;
        }

        private static void RequireDelay(double delay, string name)
        {
            if (double.IsNaN(delay) || double.IsInfinity(delay) || delay <= 0)
                throw new ArgumentOutOfRangeException(name, "Bell delays must be finite positive seconds.");
        }
    }

    // Runtime and offline regression tests share these exact local source
    // gains, deterministic fixture tones and randomized eligible-time delays.
    internal static class AbbeyAmbienceBalance
    {
        internal const float AirGain = 2f;
        internal const float ShaftGain = 1.4f;
        internal const float BellGain = 1.25f;
        // Metadata for a constant-one custom rolloff curve, never an eligibility
        // cutoff: relative-room gain/filter/blend provide the distant effect.
        internal const float BellMinDistance = 8f;
        internal const float BellMaxDistance = 52f;
        internal const float BellRolloffFloor = 1f;
        internal const string R04BellCue = "ominous_bell_cathedral_01";
        internal const int R08BellFixtureCount = 18;

        // Ordered identically to the real R08 fixture positions in the runtime.
        // The two lowest authored endpoints retain the distant variant; each
        // fixture keeps its assigned approved tone on every toll.
        private static readonly string[] R08BellCues = {
            "ominous_bell_cathedral_01", "ominous_bell_funeral_04", "ominous_bell_cracked_03",
            "ominous_bell_cathedral_01", "ominous_bell_double_05", "ominous_bell_corrupted_06",
            "ominous_bell_funeral_04", "ominous_bell_double_05", "ominous_bell_cracked_03",
            "ominous_bell_corrupted_06", "ominous_bell_cathedral_01", "ominous_bell_distant_02",
            "ominous_bell_funeral_04", "ominous_bell_cracked_03", "ominous_bell_corrupted_06",
            "ominous_bell_double_05", "ominous_bell_funeral_04", "ominous_bell_distant_02"
        };

        internal static string R08BellCue(int fixtureIndex)
        {
            if (fixtureIndex < 0 || fixtureIndex >= R08BellFixtureCount)
                throw new ArgumentOutOfRangeException(nameof(fixtureIndex));
            return R08BellCues[fixtureIndex];
        }

        internal static string BellClipId(string roomId, int fixtureIndex)
        {
            if (roomId == "R08") return R08BellCue(fixtureIndex);
            if (roomId != "R04") throw new ArgumentException("Only an authored bell room can own a bell tone.", nameof(roomId));
            if (fixtureIndex != 0) throw new ArgumentOutOfRangeException(nameof(fixtureIndex));
            return R04BellCue;
        }

        internal static float RoomBellGain(bool sameRoom) => sameRoom ? 1f : .55f;
        internal static float RoomBellBlend(bool sameRoom) => sameRoom ? .85f : .35f;
        internal static float RoomBellCutoff(bool sameRoom) => sameRoom ? 4200f : 900f;

        internal static float BoostAirSample(float sample)
        {
            float boosted = sample * AirGain;
            if (float.IsNaN(boosted) || float.IsInfinity(boosted) || Math.Abs(boosted) > 1)
                throw new InvalidDataException("Approved air runtime gain exceeds PCM headroom.");
            return boosted;
        }

        internal static double FirstBellDelay(double random01)
        {
            RequireRandom(random01);
            return 12 + 10 * random01;
        }

        internal static double NextBellDelay(double random01)
        {
            RequireRandom(random01);
            return 60 + 45 * random01;
        }

        internal static double FirstDistantBellDelay(double random01)
        {
            RequireRandom(random01);
            return 20 + 15 * random01;
        }

        internal static double NextDistantBellDelay(double random01)
        {
            RequireRandom(random01);
            return 80 + 50 * random01;
        }

        private static void RequireRandom(double value)
        {
            if (double.IsNaN(value) || double.IsInfinity(value) || value < 0 || value > 1)
                throw new ArgumentOutOfRangeException(nameof(value), "Random samples must be finite values from zero to one.");
        }
    }
}
