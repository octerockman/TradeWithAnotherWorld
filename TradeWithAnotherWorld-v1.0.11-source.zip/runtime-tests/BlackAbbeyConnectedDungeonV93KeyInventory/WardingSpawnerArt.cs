using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    internal sealed class WardingSpawnerArtRole:MonoBehaviour {[SerializeField] internal string Role;}
    internal sealed class WardingSpawnerArt:MonoBehaviour
    {
        WardingSpawnerModule module;
        readonly Dictionary<string,Transform> motionRoots=new Dictionary<string,Transform>(StringComparer.Ordinal);
        Renderer[] ward,ember,main;
        readonly MaterialPropertyBlock block=new MaterialPropertyBlock();
        readonly List<Mesh> conformed=new List<Mesh>();
        float progress,pin,targetPin;
        bool wardContested;
        bool wardMountBound;
        float wardMountDepth;
        internal GameObject Root=>gameObject;
        internal Vector3 PinPoint
        {
            get
            {
                // The native lock is above the rotating bars. Use its exact
                // seated sample for the E target, not the older bar-centre hint.
                var motion=module.motions.Single(p=>p.Key.IndexOf("locking pin slide",StringComparison.OrdinalIgnoreCase)>=0).Value;
                var seated=motion[164];return transform.TransformPoint(new Vector3(seated[0],seated[1],seated[2]));
            }
        }
        internal Vector3 ActorMouth=>World(module.sockets.actorMouth);
        internal Vector3 ActorStaging=>World(module.sockets.actorStaging);
        internal Vector3 InnerDoor=>World(module.sockets.innerDoor);
        internal Vector3 ActorExit=>World(module.sockets.actorExit);
        internal Vector3 WardCentre=>transform.TransformPoint(WardingWardShape.WorkPoint-Vector3.forward*wardMountDepth);
        internal float WardRadius=>WardingWardShape.HalfWidth;
        internal bool ContainsWard(Vector3 world)
        {
            Vector3 local=transform.InverseTransformPoint(world);local.z+=wardMountDepth;
            return WardingWardShape.Contains(local);
        }
        // The physical mechanism is fitted behind the room's original arch.
        // Its floor ward belongs in front of that source mouth, independently
        // of the recess's accepted depth. No room/collision transform changes.
        internal void SetWardMountDepth(float depth)
        {
            if(module==null||float.IsNaN(depth)||float.IsInfinity(depth)||depth<-.5f||depth>1)
                throw new ArgumentException("Valid source mount required before ward floor projection.");
            if(wardMountBound)
            {
                if(Mathf.Abs(depth-wardMountDepth)>.000001f)throw new InvalidOperationException("A ward cannot silently change its source-mouth frame.");
                return;
            }
            if(conformed.Count!=0)throw new InvalidOperationException("Bind the ward source mouth before conforming its floor.");
            foreach(var renderer in ward)
                renderer.transform.localPosition+=renderer.transform.parent.InverseTransformVector(transform.TransformVector(Vector3.back*depth));
            wardMountDepth=depth;wardMountBound=true;
        }
        internal Collider[] MovingColliders {get;private set;}
        internal bool Obstructed(Character actor,float proposedProgress)
        {
            if(!WardingDoorClearance.InSwing(transform,actor,out _,out _))return false;
            var capsule=actor.GetComponent<CapsuleCollider>();
            if(!capsule)return true; // Unknown body shape retains the safe veto.
            foreach(var pair in motionRoots)
                foreach(var collider in pair.Value.GetComponentsInChildren<Collider>(true))
                    if(WardingDoorSweep.Blocked(transform,collider,module.motions[pair.Key],progress,proposedProgress,
                        pair.Key.IndexOf("locking pin slide",StringComparison.OrdinalIgnoreCase)>=0,pin,capsule))return true;
            return false;
        }
        internal Vector3? HallYieldPoint(Character actor)
        {
            if(!actor||!actor.CanMove()||actor.InAttack()||actor.IsStaggering())return null;
            var local=transform.InverseTransformPoint(actor.transform.position);
            var capsule=actor.GetComponent<CapsuleCollider>();
            if(!capsule||local.z<=.05f||local.z>2.6f||Mathf.Abs(local.x)>1.5f||Mathf.Abs(local.y)>.4f)return null;
            float radius=Mathf.Max(.2f,capsule.radius*Mathf.Max(Mathf.Abs(actor.transform.lossyScale.x),Mathf.Abs(actor.transform.lossyScale.z)));
            float height=Mathf.Max(radius*2+.05f,capsule.height*Mathf.Abs(actor.transform.lossyScale.y));
            // Existing real buffer ends at z2.56. Keep the full native capsule
            // ahead of its back wall, over supported floor, and out of the leaves.
            float depth=2.56f-radius-.10f;
            if(depth<1.56f+radius+.06f)return null;
            int mask=LayerMask.GetMask("static_solid");if(mask==0)return null;
            Vector3 point=transform.TransformPoint(new Vector3(Mathf.Clamp(local.x,-1.49f+radius+.08f,1.49f-radius-.08f),0,depth));
            if(!Physics.Raycast(point+Vector3.up*.5f,Vector3.down,out var floor,.8f,mask,QueryTriggerInteraction.Ignore)||
                floor.normal.y<.65f||Mathf.Abs(floor.point.y-transform.position.y)>.2f)return null;
            point.y=floor.point.y+.025f;
            if(Physics.CheckCapsule(point+Vector3.up*(radius+.06f),point+Vector3.up*(height-radius),radius,mask,QueryTriggerInteraction.Ignore))return null;
            return point;
        }
        Vector3 World(float[] p)=>transform.TransformPoint(new Vector3(p[0],p[1],p[2]));
        internal void Configure(WardingSpawnerModule value)
        {
            module=value;
            foreach(var key in module.motions.Keys)
            {
                var child=transform.Find(key);if(!child)throw new InvalidOperationException("Missing spawner motion root: "+key);
                foreach(var sample in module.motions[key])
                    if(Mathf.Abs(sample[7]-1)>.00001f||Mathf.Abs(sample[8]-1)>.00001f||Mathf.Abs(sample[9]-1)>.00001f)
                        throw new InvalidOperationException("Moving threshold collider requires its checked unit-scale motion.");
                foreach(var collider in child.GetComponentsInChildren<Collider>(true))
                    if(collider.transform.parent!=child||collider.transform.localPosition.sqrMagnitude>.00000001f||
                        Quaternion.Angle(collider.transform.localRotation,Quaternion.identity)>.001f||(collider.transform.localScale-Vector3.one).sqrMagnitude>.00000001f)
                        throw new InvalidOperationException("Moving threshold collider requires its checked direct identity mount.");
                motionRoots.Add(key,child);
            }
            var roles=GetComponentsInChildren<WardingSpawnerArtRole>(true);
            ward=roles.Where(r=>r.Role=="ward").Select(r=>r.GetComponent<Renderer>()).ToArray();
            ember=roles.Where(r=>r.Role=="ember").Select(r=>r.GetComponent<Renderer>()).ToArray();
            main=roles.Where(r=>r.Role=="main").Select(r=>r.GetComponent<Renderer>()).ToArray();
            MovingColliders=motionRoots.Values.SelectMany(t=>t.GetComponentsInChildren<Collider>(true)).ToArray();
            Apply(0,false);ApplyPose();
        }
        internal void Apply(float barringProgress,bool locked)
        {
            if(float.IsNaN(barringProgress)||float.IsInfinity(barringProgress))throw new ArgumentException("Finite spawner progress required.");
            progress=Mathf.Clamp01(barringProgress);targetPin=locked?1:0;
            ApplyPose();
        }
        internal void Snap(float barringProgress,bool locked)
        {pin=locked?1:0;Apply(barringProgress,locked);}
        internal void SetWardFeedback(float barringProgress,bool contested)
        {
            wardContested=contested;
            ApplyWardFeedback(barringProgress);
        }
        void ApplyWardFeedback(float closingProgress)
        {
            float glow=WardingWardShape.Glow(closingProgress);
            foreach(var renderer in ward)
            {
                block.Clear();block.SetColor("_Color",Color.Lerp(new Color(.10f,.085f,.065f),Color.white,glow));
                block.SetColor("_EmissionColor",(wardContested?new Color(1,.35f,.12f):new Color(1,.78f,.34f))*(1.35f*glow));
                renderer.SetPropertyBlock(block);
            }
        }
        void Update()
        {
            if(module==null||Mathf.Approximately(pin,targetPin))return;
            pin=Mathf.MoveTowards(pin,targetPin,Time.deltaTime/.4f);ApplyPose();
        }
        void ApplyPose()
        {
            if(module==null)return;
            foreach(var pair in motionRoots)
            {
                WardingDoorSweep.Pose(module.motions[pair.Key],progress,
                    pair.Key.IndexOf("locking pin slide",StringComparison.OrdinalIgnoreCase)>=0,pin,out var p,out var q,out var s);
                var root=pair.Value;root.localPosition=p;root.localRotation=q;root.localScale=s;
            }
            ApplyWardFeedback(progress);
            foreach(var renderer in ember)
            {block.Clear();block.SetColor("_EmissionColor",Color.white*.7f);renderer.SetPropertyBlock(block);}
        }
        // Project only the instance's surface ward. The shared library mesh,
        // door mechanisms and original room floors remain unchanged.
        internal void ConformWard(Func<Vector3,float?> heightAt)
        {
            if(heightAt==null)throw new ArgumentNullException(nameof(heightAt));
            foreach(var renderer in ward)
            {
                var filter=renderer.GetComponent<MeshFilter>();var copy=Object.Instantiate(filter.sharedMesh);copy.name=filter.sharedMesh.name+" | floor conformed instance";
                var vertices=copy.vertices;
                for(int i=0;i<vertices.Length;i++)
                {
                    var world=filter.transform.TransformPoint(vertices[i]);float? floor=heightAt(world);
                    if(!floor.HasValue||float.IsNaN(floor.Value)||float.IsInfinity(floor.Value))
                    {Object.Destroy(copy);throw new InvalidOperationException("Spawner ward lacks source-floor support.");}
                    world.y=floor.Value+.018f;vertices[i]=filter.transform.InverseTransformPoint(world);
                }
                copy.vertices=vertices;copy.RecalculateBounds();filter.sharedMesh=copy;conformed.Add(copy);
            }
        }
        internal IEnumerator ConformWardSteps(Func<Vector3,float?> heightAt=null)
        {
            Physics.SyncTransforms();
            var hits=new RaycastHit[16];int mask=LayerMask.GetMask("static_solid");if(mask==0)mask=~0;
            if(heightAt==null)heightAt=point=>
            {
                // Start within the floor band: a longer ray can report a high
                // jamb face first and hide this same collider's floor beneath it.
                int count=Physics.RaycastNonAlloc(point+Vector3.up*WardingWardSurface.Reach,Vector3.down,hits,WardingWardSurface.Reach*2,mask,QueryTriggerInteraction.Ignore);
                float best=float.PositiveInfinity;float? height=null;
                for(int k=0;k<count;k++)
                {
                    var h=hits[k];if(!h.collider||!WardingWardSurface.Accept(h.normal.y,h.point.y,point.y))continue;
                    float distance=Mathf.Abs(h.point.y-point.y);
                    if(distance<best){best=distance;height=h.point.y;}
                }
                return height;
            };
            foreach(var renderer in ward)
            {
                var filter=renderer.GetComponent<MeshFilter>();var copy=Object.Instantiate(filter.sharedMesh);bool kept=false;
                try
                {
                    copy.name=filter.sharedMesh.name+" | floor conformed instance";var vertices=copy.vertices;
                    for(int i=0;i<vertices.Length;i++)
                    {
                        Vector3 point=filter.transform.TransformPoint(vertices[i]);float? floor=heightAt(point);
                        if(!floor.HasValue||float.IsNaN(floor.Value)||float.IsInfinity(floor.Value))
                            throw new InvalidOperationException("Spawner ward lacks actual floor support: source="+gameObject.name+"; vertex="+i+"; local="+transform.InverseTransformPoint(point).ToString("F4")+"; world="+point.ToString("F4")+"; sourceActive="+gameObject.activeInHierarchy+". Current run retained before travel.");
                        point.y=floor.Value+.018f;vertices[i]=filter.transform.InverseTransformPoint(point);
                        if((i+1)%128==0)yield return null;
                    }
                    copy.vertices=vertices;copy.RecalculateBounds();filter.sharedMesh=copy;conformed.Add(copy);kept=true;
                }
                finally {if(!kept&&copy)Object.Destroy(copy);}
            }
        }
        void OnDestroy(){foreach(var mesh in conformed)if(mesh)Object.Destroy(mesh);conformed.Clear();}
        internal float PresentedProgress=>progress;
        internal float PresentedPin=>pin;
    }
}
