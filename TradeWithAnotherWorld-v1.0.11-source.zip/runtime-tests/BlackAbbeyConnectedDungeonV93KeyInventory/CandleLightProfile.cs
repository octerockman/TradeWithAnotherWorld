using System;
using System.Linq;

namespace BlackAbbeySixRooms
{
    /// <summary>User-directed candle tuning; native waveform/settings remain in use.</summary>
    internal static class CandleLightProfile
    {
        internal const float FlickerSpeed = 1.5f;
        internal const float FlickerAmplitude = .035f;
        internal const float Movement = 0f;
        // Native LightLod's constructor default. The small Candle_resin asset
        // overrides it to15m, too short for our tall/long room fixtures.
        internal const float NativeVisibilityDistance = 40f;
        internal const float ShrineIntensityScale = .32f;
        internal const float ShrineRange = 10f;
        internal const float DefaultRange = 7.5f;
        internal const float R09CrownRange = 18f;
        internal static bool IsR09Crown(string roomId,CandleWickGrouping.Group group) => R09SplitIdentity.IsChamber(roomId) && group.Wicks.Count>0 &&
            group.Wicks.TrueForAll(wick=>wick.Name!=null && wick.Name.StartsWith("R09 runtime FLAME_SOCKET | R09_CROWN_",StringComparison.Ordinal));

        // Scope intensity/range changes to the two dense stair/altar banks;
        // preserve other rooms, including the accepted R05 fixture brightness.
        internal static bool IsShrineBank(string roomId, CandleWickGrouping.Group group)
        {
            if (roomId != "R03" && roomId != "R03_complete") return false;
            return group.Wicks.TrueForAll(wick => wick.Name.StartsWith("shrine-candle-", StringComparison.Ordinal)
                || wick.Name.StartsWith("v4-votive-", StringComparison.Ordinal));
        }
        internal static float Intensity(string roomId, CandleWickGrouping.Group group) =>
            CandleWickGrouping.BaseIntensity(group.Wicks.Count) * (IsShrineBank(roomId, group) ? ShrineIntensityScale : 1f) *
            (BossApproachLightPolicy.Applies(roomId,group.Wicks.Select(w=>w.Z)) ? BossApproachLightPolicy.IntensityScale : 1f);
        internal static float Range(string roomId, CandleWickGrouping.Group group) =>
            BossApproachLightPolicy.Applies(roomId,group.Wicks.Select(w=>w.Z)) ? BossApproachLightPolicy.Range :
            DungeonLightReachPolicy.CandleRange(roomId, IsShrineBank(roomId, group), IsR09Crown(roomId,group));
    }
}
