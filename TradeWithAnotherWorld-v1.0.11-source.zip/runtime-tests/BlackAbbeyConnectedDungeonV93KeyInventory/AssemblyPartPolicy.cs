using System;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // User-edited asset inventories are pinned by manifest hash. A complete
    // removed collar pair and the deleted static oak jamb collider are valid;
    // partial collar exports and missing moving parts are still errors.
    internal static class AssemblyPartPolicy
    {
        internal const string PerPortMode = "per-port-source-aperture";
        internal static readonly string[] VariantVisualParts = { "left_leaf", "right_leaf", "fixed_frame", "barred_crossbar", "opening_symbol_left", "opening_symbol_right" };
        internal static readonly string[] VariantCollisionParts = { "left_leaf", "right_leaf" };
        internal static bool TrimFileLengthAllowed(long length) => length >= 0 && length <= 16L * 1024 * 1024;
        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        internal static void ValidateOakFit(DoorFitRecord fit)
        {
            if(fit?.woodProfileMode==KitPointedArchitecture.DoorMode)
            {if(fit.assemblyStyle!=KitPointedArchitecture.DoorMode||Math.Abs(fit.clearWidth-3)>.001f||Math.Abs(fit.clearHeight-4)>.001f||Math.Abs(fit.openAngle-90)>.001f||Math.Abs(fit.mountDepth)>.001f)throw new InvalidDataException("Invalid pointed standard door fit.");return;}
            if (fit?.woodProfileMode == PerPortMode)
            {
                if (!Finite(fit.openAngle) || Math.Abs(fit.openAngle - 90f) > .001f || fit.assemblyStyle != "full-arched-moving-leaves")
                    throw new InvalidDataException("Source-port oak fit requires full moving leaves and the90degree limit.");
                return; // Selected records own all mount/hinge/clearance values.
            }
            if (fit == null || !Finite(fit.mountDepth) || fit.mountDepth < .02f || fit.mountDepth > .45f ||
                !Finite(fit.clearWidth) || fit.clearWidth < 2.4f || fit.clearWidth > 3.1f || !Finite(fit.clearHeight) || fit.clearHeight < 2.2f ||
                !Finite(fit.openAngle) || Math.Abs(fit.openAngle - 90f) > .001f || fit.assemblyStyle != "full-arched-moving-leaves")
                throw new InvalidDataException("Oak door requires a checked inset mount and usable clear width.");
            ValidateHingePair(fit.leftHinge, fit.rightHinge);
            HasCircleFit(fit);
        }

        private static void ValidateHingePair(float[] left, float[] right)
        {
            if (left?.Length != 3 || right?.Length != 3 || left.Any(v => !Finite(v)) || right.Any(v => !Finite(v)) ||
                left[0] >= 0 || right[0] <= 0 || Math.Abs(left[0] + right[0]) > .005f || Math.Abs(left[1] - right[1]) > .005f || Math.Abs(left[2] - right[2]) > .005f ||
                Math.Abs(left[0]) > 1.7f || Math.Abs(left[1]) > .01f || Math.Abs(left[2]) > .4f)
                throw new InvalidDataException("Oak door hinge datums differ from the checked fitted frame.");
        }

        internal static bool HasCircleFit(DoorFitRecord fit)
        {
            if (fit == null) throw new InvalidDataException("Missing oak fit.");
            if (fit.circleLeftHinge == null && fit.circleRightHinge == null && fit.circleClearWidth == 0) return false;
            ValidateHingePair(fit.circleLeftHinge, fit.circleRightHinge);
            if (!Finite(fit.circleClearWidth) || fit.circleClearWidth < 2.4f || fit.circleClearWidth > 3.1f)
                throw new InvalidDataException("Circular oak fit requires checked clear width.");
            return true;
        }

        internal static float[] HingeForProfile(DoorFitRecord fit, bool circle, bool left)
        {
            if (circle && HasCircleFit(fit)) return left ? fit.circleLeftHinge : fit.circleRightHinge;
            return left ? fit.leftHinge : fit.rightHinge;
        }

        internal static bool HasMasonryCollars(PackageManifest manifest)
        {
            if (manifest?.meshes == null) throw new InvalidDataException("Missing masonry mesh inventory.");
            int ellipse = manifest.meshes.Count(m => m?.name == "joint_mortar_e");
            int circle = manifest.meshes.Count(m => m?.name == "joint_mortar_c");
            if (ellipse == 0 && circle == 0) return false;
            if (ellipse == 1 && circle == 1) return true;
            throw new InvalidDataException("Masonry contact collars must be present as one complete pair or omitted together.");
        }

        internal static void ValidateOakParts(PackageManifest manifest)
        {
            if(manifest?.roomId==KitPointedArchitecture.DoorId){KitPointedArchitecture.ValidateDoor(manifest);return;}
            if (manifest?.meshes == null || manifest.colliderMeshes == null)
                throw new InvalidDataException("Missing oak mesh inventory.");
            if (!string.IsNullOrEmpty(manifest.doorFit?.woodProfileMode))
            {
                ValidateVariants(manifest);
                return;
            }
            bool profileHinges = HasProfileHinges(manifest);
            foreach (string name in new[] { "left_leaf", "right_leaf", "barred_crossbar", "opening_symbol_left", "opening_symbol_right" })
                if (manifest.meshes.Count(m => m?.name == name) != 1)
                    throw new InvalidDataException("Missing or duplicate oak visual part: " + name);
            int frameCount = manifest.meshes.Count(m => m?.name == "fixed_frame");
            if (frameCount > 1 || !profileHinges && frameCount != 1)
                throw new InvalidDataException("Oak static hardware requires its actual shared frame or complete profile set.");
            if (manifest.meshes.Count(m => m?.name == "ellipse_transom") > 1)
                throw new InvalidDataException("Duplicate optional oak transom.");
            if (manifest.meshes.Any(m => m?.name == "fixed_arch_head"))
                throw new InvalidDataException("The restored arched door must not contain the rejected stationary upper panel.");
            foreach (string name in new[] { "left_leaf", "right_leaf" })
                if (manifest.colliderMeshes.Count(m => m?.name == name) != 1)
                    throw new InvalidDataException("Missing or duplicate oak moving body: " + name);
            if (manifest.colliderMeshes.Count(m => m?.name == "fixed_frame") > 1)
                throw new InvalidDataException("Duplicate oak static frame body.");
        }

        internal static void ValidateVariants(PackageManifest manifest)
        {
            var fit = manifest?.doorFit;
            if (fit?.woodProfileMode != PerPortMode || fit.variants == null ||
                fit.variants.Count(v => v?.roomId != "R07") != 18 ||
                fit.variants.Count(v => v?.roomId == "R07") > 1 || fit.variants.Count(v => v?.roomId == "R09") > 1 ||
                fit.variants.Any(v => v?.roomId == "R09" || v?.roomId == "R07" && v.portId != "SOUTH"))
                throw new InvalidDataException("Oak source fit retains eighteen original ports and optional R07/SOUTH. R08 and the R09 approach keep open landings.");
            var keys = new System.Collections.Generic.HashSet<string>(StringComparer.Ordinal);
            var profiles = new System.Collections.Generic.HashSet<string>(StringComparer.Ordinal);
            foreach (var row in fit.variants)
            {
                if (row == null || !CatalogReader.RoomIds.Contains(row.roomId) || string.IsNullOrWhiteSpace(row.portId) || row.portId.Length > 48 ||
                    !CatalogReader.Hash(row.sourceSha256) || string.IsNullOrEmpty(row.prefix) || row.prefix.Length > 48 || row.prefix.Any(c => !char.IsLetterOrDigit(c) && c != '_') ||
                    !keys.Add(row.roomId + "/" + row.portId) || !Finite(row.mountDepth) || row.mountDepth < -.5f || row.mountDepth > .45f ||
                    !Finite(row.clearWidth) || row.clearWidth < 2.4f || row.clearWidth > 3.1f || !Finite(row.clearHeight) || row.clearHeight < 2.2f)
                    throw new InvalidDataException("Invalid or duplicate source-bound oak port variant.");
                ValidateHingePair(row.leftHinge, row.rightHinge);
                profiles.Add(row.prefix);
                foreach (string part in VariantVisualParts)
                    if (manifest.meshes.Count(m => m?.name == row.prefix + part) != 1)
                        throw new InvalidDataException("Missing or duplicate source-port oak visual: " + row.prefix + part);
                foreach (string part in VariantCollisionParts)
                    if (manifest.colliderMeshes.Count(m => m?.name == row.prefix + part && m.triangles <= 255) != 1)
                        throw new InvalidDataException("Missing or duplicate source-port oak moving body: " + row.prefix + part);
            }
            if (profiles.Count != 3 || manifest.meshes.Length != 3 * VariantVisualParts.Length || manifest.colliderMeshes.Length != 3 * VariantCollisionParts.Length)
                throw new InvalidDataException("Source ports must reference exactly three shared oak templates with eighteen visuals and six moving bodies.");
        }

        internal static DoorVariantRecord SelectVariant(PackageManifest manifest, string roomId, string portId, string sourceSha256)
        {
            if (string.IsNullOrEmpty(manifest?.doorFit?.woodProfileMode)) return null;
            ValidateVariants(manifest);
            var row = manifest.doorFit.variants.SingleOrDefault(v => v.roomId == roomId && v.portId == portId);
            if (row == null || row.sourceSha256 != sourceSha256)
                throw new InvalidDataException("Oak port fit does not match the source room/port/hash.");
            return row;
        }

        internal static string[] VariantObjectNames(DoorVariantRecord row)
        {
            return VariantVisualParts.Select(p => row.prefix + p).Concat(VariantCollisionParts.Select(p => "Collider | " + row.prefix + p)).ToArray();
        }

        internal static bool HasProfileHinges(PackageManifest manifest)
        {
            if (manifest?.meshes == null) throw new InvalidDataException("Missing oak hinge inventory.");
            var names = new[] { "hinge_e_left", "hinge_e_right", "fixed_hinges_e", "hinge_c_left", "hinge_c_right", "fixed_hinges_c" };
            var counts = names.Select(name => manifest.meshes.Count(m => m?.name == name)).ToArray();
            bool circle = manifest.doorFit != null && HasCircleFit(manifest.doorFit);
            if (counts.All(n => n == 0) && !circle) return false;
            if (counts.All(n => n == 1) && circle) return true;
            throw new InvalidDataException("Profile hinge geometry requires the complete six-part set and checked circular datums.");
        }

        internal static bool HasDoorRebates(PackageManifest manifest)
        {
            if (manifest?.meshes == null || manifest.colliderMeshes == null)
                throw new InvalidDataException("Missing masonry rebate inventory.");
            var counts = new[] { "fit_rebate_e", "fit_rebate_c" }
                .SelectMany(name => new[] { manifest.meshes.Count(m => m?.name == name), manifest.colliderMeshes.Count(m => m?.name == name) }).ToArray();
            if (counts.All(n => n == 0)) return false;
            if (counts.All(n => n == 1)) return true;
            throw new InvalidDataException("Fitted oak rebates require both profile visuals and their matching static collision, or must all be absent.");
        }
    }
}
