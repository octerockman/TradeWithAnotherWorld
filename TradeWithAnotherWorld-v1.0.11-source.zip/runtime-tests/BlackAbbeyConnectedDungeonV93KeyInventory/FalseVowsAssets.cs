using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbeySixRooms
{
#pragma warning disable 0649
    internal sealed class FalseVowsAssetPose
    {
        public float[] position, rotation, scale;
        internal void Apply(Transform t)
        {
            t.localPosition=RoomPackage.Vector(position??new float[3],"quest pose");
            var q=rotation??new[]{0f,0,0,1};
            if(q.Length!=4||q.Any(x=>!RoomPackage.Finite(x))||Math.Abs(q.Sum(x=>x*x)-1)>.02f)throw new InvalidDataException("Invalid quest rotation.");
            t.localRotation=new Quaternion(q[0],q[1],q[2],q[3]);
            t.localScale=RoomPackage.Vector(scale??new[]{1f,1,1},"quest scale");
        }
    }
    internal sealed class FalseVowsAssetIcon { public string file,sha256; }
    internal sealed class FalseVowsAssetKit
    {
        public string id,roomId,kind;
        public MeshRecord[] parts,colliders;
        public float[] boundsMin,boundsMax;
        public FalseVowsAssetPose roomPose;
        public FalseVowsAssetIcon icon;
        public JObject sourceNative;
        public string[] sourceObjects;
    }
    internal sealed class FalseVowsAssetMask
    { public string name,meshSha256;public bool collider;public int[] triangleIndices; }
    internal sealed class FalseVowsMovedPart : FalseVowsAssetPoseBase
    { public string kitId; }
    internal class FalseVowsAssetPoseBase
    { public float[] position,rotation,scale;internal FalseVowsAssetPose Pose=>new FalseVowsAssetPose{position=position,rotation=rotation,scale=scale}; }
    internal sealed class FalseVowsAssetRoom
    {
        public string id,baseManifestSha256,baseSourceSha256;
        public FalseVowsAssetMask[] masks;
        public FalseVowsMovedPart[] movedParts;
        public JObject sockets;
    }
    internal sealed class FalseVowsRouteVisibilityBinding
    {
        public string assetId,roomId,baseManifestSha256,baseSourceSha256;
        public FalseVowsAssetMask[] masks;
    }
    internal sealed class FalseVowsAssetMaterial
    {
        public string name,albedo,normal,metallicSmoothness,emission;
        public string albedoSha256,normalSha256,metallicSmoothnessSha256,emissionSha256;
        public bool cutout,transparent,unlit;
        public float? alphaCutoff,normalStrength;
        public TextureSamplerRecord sampler,albedoSampler,normalSampler,metallicSmoothnessSampler,emissionSampler;
        public float[] color;
        public float roughness=.6f,metallic,emissionStrength;
        internal MaterialRecord Record=>new MaterialRecord{name=name,albedo=albedo,normal=normal,metallicSmoothness=metallicSmoothness,emission=emission,cutout=cutout,transparent=transparent,unlit=unlit,roughness=roughness,metallic=metallic,emissionStrength=emissionStrength,alphaCutoff=alphaCutoff,normalStrength=normalStrength,sampler=sampler,albedoSampler=albedoSampler,normalSampler=normalSampler,metallicSmoothnessSampler=metallicSmoothnessSampler,emissionSampler=emissionSampler};
    }
    internal sealed class FalseVowsAssetManifest
    { public int schemaVersion;public string axisConversion;public FalseVowsAssetMaterial[] materials;public FalseVowsAssetKit[] kits;public FalseVowsAssetRoom[] rooms;public FalseVowsRouteVisibilityBinding[] routeVisibilityBindings; }
#pragma warning restore 0649

    internal sealed class FalseVowsAssets:IDisposable
    {
        private readonly string directory;
        private readonly Action<string> log;
        private readonly LoadedRoom resources;
        private readonly Dictionary<string,FalseVowsAssetKit> kits;
        private readonly Dictionary<string,Mesh> meshes=new Dictionary<string,Mesh>(StringComparer.Ordinal);
        private readonly Dictionary<string,Sprite> icons=new Dictionary<string,Sprite>(StringComparer.Ordinal);
        private readonly Dictionary<Material,Material> keyMaterials=new Dictionary<Material,Material>();
        private readonly Material[] materials;
        internal readonly FalseVowsAssetManifest Manifest;
        internal FalseVowsAssets(string root,Action<string> log)
        {
            this.log=log;directory=Path.Combine(root,"false-vows");
            string path=RoomPackage.FilePath(directory,"false-vows-assets.json");
            string expectedManifest=KitArchitectureProfile.ExpectedHash(root,"false-vows/false-vows-assets.json",FalseVowsAssetVersion.ManifestSha256);
            if(CatalogReader.HashFile(path)!=expectedManifest)throw new InvalidDataException("Three False Vows assets differ from the checked export.");
            Manifest=JsonConvert.DeserializeObject<FalseVowsAssetManifest>(File.ReadAllText(path));
            if(Manifest==null||Manifest.schemaVersion!=1||Manifest.materials==null||Manifest.kits==null||Manifest.rooms==null||Manifest.kits.Length>256||Manifest.materials.Length>128)
                throw new InvalidDataException("Invalid quest asset manifest.");
            kits=Manifest.kits.ToDictionary(k=>k.id,StringComparer.Ordinal);
            foreach(var k in kits.Values)
            {
                if(k.parts==null||k.parts.Length==0||k.parts.Length>128||k.parts.Any(p=>p==null||p.materialIndex<0||p.materialIndex>=Manifest.materials.Length))throw new InvalidDataException("Incomplete quest visual kit: "+k.id);
                foreach(var p in k.parts.Concat(k.colliders??Array.Empty<MeshRecord>()))Verify(p.meshFile,p.sha256);
                RoomPackage.Vector(k.boundsMin,"kit minimum");RoomPackage.Vector(k.boundsMax,"kit maximum");
                if(k.icon!=null)Verify(k.icon.file,k.icon.sha256);
            }
            resources=new LoadedRoom{Root=new GameObject("Abbey | false vows shared resources"),Manifest=new PackageManifest{roomId="FALSE_VOWS_ASSETS"},Record=new CatalogRoomRecord{manifestSha256=expectedManifest}};
            resources.Root.SetActive(false);Object.DontDestroyOnLoad(resources.Root);
            try
            {
                materials=new Material[Manifest.materials.Length];
                for(int i=0;i<materials.Length;i++)
                {
                    var m=Manifest.materials[i];Verify(m.albedo,m.albedoSha256);VerifyOptional(m.normal,m.normalSha256);VerifyOptional(m.metallicSmoothness,m.metallicSmoothnessSha256);VerifyOptional(m.emission,m.emissionSha256);
                    materials[i]=RoomPackage.LoadAdditionalMaterial(directory,m.Record,resources,log);
                    if(m.color!=null){if(m.color.Length!=4||m.color.Any(c=>!RoomPackage.Finite(c)))throw new InvalidDataException("Invalid quest material tint.");materials[i].SetColor("_Color",new Color(m.color[0],m.color[1],m.color[2],m.color[3]));}
                }
            }
            catch{Dispose();throw;}
            log?.Invoke("FALSE_VOWS_ASSETS_READY: "+kits.Count+" source-bound kits; existing room architecture and source resources retained.");
        }
        private void Verify(string file,string hash)
        {if(!CatalogReader.Hash(hash)||CatalogReader.HashFile(RoomPackage.FilePath(directory,file))!=hash)throw new InvalidDataException("Changed quest asset: "+file);}
        private void VerifyOptional(string file,string hash){if(!string.IsNullOrEmpty(file))Verify(file,hash);}
        internal FalseVowsAssetKit Kit(string id)=>kits.TryGetValue(id,out var kit)?kit:throw new InvalidDataException("Missing quest kit "+id);
        internal FalseVowsAssetRoom Room(string id)=>Manifest.rooms.SingleOrDefault(r=>r.id==id);
        private Mesh Mesh(MeshRecord record,bool collider,string kitId=null)
        {
            string key=(collider?"collision|":"visual|")+record.meshFile+"|"+record.sha256;
            if(!meshes.TryGetValue(key,out var m))
            {m=RoomPackage.LoadAdditionalMesh(directory,record,collider,resources,log);if(!collider)m=FalseVowsCabinetGlyph.Prepare(kitId,record,m,resources);meshes.Add(key,m);}
            return m;
        }
        internal GameObject CreateItemVisual(string id)=>CreateKit(id,null,false,false);
        private Material MaterialForKit(string id,int index)
        {
            var source=materials[index];
            if(!FalseVowsKeyAppearance.AppliesTo(id))return source;
            if(!keyMaterials.TryGetValue(source,out var material))
            {
                material=FalseVowsKeyAppearance.Create(source);resources.Resources.Add(material);keyMaterials.Add(source,material);
                log?.Invoke("FALSE_VOWS_KEY_SILVER: private neutral silver key; original mesh/pose/normal/metal map retained; no emission or shared atlas change.");
            }
            return material;
        }
        internal Sprite Icon(string id)
        {
            if(icons.TryGetValue(id,out var old))return old;
            var source=Kit(id).icon;if(source==null)throw new InvalidDataException("Missing actual-model icon "+id);
            Verify(source.file,source.sha256);
            var texture=new Texture2D(2,2,TextureFormat.RGBA32,false){name="Abbey item icon | "+id};resources.Resources.Add(texture);
            if(!ImageConversion.LoadImage(texture,File.ReadAllBytes(RoomPackage.FilePath(directory,source.file)),true))throw new InvalidDataException("Invalid quest icon.");
            var sprite=Sprite.Create(texture,new Rect(0,0,texture.width,texture.height),new Vector2(.5f,.5f));resources.Resources.Add(sprite);icons.Add(id,sprite);return sprite;
        }
        internal GameObject CreateKit(string id,Transform parent,bool pose=true,bool collision=true)
        {
            var kit=Kit(id);var root=new GameObject("False Vows | "+id);root.SetActive(false);root.transform.SetParent(parent,false);
            root.layer=LayerMask.NameToLayer("piece");if(pose)kit.roomPose?.Apply(root.transform);
            try
            {
                foreach(var part in kit.parts)
                {
                    var child=new GameObject(part.name);child.transform.SetParent(root.transform,false);
                    // Authored room art receives the existing stained-glass
                    // receiver mask; separate interaction colliders stay piece.
                    int visualLayer=parent?LayerMask.NameToLayer("static_solid"):root.layer;
                    child.layer=visualLayer>=0?visualLayer:root.layer;
                    child.AddComponent<MeshFilter>().sharedMesh=Mesh(part,false,id);child.AddComponent<MeshRenderer>().sharedMaterials=FalseVowsCabinetGlyph.Materials(id,MaterialForKit(id,part.materialIndex),resources);
                }
                if(collision)foreach(var part in kit.colliders??Array.Empty<MeshRecord>())
                {
                    var child=new GameObject("Collider | "+part.name);child.transform.SetParent(root.transform,false);child.layer=root.layer;
                    child.AddComponent<MeshCollider>().sharedMesh=Mesh(part,true);
                }
                root.SetActive(true);return root;
            }
            catch{Object.Destroy(root);throw;}
        }
        internal void ApplyMasks(LoadedRoom room)
        {
            var data=Room(room.Manifest.roomId);if(data==null)return;
            if(!DungeonAssetRevision.ManifestMatches(data.id,data.baseManifestSha256,room.Record.manifestSha256,data.baseSourceSha256,room.Manifest.sourceSha256,data.masks?.Length??0))throw new InvalidDataException("Quest mask room source changed: "+data.id);
            ApplyMaskRows(room,data.masks,"active-quest");
        }
        internal void ApplyInactiveRouteMasks(LoadedRoom room)
        {
            if(!FalseVowsRouteVisibilityPolicy.NeedsInactiveMasks(false,room.Manifest.roomId))return;
            var current=KitArchitectureProfile.Find(room.Manifest.sourceSha256,room.Record.manifestSha256);
            string asset=current?.assetId??throw new InvalidDataException("Inactive quest art lacks its sealed asset identity.");
            var rows=Manifest.routeVisibilityBindings??Array.Empty<FalseVowsRouteVisibilityBinding>();
            var matches=rows.Where(r=>r!=null&&r.assetId==asset&&r.roomId==room.Manifest.roomId&&
                r.baseManifestSha256==room.Record.manifestSha256&&r.baseSourceSha256==room.Manifest.sourceSha256).ToArray();
            if(matches.Length!=1||matches[0].masks==null||matches[0].masks.Length==0)
                throw new InvalidDataException("Inactive quest art requires exact rebuilt ownership: "+asset);
            ApplyMaskRows(room,matches[0].masks,"inactive-route-no-pickups");
        }
        private void ApplyMaskRows(LoadedRoom room,FalseVowsAssetMask[] masks,string purpose)
        {
            foreach(var mask in masks??Array.Empty<FalseVowsAssetMask>())
            {
                var records=mask.collider?room.Manifest.colliderMeshes:room.Manifest.meshes;
                var record=records.SingleOrDefault(r=>r.name==mask.name);
                if(record==null||record.sha256!=mask.meshSha256)throw new InvalidDataException("Quest mask mesh source changed: "+mask.name);
                var child=room.Root.transform.Find((mask.collider?"Collider | ":"")+mask.name);
                if(!child)throw new InvalidDataException("Quest mask target missing: "+mask.name);
                var collider=mask.collider?child.GetComponent<MeshCollider>():null;var filter=mask.collider?null:child.GetComponent<MeshFilter>();
                var original=mask.collider?collider.sharedMesh:filter.sharedMesh;var indices=original.triangles;
                var remainder=child.GetComponent<PewSourceRemainder>();
                HashSet<int> remove;
                if(remainder)
                {
                    if(!KitArchitectureProfile.Matches(room.Manifest.sourceSha256,room.Record.manifestSha256)||remainder.OriginalMeshSha256!=record.sha256||
                        remainder.OriginalIndexCount!=record.indices||!ReferenceEquals(original,remainder.Remainder))
                        throw new InvalidDataException("Quest source differs from the proven rebuilt pew remainder: "+mask.name);
                    if(remainder.RepairProof!=null)
                        StairCollarRepair.RequireRemainderLineage(room,record,mask.collider,remainder.RepairProof,remainder.DerivedSourceIndexCount);
                    else if(remainder.DerivedSourceIndexCount!=record.indices)
                        throw new InvalidDataException("Quest source has an unverified derived triangle tail: "+mask.name);
                    remove=SourceTriangleComposition.MapMask(remainder.OriginalTriangles,record.indices/3,mask.triangleIndices??Array.Empty<int>(),indices.Length/3,remainder.DerivedSourceIndexCount/3);
                }
                else
                {
                    if(indices.Length!=record.indices)throw new InvalidDataException("Quest ownership cannot be applied after a conflicting index rewrite: "+mask.name);
                    remove=new HashSet<int>(mask.triangleIndices??Array.Empty<int>());
                }
                if(remove.Count!=(mask.triangleIndices?.Length??0)||remove.Any(t=>t<0||t>=indices.Length/3))throw new InvalidDataException("Invalid quest triangle ownership.");
                var kept=new int[indices.Length-remove.Count*3];int offset=0;
                for(int t=0;t<indices.Length/3;t++)if(!remove.Contains(t)){kept[offset++]=indices[t*3];kept[offset++]=indices[t*3+1];kept[offset++]=indices[t*3+2];}
                var clone=Object.Instantiate(original);clone.name=original.name+" | exact false-vows source mask";clone.SetIndices(kept,MeshTopology.Triangles,0,true);room.Resources.Add(clone);
                if(mask.collider){collider.sharedMesh=null;collider.sharedMesh=clone;}else filter.sharedMesh=clone;
                log?.Invoke("FALSE_VOWS_SOURCE_MASK: room="+room.InstanceId+"; purpose="+purpose+"; batch="+mask.name+"; collision="+mask.collider+"; removed="+remove.Count+"; composedWithExactPewRemainder="+(remainder!=null)+"; unrelated triangles retained exactly.");
            }
        }
        public void Dispose(){resources?.Dispose();meshes.Clear();icons.Clear();keyMaterials.Clear();}
    }
}
