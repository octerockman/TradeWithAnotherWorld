using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BlackAbbeySixRooms
{
    // Preparation holds only bounded encoded bytes and read-only file leases.
    // Unity objects, mesh decoding and texture uploads remain in the covered loader.
    internal sealed class CinematicEncodedPreparation : IDisposable
    {
        internal const long MaximumEncodedBytes = 16L * 1024 * 1024;
        internal const int MaximumEntries = 64, MaximumCandidates = 2048, MaximumPackages = 32;
        private const int MaximumManifestBytes = 4 * 1024 * 1024;
        private static readonly object currentGate = new object();
        private static CinematicEncodedPreparation current;
        private readonly object gate = new object();
        private readonly string root;
        private readonly Candidate[] candidates;
        private readonly CatalogRoomRecord[] packages;
        private readonly Dictionary<string, PreparedFile> ready = new Dictionary<string, PreparedFile>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly ManualResetEventSlim admission = new ManualResetEventSlim(false);
        private readonly Task worker;
        private FileStream pending;
        private bool allowed, complete, disposed, finished;
        private long reserved, peakReserved, retained, peakRetained, reads, preparedBytes, adoptions, adoptedBytes, deferred, failures, manifestReads;
        private string failure;

        internal sealed class Candidate
        {
            internal readonly string Path, ExpectedHash;
            internal Candidate(string path, string expectedHash = null) { Path = path; ExpectedHash = expectedHash; }
        }
        // A successful take transfers this exact locked stream to the normal
        // resource owner. No close/reopen window or timestamp trust is introduced.
        internal sealed class PreparedFile : IDisposable
        {
            internal FileStream Input;
            internal byte[] Bytes;
            internal readonly string Hash;
            internal PreparedFile(FileStream input, byte[] bytes, string hash) { Input = input; Bytes = bytes; Hash = hash; }
            public void Dispose() { var input = Input; Input = null; Bytes = null; input?.Dispose(); }
        }
        private CinematicEncodedPreparation(string dataRoot, Candidate[] source, CatalogRoomRecord[] packageSource)
        {
            if (string.IsNullOrWhiteSpace(dataRoot) || !System.IO.Path.IsPathRooted(dataRoot)) throw new ArgumentException("Preparation requires an absolute data root.");
            root = System.IO.Path.GetFullPath(dataRoot).TrimEnd(System.IO.Path.DirectorySeparatorChar, System.IO.Path.AltDirectorySeparatorChar);
            if (!Directory.Exists(root)) throw new DirectoryNotFoundException("Preparation data root is missing.");
            RejectReparse(root);
            candidates = source; packages = packageSource;
            worker = Task.Run((Action)Run);
            // No main-thread wait. Dispose signals/cooperatively drains the worker
            // and defers event disposal until its actual completion.
            worker.ContinueWith(t => { var observed = t.Exception; }, TaskScheduler.Default);
        }
        internal static CinematicEncodedPreparation Begin(string dataRoot, Candidate[] source)
        {
            if (source == null || source.Length > MaximumCandidates) throw new ArgumentException("Preparation candidate inventory is unbounded.");
            return new CinematicEncodedPreparation(dataRoot, (Candidate[])source.Clone(), null);
        }
        internal static CinematicEncodedPreparation BeginPackages(string dataRoot, CatalogRoomRecord[] source)
        {
            if (source == null || source.Length > MaximumPackages) throw new ArgumentException("Preparation package inventory is unbounded.");
            var copy = new CatalogRoomRecord[source.Length];
            for (int i = 0; i < copy.Length; i++)
            {
                var s = source[i]; if (s == null) throw new ArgumentException("Null preparation package.");
                copy[i] = new CatalogRoomRecord { roomId = s.roomId, packageDirectory = s.packageDirectory, sourceSha256 = s.sourceSha256, manifestSha256 = s.manifestSha256 };
            }
            return new CinematicEncodedPreparation(dataRoot, null, copy);
        }
        internal void BindCurrent()
        {
            lock (currentGate) { lock (gate) { if (disposed) throw new ObjectDisposedException(nameof(CinematicEncodedPreparation)); current = this; } }
        }
        internal static void ClearCurrent(CinematicEncodedPreparation owner) { lock (currentGate) { if (ReferenceEquals(current, owner)) current = null; } }
        internal static bool TryTakeCurrent(string path, string expectedHash, long maximumBytes, out PreparedFile file)
        {
            lock (currentGate) { if (current != null) return current.TryTake(path, expectedHash, maximumBytes, out file); }
            file = null; return false;
        }
        internal void SetAdmission(bool value)
        {
            lock (gate)
            {
                if (disposed || finished || complete) return;
                allowed = value;
                if (allowed) admission.Set(); else admission.Reset();
            }
        }
        internal void Complete()
        {
            lock (gate) { if (disposed || finished) return; complete = true; admission.Set(); }
        }
        internal bool IsFinished { get { lock (gate) return finished; } }
        internal Task Completion => worker;

        private bool WaitAdmission(bool alreadyAdmitted)
        {
            for (;;)
            {
                lock (gate)
                {
                    if (disposed) return false;
                    // Complete stops new work and permits only the admitted read
                    // to drain. Pausing takes effect between 64KiB read chunks.
                    if (complete) return alreadyAdmitted;
                    if (allowed) return true;
                }
                admission.Wait();
            }
        }
        private void Run()
        {
            try
            {
                if (packages != null)
                {
                    foreach (var package in packages)
                    {
                        if (AtInventoryLimit() || !WaitAdmission(false)) break;
                        try { PreparePackage(package); }
                        catch (Exception e) { RecordFailure(e); }
                    }
                }
                else foreach (var candidate in candidates)
                {
                    if (!WaitAdmission(false)) break;
                    Prepare(candidate);
                }
            }
            catch (Exception e) { RecordFailure(e); }
            finally { lock (gate) { finished = true; if (disposed) admission.Dispose(); } }
        }
        private void PreparePackage(CatalogRoomRecord package)
        {
            if (!ValidHash(package.manifestSha256) || !ValidHash(package.sourceSha256) || string.IsNullOrWhiteSpace(package.roomId)) throw new InvalidDataException("Preparation requires the catalog's exact manifest/source identity.");
            if (string.IsNullOrWhiteSpace(package.packageDirectory) || System.IO.Path.IsPathRooted(package.packageDirectory)) throw new InvalidDataException("Preparation package must be relative to the catalog data root.");
            var directory = Canonical(System.IO.Path.Combine(root, package.packageDirectory));
            PreparedFile manifest = null;
            try
            {
                manifest = Read(new Candidate(System.IO.Path.Combine(directory, "manifest.json"), package.manifestSha256), MaximumManifestBytes);
                if (manifest == null) return;
                var model = ManifestReader.Read(Encoding.UTF8.GetString(manifest.Bytes));
                if (model == null || model.schemaVersion != 1 || model.roomId != package.roomId || model.sourceSha256 != package.sourceSha256) throw new InvalidDataException("Preparation manifest does not match its catalog room.");
                lock (gate) manifestReads++;
                // Manifest text/POCOs are bounded metadata, not decoded geometry.
                // Release its encoded reservation before resource admission.
                ReleaseTransient(manifest); manifest = null;
                var meshes = model.meshes ?? new MeshRecord[0]; var colliders = model.colliderMeshes ?? new MeshRecord[0]; var materials = model.materials ?? new MaterialRecord[0];
                if (meshes.Length > 512 || colliders.Length > 512 || materials.Length > 128) throw new InvalidDataException("Preparation manifest inventory is unbounded.");
                foreach (var material in materials)
                {
                    if (material == null) continue;
                    foreach (var relative in new[] { material.albedo, material.normal, material.metallicSmoothness, material.emission })
                    {
                        if (AtInventoryLimit() || !WaitAdmission(false)) return;
                        if (!string.IsNullOrWhiteSpace(relative)) Prepare(new Candidate(PackageFile(directory, relative)));
                    }
                }
                foreach (var mesh in meshes)
                {
                    if (AtInventoryLimit() || !WaitAdmission(false)) return;
                    if (mesh != null && ValidHash(mesh.sha256)) Prepare(new Candidate(PackageFile(directory, mesh.meshFile), mesh.sha256));
                }
                foreach (var mesh in colliders)
                {
                    if (AtInventoryLimit() || !WaitAdmission(false)) return;
                    if (mesh != null && ValidHash(mesh.sha256)) Prepare(new Candidate(PackageFile(directory, mesh.meshFile), mesh.sha256));
                }
            }
            finally { if (manifest != null) ReleaseTransient(manifest); }
        }
        private void Prepare(Candidate candidate)
        {
            PreparedFile file = null;
            try
            {
                if (candidate == null) { lock (gate) deferred++; return; }
                lock (gate) { if (disposed || complete || ready.Count >= MaximumEntries || seen.Count >= MaximumCandidates) { deferred++; return; } }
                var path = Canonical(candidate.Path);
                lock (gate)
                {
                    if (disposed || complete || ready.Count >= MaximumEntries || seen.Count >= MaximumCandidates || !seen.Add(path)) { deferred++; return; }
                }
                file = Read(new Candidate(path, candidate.ExpectedHash), MaximumEncodedBytes);
                if (file == null) return;
                lock (gate)
                {
                    if (disposed) return;
                    ready.Add(path, file); retained += file.Bytes.LongLength; peakRetained = Math.Max(peakRetained, retained); file = null;
                }
            }
            catch (Exception e) { RecordFailure(e); }
            finally { if (file != null) ReleaseTransient(file); }
        }
        private PreparedFile Read(Candidate candidate, long maximum)
        {
            if (!WaitAdmission(false)) return null;
            string path = Canonical(candidate.Path);
            if (candidate.ExpectedHash != null && !ValidHash(candidate.ExpectedHash)) throw new InvalidDataException("Invalid declared preparation hash.");
            FileStream input = null; long reservation = 0;
            try
            {
                input = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 65536, FileOptions.SequentialScan);
                long length = input.Length;
                lock (gate)
                {
                    if (disposed || complete || !allowed || length <= 0 || length > maximum || length > MaximumEncodedBytes - reserved) { deferred++; return null; }
                    reserved += length; reservation = length; peakReserved = Math.Max(peakReserved, reserved); pending = input;
                }
                var bytes = new byte[(int)length]; int offset = 0;
                using (var algorithm = SHA256.Create())
                {
                    while (offset < bytes.Length)
                    {
                        if (!WaitAdmission(true)) return null;
                        int count = input.Read(bytes, offset, Math.Min(65536, bytes.Length - offset));
                        if (count == 0) throw new EndOfStreamException("Preparation source truncated during its locked read.");
                        algorithm.TransformBlock(bytes, offset, count, bytes, offset); offset += count;
                    }
                    if (input.ReadByte() != -1) throw new InvalidDataException("Preparation source grew during its locked read.");
                    algorithm.TransformFinalBlock(bytes, bytes.Length, 0);
                    string hash = BitConverter.ToString(algorithm.Hash).Replace("-", "").ToLowerInvariant();
                    if (candidate.ExpectedHash != null && candidate.ExpectedHash != hash) throw new InvalidDataException("Preparation source differs from the declared identity.");
                    lock (gate)
                    {
                        if (disposed) return null;
                        pending = null; reads++; preparedBytes += bytes.LongLength;
                    }
                    var result = new PreparedFile(input, bytes, hash); input = null; reservation = 0; return result;
                }
            }
            finally
            {
                lock (gate) { if (ReferenceEquals(pending, input)) pending = null; if (reservation != 0) reserved -= reservation; }
                input?.Dispose();
            }
        }
        private void ReleaseTransient(PreparedFile file)
        {
            long bytes = file.Bytes?.LongLength ?? 0;
            lock (gate) { reserved -= bytes; }
            file.Dispose();
        }
        private bool TryTake(string path, string expectedHash, long maximumBytes, out PreparedFile file)
        {
            file = null;
            if (maximumBytes < 1 || expectedHash != null && !ValidHash(expectedHash)) return false;
            string key;
            try { key = Canonical(path); } catch { return false; }
            lock (gate)
            {
                if (disposed || !ready.TryGetValue(key, out var value) || value.Bytes == null || value.Input == null || value.Bytes.LongLength > maximumBytes || expectedHash != null && value.Hash != expectedHash) return false;
                ready.Remove(key); long count = value.Bytes.LongLength; reserved -= count; retained -= count; adoptions++; adoptedBytes += count; file = value; return true;
            }
        }
        private string Canonical(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !System.IO.Path.IsPathRooted(path)) throw new InvalidDataException("Preparation resource path is not absolute.");
            var full = System.IO.Path.GetFullPath(path);
            string prefix = root + System.IO.Path.DirectorySeparatorChar;
            if (!full.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Preparation resource escapes the data root.");
            RejectReparse(full); return full;
        }
        private bool AtInventoryLimit() { lock (gate) return ready.Count >= MaximumEntries || seen.Count >= MaximumCandidates; }
        private string PackageFile(string directory, string relative)
        {
            if (string.IsNullOrWhiteSpace(relative) || System.IO.Path.IsPathRooted(relative)) throw new InvalidDataException("Preparation package files must be relative.");
            string full = System.IO.Path.GetFullPath(System.IO.Path.Combine(directory, relative));
            if (!full.StartsWith(directory + System.IO.Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Preparation resource escapes its source package.");
            return Canonical(full);
        }
        private void RejectReparse(string path)
        {
            string currentPath = path;
            while (currentPath != null)
            {
                if ((File.GetAttributes(currentPath) & FileAttributes.ReparsePoint) != 0) throw new InvalidDataException("Preparation does not follow filesystem links.");
                if (string.Equals(currentPath, root, StringComparison.OrdinalIgnoreCase)) return;
                currentPath = System.IO.Path.GetDirectoryName(currentPath);
            }
            throw new InvalidDataException("Preparation path has no trusted root.");
        }
        private static bool ValidHash(string hash)
        {
            if (hash == null || hash.Length != 64) return false;
            foreach (char c in hash) if (!(c >= '0' && c <= '9') && !(c >= 'a' && c <= 'f')) return false;
            return true;
        }
        private void RecordFailure(Exception error) { lock (gate) { if (disposed) return; failures++; failure = error.GetType().Name + ": " + error.Message; } }
        internal object Snapshot()
        {
            lock (gate) return new { maximumEncodedBytes = MaximumEncodedBytes, reservedEncodedBytes = reserved, peakReservedEncodedBytes = peakReserved, retainedEncodedBytes = retained, peakRetainedEncodedBytes = peakRetained, readyEntries = ready.Count, reads, preparedBytes, adoptions, adoptedBytes, deferred, failures, manifestReads, lastFailure = failure, allowed, complete, disposed, finished, scope = "Attempt-scoped encoded IO/SHA only; no Unity/geometry/physics work. Pending and ready encoded arrays share the reservation. No FPS claim." };
        }
        public void Dispose()
        {
            ClearCurrent(this);
            PreparedFile[] files; FileStream close;
            lock (gate)
            {
                if (disposed) return;
                disposed = true; complete = true; allowed = false;
                // Worker decrements its own pending reservation in finally.
                files = new PreparedFile[ready.Count]; ready.Values.CopyTo(files, 0); ready.Clear();
                reserved -= retained; retained = 0; close = pending;
                if (finished) admission.Dispose(); else admission.Set();
            }
            close?.Dispose(); foreach (var file in files) file.Dispose();
        }
    }
}
