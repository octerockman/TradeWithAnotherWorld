using System;
using System.Linq;
using System.Reflection;
using Jotunn.Managers;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    /// <summary>Room-controlled private candle lighting with retained native flicker.</summary>
    internal static class NativeCandleFixture
    {
        internal sealed class Source { internal Transform Leaf; internal Light Light; internal LightFlicker Flicker; internal string FlickerOrigin; }
        internal static bool FixtureDiagnostics { get; set; }
        private static bool Finite(float x) => !float.IsNaN(x) && !float.IsInfinity(x);
        private static bool Persistent(LightFlicker f) => f && f.GetComponent<Light>() && f.GetComponent<Light>().type == LightType.Point &&
            Finite(f.m_flickerIntensity) && Finite(f.m_flickerSpeed) && Finite(f.m_movement) && Finite(f.m_ttl) && f.m_ttl <= 0 &&
            Finite(f.m_fadeDuration) && Finite(f.m_fadeInDuration) && Finite(f.m_accessibilityBrightnessMultiplier);
        private static bool NativeLod(Component c) => c && c.GetType().FullName == "LightLod" && c.GetType().Assembly == typeof(LightFlicker).Assembly;
        internal static Source Resolve(Action<string> log)
        {
            var prefab = PrefabManager.Instance.GetPrefab(TradeWithAnotherWorld.ResinCandleFlame.SourcePrefab);
            var leaf = prefab ? prefab.transform.Find("high/Point Light") : null; var light = leaf ? leaf.GetComponent<Light>() : null;
            if (!leaf || leaf.childCount != 0 || !light || light.type != LightType.Point) throw new InvalidOperationException("Verified Candle_resin point-light leaf is unavailable or changed.");
            foreach (var c in leaf.GetComponents<Component>())
                if (!(c is Transform) && !(c is Light) && c.GetType() != typeof(LightFlicker) && !NativeLod(c)) throw new InvalidOperationException("Unexpected native candle light component: " + c.GetType().FullName);
            var source = new Source { Leaf = leaf, Light = light, Flicker = leaf.GetComponent<LightFlicker>(), FlickerOrigin = "Candle_resin/high/Point Light" };
            if (!Persistent(source.Flicker))
            {
                source.Flicker = null;
                foreach (string name in new[] { "piece_groundtorch", "piece_walltorch", "fire_pit" })
                {
                    var vanilla = PrefabManager.Instance.GetPrefab(name); var template = vanilla ? vanilla.GetComponentsInChildren<LightFlicker>(true).FirstOrDefault(Persistent) : null;
                    if (!template) continue; source.Flicker = template; source.FlickerOrigin = name + "/" + template.name; break;
                }
                if (!source.Flicker) source.FlickerOrigin = "installed LightFlicker constructor defaults; Candle_resin leaf has no persistent LightFlicker";
            }
            log("NATIVE_CANDLE_SOURCE: components=" + string.Join(",", leaf.GetComponents<Component>().Select(c => c.GetType().FullName)) + "; flickerProfile=" + source.FlickerOrigin + "; game-native waveform/accessibility behavior; no global changes.");
            return source;
        }
        private static void CopyProfile(LightFlicker source, LightFlicker target)
        {
            if (!source) return; // Installed native constructor defaults are verified in saved IL.
            target.m_flickerIntensity = source.m_flickerIntensity; target.m_flickerSpeed = source.m_flickerSpeed; target.m_movement = source.m_movement;
            target.m_ttl = source.m_ttl; target.m_fadeDuration = source.m_fadeDuration; target.m_fadeInDuration = source.m_fadeInDuration;
            target.m_flashingLightsSetting = source.m_flashingLightsSetting; target.m_accessibilityBrightnessMultiplier = source.m_accessibilityBrightnessMultiplier;
        }
        internal static GameObject Attach(GameObject root, Source source, string name, Vector3 position, float intensity, float range, Action<string> log)
        {
            var host = new GameObject(name); host.SetActive(false); host.transform.SetParent(root.transform, false); host.transform.localPosition = position;
            try
            {
                // Configure below an inactive parent before native Awake caches
                // intensity/position/range. BudgetedFixture opts this private
                // clone out of native count/distance LOD before activation.
                var copy = Object.Instantiate(source.Leaf.gameObject, host.transform, false); copy.name = name + " | native point"; copy.SetActive(false);
                copy.transform.localPosition = Vector3.zero; copy.transform.localRotation = source.Leaf.localRotation; copy.transform.localScale = Vector3.one;
                var light = copy.GetComponent<Light>(); light.color = source.Light.color; light.intensity = intensity; light.range = range;
                light.enabled = true; light.renderMode = source.Light.renderMode; light.shadows = LightShadows.None;
                var lod = copy.GetComponent<LightLod>();
                light.shadowStrength = RoomCandleLighting.ShadowStrength; light.shadowCustomResolution = RoomCandleLighting.ShadowResolution;
                light.shadowBias = RoomCandleLighting.ShadowBias; light.shadowNormalBias = RoomCandleLighting.ShadowNormalBias; light.shadowNearPlane = RoomCandleLighting.ShadowNearPlane;
                light.bounceIntensity = 0; light.cullingMask = ~0;
                var flicker = copy.GetComponent<LightFlicker>(); if (!flicker) flicker = copy.AddComponent<LightFlicker>(); CopyProfile(source.Flicker, flicker);
                // Configure our inactive clone before Awake caches its origin.
                flicker.m_flickerSpeed = CandleLightProfile.FlickerSpeed;
                flicker.m_flickerIntensity = CandleLightProfile.FlickerAmplitude;
                flicker.m_movement = CandleLightProfile.Movement;
                if (!Persistent(flicker)) throw new InvalidOperationException("Native flicker must be a persistent finite point-light profile.");
                flicker.enabled = true;
                copy.AddComponent<BudgetedFixture>().Configure(light, intensity, false);
                if (FixtureDiagnostics) host.AddComponent<NativeFlickerObservation>().Configure(light, flicker, intensity, log);
                if (FixtureDiagnostics) log($"CANDLE_FIXTURE: {name}; source-local={position}; baseIntensity={intensity:F3}; range={light.range:F3}; flicker={source.FlickerOrigin}; nativeAmplitude={flicker.m_flickerIntensity:F4}; nativeSpeed={flicker.m_flickerSpeed:F4}; nativeMovement={flicker.m_movement:F4}; candleShadows=None; nativeLightLod={lod != null}; renderMode={light.renderMode}; room presentation controls enable; private candle count/distance LOD disabled.");
                copy.SetActive(true); host.SetActive(true);
                return host;
            }
            catch { host.SetActive(false); Object.Destroy(host); throw; }
        }
    }
    internal sealed class NativeFlickerObservation : MonoBehaviour
    {
        private Light light; private LightFlicker flicker; private Action<string> log;
        private float expected, started, minimum = float.PositiveInfinity, maximum = float.NegativeInfinity, maxMovement; private int frames; private bool reported;
        internal void Configure(Light light, LightFlicker flicker, float expected, Action<string> log) { this.light = light; this.flicker = flicker; this.expected = expected; this.log = log; }
        private void OnEnable() { started = Time.unscaledTime; }
        private void Update()
        {
            if (reported || !light || !flicker || !light.enabled) return;
            float age = Time.unscaledTime - started; if (age < .2f) return;
            minimum = Mathf.Min(minimum, light.intensity); maximum = Mathf.Max(maximum, light.intensity); maxMovement = Mathf.Max(maxMovement, light.transform.localPosition.magnitude); frames++;
            if (age < 3 || frames < 30) return;
            var field = typeof(LightFlicker).GetField("m_baseIntensity", BindingFlags.Instance | BindingFlags.NonPublic);
            string cached = field == null ? "unavailable" : ((float)field.GetValue(flicker)).ToString("F3");
            log($"NATIVE_FLICKER_SAMPLE: {light.name}; frames={frames}; minIntensity={minimum:F4}; maxIntensity={maximum:F4}; expectedBase={expected:F3}; nativeCachedBase={cached}; maxLocalMovement={maxMovement:F4}m; nativeEnabled={flicker.enabled}; lightEnabled={light.enabled}; timeScale={Time.timeScale:F3}. Actual runtime sample; native accessibility settings retained.");
            reported = true; enabled = false;
        }
    }
}
