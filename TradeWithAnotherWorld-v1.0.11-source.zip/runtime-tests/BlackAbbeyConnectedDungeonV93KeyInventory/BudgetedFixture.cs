using UnityEngine;
using System.Collections.Generic;
namespace BlackAbbeySixRooms
{
    internal sealed class BudgetedFixture : MonoBehaviour
    {
        internal Light Light;
        internal string Id;
        internal Color BaseColor;
        internal float BaseIntensity;
        internal bool IsWindow, EmissionEnabled=true;
        private LightLod lod;
        private bool eligible,applied;
        private static readonly HashSet<LightLod> wakeups=new HashSet<LightLod>();
        internal void Configure(Light light,float intensity,bool window)
        {
            Light=light;Id=light.name;BaseIntensity=intensity;BaseColor=light.color;IsWindow=window;lod=light.GetComponent<LightLod>();
            if(!window)
            {
                // Only our private room candle clones opt out of native light
                // count/distance selection. Set this before the inactive clone
                // awakens: LightLod.Awake otherwise zeros its range and light.
                light.shadows=LightShadows.None;light.renderMode=LightRenderMode.ForcePixel;
                if(lod){lod.m_lightLod=false;lod.m_shadowLod=false;lod.enabled=false;}
            }
        }
        internal void SetVisible(bool visible)
        {
            if(!Light)return;
            bool allow=visible&&EmissionEnabled&&gameObject.activeInHierarchy;
            if(!IsWindow&&Light.shadows!=LightShadows.None)Light.shadows=LightShadows.None;
            if(!IsWindow)
            {
                // Room presentation and actual candle state are authoritative.
                // Native flicker, authored range/intensity and boss day gain
                // keep running independently; never restart LOD each frame.
                if(lod&&lod.enabled)lod.enabled=false;
                if(Light.enabled!=allow)Light.enabled=allow;
                eligible=allow;applied=true;return;
            }
            if(lod)
            {
                // Native sorting checks enabled, not activeInHierarchy. OnDisable
                // stops its loop but doesn't switch off the Light.
                if(lod.enabled!=allow)lod.enabled=allow;
                if(!allow&&Light.enabled)Light.enabled=false;
                if(!allow)wakeups.Remove(lod);
                else if(!applied||!eligible)
                {
                    // Native UpdateLoop does not enable lights with m_lightLod
                    // off. We must release our own forced-off state in that case.
                    if(!lod.m_lightLod)Light.enabled=true;
                    else wakeups.Add(lod);
                }
                // Actual LOD profiles retain native count, distance and fade.
            }
            else if(!applied||allow!=eligible)Light.enabled=allow;
            eligible=allow;applied=true;
        }
        internal static void FlushLodWakeups()
        {
            if(wakeups.Count==0)return;
            // All newly eligible fixtures join before native priority sorting.
            // Refresh once per batch, then restart only their native loop so
            // it does not act on stale pre-entry priority or a sleeping cycle.
            // No quality limits, range caches, intensity or globals are forced.
            LightLod.UpdateLights(1f);
            foreach(var lod in wakeups)if(lod&&lod.enabled&&lod.gameObject.activeInHierarchy)
            {lod.StopCoroutine("UpdateLoop");lod.StartCoroutine("UpdateLoop");}
            wakeups.Clear();
        }
        internal void Release()
        {
            if(lod)wakeups.Remove(lod);if(!Light)return;
            bool allow=EmissionEnabled&&gameObject.activeInHierarchy;
            if(!IsWindow){if(lod)lod.enabled=false;Light.enabled=allow;return;}
            if(lod){lod.enabled=allow;if(!lod.m_lightLod)Light.enabled=allow;}
            else Light.enabled=allow;
        }
        private void OnDestroy(){if(lod)wakeups.Remove(lod);}
    }
}
