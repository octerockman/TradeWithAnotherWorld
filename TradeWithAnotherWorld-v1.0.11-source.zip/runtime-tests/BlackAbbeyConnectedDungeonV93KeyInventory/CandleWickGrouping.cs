using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeySixRooms
{
    /// <summary>Pure geometry: only immediately adjacent flames may share a light.</summary>
    internal static class CandleWickGrouping
    {
        internal const double MaxDiameter = .35;
        internal sealed class Wick
        {
            internal int Index; internal string Name; internal double X, Y, Z;
        }
        internal sealed class Group
        {
            internal readonly List<Wick> Wicks = new List<Wick>();
            internal Wick Anchor;
            internal double Diameter;
        }
        private static double D2(Wick a, Wick b) => (a.X - b.X) * (a.X - b.X) + (a.Y - b.Y) * (a.Y - b.Y) + (a.Z - b.Z) * (a.Z - b.Z);
        internal static Group[] Build(IEnumerable<Wick> input)
        {
            var points = input.OrderBy(p => p.X).ThenBy(p => p.Z).ThenBy(p => p.Y).ThenBy(p => p.Name, StringComparer.Ordinal).ThenBy(p => p.Index).ToArray();
            if (points.Any(p => double.IsNaN(p.X) || double.IsInfinity(p.X) || double.IsNaN(p.Y) || double.IsInfinity(p.Y) || double.IsNaN(p.Z) || double.IsInfinity(p.Z)) || points.Select(p => p.Index).Distinct().Count() != points.Length)
                throw new ArgumentException("Each source wick requires a unique index and finite position.");
            var groups = new List<Group>(); double limit = MaxDiameter * MaxDiameter + 1e-12;
            foreach (var point in points)
            {
                Group best = null; double bestDistance = double.MaxValue;
                foreach (var group in groups)
                {
                    if (!group.Wicks.All(other => D2(point, other) <= limit)) continue;
                    double distance = group.Wicks.Average(other => D2(point, other));
                    if (distance < bestDistance) { best = group; bestDistance = distance; }
                }
                if (best == null) { best = new Group(); groups.Add(best); }
                best.Wicks.Add(point);
            }
            foreach (var group in groups)
            {
                // Anchor on a real flame, never an empty midpoint on stairs.
                group.Anchor = group.Wicks.OrderBy(p => group.Wicks.Sum(other => D2(p, other))).ThenBy(p => p.Name, StringComparer.Ordinal).ThenBy(p => p.Index).First();
                group.Diameter = Math.Sqrt(group.Wicks.Max(p => group.Wicks.Max(other => D2(p, other))));
            }
            return groups.ToArray();
        }
        internal static float BaseIntensity(int adjacentFlames) => Math.Min(2.8f, 1.5f + .325f * Math.Max(0, adjacentFlames - 1));
    }
}
