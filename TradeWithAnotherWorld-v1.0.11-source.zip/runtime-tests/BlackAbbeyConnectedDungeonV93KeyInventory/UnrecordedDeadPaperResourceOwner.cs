namespace BlackAbbeySixRooms
{
    internal static class UnrecordedDeadPaperVersion
    {internal const string ManifestSha256="6eedda0319ea6d9e1c8b8d63e7df5de87b9f9fee4514d4c017250e1d5ec8ad15";}

    // Auxiliary mesh banks still use the shared loader's manifest-scoped
    // resource keys. They need a real catalog identity before the first mesh.
    internal static class UnrecordedDeadPaperResourceOwner
    {
        internal static CatalogRoomRecord CreateRecord()=>new CatalogRoomRecord{
            roomId="UD-Paper",sourceSha256=UnrecordedDeadPaperVersion.ManifestSha256,
            manifestSha256=UnrecordedDeadPaperVersion.ManifestSha256
        };
    }
}
