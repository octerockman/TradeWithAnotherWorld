using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlackAbbeySixRooms
{
    internal sealed class MonkRunSnapshot
    {
        public int schemaVersion=1,seed;
        public string runId,worldKey;
        public string[] visitedRooms;
        public MonkActorSnapshot[] slots;
        public EncounterRoomSnapshot[] plans;
    }
    internal sealed class EncounterRoomSnapshot
    {
        public string instanceId,sourceRoomId;public int depth;public string[] prefabs;public float yaw;
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)] public string assetId;
    }
    internal sealed class MonkActorSnapshot
    {
        public string slotKey,instanceId,state;
        public string prefab;
        public bool consumed;
        public long uidUser;
        public uint uidId;
        public float[] position,rotation;
        public float? health;
    }
    internal static class MonkRunPersistence
    {
        static JsonSerializer Serializer()=>JsonSerializer.Create(new JsonSerializerSettings {TypeNameHandling=TypeNameHandling.None,
            MetadataPropertyHandling=MetadataPropertyHandling.Ignore,DateParseHandling=DateParseHandling.None,MaxDepth=16});
        internal static JObject ToJson(MonkRunSnapshot value) => value==null?null:JObject.FromObject(value,Serializer());
        internal static MonkRunSnapshot Read(JObject value,string world,string runId,int seed)
        {
            if(value==null)return null;
            if(value.ToString(Formatting.None).Length>128*1024)throw new InvalidDataException("Saved Monk ledger is oversized.");
            var data=value.ToObject<MonkRunSnapshot>(Serializer());Validate(data,world,runId,seed);return data;
        }
        static bool Name(string n,int max=96)=>!string.IsNullOrWhiteSpace(n)&&n.Length<=max&&n.All(c=>!char.IsControl(c));
        static bool Finite(float n)=>!float.IsNaN(n)&&!float.IsInfinity(n);
        internal static void Validate(MonkRunSnapshot data,string world,string runId,int seed)
        {
            if(data==null||(data.schemaVersion!=1&&data.schemaVersion!=2)||!Name(data.runId,160)||data.runId!=runId||!Name(data.worldKey,4096)||data.worldKey!=world||data.seed!=seed||
                data.visitedRooms==null||data.visitedRooms.Length>64||data.visitedRooms.Any(n=>!Name(n))||
                data.visitedRooms.Distinct(StringComparer.Ordinal).Count()!=data.visitedRooms.Length||
                data.slots==null||data.slots.Length>128||data.slots.Any(s=>s==null))throw new InvalidDataException("Saved Monk run identity/schema differs.");
            var rooms=new HashSet<string>(data.visitedRooms,StringComparer.Ordinal);var slots=new HashSet<string>(StringComparer.Ordinal);var ids=new HashSet<string>(StringComparer.Ordinal);
            int count=0;
            if(data.schemaVersion==2){
                if(data.plans==null||data.plans.Length>64||data.plans.Any(p=>p==null||!Name(p.instanceId)||!new[]{"R01","R02","R03","R03_complete","R04","R05","R06","R07","R08","R09","R09-A1","R09-A2","R09-B"}.Contains(p.sourceRoomId)||p.depth<0||p.prefabs==null||p.prefabs.Length>4||p.prefabs.Any(n=>!AbbeyMonkSpawnPolicy.KnownPrefab(n))||!Finite(p.yaw)||
                    !UnrecordedDeadKnightPolicy.ValidPlan(p))||
                    data.plans.Select(p=>p.instanceId).Distinct(StringComparer.Ordinal).Count()!=data.plans.Length||rooms.Any(id=>!data.plans.Any(p=>p.instanceId==id)))throw new InvalidDataException("Saved room encounter plan differs.");
            }
            foreach(var s in data.slots)
            {
                if(!Name(s.instanceId)||!rooms.Contains(s.instanceId)||!Name(s.slotKey,112)||!slots.Add(s.slotKey)||
                    !Enumerable.Range(0,data.schemaVersion==1?2:4).Any(i=>s.slotKey==(data.schemaVersion==1?AbbeyMonkSpawnPolicy.Ledger.Key(s.instanceId,i):s.instanceId+"/enemy/"+i))||
                    (data.schemaVersion==2&&!AbbeyMonkSpawnPolicy.KnownPrefab(s.prefab))||
                    !Enum.GetNames(typeof(AbbeyMonkSpawnPolicy.SlotState)).Contains(s.state))throw new InvalidDataException("Saved Monk slot identity/state differs.");
                var state=(AbbeyMonkSpawnPolicy.SlotState)Enum.Parse(typeof(AbbeyMonkSpawnPolicy.SlotState),s.state);
                if(data.schemaVersion==2){var plan=data.plans.Single(p=>p.instanceId==s.instanceId);int index=int.Parse(s.slotKey.Substring(s.slotKey.LastIndexOf('/')+1));if(index>=plan.prefabs.Length||plan.prefabs[index]!=s.prefab)throw new InvalidDataException("Actor differs from saved room role slot.");}
                if((state==AbbeyMonkSpawnPolicy.SlotState.Spawned||state==AbbeyMonkSpawnPolicy.SlotState.Dead||state==AbbeyMonkSpawnPolicy.SlotState.Lost)&&!s.consumed||
                    state==AbbeyMonkSpawnPolicy.SlotState.Reserved&&s.consumed)throw new InvalidDataException("Saved Monk consumption state differs.");
                if(s.consumed)count++;
                bool uid=s.uidUser!=0&&s.uidId!=0;
                if((s.uidUser==0)!=(s.uidId==0)||uid&&!ids.Add(s.uidUser+":"+s.uidId)||state==AbbeyMonkSpawnPolicy.SlotState.Spawned&&!uid)
                    throw new InvalidDataException("Saved Monk UID is invalid or repeated.");
                if(uid&&(s.position==null||s.position.Length!=3||s.position.Any(v=>!Finite(v)||Math.Abs(v)>100000)||
                    s.rotation==null||s.rotation.Length!=4||s.rotation.Any(v=>!Finite(v))||s.rotation.Sum(v=>(double)v*v)<.9||s.rotation.Sum(v=>(double)v*v)>1.1))
                    throw new InvalidDataException("Saved Monk transform is invalid.");
                if(s.health.HasValue&&(!Finite(s.health.Value)||s.health.Value<0||s.health.Value>1000000))throw new InvalidDataException("Saved Monk health is invalid.");
            }
            if(count>(data.schemaVersion==1?AbbeyMonkSpawnPolicy.MaximumPerRun:AbbeyMonkSpawnPolicy.MaximumMixedPerRun))throw new InvalidDataException("Saved actor consumption exceeds the run budget.");
        }
    }
}
