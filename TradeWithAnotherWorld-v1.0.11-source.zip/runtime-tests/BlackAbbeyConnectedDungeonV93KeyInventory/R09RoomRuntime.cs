using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Host-local room interaction controller. The run owner saves/restores its
    // encounter and handles the post-boss exit; no room-wide hover component.
    internal sealed class R09RoomRuntime : MonoBehaviour
    {
        private LoadedRoom actualRoom;
        private LoadedRoom hallRoom;
        private LoadedRoom DoorRoom=>hallRoom??actualRoom;
        internal static R09RoomRuntime ForHall(LoadedRoom hall)
        {
            if(hall==null||!hall.Root)return null;
            return hall.Root.GetComponent<R09HallRuntimeBinding>()?.Owner??hall.Root.GetComponent<R09RoomRuntime>();
        }
        // Read only by the installed legacy Abbot reflection bridge.
        private object room;
        internal LoadedRoom ActualRoom=>actualRoom;
        internal string ActualSourceSha256=>actualRoom?.Manifest?.sourceSha256;
        internal string ActualManifestSha256=>actualRoom?.Record?.manifestSha256;
        private R09RuntimeContract contract;
        private Func<Humanoid, bool> canInteract;
        private Action<string> log;
        private readonly Dictionary<string, Transform> pivots = new Dictionary<string, Transform>(StringComparer.Ordinal);
        private readonly Dictionary<string, Rigidbody> doorBodies = new Dictionary<string, Rigidbody>(StringComparer.Ordinal);
        private readonly Dictionary<string, Bounds[]> doorBounds = new Dictionary<string, Bounds[]>(StringComparer.Ordinal);
        private float phase, target, lastUse = -10;
        private bool blocked, motionCuePending;
        private Func<bool> progressionUnlocked;
        private bool ProgressionReady => hallRoom == null || progressionUnlocked != null;
        private bool unrecordedDeadChain;
        private string progressionHint="Three old wax seals bind the wood. A balance waits nearby.";
        internal void ConfigureProgressionGate(Func<bool> unlocked)
        {progressionUnlocked=unlocked??throw new ArgumentNullException(nameof(unlocked));if(!unlocked()){phase=target=0;motionCuePending=false;SyncPose(true);}}
        internal void ConfigureUnrecordedDeadGate(Func<bool> unlocked)
        {unrecordedDeadChain=true;progressionHint="An old binding seals the doors. The chain is padlocked.";ConfigureProgressionGate(unlocked);}
        internal float DoorProgress=>phase;
        internal bool OperateUnrecordedDeadChain(Player player)
        {
            if(!unrecordedDeadChain||!player||!canInteract(player)||!actualRoom.Root.activeInHierarchy||progressionUnlocked==null||!progressionUnlocked()||!ApproachSide(player))return false;
            if(Time.unscaledTime-lastUse<.35f)return false;
            lastUse=Time.unscaledTime;target=target>.5f?0:1;motionCuePending=true;return true;
        }
        internal Transform QuestDoorAttachment(bool left)=>pivots.TryGetValue(left?contract.Interactions.bossDoor.leftPart:contract.Interactions.bossDoor.rightPart,out var t)?t:null;
        private R09EncounterState encounter;
        private BossMusicRuntime music;
        private R09CandleIgnitionAudio ignition;
        private R09CandleGroupBinding[] candleGroups = Array.Empty<R09CandleGroupBinding>();
        private float nearestCandleZ, farthestCandleZ;
        private Vector3 previousRoomPosition;
        private Quaternion previousRoomRotation;
        internal bool IsOpen => target > .5f;
        internal bool DoorVisibleThrough=>PortalVisibilityPolicy.PortalOpen(IsOpen,
            Mathf.Abs(AngleAt(contract.Interactions.bossDoor.leftPart,Mathf.Clamp01(phase))));
        internal string HallInstanceId=>DoorRoom?.InstanceId;
        internal bool EncounterCompleted => encounter?.Current == R09EncounterState.Stage.Completed;
        internal bool EncounterStarted => encounter?.Started==true;
        internal void RestorePersistentEncounter(bool started,bool completed)
        {
            if(encounter==null||!started&&!completed)return;
            encounter.Restore(started,completed);
            if(started&&!completed){phase=target=0;motionCuePending=false;}
            ApplyEncounterLights();
            if(completed)foreach(var group in candleGroups)if(group)group.RestoreLitEffects();
        }
        internal void AttachExitBell(Action<Player> exit)
        {
            if(exit==null||!pivots.TryGetValue("bell_casting",out var bell))return;
            foreach(var shape in bell.GetComponentsInChildren<Collider>(true))
            {
                var proxy=shape.GetComponent<R09ExitBellProxy>()??shape.gameObject.AddComponent<R09ExitBellProxy>();
                proxy.Owner=this;proxy.Shape=shape;proxy.Exit=exit;
            }
        }
        internal bool CanUseBell(Player player)=>player&&player==Player.m_localPlayer&&actualRoom!=null&&actualRoom.Root&&actualRoom.Root.activeInHierarchy&&canInteract(player);
        private bool Moving => Mathf.Abs(phase - target) > .00001f;

        internal static void Attach(LoadedRoom actualRoom, string directory, Func<Humanoid, bool> canInteract, Action<string> log, BossMusicRuntime music = null)
        {
            if (actualRoom == null || actualRoom.Manifest == null || !actualRoom.Root) throw new ArgumentNullException(nameof(actualRoom));
            if (actualRoom.Manifest.roomId != "R09") return;
            if (actualRoom.Root.activeSelf || actualRoom.Root.activeInHierarchy || actualRoom.Root.GetComponent<R09RoomRuntime>())
                throw new InvalidOperationException("Attach R09 once, to the inactive loaded room before placement/activation.");
            if (canInteract == null) throw new ArgumentNullException(nameof(canInteract));
            var spec = R09RuntimeContract.Read(directory, actualRoom.Manifest);
            string actualManifestHash=actualRoom.Manifest.sourceSha256==R09CandleSourceBinding.AlternateSourceSha256
                ?CatalogReader.HashFile(RoomPackage.FilePath(directory,"manifest.json")):actualRoom.Record?.manifestSha256;
            object actorView=R09EncounterCompatibility.LegacyActorView(actualRoom,actualRoom.Root,actualRoom.InstanceId,
                actualRoom.Manifest.roomId,actualRoom.Manifest.sourceSha256,actualRoom.Record?.sourceSha256,
                actualRoom.Record?.manifestSha256,actualManifestHash);
            var controller = actualRoom.Root.AddComponent<R09RoomRuntime>();
            controller.actualRoom = actualRoom; controller.room=actorView;
            controller.contract = spec; controller.canInteract = canInteract; controller.log = log;
            controller.music = music;
            controller.Build();
            log?.Invoke("R09_LOCAL_RUNTIME: four exact source-rest pivots; signed boss leaves -90/+90; native-rest bell/clapper; three separate shadowless fracture spills; source-bound manifest window lights; optional local encounter=" + (spec.Interactions.encounter?.enabled == true) + ". No boss AI, ringing, network or persistent state.");
        }

        internal static void AttachSplit(LoadedRoom chamber,LoadedRoom hall,string chamberDirectory,string hallDirectory,
            Func<Humanoid,bool> canInteract,Action<string> log,BossMusicRuntime music=null)
        {
            if(chamber?.Manifest==null||hall?.Manifest==null||!chamber.Root||!hall.Root||
                !R09SplitIdentity.IsChamber(chamber.Manifest.roomId)||!R09SplitIdentity.IsHall(hall.Manifest.roomId)||
                string.IsNullOrWhiteSpace(chamber.InstanceId)||string.IsNullOrWhiteSpace(hall.InstanceId)||chamber.InstanceId==hall.InstanceId)
                throw new InvalidDataException("Split boss assembly needs one actual distinct hall/chamber pair.");
            if(chamber.Root.activeSelf||hall.Root.activeSelf||chamber.Root.activeInHierarchy||hall.Root.activeInHierarchy||
                chamber.Root.GetComponent<R09RoomRuntime>()||hall.Root.GetComponent<R09RoomRuntime>()||hall.Root.GetComponent<R09HallRuntimeBinding>())
                throw new InvalidOperationException("Bind the split boss once after source chunks/fixtures, while both roots are inactive.");
            if(canInteract==null)throw new ArgumentNullException(nameof(canInteract));
            if((chamber.Root.transform.position-hall.Root.transform.position).sqrMagnitude>1e-8f||
                Quaternion.Angle(chamber.Root.transform.rotation,hall.Root.transform.rotation)>.001f||
                (chamber.Root.transform.lossyScale-Vector3.one).sqrMagnitude>1e-8f||
                (hall.Root.transform.lossyScale-Vector3.one).sqrMagnitude>1e-8f)
                throw new InvalidDataException("R09 internal boss threshold requires identical world frames and unit scale, with no connector gap.");
            foreach(var pair in new[]{new[]{chamberDirectory,"manifest.json"},new[]{hallDirectory,"manifest.json"}})
            {
                var owner=pair[0]==chamberDirectory?chamber:hall;
                if(owner.Record?.sourceSha256!=owner.Manifest.sourceSha256||
                    owner.Record.manifestSha256!=CatalogReader.HashFile(RoomPackage.FilePath(pair[0],pair[1])))
                    throw new InvalidDataException("Split boss owner differs from its actual sealed catalog/manifest.");
            }
            var chamberContract=R09RuntimeContract.Read(chamberDirectory,chamber.Manifest);
            var hallContract=R09RuntimeContract.Read(hallDirectory,hall.Manifest);
            var spec=R09RuntimeContract.Join(hallContract,chamberContract);
            object actorView=R09EncounterCompatibility.LegacyActorView(chamber,chamber.Root,chamber.InstanceId,
                chamber.Manifest.roomId,chamber.Manifest.sourceSha256,chamber.Record.sourceSha256,
                chamber.Record.manifestSha256,CatalogReader.HashFile(RoomPackage.FilePath(chamberDirectory,"manifest.json")));
            var controller=chamber.Root.AddComponent<R09RoomRuntime>();
            controller.actualRoom=chamber;controller.hallRoom=hall;controller.room=actorView;
            controller.contract=spec;controller.canInteract=canInteract;controller.log=log;controller.music=music;
            controller.Build();
            hall.Root.AddComponent<R09HallRuntimeBinding>().Owner=controller;
            AbbeyCenserEffects.Attach(hall,hallContract.Interactions.censers,log);
            log?.Invoke("R09_SPLIT_RUNTIME_READY: one B-owned encounter; selected="+hall.Manifest.roomId+"; hall-owned leaf pivots;42 always-lit hall/156 chamber-wave wicks; same-frame joint; trigger1.2/slam.55/wave5.");
        }

        private void Build()
        {
            var root = actualRoom.Root.transform;
            // Resolve and validate every exported child before making a pivot.
            // Identity local transforms are essential: the BAR1 vertices are
            // already local to their source part pivot, not room coordinates.
            var visual = new Dictionary<string, Transform>(StringComparer.Ordinal);
            var collision = new Dictionary<string, Transform>(StringComparer.Ordinal);
            foreach (var p in contract.Parts)
            {
                var partRoot=p.id.StartsWith("boss_",StringComparison.Ordinal)?DoorRoom.Root.transform:root;
                var byName=partRoot.GetComponentsInChildren<Transform>(true).GroupBy(t=>t.name,StringComparer.Ordinal).ToDictionary(g=>g.Key,g=>g.ToArray(),StringComparer.Ordinal);
                foreach (string name in p.visualMeshes) visual.Add(name, RequiredChild(byName, name, partRoot, false));
                foreach (string name in p.colliderMeshes) collision.Add(name, RequiredChild(byName, "Collider | " + name, partRoot, true));
            }
            foreach (var p in contract.Parts)
            {
                var host = new GameObject("BA_R09 | source pivot | " + p.id);
                host.transform.SetParent(p.id.StartsWith("boss_",StringComparison.Ordinal)?DoorRoom.Root.transform:root, false);
                host.transform.localPosition = V(p.pivot);
                host.transform.localRotation = Quaternion.identity;
                host.transform.localScale = Vector3.one;
                pivots.Add(p.id, host.transform);
            }
            foreach (var p in contract.Parts.Where(p => !string.IsNullOrEmpty(p.parentPart)))
            {
                var pivot = pivots[p.id];
                pivot.SetParent(pivots[p.parentPart], false);
                pivot.localPosition = V(p.parentRelativePivot);
                pivot.localRotation = Quaternion.identity;
            }
            foreach (var p in contract.Parts)
            {
                var pivot = pivots[p.id];
                foreach (string name in p.visualMeshes) ParentChunk(visual[name], pivot);
                foreach (string name in p.colliderMeshes) ParentChunk(collision[name], pivot);
                if (!p.id.StartsWith("boss_", StringComparison.Ordinal)) continue;
                doorBounds.Add(p.id, p.colliderMeshes.Select(n => collision[n].GetComponent<MeshCollider>().sharedMesh.bounds).ToArray());
                // Kinematic roots retain the exact nonconvex shaped source
                // colliders. No rectangular replacement blocks the pointed top.
                var body = pivot.gameObject.AddComponent<Rigidbody>();
                body.isKinematic = true; body.useGravity = false;
                body.interpolation = RigidbodyInterpolation.None;
                body.collisionDetectionMode = CollisionDetectionMode.ContinuousSpeculative;
                doorBodies.Add(p.id, body);
                foreach (string name in p.colliderMeshes)
                {
                    var proxy = collision[name].gameObject.AddComponent<R09BossDoorProxy>();
                    proxy.Owner = this;
                    proxy.Shape = collision[name].GetComponent<MeshCollider>();
                }
            }
            phase = target = 0;
            SyncPose(true);
            if (contract.Encounter?.enabled == true)
            {
                encounter = new R09EncounterState(contract.Encounter);
                candleGroups = actualRoom.Root.GetComponentsInChildren<R09CandleGroupBinding>(true)
                    .Concat(hallRoom!=null?hallRoom.Root.GetComponentsInChildren<R09CandleGroupBinding>(true):Array.Empty<R09CandleGroupBinding>()).ToArray();
                if(candleGroups.Sum(g=>g.SocketCount)!=contract.EffectiveFixtureCount) throw new InvalidDataException("R09 effective candle inventory is incomplete.");
                var main = candleGroups.Where(g => g.SourceZ >= contract.Encounter.chamberStartZ).ToArray();
                if (main.Length == 0) throw new InvalidDataException("R09 encounter requires source-bound main-chamber candle groups.");
                nearestCandleZ = main.Min(g => g.SourceZ); farthestCandleZ = main.Max(g => g.SourceZ);
                ignition = R09CandleIgnitionAudio.Attach(actualRoom.Root, log);
                ignition.Warmup();
                ApplyEncounterLights();
                log?.Invoke("R09_ENCOUNTER_READY: main chamber dark; approach candles retained; source-bound trigger Z=" + contract.Encounter.triggerZ + "; hashed sidecar trigger="+contract.Interactions.encounter.triggerZ+"; canonical sockets="+actualRoom.Manifest.sockets.Length+"; effective sockets="+contract.EffectiveFixtureCount+"; local instance only.");
            }
            foreach (var s in contract.Lighting.bellSpills)
            {
                var host = new GameObject("BA_R09 | separate fracture spill | " + s.id);
                host.transform.SetParent(pivots[s.parentPart], false);
                host.transform.localPosition = V(s.position);
                host.transform.localRotation = Quaternion.identity;
                var light = host.AddComponent<Light>();
                light.type = LightType.Point;
                light.color = new Color(s.color[0], s.color[1], s.color[2]);
                light.intensity = s.intensity; light.range = DungeonLightReachPolicy.AuxiliaryRange(s.range);
                light.shadows = LightShadows.None; light.bounceIntensity = 0;
                light.renderMode = LightRenderMode.ForcePixel; light.enabled = true;
                log?.Invoke("R09_BELL_SPILL: " + s.id + "; castingLocal=" + host.transform.localPosition + "; intensity=" + s.intensity + "; range=" + light.range + "; stationary/shadowless; sourceSocket=" + s.sourceSocket);
            }
            AbbeyCenserEffects.Attach(actualRoom,contract.Interactions.censers,log);
        }

        private static Transform RequiredChild(Dictionary<string, Transform[]> lookup, string name, Transform root, bool collider)
        {
            if (!lookup.TryGetValue(name, out var found) || found.Length != 1 || found[0].parent != root)
                throw new InvalidDataException("Missing/ambiguous/direct-parent R09 chunk: " + name);
            var t = found[0];
            if (t.localPosition.sqrMagnitude > .00000001f || Quaternion.Angle(t.localRotation, Quaternion.identity) > .001f ||
                (t.localScale - Vector3.one).sqrMagnitude > .00000001f || t.GetComponent<Rigidbody>())
                throw new InvalidDataException("R09 pivot-local chunk has an unexpected rest transform/body: " + name);
            if (collider)
            {
                var shape = t.GetComponent<MeshCollider>();
                if (!shape || !shape.sharedMesh || shape.convex || shape.isTrigger || t.GetComponents<Collider>().Length != 1)
                    throw new InvalidDataException("R09 requires the exact shaped nontrigger source MeshCollider: " + name);
            }
            else if (!t.GetComponent<MeshFilter>() || !t.GetComponent<MeshFilter>().sharedMesh || !t.GetComponent<MeshRenderer>())
                throw new InvalidDataException("R09 moving visual chunk is incomplete: " + name);
            return t;
        }

        private static void ParentChunk(Transform chunk, Transform pivot)
        {
            chunk.SetParent(pivot, false);
            chunk.localPosition = Vector3.zero;
            chunk.localRotation = Quaternion.identity;
            chunk.localScale = Vector3.one;
        }

        private static Vector3 V(float[] v) => new Vector3(v[0], v[1], v[2]);
        private float AngleAt(string id, float amount)
        {
            float eased = amount * amount * (3 - 2 * amount);
            float signedEndpoint = id == contract.Interactions.bossDoor.leftPart ? contract.Interactions.bossDoor.leftOpenDegrees : contract.Interactions.bossDoor.rightOpenDegrees;
            return Mathf.Clamp(signedEndpoint * eased, -90f, 90f);
        }

        private void SyncPose(bool teleport)
        {
            if (actualRoom == null || !actualRoom.Root) return;
            foreach (var pair in doorBodies)
            {
                var part = contract.Part(pair.Key);
                Vector3 position = DoorRoom.Root.transform.TransformPoint(V(part.pivot));
                Quaternion rotation = DoorRoom.Root.transform.rotation * Quaternion.AngleAxis(AngleAt(part.id, Mathf.Clamp01(phase)), V(part.axis));
                if (teleport) { pair.Value.position = position; pair.Value.rotation = rotation; }
                else { pair.Value.MovePosition(position); pair.Value.MoveRotation(rotation); }
            }
            previousRoomPosition = actualRoom.Root.transform.position;
            previousRoomRotation = actualRoom.Root.transform.rotation;
        }

        // Attach occurs before the parent receives its grid pose. Synchronize
        // only after activation so bodies never retain their pre-placement pose.
        private void OnEnable() { if (actualRoom != null) SyncPose(true); }
        internal void SyncBodies() { if (actualRoom != null) SyncPose(true); }

        private void Update()
        {
            if (encounter == null || actualRoom == null || !actualRoom.Root) return;
            var player = Player.m_localPlayer;
            Vector3 p = player ? actualRoom.Root.transform.InverseTransformPoint(player.transform.position) : Vector3.zero;
            var previousStage = encounter.Current;
            if (encounter.Observe(ProgressionReady && player && canInteract(player)&&(progressionUnlocked==null||progressionUnlocked()), p.x, p.y, p.z, Time.time))
            {
                target = 0; motionCuePending = phase > .00001f;
                MusicEvent(m => m.BeginEncounter());
                log?.Invoke("R09_ENCOUNTER_STARTED: inward source-trigger crossing; doors slam/lock; source-position candle wave from bell to entrance.");
            }
            // A returning player may open a still-active encounter from the
            // approach side after death/reload. Seal it again at the same
            // quarter-depth line, without resetting candles or boss progress.
            if(encounter.Locked&&target>.5f&&player&&canInteract(player)&&InRoom(p)&&p.z>=contract.Encounter.triggerZ)
            {target=0;motionCuePending=phase>.00001f;}
            bool eligible = ProgressionReady && player && !player.IsDead() && canInteract(player) && InRoom(p);
            bool wave = R09CandleIgnitionPolicy.IsLightingWave(previousStage, encounter.Current);
            ApplyEncounterLights(eligible && wave);
            if (!eligible && ignition) ignition.StopVoices();
        }

        private bool InRoom(Vector3 p)
        {
            var low = actualRoom.Manifest.boundsMin; var high = actualRoom.Manifest.boundsMax;
            return p.x >= low[0] && p.x <= high[0] && p.y >= low[1] - .2f && p.y <= high[1] + .2f && p.z >= low[2] && p.z <= high[2];
        }
        private void ApplyEncounterLights(bool audibleWave = false)
        {
            if (encounter == null) return;
            Vector3 nearest = Vector3.zero; float nearestDistance = float.PositiveInfinity;
            var player = Player.m_localPlayer;
            foreach (var group in candleGroups) if (group)
            {
                bool wasLit = group.IsLit;
                bool lit = encounter.Lit(group.SourceZ, farthestCandleZ, nearestCandleZ, Time.time);
                group.SetLit(lit);
                if (audibleWave && player && group.SourceZ >= contract.Encounter.chamberStartZ && R09CandleIgnitionPolicy.NewlyLit(wasLit, lit))
                {
                    var center = group.WickCenter; float distance = (center - player.transform.position).sqrMagnitude;
                    if (distance < nearestDistance) { nearestDistance = distance; nearest = center; }
                }
            }
            if (nearestDistance < 42 * 42 && ignition) ignition.Play(nearest);
        }

        internal bool CompleteEncounter()
        {
            if (encounter == null || !encounter.Complete(true)) return false;
            MusicEvent(m => m.CompleteEncounter());
            ApplyEncounterLights();
            foreach(var group in candleGroups) if(group) group.RestoreLitEffects();
            log?.Invoke("R09_ENCOUNTER_COMPLETED: test command marks boss dead; doors unlocked for E; no boss kill, loot or persistent progression claimed.");
            return true;
        }
        internal bool ResetEncounter()
        {
            if (encounter == null) return false;
            encounter.Reset(); target = progressionUnlocked==null||progressionUnlocked()?1:0; motionCuePending = phase < .99999f;
            if (ignition) ignition.ResetWave();
            MusicEvent(m => m.ResetEncounter());
            ApplyEncounterLights();
            log?.Invoke("R09_ENCOUNTER_RESET: main candles dark, doors open/unlocked; retreat below quarter-depth plane before a new inward crossing.");
            return true;
        }

        private void FixedUpdate()
        {
            if (actualRoom == null || !actualRoom.Root) return;
            if (actualRoom.Root.transform.position != previousRoomPosition || actualRoom.Root.transform.rotation != previousRoomRotation) SyncPose(true);
            if (!Moving) { blocked = false; motionCuePending = false; return; }
            var player = Player.m_localPlayer;
            if (!player || !canInteract(player)) return;
            float duration = encounter?.Locked == true && target == 0 ? contract.Encounter.slamDurationSeconds : contract.Interactions.bossDoor.durationSeconds;
            float next = Mathf.MoveTowards(phase, target, Time.fixedDeltaTime / duration);
            if (StepBlocked(player, phase, next))
            {
                if (!blocked) log?.Invoke("R09_BOSS_DOOR_BLOCKED: local participant is in the next leaf sweep; pose held without changing room or persistent state.");
                blocked = true; return;
            }
            if (blocked) log?.Invoke("R09_BOSS_DOOR_RESUMED: local participant cleared the next leaf sweep.");
            blocked = false;
            if (motionCuePending && Mathf.Abs(next - phase) > .000001f)
            {
                var left = V(contract.Part(contract.Interactions.bossDoor.leftPart).pivot);
                var right = V(contract.Part(contract.Interactions.bossDoor.rightPart).pivot);
                AbbeyDoorAudio.Play(DoorRoom.Root.transform.TransformPoint((left + right) * .5f + Vector3.up * 1.25f), target > .5f);
                motionCuePending = false;
            }
            phase = Mathf.Clamp01(next); SyncPose(false);
        }

        private void MusicEvent(Action<BossMusicRuntime> action)
        {
            if (!music) return;
            try { action(music); }
            catch (Exception error) { music.Release(); log?.Invoke("R09 music event unavailable; doors/candles continue: " + error.Message); }
        }

        private bool StepBlocked(Player player, float from, float to)
        {
            if (!player || player != Player.m_localPlayer || !canInteract(player)) return false;
            // Only the finite next physics step is tested, so standing outside
            // a future sweep does not prevent starting an otherwise clear door.
            foreach (float sample in new[] { from, (from + to) * .5f, to })
                foreach (var pair in doorBounds)
                {
                    var part = contract.Part(pair.Key);
                    Quaternion q = Quaternion.AngleAxis(AngleAt(part.id, sample), V(part.axis));
                    Quaternion world = DoorRoom.Root.transform.rotation * q;
                    foreach (var bounds in pair.Value)
                    {
                        Vector3 center = DoorRoom.Root.transform.TransformPoint(V(part.pivot) + q * bounds.center);
                        foreach (float height in new[] { .35f, .95f, 1.55f })
                        {
                            Vector3 local = Quaternion.Inverse(world) * (player.transform.position + Vector3.up * height - center);
                            Vector3 d = new Vector3(Mathf.Max(0, Mathf.Abs(local.x) - bounds.extents.x), Mathf.Max(0, Mathf.Abs(local.y) - bounds.extents.y), Mathf.Max(0, Mathf.Abs(local.z) - bounds.extents.z));
                            if (d.sqrMagnitude < .34f * .34f) return true;
                        }
                    }
                }
            return false;
        }

        internal string HoverText()
        {
            if (!ProgressionReady || actualRoom == null || !actualRoom.Root || !actualRoom.Root.activeInHierarchy || !Player.m_localPlayer || !canInteract(Player.m_localPlayer)) return "";
            if(progressionUnlocked!=null&&!progressionUnlocked())return "Abbot's great doors\n"+progressionHint;
            if(unrecordedDeadChain&&ApproachSide(Player.m_localPlayer))return "Abbot's great doors\nOperated by the chain beside the door.";
            if (encounter?.Locked == true&&!ApproachSide(Player.m_localPlayer)) return "Abbot's great doors\nSealed until the abbot falls.";
            string text = "Abbot's great doors\n[<color=yellow><b>$KEY_Use</b></color>] " + (IsOpen ? "Close" : "Open");
            return Localization.instance != null ? Localization.instance.Localize(text) : text;
        }

        internal bool Use(Humanoid user, bool hold, MeshCollider shape)
        {
            if (hold || !this || !ProgressionReady || actualRoom == null || !actualRoom.Root || !actualRoom.Root.activeInHierarchy || !shape ||
                !(user is Player player) || player != Player.m_localPlayer || !canInteract(user)) return false;
            // The E target is already the actual hit leaf collider. Bounds
            // provide a conservative distance guard without asking PhysX for
            // a closest-point query on a nonconvex moving triangle mesh.
            Vector3 usePoint = player.transform.position + Vector3.up;
            if ((shape.bounds.ClosestPoint(usePoint) - usePoint).sqrMagnitude > 20.25f) return false;
            if(progressionUnlocked!=null&&!progressionUnlocked()){player.Message(MessageHud.MessageType.Center,unrecordedDeadChain?"An old binding seals the doors.":"Old wax still binds the doors.");return true;}
            if(unrecordedDeadChain&&ApproachSide(player)){player.Message(MessageHud.MessageType.Center,"Use the chain beside the doors.");return true;}
            if (encounter?.Locked == true&&!ApproachSide(player)) return true;
            if (Time.unscaledTime - lastUse < .35f) return true;
            lastUse = Time.unscaledTime; target = target > .5f ? 0 : 1; motionCuePending = true;
            log?.Invoke("R09_BOSS_DOOR_TARGET: " + (target > .5f ? "open" : "closed") + "; source signed limits -90/+90; local-only.");
            return true;
        }
        private bool ApproachSide(Player player)=>player&&actualRoom.Root.transform.InverseTransformPoint(player.transform.position).z<contract.Encounter.chamberStartZ;
    }

    // The hall exposes its door service without owning another encounter or
    // Update hook. The separate installed actor therefore sees only B.
    internal sealed class R09HallRuntimeBinding:MonoBehaviour
    {
        internal R09RoomRuntime Owner;
    }

    // A delegate exists only on each actual boss-leaf collider object. The
    // room root, floor and static doorway masonry get no E component.
    public sealed class R09BossDoorProxy : MonoBehaviour, Hoverable, Interactable
    {
        internal R09RoomRuntime Owner;
        internal MeshCollider Shape;
        public string GetHoverName() => "Abbot's great doors";
        public float GetHoverOffset() => .15f;
        public string GetHoverText() => Owner ? Owner.HoverText() : "";
        public bool Interact(Humanoid user, bool hold, bool alt) => Owner && Owner.Use(user, hold, Shape);
        public bool UseItem(Humanoid user, ItemDrop.ItemData item) => false;
    }
    public sealed class R09ExitBellProxy:MonoBehaviour,Hoverable,Interactable
    {
        internal R09RoomRuntime Owner;internal Collider Shape;internal Action<Player> Exit;
        float lastUse=-10;
        public string GetHoverName()=>"Abbot's Bell";
        public float GetHoverOffset()=>.15f;
        public string GetHoverText()
        {
            if(!Owner||!Owner.CanUseBell(Player.m_localPlayer))return "";
            string text=Owner.EncounterCompleted?"Abbot's Bell\n[<color=yellow><b>$KEY_Use</b></color>] Leave the abbey":"Abbot's Bell\nSealed until the abbot falls.";
            return Localization.instance!=null?Localization.instance.Localize(text):text;
        }
        public bool Interact(Humanoid user,bool hold,bool alt)
        {
            if(hold||!(user is Player player)||!Owner||!Shape||!Owner.CanUseBell(player))return false;
            Vector3 point=player.transform.position+Vector3.up;
            if((Shape.bounds.ClosestPoint(point)-point).sqrMagnitude>25)return false;
            if(!Owner.EncounterCompleted){player.Message(MessageHud.MessageType.Center,"The bell is silent until the abbot falls.");return true;}
            if(Time.unscaledTime-lastUse<1)return true;lastUse=Time.unscaledTime;Exit?.Invoke(player);return true;
        }
        public bool UseItem(Humanoid user,ItemDrop.ItemData item)=>false;
    }
}
