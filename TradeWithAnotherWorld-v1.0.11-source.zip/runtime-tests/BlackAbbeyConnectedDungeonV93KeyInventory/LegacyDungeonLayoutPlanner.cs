using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeySixRooms
{
    internal static class LegacyDungeonLayoutPlanner
    {
        internal const double JointClearance=.02;
        internal static double ThresholdGap(PortRecord a,PortRecord b)=>(double)a.depth+b.depth+JointClearance;
        internal static bool Overlap(double[] a,double[] b)=>Math.Min(a[2],b[2])-Math.Max(a[0],b[0])>.015&&Math.Min(a[3],b[3])-Math.Max(a[1],b[1])>.015;
        internal static bool Overlap3D(double[] a,double lowA,double highA,double[] b,double lowB,double highB)=>Overlap(a,b)&&Math.Min(highA,highB)-Math.Max(lowA,lowB)>.015;
        private static void Shuffle<T>(IList<T> list,Random random)
        { for(int i=list.Count-1;i>0;i--){int j=random.Next(i+1);T x=list[i];list[i]=list[j];list[j]=x;} }
        private static DungeonRoomSpec[] ValidateSpecs(IEnumerable<DungeonRoomSpec> input)
        {
            var specs=input?.ToArray()??Array.Empty<DungeonRoomSpec>();
            if(specs.Length<2||specs.Any(s=>s==null||string.IsNullOrWhiteSpace(s.Id)||string.IsNullOrWhiteSpace(s.SourceId)||s.Ports==null||s.Ports.Length<1||s.Bounds==null||s.Bounds.Length!=4||s.Bounds.Any(v=>double.IsNaN(v)||double.IsInfinity(v))||s.Bounds[0]>=s.Bounds[2]||s.Bounds[1]>=s.Bounds[3])||specs.Select(s=>s.Id).Distinct().Count()!=specs.Length)throw new ArgumentException("Complete unique room definitions and at least one port are required.");
            foreach(var s in specs)foreach(var p in s.Ports)
                if(p==null||string.IsNullOrWhiteSpace(p.id)||s.Ports.Count(q=>q?.id==p.id)!=1||p.position?.Length!=3||p.outward?.Length!=3||p.position.Concat(p.outward).Concat(new[]{p.width,p.height,p.depth}).Any(v=>float.IsNaN(v)||float.IsInfinity(v))||p.width<2.4f||p.height<3f||p.depth<0||p.depth>1||Math.Abs(p.position[1])>100||!((Math.Abs(Math.Abs(p.outward[0])-1)<.001&&Math.Abs(p.outward[2])<.001)||(Math.Abs(Math.Abs(p.outward[2])-1)<.001&&Math.Abs(p.outward[0])<.001))||Math.Abs(p.outward[1])>.001)
                    throw new ArgumentException("Unsupported connector dimensions or noncardinal threshold.");
            if(specs.Any(s=>s.BoundsY!=null&&(s.BoundsY.Length!=2||s.BoundsY.Any(v=>double.IsNaN(v)||double.IsInfinity(v))||s.BoundsY[0]>=s.BoundsY[1])))throw new ArgumentException("Invalid room height envelope.");
            if(specs.Where(s=>s.SourceId=="R08").Any(stair=>stair.Ports.Length!=2||Math.Abs(stair.Ports.Min(p=>p.position[1]))>.001||Math.Abs(stair.Ports.Max(p=>p.position[1])-10.8)>.001||stair.BoundsY==null))throw new ArgumentException("Every R08 requires the actual lower0/upper10.8m thresholds and full shaft height.");
            var first=specs.SingleOrDefault(s=>s.Id=="R01"&&s.SourceId=="R01");
            if(first==null||specs.Where(s=>s.SourceId=="R01").Any(r=>r.Ports.Length<2||r.Ports.Count(p=>p.outward[2]<-.9f)!=1))throw new ArgumentException("R01 must retain its original south entrance and at least one interior port.");
            return specs;
        }
        // Explicit source showcase: retain its exact seeded all-room behavior.
        internal static DungeonPlan Generate(IEnumerable<DungeonRoomSpec> input,int seed)
        {
            var specs=ValidateSpecs(input);
            var stairs=specs.Where(s=>s.SourceId=="R08").ToArray();
            var first=specs.Single(s=>s.Id=="R01"&&s.SourceId=="R01");
            var entrance=first.Ports.Single(p=>p.outward[2]<-.9f);
            var diagnostics=new DungeonPlanningDiagnostics{MaximumPlaced=1};
            for(int attempt=0;attempt<64;attempt++)
            {
                diagnostics.Attempts++;
                var random=new Random(unchecked(seed+attempt*104729));var order=specs.Where(s=>s!=first).ToList();Shuffle(order,random);
                // Keep connecting rooms available before attaching terminal
                // shrines. Existing all-multiport catalogs retain their same
                // seeded shuffle/order; a one-port room is a legitimate leaf.
                order=order.OrderBy(s=>s.Ports.Length==1?1:0).ToList();
                // The test deliberately includes the stair and its upper room;
                // its two ports must both be connected, rather than a barred
                // upper landing that cannot test the elevation transition.
                foreach(var stair in stairs.Reverse()){order.Remove(stair);order.Insert(0,stair);}
                var placed=new List<DungeonPlacement>{new DungeonPlacement{Spec=first,Position=new PlanPoint(0,0)}};var links=new List<DungeonLink>();int budget=10000;
                if(Add(0,order,placed,links,entrance.id,random,ref budget,diagnostics))return new DungeonPlan{Seed=seed,Mode="showcase",Rooms=placed.ToArray(),Links=links.ToArray(),EntryPort=entrance.id,Diagnostics=diagnostics};
            }
            throw new InvalidOperationException("Could not fit all source rooms without overlap; seed="+seed+"; "+diagnostics+"; current floors were preserved.");
        }
        internal static DungeonPlan GenerateNatural(IEnumerable<DungeonRoomSpec> input,int seed)
            => GenerateNatural(input,seed,false);
        internal static DungeonPlan GenerateNatural(IEnumerable<DungeonRoomSpec> input,int seed,bool oneBrokenSaint)
            => GenerateNatural(input,seed,oneBrokenSaint,0);
        internal static DungeonPlan GenerateNatural(IEnumerable<DungeonRoomSpec> input,int seed,bool oneBrokenSaint,int minimumQuestHops)
        {
            if(minimumQuestHops!=0&&minimumQuestHops!=4||minimumQuestHops>0&&!oneBrokenSaint)throw new ArgumentOutOfRangeException(nameof(minimumQuestHops));
            var canonical=ValidateSpecs(input);LegacyNaturalDungeonRoster.ValidateCanonical(canonical);
            var diagnostics=new DungeonPlanningDiagnostics{MaximumPlaced=1};string lastRoster="none";
            for(int rosterAttempt=0;rosterAttempt<LegacyNaturalDungeonRoster.MaximumRosterAttempts;rosterAttempt++)
            {
                diagnostics.RosterAttempts++;
                var selected=LegacyNaturalDungeonRoster.Select(canonical,seed,rosterAttempt,oneBrokenSaint);
                if(selected==null){diagnostics.RosterRejections++;continue;}
                var specs=ValidateSpecs(selected);diagnostics.SelectedRoomCount=specs.Length;
                lastRoster=string.Join(",",specs.Select(s=>s.Id+":"+s.SourceId));
                var first=specs.Single(s=>s.Id=="R01"&&s.SourceId=="R01");var entrance=first.Ports.Single(p=>p.outward[2]<-.9f);
                for(int attempt=0;attempt<LegacyNaturalDungeonRoster.MaximumLayoutAttempts;attempt++)
                {
                    diagnostics.Attempts++;
                    diagnostics.NormalTargetRooms=specs.Length;diagnostics.ExtensionRooms=0;diagnostics.ExtensionReason="none";
                    diagnostics.BossExtensionRooms=0;diagnostics.BossExtensionReason="none";diagnostics.BossAnchorRoomId=diagnostics.BossAnchorPortId=null;diagnostics.BossAnchorDepth=0;
                    var random=new Random(unchecked(seed+rosterAttempt*15485863+attempt*104729));
                    var pool=specs.Where(s=>s!=first&&s.SourceId!="R09").ToList();Shuffle(pool,random);
                    var placed=new List<DungeonPlacement>{new DungeonPlacement{Spec=first,Position=new PlanPoint(0,0)}};
                    var links=new List<DungeonLink>();int budget=LegacyNaturalDungeonRoster.PlacementBudget;
                    int loopCount=LegacyNaturalDungeonRoster.LoopCount(seed);
                    if(loopCount>0)
                    {
                        int last=0;bool okay=true;
                        int prefix=random.Next(4);
                        for(int i=0;i<prefix&&okay;i++)okay=AppendFromPool(pool,s=>s.SourceId=="R01"||s.SourceId=="R02"||s.SourceId=="R08",last,placed,links,entrance.id,random,ref budget,diagnostics,out last);
                        if(!okay||!AppendFromPool(pool,s=>s.SourceId=="R04",last,placed,links,entrance.id,random,ref budget,diagnostics,out int anchor))continue;
                        last=anchor;
                        // The backbone and both return routes share the same
                        // finite room allowance. Small rosters reserve more of
                        // it for actual closures instead of a long first spine.
                        int middle=1+random.Next(specs.Length<24?2:3);
                        for(int i=0;i<middle&&okay;i++)okay=AppendFromPool(pool,s=>s.Ports.Length>=2&&s.SourceId!="R08"&&s.SourceId!="R04",last,placed,links,entrance.id,random,ref budget,diagnostics,out last);
                        if(!okay||!AppendFromPool(pool,s=>s.SourceId=="R03"||s.SourceId=="R03_complete"||s.SourceId=="R04",last,placed,links,entrance.id,random,ref budget,diagnostics,out int other,true))continue;
                        // Tight small rosters benefit from a few alternate
                        // closures. Larger rosters have spare route pieces;
                        // prefer a new spine over a deep three-cycle search.
                        var search=new RouteNetworkSearch{RemainingAlternatives=specs.Length<24?32:loopCount-1,NormalSpecs=specs,WantedCycles=loopCount,OneBrokenSaint=oneBrokenSaint};
                        if(!CloseRouteNetwork(pool,placed,links,entrance.id,random,ref budget,diagnostics,loopCount,canonical,search,anchor,other))continue;
                    }
                    var order=pool.ToList();Shuffle(order,random);
                    // Leaves follow connecting rooms, but stairs retain their
                    // seeded random positions rather than fixed early slots.
                    order=order.OrderBy(s=>s.Ports.Length==1?1:0).ToList();order.Add(specs.Single(s=>s.SourceId=="R09"));
                    if(Add(0,order,placed,links,entrance.id,random,ref budget,diagnostics,true,true,new NaturalCompletion{Canonical=canonical,NormalSpecs=specs,OneBrokenSaint=oneBrokenSaint}))
                    {
                        diagnostics.ClosedLoops=links.Count-placed.Count+1;
                        if(diagnostics.ClosedLoops!=loopCount)throw new InvalidOperationException("A route search changed the selected loop target.");
                        int extras=placed.Count(p=>LegacyThirdLoopExtensionPolicy.IsExtraId(p.Spec.Id)),bossExtras=placed.Count(p=>LegacyBossConnectionExtensionPolicy.IsExtraId(p.Spec.Id));
                        if(placed.Count!=specs.Length+extras+bossExtras||placed.Count>LegacyThirdLoopExtensionPolicy.MaximumRooms||
                            extras>0&&(loopCount!=3||!LegacyThirdLoopExtensionPolicy.Accepts(specs.Length,extras))||
                            bossExtras>0&&!LegacyBossConnectionExtensionPolicy.Accepts(specs.Length,extras,bossExtras))throw new InvalidOperationException("Only the third route and necessary boss approach may exceed the normal room target.");
                        diagnostics.ExtensionRooms=extras;diagnostics.ExtensionReason=extras>0?LegacyThirdLoopExtensionPolicy.Reason:"none";
                        diagnostics.BossExtensionRooms=bossExtras;diagnostics.BossExtensionReason=bossExtras>0?LegacyBossConnectionExtensionPolicy.Reason:"none";
                        var result=new DungeonPlan{Seed=seed,Mode="natural",Rooms=placed.ToArray(),Links=links.ToArray(),EntryPort=entrance.id,Diagnostics=diagnostics,FalseVowsMinimumHops=minimumQuestHops};
                        if(minimumQuestHops>0)
                        {
                            int boss=Array.FindIndex(result.Rooms,p=>p.Spec.SourceId=="R09");var gate=result.Links.Single(l=>l.A==boss||l.B==boss);
                            if(!FalseVowsRoomSelector.TrySelect(result.Rooms.Select(p=>new FalseVowsRoomNode(p.Spec.Id,p.Spec.SourceId)),
                                result.Links.Select(l=>new FalseVowsRoomEdge(result.Rooms[l.A].Spec.Id,result.Rooms[l.B].Spec.Id)),"R01",result.Rooms[boss].Spec.Id,
                                result.Rooms[gate.A].Spec.Id,result.Rooms[gate.B].Spec.Id,minimumQuestHops,out _))continue;
                        }
                        return result;
                    }
                }
            }
            throw new InvalidOperationException("Could not fit a natural source roster without overlap; seed="+seed+"; "+diagnostics+"; lastRoster="+lastRoster+"; current floors were preserved.");
        }
        private static bool Used(List<DungeonLink> links,int room,PortRecord port)=>links.Any(l=>l.A==room&&l.PortA.id==port.id||l.B==room&&l.PortB.id==port.id);
        private sealed class RouteNetworkSearch
        {
            internal int RemainingAlternatives;
            internal int WantedCycles;
            internal DungeonRoomSpec[] NormalSpecs;
            internal bool OneBrokenSaint;
            internal readonly HashSet<string> Failed=new HashSet<string>(StringComparer.Ordinal);
        }
        private static bool CloseRouteNetwork(List<DungeonRoomSpec> pool,List<DungeonPlacement> placed,List<DungeonLink> links,string entrance,Random random,ref int budget,DungeonPlanningDiagnostics diagnostics,int remaining,DungeonRoomSpec[] canonical,RouteNetworkSearch search,int anchor=-1,int other=-1)
        {
            if(--budget<=0){budget=0;return false;}
            string signature=remaining+"|"+string.Join(";",placed.Select(p=>p.Spec.Id+":"+p.QuarterTurns+":"+Math.Round(p.Position.X*10000)+":"+Math.Round(p.Position.Z*10000)+":"+Math.Round(p.Elevation*10000)))+"|"+
                string.Join(";",links.Select(l=>l.A+":"+l.PortA.id+":"+l.B+":"+l.PortB.id))+"|"+string.Join(",",pool.Select(s=>s.Id));
            if(search.Failed.Contains(signature))return false;
            Func<int,int> continuation=null;
            if(remaining>1)continuation=available=>
            {
                // A few alternative closures are useful; thousands of nearly
                // equivalent first-loop solutions are not. Restart a different
                // spatial spine when this deterministic branch limit is spent.
                if(search.RemainingAlternatives--<=0){diagnostics.RouteBranchLimits++;return -1;}
                diagnostics.RouteContinuations++;
                int next=available;bool okay=CloseRouteNetwork(pool,placed,links,entrance,random,ref next,diagnostics,remaining-1,canonical,search);
                return okay?next:-Math.Max(0,next)-1;
            };
            bool success=LegacyDungeonRouteClosure.TryClose(pool,placed,links,entrance,random,ref budget,diagnostics,anchor,other,remaining>1,continuation,canonical);
            if(!success&&remaining==1&&search.NormalSpecs!=null&&LegacyThirdLoopExtensionPolicy.Eligible(search.NormalSpecs.Length,search.WantedCycles,links.Count-placed.Count+1,true,search.NormalSpecs.Length))
            {
                diagnostics.ThirdLoopNormalFailures++;
                success=TryThirdLoopExtension(canonical,search.NormalSpecs,pool,placed,links,entrance,random,ref budget,diagnostics,search.WantedCycles,search.NormalSpecs.Length,true,search.OneBrokenSaint);
            }
            if(!success&&search.Failed.Count<2048)search.Failed.Add(signature);return success;
        }
        internal static bool TryThirdLoopExtension(DungeonRoomSpec[] canonical,DungeonRoomSpec[] normalSpecs,List<DungeonRoomSpec> pool,List<DungeonPlacement> placed,List<DungeonLink> links,string entrance,Random random,ref int budget,DungeonPlanningDiagnostics diagnostics,int wantedCycles,int normalTarget,bool normalClosureFailed,bool oneBrokenSaint=false)
        {
            if(normalSpecs==null||pool==null||placed==null||links==null||random==null||diagnostics==null||
                !LegacyThirdLoopExtensionPolicy.Eligible(normalTarget,wantedCycles,links.Count-placed.Count+1,normalClosureFailed,normalSpecs.Length))return false;
            if(placed.Count==0||links.Count(l=>l.IsLoop)!=2||Enumerable.Range(0,placed.Count).Any(i=>LegacyDungeonRouteClosure.Distance(0,i,placed.Count,links)<0))return false;
            var normalIds=new HashSet<string>(normalSpecs.Select(s=>s.Id),StringComparer.Ordinal);
            var accounted=placed.Select(p=>p.Spec).Concat(pool).ToArray();
            if(normalIds.Count!=normalSpecs.Length||accounted.Any(s=>!normalIds.Contains(s.Id)||LegacyThirdLoopExtensionPolicy.IsExtraId(s.Id))||
                accounted.Select(s=>s.Id).Distinct(StringComparer.Ordinal).Count()!=accounted.Length||
                normalSpecs.Where(s=>s.SourceId!="R09").Any(s=>!accounted.Any(a=>a.Id==s.Id)))return false;
            LegacyNaturalDungeonRoster.ValidateCanonical(canonical);
            diagnostics.ExtensionAttempts++;
            var counts=normalSpecs.GroupBy(s=>LegacyNaturalDungeonRoster.Family(s.SourceId)).ToDictionary(g=>g.Key,g=>g.Count(),StringComparer.Ordinal);
            var options=new List<DungeonRoomSpec>();
            foreach(var family in canonical.Where(s=>LegacyThirdLoopExtensionPolicy.EligibleSource(s.SourceId,s.Ports.Length)&&(!oneBrokenSaint||s.SourceId!="R03")).GroupBy(s=>LegacyNaturalDungeonRoster.Family(s.SourceId)).OrderBy(g=>g.Key,StringComparer.Ordinal))
            {
                int existing=counts.TryGetValue(family.Key,out int n)?n:0;
                int allowance=Math.Min(LegacyThirdLoopExtensionPolicy.MaximumRouteExtras,LegacyNaturalDungeonRoster.MaximumOrdinaryRepeats-existing);
                var sources=family.OrderBy(s=>s.SourceId,StringComparer.Ordinal).ToArray();int offset=random.Next(sources.Length);
                var ordinals=new Dictionary<string,int>(StringComparer.Ordinal);
                for(int i=0;i<allowance;i++)
                {
                    var source=sources[(offset+i)%sources.Length];int ordinal=ordinals.TryGetValue(source.SourceId,out int old)?old+1:1;ordinals[source.SourceId]=ordinal;
                    options.Add(new DungeonRoomSpec{Id=source.SourceId+"_loop3_extra_"+ordinal.ToString("00",System.Globalization.CultureInfo.InvariantCulture),SourceId=source.SourceId,
                        Ports=source.Ports.ToArray(),Bounds=source.Bounds.ToArray(),BoundsY=source.BoundsY.ToArray()});
                }
            }
            if(options.Count==0)return false;
            int originalRooms=placed.Count,originalEdges=links.Count;bool success=false;pool.AddRange(options);
            int extensionBudget=LegacyThirdLoopExtensionPolicy.PlacementBudget;
            try
            {
                Func<int,int> accept=available=>
                {
                    var extras=placed.Where(p=>LegacyThirdLoopExtensionPolicy.IsExtraId(p.Spec.Id)).Select(p=>p.Spec).ToArray();
                    bool valid=LegacyThirdLoopExtensionPolicy.Accepts(normalTarget,extras.Length)&&links.Count-placed.Count+1==3&&
                        extras.All(s=>placed.FindIndex(p=>p.Spec.Id==s.Id)>=originalRooms)&&
                        normalSpecs.Concat(extras).GroupBy(s=>LegacyNaturalDungeonRoster.Family(s.SourceId)).Where(g=>g.Key!="R08"&&g.Key!="R09").All(g=>g.Count()<=LegacyNaturalDungeonRoster.MaximumOrdinaryRepeats);
                    return valid?available:-Math.Max(0,available)-1;
                };
                success=LegacyDungeonRouteClosure.TryClose(pool,placed,links,entrance,random,ref extensionBudget,diagnostics,-1,-1,false,accept,canonical);
                if(success)
                {
                    budget=Math.Max(Math.Max(0,budget),extensionBudget);diagnostics.NormalTargetRooms=normalTarget;
                    diagnostics.ExtensionRooms=placed.Count(p=>LegacyThirdLoopExtensionPolicy.IsExtraId(p.Spec.Id));diagnostics.ExtensionReason=LegacyThirdLoopExtensionPolicy.Reason;
                }
                return success;
            }
            finally
            {
                // Offered definitions are not selected rooms. Keep only the
                // consumed route instances, never extra filler for normal Add.
                pool.RemoveAll(s=>LegacyThirdLoopExtensionPolicy.IsExtraId(s.Id));
                if(!success){if(links.Count>originalEdges)links.RemoveRange(originalEdges,links.Count-originalEdges);if(placed.Count>originalRooms)placed.RemoveRange(originalRooms,placed.Count-originalRooms);}
            }
        }
        private static PortRecord Facing(DungeonPlacement room,PlanPoint direction)=>room.Spec.Ports.SingleOrDefault(p=>(room.Normal(p)-direction).Length<.001);
        private static bool AppendFromPool(List<DungeonRoomSpec> pool,Func<DungeonRoomSpec,bool> eligible,int from,List<DungeonPlacement> placed,List<DungeonLink> links,string entrance,Random random,ref int budget,DungeonPlanningDiagnostics diagnostics,out int appended,bool preferStem=false)
        {
            appended=from;var choices=new List<Tuple<DungeonRoomSpec,PortRecord,PortRecord>>();
            foreach(var source in pool.Where(eligible))foreach(var a in placed[from].Spec.Ports)if(!(from==0&&a.id==entrance)&&!Used(links,from,a))foreach(var b in source.Ports)choices.Add(Tuple.Create(source,a,b));
            Shuffle(choices,random);
            var incoming=links.LastOrDefault(l=>l.A==from||l.B==from);
            var incomingPort=incoming==null?null:incoming.A==from?incoming.PortA:incoming.PortB;
            var forward=incomingPort==null?new PlanPoint(0,1):placed[from].Normal(incomingPort)*-1;
            // Search the less obstructed backbone sockets first. This is a
            // preference, not an orientation restriction: random ties and all
            // other legal cardinal poses remain in the candidate list.
            choices=choices.OrderByDescending(c=>
            {
                var n=placed[from].Normal(c.Item2);int score=n.X*forward.X+n.Z*forward.Z>.9?2:0;
                if(preferStem&&c.Item1.Ports.Length==3)
                {var others=c.Item1.Ports.Where(p=>p.id!=c.Item3.id).ToArray();if(new PlanPoint(others[0].outward[0]+others[1].outward[0],others[0].outward[2]+others[1].outward[2]).Length<.001)score++;}
                return score;
            }).ToList();
            foreach(var choice in choices)
            {
                if(--budget<=0)return false;if(choice.Item1.SourceId=="R08"&&placed[from].Spec.SourceId=="R08")continue;
                if(!TryPlacement(choice.Item1,from,choice.Item2,choice.Item3,placed,links,diagnostics,out var room,out var link))continue;
                appended=placed.Count;placed.Add(room);links.Add(link);pool.Remove(choice.Item1);diagnostics.MaximumPlaced=Math.Max(diagnostics.MaximumPlaced,placed.Count);return true;
            }
            return false;
        }
        internal static bool TryPlacement(DungeonRoomSpec next,int ai,PortRecord ap,PortRecord bp,List<DungeonPlacement> placed,List<DungeonLink> links,DungeonPlanningDiagnostics diagnostics,out DungeonPlacement b,out DungeonLink link)
        {
            diagnostics.CandidatePlacements++;var a=placed[ai];var normal=a.Normal(ap);
            int q=Enumerable.Range(0,4).First(v=>(PlanPoint.Rotate(new PlanPoint(bp.outward[0],bp.outward[2]),v)+normal).Length<.001);
            b=new DungeonPlacement{Spec=next,QuarterTurns=q,Elevation=a.Height(ap.position)-bp.position[1]};b.Position=a.Point(ap.position)+normal*ThresholdGap(ap,bp)-PlanPoint.Rotate(new PlanPoint(bp.position[0],bp.position[2]),q);
            var box=b.Envelope();var low=b.LowY;var high=b.HighY;link=null;
            if(placed.Any(p=>Overlap3D(box,low,high,p.Envelope(),p.LowY,p.HighY))){diagnostics.RoomOverlapRejections++;return false;}
            link=new DungeonLink{A=ai,B=placed.Count,PortA=ap,PortB=bp,Start=a.Outer(ap),End=b.Outer(bp),Elevation=a.Height(ap.position)};
            var envelope=link.Envelope();double linkLow=link.LowY,linkHigh=link.HighY;
            if(Math.Abs((link.End-link.Start).Length-JointClearance)>.0001||Math.Abs(link.Elevation-b.Height(bp.position))>.0001||placed.Where((p,i)=>i!=ai).Any(p=>Overlap3D(envelope,linkLow,linkHigh,p.Envelope(),p.LowY,p.HighY))||links.Any(l=>Overlap3D(box,low,high,l.Envelope(),l.LowY,l.HighY))){diagnostics.PassageRejections++;return false;}
            if(links.Any(l=>Overlap3D(envelope,linkLow,linkHigh,l.Envelope(),l.LowY,l.HighY))){diagnostics.CrossingRejections++;return false;}
            return true;
        }
        private static int[] Depths(int count,List<DungeonLink> links)
        {
            var depth=Enumerable.Repeat(-1,count).ToArray();depth[0]=0;var queue=new Queue<int>();queue.Enqueue(0);
            while(queue.Count>0){int a=queue.Dequeue();foreach(var l in links){int b=l.A==a?l.B:l.B==a?l.A:-1;if(b>=0&&depth[b]<0){depth[b]=depth[a]+1;queue.Enqueue(b);}}}
            return depth;
        }
        private sealed class NaturalCompletion{internal DungeonRoomSpec[] Canonical,NormalSpecs;internal bool OneBrokenSaint;}
        private static bool Add(int index,List<DungeonRoomSpec> order,List<DungeonPlacement> placed,List<DungeonLink> links,string entrance,Random random,ref int budget,DungeonPlanningDiagnostics diagnostics,bool natural=false,bool requireAllStairs=true,NaturalCompletion completion=null)
        {
            diagnostics.MaximumPlaced=Math.Max(diagnostics.MaximumPlaced,placed.Count);
            if(index==order.Count)
            {
                if(requireAllStairs&&!placed.Where(p=>p.Spec.SourceId=="R08").All(p=>p.Spec.Ports.All(port=>links.Any(l=>l.A==placed.IndexOf(p)&&l.PortA.id==port.id||l.B==placed.IndexOf(p)&&l.PortB.id==port.id))))return false;
                if(natural){int boss=placed.FindIndex(p=>p.Spec.SourceId=="R09");int depth=boss<0?-1:Depths(placed.Count,links)[boss];if(depth<LegacyNaturalDungeonRoster.MinimumBossDepth||depth>=placed.Count)return false;}
                return true;
            }
            if(--budget<=0){if(natural)budget=0;diagnostics.BudgetExhaustions++;return false;}
            var next=order[index];var choices=new List<Tuple<int,PortRecord,PortRecord>>();
            if(natural&&next.SourceId=="R09"&&completion!=null&&index==order.Count-1)
            {
                int rooms=placed.Count,edges=links.Count;
                if(!LegacyBossConnectionPlanner.TryConnect(completion.Canonical,completion.NormalSpecs,next,placed,links,entrance,random,ref budget,diagnostics,completion.OneBrokenSaint))return false;
                // Keep the common completion gate as well as the helper's own
                // source/chain checks: in particular every stair landing must
                // remain connected before this plan can reach runtime loading.
                if(Add(index+1,order,placed,links,entrance,random,ref budget,diagnostics,natural,requireAllStairs,completion))return true;
                links.RemoveRange(edges,links.Count-edges);placed.RemoveRange(rooms,placed.Count-rooms);
                diagnostics.BossExtensionRooms=0;diagnostics.BossExtensionReason="none";return false;
            }
            for(int i=0;i<placed.Count;i++)foreach(var a in placed[i].Spec.Ports)
                if(!(i==0&&a.id==entrance)&&!links.Any(l=>l.A==i&&l.PortA.id==a.id||l.B==i&&l.PortB.id==a.id))foreach(var b in next.Ports)
                    if(natural||next.SourceId!="R08"||Math.Abs(b.position[1])<.001)choices.Add(Tuple.Create(i,a,b));
            Shuffle(choices,random);
            var depths=natural?Depths(placed.Count,links):null;
            foreach(var choice in choices)
            {
                if(natural&&budget<=0)break;
                // Two .75m-deep R08 ports would require an unauthored1.52m
                // sleeve. An ordinary room separates shafts instead; do not
                // stretch another kit module or silently weaken preflight.
                if(natural&&next.SourceId=="R08"&&placed[choice.Item1].Spec.SourceId=="R08")continue;
                if(natural&&next.SourceId=="R09"&&depths[choice.Item1]+1<LegacyNaturalDungeonRoster.MinimumBossDepth)continue;
                if(!TryPlacement(next,choice.Item1,choice.Item2,choice.Item3,placed,links,diagnostics,out var b,out var link))continue;
                placed.Add(b);links.Add(link);
                if(Add(index+1,order,placed,links,entrance,random,ref budget,diagnostics,natural,requireAllStairs,completion))return true;
                links.RemoveAt(links.Count-1);placed.RemoveAt(placed.Count-1);
            }
            return false;
        }
    }
}
