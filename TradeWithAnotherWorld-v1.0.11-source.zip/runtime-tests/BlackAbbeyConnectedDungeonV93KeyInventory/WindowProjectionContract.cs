using System;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Pure-data checks are shared by the runtime loader and offline package probe.
    // Built-In samples cookie alpha only: separate RGB lights carry channel color.
    internal static class WindowProjectionContract
    {
        internal static bool HasCookie(WindowLightRecord record) => !string.IsNullOrEmpty(record.cookie);
        static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        static bool Vector(float[] value) => value != null && value.Length == 3 && value.All(Finite);
        static bool Same(float a, float b) => Math.Abs(a - b) <= .00001f;
        static bool Same(float[] a, float[] b) => a != null && b != null && a.Length == b.Length && a.Zip(b, Same).All(v => v);
        static float Squared(float[] a) => a.Sum(v => v * v);
        internal static void Validate(PackageManifest manifest)
        {
            var records = manifest.windowLights ?? Array.Empty<WindowLightRecord>();
            if (records.Length > (R09SplitIdentity.IsChamber(manifest.roomId) ? 16 : 8)) throw new InvalidDataException("Window fixture inventory exceeds the local room budget.");
            foreach (var record in records)
            {
                if (record == null || string.IsNullOrWhiteSpace(record.name) || !Vector(record.position) || !Vector(record.direction) || Squared(record.direction) < .0001f ||
                    !Vector(record.color) || record.color.Any(v => v < 0 || v > 1) || !Finite(record.intensity) || record.intensity <= 0 || record.intensity > 20 ||
                    !Finite(record.range) || record.range <= 0 || record.range > 40 || !Finite(record.spotAngle) || record.spotAngle < 5 || record.spotAngle > 120 ||
                    !Finite(record.innerSpotAngle) || record.innerSpotAngle < 0 || record.innerSpotAngle > record.spotAngle ||
                    !Finite(record.shadowStrength) || record.shadowStrength < 0 || record.shadowStrength > 1 || record.shadowResolution < 128 || record.shadowResolution > 1024 ||
                    !Finite(record.shadowBias) || record.shadowBias < 0 || record.shadowBias > .1f || !Finite(record.shadowNormalBias) || record.shadowNormalBias < 0 || record.shadowNormalBias > .2f ||
                    !Finite(record.shadowNearPlane) || record.shadowNearPlane < .01f || record.shadowNearPlane > .5f)
                    throw new InvalidDataException("A declared window spotlight is invalid.");
                if (record.up != null && (!Vector(record.up) || Squared(record.up) < .0001f ||
                    Math.Pow(record.up.Zip(record.direction, (a,b) => a*b).Sum(), 2) > .999f * Squared(record.up) * Squared(record.direction)))
                    throw new InvalidDataException("Window up vector is invalid or parallel to its direction.");
                if (!HasCookie(record))
                {
                    if (record.projectionGroup != null || record.channel != null || record.cookieSha256 != null || record.cookieColorSpace != null || record.shadowExcludeMeshes?.Length > 0)
                        throw new InvalidDataException("Incomplete window cookie projection.");
                    continue;
                }
                if (string.IsNullOrWhiteSpace(record.projectionGroup) || !new[] { "r", "g", "b" }.Contains(record.channel) ||
                    record.cookieColorSpace != "linear-alpha" || !CatalogReader.Hash(record.cookieSha256) || record.up == null ||
                    Path.IsPathRooted(record.cookie) || record.cookie.Replace('\\','/').Split('/').Any(p => p == ".." || p == "." || p.Length == 0) ||
                    record.shadowExcludeMeshes == null || record.shadowExcludeMeshes.Length == 0 || record.shadowExcludeMeshes.Length > 4 ||
                    record.shadowExcludeMeshes.Distinct(StringComparer.Ordinal).Count() != record.shadowExcludeMeshes.Length ||
                    record.shadowExcludeMeshes.Any(n => !GlassVisual(manifest, n)))
                    throw new InvalidDataException("A window cookie requires a contained hashed linear-alpha texture and its exact stained-glass visual chunk.");
                int channel = Array.IndexOf(new[] { "r", "g", "b" }, record.channel);
                if (!record.color.Select((v,i) => Same(v, i == channel ? 1f : 0f)).All(v => v))
                    throw new InvalidDataException("Window cookie channel must use a pure matching RGB light.");
            }
            foreach (var group in records.Where(HasCookie).GroupBy(r => r.projectionGroup, StringComparer.Ordinal))
            {
                var values = group.ToArray(); var first = values[0];
                if (values.Length != 3 || values.Select(v => v.channel).Distinct().Count() != 3 || values.Select(v => v.cookie).Distinct().Count() != 3 ||
                    values.Any(v => !Same(v.position, first.position) || !Same(v.direction, first.direction) || !Same(v.up, first.up) || !Same(v.range, first.range) ||
                        !Same(v.intensity, first.intensity) || !Same(v.spotAngle, first.spotAngle) || !Same(v.innerSpotAngle, first.innerSpotAngle) ||
                        v.shadowResolution != first.shadowResolution || !Same(v.shadowStrength, first.shadowStrength) || !Same(v.shadowBias, first.shadowBias) ||
                        !Same(v.shadowNormalBias, first.shadowNormalBias) || !Same(v.shadowNearPlane, first.shadowNearPlane) ||
                        !v.shadowExcludeMeshes.SequenceEqual(first.shadowExcludeMeshes)))
                    throw new InvalidDataException("Colored window projection requires three coincident, identically configured RGB channel lights.");
            }
        }
        private static bool GlassVisual(PackageManifest m, string name)
        {
            var mesh = m.meshes?.SingleOrDefault(v => v.name == name);
            if (mesh == null) return false;
            if (m.roomId == "R08")
            {
                var rebuilt = KitArchitectureProfile.Find(m.sourceSha256);
                if (rebuilt != null && rebuilt.roomId == "R08")
                    return (name == "r08_window_glass_bake-props_fixtures" || name == "r08_window_glass_bake-water") &&
                        !(m.colliderMeshes ?? Array.Empty<MeshRecord>()).Any(v => v.name == name);
                return name == "stained_glass";
            }
            if (!R09SplitIdentity.IsChamber(m.roomId) || mesh.partId != "static" || m.materials == null ||
                mesh.materialIndex < 0 || mesh.materialIndex >= m.materials.Length ||
                (m.colliderMeshes ?? Array.Empty<MeshRecord>()).Any(v => v.name == name)) return false;
            if (R09SplitIdentity.IsChamber(KitArchitectureProfile.Find(m.sourceSha256)?.roomId))
            {
                // These are the four actual source-UV glass buffers, proved
                // from the approved B native's fresh object-range inventory.
                // Source identity and final manifest hashes are admitted by
                // the sealed architecture profile before this shape check.
                if(m.sourceSha256!="5cd5fe0b5b678f4802e3505e4c1c4081046936cdb3cf756081066c38267e7612")return false;
                string story=name=="direct-42086dcbe89cb673"?"05-vigil-of-candles":
                    name=="direct-e6c4f9f1e2aa3974"?"06-bound-penitent":
                    name=="direct-bc25f1c671ff3aad"?"07-reliquary-of-silence":
                    name=="direct-652ecd002a9be409"?"08-sealed-threshold":null;
                return story!=null&&m.materials[mesh.materialIndex].name==
                    "R09-B runtime V84 exact glass source artwork | BA9V4 | stained glass | "+story;
            }
            return m.materials[mesh.materialIndex].name.StartsWith("R09 runtime glass_story_", StringComparison.Ordinal);
        }
    }
}
