using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using Object=UnityEngine.Object;
namespace BlackAbbeySixRooms
{
    // Repeats the source-bound0.8m profile at unchanged texel density. Only
    // the final short repeat is clipped; no axis/UV stretch is performed.
    internal static class KnightReturnConnector
    {
        internal sealed class Surface {internal float[] Rows;internal int[] Indices;}
        private const int Stride=12;
        private static float[] Mix(float[] a,float[] b,double t)
        {var v=new float[Stride];for(int i=0;i<Stride;i++)v[i]=(float)(a[i]+(b[i]-a[i])*t);return v;}
        private static List<float[]> Clip(List<float[]> input,float end)
        {
            var output=new List<float[]>();if(input.Count==0)return output;
            var a=input[input.Count-1];bool insideA=a[2]<=end+.000001f;
            foreach(var b in input){bool insideB=b[2]<=end+.000001f;if(insideA!=insideB)output.Add(Mix(a,b,(end-a[2])/(b[2]-a[2])));if(insideB)output.Add(b);a=b;insideA=insideB;}return output;
        }
        internal static Surface Remesh(float[] rows,int[] indices,float length)=>Remesh(rows,indices,length,false);
        internal static Surface Remesh(float[] rows,int[] indices,float length,bool sealApex)
        {
            if(rows==null||indices==null||rows.Length%Stride!=0||indices.Length%3!=0||!RoomPackage.Finite(length)||length<.799f||length>12.801f||rows.Any(x=>!RoomPackage.Finite(x))||indices.Any(i=>i<0||i>=rows.Length/Stride))throw new InvalidDataException("Invalid canonical knight sleeve geometry.");
            var verts=new List<float>();var tris=new List<int>();int segments=(int)Math.Ceiling(length/.8f-1e-6);
            for(int segment=0;segment<segments;segment++)
            {
                float offset=segment*.8f,take=Math.Min(.8f,length-offset);
                for(int t=0;t<indices.Length;t+=3)
                {
                    var polygon=new List<float[]>();for(int j=0;j<3;j++){var v=new float[Stride];Array.Copy(rows,indices[t+j]*Stride,v,0,Stride);polygon.Add(v);}
                    // End caps are buried in the adjoining room walls. Removing
                    // them also prevents paired coplanar faces inside repeats.
                    if(polygon.All(v=>Math.Abs(v[2])<.00001)||polygon.All(v=>Math.Abs(v[2]-.8f)<.00001))continue;
                    polygon=Clip(polygon,take);if(polygon.Count<3)continue;
                    for(int j=1;j<polygon.Count-1;j++)
                    {
                        var tri=new[]{polygon[0],polygon[j],polygon[j+1]};
                        double ax=tri[1][0]-tri[0][0],ay=tri[1][1]-tri[0][1],az=tri[1][2]-tri[0][2],bx=tri[2][0]-tri[0][0],by=tri[2][1]-tri[0][1],bz=tri[2][2]-tri[0][2];
                        double cx=ay*bz-az*by,cy=az*bx-ax*bz,cz=ax*by-ay*bx;if(cx*cx+cy*cy+cz*cz<1e-16)continue;
                        foreach(var original in tri){var v=(float[])original.Clone();v[2]=Math.Min(take,v[2])+offset;tris.Add(verts.Count/Stride);verts.AddRange(v);}
                    }
                }
            }
            if(sealApex)
            {
                // The pinned canonical mortar stops8mm short of its ring ends.
                // A15mm-wide recessed mortar liner closes only the apex seam,
                //12mm behind the source inner roof; it shares the backing
                // material and collision and never overlays a coplanar face.
                const float half=.0075f,roof=4.0185f;
                var a=new[]{-half,roof,0f,0f,-1f,0f,0f,0f,1f,0f,0f,1f};var b=new[]{half,roof,0f,0f,-1f,0f,.015f,0f,1f,0f,0f,1f};
                var c=new[]{half,roof,length,0f,-1f,0f,.015f,length,1f,0f,0f,1f};var d=new[]{-half,roof,length,0f,-1f,0f,0f,length,1f,0f,0f,1f};
                foreach(var v in new[]{a,b,c,a,c,d}){tris.Add(verts.Count/Stride);verts.AddRange(v);}
                // The canonical floor mortar has the same inset end seam.
                // Keep its12mm recess behind the source mortar and extend20mm
                // beneath each wall so every flagstone joint has real support.
                const float floorHalf=1.52f,floorY=-.024f;
                var fa=new[]{-floorHalf,floorY,0f,0f,1f,0f,0f,0f,1f,0f,0f,-1f};var fb=new[]{-floorHalf,floorY,length,0f,1f,0f,0f,length,1f,0f,0f,-1f};
                var fc=new[]{floorHalf,floorY,length,0f,1f,0f,3.04f,length,1f,0f,0f,-1f};var fd=new[]{floorHalf,floorY,0f,0f,1f,0f,3.04f,0f,1f,0f,0f,-1f};
                foreach(var v in new[]{fa,fb,fc,fa,fc,fd}){tris.Add(verts.Count/Stride);verts.AddRange(v);}
                // Source jamb backing is inset as well. These continuous
                // recessed side strips meet floor and springing behind stone.
                foreach(float side in new[]{-1f,1f})
                {
                    const float wallX=1.518f,wallTop=2.02f,wallBottom=-.03f;
                    var wa=new[]{side*wallX,wallBottom,0f,-side,0f,0f,0f,0f,0f,0f,side,1f};var wb=new[]{side*wallX,wallBottom,length,-side,0f,0f,side*length,0f,0f,0f,side,1f};
                    var wc=new[]{side*wallX,wallTop,length,-side,0f,0f,side*length,wallTop-wallBottom,0f,0f,side,1f};var wd=new[]{side*wallX,wallTop,0f,-side,0f,0f,0f,wallTop-wallBottom,0f,0f,side,1f};
                    foreach(var v in side>0?new[]{wa,wb,wc,wa,wc,wd}:new[]{wa,wc,wb,wa,wd,wc}){tris.Add(verts.Count/Stride);verts.AddRange(v);}
                }
            }
            if(tris.Count==0)throw new InvalidDataException("Empty fitted knight sleeve.");return new Surface{Rows=verts.ToArray(),Indices=tris.ToArray()};
        }
        private static Mesh Derived(Mesh source,float length,bool collider=false,bool sealApex=false)
        {
            var p=source.vertices;var n=source.normals;var uv=source.uv;var ta=source.tangents;
            if(collider){if(n.Length!=p.Length)n=Enumerable.Repeat(Vector3.up,p.Length).ToArray();if(uv.Length!=p.Length)uv=new Vector2[p.Length];if(ta.Length!=p.Length)ta=Enumerable.Repeat(new Vector4(1,0,0,1),p.Length).ToArray();}
            if(n.Length!=p.Length||uv.Length!=p.Length||ta.Length!=p.Length)throw new InvalidDataException("Canonical sleeve requires all source mapping channels.");
            var rows=new float[p.Length*Stride];for(int i=0;i<p.Length;i++){int k=i*Stride;rows[k]=p[i].x;rows[k+1]=p[i].y;rows[k+2]=p[i].z;rows[k+3]=n[i].x;rows[k+4]=n[i].y;rows[k+5]=n[i].z;rows[k+6]=uv[i].x;rows[k+7]=uv[i].y;rows[k+8]=ta[i].x;rows[k+9]=ta[i].y;rows[k+10]=ta[i].z;rows[k+11]=ta[i].w;}
            if(!collider&&sealApex)ExtendVisualMortar(rows);
            var data=Remesh(rows,source.triangles,length,sealApex);int count=data.Rows.Length/Stride;var positions=new Vector3[count];var normals=new Vector3[count];var uvs=new Vector2[count];var tangents=new Vector4[count];
            for(int i=0;i<count;i++){int k=i*Stride;positions[i]=new Vector3(data.Rows[k],data.Rows[k+1],data.Rows[k+2]);normals[i]=new Vector3(data.Rows[k+3],data.Rows[k+4],data.Rows[k+5]).normalized;uvs[i]=new Vector2(data.Rows[k+6],data.Rows[k+7]);var xyz=new Vector3(data.Rows[k+8],data.Rows[k+9],data.Rows[k+10]).normalized;tangents[i]=new Vector4(xyz.x,xyz.y,xyz.z,data.Rows[k+11]);}
            var mesh=new Mesh{name=source.name+" | owned fitted knight return"};try{if(count>65535)mesh.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;mesh.vertices=positions;mesh.normals=normals;mesh.uv=uvs;mesh.tangents=tangents;if(!collider)mesh.colors32=SolidVertexColors(count);mesh.triangles=data.Indices;mesh.RecalculateBounds();return mesh;}catch{Object.Destroy(mesh);throw;}
        }
        internal static GameObject Create(Transform parent,Vector3 innerA,Quaternion outward,PortRecord a,PortRecord b,float gap,LoadedRoom kit)
        {
            if(!parent||kit?.Root==null||kit.Manifest.roomId!=KitPointedArchitecture.KitId||kit.Manifest.sourceSha256!="7c9dd2542f26a7a6a5489907d506d883683ae8b0ef887f15354195710d01ff1b"||!KitPointedArchitecture.Pointed(a)||!KitPointedArchitecture.Pointed(b)||gap<R08KnightReturnPolicy.MinimumSleeveGap||gap>R08KnightReturnPolicy.MaximumSleeveGap)throw new InvalidDataException("Invalid fitted knight return source.");
            float length=a.depth+b.depth+gap;var root=new GameObject("Knight return | source-profile fitted passage");root.SetActive(false);root.transform.SetParent(parent,false);root.transform.localPosition=innerA;root.transform.localRotation=outward;
            var owner=root.AddComponent<KnightReturnMeshOwner>();
            try
            {
                foreach(var row in kit.Manifest.meshes.Where(m=>m.partId=="pointed_080"))
                {
                    var source=kit.Root.transform.Find(row.name);if(!source)throw new InvalidDataException("Missing canonical knight lining.");
                    var go=Object.Instantiate(source.gameObject,root.transform,false);go.transform.localPosition=Vector3.zero;go.transform.localRotation=Quaternion.identity;go.transform.localScale=Vector3.one;
                    var filter=go.GetComponent<MeshFilter>();var mesh=Derived(filter.sharedMesh,length,false,row.materialIndex==1);owner.Meshes.Add(mesh);filter.sharedMesh=mesh;go.SetActive(true);
                }
                foreach(var row in kit.Manifest.colliderMeshes.Where(m=>m.partId=="pointed_080"))
                {
                    var source=kit.Root.transform.Find("Collider | "+row.name);if(!source)throw new InvalidDataException("Missing canonical knight collision lining.");
                    var go=Object.Instantiate(source.gameObject,root.transform,false);go.transform.localPosition=Vector3.zero;go.transform.localRotation=Quaternion.identity;go.transform.localScale=Vector3.one;
                    var body=go.GetComponent<MeshCollider>();var mesh=Derived(body.sharedMesh,length,true,true);owner.Meshes.Add(mesh);body.sharedMesh=mesh;go.SetActive(true);
                }
                if(owner.Meshes.Count!=3)throw new InvalidDataException("Knight passage requires two mapped surfaces and complete collision.");root.SetActive(true);return root;
            }
            catch{owner.Release();Object.Destroy(root);throw;}
        }
        // RoomPackage.UploadMesh supplies opaque white vertex colors for the
        // native stone shader. A fresh derived mesh must retain that channel.
        internal static Color32[] SolidVertexColors(int count)
        {var colors=new Color32[count];for(int i=0;i<count;i++)colors[i]=new Color32(255,255,255,255);return colors;}
        // A repeated long sleeve needs continuous recessed mortar through its
        // segment boundaries. Its front/rear caps are removed by Remesh; only
        // this visual backing reaches the seam, never the dressed silhouette
        // or the original collision frame.
        internal static void ExtendVisualMortar(float[] rows)
        {for(int k=2;k<rows.Length;k+=Stride){if(rows[k]<.02f)rows[k]=0;else if(rows[k]>.78f)rows[k]=.8f;}}
    }
    internal sealed class KnightReturnMeshOwner:MonoBehaviour
    {
        internal readonly List<Mesh> Meshes=new List<Mesh>();
        internal void Release(){foreach(var mesh in Meshes)if(mesh)Object.Destroy(mesh);Meshes.Clear();}
        private void OnDestroy()=>Release();
    }
}
