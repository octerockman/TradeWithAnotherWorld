using System;
using UnityEngine;
namespace BlackAbbeySixRooms
{
    // Read native effect clips; never instantiate trade VFX/network objects or
    // change the player's/global mix. Two local voices belong to this scale.
    internal sealed class FalseVowsPlacementAudio:MonoBehaviour
    {
        private readonly AudioSource[] voices=new AudioSource[2];
        private int nextVoice;
        private Action<string> log;
        private bool warnedMissing;
        internal void Configure(Action<string> write)
        {
            log=write;
            for(int i=0;i<voices.Length;i++)
            {
                var child=new GameObject("Scale placement sound "+i);child.transform.SetParent(transform,false);
                var source=child.AddComponent<AudioSource>();source.playOnAwake=false;source.loop=false;voices[i]=source;
            }
        }
        internal void Play(string itemId,Vector3 worldPosition)
        {
            var player=Player.m_localPlayer;if(!player)return;
            bool coin=itemId==FalseVowsState.Purse;
            // StoreGui's buy effect is the native successful coin exchange cue.
            // Resolve on use so startup order never disables quest progression.
            var effects=coin?(StoreGui.instance?StoreGui.instance.m_buyEffects:null):player.m_dropEffects;
            ZSFX sound=null;
            if(effects?.m_effectPrefabs!=null)
                foreach(var effect in effects.m_effectPrefabs)
                {
                    if(!effect.m_enabled||!effect.m_prefab)continue;
                    foreach(var candidate in effect.m_prefab.GetComponentsInChildren<ZSFX>(true))
                        if(candidate&&candidate.m_audioClips!=null&&candidate.m_audioClips.Length>0&&candidate.GetComponent<AudioSource>())
                        {sound=candidate;break;}
                    if(sound)break;
                }
            if(!sound)
            {
                if(!warnedMissing){warnedMissing=true;log?.Invoke("FALSE_VOWS_PLACEMENT_AUDIO_WAITING: native "+(coin?"StoreGui buy":"Humanoid drop")+" audio is unavailable; retry on next placement; progression retained.");}
                return;
            }
            var clips=sound.m_audioClips;AudioClip clip=null;
            int start=UnityEngine.Random.Range(0,clips.Length);
            for(int i=0;i<clips.Length;i++){var c=clips[(start+i)%clips.Length];if(c&&c.length>0){clip=c;break;}}
            if(!clip)return;
            var template=sound.GetComponent<AudioSource>();var source=voices[nextVoice++%voices.Length];if(!source)return;
            source.Stop();source.transform.position=worldPosition;source.outputAudioMixerGroup=template.outputAudioMixerGroup;
            source.clip=clip;source.volume=UnityEngine.Random.Range(sound.m_minVol,sound.m_maxVol);
            source.pitch=UnityEngine.Random.Range(sound.m_minPitch,sound.m_maxPitch);source.spatialBlend=1;
            source.minDistance=1;source.maxDistance=12;source.rolloffMode=AudioRolloffMode.Linear;source.dopplerLevel=0;source.priority=template.priority;
            source.Play();warnedMissing=false;
            log?.Invoke("FALSE_VOWS_PLACEMENT_AUDIO: "+itemId+"; native="+(coin?"StoreGui.m_buyEffects":"Humanoid.m_dropEffects")+"; ZSFX="+sound.name+"; clip="+clip.name+"; once on accepted placement; two local voices.");
        }
    }
}
