using System;
namespace BlackAbbeySixRooms
{
 internal sealed class FalseVowsItemDefinition
 {
  internal readonly string Id, Name, Description; internal readonly float Weight;
  internal FalseVowsItemDefinition(string id,string name,string description,float weight){Id=id;Name=name;Description=description;Weight=weight;}
 }
 internal static class FalseVowsItemCatalog
 {
  internal const string Letter="abbey_hasty_note";
  internal static readonly FalseVowsItemDefinition[] All = {
   new FalseVowsItemDefinition(UnrecordedDeadState.Key,"Old Order Key","An old iron key bearing the whole diamond of the former order.",0.1f),
   new FalseVowsItemDefinition("abbey_oath_tome","The Abbey's Rule","Oxblood leather over heavy boards, with brass corners rubbed bright by generations of hands. The passages on Silence, Poverty and Obedience are dark with thumbprints. Questions crowd the margins; in places, someone has patiently scraped them away. The Chapter\u2019s mark remains clear upon the cover.",1.5f),
   new FalseVowsItemDefinition("abbey_hasty_note","A Poorly Written Letter","The ink trails off where the writer's hand began to shake.",0.1f),
   new FalseVowsItemDefinition("abbey_scriptorium_key","Scriptorium Cabinet Key","An iron key left among the folios. Its worn teeth fit the writing desks.",0.1f),
   new FalseVowsItemDefinition("abbey_bellkeeper_deposition","Bellkeeper's Deposition","The parchment has been folded until the creases are soft as cloth. The bellkeeper\u2019s orderly hand breaks into a scrawl where he describes what answered the Abbot beneath the bell. \u201cEcho\u201d has been struck out hard enough to tear the page. In a tidier hand along the margin: \u201cReminder: Your night to clean the vestry.\u201d",0.1f),
   new FalseVowsItemDefinition("abbey_hidden_tithe_purse","Hidden Tithe Purse","The purse sits heavily in the hand\u2014enough coin to feed the families waiting at the gate. Its leather is soft from handling. The donor\u2019s tally is worn almost blank; the Abbot\u2019s private mark still gleams. Deep in the seams lingers the sharp scent of the soap used on the vestry linens.",0.3f),
   new FalseVowsItemDefinition("abbey_broken_chapter_seal","Broken Chapter Seal","Two pieces of bronze, still threaded on a black cord. The old metal is smooth from handling; the broken edges still bite. A folded renunciation hangs from the knot. The Abbot has signed beneath a single line: \u201cLet the Chapter tend its own house. This one is mine.\u201d",0.1f),
  };
  internal static FalseVowsItemDefinition Find(string id){foreach(var d in All)if(string.Equals(d.Id,id,StringComparison.Ordinal))return d;return null;}
 }
}
