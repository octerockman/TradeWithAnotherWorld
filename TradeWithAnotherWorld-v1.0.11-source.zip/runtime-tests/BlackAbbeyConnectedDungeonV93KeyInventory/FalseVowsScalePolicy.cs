using System;
namespace BlackAbbeySixRooms
{
    // Relative witness weights; inventory mass is independent of this ritual.
    internal static class FalseVowsScalePolicy
    {
        internal const float MaximumDegrees=30f;
        internal const float PaperLoad=.30f,PurseLoad=.60f,SealLoad=.10f;
        internal static float LeftDownDegrees(bool bookPlaced,int solvedMask)
        {
            if(solvedMask<0||solvedMask>7)throw new ArgumentOutOfRangeException(nameof(solvedMask));
            float proof=((solvedMask&1)!=0?PaperLoad:0)+((solvedMask&2)!=0?PurseLoad:0)+((solvedMask&4)!=0?SealLoad:0);
            return MaximumDegrees*((bookPlaced?1f:0)-proof);
        }
    }
}
