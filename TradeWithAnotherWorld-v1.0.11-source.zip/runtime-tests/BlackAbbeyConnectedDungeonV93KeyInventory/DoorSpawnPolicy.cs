using System;

namespace BlackAbbeySixRooms
{
    // Optional ordinary oak doors only. The original R01 return, authored R09
    // boss doors and barred unused exits are assembled separately.
    internal static class DoorSpawnPolicy
    {
        internal const int OpenablePercent = 55;

        // Preview candidate: only ordinary linked oak leaves use this overload.
        // Source IDs are explicit; instance names and suffixes are never parsed.
        internal static bool ShouldPlaceForSources(int seed, string instanceA, string portA, string sourceA,
            string instanceB, string portB, string sourceB)
        {
            if (string.IsNullOrEmpty(sourceA) || string.IsNullOrEmpty(sourceB))
                throw new ArgumentException("Concrete source identities are required for the chain door policy.");
            if (NaturalDungeonRoster.Family(sourceA) == NaturalDungeonRoster.Family(sourceB)) return false;
            return ShouldPlace(seed, instanceA, portA, instanceB, portB);
        }

        internal static bool ShouldPlace(int seed, string instanceA, string portA, string instanceB, string portB)
        {
            if (string.IsNullOrEmpty(instanceA) || string.IsNullOrEmpty(instanceB) ||
                string.IsNullOrEmpty(portA) || string.IsNullOrEmpty(portB))
                throw new ArgumentException("A door roll requires both concrete room and port identities.");
            // Canonicalize the pair so link reversal or unrelated link-order
            // changes cannot move a door to another physical connection.
            int order = string.CompareOrdinal(instanceA, instanceB);
            if (order > 0 || order == 0 && string.CompareOrdinal(portA, portB) > 0)
            {
                string room = instanceA; instanceA = instanceB; instanceB = room;
                string port = portA; portA = portB; portB = port;
            }
            unchecked
            {
                uint hash = 2166136261u;
                Mix(ref hash, 0x314f414b); // independent ordinary-oak policy domain
                Mix(ref hash, seed);
                Mix(ref hash, instanceA); Mix(ref hash, portA);
                Mix(ref hash, instanceB); Mix(ref hash, portB);
                hash ^= hash >> 16; hash *= 0x7feb352du;
                hash ^= hash >> 15; hash *= 0x846ca68bu;
                hash ^= hash >> 16;
                return hash % 100u < OpenablePercent;
            }
        }

        private static void Mix(ref uint hash, int value)
        {
            unchecked
            {
                uint bits = (uint)value;
                for (int i = 0; i < 4; i++) { hash = (hash ^ (byte)bits) * 16777619u; bits >>= 8; }
            }
        }
        private static void Mix(ref uint hash, string value)
        {
            Mix(ref hash, value.Length);
            unchecked
            {
                foreach (char c in value)
                { hash = (hash ^ (byte)c) * 16777619u; hash = (hash ^ (byte)(c >> 8)) * 16777619u; }
            }
        }
    }
}
