using System;

namespace BlackAbbeySixRooms
{
    // UID lookup happens in the native adapter. Never recreate a missing grave
    // or apply an old transfer to another owner/prefab or a changed spawn point.
    internal static class GraveEjectionPolicy
    {
        static bool Near(float[] a,float[] b,float distance)
        {
            if(a==null||b==null||a.Length!=3||b.Length!=3)return false;
            double squared=0;
            for(int i=0;i<3;i++)
            {
                if(float.IsNaN(a[i])||float.IsInfinity(a[i])||float.IsNaN(b[i])||float.IsInfinity(b[i]))return false;
                double d=a[i]-b[i];squared+=d*d;
            }
            return squared<=distance*distance;
        }
        internal static bool AtOriginal(GraveExitRecord record,float[] spawn)=>record!=null&&Near(record.original,spawn,.03f);
        internal static bool NeedsReplay(GraveExitRecord record,int prefab,long owner,float[] position,float[] spawn)
        {
            if(record==null||record.prefabHash!=prefab||record.ownerId!=owner||record.original==null||record.original.Length!=3||
                record.original[1]<7000||position==null||position.Length!=3||position[1]<7000||Near(position,record.destination,.25f))return false;
            return AtOriginal(record,spawn)||Near(record.destination,spawn,.03f);
        }
    }
}
