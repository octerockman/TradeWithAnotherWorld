using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace BlackAbbeySixRooms
{
#pragma warning disable 0649
    internal sealed class KitFileBinding { public string path, sha256; }
    internal sealed class KitRoomBinding
    {
        public string assetId, roomId, sourceSha256, manifestSha256, packageDirectory;
        public KitFileBinding[] requiredSidecars;
        public float? recoveryBelow;
        public int breakablePews;
        public bool actorCompatibility;
        public float[][] bellFixturePositions;
    }
    internal sealed class KitArchitectureContract
    {
        public int schemaVersion, generationRevision;
        public KitFileBinding catalog, runtimeAssets, pews, falseVows, unrecordedDead, warding, paperFeedback, planningProof, legacyRetirement;
        public KitRoomBinding[] sourceBindings;
    }
    internal sealed class KitPlanningProofRoom
    {
        public string assetId,sourceSha256;
        public bool sourceBoxCoverage,actualRenderAndColliderTriangleCoverage;
        public double[][] planningReservations;
    }
    internal sealed class KitPlanningProof
    {
        public int schemaVersion;
        public double buriedSupportUpperYRelativeToConnectedFloor;
        public KitPlanningProofRoom[] rooms;
    }
#pragma warning restore 0649
    // This declaration is completed only after root seals the actual export.
    // An absent hash never accepts self-authored JSON as an installed contract.
    internal static class KitArchitectureSeal
    {
        internal const string ExpectedContractSha256 = "45460eff45f7baab2e4cf65408b245a5d3b23d23233535aa42aca42992624478";
    }
    internal static class KitArchitectureProfile
    {
        internal const int Revision = 4;
        internal const string RelativeRoot = "kit-rebuild-v2";
        private static readonly Dictionary<string, KitArchitectureContract> loaded =
            new Dictionary<string, KitArchitectureContract>(StringComparer.OrdinalIgnoreCase);
        private static readonly Dictionary<string,string> nativePins = new Dictionary<string,string>(StringComparer.Ordinal) {
            {"R01","04978a4a417229021431e65e2b91ed64553f0fd0041e42798566a54c1f09f66a"},
            {"R02","f357143c63581438e7cdbdc8f323fa2fe04c426433ab0f2aa8ce980c1e24961d"},
            {"R02-UD","f357143c63581438e7cdbdc8f323fa2fe04c426433ab0f2aa8ce980c1e24961d"},
            {"R03","6fa8bb8d6e327bb6ec37cef264a853b64d37f2fa7b487f23cc52fbba6db402e6"},
            {"R03_complete","db34bcd1758317c1429bdd306b69ed7271abd0bc7ffc86f9c47f2e421350066d"},
            {"R04","8f2009fa6987dbc7017d6910444dd62922995e1407bb21372959959efbfb9f94"},
            {"R05","187c9e58b4836005cd044d69529016a3d730501906fc02528d90d8babd7b5940"},
            {"R06","4126e55567257002df9f90a26032282ff00571c62f1708b4474ac8c04658d37b"},
            {"R06-UD","ad2a1d5a5905e9eb0621c45f2afbc409968ff76c68639405d4c11eae072ba5ac"},
            {"R07","ba59a8c156ec897be9f6cb0bdec84818344e55199dab17aafc6a9a2c2b2577b0"},
            {"R08","23d6b2f4ea294d3d79a19b4deaacf003d7cc2f00099b4b688d50d469ad6a8d58"},
            {"R08-UD","599e18fd6c6e2e01b70e52279738c678743e58a519e5eaa0790f21f1d5670aad"},
            {"R09-A1","a52d36f8bc6052abc7284941345bf9ddb32d0afd23833c52819c04464608f33d"},
            {"R09-A2","87f683c5f54496ec4f4a28e2a56a93bc9ec32c089fb044ddf060177c532daecd"},
            {"R09-B","5cd5fe0b5b678f4802e3505e4c1c4081046936cdb3cf756081066c38267e7612"}
        };
        internal static string SelectRoot(string sharedRoot,int revision)
        {
            DungeonGenerationPolicy.RequireRevision(revision);
            if(revision<Revision)throw new InvalidDataException("The Abbey rooms were rebuilt. Use twa_test_regenerate from the surface before entering; the saved run and return point were retained.");
            string root=Path.Combine(sharedRoot,RelativeRoot);
            Load(root); return root;
        }
        private static string Key(string root)=>Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar);
        internal static bool IsKitRoot(string root)=>string.Equals(Path.GetFileName(Key(root)),RelativeRoot,StringComparison.Ordinal);
        internal static KitArchitectureContract Load(string root)
        {
            string key=Key(root);
            if(loaded.TryGetValue(key,out var existing))return existing;
            if(!IsKitRoot(root)||!CatalogReader.Hash(KitArchitectureSeal.ExpectedContractSha256))
                throw new InvalidDataException("The rebuilt Abbey export is not sealed; existing dungeon and return records were retained.");
            string file=RoomPackage.FilePath(root,"kit-contract.json");
            if(!File.Exists(file)||new FileInfo(file).Length>1024*1024||CatalogReader.HashFile(file)!=KitArchitectureSeal.ExpectedContractSha256)
                throw new InvalidDataException("The rebuilt Abbey contract is absent or changed; no old source alias is permitted.");
            var contract=JsonConvert.DeserializeObject<KitArchitectureContract>(File.ReadAllText(file),ManifestReader.Settings());
            if(contract?.schemaVersion!=1||contract.generationRevision!=Revision||contract.sourceBindings?.Length!=nativePins.Count||
                contract.sourceBindings.Any(x=>x==null||!nativePins.TryGetValue(x.assetId??"",out var pin)||x.sourceSha256!=pin||
                    x.roomId!=(x.assetId.EndsWith("-UD",StringComparison.Ordinal)?x.assetId.Substring(0,x.assetId.Length-3):x.assetId)||
                    !CatalogReader.Hash(x.manifestSha256)||string.IsNullOrWhiteSpace(x.packageDirectory)||x.requiredSidecars==null)||
                contract.sourceBindings.Select(x=>x.assetId).Distinct(StringComparer.Ordinal).Count()!=nativePins.Count)
                throw new InvalidDataException("The rebuilt Abbey needs fifteen exact source/variant bindings, without legacy-source aliases.");
            foreach(var binding in new[]{contract.catalog,contract.runtimeAssets,contract.pews,contract.falseVows,contract.unrecordedDead,contract.warding,contract.paperFeedback,contract.planningProof})Verify(root,binding);
            if(contract.legacyRetirement!=null)Verify(root,contract.legacyRetirement);
            if(contract.catalog.path!="catalog.json"||contract.runtimeAssets.path!="runtime-assets.json"||contract.pews.path!="breakable-pews/manifest.json"||
                contract.falseVows.path!="false-vows/false-vows-assets.json"||contract.unrecordedDead.path!="unrecorded-dead/variants.json"||contract.warding.path!="warding-spawners/manifest.json"||contract.paperFeedback.path!="unrecorded-dead/paper-feedback-v1/papers.json"||contract.planningProof.path!="planning-reservations.json")
                throw new InvalidDataException("Rebuilt Abbey sidecar roots differ from the declared architecture namespace.");
            foreach(var row in contract.sourceBindings)
            {
                string directory=PackageDirectory(root,row.packageDirectory);
                string manifest=RoomPackage.FilePath(directory,"manifest.json");
                if(CatalogReader.HashFile(manifest)!=row.manifestSha256)throw new InvalidDataException("Changed rebuilt room manifest: "+row.assetId);
                var m=ManifestReader.Read(File.ReadAllText(manifest));
                if(m.roomId!=row.roomId||m.sourceSha256!=row.sourceSha256)throw new InvalidDataException("Wrong rebuilt native source: "+row.assetId);
                foreach(var sidecar in row.requiredSidecars)Verify(directory,sidecar);
                if(row.roomId=="R07"&&(!CatalogReader.Hash(m.interactionSha256)||string.IsNullOrEmpty(m.interactionFile)))throw new InvalidDataException("Rebuilt R07 is missing its newly bound moving/inventory/candle sidecar.");
                if(row.roomId=="R08"&&(!row.recoveryBelow.HasValue||m.bottomMist==null||m.bottomMist.recoveryBelow!=row.recoveryBelow.Value))throw new InvalidDataException("Rebuilt R08 is missing its measured fall recovery contract.");
                if(R09SplitIdentity.IsPiece(row.roomId)&&(!row.actorCompatibility||!CatalogReader.Hash(m.r09InteractionSha256)||!CatalogReader.Hash(m.r09LightingSha256)))throw new InvalidDataException("Rebuilt R09 needs exact interaction, lighting and actor-bridge evidence.");
                if(row.roomId=="R04"&&row.breakablePews!=4||R09SplitIdentity.IsPiece(row.roomId)&&row.breakablePews!=(row.roomId=="R09-B"?24:0))throw new InvalidDataException("Rebuilt pew ownership must cover four crossing pews and all twenty-four authored sanctum pews.");
                if((row.roomId=="R04"||row.roomId=="R08")&&(row.bellFixturePositions?.Length!=(row.roomId=="R04"?1:18)||row.bellFixturePositions.Any(p=>p==null||p.Length!=3||p.Any(v=>float.IsNaN(v)||float.IsInfinity(v)))))
                    throw new InvalidDataException("Rebuilt ambient bells need one crossing or eighteen stair fixture positions measured from the exact source.");
            }
            var planning=JsonConvert.DeserializeObject<KitPlanningProof>(File.ReadAllText(RoomPackage.FilePath(root,contract.planningProof.path)),ManifestReader.Settings());
            if(planning?.schemaVersion!=1||planning.buriedSupportUpperYRelativeToConnectedFloor!=-.04||planning.rooms?.Length!=nativePins.Count||
                planning.rooms.Any(x=>x==null||!x.sourceBoxCoverage||!x.actualRenderAndColliderTriangleCoverage||!nativePins.TryGetValue(x.assetId??"",out var pin)||pin!=x.sourceSha256)||planning.rooms.Select(x=>x.assetId).Distinct().Count()!=nativePins.Count)
                throw new InvalidDataException("Rebuilt planning reservations require complete exact-source coverage and the bounded40mm buried-support policy.");
            foreach(var row in planning.rooms)KitPlanningReservationPolicy.Register(row.sourceSha256,row.assetId,row.planningReservations);
            loaded.Add(key,contract);
            try
            {
                foreach (var row in contract.sourceBindings)
                {
                    string directory = PackageDirectory(root, row.packageDirectory);
                    var manifest = ManifestReader.Read(File.ReadAllText(RoomPackage.FilePath(directory, "manifest.json")));
                    KitRoomConsumerContracts.Validate(directory, row, manifest);
                }
            }
            catch { loaded.Remove(key); throw; }
            return contract;
        }
        private static void Verify(string root,KitFileBinding binding)
        {
            if(binding==null||string.IsNullOrWhiteSpace(binding.path)||!CatalogReader.Hash(binding.sha256))throw new InvalidDataException("Missing source-bound rebuilt sidecar.");
            string path=RoomPackage.FilePath(root,binding.path);
            if(!File.Exists(path)||CatalogReader.HashFile(path)!=binding.sha256)throw new InvalidDataException("Missing or changed rebuilt sidecar: "+binding.path);
        }
        private static string PackageDirectory(string root,string relative)
        {
            if(string.IsNullOrWhiteSpace(relative)||Path.IsPathRooted(relative))throw new InvalidDataException("Rebuilt room directories must be relative.");
            string parent=Key(root)+Path.DirectorySeparatorChar,path=Path.GetFullPath(Path.Combine(parent,relative));
            if(!path.StartsWith(parent,StringComparison.OrdinalIgnoreCase)||!Directory.Exists(path))throw new InvalidDataException("Missing/outside rebuilt room directory: "+relative);
            return path;
        }
        internal static KitRoomBinding Find(string source,string manifest=null)
            =>loaded.Values.SelectMany(x=>x.sourceBindings).FirstOrDefault(x=>x.sourceSha256==source&&(manifest==null||x.manifestSha256==manifest));
        internal static bool Matches(string source,string manifest=null)=>Find(source,manifest)!=null;
        internal static string ExpectedHash(string root,string relative,string legacy)
        {
            if(IsKitRoot(root)&&!loaded.ContainsKey(Key(root)))Load(root);
            string absolute=Path.GetFullPath(Path.Combine(root,relative));
            foreach(var pair in loaded)
            {
                var c=pair.Value;
                foreach(var binding in new[]{c.catalog,c.runtimeAssets,c.pews,c.falseVows,c.unrecordedDead,c.warding,c.paperFeedback,c.planningProof})
                    if(string.Equals(absolute,Path.GetFullPath(Path.Combine(pair.Key,binding.path)),StringComparison.OrdinalIgnoreCase))return binding.sha256;
            }
            if(IsKitRoot(root))throw new InvalidDataException("Unknown rebuilt shared sidecar: "+relative);
            return legacy;
        }
        internal static bool ContainsDirectory(string root)=>loaded.Keys.Any(k=>Key(root).StartsWith(k+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase)||Key(root)==k);
    }
}
