namespace BlackAbbeyDungeonMap
{
    internal static class MapGeometryIdentity
    {
        // The R06 no-glow partition preserves every measured vertex, collider,
        // bound, floor and connector. Only its manifest checksum changed in
        // this exact map resource. Keep prior personal discovery/pin identities;
        // any other resource payload still produces its own normal fingerprint.
        internal const string BeforeMaterialUpdate="f35b53c7bdc348839d45cc6b4ed962f8e7c9036008a668c96b24b58f7b9a815d";
        internal const string MaterialOnlyUpdate="f3261359d3c950616312736173d9d66ad211d26938d49412aefa25b79580db84";
        internal static string Fingerprint(string json)
        {
            string hash=Geometry.Hash(json);
            return hash==MaterialOnlyUpdate?BeforeMaterialUpdate:hash;
        }
    }
}
