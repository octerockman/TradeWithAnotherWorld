using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeyDungeonMap
{
    internal static class MapAnnotations
    {
        internal static List<RoomMark> ForFloor(MapPinBook pins,IReadOnlyList<MapGraveMark> graves,int floor)
        {
            var result=new List<RoomMark>();
            if(pins!=null)result.AddRange(pins.Pins.Where(p=>p.floor==floor).Select(p=>new RoomMark{Id="pin/"+p.id,Kind="custom-pin",Position=p.Position,Floor=p.floor}));
            if(graves!=null)result.AddRange(graves.Where(g=>g.Floor==floor).Select(g=>new RoomMark{Id="grave/"+g.Id,Kind="grave",Position=g.Position,Floor=g.Floor}));
            return result;
        }
        internal static Point FromPixel(Point center,double scale,double x,double y)
        {
            if(double.IsNaN(scale)||double.IsInfinity(scale)||scale<=0||double.IsNaN(x)||double.IsInfinity(x)||double.IsNaN(y)||double.IsInfinity(y))throw new ArgumentException("Invalid map view coordinates.");
            return center+new Point(x,y)*(1/scale);
        }
        internal static MapPin Nearest(MapPinBook pins,int floor,Point point,double pixelsPerMetre,double radius=19)=>pins?.Pins
            .Where(p=>p.floor==floor&&(p.Position-point).Length*pixelsPerMetre<=radius).OrderBy(p=>(p.Position-point).Length).FirstOrDefault();
    }
}
