using System;
namespace BlackAbbeyDungeonMap
{
    internal static class MapZoom
    {
        internal const double PreviousLogRate=.16,SpeedMultiplier=4;
        // One input step now equals two installed 0.2.3 steps in either direction.
        // Keep existing full/minimap limits and use the same path for all input.
        internal static double Apply(double span,double delta,bool large)
            =>Math.Max(large?18:12,Math.Min(large?600:65,span*Math.Exp(-delta*PreviousLogRate*SpeedMultiplier)));
    }
}
