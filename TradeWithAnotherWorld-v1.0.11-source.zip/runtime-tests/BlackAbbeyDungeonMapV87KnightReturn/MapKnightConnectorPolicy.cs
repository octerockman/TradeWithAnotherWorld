using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
namespace BlackAbbeyDungeonMap
{
    // Exact source-profile repetition used only by the opt-in fresh UD loop.
    // Ordinary fixed modules and the R09 zero threshold retain their old path.
    internal static class MapKnightConnectorPolicy
    {
        internal const string Kind="R08KnightLoopSleeve";
        internal const string Kit="POINTED_CONNECTOR_KIT_V1";
        internal const string Source="7c9dd2542f26a7a6a5489907d506d883683ae8b0ef887f15354195710d01ff1b";
        private static bool Finite(double n)=>!double.IsNaN(n)&&!double.IsInfinity(n);
        private static bool Near(double a,double b)=>Finite(a)&&Math.Abs(a-b)<.0002;
        private static bool Ordinary(string s)=>s=="R01"||s=="R04"||s=="R05"||s=="R06";
        internal static string Module(double length)
        {if(!Finite(length)||length<.799||length>12.801)throw new InvalidDataException("Knight passage length is outside its source construction.");return Kind+"/pointed_080/"+length.ToString("R",CultureInfo.InvariantCulture);}
        internal static void ValidatePlan(int generation,string mode,string route,int revision,IEnumerable<string> kinds,
            IEnumerable<string> ids,IEnumerable<string> sources,IEnumerable<string> assets)
        {
            string[] k=kinds?.ToArray(),i=ids?.ToArray(),s=sources?.ToArray(),a=assets?.ToArray();
            if(generation!=4||mode!="natural"||route!="unrecorded-dead"||revision!=1||k==null||k.Count(v=>v==Kind)!=1||
                i==null||s==null||a==null||i.Length!=s.Length||s.Length!=a.Length||
                a.Count(v=>v=="R08-UD")!=1||s.Count(v=>v=="R09-A2")!=1||s.Count(v=>v=="R09-B")!=1||s.Any(v=>v=="R09-A1")||
                i.Count(v=>v!=null&&v.StartsWith("KNIGHT_LOOP_",StringComparison.Ordinal))<1||i.Count(v=>v!=null&&v.StartsWith("KNIGHT_LOOP_",StringComparison.Ordinal))>7)
                throw new InvalidDataException("Knight map connector is outside the exact fresh revision1 UD loop.");
        }
        private static bool Profile(double[] p)=>p?.Length==5&&p.All(Finite)&&Near(p[0],3)&&Near(p[1],4)&&p[2]>=.1&&p[2]<=.3902&&Near(p[3],2)&&Near(p[4],2);
        internal static Link MakeLink(string kit,string source,double[] canonicalFloor,string idA,string sourceA,string idB,string sourceB,string id,
            Point start,Point end,Point normalA,Point normalB,Point exteriorA,Point exteriorB,bool loop,
            double[] profileA,double[] profileB,double elevation,double elevationA,double elevationB,int floor)
        {
            double length=(end-start).Length;
            if(kit!=Kit||source!=Source||canonicalFloor?.Length!=4||!Near(canonicalFloor[0],-1.5)||!Near(canonicalFloor[1],1.5)||
                !Near(canonicalFloor[2],0)||!Near(canonicalFloor[3],.8)||!Ordinary(sourceA)||!Ordinary(sourceB)||
                !(idA?.StartsWith("KNIGHT_LOOP_",StringComparison.Ordinal)==true||idB?.StartsWith("KNIGHT_LOOP_",StringComparison.Ordinal)==true)||
                !loop||!Profile(profileA)||!Profile(profileB)||!Near(normalA.Length,1)||!Near(normalB.Length,1)||(normalA+normalB).Length>.0002||
                (start+normalA*profileA[2]-exteriorA).Length>.0002||(end+normalB*profileB[2]-exteriorB).Length>.0002)
                throw new InvalidDataException("Knight map passage differs from its pinned source, profile or actual endpoint ownership.");
            Point exteriorDelta=exteriorB-exteriorA;
            double gap=exteriorDelta.X*normalA.X+exteriorDelta.Z*normalA.Z;
            if(!Finite(gap)||gap<.0198||gap>12.0201||(exteriorDelta-normalA*gap).Length>.0002||
                Math.Abs(length-profileA[2]-profileB[2]-gap)>.0002||
                !Finite(start.X)||!Finite(start.Z)||!Finite(end.X)||!Finite(end.Z))
                throw new InvalidDataException("Knight map length must equal both source inset depths plus the actual collinear gap.");
            Module(length);
            // The visible floor is3m wide; the3.04m recessed collision liner is
            // behind the walls. Map the walkable source floor, not that backing.
            var result=MapSplitTopology.MakeLink("Standard",sourceA,sourceB,id,start,end,normalA,normalB,
                profileA[0],profileB[0],elevation,elevationA,elevationB,floor,new[]{canonicalFloor[0],canonicalFloor[1],0d,length});
            result.Kind=Kind;return result;
        }
    }
}
