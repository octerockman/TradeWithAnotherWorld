using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BlackAbbeyDungeonMap
{
    // Exact V84 topology boundary. A zero-length boss threshold is a real
    // shared edge, never an ordinary masonry passage or a synthetic R09 door.
    internal static class MapSplitTopology
    {
        internal const int GenerationRevision=4,CatalogRevision=4;
        internal const string BossThreshold="R09BossThreshold";
        internal static bool IsHall(string source)=>source=="R09-A1"||source=="R09-A2";
        internal static void ValidateCatalog(int canonicalRevision,int variantRevision,IEnumerable<string> canonical,IEnumerable<string> variants)
        {
            string[] a=canonical?.ToArray(),b=variants?.ToArray();
            string[] expectedA={"R01","R02","R03","R03_complete","R04","R05","R06","R07","R08","R09-A1","R09-B"};
            string[] expectedB={"R02-UD","R06-UD","R08-UD","R09-A2"};
            if(canonicalRevision!=CatalogRevision||variantRevision!=CatalogRevision||a==null||b==null||
                a.Length!=expectedA.Length||b.Length!=expectedB.Length||a.Distinct(StringComparer.Ordinal).Count()!=a.Length||
                b.Distinct(StringComparer.Ordinal).Count()!=b.Length||expectedA.Except(a,StringComparer.Ordinal).Any()||expectedB.Except(b,StringComparer.Ordinal).Any())
                throw new InvalidDataException("The map needs the exact revision4 split-room catalog. Existing discovery is retained.");
        }
        internal static void ValidateRoomSet(int generation,IEnumerable<string> sources)
        {
            string[] rows=sources?.ToArray();
            if(generation!=GenerationRevision||rows==null||rows.Count(IsHall)!=1||rows.Count(s=>s=="R09-B")!=1||rows.Any(s=>s=="R09"||s=="R09-UD"))
                throw new InvalidDataException("This map requires a regenerated revision4 dungeon with one path hall and one boss chamber. Existing run and map records are retained.");
        }
        internal static void ValidateLinkSet(IEnumerable<string> kinds)
        {
            if(kinds==null||kinds.Count(k=>k==BossThreshold)!=1||kinds.Count(k=>k==MapKnightConnectorPolicy.Kind)>1||kinds.Any(k=>k!=null&&k!="Standard"&&k!=BossThreshold&&k!=MapKnightConnectorPolicy.Kind))
                throw new InvalidDataException("The split map requires exactly one explicit boss-threshold link.");
        }
        internal static Link MakeLink(string kind,string sourceA,string sourceB,string id,Point start,Point end,
            Point normalA,Point normalB,double widthA,double widthB,double elevation,double portElevationA,double portElevationB,int floor,double[] measured)
        {
            double length=(end-start).Length;
            bool finite=!double.IsNaN(length)&&!double.IsInfinity(length)&&!double.IsNaN(elevation)&&!double.IsInfinity(elevation)&&
                new[]{widthA,widthB,portElevationA,portElevationB,normalA.X,normalA.Z,normalB.X,normalB.Z}.All(v=>!double.IsNaN(v)&&!double.IsInfinity(v));
            if(!finite||widthA<=0||widthB<=0||Math.Abs(portElevationA-elevation)>.015||Math.Abs(portElevationB-elevation)>.015)
                throw new InvalidDataException("Map link dimensions or elevations differ from their authored ports.");
            if(kind==BossThreshold)
            {
                if(!(IsHall(sourceA)&&sourceB=="R09-B"||sourceA=="R09-B"&&IsHall(sourceB))||length>.015||
                    Math.Abs(normalA.Length-1)>.001||Math.Abs(normalB.Length-1)>.001||(normalA+normalB).Length>.002||
                    Math.Abs(widthA-widthB)>.015||widthA<4||widthA>6||measured!=null)
                    throw new InvalidDataException("The internal boss threshold is not the exact coincident hall/chamber joint.");
                return new Link{Id=id,A=start,B=end,Y=elevation,Floor=floor,Width=Math.Min(widthA,widthB),Kind=kind,Outward=normalA};
            }
            if(kind!=null&&kind!="Standard")throw new InvalidDataException("Unknown map link kind.");
            if(measured?.Length!=4||measured.Any(v=>double.IsNaN(v)||double.IsInfinity(v))||length<.5||
                measured[1]<=measured[0]||Math.Abs(measured[3]-measured[2]-length)>.015)
                throw new InvalidDataException("Map connector differs from its constructed masonry source.");
            return new Link{Id=id,A=start,B=end,Y=elevation,Floor=floor,Kind=kind,Width=Math.Min(Math.Min(widthA,widthB),measured[1]-measured[0])};
        }
    }
}
