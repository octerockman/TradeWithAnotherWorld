using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlackAbbeyDungeonMap
{
    // This record is immutable. UI callers may retain a snapshot without being
    // able to change the durable book behind its conflict check.
    internal sealed class MapPin
    {
        public string id { get; }
        public string name { get; }
        public int floor { get; }
        public double x { get; }
        public double z { get; }
        internal Point Position => new Point(x, z);
        internal MapPin(string id, string name, Point position, int floor)
        { this.id = id; this.name = name; x = position.X; z = position.Z; this.floor = floor; }
    }

    internal sealed class MapPinBook
    {
        private readonly MapPinStore store;
        private readonly string identity, fingerprint;
        private string expectedHash;
        private IReadOnlyList<MapPin> pins;
        internal IReadOnlyList<MapPin> Pins => pins;
        internal int Revision { get; private set; }
        internal MapPinBook(MapPinStore store, string identity, string fingerprint, IEnumerable<MapPin> values, string expectedHash)
        {
            this.store = store; this.identity = identity; this.fingerprint = fingerprint;
            pins = Array.AsReadOnly(values.ToArray()); this.expectedHash = expectedHash;
        }
        internal string Add(string name, Point position, int floor)
        {
            if (pins.Count >= MapPinStore.MaximumPins) throw new InvalidOperationException("This dungeon map already has 512 custom markers.");
            MapPinStore.ValidatePosition(position, floor);
            string id = Guid.NewGuid().ToString("N");
            var next = pins.Concat(new[] { new MapPin(id, MapPinStore.NormalizeName(name), position, floor) }).ToArray();
            Commit(next); return id;
        }
        internal bool Rename(string id, string name)
        {
            int index = Find(id); if (index < 0) return false;
            string selected = MapPinStore.NormalizeName(name);
            if (pins[index].name == selected) return false;
            var next = pins.ToArray(); var old = next[index];
            next[index] = new MapPin(old.id, selected, old.Position, old.floor);
            Commit(next); return true;
        }
        internal bool Remove(string id)
        {
            int index = Find(id); if (index < 0) return false;
            Commit(pins.Where((p, i) => i != index).ToArray()); return true;
        }
        private int Find(string id)
        { for (int i = 0; i < pins.Count; i++) if (pins[i].id == id) return i; return -1; }
        private void Commit(MapPin[] values)
        {
            // Allocate the read-only view before durable publication. Nothing
            // changes in memory or Revision if validation/storage fails.
            var snapshot = Array.AsReadOnly(values);
            string committed = store.Save(identity, fingerprint, values, expectedHash);
            pins = snapshot; expectedHash = committed; Revision++;
        }
    }

    internal sealed class MapPinStore
    {
        internal const int MaximumPins = 512, MaximumNameElements = 64, MaximumBytes = 256 * 1024;
        private readonly string root;
        internal MapPinStore(string root)
        { this.root = root ?? throw new ArgumentNullException(nameof(root)); }
        private string FileFor(string identity) => Path.Combine(root, Geometry.Hash(identity) + ".json");
        internal MapPinBook Load(string identity, string fingerprint)
        {
            ValidateScope(identity, fingerprint);
            string path = FileFor(identity);
            if (!File.Exists(path)) return new MapPinBook(this, identity, fingerprint, Array.Empty<MapPin>(), null);
            byte[] bytes = ReadBytes(path); var doc = Parse(bytes);
            Fields(doc, "schemaVersion", "identity", "fingerprint", "pins");
            if (Integer(doc["schemaVersion"]) != 1 || Text(doc["identity"]) != identity || Text(doc["fingerprint"]) != fingerprint || doc["pins"].Type != JTokenType.Array)
                throw new InvalidDataException("Custom markers belong to another dungeon map; existing file retained.");
            var rows = (JArray)doc["pins"];
            if (rows.Count > MaximumPins) throw new InvalidDataException("Custom marker record exceeds its pin limit.");
            var values = new List<MapPin>(); var ids = new HashSet<string>(StringComparer.Ordinal);
            foreach (var token in rows)
            {
                if (!(token is JObject pin)) throw new InvalidDataException("Invalid custom marker record.");
                Fields(pin, "id", "name", "floor", "x", "z");
                string id = Text(pin["id"]), name = Text(pin["name"]);
                if (!Guid.TryParseExact(id, "N", out var guid) || guid.ToString("N") != id || !ids.Add(id) || NormalizeName(name) != name)
                    throw new InvalidDataException("Invalid or repeated custom marker identity/name.");
                var position = new Point(Number(pin["x"]), Number(pin["z"])); int floor = Integer(pin["floor"]);
                ValidatePosition(position, floor); values.Add(new MapPin(id, name, position, floor));
            }
            return new MapPinBook(this, identity, fingerprint, values, Hash(bytes));
        }
        internal string Save(string identity, string fingerprint, MapPin[] values, string expectedHash)
        {
            ValidateScope(identity, fingerprint);
            if (values == null || values.Length > MaximumPins) throw new InvalidDataException("Too many custom markers.");
            var document = new { schemaVersion = 1, identity, fingerprint, pins = values };
            byte[] bytes = new UTF8Encoding(false, true).GetBytes(JsonConvert.SerializeObject(document, Formatting.Indented));
            if (bytes.Length > MaximumBytes) throw new InvalidDataException("Custom marker record exceeds its size limit.");
            string digest = Hash(bytes), path = FileFor(identity), temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            Directory.CreateDirectory(root);
            // Cooperating books/processes serialize publication here. Compare
            // original bytes as well, so a stale UI never overwrites edits.
            using (var lease = new FileStream(path + ".lock", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None))
            {
                RequireUnchanged(path, expectedHash);
                try
                {
                    using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    { stream.Write(bytes, 0, bytes.Length); stream.Flush(true); }
                    RequireUnchanged(path, expectedHash);
                    if (expectedHash == null) File.Move(temp, path);
                    else File.Replace(temp, path, path + ".bak");
                }
                finally { if (File.Exists(temp)) File.Delete(temp); }
            }
            return digest;
        }
        private static void RequireUnchanged(string path, string expectedHash)
        {
            string actual = File.Exists(path) ? Hash(ReadBytes(path)) : null;
            if (actual != expectedHash) throw new IOException("Custom markers changed on disk. Existing changes were retained; reload the marker record before editing again.");
        }
        private static byte[] ReadBytes(string path)
        {
            using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                if (stream.Length > MaximumBytes) throw new InvalidDataException("Custom marker record exceeds its size limit.");
                using (var buffer = new MemoryStream()) { stream.CopyTo(buffer); return buffer.ToArray(); }
            }
        }
        private static JObject Parse(byte[] bytes)
        {
            using (var text = new StringReader(new UTF8Encoding(false, true).GetString(bytes)))
            using (var reader = new JsonTextReader(text) { MaxDepth = 8, DateParseHandling = DateParseHandling.None })
            {
                var value = JObject.Load(reader, new JsonLoadSettings { DuplicatePropertyNameHandling = DuplicatePropertyNameHandling.Error });
                while (reader.Read()) if (reader.TokenType != JsonToken.Comment) throw new InvalidDataException("Custom marker record contains trailing content.");
                return value;
            }
        }
        private static void Fields(JObject value, params string[] names)
        {
            var required = new HashSet<string>(names, StringComparer.Ordinal);
            if (value.Count != required.Count || value.Properties().Any(p => !required.Contains(p.Name)))
                throw new InvalidDataException("Custom marker record fields differ from this version.");
        }
        private static string Text(JToken value)
        { if (value?.Type != JTokenType.String) throw new InvalidDataException("Invalid custom marker text."); return (string)value; }
        private static int Integer(JToken value)
        {
            if (value?.Type != JTokenType.Integer) throw new InvalidDataException("Invalid custom marker integer.");
            try { return checked((int)value); } catch (Exception ex) { throw new InvalidDataException("Custom marker integer is out of range.", ex); }
        }
        private static double Number(JToken value)
        {
            if (value?.Type != JTokenType.Float && value?.Type != JTokenType.Integer) throw new InvalidDataException("Invalid custom marker coordinate.");
            return (double)value;
        }
        private static string Hash(byte[] bytes)
        { using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
        private static void ValidateScope(string identity, string fingerprint)
        {
            if (string.IsNullOrWhiteSpace(identity) || identity.Length > 1024 || string.IsNullOrWhiteSpace(fingerprint) || fingerprint.Length > 256)
                throw new InvalidDataException("Invalid custom marker map identity.");
        }
        internal static void ValidatePosition(Point position, int floor)
        {
            if (double.IsNaN(position.X) || double.IsInfinity(position.X) || double.IsNaN(position.Z) || double.IsInfinity(position.Z) || Math.Abs(position.X) > 1000000 || Math.Abs(position.Z) > 1000000 || floor < -256 || floor > 256)
                throw new InvalidDataException("Custom marker position is outside the supported map range.");
        }
        internal static string NormalizeName(string name)
        {
            // Preserve Unicode names and render them as plain text in the UI.
            // Cap both graphemes and storage length without splitting a pair.
            string clean = new string((name ?? "").Select(c => char.IsControl(c) ? ' ' : c).ToArray()).Normalize(NormalizationForm.FormC).Trim();
            if (clean.Length == 0) return "Marker";
            var starts = StringInfo.ParseCombiningCharacters(clean); int length = clean.Length;
            if (starts.Length > MaximumNameElements) length = starts[MaximumNameElements];
            if (length > 256) length = starts.TakeWhile(p => p <= 256).LastOrDefault();
            if (length < clean.Length) clean = clean.Substring(0, length).TrimEnd();
            return clean.Length == 0 ? "Marker" : clean;
        }
    }
}
