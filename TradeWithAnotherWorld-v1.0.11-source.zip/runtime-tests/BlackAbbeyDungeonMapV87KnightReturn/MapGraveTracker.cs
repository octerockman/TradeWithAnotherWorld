using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

namespace BlackAbbeyDungeonMap
{
    // Read-only local-host observer. Native grave ZDOs are the persistence
    // source; no replacement grave, local grave save or world pin is created.
    internal sealed class MapGraveTracker
    {
        const float StepInterval=.05f,ScanInterval=2f;
        const int MaximumScanSteps=4096,MaximumExamined=32768;
        readonly Action<string> warning;
        readonly MapGraveSet set=new MapGraveSet();
        readonly List<ZDO> batch=new List<ZDO>();
        readonly HashSet<ZDOID> observedIds=new HashSet<ZDOID>();
        ZDOMan manager;
        Layout currentLayout;
        string scope,prefabName,lastFailure;
        int prefabHash,sectorIndex,steps,examined;
        long ownerId;
        float nextStep,nextScan;
        bool scanning;
        Vector3 origin;

        internal MapGraveTracker(Action<string> warning){this.warning=warning;}
        internal IReadOnlyList<MapGraveMark> Markers=>set.Markers;
        internal int Revision=>set.Revision;
        // Optional authoritative room/passage probe includes actual ward bays,
        // without adding guessed bay outlines to the measured parchment map.
        internal Func<Vector3,bool> ContainsRunPoint{get;set;}

        internal void Tick(Layout layout,Vector3 runOrigin,Player localPlayer,bool enabled)
        {
            if(!enabled||layout==null||!localPlayer||localPlayer!=Player.m_localPlayer){CancelScan();return;}
            long playerId=localPlayer.GetPlayerID();
            if(playerId==0||layout.Character!=playerId.ToString(CultureInfo.InvariantCulture))
            {Clear();return;}
            string key=layout.World+"|"+layout.Character+"|"+layout.RunId+"|"+layout.Fingerprint;
            if(scope!=key)
            {
                Clear();scope=key;ownerId=playerId;
            }
            if(!ReferenceEquals(currentLayout,layout))
            {CancelScan();currentLayout=layout;nextScan=0;}
            origin=runOrigin;
            if(!ZNet.instance||!ZNet.instance.IsServer()||ZDOMan.instance==null)
            {CancelScan();return;}
            if(!ReferenceEquals(manager,ZDOMan.instance))
            {CancelScan();manager=ZDOMan.instance;nextScan=0;}
            if(prefabName==null)
            {
                if(!localPlayer.m_tombstone||string.IsNullOrWhiteSpace(localPlayer.m_tombstone.name))return;
                prefabName=localPlayer.m_tombstone.name;prefabHash=prefabName.GetStableHashCode();
            }
            float now=Time.unscaledTime;
            if(!scanning)
            {
                if(now<nextScan)return;
                scanning=true;sectorIndex=steps=examined=0;nextStep=now;
                observedIds.Clear();set.Begin();
            }
            if(now<nextStep)return;
            nextStep=now+StepInterval;
            try
            {
                // The native512x512registry can need657slices. A wall-clock
                // timeout could discard a healthy advancing scan forever on a
                // large world or slow frame rate. The finite slice cap is the
                // scan bound; pacing never restarts a progressing pass.
                if(++steps>MaximumScanSteps)
                    throw new InvalidOperationException("native grave scan reached its bounded step limit");
                batch.Clear();
                bool complete=manager.GetAllZDOsWithPrefabIterative(prefabName,batch,ref sectorIndex);
                examined+=batch.Count;
                if(examined>MaximumExamined)throw new InvalidOperationException("native grave scan reached its record limit");
                foreach(var zdo in batch)
                    if(TryRead(zdo,out var mark))
                    {
                        observedIds.Add(zdo.m_uid);
                        if(observedIds.Count>MapGraveSet.MaximumMarkers||!set.Observe(mark))
                            throw new InvalidOperationException("native grave marker count reached its bounded limit");
                    }
                batch.Clear();
                if(!complete)return;
                // A grave observed early in a multi-frame scan may already have
                // been collected. Recheck its exact native UID before pruning.
                set.Begin();
                foreach(var id in observedIds)
                    if(TryRead(manager.GetZDO(id),out var mark)&&!set.Observe(mark))
                        throw new InvalidOperationException("native grave marker count reached its bounded limit");
                set.Complete();scanning=false;observedIds.Clear();nextScan=now+ScanInterval;lastFailure=null;
            }
            catch(Exception ex)
            {
                CancelScan();nextScan=now+ScanInterval;
                Warn("Grave map markers retained; "+ex.Message);
            }
        }

        bool TryRead(ZDO zdo,out MapGraveMark mark)
        {
            mark=null;
            if(zdo==null||!zdo.IsValid()||zdo.GetPrefab()!=prefabHash||zdo.GetLong(ZDOVars.s_owner,0)!=ownerId)return false;
            Vector3 current=zdo.GetPosition();
            Vector3 original=zdo.GetVec3(ZDOVars.s_spawnPoint,new Vector3(float.NaN,float.NaN,float.NaN));
            Vector3 a=current-origin,b=original-origin;
            bool currentInside=Contains(current,a),originalInside=Contains(original,b);
            if(!MapGravePolicy.TryPlace(currentLayout,new Point(a.x,a.z),a.y,currentInside,
                new Point(b.x,b.z),b.y,originalInside,out var point,out int floor))return false;
            mark=new MapGraveMark{Id=zdo.m_uid.ToString(),Position=point,Floor=floor};return true;
        }
        bool Contains(Vector3 world,Vector3 relative)
        {
            if(!MapGravePolicy.Finite(new Point(relative.x,relative.z),relative.y))return false;
            // Probe exceptions abort the scan; absence must never be inferred
            // from an unavailable helper or partially loaded native context.
            return ContainsRunPoint!=null?ContainsRunPoint(world):currentLayout.InScope(new Point(relative.x,relative.z),relative.y);
        }
        void Warn(string message)
        {
            if(lastFailure==message)return;lastFailure=message;
            try{warning?.Invoke(message);}catch{/* A logger cannot break the base map. */}
        }
        void CancelScan(){scanning=false;batch.Clear();observedIds.Clear();set.Cancel();}
        internal void Clear()
        {
            CancelScan();set.Clear();manager=null;currentLayout=null;scope=prefabName=lastFailure=null;
            prefabHash=sectorIndex=steps=examined=0;ownerId=0;nextStep=nextScan=0;
        }
    }
}
