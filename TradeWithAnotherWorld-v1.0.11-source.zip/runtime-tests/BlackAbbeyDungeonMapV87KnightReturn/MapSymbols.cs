using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace BlackAbbeyDungeonMap
{
#pragma warning disable 0649
    internal sealed class InkIconCatalog{public int schemaVersion;public InkIcon[] icons;}
    internal sealed class InkIcon{public string id;public IconPath[] paths;}
    internal sealed class IconPath{public bool closed,fill;public double[][] points;}
#pragma warning restore 0649
    internal sealed class RoomMark
    {internal string Id,Kind;internal Point Position;internal int Floor;}
    internal static class MapSymbols
    {
        private static Dictionary<string,InkIcon> icons;
        internal static IReadOnlyDictionary<string,InkIcon> Icons
        {
            get
            {
                if(icons==null)
                    using(var stream=typeof(MapSymbols).Assembly.GetManifestResourceStream("BlackAbbeyDungeonMap.map-ink-icons.json"))
                    using(var reader=new StreamReader(stream??throw new InvalidDataException("Missing ink glyphs.")))SetIcons(reader.ReadToEnd());
                return icons;
            }
        }
        internal static void SetIcons(string json)
        {
            var value=JsonConvert.DeserializeObject<InkIconCatalog>(json,new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MaxDepth=12});
            if(value?.schemaVersion!=1||value.icons?.Length!=RoomIconRules.Glyphs.Length||value.icons.Any(i=>i==null||string.IsNullOrEmpty(i.id)||i.paths==null||i.paths.Length==0||i.paths.Any(p=>p==null||p.points==null||p.points.Length<2||p.points.Any(v=>v==null||v.Length!=2||v.Any(n=>double.IsNaN(n)||double.IsInfinity(n)||Math.Abs(n)>12))))||value.icons.Select(i=>i.id).Distinct(StringComparer.Ordinal).Count()!=value.icons.Length)throw new InvalidDataException("Invalid map glyph source.");
            var next=value.icons.ToDictionary(i=>i.id,StringComparer.Ordinal);
            if(!RoomIconRules.Glyphs.All(next.ContainsKey))throw new InvalidDataException("Missing requested map glyph.");
            icons=next;
        }
        internal static string RoomLabel(string instance,string source,string original)=>source=="R01"?(instance=="R01"?"Entrance":"Hall of Statues"):original;
        internal static string Kind(Zone zone)=>RoomIconRules.Kind(zone);
        internal static Point Anchor(Zone zone)
        {
            Point[] ring=zone.Reveal;double area=0,x=0,z=0;
            for(int i=0;i<ring.Length;i++)
            {Point a=ring[i],b=ring[(i+1)%ring.Length];double cross=a.X*b.Z-b.X*a.Z;area+=cross;x+=(a.X+b.X)*cross;z+=(a.Z+b.Z)*cross;}
            Point center=Math.Abs(area)<1e-9?ring[0]:new Point(x/(3*area),z/(3*area));
            bool Inside(Point p)=>Geometry.Contains(ring,p)&&!(zone.RevealHoles??Array.Empty<Point[]>()).Any(h=>Geometry.Contains(h,p));
            if(Inside(center))return center;
            // Concave future rooms retain a genuine interior label point.
            double best=-1;Point result=ring[0];double minX=ring.Min(p=>p.X),maxX=ring.Max(p=>p.X),minZ=ring.Min(p=>p.Z),maxZ=ring.Max(p=>p.Z);
            for(int ix=1;ix<20;ix++)for(int iz=1;iz<20;iz++)
            {
                var candidate=new Point(minX+(maxX-minX)*ix/20,minZ+(maxZ-minZ)*iz/20);if(!Inside(candidate))continue;
                double clearance=new[]{ring}.Concat(zone.RevealHoles??Array.Empty<Point[]>()).SelectMany(h=>Enumerable.Range(0,h.Length).Select(i=>Geometry.Distance(candidate,h[i],h[(i+1)%h.Length]))).Min();
                if(clearance>best){result=candidate;best=clearance;}
            }
            return result;
        }
        internal static List<RoomMark> Rooms(MapState state,int floor)=>state.Layout.Zones.Where(z=>z.Floor==floor&&state.Zones.Contains(z.Id)&&Kind(z)!=null)
            .Select(z=>new RoomMark{Id=z.Id,Kind=Kind(z),Position=RoomAnchor(z),Floor=floor}).OrderBy(m=>m.Id,StringComparer.Ordinal).ToList();
        internal static Point RoomAnchor(Zone zone)
        {
            var center=Anchor(zone);string kind=Kind(zone);
            // Existing quest-room marks retain their exact original anchors.
            if(kind=="book"||kind=="stone-tomb"||kind=="jawless-skull")return center;
            var ring=zone.Reveal;
            bool Inside(Point p)=>Geometry.Contains(ring,p)&&!(zone.RevealHoles??Array.Empty<Point[]>()).Any(h=>Geometry.Contains(h,p));
            double Clearance(Point p)=>new[]{ring}.Concat(zone.RevealHoles??Array.Empty<Point[]>()).SelectMany(h=>Enumerable.Range(0,h.Length).Select(i=>Geometry.Distance(p,h[i],h[(i+1)%h.Length]))).Min();
            double best=Clearance(center);Point result=center;
            double minX=ring.Min(p=>p.X),maxX=ring.Max(p=>p.X),minZ=ring.Min(p=>p.Z),maxZ=ring.Max(p=>p.Z);
            for(int ix=1;ix<20;ix++)for(int iz=1;iz<20;iz++)
            {
                var candidate=new Point(minX+(maxX-minX)*ix/20,minZ+(maxZ-minZ)*iz/20);
                if(!Inside(candidate))continue;double clearance=Clearance(candidate);
                if(clearance>best+.001){best=clearance;result=candidate;}
            }
            return result;
        }
        internal static List<DoorMark> Doors(MapState state,int floor)=>state.Layout.Doors.Where(d=>d.Floor==floor&&d.Owners.Any(id=>state.Zones.Contains(id)))
            .GroupBy(d=>d.Id,StringComparer.Ordinal).Select(g=>g.First()).OrderBy(d=>d.Id,StringComparer.Ordinal).ToList();
        internal static List<RoomMark> Markers(MapState state,int floor)
        {
            var result=Rooms(state,floor);
            result.AddRange(Doors(state,floor).Where(d=>d.Warded).Select(d=>new RoomMark{Id="ward/"+d.Id,Kind="warded-door",Position=d.Center,Floor=d.Floor}));
            result.AddRange(Doors(state,floor).Where(d=>d.Exit).Select(d=>new RoomMark{Id="exit/"+d.Id,Kind="exit-door",Position=d.Center,Floor=d.Floor}));
            return result;
        }
        internal static List<InkStroke> DoorStrokes(DoorMark door)
        {
            Point n=door.Outward*(1/Math.Max(.0001,door.Outward.Length)),t=new Point(n.Z,-n.X),c=door.Center;
            Point left=c-t*(door.Width*.5),right=c+t*(door.Width*.5);
            var result=new List<InkStroke>{new InkStroke(left-n*.16,left+n*.16,true),new InkStroke(right-n*.16,right+n*.16,true),
                new InkStroke(left,c-n*.05,true),new InkStroke(c+n*.05,right,true),new InkStroke(left+n*.09,right+n*.09,true),new InkStroke(c-n*.14,c+n*.17,true)};
            // Ward icon is a fixed-size location mark, not a live lock/AI state.
            // Retain the authored doorway direction and omit ordinary hinge arcs.
            if(door.Warded)return result.Select(s=>new InkStroke(s.A,s.B,true,0,true)).ToList();
            if(door.Barred)result.Add(new InkStroke(c-t*(door.Width*.34)-n*.16,c+t*(door.Width*.34)+n*.16,true));
            result=result.Select(s=>new InkStroke(s.A,s.B,true,0,true)).ToList();
            // Conventional dashed hinge arcs identify the doorway clearly.
            // They are a cartographic location symbol, not animated leaf poses.
            if(!door.Barred)
                foreach(int side in new[]{-1,1})
                {
                    Point hinge=side<0?left:right,across=t*(-side);double radius=door.Width*.5;
                    for(int i=0;i<8;i+=2)
                    {
                        double a=i*Math.PI/16,b=(i+1)*Math.PI/16;
                        result.Add(new InkStroke(hinge+across*(Math.Cos(a)*radius)-n*(Math.Sin(a)*radius),hinge+across*(Math.Cos(b)*radius)-n*(Math.Sin(b)*radius),true));
                    }
                }
            return result;
        }
    }
}
