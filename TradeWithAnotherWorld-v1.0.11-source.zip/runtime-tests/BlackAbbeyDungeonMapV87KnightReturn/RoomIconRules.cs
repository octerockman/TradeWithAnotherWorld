using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace BlackAbbeyDungeonMap
{
#pragma warning disable 0649
    internal sealed class RoomIconMapping
    {
        public Dictionary<string,string> instanceOverrides,sources,zoneOverrides,doorMarkers,names;
    }
#pragma warning restore 0649
    internal static class RoomIconRules
    {
        internal static readonly string[] Glyphs={"entry-arch","hall-arches","book","saint-statue","broken-saint","hanging-bell","reliquary-bone","vestry-robe","stone-tomb","stairs-up","stairs-down","procession-candles","jawless-skull","warded-door","exit-door","custom-pin","grave"};
        static RoomIconMapping mapping;
        internal static RoomIconMapping Mapping
        {
            get
            {
                if(mapping==null)
                    using(var stream=typeof(RoomIconRules).Assembly.GetManifestResourceStream("BlackAbbeyDungeonMap.room-icon-mapping.json"))
                    using(var reader=new StreamReader(stream??throw new InvalidDataException("Missing room icon mapping.")))SetMapping(reader.ReadToEnd());
                return mapping;
            }
        }
        internal static void SetMapping(string json)
        {
            var next=JsonConvert.DeserializeObject<RoomIconMapping>(json,new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MaxDepth=8});
            if(next?.instanceOverrides==null||next.sources==null||next.zoneOverrides==null||next.doorMarkers==null||next.names==null||
                next.instanceOverrides.Concat(next.sources).Concat(next.zoneOverrides).Concat(next.doorMarkers).Any(p=>string.IsNullOrEmpty(p.Key)||!Glyphs.Contains(p.Value))||
                Glyphs.Take(14).Any(id=>!next.names.TryGetValue(id,out var label)||string.IsNullOrWhiteSpace(label)||label.Length>64)||
                !next.instanceOverrides.TryGetValue("R01",out var entry)||entry!="entry-arch"||
                !next.doorMarkers.TryGetValue("warded",out var ward)||ward!="warded-door")throw new InvalidDataException("Invalid room icon mapping.");
            mapping=next;
        }
        internal static string Kind(Zone zone)
        {
            if(zone==null)return null;
            if(zone.IconOverride!=null)
            {
                if(zone.IconOverride.Length==0)return null;
                if(!Glyphs.Contains(zone.IconOverride))throw new InvalidDataException("Unknown alternate room marker.");
                return zone.IconOverride;
            }
            var rules=Mapping;
            if(rules.instanceOverrides.TryGetValue(zone.Instance??"",out var icon))return icon;
            string id=zone.Id??"";int slash=id.LastIndexOf('/');string key=zone.Source+"/"+id.Substring(slash+1);
            if(rules.zoneOverrides.TryGetValue(key,out icon))return icon;
            return rules.sources.TryGetValue(zone.Source??"",out icon)?icon:null;
        }
        internal static string Name(string glyph)=>Mapping.names.TryGetValue(glyph,out var name)?name:
            glyph=="exit-door"?"Dungeon exit":glyph=="custom-pin"?"Personal marker":glyph=="grave"?"Grave":glyph;
    }
}
