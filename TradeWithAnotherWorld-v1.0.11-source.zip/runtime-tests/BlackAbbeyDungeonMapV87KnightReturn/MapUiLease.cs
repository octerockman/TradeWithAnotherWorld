using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using Object=UnityEngine.Object;

namespace BlackAbbeyDungeonMap
{
    internal sealed class MapUiLease:IDisposable
    {
        private readonly Minimap map;private readonly GameObject smallRoot,largeRoot;
        private readonly Dictionary<Graphic,bool> enabled=new Dictionary<Graphic,bool>();
        private readonly Dictionary<string,object> fields=new Dictionary<string,object>();
        private readonly Texture2D paper;private readonly ParchmentView small,large;
        internal bool LargeOpen=>largeRoot&&largeRoot.activeInHierarchy;
        internal MapUiLease(Minimap map)
        {
            this.map=map;smallRoot=(GameObject)Get("m_smallRoot");largeRoot=(GameObject)Get("m_largeRoot");
            var smallImage=(UnityEngine.UI.RawImage)Get("m_mapImageSmall");var largeImage=(UnityEngine.UI.RawImage)Get("m_mapImageLarge");
            if(!smallRoot||!largeRoot||!smallImage||!largeImage)throw new InvalidOperationException("Native map views are not ready.");
            var font=((TMP_Text)Get("m_biomeNameLarge"))?.font??largeRoot.GetComponentsInChildren<TMP_Text>(true).Select(t=>t.font).FirstOrDefault(f=>f);
            if(!font)throw new InvalidOperationException("Native map font is not ready.");
            foreach(string name in new[]{"m_mode","m_largeZoom","m_smallZoom","m_mapOffset","m_dragView"})fields.Add(name,Get(name));
            try
            {
                foreach(var graphic in smallRoot.GetComponentsInChildren<Graphic>(true).Concat(largeRoot.GetComponentsInChildren<Graphic>(true)))
                    if(!enabled.ContainsKey(graphic)){enabled.Add(graphic,graphic.enabled);graphic.enabled=false;}
                paper=CreatePaper();
                small=new ParchmentView(smallRoot.transform,smallImage.rectTransform,false,paper,font);
                large=new ParchmentView(largeRoot.transform,largeImage.rectTransform,true,paper,font);
            }
            catch{Dispose();throw;}
        }
        private object Get(string name)=>(AccessTools.Field(typeof(Minimap),name)??throw new MissingFieldException("Minimap",name)).GetValue(map);
        internal void Show(MapState state,Point position,float heading,MapPinBook pins,IReadOnlyList<MapGraveMark> graves,int graveRevision,Action<Exception> pinError)
        {
            if(!map)throw new InvalidOperationException("Native map was destroyed.");
            small.Annotations(pins,graves,graveRevision,pinError);large.Annotations(pins,graves,graveRevision,pinError);
            if(LargeOpen&&InputAllowed())
            {
                if(ZInput.GetKeyDown(KeyCode.F))large.Centre(position,state.CurrentFloor);
                if(ZInput.GetKeyDown(KeyCode.R))large.FitExplored();
                if(ZInput.GetKeyDown(KeyCode.Insert)||ZInput.GetButtonDown("JoyButtonA"))large.AddMarkerAtCenter();
                if(ZInput.GetKeyDown(KeyCode.Delete)||ZInput.GetButtonDown("JoyButtonX"))large.RemoveMarkerAtCenter();
                if(ZInput.GetKeyDown(KeyCode.PageUp)||ZInput.GetButtonDown("JoyTabRight"))large.CycleFloor(1);
                if(ZInput.GetKeyDown(KeyCode.PageDown)||ZInput.GetButtonDown("JoyTabLeft"))large.CycleFloor(-1);
                if(ZInput.GetButton("JoyMapZoomIn"))large.Zoom(Time.unscaledDeltaTime*4);
                if(ZInput.GetButton("JoyMapZoomOut"))large.Zoom(-Time.unscaledDeltaTime*4);
                var pan=new Vector2(ZInput.GetJoyLeftStickX(),-ZInput.GetJoyLeftStickY());if(pan.sqrMagnitude>.1f)large.Pan(-pan*Time.unscaledDeltaTime*250);
            }
            else if(!LargeOpen&&InputAllowed())
            {
                if(ZInput.GetButtonDown("MapZoomIn"))small.Zoom(1);
                if(ZInput.GetButtonDown("MapZoomOut"))small.Zoom(-1);
            }
            small.Show(state,position,heading,smallRoot.activeInHierarchy);large.Show(state,position,heading,LargeOpen);
        }
        internal static bool InputAllowed()=>!global::Console.IsVisible()&&!Menu.IsActive()&&!InventoryGui.IsVisible()&&!TextInput.IsVisible()&&(!Chat.instance||!Chat.instance.HasFocus());
        private static Texture2D CreatePaper()
        {
            const int size=256;var texture=new Texture2D(size,size,TextureFormat.RGBA32,false){name="Abbey | procedural parchment",wrapMode=TextureWrapMode.Clamp,filterMode=FilterMode.Bilinear};
            var pixels=new Color32[size*size];var random=new System.Random(140713);
            for(int y=0;y<size;y++)for(int x=0;x<size;x++)
            {
                double edge=Math.Min(Math.Min(x,size-1-x),Math.Min(y,size-1-y))/(double)size;
                double stain=Math.Exp(-edge*22)*.12,grain=(random.NextDouble()-.5)*.035;
                double fold=Math.Sin(x*.071+y*.023)*.009+Math.Sin(x*.018-y*.047)*.012;
                pixels[y*size+x]=new Color((float)(.83-stain+grain+fold),(float)(.73-stain+grain+fold),(float)(.53-stain+grain+fold),1);
            }
            texture.SetPixels32(pixels);texture.Apply(false,true);return texture;
        }
        public void Dispose()
        {
            small?.Dispose();large?.Dispose();
            foreach(var pair in enabled)if(pair.Key)pair.Key.enabled=pair.Value;enabled.Clear();
            if(map&&fields.Count>0)
            {
                var p=Player.m_localPlayer;
                if(p&&!p.IsDead())AccessTools.Method(typeof(Minimap),"SetMapMode").Invoke(map,new[]{fields["m_mode"]});
                foreach(var pair in fields.Where(f=>f.Key!="m_mode"))AccessTools.Field(typeof(Minimap),pair.Key)?.SetValue(map,pair.Value);
            }
            fields.Clear();if(paper)Object.Destroy(paper);
        }
    }
}
