using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Object=UnityEngine.Object;

namespace BlackAbbeyDungeonMap
{
    internal sealed class MapInkGraphic:UnityEngine.UI.MaskableGraphic
    {
        internal List<InkStroke> Strokes=new List<InkStroke>();internal List<RoomMark> Markers=new List<RoomMark>();internal Point Center;internal float PixelsPerMetre=5,MarkerSize=24;
        protected override void OnPopulateMesh(VertexHelper vh)
        {
            vh.Clear();
            foreach(var stroke in Strokes)
            {
                Vector2 a=ToPixel(stroke.A),b=ToPixel(stroke.B);Rect bounds=rectTransform.rect;
                if(Mathf.Max(a.x,b.x)<bounds.xMin-8||Mathf.Min(a.x,b.x)>bounds.xMax+8||Mathf.Max(a.y,b.y)<bounds.yMin-8||Mathf.Min(a.y,b.y)>bounds.yMax+8)continue;
                foreach(var pen in HandInk.Stroke(new Point(a.x,a.y),new Point(b.x,b.y),stroke.Fine,stroke.Seed,stroke.HatchSide))
                    Draw(vh,Pixel(pen.A),Pixel(pen.B),(float)(pen.Width*(stroke.Bold?1.7:1)),new Color(.22f,.125f,.055f,stroke.Bold?.96f:(float)pen.Opacity));
            }
            foreach(var marker in Markers)DrawGlyph(vh,marker);
        }
        private static Vector2 Pixel(Point p)=>new Vector2((float)p.X,(float)p.Z);
        private void DrawGlyph(VertexHelper vh,RoomMark marker)
        {
            if(!MapSymbols.Icons.TryGetValue(marker.Kind,out var icon))return;
            Vector2 center=ToPixel(marker.Position);Rect bounds=rectTransform.rect;float radius=MarkerSize*.55f;
            if(!bounds.Contains(center+new Vector2(radius,radius))||!bounds.Contains(center-new Vector2(radius,radius)))return;
            var points=icon.paths.SelectMany(p=>p.points).ToArray();double minX=points.Min(p=>p[0]),maxX=points.Max(p=>p[0]),minY=points.Min(p=>p[1]),maxY=points.Max(p=>p[1]);
            double scale=MarkerSize/Math.Max(maxX-minX,maxY-minY);var pivot=new Point((minX+maxX)*.5,(minY+maxY)*.5);
            Point Place(double[] value)=>new Point(center.x,center.y)+(Point.Of(value)-pivot)*scale;
            foreach(var path in icon.paths)
            {
                if(path.fill)
                {
                    int index=vh.currentVertCount;foreach(var p in path.points)vh.AddVert(Pixel(Place(p)),new Color(.22f,.125f,.055f,.95f),Vector2.zero);
                    for(int j=1;j<path.points.Length-1;j++)vh.AddTriangle(index,index+j,index+j+1);
                }
                int count=path.closed?path.points.Length:path.points.Length-1;
                for(int j=0;j<count;j++)
                {
                    var a=Place(path.points[j]);var b=Place(path.points[(j+1)%path.points.Length]);
                    foreach(var pen in HandInk.Stroke(a,b,true,HandInk.Seed(Point.Of(path.points[j]),Point.Of(path.points[(j+1)%path.points.Length]))))
                        Draw(vh,Pixel(pen.A),Pixel(pen.B),(float)(pen.Width*1.25),new Color(.22f,.125f,.055f,.95f));
                }
            }
        }
        internal Vector2 ToPixel(Point p)=>new Vector2((float)(p.X-Center.X)*PixelsPerMetre,(float)(p.Z-Center.Z)*PixelsPerMetre);
        private void Draw(VertexHelper vh,Vector2 a,Vector2 b,float width,Color color)
        {
            if(!Clip(ref a,ref b,rectTransform.rect))return;
            Vector2 d=b-a;if(d.sqrMagnitude<.01f)return;
            Vector2 n=new Vector2(-d.y,d.x).normalized*(width*.5f);int start=vh.currentVertCount;
            vh.AddVert(a-n,color,Vector2.zero);vh.AddVert(a+n,color,Vector2.zero);vh.AddVert(b+n,color,Vector2.zero);vh.AddVert(b-n,color,Vector2.zero);
            vh.AddTriangle(start,start+1,start+2);vh.AddTriangle(start,start+2,start+3);
        }
        private static bool Clip(ref Vector2 a,ref Vector2 b,Rect rect)
        {
            Vector2 d=b-a;float lo=0,hi=1;
            if(!Edge(-d.x,a.x-rect.xMin,ref lo,ref hi)||!Edge(d.x,rect.xMax-a.x,ref lo,ref hi)||!Edge(-d.y,a.y-rect.yMin,ref lo,ref hi)||!Edge(d.y,rect.yMax-a.y,ref lo,ref hi))return false;
            b=a+d*hi;a+=d*lo;return true;
        }
        private static bool Edge(float p,float q,ref float lo,ref float hi)
        {if(Mathf.Abs(p)<1e-8f)return q>=0;float t=q/p;if(p<0){if(t>hi)return false;lo=Mathf.Max(lo,t);}else{if(t<lo)return false;hi=Mathf.Min(hi,t);}return true;}
    }
    internal sealed class PlayerArrowGraphic:UnityEngine.UI.MaskableGraphic
    {
        internal Vector2 Position;internal float Heading;internal bool Visible=true;
        protected override void OnPopulateMesh(VertexHelper vh)
        {
            vh.Clear();if(!Visible||!rectTransform.rect.Contains(Position))return;
            float a=-Heading*Mathf.Deg2Rad;Vector2 forward=new Vector2(-Mathf.Sin(a),Mathf.Cos(a)),right=new Vector2(forward.y,-forward.x);
            var red=new Color(.58f,.09f,.055f,1);float size=7;
            vh.AddVert(Position+forward*size,red,Vector2.zero);vh.AddVert(Position-forward*size*.65f-right*size*.65f,red,Vector2.zero);
            vh.AddVert(Position-forward*size*.25f,red,Vector2.zero);vh.AddVert(Position-forward*size*.65f+right*size*.65f,red,Vector2.zero);
            vh.AddTriangle(0,1,2);vh.AddTriangle(0,2,3);
        }
    }
    internal sealed class MapPointer:MonoBehaviour,IScrollHandler,IBeginDragHandler,IDragHandler,IPointerClickHandler
    {
        internal ParchmentView View;
        public void OnScroll(PointerEventData e){if(MapUiLease.InputAllowed()){View?.Zoom(e.scrollDelta.y);e.Use();}}
        public void OnBeginDrag(PointerEventData e){if(e.button==PointerEventData.InputButton.Left)e.Use();}
        public void OnDrag(PointerEventData e){if(e.button==PointerEventData.InputButton.Left&&MapUiLease.InputAllowed()){View?.Pan(e.delta);e.Use();}}
        public void OnPointerClick(PointerEventData e)
        {
            if(!MapUiLease.InputAllowed())return;
            if(e.button==PointerEventData.InputButton.Right){View?.ClickMarker(e.position,e.pressEventCamera,true);e.Use();}
            else if(e.button==PointerEventData.InputButton.Left&&e.clickCount==2){View?.ClickMarker(e.position,e.pressEventCamera,false);e.Use();}
        }
    }
    internal sealed class ParchmentView:IDisposable
    {
        internal readonly GameObject Root;internal readonly bool Large;
        internal int Floor;internal float Span;internal Point Center;
        private readonly MapInkGraphic ink;private readonly PlayerArrowGraphic arrow;
        private readonly TextMeshProUGUI title,footer,reticle;private readonly RectTransform reference,parent;
        private readonly RectTransform rect,viewport;
        private readonly TMP_FontAsset font;private int revision=-1,cachedFloor=int.MinValue;private float nextSmallRefresh;private MapState state;
        private MapPinBook pinBook;private IReadOnlyList<MapGraveMark> graves=Array.Empty<MapGraveMark>();private Action<Exception> pinError;
        private int pinRevision=-1,graveRevision=-1,currentGraveRevision,lastPromptFrame=-1;
        private readonly List<KeyValuePair<Point,GameObject>> personalLabels=new List<KeyValuePair<Point,GameObject>>();
        private bool shown;
        private readonly Vector3[] corners=new Vector3[4];
        internal ParchmentView(Transform parent,RectTransform reference,bool large,Texture2D paper,TMP_FontAsset font)
        {
            Large=large;Span=large?90:28;this.reference=reference;this.parent=parent as RectTransform;this.font=font;
            Root=new GameObject(large?"AbbeyParchmentFullMap":"AbbeyParchmentMinimap",typeof(RectTransform),typeof(CanvasRenderer),typeof(UnityEngine.UI.RawImage));
            rect=Root.GetComponent<RectTransform>();rect.SetParent(parent,false);rect.anchorMin=rect.anchorMax=new Vector2(.5f,.5f);rect.pivot=new Vector2(.5f,.5f);
            var background=Root.GetComponent<UnityEngine.UI.RawImage>();background.texture=paper;background.raycastTarget=large;background.maskable=false;
            title=Text("Title",rect,large?27:15,TextAlignmentOptions.Center);title.text=large?"The Black Abbey":"Black Abbey";
            title.rectTransform.anchorMin=new Vector2(0,1);title.rectTransform.anchorMax=Vector2.one;title.rectTransform.pivot=new Vector2(.5f,1);title.rectTransform.sizeDelta=new Vector2(0,large?44:25);
            title.rectTransform.anchoredPosition=new Vector2(0,-5);
            var viewObject=new GameObject("InkViewport",typeof(RectTransform));viewport=viewObject.GetComponent<RectTransform>();viewport.SetParent(rect,false);Stretch(viewport,large?35:8,large?56:30,large?35:8,large?94:8);
            ink=viewObject.AddComponent<MapInkGraphic>();ink.raycastTarget=false;ink.maskable=false;
            ink.MarkerSize=large?25:18;
            var marker=new GameObject("PlayerArrow",typeof(RectTransform));var markerRect=marker.GetComponent<RectTransform>();markerRect.SetParent(viewport,false);Stretch(markerRect,0,0,0,0);
            arrow=marker.AddComponent<PlayerArrowGraphic>();arrow.raycastTarget=false;arrow.maskable=false;
            if(large){reticle=Text("MarkerCrosshair",viewport,25,TextAlignmentOptions.Center);reticle.text="+";reticle.rectTransform.sizeDelta=new Vector2(30,30);reticle.rectTransform.anchoredPosition=Vector2.zero;reticle.gameObject.SetActive(false);}
            footer=Text("MapControls",rect,large?15:12,TextAlignmentOptions.Center);footer.rectTransform.anchorMin=Vector2.zero;footer.rectTransform.anchorMax=new Vector2(1,0);footer.rectTransform.pivot=new Vector2(.5f,0);footer.rectTransform.sizeDelta=new Vector2(0,large?46:18);footer.rectTransform.anchoredPosition=new Vector2(0,5);
            if(large){var pointer=Root.AddComponent<MapPointer>();pointer.View=this;CreateAddMarkerButton();CreateRoomKey();}
            Root.SetActive(false);UpdateBounds();
        }
        private TextMeshProUGUI Text(string name,Transform host,float size,TextAlignmentOptions alignment)
        {
            var go=new GameObject(name,typeof(RectTransform),typeof(CanvasRenderer),typeof(TextMeshProUGUI));go.transform.SetParent(host,false);
            var text=go.GetComponent<TextMeshProUGUI>();text.font=font;text.fontSize=size;text.color=new Color(.24f,.14f,.07f,1);text.alignment=alignment;text.raycastTarget=false;text.maskable=false;text.richText=false;return text;
        }
        private void CreateAddMarkerButton()
        {
            var go=new GameObject("AddMarker",typeof(RectTransform),typeof(CanvasRenderer),typeof(UnityEngine.UI.Image),typeof(UnityEngine.UI.Button));
            var rt=go.GetComponent<RectTransform>();rt.SetParent(rect,false);rt.anchorMin=rt.anchorMax=Vector2.zero;rt.pivot=Vector2.zero;rt.anchoredPosition=new Vector2(35,59);rt.sizeDelta=new Vector2(126,28);
            var image=go.GetComponent<UnityEngine.UI.Image>();image.color=new Color(.35f,.21f,.09f,.22f);image.raycastTarget=true;image.maskable=false;
            var button=go.GetComponent<UnityEngine.UI.Button>();button.targetGraphic=image;button.navigation=new Navigation{mode=Navigation.Mode.None};button.onClick.AddListener(AddMarkerAtCenter);
            var label=Text("Label",rt,16,TextAlignmentOptions.Center);label.text="Add marker";Stretch(label.rectTransform,0,0,0,0);
        }
        internal void Annotations(MapPinBook book,IReadOnlyList<MapGraveMark> marks,int markRevision,Action<Exception> error)
        {
            if(!ReferenceEquals(pinBook,book)){pinRevision=-1;revision=-1;}pinBook=book;graves=marks??Array.Empty<MapGraveMark>();currentGraveRevision=markRevision;pinError=error;
        }
        private void CreateRoomKey()
        {
            var panel=new GameObject("RoomKey",typeof(RectTransform),typeof(CanvasRenderer),typeof(UnityEngine.UI.Image));
            var rt=panel.GetComponent<RectTransform>();rt.SetParent(rect,false);rt.anchorMin=rt.anchorMax=new Vector2(1,0);rt.pivot=new Vector2(1,0);
            const float row=23,height=437;rt.anchoredPosition=new Vector2(-35,94);rt.sizeDelta=new Vector2(260,height);
            var background=panel.GetComponent<UnityEngine.UI.Image>();background.color=new Color(.91f,.83f,.65f,.98f);background.raycastTarget=false;background.maskable=false;
            var heading=Text("RoomKeyTitle",rt,18,TextAlignmentOptions.TopLeft);heading.text="Map key";heading.rectTransform.anchorMin=heading.rectTransform.anchorMax=new Vector2(0,1);heading.rectTransform.pivot=new Vector2(0,1);heading.rectTransform.anchoredPosition=new Vector2(16,-10);heading.rectTransform.sizeDelta=new Vector2(228,26);
            var drawing=new GameObject("RoomKeyGlyphs",typeof(RectTransform));var drawingRect=drawing.GetComponent<RectTransform>();drawingRect.SetParent(rt,false);Stretch(drawingRect,0,0,0,0);
            var glyphs=drawing.AddComponent<MapInkGraphic>();glyphs.raycastTarget=false;glyphs.maskable=false;glyphs.PixelsPerMetre=1;glyphs.MarkerSize=18;
            for(int i=0;i<RoomIconRules.Glyphs.Length;i++)
            {
                string kind=RoomIconRules.Glyphs[i];glyphs.Markers.Add(new RoomMark{Id="key/"+kind,Kind=kind,Position=new Point(-105,height*.5-51-i*row)});
                var name=Text("RoomKeyName",rt,15,TextAlignmentOptions.MidlineLeft);name.text=RoomIconRules.Name(kind);name.rectTransform.anchorMin=name.rectTransform.anchorMax=new Vector2(0,1);name.rectTransform.pivot=new Vector2(0,1);name.rectTransform.anchoredPosition=new Vector2(45,-40-i*row);name.rectTransform.sizeDelta=new Vector2(205,row);
            }
            var go=new GameObject("RoomKeyButton",typeof(RectTransform),typeof(CanvasRenderer),typeof(UnityEngine.UI.Image),typeof(UnityEngine.UI.Button));
            var buttonRect=go.GetComponent<RectTransform>();buttonRect.SetParent(rect,false);buttonRect.anchorMin=buttonRect.anchorMax=new Vector2(1,0);buttonRect.pivot=new Vector2(1,0);buttonRect.anchoredPosition=new Vector2(-35,59);buttonRect.sizeDelta=new Vector2(126,28);
            var image=go.GetComponent<UnityEngine.UI.Image>();image.color=new Color(.35f,.21f,.09f,.22f);image.raycastTarget=true;image.maskable=false;
            var button=go.GetComponent<UnityEngine.UI.Button>();button.targetGraphic=image;button.navigation=new Navigation{mode=Navigation.Mode.None};
            var label=Text("Label",buttonRect,16,TextAlignmentOptions.Center);label.text="Map key";Stretch(label.rectTransform,0,0,0,0);
            button.onClick.AddListener(()=>{panel.SetActive(!panel.activeSelf);label.text=panel.activeSelf?"Hide key":"Map key";});panel.SetActive(false);
        }
        private static void Stretch(RectTransform rt,float left,float top,float right,float bottom)
        {rt.anchorMin=Vector2.zero;rt.anchorMax=Vector2.one;rt.pivot=new Vector2(.5f,.5f);rt.offsetMin=new Vector2(left,bottom);rt.offsetMax=new Vector2(-right,-top);}
        private void UpdateBounds()
        {
            reference.GetWorldCorners(corners);
            Vector3 a=parent.InverseTransformPoint(corners[0]),b=parent.InverseTransformPoint(corners[2]);
            rect.localPosition=(a+b)*.5f;rect.sizeDelta=new Vector2(Mathf.Abs(b.x-a.x),Mathf.Abs(b.y-a.y));
        }
        internal void Show(MapState current,Point player,float heading,bool visible)
        {
            if(!Root)return;UpdateBounds();Root.SetActive(visible);
            if(!visible){shown=false;return;}bool newlyShown=!shown;shown=true;
            if(state!=current){state=current;revision=-1;Floor=state.CurrentFloor??state.KnownFloors.FirstOrDefault();Center=player;Span=Large?90:28;}
            if(!Large){Floor=state.CurrentFloor??Floor;if(Time.unscaledTime>=nextSmallRefresh){Center=player;nextSmallRefresh=Time.unscaledTime+.08f;ink.SetVerticesDirty();}}
            else if(newlyShown){Center=player;Floor=state.CurrentFloor??Floor;revision=-1;}
            if(revision!=state.Revision||cachedFloor!=Floor||pinRevision!=(pinBook?.Revision??0)||graveRevision!=currentGraveRevision)
            {
                ink.Strokes=InkPlan.Build(state,Floor);ink.Strokes.AddRange(MapSymbols.Doors(state,Floor).SelectMany(MapSymbols.DoorStrokes));ink.Markers=MapSymbols.Markers(state,Floor);
                ink.Markers.AddRange(MapAnnotations.ForFloor(pinBook,graves,Floor));
                revision=state.Revision;cachedFloor=Floor;pinRevision=pinBook?.Revision??0;graveRevision=currentGraveRevision;UpdateLabels();ink.SetVerticesDirty();
            }
            ink.Center=Center;ink.PixelsPerMetre=Mathf.Max(1,viewport.rect.width)/Span;
            arrow.Position=ink.ToPixel(player);arrow.Heading=heading;arrow.Visible=Floor==state.CurrentFloor;arrow.SetVerticesDirty();
            if(reticle)reticle.gameObject.SetActive(Large&&ZInput.IsGamepadActive());
            if(Large)PositionLabels();
            footer.text=Large?(ZInput.IsGamepadActive()?"A: add / rename marker   X: remove marker at centre\nLeft stick: pan   Triggers: zoom   Tabs: explored floors":"Wheel: zoom   Drag: pan   F: centre   R: fit   PgUp/PgDn: floors\nDouble-click: add / rename marker   Right-click: remove marker"):"";
            title.text=(Large?"The Black Abbey":"Black Abbey")+(state.KnownFloors.Length>1?"  ·  "+FloorName(Floor):"");
        }
        private string FloorName(int floor)=>floor==0?"Lower halls":floor>0?"Upper "+floor:"Depth "+(-floor);
        private void UpdateLabels()
        {
            foreach(var label in personalLabels)if(label.Value)Object.Destroy(label.Value);personalLabels.Clear();
            if(!Large)return;
            if(pinBook!=null)foreach(var pin in pinBook.Pins.Where(p=>p.floor==Floor))AddPersonalLabel(pin.Position,pin.name);
            foreach(var grave in graves.Where(g=>g.Floor==Floor))AddPersonalLabel(grave.Position,"Grave");
        }
        private void AddPersonalLabel(Point point,string name)
        {
            var text=Text("MarkerName",viewport,14,TextAlignmentOptions.Center);text.text=name;text.rectTransform.sizeDelta=new Vector2(160,23);text.overflowMode=TextOverflowModes.Ellipsis;
            personalLabels.Add(new KeyValuePair<Point,GameObject>(point,text.gameObject));
        }
        private void PositionLabels()
        {
            foreach(var label in personalLabels)
            {
                var pos=ink.ToPixel(label.Key)+new Vector2(0,-25);label.Value.SetActive(viewport.rect.Contains(pos));label.Value.GetComponent<RectTransform>().anchoredPosition=pos;
            }
        }
        internal void ClickMarker(Vector2 screen,Camera camera,bool remove)
        {
            if(!Large||state==null||pinBook==null||!MapUiLease.InputAllowed())return;
            if(!RectTransformUtility.ScreenPointToLocalPointInRectangle(viewport,screen,camera,out var local)||!viewport.rect.Contains(local))return;
            var point=MapAnnotations.FromPixel(Center,Math.Max(.1,ink.PixelsPerMetre),local.x,local.y);
            if(remove)RemoveMarkerAt(point);else PromptMarker(point);
        }
        internal void AddMarkerAtCenter(){if(Large&&state!=null&&MapUiLease.InputAllowed())PromptMarker(Center);}
        internal void RemoveMarkerAtCenter(){if(Large&&state!=null&&MapUiLease.InputAllowed())RemoveMarkerAt(Center);}
        private MapPin NearestPin(Point point)=>MapAnnotations.Nearest(pinBook,Floor,point,ink.PixelsPerMetre);
        private void RemoveMarkerAt(Point point)
        {
            var pin=NearestPin(point);if(pin==null)return;
            try{pinBook.Remove(pin.id);}catch(Exception ex){pinError?.Invoke(ex);}
        }
        private void PromptMarker(Point point)
        {
            if(pinBook==null||!TextInput.instance||lastPromptFrame==Time.frameCount)return;
            lastPromptFrame=Time.frameCount;var book=pinBook;var existing=NearestPin(point);int floor=Floor;
            TextInput.instance.RequestText(new MarkerNameReceiver(existing?.name??"",name=>
            {
                if(!Root||!Root.activeInHierarchy||!ReferenceEquals(pinBook,book))return;
                try{if(existing==null)book.Add(name,point,floor);else book.Rename(existing.id,name);}
                catch(Exception ex){pinError?.Invoke(ex);}
            }),existing==null?"Name map marker":"Rename map marker",64);
        }
        private sealed class MarkerNameReceiver:TextReceiver
        {
            private readonly string text;private readonly Action<string> accept;
            internal MarkerNameReceiver(string text,Action<string> accept){this.text=text;this.accept=accept;}
            public string GetText()=>text;
            public void SetText(string value)=>accept(value);
        }
        internal void Zoom(float delta){Span=(float)MapZoom.Apply(Span,delta,Large);ink.SetVerticesDirty();}
        internal void Pan(Vector2 delta){Center-=new Point(delta.x,delta.y)*(1/Math.Max(.1,ink.PixelsPerMetre));ink.Center=Center;ink.SetVerticesDirty();}
        internal void Centre(Point player,int? floor){Center=player;if(floor.HasValue)Floor=floor.Value;ink.SetVerticesDirty();}
        internal void FitExplored()
        {
            if(ink.Strokes.Count==0)return;
            var points=ink.Strokes.SelectMany(s=>new[]{s.A,s.B}).ToArray();
            double left=points.Min(p=>p.X),right=points.Max(p=>p.X),bottom=points.Min(p=>p.Z),top=points.Max(p=>p.Z);
            Center=new Point((left+right)*.5,(bottom+top)*.5);
            double aspect=Math.Max(.2,viewport.rect.width/Math.Max(1,viewport.rect.height));
            Span=(float)Math.Max(18,Math.Max(right-left,(top-bottom)*aspect)*1.12);ink.SetVerticesDirty();
        }
        internal void CycleFloor(int direction)
        {
            if(state==null)return;var floors=state.KnownFloors;if(floors.Length<2)return;
            int index=Array.IndexOf(floors,Floor);Floor=floors[(Math.Max(0,index)+direction+floors.Length)%floors.Length];
        }
        public void Dispose(){if(Root){Root.SetActive(false);Object.Destroy(Root);}}
    }
}
