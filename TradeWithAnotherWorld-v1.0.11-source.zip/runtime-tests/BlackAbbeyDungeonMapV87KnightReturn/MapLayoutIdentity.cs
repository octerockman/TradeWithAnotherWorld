using System.Globalization;
using System.IO;

namespace BlackAbbeyDungeonMap
{
    internal static class MapLayoutIdentity
    {
        // Legacy layouts keep their historical prefix byte for byte. Only an
        // actual alternate asset selects the separate measured catalog hash.
        internal static string Prefix(string geometry,string variants,bool hasVariants,string mode,int seed)=>
            geometry+(hasVariants?"/variants/"+variants:"")+"/"+mode+"/"+seed.ToString(CultureInfo.InvariantCulture);
        internal static string PrefixForGeneration(string geometry,string variants,bool hasVariants,string mode,int seed,int generation)
        {
            if(generation!=MapSplitTopology.GenerationRevision)throw new InvalidDataException("Map generation is retired; regenerate the dungeon.");
            return Prefix(geometry,variants,hasVariants,mode,seed)+"/generation4/catalog4";
        }
    }
}
