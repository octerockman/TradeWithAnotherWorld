using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace BlackAbbeyDungeonMap
{
    // A copied immutable helper descriptor. It is not a replacement for the
    // planned map source: discovery/fingerprint inputs always remain planned.
    internal sealed class MapPresentationBinding
    {
        internal readonly int SchemaVersion;
        internal readonly bool IsSaintSwap;
        internal readonly string InstanceId,PlannedSourceId,PlannedAssetId,PlannedSourceSha256,PlannedManifestSha256;
        internal readonly string PresentationSourceId,PresentationAssetId,PresentationSourceSha256,PresentationManifestSha256;
        internal MapPresentationBinding(int schema,bool swap,string instance,string plannedSource,string plannedAsset,string plannedSha,string plannedManifest,
            string source,string asset,string sha,string manifest)
        {
            SchemaVersion=schema;IsSaintSwap=swap;InstanceId=instance;PlannedSourceId=plannedSource;PlannedAssetId=plannedAsset;
            PlannedSourceSha256=plannedSha;PlannedManifestSha256=plannedManifest;
            PresentationSourceId=source;PresentationAssetId=asset;PresentationSourceSha256=sha;PresentationManifestSha256=manifest;
        }
    }
    internal static class MapPresentationIdentity
    {
        private static string GeometryOnly(Shape shape)=>JsonConvert.SerializeObject(new{shape.enclosure,shape.enclosures,shape.lowY,shape.highY,shape.zones});
        internal static Shape Verify(string instance,string plannedSource,string plannedAsset,Shape planned,IDictionary<string,Shape> measured,
            string loadedSource,string loadedSha,MapPresentationBinding binding)
        {
            if(planned==null||measured==null||planned.sourceId!=plannedAsset)
                throw new InvalidDataException("Missing planned measured map source.");
            if(binding==null)
            {
                if(loadedSource!=plannedSource||loadedSha!=planned.sourceSha256)
                    throw new InvalidDataException("Loaded room differs from the measured map source: "+plannedSource);
                return planned;
            }
            if(binding.SchemaVersion!=1||binding.InstanceId!=instance||binding.PlannedSourceId!=plannedSource||binding.PlannedAssetId!=plannedAsset||
                binding.PlannedSourceSha256!=planned.sourceSha256||binding.PlannedManifestSha256!=planned.manifestSha256||
                loadedSource!=binding.PresentationSourceId||loadedSha!=binding.PresentationSourceSha256||
                !measured.TryGetValue(binding.PresentationAssetId,out var actual)||actual.sourceId!=binding.PresentationAssetId||
                actual.sourceSha256!=binding.PresentationSourceSha256||actual.manifestSha256!=binding.PresentationManifestSha256)
                throw new InvalidDataException("Room presentation differs from its checked logical/measured map identity: "+instance);
            if(binding.IsSaintSwap)
            {
                if(plannedSource!="R03"||plannedAsset!="R03"||binding.PresentationSourceId!="R03_complete"||binding.PresentationAssetId!="R03_complete"||
                    GeometryOnly(planned)!=GeometryOnly(actual))
                    throw new InvalidDataException("Saint map presentation is not the exact equal-geometry intact source pair.");
            }
            else if(binding.PresentationSourceId!=plannedSource||binding.PresentationAssetId!=plannedAsset)
                throw new InvalidDataException("An unmarked room presentation cannot replace a planned map source.");
            return actual;
        }
    }
}
