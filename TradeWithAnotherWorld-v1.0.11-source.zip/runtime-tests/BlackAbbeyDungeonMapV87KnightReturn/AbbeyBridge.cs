using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using BepInEx;
using BepInEx.Bootstrap;
using HarmonyLib;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace BlackAbbeyDungeonMap
{
    // A read-only boundary to the independently versioned Abbey helper.
    // Reflected metadata is cached; no room, enemy, door or run state is written.
    internal sealed class AbbeyBridge
    {
        internal const string HelperId="studio.otherworld.blackabbeyroomtest";
        private readonly BaseUnityPlugin owner;private readonly Type type;
        private readonly Dictionary<string,Shape> shapes;
        private readonly Dictionary<string,double[]> joinFloors;
        private readonly Dictionary<string,MemberInfo> members=new Dictionary<string,MemberInfo>();
        private readonly MethodInfo matches,worldKey,containing,passage,presentationRead;
        private readonly FieldInfo wardingViews;
        private readonly string geometryFingerprint;
        private readonly string variantGeometryFingerprint;
        internal object Plan=>Get(owner,"dungeonPlan");
        internal bool Busy=>(bool)Get(owner,"busy");
        internal Vector3 Origin=>(Vector3)(Get(owner,"gridOrigin")??throw new InvalidOperationException("Missing dungeon origin."));
        internal string LiveRunId=>(string)Get(owner,"naturalRunId");
        internal object Owner=>owner;
        internal Type OwnerType=>type;
        internal bool Alive=>owner&&owner.enabled;
        internal AbbeyBridge()
        {
            if(!Chainloader.PluginInfos.TryGetValue(HelperId,out var info)||!info.Instance)throw new InvalidOperationException("Black Abbey helper is unavailable.");
            owner=info.Instance;type=owner.GetType();
            var presentationType=type.Assembly.GetType("BlackAbbeySixRooms.RoomPresentationIdentity",false);
            if(presentationType!=null)
            {
                var methods=presentationType.GetMethods(BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic)
                    .Where(m=>m.Name=="Read"&&m.GetParameters().Length==4&&m.GetParameters()[0].ParameterType.FullName=="BlackAbbeySixRooms.LoadedRoom"&&
                        m.GetParameters().Skip(1).All(p=>p.ParameterType==typeof(string))).ToArray();
                if(methods.Length!=1)throw new MissingMethodException("Abbey checked room presentation contract differs.");
                presentationRead=methods[0];
            }
            // Optional V47+ render metadata. Older helpers retain normal maps.
            wardingViews=AccessTools.Field(type,"wardingViews");
            matches=AccessTools.Method(type,"Matches",new[]{typeof(Player)});worldKey=AccessTools.Method(type,"WorldKey",Type.EmptyTypes);
            containing=AccessTools.Method(type,"FindContainingRoom");passage=AccessTools.Method(type,"InsideDungeonPassage");
            foreach(string name in new[]{"dungeonPlan","rooms","gridOrigin","busy","naturalRunId"})if(AccessTools.Field(type,name)==null)throw new MissingFieldException(type.FullName,name);
            if(matches==null||worldKey==null||containing==null||passage==null)throw new MissingMethodException("Abbey player/world contract differs.");
            int canonicalRevision;string[] canonicalIds;
            using(var stream=typeof(AbbeyBridge).Assembly.GetManifestResourceStream("BlackAbbeyDungeonMap.map-geometry.json"))
            using(var reader=new StreamReader(stream??throw new InvalidDataException("Missing map geometry resource.")))
            {
                string json=reader.ReadToEnd();geometryFingerprint=MapGeometryIdentity.Fingerprint(json);var catalog=JsonConvert.DeserializeObject<ShapeCatalog>(json);
                if(catalog?.schemaVersion!=1||catalog.rooms?.Length!=11||catalog.joinFloors==null)throw new InvalidDataException("Invalid measured map geometry.");
                canonicalRevision=catalog.catalogRevision;canonicalIds=catalog.rooms.Select(s=>s.sourceId).ToArray();
                shapes=catalog.rooms.ToDictionary(s=>s.sourceId,StringComparer.Ordinal);joinFloors=catalog.joinFloors;
            }
            using(var stream=typeof(AbbeyBridge).Assembly.GetManifestResourceStream("BlackAbbeyDungeonMap.unrecorded-dead-map-geometry.json"))
            using(var reader=new StreamReader(stream??throw new InvalidDataException("Missing alternate-route map geometry.")))
            {
                string json=reader.ReadToEnd();variantGeometryFingerprint=Geometry.Hash(json);
                var variants=JsonConvert.DeserializeObject<ShapeCatalog>(json);
                if(variants?.schemaVersion!=1||variants.rooms?.Length!=4||variants.joinFloors==null)throw new InvalidDataException("Invalid alternate-route map geometry.");
                MapSplitTopology.ValidateCatalog(canonicalRevision,variants.catalogRevision,canonicalIds,variants.rooms.Select(s=>s.sourceId));
                foreach(var shape in variants.rooms)
                {
                    if(!new[]{"R02-UD","R06-UD","R08-UD","R09-A2"}.Contains(shape.sourceId)||shapes.ContainsKey(shape.sourceId))throw new InvalidDataException("Ambiguous alternate map shape.");
                    shapes.Add(shape.sourceId,shape);
                }
                foreach(var row in variants.joinFloors){if(joinFloors.ContainsKey(row.Key))throw new InvalidDataException("Alternate connector replaces a legacy map measurement.");joinFloors.Add(row.Key,row.Value);}
            }
        }
        internal bool Authorized(Player p)=>Alive&&p&&ZNet.instance&&ZNet.instance.IsServer()&&(bool)matches.Invoke(owner,new object[]{p});
        internal bool ProtectWorldAt(Player p)=>Plan!=null&&(containing.Invoke(owner,new object[]{p.transform.position})!=null||(bool)passage.Invoke(owner,new object[]{p.transform.position}));
        internal bool ContainsWorldPoint(Vector3 point)=>Plan!=null&&(containing.Invoke(owner,new object[]{point})!=null||(bool)passage.Invoke(owner,new object[]{point}));
        internal string World=>(string)worldKey.Invoke(null,null);
        internal string PersistentRunId
        {
            get
            {
                // Optional V43+ contract. V42 uses our own stable generation stamp.
                var field=AccessTools.Field(type,"persistentRun");var run=field?.GetValue(owner);
                return run==null?null:Get(run,"runId") as string;
            }
        }
        private object Get(object value,string name)
        {
            if(value==null)return null;string key=value.GetType().FullName+"/"+name;
            if(!members.TryGetValue(key,out var member))
            {
                var flags=BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic;
                member=(MemberInfo)value.GetType().GetField(name,flags)??value.GetType().GetProperty(name,flags);
                if(member==null)throw new MissingMemberException(value.GetType().FullName,name);members.Add(key,member);
            }
            return member is FieldInfo field?field.GetValue(value):((PropertyInfo)member).GetValue(value,null);
        }
        private double Number(object value,string name)=>Convert.ToDouble(Get(value,name),CultureInfo.InvariantCulture);
        private Point PlanPoint(object value)=>new Point(Number(value,"X"),Number(value,"Z"));
        private string Asset(object spec)
        {
            // AssetId is a property on the rebuilt helper. Cache that exact
            // member through Get; AccessTools.Field logs a warning on every
            // frame when asked to find a property as if it were a field.
            string asset=Get(spec,"AssetId") as string;
            return string.IsNullOrEmpty(asset)?(string)Get(spec,"SourceId"):asset;
        }
        private MapPresentationBinding ReadPresentation(object room,string instance,string source,string asset)
        {
            if(presentationRead==null)return null;
            object value=presentationRead.Invoke(null,new[]{room,instance,source,asset});
            if(value==null)throw new InvalidDataException("Helper did not supply its checked room presentation identity.");
            return new MapPresentationBinding((int)Get(value,"SchemaVersion"),(bool)Get(value,"IsSaintSwap"),(string)Get(value,"InstanceId"),
                (string)Get(value,"PlannedSourceId"),(string)Get(value,"PlannedAssetId"),(string)Get(value,"PlannedSourceSha256"),(string)Get(value,"PlannedManifestSha256"),
                (string)Get(value,"PresentationSourceId"),(string)Get(value,"PresentationAssetId"),(string)Get(value,"PresentationSourceSha256"),(string)Get(value,"PresentationManifestSha256"));
        }
        private Point[] Ring(double[][] values,Point position,int q)=>values.Select(v=>position+Point.Rotate(Point.Of(v),q)).ToArray();
        private static int Floor(double elevation)=>(int)Math.Round(elevation/10.8);
        internal Layout ReadLayout(Player player)
        {
            object plan=Plan;if(plan==null)throw new InvalidOperationException("No connected Abbey plan.");
            var result=new Layout{World=World,Character=player.GetPlayerID().ToString(),Seed=(int)Get(plan,"Seed"),Mode=(string)Get(plan,"Mode")};
            var instances=((IEnumerable)Get(plan,"Rooms")).Cast<object>().ToArray();
            var links=((IEnumerable)Get(plan,"Links")).Cast<object>().ToArray();
            int generation=(int)Get(plan,"GenerationRevision");
            MapSplitTopology.ValidateRoomSet(generation,instances.Select(p=>(string)Get(Get(p,"Spec"),"SourceId")));
            MapSplitTopology.ValidateLinkSet(links.Select(l=>Get(l,"Kind") as string));
            var loaded=(IDictionary)Get(owner,"rooms");var doors=new Dictionary<string,Door[]>();
            bool variant=instances.Any(p=>{string asset=Asset(Get(p,"Spec"));return asset.EndsWith("-UD",StringComparison.Ordinal)||asset=="R09-A2";});
            var fingerprint=new StringBuilder(MapLayoutIdentity.PrefixForGeneration(geometryFingerprint,variantGeometryFingerprint,variant,result.Mode,result.Seed,generation));
            var positions=new List<Point>();var elevations=new List<double>();var quarters=new List<int>();var ids=new List<string>();var sources=new List<string>();var verifiedSources=new HashSet<string>();
            for(int i=0;i<instances.Length;i++)
            {
                object placement=instances[i],spec=Get(placement,"Spec");string id=(string)Get(spec,"Id"),source=(string)Get(spec,"SourceId");
                string asset=Asset(spec);
                if(!shapes.TryGetValue(asset,out var shape))throw new InvalidDataException("No measured map shape for "+asset);
                if(!loaded.Contains(id))throw new InvalidDataException("Map source room is not loaded.");
                object room=loaded[id],manifest=Get(room,"Manifest");var root=Get(room,"Root") as GameObject;
                if(!root||!root.activeInHierarchy)throw new InvalidDataException("Measured map room is not active: "+source);
                var presentedShape=MapPresentationIdentity.Verify(id,source,asset,shape,shapes,(string)Get(manifest,"roomId"),(string)Get(manifest,"sourceSha256"),ReadPresentation(room,id,source,asset));
                if(verifiedSources.Add(presentedShape.sourceId))
                {
                    string path=Path.Combine((string)Get(room,"PackageDirectory"),"manifest.json");
                    if(Geometry.Hash(File.ReadAllText(path))!=presentedShape.manifestSha256)
                    {
                        // File hashes use original bytes, including BOM/newlines.
                        using(var stream=File.OpenRead(path))using(var hash=System.Security.Cryptography.SHA256.Create())
                            if(BitConverter.ToString(hash.ComputeHash(stream)).Replace("-","").ToLowerInvariant()!=presentedShape.manifestSha256)throw new InvalidDataException("Room data changed since its map measurements: "+source);
                    }
                }
                Point position=PlanPoint(Get(placement,"Position"));int q=(int)Get(placement,"QuarterTurns");double elevation=Number(placement,"Elevation");
                Vector3 expected=Origin+new Vector3((float)position.X,(float)elevation,(float)position.Z);
                if(Vector3.Distance(root.transform.position,expected)>.015f||Quaternion.Angle(root.transform.rotation,Quaternion.Euler(0,q*90,0))>.02f||Vector3.Distance(root.transform.lossyScale,Vector3.one)>.001f)
                    throw new InvalidDataException("Actual room transform differs from its generated map plan.");
                ids.Add(id);sources.Add(source);positions.Add(position);elevations.Add(elevation);quarters.Add(q);
                fingerprint.Append('|').Append(id).Append(':').Append(shape.sourceSha256).Append(':').Append(q).Append(':')
                    .Append(position.X.ToString("R",CultureInfo.InvariantCulture)).Append(',').Append(position.Z.ToString("R",CultureInfo.InvariantCulture)).Append(',').Append(elevation.ToString("R",CultureInfo.InvariantCulture));
                var sourcePorts=((IEnumerable)Get(spec,"Ports")).Cast<object>().ToArray();
                doors[id]=sourcePorts.Select(port=>
                {
                    var p=(float[])Get(port,"position");var n=(float[])Get(port,"outward");string portId=(string)Get(port,"id");
                    return new Door{Center=position+Point.Rotate(new Point(p[0],p[2]),q),Outward=Point.Rotate(new Point(n[0],n[2]),q),Width=Number(port,"width"),Y=elevation+p[1],
                        Linked=links.Any(l=>((int)Get(l,"A")==i&&(string)Get(Get(l,"PortA"),"id")==portId)||((int)Get(l,"B")==i&&(string)Get(Get(l,"PortB"),"id")==portId))};
                }).ToArray();
                foreach(var enclosure in shape.enclosures??new[]{shape.enclosure})
                    result.Enclosures.Add(new Enclosure{Instance=id,Polygon=Ring(enclosure,position,q),Low=elevation+shape.lowY,High=elevation+shape.highY});
                foreach(var z in shape.zones)
                {
                    var applicable=doors[id].Where(d=>Math.Abs(d.Y-elevation-z.floorOffset)<.2).ToList();
                    foreach(var opening in z.openings??Array.Empty<MapOpeningTemplate>())
                        applicable.Add(new Door{Center=position+Point.Rotate(Point.Of(opening.center),q),Outward=Point.Rotate(Point.Of(opening.outward),q),
                            Width=opening.width,Y=elevation+opening.y,Linked=true,RevealOwner=id+"/"+opening.revealWith});
                    var zone=new Zone{Id=id+"/"+z.id,Instance=id,Source=source,Label=MapSymbols.RoomLabel(id,source,z.label),Floor=Floor(elevation+z.floorOffset),MinY=elevation+z.minY,MaxY=elevation+z.maxY,
                        Outlines=z.outlines.Select(r=>Ring(r,position,q)).ToArray(),Marks=z.marks.Select(r=>Ring(r,position,q)).ToArray(),Reveal=Ring(z.revealPolygon,position,q),
                        RevealHoles=(z.revealHoles??Array.Empty<double[][]>()).Select(r=>Ring(r,position,q)).ToArray(),IconOverride=z.icon,Doors=applicable.ToArray()};
                    if(source=="R01"&&id=="R01")
                    {
                        var entry=(float[])Get(manifest,"entryPosition");zone.Symbol=position+Point.Rotate(new Point(entry[0],entry[2]),q);zone.SymbolKind="entry";
                    }
                    if(z.symbolPosition?.Length==2&&new[]{"up","down"}.Contains(z.symbolKind))
                    {zone.Symbol=position+Point.Rotate(Point.Of(z.symbolPosition),q);zone.SymbolKind=z.symbolKind;}
                    else if(source=="R08"&&zone.Marks.Length>0)
                    {var mark=z.id=="lower"?zone.Marks[0]:zone.Marks[zone.Marks.Length-1];zone.Symbol=(mark[0]+mark[1])*.5;zone.SymbolKind=z.id=="lower"?"up":"down";}
                    result.Zones.Add(zone);
                }
            }
            bool knightSleeve=links.Any(l=>Get(l,"Kind") as string==MapKnightConnectorPolicy.Kind);
            if(knightSleeve)
                MapKnightConnectorPolicy.ValidatePlan(generation,result.Mode,(string)Get(plan,"BossUnlockRoute"),
                    (int)Get(plan,"KnightReturnLoopRevision"),links.Select(l=>Get(l,"Kind") as string),ids,sources,
                    instances.Select(p=>Asset(Get(p,"Spec"))));
            for(int k=0;k<links.Length;k++)
            {
                object link=links[k];int a=(int)Get(link,"A"),b=(int)Get(link,"B");object pa=Get(link,"PortA"),pb=Get(link,"PortB");
                var va=(float[])Get(pa,"position");var vb=(float[])Get(pb,"position");
                Point start=positions[a]+Point.Rotate(new Point(va[0],va[2]),quarters[a]);Point end=positions[b]+Point.Rotate(new Point(vb[0],vb[2]),quarters[b]);
                double length=(end-start).Length;string kind=Get(link,"Kind") as string;
                if(kind==MapKnightConnectorPolicy.Kind)
                {
                    object kit=Get(Get(owner,"extraAssets"),"DoorwayKit"),km=Get(kit,"Manifest");
                    if(!joinFloors.TryGetValue("joined_080_cc",out var canonicalFloor))throw new InvalidDataException("Missing pinned pointed-floor measurement.");
                    var knightNa=(float[])Get(pa,"outward");var knightNb=(float[])Get(pb,"outward");
                    if(Math.Abs(knightNa[1])>.00001||Math.Abs(knightNb[1])>.00001)throw new InvalidDataException("Knight passage normals must be horizontal.");
                    bool ownsA=((IEnumerable)Get(Get(instances[a],"Spec"),"Ports")).Cast<object>().Any(p=>ReferenceEquals(p,pa));
                    bool ownsB=((IEnumerable)Get(Get(instances[b],"Spec"),"Ports")).Cast<object>().Any(p=>ReferenceEquals(p,pb));
                    if(!ownsA||!ownsB)throw new InvalidDataException("Knight passage endpoints are not the actual authored ports.");
                    string knightModule=MapKnightConnectorPolicy.Module(length);
                    result.Links.Add(MapKnightConnectorPolicy.MakeLink((string)Get(km,"roomId"),(string)Get(km,"sourceSha256"),canonicalFloor,
                        ids[a],sources[a],ids[b],sources[b],ids[a]+"/"+(string)Get(pa,"id")+"->"+ids[b]+"/"+(string)Get(pb,"id"),start,end,
                        Point.Rotate(new Point(knightNa[0],knightNa[2]),quarters[a]),Point.Rotate(new Point(knightNb[0],knightNb[2]),quarters[b]),
                        PlanPoint(Get(link,"Start")),PlanPoint(Get(link,"End")),(bool)Get(link,"IsLoop"),
                        new[]{Number(pa,"width"),Number(pa,"height"),Number(pa,"depth"),Number(pa,"springHeight"),Number(pa,"archRise")},
                        new[]{Number(pb,"width"),Number(pb,"height"),Number(pb,"depth"),Number(pb,"springHeight"),Number(pb,"archRise")},
                        Number(link,"Elevation"),elevations[a]+va[1],elevations[b]+vb[1],Floor(Number(link,"Elevation"))));
                    fingerprint.Append("|link:").Append(result.Links.Last().Id).Append(':').Append(knightModule);
                    continue;
                }
                string module=kind==MapSplitTopology.BossThreshold?MapSplitTopology.BossThreshold:
                    "joined_"+Math.Round(length*100).ToString("000",CultureInfo.InvariantCulture)+"_"+(Number(pa,"springHeight")<2.1?"c":"e")+(Number(pb,"springHeight")<2.1?"c":"e");
                double[] measured=null;
                if(kind!=MapSplitTopology.BossThreshold&&!joinFloors.TryGetValue(module,out measured))throw new InvalidDataException("Map connector has no constructed masonry source.");
                double y=Number(link,"Elevation");var na=(float[])Get(pa,"outward");var nb=(float[])Get(pb,"outward");
                if(kind==MapSplitTopology.BossThreshold&&(Math.Abs(na[1])>.001||Math.Abs(nb[1])>.001))throw new InvalidDataException("Internal boss-threshold normals must be horizontal.");
                result.Links.Add(MapSplitTopology.MakeLink(kind,sources[a],sources[b],ids[a]+"/"+(string)Get(pa,"id")+"->"+ids[b]+"/"+(string)Get(pb,"id"),start,end,
                    Point.Rotate(new Point(na[0],na[2]),quarters[a]),Point.Rotate(new Point(nb[0],nb[2]),quarters[b]),Number(pa,"width"),Number(pb,"width"),y,elevations[a]+va[1],elevations[b]+vb[1],Floor(y),measured));
                fingerprint.Append("|link:").Append(result.Links.Last().Id).Append(':').Append(module);
            }
            ReadDoorMarkers(result,loaded,ids,doors,instances,links);
            result.Fingerprint=Geometry.Hash(fingerprint.ToString());return result;
        }
        private void ReadDoorMarkers(Layout layout,IDictionary loaded,List<string> ids,Dictionary<string,Door[]> sourceDoors,object[] placements,object[] links)
        {
            Type doorType=type.Assembly.GetType("BlackAbbeySixRooms.AbbeyDoor",true);var seen=new HashSet<int>();
            string[] Owners(IEnumerable<string> names,int floor)=>layout.Zones.Where(z=>z.Floor==floor&&names.Contains(z.Instance)).Select(z=>z.Id).ToArray();
            void Add(Component component,string id,string[] owners,int floor)
            {
                if(!component||!seen.Add(component.GetInstanceID()))return;
                var left=Get(component,"left") as Transform;var right=Get(component,"right") as Transform;
                if(!left||!right||owners.Length==0)throw new InvalidDataException("Spawned map door has no valid hinge/room ownership.");
                Vector3 center=(left.position+right.position)*.5f-Origin,forward=component.transform.forward;
                layout.Doors.Add(new DoorMark{Id=id,Owners=owners,Center=new Point(center.x,center.z),Outward=new Point(forward.x,forward.z),
                    Width=Vector3.Distance(left.position,right.position),Floor=floor,Barred=(bool)Get(component,"IsBarred"),Exit=(bool)Get(component,"portalExit")});
            }
            foreach(DictionaryEntry pair in (IDictionary)Get(owner,"dungeonDoors"))
            {
                int a=(int)Get(pair.Key,"A"),b=(int)Get(pair.Key,"B"),floor=Floor(Number(pair.Key,"Elevation"));
                int linkIndex=Array.IndexOf(links,pair.Key);if(linkIndex<0)throw new InvalidDataException("Spawned door does not belong to the active plan.");
                Add(pair.Value as Component,"shared/"+layout.Links[linkIndex].Id,Owners(new[]{ids[a],ids[b]},floor),floor);
            }
            foreach(string id in ids)
            {
                object room=loaded[id];var root=Get(room,"Root") as GameObject;
                foreach(var component in root.GetComponentsInChildren(doorType,true))
                {
                    Vector3 local=component.transform.position-Origin;Point p=new Point(local.x,local.z);var ports=sourceDoors[id];
                    var selected=ports.OrderBy(d=>(d.Center-p).Length+Math.Abs(d.Y-local.y)).First();int floor=Floor(selected.Y);
                    Add(component,id+"/port/"+Array.IndexOf(ports,selected),Owners(new[]{id},floor),floor);
                }
                object manifest=Get(room,"Manifest");if(!MapSplitTopology.IsHall((string)Get(manifest,"roomId")))continue;
                string path=Path.Combine((string)Get(room,"PackageDirectory"),(string)Get(manifest,"r09InteractionFile"));
                if(new FileInfo(path).Length>2*1024*1024)throw new InvalidDataException("Boss door map source exceeds its limit.");
                var parts=(JArray)JObject.Parse(File.ReadAllText(path))["parts"];
                var lp=parts.Single(p=>(string)p["id"]=="boss_left")["pivot"].ToObject<float[]>();var rp=parts.Single(p=>(string)p["id"]=="boss_right")["pivot"].ToObject<float[]>();
                var all=root.GetComponentsInChildren<Transform>(true);
                Transform left=all.Single(t=>t.name=="BA_R09 | source pivot | boss_left"),right=all.Single(t=>t.name=="BA_R09 | source pivot | boss_right");
                if(left.parent!=root.transform||right.parent!=root.transform||
                    Vector3.Distance(left.localPosition,new Vector3(lp[0],lp[1],lp[2]))>.015f||Vector3.Distance(right.localPosition,new Vector3(rp[0],rp[1],rp[2]))>.015f)
                    throw new InvalidDataException("Boss door map hinges differ from the selected hall's authored pivots.");
                Vector3 leftBoss=left.position,rightBoss=right.position;
                Vector3 c=(leftBoss+rightBoss)*.5f-Origin,n=root.transform.forward;int bossFloor=Floor(root.transform.position.y-Origin.y);
                object joint=links.Single(l=>(Get(l,"Kind") as string)==MapSplitTopology.BossThreshold&&(ids[(int)Get(l,"A")]==id||ids[(int)Get(l,"B")]==id));
                string[] joinedOwners={ids[(int)Get(joint,"A")],ids[(int)Get(joint,"B")]};
                layout.Doors.Add(new DoorMark{Id=id+"/boss-door",Owners=Owners(joinedOwners,bossFloor),Center=new Point(c.x,c.z),Outward=new Point(n.x,n.z),
                    Width=Vector3.Distance(leftBoss,rightBoss),Floor=bossFloor,Barred=false});
            }
            ReadWardingDoorMarkers(layout,sourceDoors,placements,ids);
        }
        private void ReadWardingDoorMarkers(Layout layout,Dictionary<string,Door[]> sourceDoors,object[] placements,List<string> ids)
        {
            // Selection candidates and unused ports are not evidence that art
            // exists. Read only completed views with their actual live hinges.
            if(wardingViews==null)return;
            IEnumerable views;
            try{views=(wardingViews.GetValue(owner) as IEnumerable)?.Cast<object>().Take(129).ToArray();}
            catch(Exception ex){Debug.LogWarning("Abbey ward doorway map markers unavailable: "+ex.Message);return;}
            if(views==null)return;
            var seen=new HashSet<string>(StringComparer.Ordinal);var rootsSeen=new HashSet<int>();
            bool warned=false;int inspected=0;
            foreach(object view in views)
            {
                if(++inspected>128)
                {if(!warned)Debug.LogWarning("Abbey ward doorway registry exceeds the map room bound; remaining optional markers omitted.");break;}
                if(view==null)continue;
                try
                {
                    object placement=Get(view,"Placement"),art=Get(view,"Art");
                    if(placement==null||art==null)continue;
                    var root=Get(art,"Root") as GameObject;if(!root)continue;
                    string id=(string)Get(placement,"Id"),roomId=(string)Get(placement,"RoomId"),portId=(string)Get(placement,"PortId");
                    int index=(int)Get(placement,"RoomIndex");
                    if(index<0||index>=placements.Length||ids[index]!=roomId||id!=roomId+"/ward/"+portId||!sourceDoors.TryGetValue(roomId,out var roomDoors))
                        throw new InvalidDataException("Spawned ward does not identify its active source room and port.");
                    var spec=Get(placements[index],"Spec");var ports=((IEnumerable)Get(spec,"Ports")).Cast<object>().ToArray();
                    int portIndex=Array.FindIndex(ports,p=>(string)Get(p,"id")==portId);
                    if(portIndex<0||portIndex>=roomDoors.Length||roomDoors[portIndex].Linked)
                        throw new InvalidDataException("Spawned ward does not occupy a real unused source port.");
                    var position=PlanPoint(Get(placement,"Position"));double elevation=Number(placement,"Elevation");int turn=(int)Get(placement,"QuarterTurns");
                    Vector3 expected=Origin+new Vector3((float)position.X,(float)elevation,(float)position.Z);
                    if(Vector3.Distance(root.transform.position,expected)>.02f||Quaternion.Angle(root.transform.rotation,Quaternion.Euler(0,turn*90,0))>.02f||Vector3.Distance(root.transform.lossyScale,Vector3.one)>.001f)
                        throw new InvalidDataException("Spawned ward transform differs from its actual placement.");
                    var motionRoots=Get(art,"motionRoots") as IDictionary;
                    if(motionRoots==null)throw new MissingMemberException("Spawned ward has no hinge registry.");
                    Transform left=null,right=null;
                    foreach(DictionaryEntry motion in motionRoots)
                    {
                        var name=motion.Key as string;
                        if(name?.EndsWith(" | left rear hinge root",StringComparison.Ordinal)==true)left=motion.Value as Transform;
                        if(name?.EndsWith(" | right rear hinge root",StringComparison.Ordinal)==true)right=motion.Value as Transform;
                    }
                    if(!left||!right||!left.IsChildOf(root.transform)||!right.IsChildOf(root.transform))
                        throw new InvalidDataException("Spawned ward's two actual hinge roots are unavailable.");
                    Vector3 center=(left.position+right.position)*.5f-Origin,n=root.transform.forward;
                    float width=Vector3.Distance(left.position,right.position);
                    if(float.IsNaN(width)||float.IsInfinity(width)||width<.25f||width>8||Mathf.Abs(n.y)>.001f)
                        throw new InvalidDataException("Spawned ward hinge width or orientation is invalid.");
                    int floor=Floor(elevation);var owners=layout.Zones.Where(z=>z.Instance==roomId&&z.Floor==floor).Select(z=>z.Id).ToArray();
                    if(owners.Length==0||floor!=Floor(roomDoors[portIndex].Y))throw new InvalidDataException("Spawned ward has no owning map zone on its source floor.");
                    if(!seen.Add(id)||!rootsSeen.Add(root.GetInstanceID()))continue;
                    // Current helper omits ordinary barred doors on ward ports.
                    // Replace only the exact same-port fallback if a compatible
                    // helper retains it; never remove another shared doorway.
                    string fallback=roomId+"/port/"+portIndex;
                    layout.Doors.RemoveAll(d=>d.Id==fallback);
                    layout.Doors.Add(new DoorMark{Id=id,Owners=owners,Center=new Point(center.x,center.z),Outward=new Point(n.x,n.z),Width=width,Floor=floor,Warded=true,Barred=false});
                }
                catch(Exception ex)
                {
                    // Optional marking cannot erase exploration or disable the
                    // base map. Missing/incompatible ward data is never guessed.
                    if(!warned){warned=true;Debug.LogWarning("Abbey ward doorway map marker omitted: "+ex.Message);}
                }
            }
        }
    }
}
