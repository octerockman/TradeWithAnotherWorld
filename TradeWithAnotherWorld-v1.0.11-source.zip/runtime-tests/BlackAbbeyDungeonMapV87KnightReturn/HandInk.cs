using System;
using System.Collections.Generic;

namespace BlackAbbeyDungeonMap
{
    internal readonly struct PenSegment
    {
        internal readonly Point A,B;internal readonly double Width,Opacity;
        internal PenSegment(Point a,Point b,double width,double opacity){A=a;B=b;Width=width;Opacity=opacity;}
    }
    internal static class HandInk
    {
        internal static uint Seed(Point a,Point b)
        {
            unchecked
            {
                uint value=2166136261;
                foreach(long number in new[]{(long)Math.Round(a.X*1000),(long)Math.Round(a.Z*1000),(long)Math.Round(b.X*1000),(long)Math.Round(b.Z*1000)})
                {value=(value^(uint)number)*16777619;value=(value^(uint)(number>>32))*16777619;}
                return value;
            }
        }
        internal static List<PenSegment> Stroke(Point a,Point b,bool fine,uint seed,int hatchSide=0)
        {
            var result=new List<PenSegment>();Point delta=b-a;double length=delta.Length;
            if(length<(fine?.7:.2))return result;
            Point tangent=delta*(1/length),normal=new Point(-tangent.Z,tangent.X);
            int steps=fine?Math.Max(1,Math.Min(128,(int)Math.Ceiling(length/8))):Math.Max(2,Math.Min(768,(int)Math.Ceiling(length/8)));
            double phase=(seed%997)*.017,amplitude=fine?.16:.72;
            Point previous=a;
            for(int i=1;i<=steps;i++)
            {
                double t=i/(double)steps;
                double wobble=Math.Sin(Math.PI*t)*(Math.Sin(phase+t*15)*.64+Math.Sin(phase*1.7+t*31)*.31)*amplitude;
                Point next=i==steps?b:a+delta*t+normal*wobble;
                double pressure=.94+.21*Math.Sin(phase+t*8)+.1*Math.Sin(phase*.7+t*23);
                result.Add(new PenSegment(previous,next,(fine?.9:1.8)*pressure,fine?.66:.92));
                if(!fine&&(i+(seed%5))%4!=0)
                {
                    Point offset=normal*(.9+.18*Math.Sin(phase+t*9));
                    result.Add(new PenSegment(previous+offset,next+offset,.65,.28));
                }
                previous=next;
            }
            if(!fine&&hatchSide!=0&&length>11)
            {
                Point outward=normal*hatchSide;int count=Math.Min(256,(int)(length/8));
                for(int i=0;i<count;i++)
                {
                    double t=(i+.4+Math.Sin(phase+i)*.15)/(count+1);Point start=a+delta*t+outward*1.7;
                    result.Add(new PenSegment(start,start+outward*(3.5+Math.Sin(phase+i*1.3))+tangent*2.3,.65,.38));
                }
            }
            return result;
        }
    }
}
