using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeyDungeonMap
{
    internal readonly struct InkStroke
    {
        internal readonly Point A,B;internal readonly bool Fine,Bold;internal readonly int HatchSide;internal readonly uint Seed;
        internal InkStroke(Point a,Point b,bool fine=false,int hatchSide=0,bool bold=false){A=a;B=b;Fine=fine;HatchSide=hatchSide;Bold=bold;Seed=HandInk.Seed(a,b);}
    }
    internal static class InkPlan
    {
        internal static List<InkStroke> Build(MapState state,int floor)
        {
            var strokes=new List<InkStroke>();
            foreach(var zone in state.Layout.Zones.Where(z=>z.Floor==floor&&state.Zones.Contains(z.Id)))
            {
                for(int r=0;r<zone.Outlines.Length;r++)for(int i=0;i<zone.Outlines[r].Length;i++)
                {
                    var ring=zone.Outlines[r];bool fine=zone.Source=="R08"&&r>0;
                    double area=Enumerable.Range(0,ring.Length).Sum(k=>ring[k].X*ring[(k+1)%ring.Length].Z-ring[(k+1)%ring.Length].X*ring[k].Z);
                    Point a=ring[i],b=ring[(i+1)%ring.Length];
                    var pieces=new List<InkStroke>{new InkStroke(a,b,fine,fine?0:area>0?-1:1)};
                    foreach(var door in zone.Doors)
                    {
                        if(door.RevealOwner!=null&&!state.Zones.Contains(door.RevealOwner))continue;
                        if(Geometry.Distance(door.Center,a,b)>.18)continue;
                        var next=new List<InkStroke>();
                        foreach(var part in pieces)Cut(part,door,next);pieces=next;
                    }
                    strokes.AddRange(pieces);
                }
                foreach(var mark in zone.Marks)if(mark.Length==2)strokes.Add(new InkStroke(mark[0],mark[1],true));
                if(zone.Symbol.HasValue&&zone.SymbolKind!="entry")
                {
                    var p=zone.Symbol.Value;
                    if(zone.SymbolKind=="entry")
                    {
                        strokes.Add(new InkStroke(p+new Point(-.35,-.45),p+new Point(-.35,.45),true));strokes.Add(new InkStroke(p+new Point(.35,-.45),p+new Point(.35,.45),true));
                        strokes.Add(new InkStroke(p+new Point(-.35,.45),p+new Point(.35,.45),true));
                    }
                    else
                    {
                        double direction=zone.SymbolKind=="up"?1:-1;
                        strokes.Add(new InkStroke(p+new Point(-.3,-direction*.25),p+new Point(0,direction*.3),true));strokes.Add(new InkStroke(p+new Point(.3,-direction*.25),p+new Point(0,direction*.3),true));
                    }
                }
            }
            foreach(var link in state.Layout.Links.Where(l=>l.Floor==floor&&state.Links.Contains(l.Id)))
            {
                // The authored boss frame joins the two room outlines directly.
                // It contributes no passage rails and must never divide by zero.
                if(link.IsBossThreshold)continue;
                Point d=link.B-link.A,n=new Point(d.Z,-d.X)*(link.Width/(2*d.Length));
                strokes.Add(new InkStroke(link.A+n,link.B+n,false,-1));strokes.Add(new InkStroke(link.A-n,link.B-n,false,1));
            }
            return strokes;
        }
        private static void Cut(InkStroke stroke,Door door,List<InkStroke> result)
        {
            Point a=stroke.A,b=stroke.B,d=b-a;double length=d.Length;
            if(length<.001)return;
            Point axis=d*(1/length);double center=(door.Center.X-a.X)*axis.X+(door.Center.Z-a.Z)*axis.Z;
            double lo=Math.Max(0,center-door.Width/2),hi=Math.Min(length,center+door.Width/2);
            if(lo>=hi){result.Add(stroke);return;}
            if(lo>.002)result.Add(new InkStroke(a,a+axis*lo,stroke.Fine,stroke.HatchSide));
            if(hi<length-.002)result.Add(new InkStroke(a+axis*hi,b,stroke.Fine,stroke.HatchSide));
        }
    }
}
