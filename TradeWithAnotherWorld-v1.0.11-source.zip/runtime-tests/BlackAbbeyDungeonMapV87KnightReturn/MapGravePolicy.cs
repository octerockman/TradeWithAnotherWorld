using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeyDungeonMap
{
    internal sealed class MapGraveMark
    {
        internal string Id;
        internal Point Position;
        internal int Floor;
    }

    // Coordinates are relative to the run origin. Native scene loading does
    // not enter this policy: a saved native tombstone owns a marker by UID.
    internal static class MapGravePolicy
    {
        internal static bool Finite(Point point, double y)=>
            !double.IsNaN(point.X)&&!double.IsInfinity(point.X)&&
            !double.IsNaN(point.Z)&&!double.IsInfinity(point.Z)&&
            !double.IsNaN(y)&&!double.IsInfinity(y);

        internal static bool TryPlace(Layout layout,Point current,double currentY,bool currentInRun,
            Point original,double originalY,bool originalInRun,out Point position,out int floor)
        {
            position=default;floor=0;
            if(layout==null)return false;
            double y;
            // The native spawn point records the place of death, even when a
            // rigidbody has fallen. Retirement moves both native coordinates
            // outside, so an ejected grave no longer qualifies here.
            if(originalInRun&&Finite(original,originalY)){position=original;y=originalY;}
            else if(currentInRun&&Finite(current,currentY)){position=current;y=currentY;}
            else return false;
            var zone=layout.FindZone(position,y,null);
            floor=zone?.Floor??(int)Math.Round(y/10.8);
            return true;
        }
    }

    // New observations can appear during a scan. Missing IDs are removed only
    // after a complete successful authoritative pass, never a partial/failure.
    internal sealed class MapGraveSet
    {
        internal const int MaximumMarkers=256;
        readonly Dictionary<string,MapGraveMark> known=new Dictionary<string,MapGraveMark>(StringComparer.Ordinal);
        readonly HashSet<string> seen=new HashSet<string>(StringComparer.Ordinal);
        MapGraveMark[] markers=Array.Empty<MapGraveMark>();
        internal IReadOnlyList<MapGraveMark> Markers=>markers;
        internal int Revision{get;private set;}
        internal void Begin()=>seen.Clear();
        internal bool Observe(MapGraveMark mark)
        {
            if(mark==null||string.IsNullOrEmpty(mark.Id)||!MapGravePolicy.Finite(mark.Position,0))return false;
            if(!known.ContainsKey(mark.Id)&&known.Count>=MaximumMarkers)return false;
            seen.Add(mark.Id);
            if(!known.TryGetValue(mark.Id,out var old)||old.Floor!=mark.Floor||old.Position.X!=mark.Position.X||old.Position.Z!=mark.Position.Z)
            {
                known[mark.Id]=new MapGraveMark{Id=mark.Id,Position=mark.Position,Floor=mark.Floor};
                Changed();
            }
            return true;
        }
        internal void Complete()
        {
            bool changed=false;
            foreach(string id in known.Keys.Where(id=>!seen.Contains(id)).ToArray())changed|=known.Remove(id);
            seen.Clear();if(changed)Changed();
        }
        internal void Cancel()=>seen.Clear();
        internal void Clear()
        {
            seen.Clear();if(known.Count==0)return;known.Clear();Changed();
        }
        void Changed(){markers=known.Values.OrderBy(m=>m.Id,StringComparer.Ordinal).ToArray();unchecked{Revision++;}}
    }
}
