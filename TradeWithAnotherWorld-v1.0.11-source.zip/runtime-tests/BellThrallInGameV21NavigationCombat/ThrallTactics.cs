using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbey.BellThrall {
 // Chooses only; SourceMotion still owns complete route playback, contact,
 // heading commitment and the existing network packet. Native AI owns travel.
 public sealed class ThrallTactics:MonoBehaviour {
  public const float SourceMetresPerUnit=.6f*ThrallSizePolicy.Multiplier;
  static readonly MethodInfo HavePath=AccessTools.Method(typeof(BaseAI),"HavePath",new[]{typeof(Vector3)});
  static readonly MethodInfo MoveTo=AccessTools.Method(typeof(BaseAI),"MoveTo",new[]{typeof(float),typeof(Vector3),typeof(float),typeof(bool)});
  static readonly MethodInfo FindPath=AccessTools.Method(typeof(BaseAI),"FindPath",new[]{typeof(Vector3)});
  static readonly FieldInfo LastPathTime=AccessTools.Field(typeof(BaseAI),"m_lastFindPathTime");
  static readonly MethodInfo NativeDoAttack=AccessTools.Method(typeof(MonsterAI),"DoAttack",new[]{typeof(Character),typeof(bool)});
  static readonly MethodInfo NativeTakingOff=AccessTools.Method(typeof(BaseAI),"IsTakingOff",Type.EmptyTypes);
  readonly Dictionary<int,long> cooldownTicks=new Dictionary<int,long>();
  readonly Dictionary<int,float> cooldowns=new Dictionary<int,float>();
  Humanoid human;MonsterAI ai;ZNetView view;ThrallSourceMotion motion;ThrallCombat combat;
  long historyOwner;int sequence,lastAct;string lastRoute="",reason="not ready";
  uint identity;float spacingReady,spacingExpires,stepUntil,nextPathCheck;bool pendingSpacing,pendingDistantHit,inNativeUpdate,nativePriority,hadStep;
  Vector3 stepDestination;long nextSpacing,nextDistantStep;int decisions,approaches,steps,attackOpportunities,attackRequests,attackStarts,pathRejects,navigateRequests;float nextGateLog;
  static long Now=>ThrallAudio.Now;
  bool Own=>human&&!human.IsDead()&&human.GetHealth()>0&&view&&view.IsValid()&&view.IsOwner();
  public bool Positioning=>Own&&Time.time<stepUntil;
  void Awake(){human=GetComponent<Humanoid>();ai=GetComponent<MonsterAI>();view=GetComponent<ZNetView>();motion=GetComponent<ThrallSourceMotion>();combat=GetComponent<ThrallCombat>();}
  void OnDisable(){pendingSpacing=pendingDistantHit=false;if(Own&&hadStep)EndStep();stepUntil=0;}
  void RefreshHistory(){
   if(!Own)return;long current=view.GetZDO().GetOwner();if(current==historyOwner&&view.GetZDO().GetInt("bt_tactics_seq",0)==sequence)return;
   historyOwner=current;var z=view.GetZDO();identity=unchecked((uint)z.m_uid.ToString().GetStableHashCode());
   sequence=z.GetInt("bt_tactics_seq",0);lastAct=z.GetInt("bt_tactics_act",0);lastRoute=z.GetString("bt_tactics_route","");
   cooldownTicks.Clear();for(int key=3000;key<=3036;key++){long until=z.GetLong("bt_tactics_cd_"+key,0);if(until>Now)cooldownTicks[key]=until;}
   nextSpacing=z.GetLong("bt_tactics_space",0);nextDistantStep=z.GetLong("bt_tactics_distant",0);
   // A new owner never replays a previous owner's positioning or decision.
   pendingSpacing=pendingDistantHit=false;stepUntil=0;
  }
  ThrallTacticsSnapshot Snapshot(){
   RefreshHistory();var target=ai?ai.GetTargetCreature():null;bool valid=target&&!target.IsDead()&&!target.InGhostMode()&&BaseAI.IsEnemy(human,target);
   Vector3 offset=valid?Vector3.ProjectOnPlane(target.transform.position-transform.position,Vector3.up):Vector3.zero;
   cooldowns.Clear();foreach(var row in cooldownTicks)cooldowns[row.Key]=Time.time+(float)Math.Max(0,(row.Value-Now)/10000000d);
   return new ThrallTacticsSnapshot{Owner=Own,Alive=human&&!human.IsDead()&&human.GetHealth()>0,TargetValid=valid&&Mathf.Abs(target.transform.position.y-transform.position.y)<1.5f,
    Visible=valid&&ai.CanSeeTarget(target),Grounded=human&&human.IsOnGround(),Staggered=human&&human.IsStaggering(),Blocking=!motion||!motion.Ready||motion.Blocking||combat&&combat.BellActive,
    DistanceMetres=offset.magnitude,BearingDegrees=offset.sqrMagnitude>.0001f?Vector3.SignedAngle(transform.forward,offset,Vector3.up):0,
    HealthFraction=human?Mathf.Clamp01(human.GetHealth()/Mathf.Max(1,human.GetMaxHealth())):0,NowSeconds=Time.time,SourceMetresPerUnit=SourceMetresPerUnit,
    Seed=identity^unchecked((uint)sequence*0x9e3779b9u),LastAct=lastAct,LastRoute=lastRoute,CooldownUntil=cooldowns,SecondaryWeightScale=.30f,AllowHeldReleaseAdaptation=true};
  }
  static IEnumerable<ThrallTacticsRoute> Routes(IEnumerable<ThrallMotionDescriptor> available){
   foreach(var d in available){float reach=ThrallTacticsReachData.Maximum(d.id);if(reach>0)yield return new ThrallTacticsRoute{Id=d.id,Ready=true,MinDistanceMetres=0,MaxDistanceMetres=reach,MaxBearingDegrees=80};}
  }
  public ThrallTacticsDecision Choose(IEnumerable<ThrallMotionDescriptor> available){
   var s=Snapshot();if(Positioning)s.Blocking=true;
   var decision=ThrallTacticsPolicy.Decide(s,Routes(available));reason=decision.Reason;return decision;
  }
  public void Commit(ThrallTacticsCandidate candidate){
   if(!Own||candidate==null)return;RefreshHistory();var z=view.GetZDO();sequence=unchecked(sequence+1);lastAct=candidate.CooldownKey;lastRoute=candidate.RouteId;
   z.Set("bt_tactics_seq",sequence);z.Set("bt_tactics_act",lastAct);z.Set("bt_tactics_route",lastRoute);
   if(candidate.CooldownSeconds>0){long until=Now+(long)(candidate.CooldownSeconds*10000000d);cooldownTicks[lastAct]=until;z.Set("bt_tactics_cd_"+lastAct,until);}
   pendingSpacing=pendingDistantHit=false;if(hadStep)EndStep();stepUntil=0;decisions++;
   ThrallSourceMotion.Log?.Invoke("BT_AI_ATTACK route="+lastRoute+" sourceGoal="+candidate.SourceGoal+" act="+candidate.SourceAct+" command="+candidate.SourceCommand+" cooldown="+candidate.CooldownSeconds+" adapted="+candidate.Adapted);
  }
  public void RouteFinished(float recovery){
   if(!Own)return;RefreshHistory();pendingSpacing=true;spacingReady=Time.time+Mathf.Max(ThrallCombatPolicy.Recovery,recovery);spacingExpires=spacingReady+2f;
  }
  public void ConfirmRangedHit(HitData hit,float before){
   if(hit!=null&&hit.m_ranged&&Own&&before>human.GetHealth())DistantHit(before-human.GetHealth(),hit.GetAttacker());
  }
  void DistantHit(float damage,Character attacker){
   // A confirmed damaging ranged hit is only a deferred navigation suggestion.
   // It does not infer an incoming projectile, interrupt a swing or grant dodge frames.
   if(!Own||damage<=0||!attacker||attacker!=ai.GetTargetCreature()||Vector3.Distance(attacker.transform.position,transform.position)<=5*SourceMetresPerUnit)return;
   RefreshHistory();if(Now<nextDistantStep)return;pendingDistantHit=true;spacingReady=Mathf.Max(spacingReady,Time.time+ThrallCombatPolicy.Recovery);spacingExpires=Time.time+8f;
  }
  public void BeginNativeUpdate(){inNativeUpdate=true;nativePriority=false;}
  public void ObserveNativePriority(){if(inNativeUpdate)nativePriority=true;}
  public void AfterNativeUpdate(float dt){
   inNativeUpdate=false;
   if(!Own){historyOwner=0;stepUntil=0;hadStep=false;pendingSpacing=pendingDistantHit=false;return;}
   if(hadStep&&!Positioning)EndStep();
   if(!ai||!motion||!combat||ai.IsSleeping()||!ai.IsAlerted()||human.InAttack()||nativePriority){if(hadStep)EndStep();return;}
   var s=Snapshot();if(!s.TargetValid||!s.Visible||!s.Grounded||s.Staggered||s.Blocking){if(hadStep)EndStep();Gate("snapshot target="+s.TargetValid+" visible="+s.Visible+" grounded="+s.Grounded+" staggered="+s.Staggered+" blocking="+s.Blocking);return;}
   if(Positioning){
    if(Vector3.ProjectOnPlane(stepDestination-transform.position,Vector3.up).sqrMagnitude<.01f){EndStep();return;}
    if(Time.time>=nextPathCheck){nextPathCheck=Time.time+.2f;if(!SafeDestination(stepDestination)){EndStep();return;}}
    Navigate(dt,stepDestination,false);return;
   }
   if(Time.time>=spacingReady&&Time.time<=spacingExpires&&(pendingDistantHit||pendingSpacing)){
    var suggestion=pendingDistantHit&&Now>=nextDistantStep?ThrallTacticsPolicy.AfterRangedHit(s):Now>=nextSpacing?ThrallTacticsPolicy.AfterAction(s):null;
    bool distant=pendingDistantHit;pendingDistantHit=pendingSpacing=false;
    if(suggestion!=null&&suggestion.Kind==ThrallTacticsKind.Reposition&&BeginStep(s,suggestion)){
     if(distant){nextDistantStep=Now+(3+(s.Seed%6))*10000000L;view.GetZDO().Set("bt_tactics_distant",nextDistantStep);}
     else {nextSpacing=Now+100000000L;view.GetZDO().Set("bt_tactics_space",nextSpacing);}Navigate(dt,stepDestination,false);return;
    }
   }
   // Source routes and the two native log items have different range
   // conventions. A legal source attack must not depend on the legacy item
   // entering its narrower native in-range branch. Keep native dispatch and
   // all native readiness/facing/item gates, rather than start playback here.
   var choice=Choose(motion.TacticalDescriptors());
   if(choice.Kind==ThrallTacticsKind.Attack){TryNativeAttack();return;}
   // Preserve native fleeing and active travel; only correct an idle gap.
   if(human.GetMoveDir().sqrMagnitude>.0001f)return;
   if(choice.Kind==ThrallTacticsKind.Face){ai.LookTowards(Vector3.ProjectOnPlane(ai.GetTargetCreature().transform.position-transform.position,Vector3.up));return;}
   if(choice.Kind==ThrallTacticsKind.Approach&&s.DistanceMetres>ThrallSizePolicy.World(1f)){var point=ai.GetTargetCreature().transform.position;if(PathExists(point)){Navigate(dt,point,true);approaches++;}}
  }
  void TryNativeAttack(){
   attackOpportunities++;
   if(!Own||!combat.CanStartMelee||human.InAttack()){Gate("source/native action or recovery still busy");return;}
   var target=ai.GetTargetCreature();var item=human.GetCurrentWeapon();
   if(!target||target.IsDead()||target.InGhostMode()||!BaseAI.IsEnemy(human,target)||item?.m_shared==null){Gate("native target or weapon unavailable");return;}
   if(NativeDoAttack==null||NativeTakingOff==null){Gate("native dispatch API unavailable");return;}
   try{
    bool takingOff=(bool)NativeTakingOff.Invoke(ai,null);
    if(!ThrallNativeAttackPolicy.Ready(Time.time,item.m_lastAttackTime,item.m_shared.m_aiAttackInterval,human.GetTimeSinceLastAttack(),ai.m_minAttackInterval,takingOff)){Gate("native attack interval or taking-off gate");return;}
    if(!ai.CanUseAttack(item)){Gate("native item restrictions");return;}
    ai.LookTowards(Vector3.ProjectOnPlane(target.transform.position-transform.position,Vector3.up));
    if(!ai.IsLookingAt(target.transform.position,item.m_shared.m_aiAttackMaxAngle,item.m_shared.m_aiInvertAngleCheck)){Gate("native attack facing");return;}
    attackRequests++;bool started=(bool)NativeDoAttack.Invoke(ai,new object[]{target,false});
    if(started&&motion.SourceAttackActive){attackStarts++;reason="native dispatch started legal source route";}
    else Gate(started?"native start did not commit source route":"native StartAttack or prepared route refused");
   }catch(Exception e){Gate("native attack unavailable: "+e.GetBaseException().Message);}
  }
  void Gate(string value){reason=value;if(!Own||Time.time<nextGateLog)return;nextGateLog=Time.time+3;ThrallSourceMotion.Log?.Invoke("BT_AI_GATE reason="+value+" attackOpportunities="+attackOpportunities+" attackRequests="+attackRequests+" attackStarts="+attackStarts+" pathRejects="+pathRejects);}
  bool BeginStep(ThrallTacticsSnapshot s,ThrallTacticsDecision suggestion){
   var target=ai.GetTargetCreature();if(!target)return false;
   Vector3 toward=Vector3.ProjectOnPlane(target.transform.position-transform.position,Vector3.up).normalized;
   Vector3 side=Vector3.Cross(Vector3.up,toward);Vector3 direction=suggestion.Side==ThrallTacticsSide.Retreat?-toward:suggestion.Side==ThrallTacticsSide.Left?-side:side;
   // Native walking MoveTo stops within0.5m. Put its path endpoint beyond
   // that tolerance so the requested small displacement can actually happen.
   float length=Mathf.Clamp(suggestion.SuggestedDistanceMetres+.5f,.75f,1.2f);var point=transform.position+direction*length;
   if(!SafeDestination(point)||!FreshPath(point))return false;stepDestination=point;stepUntil=Time.time+Mathf.Clamp(suggestion.SuggestedSeconds,.2f,.9f);hadStep=true;nextPathCheck=Time.time+.2f;steps++;
   ThrallSourceMotion.Log?.Invoke("BT_AI_STEP side="+suggestion.Side+" metres="+length+" reason="+suggestion.Reason);return true;
  }
  bool SafeDestination(Vector3 point){
   // Path existence is checked independently: native MoveTo also returns true
   // on path failure. Short steps require nearby supporting floor as well.
   if(!Physics.Raycast(point+Vector3.up*.7f,Vector3.down,out var floor,1.4f,ThrallCombat.SolidMask,QueryTriggerInteraction.Ignore)||Mathf.Abs(floor.point.y-transform.position.y)>.5f)return false;
   return PathExists(point);
  }
  bool PathExists(Vector3 point){try{bool found=HavePath!=null&&(bool)HavePath.Invoke(ai,new object[]{point});if(!found){pathRejects++;Gate("native path not reachable");}return found;}catch(Exception e){pathRejects++;Gate("native path unavailable: "+e.GetBaseException().Message);return false;}}
  bool FreshPath(Vector3 point){try{if(LastPathTime==null||FindPath==null)return false;LastPathTime.SetValue(ai,Time.time-6f);bool found=(bool)FindPath.Invoke(ai,new object[]{point});if(!found)LastPathTime.SetValue(ai,Time.time-6f);return found;}catch{if(LastPathTime!=null)LastPathTime.SetValue(ai,Time.time-6f);return false;}}
  void EndStep(){stepUntil=0;hadStep=false;if(LastPathTime!=null)LastPathTime.SetValue(ai,Time.time-6f);}
  void Navigate(float dt,Vector3 point,bool run){try{if(MoveTo!=null){navigateRequests++;MoveTo.Invoke(ai,new object[]{Mathf.Clamp(dt,.001f,.1f),point,.1f,run});}else Gate("native MoveTo API unavailable");}catch(Exception e){stepUntil=0;Gate("native movement unavailable: "+e.GetBaseException().Message);}}
  public string Diagnostics()=>" aiDecision="+reason+" aiAttacks="+decisions+" aiApproaches="+approaches+" aiSteps="+steps+" aiLast="+lastRoute+" attackOpportunities="+attackOpportunities+" attackRequests="+attackRequests+" attackStarts="+attackStarts+" pathRejects="+pathRejects+" navigateRequests="+navigateRequests;
 }
}
