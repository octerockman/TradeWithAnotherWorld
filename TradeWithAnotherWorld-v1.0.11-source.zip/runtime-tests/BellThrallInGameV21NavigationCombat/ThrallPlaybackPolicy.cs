using System;

namespace BlackAbbey.BellThrall {
 public sealed class ThrallLocomotionDistanceProfile {public float[] times,distance;}
 public static class ThrallLocomotionDistance {
  public static void Validate(ThrallMotionDescriptor d){
   var p=d.locomotionDistance;if(p==null)return;
   if(d.category!="WalkRun"||p.times==null||p.times.Length<2||p.times.Length>2000||p.distance?.Length!=p.times.Length)throw new ArgumentException("Invalid gait-distance arrays");
   if(Math.Abs(p.times[0])>.00001f||Math.Abs(p.distance[0])>.00001f||Math.Abs(p.times[p.times.Length-1]-d.duration)>.0001f||Math.Abs(p.distance[p.distance.Length-1]-d.strideDistance)>.0002f||d.strideDistance<.01f)throw new ArgumentException("Gait-distance endpoints differ");
   for(int i=0;i<p.times.Length;i++)if(!ThrallMotionPolicy.Finite(p.times[i])||!ThrallMotionPolicy.Finite(p.distance[i])||p.times[i]<0||p.distance[i]<0||(i>0&&(p.times[i]<=p.times[i-1]||p.distance[i]<p.distance[i-1])))throw new ArgumentException("Nonmonotonic gait-distance profile");
  }
  public static double DistanceAtTime(ThrallLocomotionDistanceProfile p,float time){
   if(p?.times==null)return 0;
   float at=ThrallMotionPolicy.Clamp(time,p.times[0],p.times[p.times.Length-1]);int a=ThrallMotionPolicy.LowerFrame(p.times,at),b=Math.Min(a+1,p.times.Length-1);double f=a==b?0:(double)(at-p.times[a])/(p.times[b]-p.times[a]);return p.distance[a]+(p.distance[b]-p.distance[a])*f;
  }
  public static float TimeAtDistance(ThrallLocomotionDistanceProfile p,double distance){
   if(p?.distance==null||distance<=0)return 0;
   int last=p.distance.Length-1;if(distance>=p.distance[last])return p.times[last];
   int lo=0,hi=last;while(lo<hi){int mid=(lo+hi+1)/2;if(p.distance[mid]<=distance)lo=mid;else hi=mid-1;}
   // A genuinely flat root segment has no unique inverse. Choose its last
   // coincident time, without inventing spatial travel or dividing by zero.
   int next=Math.Min(lo+1,last);double span=p.distance[next]-p.distance[lo];
   return span<=0?p.times[next]:(float)(p.times[lo]+(p.times[next]-p.times[lo])*(distance-p.distance[lo])/span);
  }
 }
 // Render-frame presentation follows native physical velocity and observed
 // travel. Physics/network transform pulses are not animation state changes.
 public sealed class ThrallLocomotionPlayback {
  public string ClipId {get;private set;}="a000_000020";
  public float Forward {get;private set;}
  public float Right {get;private set;}
  public float Speed {get;private set;}
  public float DistanceStep {get;private set;}
  public float DistanceDebt {get;private set;}
  public bool Moving {get;private set;}
  public int StateChanges {get;private set;}
  float stoppedFor;

  public void Reset(){ClipId="a000_000020";Forward=Right=Speed=DistanceStep=DistanceDebt=stoppedFor=0;Moving=false;StateChanges=0;}
  public void Update(float forward,float right,float observedTravel,float walkSpeed,float dt){
   DistanceStep=0;
   if(!ThrallMotionPolicy.Finite(dt)||dt<=0)return;
   if(!ThrallMotionPolicy.Finite(observedTravel)||observedTravel<0||observedTravel>3||dt>.25f){
    // A teleport or long pause must not turn into a burst of foot cycles.
    Forward=Right=Speed=DistanceDebt=stoppedFor=0;Moving=false;Select("a000_000020");return;
   }
   if(!ThrallMotionPolicy.Finite(forward)||!ThrallMotionPolicy.Finite(right)){forward=right=0;}
   float physicalSpeed=(float)Math.Sqrt(forward*forward+right*right);
   if(physicalSpeed>20){forward=right=physicalSpeed=0;}
   float alpha=ThrallPlaybackPolicy.Smoothing(dt,physicalSpeed<.04f?.035f:.06f);
   Forward+=(forward-Forward)*alpha;Right+=(right-Right)*alpha;
   Speed=(float)Math.Sqrt(Forward*Forward+Right*Right);
   stoppedFor=physicalSpeed<.04f?stoppedFor+dt:0;
   if(!Moving){if(physicalSpeed>=.12f)Moving=true;}
   else if(stoppedFor>=.10f){Moving=false;Forward=Right=Speed=0;}

   DistanceDebt+=observedTravel;
   // Velocity presents motion between physics ticks. Reconcile against real
   // horizontal distance, with a strict60ms+15mm maximum extrapolation lead.
   // With zero physical velocity only15mm of residual lead is possible.
   float lead=physicalSpeed*.06f+.015f;
   float correction=ThrallMotionPolicy.Clamp(DistanceDebt*8f,-physicalSpeed*.5f,physicalSpeed*.5f);
   float requested=Math.Max(0,(physicalSpeed+correction)*dt);
   DistanceStep=Math.Min(requested,Math.Max(0,DistanceDebt+lead));
   DistanceDebt-=DistanceStep;
   if(!Moving){DistanceStep=0;DistanceDebt=0;Select("a000_000020");return;}
   if(physicalSpeed<.04f)return; // Keep one stopped pose until the single idle transition.
   if(!ThrallMotionPolicy.Finite(walkSpeed)||walkSpeed<=.01f)walkSpeed=1.5f;
   Select(SelectGait(Forward,Right,Speed,walkSpeed,ClipId));
  }
  void Select(string id){if(id!=ClipId){ClipId=id;StateChanges++;}}
  static string SelectGait(float forward,float right,float speed,float walkSpeed,string previous){
   bool strafe=previous=="a000_002002"||previous=="a000_002003";
   float lateral=Math.Abs(right),longitudinal=Math.Abs(forward);
   if(lateral>Math.Max(.10f,longitudinal*(strafe?.95f:1.4f)))return right<0?"a000_002002":"a000_002003";
   if(forward<(previous=="a000_002001"?-.04f:-.14f))return "a000_002001";
   float runEnter=Math.Max(1.8f,walkSpeed*1.65f),runExit=Math.Max(1.5f,walkSpeed*1.35f);
   if(speed>(previous=="a000_002100"?runExit:runEnter))return "a000_002100";
   float fastWalk=walkSpeed*(previous=="a000_002000"?.76f:.94f);
   return speed>fastWalk?"a000_002000":"a000_002300";
  }
 }

 public static class ThrallPlaybackPolicy {
  public const float TrackingCommitLead=.16f;
  public static float Smoothing(float dt,float seconds)=>1f-(float)Math.Exp(-Math.Max(0,dt)/Math.Max(.001f,seconds));
  public static float TrackingCommit(float from,float to,ThrallMotionWindow[] windows){
   float commit=float.PositiveInfinity;
   foreach(var window in windows??Array.Empty<ThrallMotionWindow>()){
    if(window==null||window.end<from||window.start>to)continue;
    commit=Math.Min(commit,Math.Max(from,window.start-TrackingCommitLead));
   }
   return commit;
  }
  public static float ComboTurnSpeed(float original){if(!ThrallMotionPolicy.Finite(original)||original<=0)return original;return Math.Max(original,Math.Min(300f,Math.Max(180f,original*2.5f)));}
  public static float TrackingTurnSpeed(float original,bool running){
   if(!ThrallMotionPolicy.Finite(original)||original<=0)return original;
   return Math.Max(original,Math.Min(running?240f:180f,Math.Max(running?120f:90f,original*1.5f)));
  }
 }
}
