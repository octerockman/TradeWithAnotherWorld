using System;
namespace BlackAbbey.BellThrall {
 public sealed class ThrallAttackAdvanceProfile {
  public bool eligible;
  public string sourceProfileId,classification;public string[] eligibilityReasons;
  public float[] times,right,forward;
 }
 public struct ThrallAttackTravelStep {public float Right,Forward;public float Length=>(float)Math.Sqrt(Right*Right+Forward*Forward);}
 public struct ThrallAttackTravelSegment {public ThrallAttackAdvanceProfile Profile;public float From,To;}
 public static class ThrallAttackTravelPolicy {
  public const float RouteDistance=3f,MaximumSpeed=2.8f,LateralDistance=.35f;
  // Normalize the COMPLETE declared route before its first physics sample.
  // Earlier swings cannot consume the terminal swing's share. The record-high
  // forward envelope matches Consume; all raw lateral demand is conservative.
  public static float RouteGain(System.Collections.Generic.IEnumerable<ThrallAttackTravelSegment> route){
   double demand=0;
   foreach(var s in route){var p=s.Profile;if(p==null||!p.eligible||p.times==null||s.To<=s.From)continue;
    var previous=Sample(p,s.From);float first=previous.Forward,furthest=first;double side=0;
    foreach(float t in p.times){if(t<=s.From||t>=s.To)continue;var current=Sample(p,t);furthest=Math.Max(furthest,current.Forward);side+=Math.Abs(current.Right-previous.Right);previous=current;}
    var end=Sample(p,s.To);furthest=Math.Max(furthest,end.Forward);side+=Math.Abs(end.Right-previous.Right);demand+=Math.Max(0,furthest-first)+side;
   }
   return demand>RouteDistance?(float)(RouteDistance/demand):1f;
  }
  public static void Validate(ThrallMotionDescriptor descriptor){
   var p=descriptor.attackAdvance;if(p==null)return;
   if(p.eligible&&(!ThrallMotionPolicy.CombatReady(descriptor)||ThrallMotionPolicy.IsRaised(descriptor.id)))throw new ArgumentException("Advance profile is not an admitted grounded attack");
   if(p.times==null){if(p.eligible)throw new ArgumentException("Eligible advance profile has no samples");return;}
   if(p.times.Length<2||p.times.Length>2000||p.right?.Length!=p.times.Length||p.forward?.Length!=p.times.Length)throw new ArgumentException("Advance profile arrays differ");
   if(Math.Abs(p.times[0])>.00001f||Math.Abs(p.times[p.times.Length-1]-descriptor.duration)>.0001f)throw new ArgumentException("Advance profile does not cover source duration");
   for(int i=0;i<p.times.Length;i++)if(!ThrallMotionPolicy.Finite(p.times[i])||!ThrallMotionPolicy.Finite(p.right[i])||!ThrallMotionPolicy.Finite(p.forward[i])||p.times[i]<0||p.times[i]>descriptor.duration+.0001f||(i>0&&p.times[i]<=p.times[i-1])||Math.Abs(p.right[i])>200||Math.Abs(p.forward[i])>200)throw new ArgumentException("Invalid source advance sample");
  }
  public static ThrallAttackTravelStep Sample(ThrallAttackAdvanceProfile p,float time){
   if(p?.times==null||p.times.Length<2)return default;
   float t=ThrallMotionPolicy.Clamp(time,p.times[0],p.times[p.times.Length-1]);int a=ThrallMotionPolicy.LowerFrame(p.times,t),b=Math.Min(a+1,p.times.Length-1);float f=a==b?0:(t-p.times[a])/(p.times[b]-p.times[a]);
   return new ThrallAttackTravelStep{Right=p.right[a]+(p.right[b]-p.right[a])*f,Forward=p.forward[a]+(p.forward[b]-p.forward[a])*f};
  }
 }
 // This clock consumes source time even when the physical step is blocked.
 // Recoil never creates a second forward lunge and no skipped delta is queued.
 public sealed class ThrallAttackTravelClock {
  int route=-1,packet=-1;float previousTime,furthestForward;
  public float UsedDistance {get;private set;}
  public float UsedLateral {get;private set;}
  public void Reset(){route=packet=-1;previousTime=furthestForward=UsedDistance=UsedLateral=0;}
  void Route(int serial){if(route==serial)return;route=serial;packet=-1;UsedDistance=UsedLateral=0;}
  public void Seed(int routeSerial,int packetSerial,float at,ThrallAttackAdvanceProfile profile){Route(routeSerial);packet=packetSerial;previousTime=at;furthestForward=ThrallAttackTravelPolicy.Sample(profile,at).Forward;}
  public ThrallAttackTravelStep Consume(int routeSerial,int packetSerial,float from,float at,ThrallAttackAdvanceProfile profile,float dt,bool seedOnly=false,float routeGain=1){
   Route(routeSerial);
   if(packet!=packetSerial){packet=packetSerial;previousTime=from;furthestForward=ThrallAttackTravelPolicy.Sample(profile,from).Forward;}
   if(!ThrallMotionPolicy.Finite(at)||at<previousTime)return default;
   if(profile==null||!profile.eligible||seedOnly||!ThrallMotionPolicy.Finite(dt)||dt<=0||dt>.1f||!ThrallMotionPolicy.Finite(routeGain)||routeGain<=0||routeGain>1){Seed(routeSerial,packetSerial,at,profile);return default;}
   var before=ThrallAttackTravelPolicy.Sample(profile,previousTime);var current=ThrallAttackTravelPolicy.Sample(profile,at);previousTime=at;
   float ahead=Math.Max(0,current.Forward-furthestForward)*routeGain;furthestForward=Math.Max(furthestForward,current.Forward);
   float side=ThrallMotionPolicy.Clamp((current.Right-before.Right)*routeGain,-Math.Max(0,ThrallAttackTravelPolicy.LateralDistance-UsedLateral),Math.Max(0,ThrallAttackTravelPolicy.LateralDistance-UsedLateral));
   var step=new ThrallAttackTravelStep{Right=side,Forward=ahead};float length=step.Length;
   float allowed=Math.Min(ThrallAttackTravelPolicy.MaximumSpeed*dt,Math.Max(0,ThrallAttackTravelPolicy.RouteDistance-UsedDistance));
   if(length>allowed&&length>0){float scale=allowed/length;step.Right*=scale;step.Forward*=scale;}
   UsedDistance+=step.Length;UsedLateral+=Math.Abs(step.Right);return step;
  }
 }
}
