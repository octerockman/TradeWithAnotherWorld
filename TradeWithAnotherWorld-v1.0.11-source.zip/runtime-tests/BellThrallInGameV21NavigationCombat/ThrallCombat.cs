using System;using System.Linq;using System.Collections.Generic;using UnityEngine;using Object=UnityEngine.Object;
namespace BlackAbbey.BellThrall {
 [DefaultExecutionOrder(950)]
 public sealed class ThrallCombat:MonoBehaviour {
  public static BellMotionBank BellBank;public static ThrallBellVariants BellVariants;public static ThrallHeadShape HeadShape;public static ThrallWeaponShape[] WeaponShapes;public static Action<string> Log;
  public static readonly Dictionary<string,float> MeasuredRanges=new Dictionary<string,float>();
  public static int SolidMask=>LayerMask.GetMask("Default","static_solid","Default_small","piece","terrain","vehicle");
  static int HitMask=>SolidMask|LayerMask.GetMask("character","character_net","character_noenv","character_ghost","piece_nonsolid");
  Humanoid humanoid;MonsterAI ai;ZNetView view;Animator animator;ThrallSourceMotion motion;Transform head;TrailRenderer trail;AudioSource swish;Dictionary<string,Transform> named;int heardAttackSerial;float sourceRecovery=ThrallCombatPolicy.Recovery;
  int strikeRoute=-1,strikePacket=-1,strikeArc=-1,cachedStrikePacket=-1,physicalStrikes;ThrallMotionWindow[] physicalGroups=Array.Empty<ThrallMotionWindow>();
  ItemDrop.ItemData weapon;Attack attack;bool melee,entered,whooshed,blocked,windowWas;float began,nextMelee,nextBell,savedSpeed=1;long seenPulse;readonly ThrallHitLedger hitTargets=new ThrallHitLedger();readonly ThrallSweepQuery sweepQuery=new ThrallSweepQuery();
  Vector3 previousHead,previousActor;Quaternion previousRotation;readonly Collider[] overlaps=new Collider[128];readonly RaycastHit[] casts=new RaycastHit[128];
  Transform[] weaponParts;Vector3[] previousParts;Quaternion[] previousPartRotations;int swingHitStart,solidStops;string lastSolid="";
  public int swings,hits,rings,cancellations,nativeTriggers;public string lastClip="";public float lastPhase,releasePhase,peakHeadSpeed;
  readonly ThrallBellEpisodeGate bellGate=new ThrallBellEpisodeGate();string bellText;ThrallBellEpisode bellEpisode;bool bellValid;long bellEnabledAt;
  ThrallBellEpisode CurrentBell {get{
   if(!view||!view.IsValid())return default;var z=view.GetZDO();string text=z.GetString(ThrallBellVariantPolicy.StateKey,"");
   if(string.IsNullOrEmpty(text)){long oldStart=z.GetLong("bt_bell_start",0);return new ThrallBellEpisode(0,oldStart,0,z.GetInt("bt_bell_sequence",0)==0&&oldStart<bellEnabledAt&&z.GetInt("bt_bell_active",0)!=0);}
   if(text!=bellText){if(ThrallBellVariantPolicy.TryRead(text,out var value)){bellEpisode=bellValid?ThrallBellVariantPolicy.PreserveVariant(bellEpisode,value):value;bellValid=true;}else bellValid=false;bellText=text;}
   return bellValid?bellEpisode:default;
  }}
  BellMotionBank CurrentBellBank=>BellVariants?.Get(CurrentBell.Variant)??BellBank;
  public long BellStarted=>CurrentBell.Started;
  public float BellRingTime=>CurrentBellBank?.ringTime??0;
  public float BellActionDuration=>CurrentBellBank?.duration??0;
  public Vector3 HammerAudioPoint=>head?head.position:transform.position;
  public bool Own=>view&&view.IsValid()&&view.IsOwner()&&humanoid&&!humanoid.IsDead();
  static long Now=>ZNet.instance?ZNet.instance.GetTime().Ticks:DateTime.UtcNow.Ticks;
  public float BellElapsed {get{var e=CurrentBell;if(!e.Active||e.Started<=0)return -1;return (float)((Now-e.Started)/10000000d);}}
  public bool BellActive=>BellElapsed>=0&&BellElapsed<BellActionDuration;
  public bool MeleeActive=>melee||motion&&motion.Busy;
  public bool CanStartMelee=>head&&motion&&motion.CanBeginAttack&&!melee&&!BellActive&&Time.time>=nextMelee&&!BellReady()&&!(GetComponent<ThrallTactics>()?.Positioning??false);
  public bool MotionBlocking=>motion&&motion.Blocking;
  bool BellReady(){if(!Own||!ai||named==null||Time.time<nextMelee||motion&&motion.Busy)return false;var target=ai.GetTargetCreature();float distance=target?Vector3.Distance(transform.position,target.transform.position):999;bool sight=target&&!target.IsDead()&&!target.InGhostMode()&&!Physics.Linecast(named["Head"].position,target.GetCenterPoint(),SolidMask,QueryTriggerInteraction.Ignore);return ThrallCombatPolicy.CanBell(true,true,humanoid.InAttack()||melee,humanoid.IsStaggering(),sight,distance,Time.time,nextBell);}
  void Awake(){humanoid=GetComponent<Humanoid>();ai=GetComponent<MonsterAI>();view=GetComponent<ZNetView>();animator=GetComponentInChildren<Animator>(true);}
  void Start(){
   motion=GetComponent<ThrallSourceMotion>();
   if(!view||!view.IsValid()||BellBank==null||HeadShape==null){enabled=false;return;}
   named=GetComponentsInChildren<Transform>(true).GroupBy(t=>t.name).ToDictionary(g=>g.Key,g=>g.First());if(BellBank.boneNames.Any(n=>!named.ContainsKey(n)))throw new InvalidOperationException("Own bell animation binding missing");
   var go=new GameObject("BT_Model_Hammer_Head");head=go.transform;head.SetParent(named["RightHand"],false);head.localPosition=HeadShape.localPosition;head.localRotation=HeadShape.localRotation;
   trail=go.AddComponent<TrailRenderer>();trail.sharedMaterial=ThrallEffects.Material;trail.time=.18f;trail.minVertexDistance=ThrallSizePolicy.World(.035f);trail.startWidth=ThrallSizePolicy.World(Mathf.Max(HeadShape.halfExtents.x,HeadShape.halfExtents.y)*1.4f);trail.endWidth=ThrallSizePolicy.World(.015f);trail.startColor=new Color(1,.75f,.45f,.32f);trail.endColor=new Color(1,.5f,.2f,0);trail.emitting=false;trail.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;trail.receiveShadows=false;swish=ThrallEffects.Audio(head);
   weaponParts=new Transform[WeaponShapes.Length];previousParts=new Vector3[weaponParts.Length];previousPartRotations=new Quaternion[weaponParts.Length];for(int i=0;i<weaponParts.Length;i++){var part=new GameObject("BT_Hammer_Contact_Section_"+i).transform;part.SetParent(named["RightHand"],false);part.localPosition=WeaponShapes[i].localPosition;part.localRotation=WeaponShapes[i].localRotation;weaponParts[i]=part;}SaveWeaponPose();
   nextBell=Time.time+8f;previousHead=head.position;previousRotation=head.rotation;previousActor=transform.position;
   SeedBellTimeline();
  }
  void SeedBellTimeline(){if(!view||!view.IsValid())return;bellEnabledAt=Now;seenPulse=view.GetZDO().GetLong("bt_bell_pulse",0);bellGate.Enable(bellEnabledAt,view.GetZDO().GetOwner());}
  void OnEnable(){if(head)SeedBellTimeline();}
  void BeginBell(){
   var z=view.GetZDO();var previous=CurrentBell;int last=Math.Max(z.GetInt("bt_bell_sequence",0),previous.Sequence);int sequence=last==int.MaxValue?1:Math.Max(0,last)+1;
   uint identity=unchecked((uint)z.m_uid.ToString().GetStableHashCode());var e=new ThrallBellEpisode(sequence,Now,ThrallBellVariantPolicy.Choose(identity,sequence),true);
   z.Set("bt_bell_sequence",sequence);z.Set(ThrallBellVariantPolicy.StateKey,ThrallBellVariantPolicy.Encode(e));z.Set("bt_bell_start",e.Started);z.Set("bt_bell_active",1);
   nextBell=Time.time+ThrallCombatPolicy.BellCooldown;StopForBell();Log?.Invoke("BT_BELL_WINDUP variant="+e.Variant+" sequence="+sequence+" ringTime="+BellRingTime);
  }
  public void BeginAttack(Attack nativeAttack=null){if(melee||BellActive||!head||!motion||!motion.Ready)return;if(Own&&!motion.SourceAttackActive&&!motion.TryBeginMelee(humanoid.GetCurrentWeapon()?.m_shared.m_attack.m_attackAnimation))return;if(!motion.SourceAttackActive)return;attack=nativeAttack;weapon=humanoid.GetCurrentWeapon();melee=true;entered=false;whooshed=false;blocked=false;windowWas=false;began=Time.time;hitTargets.Reset();strikeRoute=strikePacket=strikeArc=cachedStrikePacket=-1;physicalGroups=Array.Empty<ThrallMotionWindow>();swings++;previousHead=head.position;previousRotation=head.rotation;peakHeadSpeed=0;swingHitStart=hits;solidStops=0;lastSolid="";sourceRecovery=ThrallCombatPolicy.Recovery;SaveWeaponPose();
  }
  void FinishAttack(){if(!melee)return;if(Own&&(swings<=12||swings%20==0))Log?.Invoke("BT_SWING_RESULT swing="+swings+" clip="+lastClip+" contacts="+(hits-swingHitStart)+" solidFrames="+solidStops+" lastSolid="+lastSolid);melee=false;if(trail)trail.emitting=false;nextMelee=Time.time+Mathf.Max(ThrallCombatPolicy.Recovery,sourceRecovery);windowWas=false;if(Own)GetComponent<ThrallTactics>()?.RouteFinished(sourceRecovery);}
  public void NativeTrigger(){nativeTriggers++;}
  public void StopForBell(){humanoid.SetMoveDir(Vector3.zero);humanoid.SetRun(false);}
  void Update(){if(!head||!view.IsValid())return;
   if(humanoid.IsDead()){FinishAttack();motion?.CancelAction();if(view.IsOwner())CancelBell();return;}
   if(motion&&motion.SourceAttackActive&&!melee&&!BellActive)BeginAttack();if(melee&&(!motion||!motion.SourceAttackActive))FinishAttack();
   if(Own){float elapsed=BellElapsed;if(elapsed>=0){if(humanoid.IsStaggering()){CancelBell();cancellations++;}else if(elapsed>=BellActionDuration)CancelBell();else StopForBell();}
    else if(BellReady())BeginBell();
   }
  }
  void CancelBell(){if(view&&view.IsValid()&&view.IsOwner()){var e=CurrentBell;var z=view.GetZDO();if(e.Variant>0&&e.Sequence>0)z.Set(ThrallBellVariantPolicy.StateKey,ThrallBellVariantPolicy.Encode(e.Stop()));z.Set("bt_bell_active",0);}nextMelee=Time.time+ThrallCombatPolicy.Recovery;}
  void LateUpdate(){if(!head||!view.IsValid()||humanoid.IsDead())return;
   var episode=CurrentBell;var bank=CurrentBellBank;float elapsed=BellElapsed;if(elapsed>=0&&elapsed<bank.duration){ThrallBellMotion.Apply(bank,named,elapsed,ThrallBellVariantPolicy.Weight(elapsed,bank.duration));trail.emitting=false;
    bool crossed=bellGate.Step(episode,elapsed,bank.ringTime,bank.duration,view.GetZDO().GetOwner());
    if(Own&&crossed){var z=view.GetZDO();long release=ThrallBellVariantPolicy.ReleaseTick(episode,bank.ringTime);if(z.GetLong("bt_bell_pulse",0)!=release){z.Set("bt_bell_pulse_pos",named["BT1_Bell_Hinge"].position);z.Set("bt_bell_pulse",release);rings++;Log?.Invoke("BT_BELL_RELEASE variant="+episode.Variant+" ringAt="+elapsed+" eventTime="+bank.ringTime+" regenMultiplier="+ThrallCombatPolicy.RegenMultiplier);}}
   }else SweepLate();
   long pulse=view.GetZDO().GetLong("bt_bell_pulse",0);if(pulse>0&&pulse!=seenPulse){seenPulse=pulse;float age=(float)((Now-pulse)/10000000d);if(pulse>=bellEnabledAt&&age>=0&&age<.65f)ThrallEffects.Ring(view.GetZDO().GetVec3("bt_bell_pulse_pos",named["BT1_Bell_Hinge"].position),age,humanoid);}
   previousHead=head.position;previousRotation=head.rotation;previousActor=transform.position;SaveWeaponPose();
   ThrallAudio.Safe(()=>GetComponent<ThrallAudio>()?.SourceFrame(motion));
   motion?.EndContactFrame();
   motion?.CachePresentedPose();
  }
  void SaveWeaponPose(){if(weaponParts==null)return;for(int i=0;i<weaponParts.Length;i++){previousParts[i]=weaponParts[i].position;previousPartRotations[i]=weaponParts[i].rotation;}}
  bool Clip(out AnimationClip clip,out float phase){clip=null;phase=0;for(int layer=0;layer<animator.layerCount;layer++){
   var infos=animator.IsInTransition(layer)?animator.GetNextAnimatorClipInfo(layer):animator.GetCurrentAnimatorClipInfo(layer);var state=animator.IsInTransition(layer)?animator.GetNextAnimatorStateInfo(layer):animator.GetCurrentAnimatorStateInfo(layer);
   foreach(var info in infos.OrderByDescending(i=>i.weight)){if(info.clip&&info.clip.events.Any(e=>e.functionName=="OnAttackTrigger"||e.functionName=="Hit")){clip=info.clip;phase=state.normalizedTime;return true;}}
  }return false;}
  void SweepLate(){if(!melee||BellActive||!motion||!motion.SourceAttackActive){trail.emitting=false;return;}lastClip=motion.CurrentClipId;lastPhase=motion.SampleTime/Mathf.Max(.001f,motion.CurrentDuration);
   if(motion.AttackSerial>0&&heardAttackSerial!=motion.AttackSerial){heardAttackSerial=motion.AttackSerial;sourceRecovery=motion.Recovery;}
   blocked=false;bool window=motion.ContactActive&&!humanoid.IsStaggering();float speed=Vector3.Distance(previousHead,head.position)/Mathf.Max(.001f,Time.deltaTime);peakHeadSpeed=Mathf.Max(peakHeadSpeed,speed);
   bool displayedWindow=ThrallMotionPolicy.Contact(motion.PreviousSampleTime,motion.SampleTime,motion.ContactWindows);trail.emitting=displayedWindow&&!blocked;if(displayedWindow&&!windowWas)trail.Clear();if(motion.SwishCrossed){whooshed=true;/* Source-clock audio owns the selected air cue; visual trail remains here. */}
   if(window&&!blocked&&Own&&weapon!=null&&ThrallCombatPolicy.SafeSweep(Vector3.Distance(previousActor,transform.position),Time.deltaTime)){
    if(cachedStrikePacket!=motion.AudioPacketSerial){physicalGroups=ThrallStrikePolicy.Groups(motion.AudioFrom,motion.AudioTo,motion.ContactWindows);cachedStrikePacket=motion.AudioPacketSerial;}
    for(int i=0;i<physicalGroups.Length;i++)if(ThrallMotionPolicy.ContactSegment(motion.PreviousSampleTime,motion.SampleTime,physicalGroups[i],out float start,out float end)){
     BeginPhysicalStrike(i);SweepSourceWindow(start,end);
    }
   }else if(window&&!ThrallCombatPolicy.SafeSweep(Vector3.Distance(previousActor,transform.position),Time.deltaTime)){trail.Clear();}windowWas=displayedWindow;
  }
  void BeginPhysicalStrike(int group){
   if(strikeRoute==motion.AttackSerial&&strikePacket==motion.AudioPacketSerial&&strikeArc==group)return;
   strikeRoute=motion.AttackSerial;strikePacket=motion.AudioPacketSerial;strikeArc=group;physicalStrikes++;hitTargets.Reset();
   ThrallAudio.Safe(()=>GetComponent<ThrallAudio>()?.BeginSwing());
   if(physicalStrikes<=12||physicalStrikes%20==0)Log?.Invoke("BT_STRIKE_BEGIN route="+strikeRoute+" packet="+strikePacket+" arc="+strikeArc+" clip="+motion.CurrentClipId);
  }

  void SweepSourceWindow(float start,float end){
   // BeginPhysicalStrike has admitted a stable route+packet+physical contact
   // group. All subdivisions/colliders share that one strike's victim ledger;
   // a later distinct swing may hit again, even inside the same combo route.
   int steps=Mathf.Clamp(Mathf.CeilToInt((end-start)*60),1,18);for(int s=0;s<steps;s++)SweepSourceSegment(Mathf.Lerp(start,end,(float)s/steps),Mathf.Lerp(start,end,(float)(s+1)/steps));
  }
  void SweepSourceSegment(float start,float end){
   if(!motion.WeaponPoseAt(start,out var fromHand,out var fromRotation)||!motion.WeaponPoseAt(end,out var toHand,out var toRotation))return;
   for(int i=0;i<WeaponShapes.Length;i++){blocked=false;var shape=WeaponShapes[i];var scale=(toHand*Matrix4x4.TRS(shape.localPosition,shape.localRotation,Vector3.one)).lossyScale;var half=Vector3.Scale(shape.halfExtents,new Vector3(Mathf.Abs(scale.x),Mathf.Abs(scale.y),Mathf.Abs(scale.z)));var from=fromHand.MultiplyPoint3x4(shape.localPosition);var to=toHand.MultiplyPoint3x4(shape.localPosition);sweepQuery.Visit(from,fromRotation*shape.localRotation,to,toRotation*shape.localRotation,half,HitMask,(c,f,t)=>{Contact(c,f,t);return blocked;});}
  }
  public Vector3 WorldHalfExtents=>Vector3.Scale(HeadShape.halfExtents,new Vector3(Mathf.Abs(head.lossyScale.x),Mathf.Abs(head.lossyScale.y),Mathf.Abs(head.lossyScale.z)));
  void Sweep(Vector3 from,Quaternion before,Vector3 to,Quaternion after){for(int i=0;i<weaponParts.Length;i++){blocked=false;var part=weaponParts[i];var scale=part.lossyScale;var half=Vector3.Scale(WeaponShapes[i].halfExtents,new Vector3(Mathf.Abs(scale.x),Mathf.Abs(scale.y),Mathf.Abs(scale.z)));sweepQuery.Visit(previousParts[i],previousPartRotations[i],part.position,part.rotation,half,HitMask,(c,f,t)=>{Contact(c,f,t);return blocked;});}}
  void Contact(Collider collider,Vector3 from,Vector3 at){if(!collider||collider.transform.IsChildOf(transform))return;GameObject target=collider.attachedRigidbody?collider.attachedRigidbody.gameObject:collider.gameObject;var destructible=target.GetComponent<IDestructible>()??collider.GetComponentInParent<IDestructible>();var component=destructible as Component;Vector3 point=component?ThrallWeaponShape.Point(collider,at):at;
   if(component){
    var character=component.GetComponentInParent<Character>()??collider.GetComponentInParent<Character>();int targetKey=character?character.GetInstanceID():component.GetInstanceID();
    if(component.transform.IsChildOf(transform)||character==humanoid||hitTargets.Contains(targetKey))return;
    if(character&&(!BaseAI.IsEnemy(humanoid,character)||character.IsDead()||character.InGhostMode()))return;
    var ownerTree=character?character.transform:component.transform;
    if(Physics.Linecast(humanoid.GetCenterPoint(),point,out var cover,SolidMask,QueryTriggerInteraction.Ignore)&&cover.collider!=collider&&!cover.collider.transform.IsChildOf(ownerTree)){blocked=true;solidStops++;lastSolid=cover.collider.name;return;}
    hitTargets.Mark(targetKey);var hit=new HitData{m_point=point,m_dir=(at-from).sqrMagnitude>.00001f?(at-from).normalized:transform.forward,m_hitCollider=collider,m_pushForce=weapon.m_shared.m_attackForce*(attack?.m_forceMultiplier??1),m_staggerMultiplier=attack?.m_staggerMultiplier??1,m_blockable=weapon.m_shared.m_blockable,m_dodgeable=weapon.m_shared.m_dodgeable,m_hitType=HitData.HitType.EnemyHit};hit.m_damage=weapon.GetDamage();hit.m_damage.Modify(attack?.m_damageMultiplier??1);hit.SetAttacker(humanoid);ThrallAudio.Safe(()=>GetComponent<ThrallAudio>()?.RecordSubmission(character,hit.m_point));destructible.Damage(hit);hits++;Log?.Invoke("BT_HAMMER_CONTACT route="+strikeRoute+" packet="+strikePacket+" arc="+strikeArc+" target="+component.name+" phase="+lastPhase+" clip="+lastClip+" damageSubmitted="+hit.GetTotalDamage()+" dodgeable="+hit.m_dodgeable);
   }
   if((SolidMask&(1<<collider.gameObject.layer))!=0){blocked=true;solidStops++;lastSolid=collider.name;}
  }
  public string Diagnostics()=>" melee="+melee+" clip="+lastClip+" phase="+lastPhase+" headSpeed="+peakHeadSpeed+" lastSolid="+lastSolid+" contacts="+hits+" swings="+swings+" physicalStrikes="+physicalStrikes+" strikeArc="+strikeArc+" bellRings="+rings+" bellCancelled="+cancellations+" nativeTriggersSuppressed="+nativeTriggers+(GetComponent<ThrallTactics>()?.Diagnostics()??"");
  void OnDisable(){FinishAttack();if(view&&view.IsValid()&&view.IsOwner())CancelBell();}
 }
}
