using System;
namespace BlackAbbey.BellThrall {
 // Exact installed MonsterAI.UpdateAI readiness (IL0488..04d9). Source
 // reach replaces only its legacy two-log range opportunity, not its timers.
 public static class ThrallNativeAttackPolicy {
  static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
  public static bool Ready(float now,float itemLastAttack,float itemInterval,float sinceAttack,float minimumInterval,bool takingOff)=>
   Finite(now)&&Finite(itemLastAttack)&&Finite(itemInterval)&&Finite(sinceAttack)&&Finite(minimumInterval)&&
   now>=0&&itemInterval>=0&&minimumInterval>=0&&!takingOff&&now-itemLastAttack>itemInterval&&sinceAttack>=minimumInterval;
 }
}
