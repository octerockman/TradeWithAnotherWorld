using System;using System.Collections.Generic;using System.Linq;using UnityEngine;
namespace BlackAbbey.BellThrall {
 // Contact presentation only: no forces, collider changes, damage or death delays.
 public enum ThrallCorpseContactCue { None,LandingLight,LandingHeavy,Iron }
 public sealed class ThrallCorpseContactAudioPolicy {
  bool landed,iron;float landedAt;
  public ThrallCorpseContactCue Observe(float time,float normalSpeed,bool newContact,bool eligibleBody){
   if(!Finite(time)||!Finite(normalSpeed)||normalSpeed<0||!newContact||!eligibleBody)return ThrallCorpseContactCue.None;
   if(!landed){if(normalSpeed<.8f)return ThrallCorpseContactCue.None;landed=true;landedAt=time;return normalSpeed>=1.8f?ThrallCorpseContactCue.LandingHeavy:ThrallCorpseContactCue.LandingLight;}
   if(!iron&&time>=landedAt+.2f&&normalSpeed>=.25f){iron=true;return ThrallCorpseContactCue.Iron;}
   return ThrallCorpseContactCue.None;
  }
  static bool Finite(float v)=>!float.IsNaN(v)&&!float.IsInfinity(v);
 }
 public sealed class ThrallCorpseAudio:MonoBehaviour {
  sealed class Binding {public Transform Head;public AudioSource Source;public ThrallDeathVoiceFollow Follow;public float Born;}
  static readonly Dictionary<int,Binding> bindings=new Dictionary<int,Binding>();
  static readonly HashSet<ThrallCorpseAudio> actors=new HashSet<ThrallCorpseAudio>();
  const int MaximumBindings=24;
  readonly ThrallCorpseContactAudioPolicy contacts=new ThrallCorpseContactAudioPolicy();
  AudioSource impact;int actorId;Transform head;
  public void Configure(int id,Transform corpseHead){actorId=id;head=corpseHead;actors.Add(this);BindHead(id,corpseHead);}
  static Binding Get(int id){
   foreach(var item in bindings.Where(p=>(!p.Value.Head&&!p.Value.Source)||Time.time-p.Value.Born>15f).ToArray())bindings.Remove(item.Key);
   if(bindings.TryGetValue(id,out var found))return found;
   while(bindings.Count>=MaximumBindings){var oldest=bindings.OrderBy(p=>p.Value.Born).First();bindings.Remove(oldest.Key);}
   var entry=new Binding{Born=Time.time};bindings.Add(id,entry);return entry;
  }
  public static void BindHead(int actorId,Transform corpseHead){
   if(actorId==0||!corpseHead)return;var entry=Get(actorId);entry.Head=corpseHead;if(entry.Follow)entry.Follow.Target=corpseHead;
  }
  // Caller owns the already-playing source and its lifetime. Binding only follows
  // the presented corpse head, and deliberately never changes playback/time.
  public static void FollowDeathVoice(int actorId,AudioSource alreadyPlaying){
   if(actorId==0||!alreadyPlaying)return;var entry=Get(actorId);entry.Source=alreadyPlaying;
   var follow=alreadyPlaying.GetComponent<ThrallDeathVoiceFollow>()??alreadyPlaying.gameObject.AddComponent<ThrallDeathVoiceFollow>();
   follow.ActorId=actorId;follow.Source=alreadyPlaying;follow.Target=entry.Head;entry.Follow=follow;
   if(entry.Head)alreadyPlaying.transform.position=entry.Head.position;
  }
  internal static void ReleaseVoice(int id,AudioSource source){if(bindings.TryGetValue(id,out var entry)&&ReferenceEquals(entry.Source,source)){entry.Source=null;entry.Follow=null;if(!entry.Head)bindings.Remove(id);}}
  public void FloorContact(string body,Vector3 point,float normalSpeed,bool newContact){
   if(!enabled||!gameObject.activeInHierarchy||!Finite(point))return;
   // Feet/hands may touch before the body falls. They do not impersonate the
   // body's first landing; torso/head/major limb contacts carry the mass cue.
   bool eligible=body=="Hips"||body=="Spine2"||body=="Head"||body=="LeftArm"||body=="RightArm"||body=="LeftUpLeg"||body=="RightUpLeg"||body=="LeftLeg"||body=="RightLeg";
   var cue=contacts.Observe(Time.fixedTime,normalSpeed,newContact,eligible);if(cue==ThrallCorpseContactCue.None)return;
   AudioClip clip=cue==ThrallCorpseContactCue.Iron?ThrallEffects.Iron:ThrallEffects.Landings!=null&&ThrallEffects.Landings.Length>0?ThrallEffects.Landings[Math.Min(cue==ThrallCorpseContactCue.LandingHeavy?1:0,ThrallEffects.Landings.Length-1)]:null;
   if(!clip)return;if(!impact){var go=new GameObject("BT Corpse Floor Contact Audio");go.transform.SetParent(transform,false);impact=ThrallEffects.Audio(go.transform);impact.dopplerLevel=0;}
   impact.transform.position=point;impact.PlayOneShot(clip,cue==ThrallCorpseContactCue.Iron?.35f:.8f);
   ThrallSourceMotion.Log?.Invoke("BT_CORPSE_AUDIO cue="+cue+" body="+body+" normalSpeed="+normalSpeed);
  }
  static bool Finite(Vector3 p)=>!float.IsNaN(p.x)&&!float.IsInfinity(p.x)&&!float.IsNaN(p.y)&&!float.IsInfinity(p.y)&&!float.IsNaN(p.z)&&!float.IsInfinity(p.z);
  void OnDestroy(){actors.Remove(this);if(impact)impact.Stop();if(bindings.TryGetValue(actorId,out var entry)&&ReferenceEquals(entry.Head,head)){entry.Head=null;if(entry.Follow)entry.Follow.Target=null;if(!entry.Source)bindings.Remove(actorId);}}
  public static void Shutdown(){foreach(var actor in actors)if(actor&&actor.impact)actor.impact.Stop();actors.Clear();foreach(var entry in bindings.Values)if(entry.Follow){entry.Follow.Target=null;entry.Follow.enabled=false;}bindings.Clear();}
 }
 [DefaultExecutionOrder(1100)]
 public sealed class ThrallDeathVoiceFollow:MonoBehaviour {
  public int ActorId;public AudioSource Source;public Transform Target;
  void LateUpdate(){if(Source&&Target)Source.transform.position=Target.position;}
  void OnDestroy(){ThrallCorpseAudio.ReleaseVoice(ActorId,Source);}
 }
}
