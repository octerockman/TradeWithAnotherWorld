using System;
namespace BlackAbbey.BellThrall {
 public readonly struct ThrallTrackingPhase {
  public readonly bool Valid,Locked;public readonly int Group;public readonly float CommitAt,ReleaseAt;
  public ThrallTrackingPhase(bool valid,bool locked,int group,float commitAt,float releaseAt){Valid=valid;Locked=locked;Group=group;CommitAt=commitAt;ReleaseAt=releaseAt;}
 }
 // Heading commitment has its own groups. Damage arcs group the physical contact
 // windows, whereas tracking also includes each arc's unchanged .16s lead-in.
 // Owner/target/recovery/restore decisions remain in the native-facing adapter.
 public static class ThrallTrackingPolicy {
  public const float CommitLead=.16f;
  static bool Finite(float v)=>!float.IsNaN(v)&&!float.IsInfinity(v);
  public static ThrallTrackingPhase Evaluate(float from,float to,ThrallMotionWindow[] windows,float at){
   if(!Finite(from)||!Finite(to)||!Finite(at)||from<0||to<=from||windows==null||windows.Length>64)return new ThrallTrackingPhase(false,true,-1,from,to);
   foreach(var w in windows)if(w==null||!Finite(w.start)||!Finite(w.end)||w.start<0||w.end<w.start)return new ThrallTrackingPhase(false,true,-1,from,to);
   // Scan a bounded, possibly unsorted inventory without allocating/sorting on
   // every native physics tick. A component is the union of touching intervals.
   float cursor=float.NegativeInfinity;int group=0;
   for(int pass=0;pass<windows.Length;pass++){
    float start=float.PositiveInfinity,end=float.NegativeInfinity;
    foreach(var w in windows){if(w.end<from||w.start>to)continue;float a=Math.Max(from,w.start-CommitLead),b=Math.Min(to,w.end);if(a<=cursor)continue;if(a<start){start=a;end=b;}else if(a==start)end=Math.Max(end,b);}
    if(float.IsPositiveInfinity(start))break;
    for(int merge=0;merge<windows.Length;merge++){
     float extended=end;
     foreach(var w in windows){if(w.end<from||w.start>to)continue;float a=Math.Max(from,w.start-CommitLead),b=Math.Min(to,w.end);if(a>=start&&a<=end)extended=Math.Max(extended,b);}
     if(extended==end)break;end=extended;
    }
    // Inclusive release prevents the exact final contact sample from turning.
    if(at>=start&&at<=end)return new ThrallTrackingPhase(true,true,group,start,end);
    cursor=end;group++;
   }
   return new ThrallTrackingPhase(true,false,-1,float.PositiveInfinity,float.NegativeInfinity);
  }
 }
}
