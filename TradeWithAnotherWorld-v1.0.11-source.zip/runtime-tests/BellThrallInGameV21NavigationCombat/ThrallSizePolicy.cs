namespace BlackAbbey.BellThrall {
 // A runtime derivative of the exact approved art/motion. Only the outer
 // visual and physical measurements change; source bones/poses stay authored.
 public static class ThrallSizePolicy {
  public const float Multiplier=.75f,PreviousActorScale=1.75f,ActorScale=PreviousActorScale*Multiplier;
  public static float World(float authored)=>authored*Multiplier;
  public static float Authored(float world)=>world/Multiplier;
 }
}
