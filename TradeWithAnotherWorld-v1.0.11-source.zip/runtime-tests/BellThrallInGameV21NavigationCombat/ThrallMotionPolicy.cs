using System;

namespace BlackAbbey.BellThrall {
 public sealed class ThrallMotionWindow { public float start,end; }
 public sealed class ThrallMotionSegment {public string id,kind,startState,endState;public float start,end;}
 public sealed class ThrallMotionRouteStep {public string id,kind,startState,endState;public float start,end=-1;}
 public sealed class ThrallMotionDescriptor {
  public string id,category,file,sha256,startState,endState; public int frameCount,fps,timelineFps,uncompressedBytes;public float sampleHz;public float[] bodyBoundsUnityMin,bodyBoundsUnityMax;
  public float duration,strideDistance,recovery,yawDegrees; public bool loop,autonomousEligible,rootMotionApplied,requiresClearance,contextSupported=true,manualOnly,contactPhaseReviewed;
  public ThrallMotionWindow[] contactWindows; public float[] swishTimes; public string[] entryClips,exitClips;
  public ThrallMotionSegment[] entrySegments,exitSegments;
  public ThrallAttackAdvanceProfile attackAdvance;
  public ThrallLocomotionDistanceProfile locomotionDistance;
 }
 public sealed class ThrallMotionPacket {public int serial,actionSerial;public long ticks;public string id,kind,startState,endState;public float rate=1,from,to;public ThrallMotionRouteStep[] remaining;}

 // Pure timing/admission helpers are also linked directly into offline checks.
 public static class ThrallMotionPolicy {
  public const int ClipCount=157,BoneCount=58;public const float Transition=.18f;
  public static bool Finite(float n)=>!float.IsNaN(n)&&!float.IsInfinity(n);
  public static bool CanEmitEffects(bool active,bool restoredVisualOnly,bool alive)=>active&&!restoredVisualOnly&&alive;
  public static bool CanComplete(float elapsed,float duration,bool finalPosePresented)=>Finite(elapsed)&&Finite(duration)&&elapsed>=duration&&finalPosePresented;
  public static float DeathEntry(float[] times,float[] costs,float duration){
   if(times==null||costs==null||times.Length!=costs.Length||times.Length<2||!Finite(duration)||duration<=0)throw new ArgumentException("Invalid death-entry samples");
   int best=0;for(int i=0;i<times.Length;i++){if(!Finite(times[i])||!Finite(costs[i])||times[i]<0||times[i]>duration||costs[i]<0)throw new ArgumentException("Invalid death-entry cost");if(costs[i]<costs[best])best=i;}
   // Preserve the complete standing fall unless the presented low/raised pose
   // has a substantially closer supported phase in this same selected clip.
   return costs[best]<costs[0]*.6f?times[best]:0;
  }
  public static float Clamp(float n,float lo,float hi)=>Math.Max(lo,Math.Min(hi,n));
  public static float Elapsed(long start,long now,float rate)=>Math.Max(0,(float)((now-start)/10000000d)*rate);
  public static float SampleTime(float elapsed,float duration,bool loop){if(duration<=0)return 0;return loop?Math.Max(0,elapsed)%duration:Clamp(elapsed,0,duration);}
  public static bool Crossed(float before,float now,float at)=>before<at&&now>=at;
  public static bool Contact(float before,float now,ThrallMotionWindow[] windows){
   if(windows==null||now<before)return false;
   foreach(var w in windows)if(now>=w.start&&now<=w.end)return true;return false;
  }
  public static bool ContactSegment(float before,float now,ThrallMotionWindow window,out float start,out float end){
   start=end=0;if(window==null||!Finite(before)||!Finite(now)||now<before||now-before>.3f)return false;
   start=Math.Max(Math.Max(0,before),window.start);end=Math.Min(now,window.end);return end>=start&&now>=window.start&&before<=window.end;
  }
  public static bool ClearanceDefined(ThrallMotionDescriptor d){if(!d.requiresClearance)return true;if(d.bodyBoundsUnityMin?.Length!=3||d.bodyBoundsUnityMax?.Length!=3)return false;for(int i=0;i<3;i++)if(!Finite(d.bodyBoundsUnityMin[i])||!Finite(d.bodyBoundsUnityMax[i])||d.bodyBoundsUnityMax[i]<=d.bodyBoundsUnityMin[i])return false;return true;}
  public static bool CombatReady(ThrallMotionDescriptor d)=>d!=null&&d.category=="Attacks"&&d.autonomousEligible&&!d.manualOnly&&d.contextSupported&&d.contactPhaseReviewed&&ClearanceDefined(d)&&d.contactWindows!=null&&d.contactWindows.Length>0&&d.swishTimes!=null&&d.swishTimes.Length>0;
  public static int LowerFrame(float[] times,float time){int lo=0,hi=times.Length-1;while(lo<hi){int mid=(lo+hi+1)/2;if(times[mid]<=time)lo=mid;else hi=mid-1;}return lo;}
  public static float AdvanceDistancePhase(float phase,float distance,float stride,float dt){
   if(!Finite(distance)||!Finite(stride)||!Finite(dt)||distance<0||distance>3||stride<=.001f||dt<=0||dt>.25f)return phase;
   return (phase+distance/stride)%1f;
  }
  public static string Locomotion(float forward,float right,float speed,float walkSpeed){
   if(speed<.08f)return "a000_000020";
   if(Math.Abs(right)>Math.Abs(forward)*1.25f)return right<0?"a000_002002":"a000_002003";
   if(forward<-.05f)return "a000_002001";
   if(speed>Math.Max(1.6f,walkSpeed*1.55f))return "a000_002100";
   return speed>walkSpeed*.85f?"a000_002000":"a000_002300";
  }
  public static string Turn(float signedDegrees,bool halfTurn,bool alternate){int code=(signedDegrees<0?0:1)+(halfTurn?2:0)+(alternate?10:0);return "a000_005"+code.ToString("000",System.Globalization.CultureInfo.InvariantCulture);}
  public static bool Standing(string state){return string.IsNullOrEmpty(state)||state=="standing"||state=="neutral"||state=="hunched"||state=="upright"||state=="upright-neutral";}
  public static bool Compatible(string current,string required)=>string.IsNullOrEmpty(required)||required=="any"||current==required||(Standing(current)&&Standing(required));
  public static bool IsRaised(string id)=>id!=null&&id.StartsWith("a000_013",StringComparison.Ordinal)&&
   (id=="a000_013130"||id=="a000_013140"||id=="a000_013150"||id=="a000_013160"||id=="a000_013170"||id=="a000_013180");
  public static string[] RecoveryPath(string start,ThrallMotionDescriptor[] clips){
   if(Standing(start))return Array.Empty<string>();var pending=new System.Collections.Generic.Queue<string>();var seen=new System.Collections.Generic.HashSet<string>(StringComparer.Ordinal){start};var previous=new System.Collections.Generic.Dictionary<string,Tuple<string,string>>(StringComparer.Ordinal);pending.Enqueue(start);
   while(pending.Count>0){string state=pending.Dequeue();foreach(var clip in clips){if(clip==null||!clip.contextSupported||clip.loop||clip.startState==clip.endState||!(clip.category=="Recoveries"||clip.category=="Special"||clip.category=="IdleAndHolds")||!Compatible(state,clip.startState)||string.IsNullOrEmpty(clip.endState)||!seen.Add(clip.endState))continue;previous[clip.endState]=Tuple.Create(state,clip.id);if(Standing(clip.endState)){var route=new System.Collections.Generic.List<string>();string at=clip.endState;while(at!=start){var step=previous[at];route.Add(step.Item2);at=step.Item1;}route.Reverse();return route.ToArray();}pending.Enqueue(clip.endState);}}
   return null;
  }
  public static string[] EntryHelpers(ThrallMotionDescriptor clip){
   if(clip.entryClips!=null)return clip.entryClips;
   return Array.Empty<string>();
  }
  public static string[] ExitHelpers(ThrallMotionDescriptor clip){
   if(clip.exitClips!=null)return clip.exitClips;
   return Array.Empty<string>();
  }
  public sealed class Playback {
   public readonly string Id;public readonly float Duration,Rate;public readonly long Started;
   public Playback(string id,float duration,long ticks,float rate=1){Id=id;Duration=duration;Started=ticks;Rate=rate;}
   public float Time(long now)=>SampleTime(Elapsed(Started,now,Rate),Duration,false);
   public bool Complete(long now)=>Elapsed(Started,now,Rate)>=Duration;
  }
  public sealed class Gate {
   public long Owner,EnabledAt;public int Serial=-1;public bool Active;
   public void Enable(long owner,long now){Owner=owner;EnabledAt=now;Serial=-1;Active=true;}
   public void Disable(){Active=false;}
   public bool Accept(long owner,int serial,long ticks,long now,float duration,bool restored=false){
    if(!Active||owner==0||Owner==0||owner!=Owner||serial<=Serial||serial<0||ticks<=0||!Finite(duration)||duration<=0)return false;
    double age=(now-ticks)/10000000d;if(age<-.3||age>duration+.5||(!restored&&ticks<EnabledAt))return false;
    Serial=serial;return true;
   }
  }
 }
 public sealed class ThrallPresentedPoseCache {
  readonly float[] positions=new float[174],rotations=new float[232];public bool Ready{get;private set;}
  public void Store(float[] p,float[] q){if(p?.Length!=174||q?.Length!=232)throw new ArgumentException("Presented pose inventory differs");for(int i=0;i<174;i++)if(!ThrallMotionPolicy.Finite(p[i]))throw new ArgumentException("Nonfinite presented position");for(int i=0;i<232;i++)if(!ThrallMotionPolicy.Finite(q[i]))throw new ArgumentException("Nonfinite presented quaternion");Array.Copy(p,positions,174);Array.Copy(q,rotations,232);Ready=true;}
  public void Copy(float[] p,float[] q){if(!Ready||p?.Length!=174||q?.Length!=232)throw new InvalidOperationException("Presented pose is unavailable");Array.Copy(positions,p,174);Array.Copy(rotations,q,232);}
 }
}
