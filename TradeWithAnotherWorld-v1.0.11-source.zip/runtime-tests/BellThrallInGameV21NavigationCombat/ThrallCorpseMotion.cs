using System;using System.Collections.Generic;using System.Linq;using UnityEngine;using Object=UnityEngine.Object;
namespace BlackAbbey.BellThrall {
 // A presentation tail only. The native dead Character, its ZDO, damage and
 // deletion lifecycle are never retained or replaced by this object.
 [DefaultExecutionOrder(900)]
 public sealed class ThrallCorpseMotion:MonoBehaviour {
  static readonly List<ThrallCorpseMotion> tails=new List<ThrallCorpseMotion>();
  static readonly int FloorMask=LayerMask.GetMask("Default","Default_small","terrain","static_solid","piece");
  ThrallSourceBank bank;ThrallSourceClip clip;Transform[] bones;long started;float offset,remaining,nextProbe,fallSpeed,floorY;bool floorKnown,expired;
  readonly RaycastHit[] hits=new RaycastHit[24];SkinSupport[] support;Vector3 lowest;Bounds coverage;bool hasCoverage;ThrallDeathPuff puff;
  ThrallCorpseRagdoll ragdoll;ThrallCorpseAudio corpseAudio;bool ragdollAttempted,finishing;float nextPuffAttempt;Vector3 inheritedVelocity,deathForward;
  readonly Vector3[] poses=new Vector3[58],initial=new Vector3[58];readonly Quaternion[] rotations=new Quaternion[58],initialRotations=new Quaternion[58];float born;int bornFrame;
  public static void Create(Transform visual,ThrallSourceBank bank,ThrallSourceClip clip,long ticks,float offset,float[] initialP,float[] initialQ){
   if(!visual||bank==null||clip==null||clip.Descriptor.category!="Death")return;
   tails.RemoveAll(t=>!t);while(tails.Count>=ThrallDeathPolicy.MaximumCorpses){var old=tails[0];tails.RemoveAt(0);if(old)old.Expire(true);}
   var holder=new GameObject("BT Private Grounded Death Visual");holder.SetActive(false);
   try{
    holder.transform.position=visual.position;holder.transform.rotation=visual.rotation;holder.transform.localScale=visual.lossyScale;
    var clone=Object.Instantiate(visual.gameObject,holder.transform,false);clone.name="BT Corpse Art";clone.transform.localPosition=Vector3.zero;clone.transform.localRotation=Quaternion.identity;clone.transform.localScale=Vector3.one;
    // Inactive-parent construction is essential: cloned CharacterAnimEvent,
    // footsteps and attached sources must never wake against the live owner.
    foreach(var b in clone.GetComponentsInChildren<MonoBehaviour>(true)){b.enabled=false;Object.DestroyImmediate(b);}
    foreach(var a in clone.GetComponentsInChildren<Animator>(true)){a.enabled=false;Object.DestroyImmediate(a);}
    foreach(var a in clone.GetComponentsInChildren<Animation>(true)){a.enabled=false;Object.DestroyImmediate(a);}
    foreach(var c in clone.GetComponentsInChildren<Collider>(true)){c.enabled=false;Object.DestroyImmediate(c);}
    foreach(var r in clone.GetComponentsInChildren<Rigidbody>(true)){r.isKinematic=true;Object.DestroyImmediate(r);}
    foreach(var a in clone.GetComponentsInChildren<AudioSource>(true)){a.Stop();a.enabled=false;Object.DestroyImmediate(a);}
    foreach(var p in clone.GetComponentsInChildren<ParticleSystem>(true)){p.Stop(true,ParticleSystemStopBehavior.StopEmittingAndClear);Object.DestroyImmediate(p);}
    foreach(var t in clone.GetComponentsInChildren<TrailRenderer>(true)){t.emitting=false;t.Clear();Object.DestroyImmediate(t);}
    var named=clone.GetComponentsInChildren<Transform>(true).GroupBy(t=>t.name).ToDictionary(g=>g.Key,g=>g.First());
    if(bank.Manifest.boneNames.Any(n=>!named.ContainsKey(n)))throw new InvalidOperationException("Death visual bone binding missing");
    var tail=holder.AddComponent<ThrallCorpseMotion>();tail.bank=bank;tail.clip=clip;tail.bones=bank.Manifest.boneNames.Select(n=>named[n]).ToArray();tail.started=ticks;tail.offset=offset;tail.born=Time.time;tail.bornFrame=Time.frameCount;
    var actor=visual.GetComponentInParent<Character>();tail.inheritedVelocity=actor?actor.GetVelocity():Vector3.zero;tail.deathForward=actor?actor.transform.forward:visual.forward;
    ThrallAudio.Safe(()=>{tail.corpseAudio=holder.AddComponent<ThrallCorpseAudio>();tail.corpseAudio.Configure(actor?actor.GetInstanceID():0,named["Head"]);});
    for(int i=0;i<58;i++){int p=i*3,q=i*4;tail.initial[i]=new Vector3(initialP[p],initialP[p+1],initialP[p+2]);tail.initialRotations[i]=new Quaternion(initialQ[q],initialQ[q+1],initialQ[q+2],initialQ[q+3]);tail.bones[i].localPosition=tail.initial[i];tail.bones[i].localRotation=tail.initialRotations[i];tail.bones[i].localScale=new Vector3(bank.Manifest.restScales[p],bank.Manifest.restScales[p+1],bank.Manifest.restScales[p+2]);}
    tail.remaining=ThrallDeathPolicy.Remaining(clip.duration,offset,ThrallMotionPolicy.Elapsed(ticks,ThrallAudio.Now,1));
    tail.support=clone.GetComponentsInChildren<SkinnedMeshRenderer>(true).Where(s=>s.enabled&&s.sharedMesh).Select(s=>new SkinSupport(s)).ToArray();
    if(tail.support.Length==0)throw new InvalidOperationException("Death skin support unavailable");
    tails.Add(tail);holder.SetActive(true);tail.Measure(true);Object.Destroy(holder,ThrallDeathPolicy.Lifetime(tail.remaining)+.5f);
   }catch{Object.Destroy(holder);throw;}
  }
  void Measure(bool full){
   bool anyBody=false,anyBounds=false;Vector3 min=Vector3.zero;Bounds bounds=default;
   foreach(var skin in support){skin.Palette();if(full)skin.SelectSupport();var point=skin.Lowest();if(skin.GroundBody){if(!anyBody||point.y<min.y)min=point;anyBody=true;}if(full){if(!anyBounds)bounds=skin.Bounds;else bounds.Encapsulate(skin.Bounds);}anyBounds=true;}
   if(!anyBody)return;lowest=min;if(full){coverage=bounds;hasCoverage=true;nextProbe=Time.time+ThrallDeathPolicy.ProbeInterval;if(ragdoll==null)ProbeFloor(min);}
  }
  void ProbeFloor(Vector3 point){
   var origin=point+Vector3.up*.75f;if(floorKnown)origin.y=Mathf.Max(origin.y,floorY+.75f);
   int count=Physics.RaycastNonAlloc(origin,Vector3.down,hits,14f,FloorMask,QueryTriggerInteraction.Ignore);float best=float.NegativeInfinity;
   for(int i=0;i<count;i++){var h=hits[i];if(!h.collider||h.normal.y<.45f||h.collider.GetComponentInParent<Character>())continue;if(h.point.y<=origin.y+.001f)best=Mathf.Max(best,h.point.y);}
   if(!float.IsNegativeInfinity(best)){floorY=best;floorKnown=true;}
  }
  void LateUpdate(){
   if(expired||bank==null||clip==null||bones==null)return;float age=Time.time-born,elapsed=ThrallMotionPolicy.Elapsed(started,ThrallAudio.Now,1);
   if(ragdoll==null){bank.Sample(clip,Math.Min(offset+elapsed,clip.duration),poses,rotations);float blend=Mathf.Clamp01(age/ThrallDeathPolicy.PoseBlendSeconds);for(int i=0;i<58;i++){bones[i].localPosition=Vector3.Lerp(initial[i],poses[i],blend);bones[i].localRotation=Quaternion.Slerp(initialRotations[i],rotations[i],blend);int s=i*3;bones[i].localScale=new Vector3(bank.Manifest.restScales[s],bank.Manifest.restScales[s+1],bank.Manifest.restScales[s+2]);}
    if(!ragdollAttempted&&ThrallDeathPolicy.BeginPhysics(age,Time.frameCount>bornFrame)){ragdollAttempted=true;try{ragdoll=new ThrallCorpseRagdoll(bones,bank.Manifest.boneNames,inheritedVelocity,deathForward,corpseAudio);ThrallSourceMotion.Log?.Invoke("BT_CORPSE_SETTLE_STARTED clip="+clip.id+" bodies=15 joints=14 handoffAge="+age+" sourceSeconds="+(offset+elapsed));}catch(Exception error){ThrallSourceMotion.Log?.Invoke("BT_CORPSE_SETTLE_FAILED "+error.GetBaseException().Message);}}
   }
   if(ragdoll!=null)ragdoll.CopyPose();
   Measure(Time.time>=nextProbe);
   if(ragdoll==null&&floorKnown&&age>.08f){var p=transform.position;float target=p.y+floorY+ThrallDeathPolicy.FloorGap-lowest.y;float y=ThrallDeathPolicy.Settle(p.y,target,ref fallSpeed,Mathf.Min(Time.deltaTime,.1f));float dy=y-p.y;p.y=y;transform.position=p;lowest.y+=dy;if(hasCoverage)coverage.center+=Vector3.up*dy;}
   // Once masking smoke begins, cleanup is committed even if the body wakes
   // again. Cached coverage is refreshed above; failed creation must not force
   // another full skin scan on every rendered frame.
   bool canFinish=finishing||(ragdoll!=null?ragdoll.CanFinish:ragdollAttempted);
   if(canFinish&&age>=remaining+ThrallDeathPolicy.SmokeStartSeconds&&!puff&&Time.time>=nextPuffAttempt){nextPuffAttempt=Time.time+.25f;puff=ThrallDeathPuff.Create(coverage,false);if(puff){finishing=true;ThrallSourceMotion.Log?.Invoke("BT_CORPSE_RED_PUFF clip="+clip.id+" settled="+(ragdoll!=null&&ragdoll.Settled));}}
   if(puff){puff.transform.position=coverage.center;if(canFinish&&ThrallDeathPolicy.Hide(age,remaining,Time.time-puff.Began,puff.HasParticles,Time.frameCount>puff.StartedFrame))Expire(false);}
   if(!expired&&age>=ThrallDeathPolicy.Lifetime(remaining))Expire(false);
  }
  void Expire(bool capacity){
   if(expired)return;if(!puff){if(support!=null)Measure(true);puff=ThrallDeathPuff.Create(coverage,capacity);}expired=true;
   foreach(var renderer in GetComponentsInChildren<Renderer>(true))renderer.enabled=false;if(puff)puff.Release();tails.Remove(this);Object.Destroy(gameObject);
  }
  void OnDestroy(){ragdoll?.Dispose();if(puff)puff.Release();tails.Remove(this);}
  public static void Shutdown(){foreach(var tail in tails.ToArray())if(tail){tail.enabled=false;Object.Destroy(tail.gameObject);}tails.Clear();ThrallDeathPuff.Shutdown();SkinSupport.ClearCache();}
  // Full skin support selection is throttled. Twelve retained candidate vertices
  // per renderer follow every pose frame; no BakeMesh or per-frame allocations.
  sealed class SkinSupport {
   static readonly Dictionary<Mesh,SupportVertices> cache=new Dictionary<Mesh,SupportVertices>();
   readonly Transform[] bones;readonly Matrix4x4[] bind,palette;readonly Vector3[] vertices;readonly BoneWeight[] weights;
   readonly int[] candidates=new int[12];readonly float[] heights=new float[12];public Bounds Bounds;public readonly bool GroundBody;
   public SkinSupport(SkinnedMeshRenderer skin){var mesh=skin.sharedMesh;bones=skin.bones;bind=mesh.bindposes;palette=new Matrix4x4[bones.Length];if(!cache.TryGetValue(mesh,out var data)){data=new SupportVertices(mesh);cache.Add(mesh,data);}vertices=data.Vertices;weights=data.Weights;GroundBody=!skin.name.StartsWith("BT1_Maul",StringComparison.Ordinal);if(weights.Length!=vertices.Length||bind.Length!=bones.Length)throw new InvalidOperationException("Death skin weights differ");}
   public static void ClearCache(){cache.Clear();}
   readonly struct VertexKey:IEquatable<VertexKey>{readonly Vector3 p;readonly BoneWeight w;public VertexKey(Vector3 p,BoneWeight w){this.p=p;this.w=w;}public bool Equals(VertexKey b)=>p.Equals(b.p)&&w.Equals(b.w);public override bool Equals(object b)=>b is VertexKey other&&Equals(other);public override int GetHashCode()=>unchecked(p.GetHashCode()*397^w.GetHashCode());}
   sealed class SupportVertices{public readonly Vector3[] Vertices;public readonly BoneWeight[] Weights;public SupportVertices(Mesh mesh){var v=mesh.vertices;var w=mesh.boneWeights;if(v.Length!=w.Length)throw new InvalidOperationException("Death skin source weights differ");var seen=new HashSet<VertexKey>();var vs=new List<Vector3>();var ws=new List<BoneWeight>();for(int i=0;i<v.Length;i++)if(seen.Add(new VertexKey(v[i],w[i]))){vs.Add(v[i]);ws.Add(w[i]);}Vertices=vs.ToArray();Weights=ws.ToArray();}}
   public void Palette(){for(int i=0;i<bones.Length;i++)palette[i]=bones[i].localToWorldMatrix*bind[i];}
   Vector3 Point(int i){var w=weights[i];var v=vertices[i];Vector3 p=Vector3.zero;if(w.weight0>0)p+=palette[w.boneIndex0].MultiplyPoint3x4(v)*w.weight0;if(w.weight1>0)p+=palette[w.boneIndex1].MultiplyPoint3x4(v)*w.weight1;if(w.weight2>0)p+=palette[w.boneIndex2].MultiplyPoint3x4(v)*w.weight2;if(w.weight3>0)p+=palette[w.boneIndex3].MultiplyPoint3x4(v)*w.weight3;return p;}
   public void SelectSupport(){for(int k=0;k<12;k++){candidates[k]=-1;heights[k]=float.PositiveInfinity;}for(int i=0;i<vertices.Length;i++){var p=Point(i);if(i==0)Bounds=new Bounds(p,Vector3.zero);else Bounds.Encapsulate(p);if(p.y>=heights[11])continue;int j=11;while(j>0&&p.y<heights[j-1]){heights[j]=heights[j-1];candidates[j]=candidates[j-1];j--;}heights[j]=p.y;candidates[j]=i;}}
   public Vector3 Lowest(){var result=new Vector3(0,float.PositiveInfinity,0);foreach(int i in candidates)if(i>=0){var p=Point(i);if(p.y<result.y)result=p;}return result;}
  }
 }
}
