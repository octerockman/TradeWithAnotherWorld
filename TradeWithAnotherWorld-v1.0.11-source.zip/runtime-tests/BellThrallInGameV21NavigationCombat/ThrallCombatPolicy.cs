using System;
namespace BlackAbbey.BellThrall {
 public static class ThrallCombatPolicy {
  public const float BellDamage=8f;
  public const float AttackSpeed=.70f,Recovery=1.15f,BellDuration=4.1f,RingTime=1.83f,BellCooldown=16f,BellRange=8f,DeafenSeconds=8f,RegenMultiplier=.75f;
  public static bool Contact(float phase,float release)=>phase>=Math.Max(0,release-.12f)&&phase<=Math.Min(.94f,release+.14f);
  public static bool CanBell(bool owner,bool alive,bool attacking,bool staggered,bool sight,float distance,float now,float ready)=>owner&&alive&&!attacking&&!staggered&&sight&&distance>=.5f&&distance<=BellRange&&now>=ready;
  public static bool Crossed(float previous,float now,float eventTime)=>previous<eventTime&&now>=eventTime;
  public static float BellWeight(float elapsed)=>Math.Max(0,Math.Min(1,Math.Min(elapsed/.25f,(BellDuration-elapsed)/.30f)));
  public static int SweepSteps(float distance,float angle,float minimumHalfExtent)=>Math.Max(1,Math.Min(24,Math.Max((int)Math.Ceiling(distance/Math.Max(.05f,minimumHalfExtent)),(int)Math.Ceiling(angle/8f))));
  public static bool SafeSweep(float distance,float dt)=>distance<=3f&&dt>0&&dt<=.25f;
 }
}
