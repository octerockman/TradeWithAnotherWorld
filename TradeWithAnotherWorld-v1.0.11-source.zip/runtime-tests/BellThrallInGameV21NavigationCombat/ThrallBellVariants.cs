using System;using System.Collections.Generic;using System.IO;using System.Linq;using Newtonsoft.Json;
namespace BlackAbbey.BellThrall {
 [Serializable]public sealed class ThrallBellVariantRecord {public string id,file,sha256,sourceAction;public FileRecord sourceNative;public float duration,ringTime;}
 [Serializable]public sealed class ThrallBellVariantManifest {public string schema;public ThrallBellVariantRecord[] variants;}
 public sealed class ThrallBellVariants {
  public const string IndexSha256="45a46b1e3bff68b2fdd1c525d1b9fba692e28723888e89d8ee39ff0e4eec8934";
  readonly Dictionary<int,BellMotionBank> banks=new Dictionary<int,BellMotionBank>();
  readonly BellMotionBank legacy;
  ThrallBellVariants(BellMotionBank old){legacy=old;}
  public BellMotionBank Get(int variant)=>variant==0?legacy:banks.TryGetValue(variant,out var bank)?bank:null;
  public static ThrallBellVariants Read(string folder,BellMotionBank legacy){
   string path=Path.Combine(folder,"bell-variants.json");if(ThrallVisual.Hash(path)!=IndexSha256)throw new InvalidDataException("Bell variant index differs from approved source");
   var manifest=JsonConvert.DeserializeObject<ThrallBellVariantManifest>(File.ReadAllText(path),new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MaxDepth=16});
   if(manifest?.schema!="bell-thrall.bell-variants.v1"||manifest.variants?.Length!=3||manifest.variants.Select(v=>v?.id).Distinct().Count()!=3)throw new InvalidDataException("Unexpected bell variant inventory");
   var result=new ThrallBellVariants(legacy);
   for(int i=1;i<=3;i++){
    string id=((char)('A'+i)).ToString();var row=manifest.variants.SingleOrDefault(v=>v.id==id);string expected="bell-variant-"+id.ToLowerInvariant()+".json";
    if(row==null||row.file!=expected||Path.GetFileName(row.file)!=row.file||string.IsNullOrEmpty(row.sha256))throw new InvalidDataException("Missing approved bell variant "+id);
    string file=Path.Combine(folder,row.file);if(ThrallVisual.Hash(file)!=row.sha256)throw new InvalidDataException("Bell variant hash differs: "+id);
    var bank=ThrallBellMotion.ReadVariant(file);
    if(!bank.boneNames.SequenceEqual(legacy.boneNames)||Math.Abs(bank.duration-row.duration)>.00001f||Math.Abs(bank.ringTime-row.ringTime)>.00001f||bank.sourceNative?.sha256!=row.sourceNative?.sha256||bank.sourceAction!=row.sourceAction)throw new InvalidDataException("Bell variant source/timing/binding differs: "+id);
    result.banks.Add(i,bank);
   }
   return result;
  }
 }
}
