using System;
using System.Collections.Generic;
namespace BlackAbbey.BellThrall {
 // Horizontal admission estimates only. Facing, height, clearance and actual sweeps remain separate.
 // Final world metres at 0.75 size. Do not scale this table again.
 // Frozen V6F poses, actual hammer and complete-route gain before bounded 60Hz advance.
 public static class ThrallTacticsReachData {
  public const string EvidenceSha256="bbb44395b9d3ff6983da56dff08e5765d17b647952cc2186cbe801421063e8e1";
  public const string ManifestSha256="236b999e25bcb5aa28f176e4eb71fa5a493ed87e772d19e91c71170a3d093b39";
  public const float MaximumAll=4.50f;
  public const int Count=29;
  static readonly Dictionary<string,float> Values=new Dictionary<string,float>(StringComparer.Ordinal) {
   {"a000_003000",4.50f},
   {"a000_003001",3.60f},
   {"a000_003002",3.50f},
   {"a000_003003",3.30f},
   {"a000_003004",1.65f},
   {"a000_003005",3.40f},
   {"a000_003006",4.40f},
   {"a000_003007",3.20f},
   {"a000_003008",3.35f},
   {"a000_003009",3.65f},
   {"a000_003010",3.95f},
   {"a000_003011",3.55f},
   {"a000_003012",3.45f},
   {"a000_003013",3.25f},
   {"a000_003015",2.85f},
   {"a000_003016",3.00f},
   {"a000_003017",2.90f},
   {"a000_003018",3.25f},
   {"a000_003021",1.50f},
   {"a000_003022",1.60f},
   {"a000_003023",2.20f},
   {"a000_003024",2.05f},
   {"a000_003025",0.00f},
   {"a000_003026",2.15f},
   {"a000_003030",4.10f},
   {"a000_003031",3.65f},
   {"a000_003033",3.90f},
   {"a000_004100",1.85f},
   {"a000_004101",2.50f},
  };
  public static float Maximum(string id)=>id!=null&&Values.TryGetValue(id,out var value)?value:0f;
 }
}
