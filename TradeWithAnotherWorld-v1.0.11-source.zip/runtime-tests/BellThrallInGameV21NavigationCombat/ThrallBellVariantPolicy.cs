using System;using System.Globalization;
namespace BlackAbbey.BellThrall {
 public readonly struct ThrallBellEpisode {
  public readonly int Sequence,Variant;public readonly long Started;public readonly bool Active;
  public ThrallBellEpisode(int sequence,long started,int variant,bool active){Sequence=sequence;Started=started;Variant=variant;Active=active;}
  public ThrallBellEpisode Stop()=>new ThrallBellEpisode(Sequence,Started,Variant,false);
 }
 public static class ThrallBellVariantPolicy {
  public const string StateKey="bt_bell_motion_v1";
  public static int Choose(uint actorIdentity,int sequence){if(sequence<=0)throw new ArgumentOutOfRangeException(nameof(sequence));return 1+(int)((actorIdentity%3+(uint)((sequence-1)%3))%3);}
  public static string Encode(ThrallBellEpisode e){if(e.Sequence<=0||e.Started<=0||e.Variant<1||e.Variant>3)throw new ArgumentException("Invalid bell episode");return "1|"+e.Sequence.ToString(CultureInfo.InvariantCulture)+"|"+e.Started.ToString(CultureInfo.InvariantCulture)+"|"+e.Variant.ToString(CultureInfo.InvariantCulture)+"|"+(e.Active?"1":"0");}
  public static bool TryRead(string text,out ThrallBellEpisode e){
   e=default;if(string.IsNullOrEmpty(text)||text.Length>100)return false;var p=text.Split('|');
   if(p.Length!=5||p[0]!="1"||!int.TryParse(p[1],NumberStyles.None,CultureInfo.InvariantCulture,out int sequence)||sequence<=0||!long.TryParse(p[2],NumberStyles.None,CultureInfo.InvariantCulture,out long started)||started<=0||!int.TryParse(p[3],NumberStyles.None,CultureInfo.InvariantCulture,out int variant)||variant<1||variant>3||(p[4]!="0"&&p[4]!="1"))return false;
   e=new ThrallBellEpisode(sequence,started,variant,p[4]=="1");return true;
  }
  public static long ReleaseTick(ThrallBellEpisode e,float ring)=>e.Started+(long)Math.Round((double)ring*10000000d,MidpointRounding.AwayFromZero);
  public static ThrallBellEpisode PreserveVariant(ThrallBellEpisode current,ThrallBellEpisode observed)=>current.Sequence==observed.Sequence&&current.Started==observed.Started?new ThrallBellEpisode(observed.Sequence,observed.Started,current.Variant,observed.Active):observed;
  public static float Weight(float elapsed,float duration)=>Math.Max(0,Math.Min(1,Math.Min(elapsed/.25f,(duration-elapsed)/.30f)));
  public static float WarningStart(float ring)=>Math.Max(0,ring-1.63f);
  public static float WarningAdmissionEnd(float ring)=>Math.Max(0,ring-.88f);
  public static float WarningEnd(float ring)=>Math.Max(0,ring-.68f);
  public static float HeaveStart(float ring)=>Math.Max(0,ring-.33f);
  public static float HeaveEnd(float ring)=>ring+.02f;
  public static bool Warning(long started,long enabled,float elapsed,float ring,bool active,bool live,bool staggered)=>started>=enabled&&elapsed>=WarningStart(ring)&&elapsed<WarningAdmissionEnd(ring)&&active&&live&&!staggered;
 }
 // Every observer advances its sample history. New owners seed the current phase
 // instead of replaying a release crossed before ownership/enable.
 public sealed class ThrallBellEpisodeGate {
  long enabled,owner;ThrallBellEpisode episode;float previous;bool observed;
  public void Enable(long now,long currentOwner){enabled=now;owner=currentOwner;observed=false;previous=0;episode=default;}
  public bool Step(ThrallBellEpisode value,float elapsed,float ring,float duration,long currentOwner){
   if(float.IsNaN(elapsed)||float.IsInfinity(elapsed)||float.IsNaN(ring)||float.IsInfinity(ring)||ring<=0||ring>=duration)return false;
   bool changed=!observed||value.Sequence!=episode.Sequence||value.Started!=episode.Started||value.Variant!=episode.Variant;
   bool ownerChanged=currentOwner!=owner;
   if(changed||ownerChanged){previous=changed&&!ownerChanged&&value.Started>=enabled?-.001f:elapsed;episode=value;owner=currentOwner;observed=true;}
   bool release=value.Active&&previous<ring&&elapsed>=ring&&elapsed<duration;previous=elapsed;return release;
  }
 }
}
