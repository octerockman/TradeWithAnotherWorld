using System;
using System.IO;
using System.Linq;
#if !UNITY_EDITOR
using Newtonsoft.Json;
#endif
namespace BlackAbbey.BellThrall {
 public static class ThrallPayloadReader {
  public static ThrallPayload Read(string path){
   if(new FileInfo(path).Length>64*1024*1024)throw new InvalidDataException("Oversized Thrall visual");
   string text=File.ReadAllText(path).TrimStart('\ufeff');
#if UNITY_EDITOR
   var p=UnityEngine.JsonUtility.FromJson<ThrallPayload>(text);
#else
   var p=JsonConvert.DeserializeObject<ThrallPayload>(text,new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MetadataPropertyHandling=MetadataPropertyHandling.Ignore,MaxDepth=64,CheckAdditionalContent=true});
#endif
   if(p==null||p.schema!="bell-thrall.runtime-visual.v2"||p.totalTriangles!=32838||p.bodyTriangles!=30839||p.renderers?.Length!=3||p.items?.Length!=0||p.materials?.Length!=3||p.nodes==null||p.humanDescription?.human?.Length!=38||p.containsAnimationClips||p.containsGameOwnedMeshes)throw new InvalidDataException("Unexpected Thrall source inventory");
   if(p.sourceNative?.sha256?.Length!=64||p.humanDescription.human.Any(h=>h.humanName.StartsWith("Right ",StringComparison.Ordinal))||!p.nodes.Any(n=>n.name=="BT1_Maul_Main_Grip")||p.nodes.Any(n=>n.name.Contains("Offhand")))throw new InvalidDataException("Thrall authority or one-handed grip differs");
   // Unity's editor serializer emits empty records for absent optional maps.
   // Normalize those explicitly so the managed player reader uses the same policy.
   foreach(var m in p.materials){m.diffuse=Optional(m.diffuse);m.normal=Optional(m.normal);m.metallicGloss=Optional(m.metallicGloss);}
   return p;
  }
  static FileRecord Optional(FileRecord f){if(f==null)return null;if(string.IsNullOrEmpty(f.path)&&string.IsNullOrEmpty(f.sha256))return null;if(string.IsNullOrWhiteSpace(f.path)||f.sha256?.Length!=64)throw new InvalidDataException("Incomplete Thrall texture");return f;}
 }
}
