using System;
namespace BlackAbbey.BellThrall {
 public static class ThrallReactionPolicy {
  public const float StaggerHealthFraction=.60f,OrdinaryExitGap=.35f;
  public static readonly string[] OrdinaryIds={"a000_008033","a000_008034"};
  public static readonly string[] NativeIds={"a000_008140","a000_008141","a000_008142","a000_008143"};
 }
 public sealed class ThrallReactionGate {
  bool nativeEpisode;
  public float NextOrdinaryAt {get;private set;}
  public int NativeEpisodes {get;private set;}
  public int OrdinaryEpisodes {get;private set;}
  public void Reset(float now,bool alreadyStaggering=false){nativeEpisode=alreadyStaggering;NextOrdinaryAt=now+.15f;NativeEpisodes=OrdinaryEpisodes=0;}
  public bool TryOrdinary(float now,bool reactionBusy,bool nativeStagger,bool bell,bool attack){return Finite(now)&&now>=NextOrdinaryAt&&!reactionBusy&&!nativeStagger&&!bell&&!attack;}
  // Observe every native state, including idle and non-HP parries. A fresh native
  // episode bypasses the ordinary cooldown but never restarts itself every hit.
  public bool TryNative(bool staggering){if(!staggering){nativeEpisode=false;return false;}if(nativeEpisode)return false;nativeEpisode=true;NativeEpisodes++;return true;}
  public void Admit(float now,float duration,bool native=false){if(!Finite(now)||!Finite(duration)||duration<=0)return;NextOrdinaryAt=Math.Max(NextOrdinaryAt,now+duration+ThrallReactionPolicy.OrdinaryExitGap);if(!native)OrdinaryEpisodes++;}
  static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
 }
}
