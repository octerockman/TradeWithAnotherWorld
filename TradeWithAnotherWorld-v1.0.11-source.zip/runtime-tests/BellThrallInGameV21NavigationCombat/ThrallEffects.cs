using System;using System.IO;using System.Linq;using System.Collections.Generic;using UnityEngine;using UnityEngine.Audio;using Object=UnityEngine.Object;
namespace BlackAbbey.BellThrall {
 public sealed class SE_ThrallDeafened:StatusEffect {public override void ModifyStaminaRegen(ref float regen){regen*=ThrallCombatPolicy.RegenMultiplier;}}
 public static class ThrallEffects {
  public const string StatusName="BA_ThrallLesserDeafened";public static Material Material;public static Sprite Icon;public static AudioClip Bell,DryHit;public static AudioClip[] Swishes=Array.Empty<AudioClip>();public static AudioMixerGroup Mixer;static Texture2D iconTexture;
  public static AudioClip Idle,CombatBreath,Alert,Effort,QuickEffort,OverheadEffort,Body,Warning,Death,HurtLight,HurtHeavy,BellHeave,Leather,Frame,Iron;
  public static AudioClip[] LightAir=Array.Empty<AudioClip>(),OverheadAir=Array.Empty<AudioClip>(),RecoveryAir=Array.Empty<AudioClip>(),Steps=Array.Empty<AudioClip>(),Landings=Array.Empty<AudioClip>(),Staggers=Array.Empty<AudioClip>();
  static readonly List<AudioClip> ownedCues=new List<AudioClip>();
  public static void Initialize(string folder,GameObject nativeWeapon){
   var data=nativeWeapon.GetComponent<ItemDrop>().m_itemData.m_shared;var effects=new[]{data.m_startEffect,data.m_trailStartEffect,data.m_attack.m_startEffect,data.m_attack.m_triggerEffect};var prefabs=effects.Where(e=>e!=null).SelectMany(e=>e.m_effectPrefabs??Array.Empty<EffectList.EffectData>()).Where(e=>e?.m_prefab).Select(e=>e.m_prefab).Distinct().ToArray();
   Swishes=prefabs.SelectMany(p=>p.GetComponentsInChildren<ZSFX>(true)).SelectMany(s=>s.m_audioClips??Array.Empty<AudioClip>()).Where(c=>c).Distinct().ToArray();Mixer=prefabs.SelectMany(p=>p.GetComponentsInChildren<AudioSource>(true)).Select(s=>s.outputAudioMixerGroup).FirstOrDefault(m=>m);
   var shader=Shader.Find("Sprites/Default")??Shader.Find("Legacy Shaders/Particles/Additive")??Shader.Find("Particles/Standard Unlit");if(!shader)throw new InvalidDataException("No native-compatible swish shader");Material=new Material(shader){name="BT_Model_Synced_Amber_Trail"};
   Bell=ReadWav(Path.Combine(folder,"Thrall-Back-Bell.wav"));Swishes=new[]{ReadWav(Path.Combine(folder,"Thrall-Hammer-Air.wav"))};DryHit=ReadWav(Path.Combine(folder,"Thrall-Dry-Hit.wav"));iconTexture=new Texture2D(64,64,TextureFormat.RGBA32,false);var pixels=new Color[4096];for(int y=0;y<64;y++)for(int x=0;x<64;x++){float u=(x-31.5f)/31.5f,v=y/63f;float radius=.23f+.38f*Mathf.Pow(1-v,2);bool bell=v>.22f&&v<.83f&&Mathf.Abs(Mathf.Abs(u)-radius)<.055f;bool baseLine=v>.19f&&v<.25f&&Mathf.Abs(u)<.61f;bool clapper=v>.10f&&v<.18f&&Mathf.Abs(u)<.1f;pixels[y*64+x]=bell||baseLine||clapper?new Color(1,.62f,.16f,1):Color.clear;}iconTexture.SetPixels(pixels);iconTexture.Apply();Icon=Sprite.Create(iconTexture,new Rect(0,0,64,64),new Vector2(.5f,.5f));
  }
  public static void InitializeAdditional(string folder){
   Func<string,AudioClip> load=id=>ReadWav(Path.Combine(folder,ThrallAudioAssets.File(id)));
   Idle=load("voice_idle");CombatBreath=load("voice_combat");Alert=load("voice_alert");Effort=load("effort_drag");QuickEffort=load("effort_quick");OverheadEffort=load("effort_overhead");
   HurtLight=load("hurt_light");HurtHeavy=load("hurt_heavy");Death=load("voice_death");BellHeave=load("bell_heave");Staggers=new[]{load("voice_stagger_A"),load("voice_stagger_B")};
   Body=load("hammer_hit_body");Warning=load("bell_warning");Leather=load("gear_leather");Frame=load("gear_frame");Iron=load("iron_settle");
   LightAir=new[]{load("air_light_A"),load("air_light_B")};OverheadAir=new[]{load("air_overhead_A"),load("air_overhead_B")};RecoveryAir=new[]{load("air_recovery_A"),load("air_recovery_B")};
   Steps=new[]{load("step_stone_A"),load("step_stone_B"),load("step_stone_C")};Landings=new[]{load("body_land_stone_A"),load("body_land_stone_B")};
   if(ownedCues.Count!=ThrallAudioAssets.CueCount)throw new InvalidDataException("Incomplete approved Thrall audio bank");
  }
  public static AudioClip Air(int weight,int variant){var clips=weight==2?OverheadAir:weight==0?LightAir:Swishes;return clips.Length==0?null:clips[(variant&int.MaxValue)%clips.Length];}
  public static AudioClip ReadWav(string path){var clip=ThrallCueReader.Read(path,ThrallSourceContract.AudioHash(Path.GetFileName(path)));ownedCues.Add(clip);return clip;}
  public static AudioSource Audio(Transform parent){var s=parent.gameObject.AddComponent<AudioSource>();s.playOnAwake=false;s.spatialBlend=1;s.rolloffMode=AudioRolloffMode.Logarithmic;s.minDistance=2;s.maxDistance=35;s.outputAudioMixerGroup=Mixer;s.volume=.8f;return s;}
  public static void Ring(Vector3 at,float age,Character owner){var go=new GameObject("BT_Bell_Pulse");go.transform.position=at;var pulse=go.AddComponent<ThrallBellPulse>();pulse.owner=owner;pulse.age=age;var audio=Audio(go.transform);if(age<.25f){audio.clip=Bell;audio.time=Mathf.Max(0,age);audio.Play();}pulse.Initialize();}
  public static void Shutdown(){if(Material)Object.Destroy(Material);foreach(var cue in ownedCues)if(cue)Object.Destroy(cue);ownedCues.Clear();Bell=null;DryHit=null;Swishes=Array.Empty<AudioClip>();Idle=CombatBreath=Alert=Effort=QuickEffort=OverheadEffort=Body=Warning=Death=HurtLight=HurtHeavy=BellHeave=Leather=Frame=Iron=null;LightAir=OverheadAir=RecoveryAir=Steps=Landings=Staggers=Array.Empty<AudioClip>();if(Icon)Object.Destroy(Icon);if(iconTexture)Object.Destroy(iconTexture);}
 }
 public sealed class ThrallBellPulse:MonoBehaviour {
  public float age;public Character owner;LineRenderer[] rings;bool applied;
  public void Initialize(){rings=new LineRenderer[3];for(int i=0;i<3;i++){var child=new GameObject("Amber sound wave "+i);child.transform.SetParent(transform,false);var line=child.AddComponent<LineRenderer>();line.sharedMaterial=ThrallEffects.Material;line.loop=true;line.useWorldSpace=false;line.positionCount=72;line.widthMultiplier=.055f;line.startColor=line.endColor=new Color(1,.6f,.18f,.65f);rings[i]=line;}}
  void Update(){age+=Time.deltaTime;float radius=Mathf.Min(ThrallCombatPolicy.BellRange,age*16f);if(age<.65f&&rings!=null)for(int i=0;i<rings.Length;i++){rings[i].enabled=true;var color=new Color(1,.6f,.18f,Mathf.Clamp01(1-age/.65f)*.65f);rings[i].startColor=rings[i].endColor=color;for(int j=0;j<72;j++){float a=j*Mathf.PI*2/72;var v=new Vector3(Mathf.Cos(a),0,Mathf.Sin(a))*radius;rings[i].SetPosition(j,i==0?v:i==1?new Vector3(v.x,v.z,0):new Vector3(0,v.x,v.z));}}else if(rings!=null)foreach(var line in rings)line.enabled=false;
   if(age>.65f)applied=true;
   if(!applied){var player=Player.m_localPlayer;if(player&&!player.IsDead()&&!player.InGhostMode()){var view=player.GetComponent<ZNetView>();float distance=Vector3.Distance(transform.position,player.GetCenterPoint());if(view&&view.IsValid()&&view.IsOwner()&&distance<=radius&&distance<=ThrallCombatPolicy.BellRange&&!Physics.Linecast(transform.position,player.GetCenterPoint(),ThrallCombat.SolidMask,QueryTriggerInteraction.Ignore)){applied=true;
      if(owner){var hit=new HitData{m_point=player.GetCenterPoint(),m_dir=(player.GetCenterPoint()-transform.position).normalized,m_dodgeable=true,m_blockable=false,m_staggerMultiplier=.2f,m_hitType=HitData.HitType.EnemyHit};hit.m_damage.m_blunt=ThrallCombatPolicy.BellDamage;hit.SetAttacker(owner);player.Damage(hit);ThrallCombat.Log?.Invoke("BT_BELL_DAMAGE_SUBMITTED damage="+ThrallCombatPolicy.BellDamage);}
      var effects=player.GetSEMan();bool stronger=effects.GetStatusEffects().Any(s=>s&&s.name!=ThrallEffects.StatusName&&(s.name.IndexOf("deafen",StringComparison.OrdinalIgnoreCase)>=0||(s.m_name??"").IndexOf("deafen",StringComparison.OrdinalIgnoreCase)>=0));if(!stronger)effects.AddStatusEffect(ThrallEffects.StatusName.GetStableHashCode(),true);}}}
   if(age>6)Destroy(gameObject);
  }
 }
}
