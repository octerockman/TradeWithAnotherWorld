using System;
namespace BlackAbbey.BellThrall {
 public static class ThrallMotorPolicy {
  public static float MovingFriction(float slippage)=>.4f*(1f-Math.Max(0,Math.Min(1,slippage)));
  public static bool MayMove(bool eligible,bool restored,bool grounded,bool bodyEnabled,float allowed)=>eligible&&!restored&&grounded&&bodyEnabled&&!float.IsNaN(allowed)&&!float.IsInfinity(allowed)&&allowed>.00001f;
 }
}
