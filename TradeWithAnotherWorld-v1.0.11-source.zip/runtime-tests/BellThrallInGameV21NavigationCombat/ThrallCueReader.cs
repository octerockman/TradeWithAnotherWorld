using System;using System.IO;using System.Security.Cryptography;using UnityEngine;
namespace BlackAbbey.BellThrall {
 public static class ThrallCueReader {
  public static AudioClip Read(string path,string expectedSha256){
   byte[] bytes=File.ReadAllBytes(path);using(var hash=SHA256.Create()){string actual=BitConverter.ToString(hash.ComputeHash(bytes)).Replace("-","").ToLowerInvariant();if(actual!=expectedSha256)throw new InvalidDataException("Thrall cue checksum differs: "+Path.GetFileName(path));}
   using(var r=new BinaryReader(new MemoryStream(bytes))){
    if(bytes.Length<44||new string(r.ReadChars(4))!="RIFF")throw new InvalidDataException("Cue RIFF header");int declared=r.ReadInt32();if(declared!=bytes.Length-8||new string(r.ReadChars(4))!="WAVE")throw new InvalidDataException("Cue WAVE extent");
    int channels=0,rate=0,bits=0,format=0,block=0;byte[] data=null;
    while(r.BaseStream.Position+8<=r.BaseStream.Length){string id=new string(r.ReadChars(4));int n=r.ReadInt32();long begin=r.BaseStream.Position,end=begin+n;if(n<0||end>r.BaseStream.Length)throw new InvalidDataException("Cue chunk extent");
     if(id=="fmt "){if(n<16)throw new InvalidDataException("Cue format size");format=r.ReadInt16();channels=r.ReadInt16();rate=r.ReadInt32();r.ReadInt32();block=r.ReadInt16();bits=r.ReadInt16();}else if(id=="data"){if(data!=null)throw new InvalidDataException("Duplicate cue data");data=r.ReadBytes(n);}r.BaseStream.Position=end+(n&1);
    }
    if(format!=1||channels!=1||bits!=16||block!=2||rate!=48000||data==null||data.Length==0||data.Length%2!=0||data.Length>2000000)throw new InvalidDataException("Expected bounded48k monoPCM16 Thrall cue");
    var samples=new float[data.Length/2];for(int i=0;i<samples.Length;i++)samples[i]=BitConverter.ToInt16(data,i*2)/32768f;var clip=AudioClip.Create("BT_"+Path.GetFileNameWithoutExtension(path),samples.Length,1,rate,false);if(!clip.SetData(samples,0)){UnityEngine.Object.Destroy(clip);throw new InvalidDataException("Cue PCM upload failed");}return clip;
   }
  }
 }
}
