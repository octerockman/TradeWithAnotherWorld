using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Jotunn.Entities;
using Jotunn.Managers;
using Jotunn.Utils;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbey.BellThrall {
 // Only the own actor receives new containers/entries. Borrowed vanilla effect
 // prefabs and native voice recordings are never edited or exported.
 public static class ThrallNativeVoice {
  static readonly Dictionary<GameObject,GameObject> forks=new Dictionary<GameObject,GameObject>();
  static readonly MethodInfo Clone=typeof(object).GetMethod("MemberwiseClone",BindingFlags.Instance|BindingFlags.NonPublic);
  static bool Sound(GameObject p)=>p&&(p.GetComponentInChildren<AudioSource>(true)||p.GetComponentInChildren<ZSFX>(true));
  static bool Visual(GameObject p)=>p&&(p.GetComponentInChildren<Renderer>(true)||p.GetComponentInChildren<ParticleSystem>(true)||p.GetComponentInChildren<Light>(true));
  static GameObject Silent(GameObject source){
   if(forks.TryGetValue(source,out var known)&&known)return known;
   if(source.GetComponentInChildren<Character>(true)||source.GetComponentInChildren<Ragdoll>(true)||source.GetComponentInChildren<Projectile>(true)||source.GetComponentInChildren<Aoe>(true)||source.GetComponentInChildren<EffectArea>(true)||source.GetComponentsInChildren<ZNetView>(true).Any(v=>v.gameObject!=source))throw new InvalidOperationException("Unexpected actor/damage content in native voice visual: "+source.name);
   var manager=PrefabManager.Instance;string name="BA_Thrall_SilentVoice_"+source.name;
   if(ModQuery.GetPrefab(name)!=null)throw new InvalidOperationException("Own voice fork already registered: "+name);
   var fork=manager.CreateClonedPrefab(name,source);
   if(!fork||fork==source||!fork.transform.parent||fork.activeInHierarchy)throw new InvalidOperationException("Voice fork requires a private inactive prefab container");
   try{
    foreach(var s in fork.GetComponentsInChildren<AudioSource>(true)){s.Stop();s.mute=true;s.playOnAwake=false;s.volume=0;s.enabled=false;}
    foreach(var s in fork.GetComponentsInChildren<ZSFX>(true)){s.m_playOnAwake=false;s.m_minVol=s.m_maxVol=0;s.m_audioClips=Array.Empty<AudioClip>();s.m_useVibration=false;s.m_playThroughController=s.m_playThroughAllControllers=false;s.m_controllerAudioVolume=0;s.m_closedCaptionToken=s.m_secondaryCaptionToken="";s.enabled=false;}
    manager.AddPrefab(new CustomPrefab(fork,false));var published=ModQuery.GetPrefab(name);if(published?.Prefab!=fork||published.SourceMod?.GUID!=ThrallPlugin.Id)throw new InvalidOperationException("Own voice visual fork registration failed");
    forks.Add(source,fork);return fork;
   }catch{Object.Destroy(fork);throw;}
  }
  static void Filter(object target,string[] names){foreach(string name in names){
   var field=target.GetType().GetField(name,BindingFlags.Public|BindingFlags.Instance);if(field==null||field.FieldType!=typeof(EffectList))throw new MissingFieldException("Native voice field changed: "+name);
   var original=(field.GetValue(target)as EffectList)?.m_effectPrefabs??Array.Empty<EffectList.EffectData>();var kept=new List<EffectList.EffectData>();
   foreach(var e in original){if(e?.m_prefab==null)continue;var copy=(EffectList.EffectData)Clone.Invoke(e,null);
    if(Sound(e.m_prefab)){if(!Visual(e.m_prefab))continue;copy.m_prefab=Silent(e.m_prefab);}kept.Add(copy);
   }
   field.SetValue(target,new EffectList{m_effectPrefabs=kept.ToArray()});
  }}
  public static void Prepare(GameObject source,GameObject own){
   if(!source||!own||source==own)throw new InvalidOperationException("Voice replacement requires a distinct own actor clone");
   var native=source.GetComponent<Humanoid>();var ai=source.GetComponent<MonsterAI>();var target=own.GetComponent<Humanoid>();var targetAI=own.GetComponent<MonsterAI>();
   if(!native||!ai||!target||!targetAI||native==target||ai==targetAI)throw new InvalidOperationException("Native voice lifecycle unavailable");
   string h=JsonUtility.ToJson(native),a=JsonUtility.ToJson(ai);
   Filter(target,new[]{"m_deathEffects","m_backstabHitEffects","m_critHitEffects"});Filter(targetAI,new[]{"m_idleSound","m_alertedEffects","m_wakeupEffects","m_sleepEffects"});
   if(h!=JsonUtility.ToJson(native)||a!=JsonUtility.ToJson(ai))throw new InvalidOperationException("Native Troll source changed during own voice replacement");
   ThrallCombat.Log?.Invoke("BT_FULL_AUDIO_READY cues=31 ownVoiceLists=7 nativeUnchanged=true");
  }
  public static void Shutdown(){foreach(var f in forks.Values)if(f){PrefabManager.Instance.RemovePrefab(f.name);Object.Destroy(f);}forks.Clear();}
 }
}
