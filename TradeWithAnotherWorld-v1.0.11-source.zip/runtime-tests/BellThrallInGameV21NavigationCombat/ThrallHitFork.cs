using System;using System.Collections.Generic;using System.Linq;using UnityEngine;using Object=UnityEngine.Object;
namespace BlackAbbey.BellThrall {
 // Pure Unity fork implementation also used by the isolated Editor fixture.
 // Source templates, native audio clips, shared material and effect entries
 // remain untouched. The integration adapter supplies its private clone factory.
 public static class ThrallHitFork {
  public static readonly Color StartLow=new Color(.75f,.025f,.01f,.85f),StartHigh=new Color(1,.09f,.025f,.95f),Tint=new Color(1,.035f,.015f,.9f);
  public static bool HasVisual(GameObject source)=>source&&source.GetComponentsInChildren<Renderer>(true).Length>0;
  public static bool HasAudio(GameObject source)=>source&&(source.GetComponentsInChildren<AudioSource>(true).Length>0||source.GetComponentsInChildren<MonoBehaviour>(true).Any(b=>b&&b.GetType().Name=="ZSFX"));
  // Native vfx_foresttroll_hit owns a root ZNetView plus timed destruction.
  // Preserve it on our registered private effect; still reject actor/damage
  // components and nested network objects rather than weakening those checks.
  public static bool SafeVisual(GameObject source)=>HasVisual(source)&&!source.GetComponentsInChildren<MonoBehaviour>(true).Any(b=>b&&new[]{"Character","Humanoid","Ragdoll","Projectile","Aoe","EffectArea"}.Contains(b.GetType().Name))&&!source.GetComponentInChildren<SkinnedMeshRenderer>(true)&&source.GetComponentsInChildren<ZNetView>(true).All(v=>v.gameObject==source);
  public static GameObject Build(GameObject source,string name,Func<string,GameObject,GameObject> cloneFactory,List<Object> owned){
   if(!SafeVisual(source))throw new InvalidOperationException("Expected cosmetic native hit visual: "+(source?source.name:"null"));bool blood=source.GetComponentsInChildren<ParticleSystem>(true).Length>0;
   var clone=cloneFactory(name,source);if(!clone||clone==source)throw new InvalidOperationException("Hit fork must be a distinct own clone");clone.SetActive(false);owned.Add(clone);
   foreach(var audio in clone.GetComponentsInChildren<AudioSource>(true)){audio.Stop();audio.clip=null;audio.playOnAwake=false;audio.volume=0;audio.enabled=false;}
   foreach(var b in clone.GetComponentsInChildren<MonoBehaviour>(true))if(b&&b.GetType().Name=="ZSFX"){
    b.enabled=false;var field=b.GetType().GetField("m_audioClips");if(field!=null&&field.FieldType==typeof(AudioClip[]))field.SetValue(b,Array.Empty<AudioClip>());
   }
   foreach(var particle in clone.GetComponentsInChildren<ParticleSystem>(true)){
    particle.Stop(true,ParticleSystemStopBehavior.StopEmittingAndClear);var main=particle.main;main.startColor=new ParticleSystem.MinMaxGradient(StartLow,StartHigh);
    var color=particle.colorOverLifetime;var gradient=new Gradient();gradient.SetKeys(new[]{new GradientColorKey(Color.white,0),new GradientColorKey(new Color(.55f,.05f,.025f),1)},new[]{new GradientAlphaKey(1,0),new GradientAlphaKey(0,1)});color.enabled=true;color.color=gradient;var speed=particle.colorBySpeed;speed.enabled=false;
   }
   if(blood)foreach(var renderer in clone.GetComponentsInChildren<Renderer>(true))renderer.sharedMaterials=renderer.sharedMaterials.Select(m=>{
    if(!m)return m;var copy=new Material(m){name="BT_Private_RedHit_"+m.name};owned.Add(copy);foreach(string prop in new[]{"_Color","_BaseColor","_TintColor","_EmissionColor"})if(copy.HasProperty(prop))copy.SetColor(prop,Tint);return copy;
   }).ToArray();
   if(blood)foreach(var light in clone.GetComponentsInChildren<Light>(true))light.color=new Color(1,.04f,.015f);
   clone.SetActive(true);return clone;
  }
 }
}
