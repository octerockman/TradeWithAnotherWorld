using System;using System.Collections.Generic;using UnityEngine;
namespace BlackAbbey.BellThrall {
 public sealed class ThrallSweepQuery {
  readonly Collider[] overlaps=new Collider[128];readonly RaycastHit[] casts=new RaycastHit[128];
  public bool Visit(Vector3 from,Quaternion before,Vector3 to,Quaternion after,Vector3 half,int mask,Func<Collider,Vector3,Vector3,bool> contact){int steps=ThrallCombatPolicy.SweepSteps(Vector3.Distance(from,to),Quaternion.Angle(before,after),Mathf.Min(half.x,half.y,half.z));Vector3 previous=from;
   for(int i=0;i<=steps;i++){float t=i/(float)steps;var at=Vector3.Lerp(from,to,t);var rotation=Quaternion.Slerp(before,after,t);Vector3 delta=at-previous;
    if(delta.sqrMagnitude>.000001f){int count=Physics.BoxCastNonAlloc(previous,half,delta.normalized,casts,rotation,delta.magnitude,mask,QueryTriggerInteraction.Ignore);Array.Sort(casts,0,count,Comparer<RaycastHit>.Create((a,b)=>a.distance.CompareTo(b.distance)));for(int n=0;n<count;n++)if(contact(casts[n].collider,previous,at))return true;}
    int found=Physics.OverlapBoxNonAlloc(at,half,overlaps,rotation,mask,QueryTriggerInteraction.Ignore);for(int n=0;n<found;n++)if(contact(overlaps[n],previous,at))return true;previous=at;
   }return false;
  }
 }
 public sealed class ThrallHitLedger {readonly HashSet<int> ids=new HashSet<int>();public bool Contains(int id)=>ids.Contains(id);public bool Mark(int id)=>ids.Add(id);public void Reset()=>ids.Clear();}
}
