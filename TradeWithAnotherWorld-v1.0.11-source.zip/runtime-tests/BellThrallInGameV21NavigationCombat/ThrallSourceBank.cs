using System;using System.IO;using System.IO.Compression;using System.Linq;using System.Text;using System.Collections.Generic;
using Newtonsoft.Json;using UnityEngine;
namespace BlackAbbey.BellThrall {
 public sealed class ThrallSourceManifest {
  public string schema,visualSha256;public string[] boneNames;public int[] parentIndices;public float[] restScales;public ThrallMotionDescriptor[] clips,authoredHelpers;
 }
 public sealed class ThrallSourceClip {
  public string schema,id;public float duration;public float[] times;public BellFrame[] frames;
  [JsonIgnore]public ThrallMotionDescriptor Descriptor;
  [JsonIgnore]internal string SourcePath;[JsonIgnore]internal bool Failed;
 }
 public sealed class ThrallSourceBank {
  public const string ManifestName="motion-bank.json";
  public const string CheckedManifestSha256="236b999e25bcb5aa28f176e4eb71fa5a493ed87e772d19e91c71170a3d093b39";
  public const int MaximumManifestBytes=4*1024*1024;
  public ThrallSourceManifest Manifest;public readonly Dictionary<string,ThrallSourceClip> Clips=new Dictionary<string,ThrallSourceClip>(StringComparer.Ordinal);int[][] chains;long hydratedBytes;
  public const long CacheBudget=32L*1024*1024;public int HydratedCount=>Clips.Values.Count(c=>c.frames!=null);public long HydratedBytes=>hydratedBytes;
  public int SourceCount=>Manifest.clips.Length;public int AuthoredHelperCount=>Manifest.authoredHelpers?.Length??0;
  static readonly JsonSerializerSettings Settings=new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MaxDepth=24};
  public static ThrallSourceBank Read(string folder,string expectedManifest,string visualHash){
   string path=ThrallVisual.Safe(folder,ManifestName);
   if(new FileInfo(path).Length>MaximumManifestBytes||string.IsNullOrEmpty(expectedManifest)||ThrallVisual.Hash(path)!=expectedManifest)throw new InvalidDataException("Source-motion manifest does not match checked candidate");
   var m=JsonConvert.DeserializeObject<ThrallSourceManifest>(File.ReadAllText(path),Settings);
   if(m==null||m.schema!="bell-thrall.full-motion.v1"||m.visualSha256!=visualHash||m.boneNames?.Length!=58||m.boneNames.Distinct().Count()!=58||m.parentIndices?.Length!=58||m.restScales?.Length!=174||m.clips?.Length!=157||m.boneNames[0]!="BT1_Root"||m.parentIndices.Count(i=>i==-1)!=1)throw new InvalidDataException("Unexpected full-motion source inventory");
   if(m.authoredHelpers!=null&&(m.authoredHelpers.Length>1||m.authoredHelpers.Any(h=>h==null||h.id!="bt_prep_forward_down"||h.category!="AuthoredPreparation"||h.contactWindows!=null&&h.contactWindows.Length>0||h.swishTimes!=null&&h.swishTimes.Length>0)))throw new InvalidDataException("Unexpected authored preparation inventory");
   for(int i=0;i<58;i++){if(m.parentIndices[i]>=i||m.parentIndices[i]<-1)throw new InvalidDataException("Invalid motion hierarchy");for(int j=0;j<3;j++)if(!ThrallMotionPolicy.Finite(m.restScales[i*3+j])||m.restScales[i*3+j]<=0)throw new InvalidDataException("Invalid motion rest scale");}
   var result=new ThrallSourceBank{Manifest=m};result.chains=new int[58][];for(int i=0;i<58;i++){var chain=new List<int>();for(int j=i;j>=0;j=m.parentIndices[j])chain.Add(j);chain.Reverse();result.chains[i]=chain.ToArray();}long admittedBytes=0;
   foreach(var descriptor in m.clips.Concat(m.authoredHelpers??Array.Empty<ThrallMotionDescriptor>())){
    if(descriptor==null||string.IsNullOrEmpty(descriptor.id)||string.IsNullOrEmpty(descriptor.startState)||string.IsNullOrEmpty(descriptor.endState)||result.Clips.ContainsKey(descriptor.id)||descriptor.frameCount<2||descriptor.frameCount>1500||(descriptor.timelineFps>0?descriptor.timelineFps:descriptor.fps)!=30||!ThrallMotionPolicy.Finite(descriptor.duration)||descriptor.duration<=0||descriptor.duration>50||descriptor.rootMotionApplied||descriptor.uncompressedBytes<=0||descriptor.uncompressedBytes>8*1024*1024)throw new InvalidDataException("Invalid source-motion descriptor");
    if(!ThrallMotionPolicy.Finite(descriptor.recovery)||descriptor.recovery<0||descriptor.recovery>5)throw new InvalidDataException("Invalid source recovery");
    string clipPath=ThrallVisual.Safe(folder,descriptor.file);if(new FileInfo(clipPath).Length>8*1024*1024||ThrallVisual.Hash(clipPath)!=descriptor.sha256)throw new InvalidDataException("Source clip hash differs:"+descriptor.id);
    ValidateEvents(descriptor);ValidateTravelMetadata(descriptor);admittedBytes+=EstimatedBytes(descriptor);if(admittedBytes>CacheBudget)throw new InvalidDataException("Full retained motion inventory exceeds32MiB cache budget");
    // Registration verifies every declared file and hash, without decompressing
    // or parsing any clip. Actual frames hydrate once on first use, shared by
    // all actors; the entire admitted inventory fits the retained cache cap.
    result.Clips.Add(descriptor.id,new ThrallSourceClip{id=descriptor.id,duration=descriptor.duration,Descriptor=descriptor,SourcePath=clipPath});
   }
   var inventory=new Dictionary<string,int>{{"WalkRun",6},{"Turns",8},{"IdleAndHolds",15},{"Attacks",40},{"HurtAndKnockdown",42},{"Death",10},{"Recoveries",17},{"Special",19}};
   if(inventory.Any(row=>result.Clips.Values.Count(c=>c.Descriptor.category==row.Key)!=row.Value))throw new InvalidDataException("Source category inventory differs");
   foreach(string id in new[]{"a000_000000","a000_000020","a000_002000","a000_002001","a000_002002","a000_002003","a000_002100","a000_002300","a000_005000","a000_005001","a000_005002","a000_005003","a000_005010","a000_005011","a000_005012","a000_005013","a000_007600"})if(!result.Clips.ContainsKey(id))throw new InvalidDataException("Required motion state missing:"+id);
   foreach(var clip in result.Clips.Values){result.ValidateRoute(clip.Descriptor,true);result.ValidateRoute(clip.Descriptor,false);}
   return result;
  }
  static string ReadGzip(string path,int expected){using(var input=File.OpenRead(path))using(var gzip=new GZipStream(input,CompressionMode.Decompress))using(var output=new MemoryStream(Math.Min(expected,1024*1024))){var bytes=new byte[16384];int count;while((count=gzip.Read(bytes,0,bytes.Length))>0){if(output.Length+count>expected)throw new InvalidDataException("Motion decompression exceeds declared size");output.Write(bytes,0,count);}if(output.Length!=expected)throw new InvalidDataException("Motion decompression size differs");return new UTF8Encoding(false,true).GetString(output.ToArray());}}
  static long EstimatedBytes(ThrallMotionDescriptor d)=>(long)d.frameCount*(174*4+232*4+4+96)+1024+(long)(d.attackAdvance?.times?.Length??0)*12+(long)(d.locomotionDistance?.times?.Length??0)*8;
  static void ValidateTravelMetadata(ThrallMotionDescriptor descriptor){
   try{ThrallAttackTravelPolicy.Validate(descriptor);ThrallLocomotionDistance.Validate(descriptor);}
   catch(ArgumentException e){throw new InvalidDataException("Invalid source actor-travel metadata:"+descriptor.id,e);}
  }
  public void Hydrate(ThrallSourceClip clip){
   if(clip==null)throw new InvalidDataException("Missing source clip");if(clip.frames!=null)return;if(clip.Failed)throw new InvalidDataException("Source clip previously failed admission:"+clip.id);
   try{var d=clip.Descriptor;if(ThrallVisual.Hash(clip.SourcePath)!=d.sha256)throw new InvalidDataException("Source clip changed after registration");if(hydratedBytes+EstimatedBytes(d)>CacheBudget)throw new InvalidDataException("Motion cache budget exceeded");var loaded=JsonConvert.DeserializeObject<ThrallSourceClip>(ReadGzip(clip.SourcePath,d.uncompressedBytes),Settings);ValidateClip(loaded,d);clip.schema=loaded.schema;clip.times=loaded.times;clip.frames=loaded.frames;hydratedBytes+=EstimatedBytes(d);}
   catch{clip.Failed=true;throw;}
  }
  public void HydrateAllForOfflineCheck(){foreach(var clip in Clips.Values.OrderBy(c=>c.id))Hydrate(clip);}
  public static void ValidateClip(ThrallSourceClip clip,ThrallMotionDescriptor d){
   if(clip==null||clip.schema!="bell-thrall.full-motion.clip.v1"||clip.id!=d.id||!ThrallMotionPolicy.Finite(clip.duration)||clip.duration<=0||Math.Abs(clip.duration-d.duration)>.0001f||clip.times?.Length!=d.frameCount||clip.frames?.Length!=d.frameCount||Math.Abs(clip.times[0])>.00001f||Math.Abs(clip.times[clip.times.Length-1]-clip.duration)>.0001f)throw new InvalidDataException("Source clip header differs:"+d.id);
   for(int f=0;f<clip.frames.Length;f++){
    if(!ThrallMotionPolicy.Finite(clip.times[f])||(f>0&&clip.times[f]<=clip.times[f-1]))throw new InvalidDataException("Invalid source timeline");
    var frame=clip.frames[f];if(frame?.positions?.Length!=174||frame.rotations?.Length!=232||frame.positions.Concat(frame.rotations).Any(n=>!ThrallMotionPolicy.Finite(n)))throw new InvalidDataException("Invalid sampled source pose");
    for(int b=0;b<58;b++){int q=b*4;float norm=0;for(int j=0;j<4;j++)norm+=frame.rotations[q+j]*frame.rotations[q+j];if(Math.Abs(norm-1)>.002f)throw new InvalidDataException("Source pose quaternion is not unit");}
   }
   ValidateEvents(d);
  }
  static void ValidateEvents(ThrallMotionDescriptor d){
   float previous=-1;foreach(var w in d.contactWindows??Array.Empty<ThrallMotionWindow>()){if(w==null||!ThrallMotionPolicy.Finite(w.start)||!ThrallMotionPolicy.Finite(w.end)||w.start<0||w.end<w.start||w.end>d.duration||w.start<previous)throw new InvalidDataException("Invalid measured contact window");previous=w.end;}
   foreach(float t in d.swishTimes??Array.Empty<float>())if(!ThrallMotionPolicy.Finite(t)||t<0||t>d.duration)throw new InvalidDataException("Invalid measured swish time");
   if((d.contactWindows?.Length??0)>64||(d.swishTimes?.Length??0)>64)throw new InvalidDataException("Too many contact/swish events");
  }
  void ValidateRoute(ThrallMotionDescriptor d,bool entering){
   var segments=entering?d.entrySegments:d.exitSegments;var ids=entering?ThrallMotionPolicy.EntryHelpers(d):ThrallMotionPolicy.ExitHelpers(d);
   string state=entering?null:d.endState;
   if(segments!=null&&segments.Length>0){
    if(segments.Length>12)throw new InvalidDataException("Context route too long");
    foreach(var s in segments){
     if(s==null||!Clips.TryGetValue(s.id??"",out var clip)||!ThrallMotionPolicy.Finite(s.start)||!ThrallMotionPolicy.Finite(s.end)||s.start<0||s.end<=s.start||s.end>clip.duration+.0001f)throw new InvalidDataException("Invalid contextual motion segment");
     string first=s.startState??(s.start<=.00001f?clip.Descriptor.startState:null),last=s.endState??(Math.Abs(s.end-clip.duration)<.0001f?clip.Descriptor.endState:null);
     if(string.IsNullOrEmpty(first)||string.IsNullOrEmpty(last)||state!=null&&!ThrallMotionPolicy.Compatible(state,first))throw new InvalidDataException("Unverified contextual segment endpoint:"+d.id);state=last;
    }
   }else{
    if(ids.Length>12)throw new InvalidDataException("Context route too long");
    foreach(string id in ids){if(!Clips.TryGetValue(id,out var clip))throw new InvalidDataException("Missing contextual motion helper:"+id);if(state!=null&&!ThrallMotionPolicy.Compatible(state,clip.Descriptor.startState))throw new InvalidDataException("Context helper endpoint differs:"+d.id);state=clip.Descriptor.endState;}
   }
   if(entering&&state!=null&&!ThrallMotionPolicy.Compatible(state,d.startState))throw new InvalidDataException("Context route does not enter requested attack:"+d.id);
  }
  public void Bind(Dictionary<string,Transform> named,ThrallPayload payload){
   var nodes=payload.nodes.ToDictionary(n=>n.name,StringComparer.Ordinal);
   for(int i=0;i<58;i++){string name=Manifest.boneNames[i];if(!named.ContainsKey(name)||!nodes.ContainsKey(name))throw new InvalidDataException("Source bank cannot bind own bone:"+name);int parent=Manifest.parentIndices[i];if(parent>=0&&named[name].parent!=named[Manifest.boneNames[parent]])throw new InvalidDataException("Source bank hierarchy differs:"+name);for(int j=0;j<3;j++)if(Math.Abs(nodes[name].scale[j]-Manifest.restScales[i*3+j])>.0001f)throw new InvalidDataException("Source bank rest scale differs:"+name);}
  }
  public void Sample(ThrallSourceClip clip,float time,Vector3[] positions,Quaternion[] rotations){
   Hydrate(clip);
   float at=ThrallMotionPolicy.SampleTime(time,clip.duration,clip.Descriptor.loop);int lo=ThrallMotionPolicy.LowerFrame(clip.times,at),hi=Math.Min(lo+1,clip.frames.Length-1);float weight=hi==lo?0:(at-clip.times[lo])/(clip.times[hi]-clip.times[lo]);var a=clip.frames[lo];var z=clip.frames[hi];
   for(int i=0;i<58;i++){int p=i*3,q=i*4;positions[i]=Vector3.LerpUnclamped(new Vector3(a.positions[p],a.positions[p+1],a.positions[p+2]),new Vector3(z.positions[p],z.positions[p+1],z.positions[p+2]),weight);rotations[i]=Quaternion.SlerpUnclamped(new Quaternion(a.rotations[q],a.rotations[q+1],a.rotations[q+2],a.rotations[q+3]),new Quaternion(z.rotations[q],z.rotations[q+1],z.rotations[q+2],z.rotations[q+3]),weight);}
  }
  public Matrix4x4 BoneMatrix(ThrallSourceClip clip,float time,int bone,Matrix4x4 root,Quaternion rootRotation,Vector3[] blendPos,Quaternion[] blendRot,float weight,out Quaternion rotation){
   Hydrate(clip);
   float at=ThrallMotionPolicy.SampleTime(time,clip.duration,clip.Descriptor.loop);int lo=ThrallMotionPolicy.LowerFrame(clip.times,at),hi=Math.Min(lo+1,clip.frames.Length-1);float f=hi==lo?0:(at-clip.times[lo])/(clip.times[hi]-clip.times[lo]);rotation=rootRotation;
   foreach(int i in chains[bone]){int p=i*3,q=i*4;var a=clip.frames[lo];var z=clip.frames[hi];var position=Vector3.LerpUnclamped(new Vector3(a.positions[p],a.positions[p+1],a.positions[p+2]),new Vector3(z.positions[p],z.positions[p+1],z.positions[p+2]),f);var r=Quaternion.SlerpUnclamped(new Quaternion(a.rotations[q],a.rotations[q+1],a.rotations[q+2],a.rotations[q+3]),new Quaternion(z.rotations[q],z.rotations[q+1],z.rotations[q+2],z.rotations[q+3]),f);if(blendPos!=null){position=Vector3.Lerp(blendPos[i],position,weight);r=Quaternion.Slerp(blendRot[i],r,weight);}root=root*Matrix4x4.TRS(position,r,new Vector3(Manifest.restScales[p],Manifest.restScales[p+1],Manifest.restScales[p+2]));rotation=rotation*r;}
   return root;
  }
  public float NearestSupportPhase(ThrallSourceClip clip,Vector3 left,Vector3 right,float previous){
   Hydrate(clip);
   int l=Array.IndexOf(Manifest.boneNames,"LeftFoot"),r=Array.IndexOf(Manifest.boneNames,"RightFoot");if(l<0||r<0)return previous;float best=float.MaxValue,result=previous;
   for(int f=0;f<clip.frames.Length;f++){float phase=clip.times[f]/clip.duration;var a=BoneMatrix(clip,clip.times[f],l,Matrix4x4.identity,Quaternion.identity,null,null,1,out _).MultiplyPoint3x4(Vector3.zero);var b=BoneMatrix(clip,clip.times[f],r,Matrix4x4.identity,Quaternion.identity,null,null,1,out _).MultiplyPoint3x4(Vector3.zero);float phaseDistance=Math.Abs(phase-previous);phaseDistance=Math.Min(phaseDistance,1-phaseDistance);float cost=(a-left).sqrMagnitude+(b-right).sqrMagnitude+phaseDistance*phaseDistance*.01f;if(cost<best){best=cost;result=phase;}}
   return result%1;
  }
  Matrix4x4 PresentedBoneMatrix(int bone,float[] positions,float[] rotations){var matrix=Matrix4x4.identity;foreach(int i in chains[bone]){int p=i*3,q=i*4;matrix=matrix*Matrix4x4.TRS(new Vector3(positions[p],positions[p+1],positions[p+2]),new Quaternion(rotations[q],rotations[q+1],rotations[q+2],rotations[q+3]),new Vector3(Manifest.restScales[p],Manifest.restScales[p+1],Manifest.restScales[p+2]));}return matrix;}
  public float NearestDeathTime(ThrallSourceClip clip,float[] positions,float[] rotations){
   Hydrate(clip);string[] names={"Hips","Spine2","Head","LeftFoot","RightFoot"};float[] weights={3,1.5f,2,2,2};var indices=names.Select(n=>Array.IndexOf(Manifest.boneNames,n)).ToArray();var current=new Vector3[indices.Length];for(int i=0;i<indices.Length;i++)if(indices[i]>=0)current[i]=PresentedBoneMatrix(indices[i],positions,rotations).MultiplyPoint3x4(Vector3.zero);
   var costs=new float[clip.frames.Length];for(int f=0;f<costs.Length;f++){for(int i=0;i<indices.Length;i++)if(indices[i]>=0){var candidate=BoneMatrix(clip,clip.times[f],indices[i],Matrix4x4.identity,Quaternion.identity,null,null,1,out _).MultiplyPoint3x4(Vector3.zero);costs[f]+=(candidate-current[i]).sqrMagnitude*weights[i];}costs[f]+=.002f*f/Math.Max(1,costs.Length-1);}
   return ThrallMotionPolicy.DeathEntry(clip.times,costs,clip.duration);
  }
 }
}
