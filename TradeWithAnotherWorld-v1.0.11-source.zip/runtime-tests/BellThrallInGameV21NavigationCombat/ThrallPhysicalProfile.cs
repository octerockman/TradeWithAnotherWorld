using UnityEngine;
namespace BlackAbbey.BellThrall {
 public static class ThrallPhysicalProfile {
  public const float ActorScale=ThrallSizePolicy.ActorScale,BodyHeight=2.20f*ActorScale,BodyRadius=.55f*ActorScale,SourceBodyRadius=.55f*ThrallSizePolicy.PreviousActorScale;
  // Shared by runtime construction and the offline collider/nav checks.
  public static void Configure(CapsuleCollider capsule){capsule.direction=1;capsule.center=new Vector3(0,BodyHeight*.5f,.12f*ActorScale);capsule.height=BodyHeight;capsule.radius=BodyRadius;capsule.isTrigger=false;capsule.enabled=true;}
  // Head is below the reduced visual, so its source-local size stays unchanged.
  public static SphereCollider Head(Transform head,int layer){var go=new GameObject("BT_Head_Hit");go.layer=layer;go.transform.SetParent(head,false);go.transform.localPosition=new Vector3(0,.08f*ThrallSizePolicy.PreviousActorScale,0);var sphere=go.AddComponent<SphereCollider>();sphere.radius=.20f*ThrallSizePolicy.PreviousActorScale;sphere.isTrigger=false;return sphere;}
 }
}
