using UnityEngine;using UnityEngine.AI;
namespace BlackAbbey.BellThrall {
 public static class ThrallNavigationGeometry {
  public static NavMeshBuildSettings Create(CapsuleCollider capsule,NavMeshBuildSettings native){
   var settings=NavMesh.CreateSettings();settings.agentHeight=capsule.bounds.size.y+.025f;settings.agentRadius=Mathf.Max(capsule.bounds.extents.x,capsule.bounds.extents.z)+.025f;
   settings.agentSlope=native.agentSlope;settings.agentClimb=native.agentClimb;settings.minRegionArea=native.minRegionArea;
   settings.overrideVoxelSize=true;settings.voxelSize=.08f;settings.overrideTileSize=true;settings.tileSize=128;return settings;
  }
 }
}
