using System;using System.Collections.Generic;using System.Linq;using Jotunn.Managers;using UnityEngine;using Object=UnityEngine.Object;
namespace BlackAbbey.BellThrall {
 public sealed class ThrallCorpsePhysicsMarker:MonoBehaviour {}
 // Same fifteen-body/fourteen-joint cosmetic settlement pattern as the Guard.
 // Physics nodes are unscaled siblings, never children of animated skin bones.
 public sealed class ThrallCorpseRagdoll:IDisposable {
  readonly GameObject root;readonly List<Rigidbody> bodies=new List<Rigidbody>();readonly List<Collider> colliders=new List<Collider>();
  readonly List<KeyValuePair<Transform,Rigidbody>> bindings=new List<KeyValuePair<Transform,Rigidbody>>();
  readonly Dictionary<string,Rigidbody> byName=new Dictionary<string,Rigidbody>();readonly Dictionary<string,Transform> bones;
  readonly float scale;readonly int layer;readonly Vector3 velocity,forward;readonly ThrallCorpseRest rest;readonly ThrallCorpseAudio audio;
  public float Age=>Time.time-rest.Born;public bool Settled=>rest.Settled;
  public bool CanFinish=>Settled||Age>=ThrallDeathPolicy.MaximumSettleWait;
  public ThrallCorpseRagdoll(Transform[] input,string[] names,Vector3 velocity,Vector3 forward,ThrallCorpseAudio audio=null){
   this.audio=audio;
   bones=new Dictionary<string,Transform>();for(int i=0;i<names.Length;i++)bones.Add(names[i],input[i]);
   foreach(string name in new[]{"Hips","Spine2","Neck","Head","LeftArm","LeftForeArm","LeftHand","RightArm","RightForeArm","RightHand","LeftUpLeg","LeftLeg","LeftFoot","RightUpLeg","RightLeg","RightFoot"})if(!bones.ContainsKey(name))throw new InvalidOperationException("Corpse landmark missing: "+name);
   this.velocity=velocity;this.forward=Vector3.ProjectOnPlane(forward,Vector3.up).normalized;
   float left=Vector3.Distance(bones["LeftUpLeg"].position,bones["LeftLeg"].position)+Vector3.Distance(bones["LeftLeg"].position,bones["LeftFoot"].position);
   float right=Vector3.Distance(bones["RightUpLeg"].position,bones["RightLeg"].position)+Vector3.Distance(bones["RightLeg"].position,bones["RightFoot"].position);
   scale=Mathf.Clamp((left+right)*.5f,.75f,3f);
   var skeleton=PrefabManager.Instance.GetPrefab("Skeleton");var effects=skeleton?skeleton.GetComponent<Character>()?.m_deathEffects?.m_effectPrefabs:null;
   var nativeRagdoll=(effects??Array.Empty<EffectList.EffectData>()).Where(e=>e?.m_prefab).Select(e=>e.m_prefab.GetComponentInChildren<Ragdoll>(true)).FirstOrDefault(r=>r);
   var nativeCollider=nativeRagdoll?nativeRagdoll.GetComponentsInChildren<Collider>(true).FirstOrDefault(c=>c&&!c.isTrigger):null;
   layer=nativeCollider?nativeCollider.gameObject.layer:LayerMask.NameToLayer("ragdoll");if(layer<0)layer=LayerMask.NameToLayer("Default");
   root=new GameObject("BT Own Corpse Physics");root.SetActive(false);root.AddComponent<ThrallCorpsePhysicsMarker>();rest=root.AddComponent<ThrallCorpseRest>();
   try{
    Add("Hips","Spine2",null,.14f,8);Add("Spine2","Neck","Hips",.15f,8);Add("Head",null,"Spine2",.12f,2);
    foreach(string side in new[]{"Left","Right"}){Add(side+"Arm",side+"ForeArm","Spine2",.065f,2);Add(side+"ForeArm",side+"Hand",side+"Arm",.052f,1.2f);Add(side+"Hand",null,side+"ForeArm",.055f,.5f);Add(side+"UpLeg",side+"Leg","Hips",.085f,4);Add(side+"Leg",side+"Foot",side+"UpLeg",.065f,2);Add(side+"Foot",null,side+"Leg",.075f,.8f);}
    rest.Configure(bodies);root.SetActive(true);foreach(var a in colliders)foreach(var b in colliders)if(a!=b)Physics.IgnoreCollision(a,b);
   }catch{Object.Destroy(root);throw;}
  }
  void Add(string name,string endpoint,string parent,float radius,float mass){
   var bone=bones[name];float worldRadius=radius*scale;Vector3 delta=endpoint!=null?bones[endpoint].position-bone.position:bone.up*worldRadius;
   var node=new GameObject("BT Corpse Body "+name);node.transform.SetParent(root.transform,false);node.transform.SetPositionAndRotation(bone.position,bone.rotation);node.layer=layer;
   var local=node.transform.InverseTransformDirection(delta);var shape=new GameObject("BT Corpse Collider "+name);shape.layer=layer;shape.transform.SetParent(node.transform,false);shape.transform.localPosition=local*.5f;shape.transform.localRotation=Quaternion.FromToRotation(Vector3.up,local.sqrMagnitude>.000001f?local.normalized:Vector3.up);
   var collider=shape.AddComponent<CapsuleCollider>();collider.direction=1;collider.radius=worldRadius;collider.height=Mathf.Max(worldRadius*2,local.magnitude)+worldRadius;collider.contactOffset=.005f;
   collider.excludeLayers=LayerMask.GetMask("character","character_net","character_ghost","character_noenv");collider.includeLayers=LayerMask.GetMask("Default","Default_small","terrain","static_solid","piece");collider.layerOverridePriority=int.MaxValue;
   var body=node.AddComponent<Rigidbody>();body.mass=mass;body.useGravity=true;body.linearDamping=.15f;body.angularDamping=.4f;body.maxAngularVelocity=10;body.maxDepenetrationVelocity=1.5f;body.solverIterations=20;body.solverVelocityIterations=8;body.interpolation=RigidbodyInterpolation.Interpolate;body.collisionDetectionMode=CollisionDetectionMode.ContinuousSpeculative;
   var angular=Vector3.Cross(Vector3.up,forward).normalized*.6f;body.linearVelocity=Vector3.ClampMagnitude(velocity,4)+forward*.25f+Vector3.Cross(angular,body.position-bones["Hips"].position);body.angularVelocity=angular;
   bodies.Add(body);colliders.Add(collider);byName.Add(name,body);bindings.Add(new KeyValuePair<Transform,Rigidbody>(bone,body));var floorContact=node.AddComponent<ThrallCorpseFloorContact>();floorContact.Rest=rest;floorContact.Audio=audio;floorContact.BodyName=name;
   if(parent!=null){var connected=byName[parent];var joint=node.AddComponent<CharacterJoint>();joint.connectedBody=connected;joint.autoConfigureConnectedAnchor=false;joint.anchor=Vector3.zero;joint.connectedAnchor=Quaternion.Inverse(connected.rotation)*(body.position-connected.position);joint.axis=local.sqrMagnitude>.000001f?local.normalized:Vector3.up;var cross=Vector3.Cross(joint.axis,node.transform.InverseTransformDirection(forward));joint.swingAxis=cross.sqrMagnitude>.01f?cross.normalized:Vector3.right;bool limb=name.Contains("Arm")||name.Contains("Leg");joint.lowTwistLimit=new SoftJointLimit{limit=limb?-35:-25};joint.highTwistLimit=new SoftJointLimit{limit=limb?35:25};joint.swing1Limit=new SoftJointLimit{limit=limb?75:35};joint.swing2Limit=new SoftJointLimit{limit=limb?45:30};joint.enableCollision=false;joint.enablePreprocessing=false;joint.enableProjection=true;joint.projectionDistance=.01f;joint.projectionAngle=8;}
  }
  public void CopyPose(){foreach(var binding in bindings)if(binding.Key&&binding.Value)binding.Key.SetPositionAndRotation(binding.Value.transform.position,binding.Value.transform.rotation);}
  public void Dispose(){if(root)Object.Destroy(root);}
 }
 public sealed class ThrallCorpseRest:MonoBehaviour {
  List<Rigidbody> bodies;float lastGround=float.NegativeInfinity,quiet;bool grounded;int steps;public float Born{get;private set;}
  public void Configure(List<Rigidbody> list){bodies=list;Born=Time.time;}
  public void Ground(){grounded=true;lastGround=Time.fixedTime;}
  bool Read(out float speed,out float spin,out bool sleeping){speed=spin=0;sleeping=true;if(bodies==null||bodies.Count!=15)return false;foreach(var body in bodies){if(!body||body.isKinematic)return false;speed=Mathf.Max(speed,body.linearVelocity.magnitude);spin=Mathf.Max(spin,body.angularVelocity.magnitude);sleeping&=body.IsSleeping();}return true;}
  public bool Settled=>quiet>=.4f&&Time.time-Born>=.55f&&steps>=3&&Read(out float speed,out float spin,out _)&&speed<=.06f&&spin<=.25f;
  void FixedUpdate(){steps++;bool valid=Read(out float speed,out float spin,out bool sleeping);bool supported=grounded&&(sleeping||Time.fixedTime-lastGround<=Time.fixedDeltaTime*2.1f);quiet=valid&&supported&&speed<=.06f&&spin<=.25f?quiet+Mathf.Min(Time.fixedDeltaTime,.05f):0;}
 }
 public sealed class ThrallCorpseFloorContact:MonoBehaviour {
  public ThrallCorpseRest Rest;public ThrallCorpseAudio Audio;public string BodyName;static readonly int World=LayerMask.GetMask("Default","Default_small","terrain","static_solid","piece");
  void OnCollisionEnter(Collision collision){Observe(collision,true);}void OnCollisionStay(Collision collision){Observe(collision,false);}
  void Observe(Collision collision,bool newContact){if(!Rest||collision.collider.isTrigger||collision.collider.GetComponentInParent<Character>()||(World&(1<<collision.collider.gameObject.layer))==0)return;for(int i=0;i<collision.contactCount;i++){var point=collision.GetContact(i);if(point.normal.y>.45f){Rest.Ground();if(Audio&&newContact)ThrallAudio.Safe(()=>Audio.FloorContact(BodyName,point.point,Mathf.Abs(Vector3.Dot(collision.relativeVelocity,point.normal)),true));break;}}}
 }
}
