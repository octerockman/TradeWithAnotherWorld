using System;using System.Linq;using System.Collections.Generic;using System.Reflection;using Jotunn.Entities;using Jotunn.Managers;using UnityEngine;using Object=UnityEngine.Object;
namespace BlackAbbey.BellThrall {
 public sealed class ThrallHitSoundLifetime:MonoBehaviour {void Start(){Object.Destroy(gameObject,.65f);}}
 public static class ThrallHitPresentation {
  static readonly List<Object> owned=new List<Object>();static readonly Dictionary<GameObject,GameObject> forks=new Dictionary<GameObject,GameObject>();static GameObject dry;
  static readonly MethodInfo CloneEntry=typeof(object).GetMethod("MemberwiseClone",BindingFlags.Instance|BindingFlags.NonPublic);
  public static object Apply(Humanoid source,Humanoid own,Action<string> log){
   if(!source||!own||source==own)throw new InvalidOperationException("Hit presentation requires a distinct own character");
   string nativeBefore=JsonUtility.ToJson(source);var rows=new List<object>();int particles=0,removedAudio=0;
   if(!dry){dry=new GameObject("BA_Thrall_DryHitSound");dry.SetActive(false);owned.Add(dry);var audio=ThrallEffects.Audio(dry.transform);audio.clip=ThrallEffects.DryHit;audio.volume=.65f;audio.playOnAwake=true;dry.AddComponent<ThrallHitSoundLifetime>();PrefabManager.Instance.AddPrefab(new CustomPrefab(dry,false));dry.SetActive(true);}
   foreach(string name in new[]{"m_hitEffects"}){
    var field=typeof(Character).GetField(name,BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic);if(field==null||field.FieldType!=typeof(EffectList))throw new MissingFieldException("Character",name);
    var original=field.GetValue(source)as EffectList;var entries=original?.m_effectPrefabs??Array.Empty<EffectList.EffectData>();var output=new List<EffectList.EffectData>();var names=new List<string>();
    foreach(var entry in entries){if(entry?.m_prefab==null)continue;var p=entry.m_prefab;names.Add(p.name);if(!ThrallHitFork.HasVisual(p)){if(ThrallHitFork.HasAudio(p))removedAudio++;continue;}
     if(!ThrallHitFork.SafeVisual(p)){log?.Invoke("BT_HIT_COSMETIC_SKIPPED unsafe="+p.name);continue;}
     if(!forks.TryGetValue(p,out var fork)){fork=ThrallHitFork.Build(p,"BA_Thrall_RedHit_"+forks.Count,(n,s)=>PrefabManager.Instance.CreateClonedPrefab(n,s),owned);forks.Add(p,fork);}
     if(p.GetComponentsInChildren<ParticleSystem>(true).Length>0)particles++;
     var copy=(EffectList.EffectData)CloneEntry.Invoke(entry,null);copy.m_prefab=fork;output.Add(copy);
    }
    // Exactly one compact dry cue belongs to the ordinary hit list. Existing
    // critical/backstab effect lists and their separate feedback stay untouched.
    if(name=="m_hitEffects")output.Add(new EffectList.EffectData{m_prefab=dry,m_enabled=true,m_variant=-1});
    field.SetValue(own,new EffectList{m_effectPrefabs=output.ToArray()});rows.Add(new{field=name,source=names.ToArray(),candidate=output.Select(e=>e.m_prefab.name).ToArray()});
   }
   if(particles==0)throw new InvalidOperationException("Native Troll hit particle source unavailable; no silent no-blood substitute");
   bool unchanged=nativeBefore==JsonUtility.ToJson(source);if(!unchanged)throw new InvalidOperationException("Native Troll changed by own hit presentation");
   log?.Invoke("BT_PRIVATE_RED_HIT_READY tinted="+particles+" nativeUnchanged=true wetHitAudioReplaced=true");
   return new{nativeSourceUnchanged=unchanged,redParticleEntries=particles,audioOnlyEntriesRemoved=removedAudio,lists=rows,paletteSource="Existing ReliquaryGuard red-hit palette",dryCue="Thrall-Dry-Hit.wav",scope="Own receiving-hit presentation only; native damage, controller, hitboxes and other actors remain unchanged."};
  }
  public static void Shutdown(){foreach(var o in owned)if(o)Object.Destroy(o);owned.Clear();forks.Clear();dry=null;}
 }
}
