using System;using System.Linq;using System.Collections.Generic;using System.IO;using UnityEngine;using Object=UnityEngine.Object;
namespace BlackAbbey.BellThrall {
 public sealed class ThrallReceiveShape {
  public string start,end;public float radius,rawWorldRadius,fittedWorldRadius;public int fittedVertices;
  static readonly string[][] Segments={new[]{"Hips","Spine"},new[]{"Spine","Spine2"},new[]{"Spine2","Neck"},new[]{"LeftUpLeg","LeftLeg"},new[]{"RightUpLeg","RightLeg"}};
  static float Scale(Vector3 s)=>Mathf.Max(Mathf.Abs(s.x),Mathf.Abs(s.y),Mathf.Abs(s.z));
  public static ThrallReceiveShape[] Fit(ThrallPayload payload){
   var byName=payload.nodes.ToDictionary(n=>n.name,StringComparer.Ordinal);var world=new Dictionary<int,Matrix4x4>();foreach(var n in payload.nodes){var local=Matrix4x4.TRS(ThrallVisual.V(n.position),ThrallVisual.Q(n.rotation),ThrallVisual.V(n.scale));world[n.id]=n.parentId<0?local:world[n.parentId]*local;}
   var result=new List<ThrallReceiveShape>();
   foreach(var segment in Segments){
    var first=byName[segment[0]];var last=byName[segment[1]];var localEnd=world[first.id].inverse.MultiplyPoint3x4(world[last.id].MultiplyPoint3x4(Vector3.zero));float length=localEnd.magnitude;if(length<.001f)throw new InvalidDataException("Degenerate own torso/thigh segment");var axis=localEnd/length;
    var selected=new List<float>();var fallback=new List<float>();var group=new HashSet<int>{first.id};if(first.name=="Spine")group.Add(byName["Spine1"].id);
    foreach(var mesh in payload.renderers.Where(r=>r.name.StartsWith("BT1_Body_Runtime_",StringComparison.Ordinal))){
     int binding=Array.IndexOf(mesh.boneNodeIds,first.id);if(binding<0)continue;var bind=new Matrix4x4();for(int k=0;k<16;k++)bind[k/4,k%4]=mesh.bindposes[binding].values[k];
     for(int i=0;i<mesh.weights.Length;i++){var w=mesh.weights[i];int dominant=w.boneIndex0;float largest=w.weight0;if(w.weight1>largest){dominant=w.boneIndex1;largest=w.weight1;}if(w.weight2>largest){dominant=w.boneIndex2;largest=w.weight2;}if(w.weight3>largest){dominant=w.boneIndex3;largest=w.weight3;}if(largest<.45f||!group.Contains(mesh.boneNodeIds[dominant]))continue;int p=i*3;var point=bind.MultiplyPoint3x4(new Vector3(mesh.positions[p],mesh.positions[p+1],mesh.positions[p+2]));float along=Vector3.Dot(point,axis);float radial=(point-axis*along).magnitude;fallback.Add(radial);if(along>=-.05f*length&&along<=1.05f*length)selected.Add(radial);}
    }
    if(selected.Count<8)selected=fallback;if(selected.Count<8)throw new InvalidDataException("Own body skin cannot fit query volume:"+first.name);selected.Sort();float radius=selected[(int)Math.Floor((selected.Count-1)*.70)];float scale=Scale(world[first.id].lossyScale);float raw=radius*scale;
    // Frame/bell vertices share the body renderer and some spine weights.
    // A central skin percentile plus the existing native body radius bounds
    // avoids turning the back frame into an oversized torso damage volume.
    // Payload coordinates are still the accepted source size. The visual's
    // outer scale applies the reduction once after this source-space fit.
    bool thigh=first.name.EndsWith("UpLeg",StringComparison.Ordinal);float bounded=Mathf.Clamp(raw,ThrallPhysicalProfile.SourceBodyRadius*.12f,ThrallPhysicalProfile.SourceBodyRadius*(thigh?.55f:.85f));
    result.Add(new ThrallReceiveShape{start=first.name,end=last.name,radius=bounded/scale,rawWorldRadius=raw,fittedWorldRadius=bounded,fittedVertices=selected.Count});
   }
   if(result.Count!=5)throw new InvalidDataException("Expected five fitted receive-hit volumes");return result.ToArray();
  }
 }
 public sealed class ThrallReceiveVolumes:IDisposable {
  sealed class NativeMass {
   public float mass;public Vector3 center,inertia;public Quaternion rotation;public bool autoCenter,autoInertia;
   public static NativeMass Capture(Rigidbody body)=>new NativeMass{mass=body.mass,center=body.centerOfMass,inertia=body.inertiaTensor,rotation=body.inertiaTensorRotation,autoCenter=body.automaticCenterOfMass,autoInertia=body.automaticInertiaTensor};
   public void Freeze(Rigidbody body){body.automaticCenterOfMass=false;body.automaticInertiaTensor=false;body.centerOfMass=center;body.inertiaTensor=inertia;body.inertiaTensorRotation=rotation;}
   public void RestoreFlags(Rigidbody body){body.automaticCenterOfMass=autoCenter;body.automaticInertiaTensor=autoInertia;}
   public bool NumericMatch(Rigidbody body)=>(body.centerOfMass-center).sqrMagnitude<1e-8f&&(body.inertiaTensor-inertia).sqrMagnitude<Mathf.Max(1e-7f,inertia.sqrMagnitude*1e-8f)&&Mathf.Abs(Quaternion.Dot(body.inertiaTensorRotation,rotation))>.99999f;
  }
  readonly Transform actor;readonly Rigidbody body;readonly ThrallReceiveShape[] shapes;readonly Transform[] starts,ends;readonly Collider[] colliders;NativeMass original;bool active,disposed,first=true;
  public bool Active=>active&&!disposed;public int Count=>colliders.Length;
  public ThrallReceiveVolumes(Transform actor,Dictionary<string,Transform> named,ThrallReceiveShape[] shapes,int layer){
   this.actor=actor;body=actor.GetComponent<Rigidbody>();if(!body||shapes==null||shapes.Length!=5)throw new InvalidOperationException("Own receive volumes require native body and five fitted shapes");this.shapes=shapes;original=NativeMass.Capture(body);starts=shapes.Select(s=>named[s.start]).ToArray();ends=shapes.Select(s=>named[s.end]).ToArray();colliders=new Collider[shapes.Length];
   for(int i=0;i<shapes.Length;i++){var go=new GameObject("BT Posed Receive "+shapes[i].start);go.SetActive(false);go.layer=layer;go.transform.SetParent(actor,false);Collider c;if(shapes[i].start.EndsWith("UpLeg",StringComparison.Ordinal)){var capsule=go.AddComponent<CapsuleCollider>();capsule.direction=1;capsule.center=Vector3.zero;c=capsule;}else{var box=go.AddComponent<BoxCollider>();box.center=Vector3.zero;c=box;}c.isTrigger=false;c.excludeLayers=~0;c.layerOverridePriority=int.MaxValue;c.enabled=false;colliders[i]=c;}
  }
  public void Enable(){if(disposed||active||!body)return;if(!first)original=NativeMass.Capture(body);first=false;original.Freeze(body);active=true;for(int i=0;i<colliders.Length;i++){colliders[i].gameObject.SetActive(true);colliders[i].enabled=true;if(colliders[i].attachedRigidbody!=body)throw new InvalidOperationException("Posed receive collider escaped native Rigidbody");}UpdatePose();if(Mathf.Abs(body.mass-original.mass)>.0001f||!original.NumericMatch(body))throw new InvalidOperationException("Native mass geometry changed while adding own query volumes");}
  public void UpdatePose(){if(!Active||!body)return;for(int i=0;i<colliders.Length;i++){var a=starts[i].position;var b=ends[i].position;var direction=b-a;var boneScale=starts[i].lossyScale;float radius=shapes[i].radius*Mathf.Max(Mathf.Abs(boneScale.x),Mathf.Abs(boneScale.y),Mathf.Abs(boneScale.z));var c=colliders[i];c.transform.position=(a+b)*.5f;c.transform.rotation=direction.sqrMagnitude>.000001f?Quaternion.FromToRotation(Vector3.up,direction.normalized):starts[i].rotation;var scale=c.transform.lossyScale;float radialScale=Mathf.Max(.0001f,Mathf.Max(Mathf.Abs(scale.x),Mathf.Abs(scale.z))),axialScale=Mathf.Max(.0001f,Mathf.Abs(scale.y));if(c is CapsuleCollider capsule){capsule.radius=radius/radialScale;capsule.height=(direction.magnitude+radius*2)/axialScale;}else if(c is BoxCollider box){box.size=new Vector3(radius*2/Mathf.Max(.0001f,Mathf.Abs(scale.x)),Mathf.Max(.02f,direction.magnitude)/axialScale,radius*2/Mathf.Max(.0001f,Mathf.Abs(scale.z)));}}}
  public void Disable(){if(!active)return;foreach(var c in colliders)if(c)c.enabled=false;active=false;if(body)original.RestoreFlags(body);}
  public object Snapshot()=>new{active=Active,count=colliders.Length,nativeNumericMassGeometry=body&&original.NumericMatch(body),nativeMass=body?body.mass:0,nativeInitialMass=original.mass,automaticCenterWhileActive=body&&body.automaticCenterOfMass,automaticInertiaWhileActive=body&&body.automaticInertiaTensor,originalAutomaticCenter=original.autoCenter,originalAutomaticInertia=original.autoInertia,scope="Three fitted torso boxes/two thigh capsules, query-only; native navigation capsule remains approximate and unchanged."};
  public void Dispose(){if(disposed)return;Disable();foreach(var c in colliders)if(c)Object.Destroy(c.gameObject);disposed=true;}
 }
}
