using System;
using System.Collections.Generic;

namespace BlackAbbey.BellThrall {
 // Pure admission rules. This class never drives combat, AI, motion or damage.
 public static class ThrallAudioPolicy {
  public const double EventLifetime=1.5,ContactLifetime=8;
  public enum Cue { Alert=1,HammerEffort=2,HammerBody=3,Death=4,QuickEffort=5,OverheadEffort=6,HurtLight=7,HurtHeavy=8,StaggerA=9,StaggerB=10,BellHeave=11,StepA=12,StepB=13,StepC=14 }
  public sealed class Gate {
   public long EnabledAt {get;private set;}
   public bool Active {get;private set;}
   long lastOwner;int sequence;bool death;
   public void Enable(long now){EnabledAt=now;Active=true;lastOwner=0;sequence=0;}
   public void Disable(){Active=false;}
   public bool Accept(long sender,long expectedOwner,int next,long ticks,long now,int cue,bool dead){
    if(!Active||sender==0||sender!=expectedOwner||next<=0||cue<1||cue>14||ticks<EnabledAt||ticks>now+2500000L||(now-ticks)/10000000d>EventLifetime||(dead&&cue!=(int)Cue.Death))return false;
    if(lastOwner!=sender){lastOwner=sender;sequence=0;}
    if(next<=sequence)return false;sequence=next;return true;
   }
   public bool TakeDeath(){if(!Active||death)return false;death=true;return true;}
  }
  public static bool Breathing(bool live,bool alerted,bool melee,bool bell,bool staggered,bool teleported)=>live&&!alerted&&!melee&&!bell&&!staggered&&!teleported;
  public static bool BellWarning(long start,long enabledAt,float elapsed,bool active,bool alive,bool staggered)=>start>=enabledAt&&elapsed>=.20f&&elapsed<.95f&&active&&alive&&!staggered;
  public sealed class Contacts {
   sealed class Swing {public long stamp;public bool delivered;}
   sealed class Entry {public string target;public float x,y,z;public long at;public Swing swing;}
   readonly List<Entry> pending=new List<Entry>();readonly Dictionary<string,long> receipts=new Dictionary<string,long>();Swing current;
   public void Clear(){pending.Clear();receipts.Clear();current=null;}
   public void Begin(long stamp){Prune(stamp);current=new Swing{stamp=stamp};}
   void Prune(long now){pending.RemoveAll(p=>now<p.at||(now-p.at)/10000000d>ContactLifetime);}
   public void Add(string target,float x,float y,float z,long now){
    Prune(now);if(current==null||current.delivered||string.IsNullOrEmpty(target)||!Finite(x)||!Finite(y)||!Finite(z)||(now-current.stamp)/10000000d>ContactLifetime)return;
    if(pending.Count>=128)pending.RemoveAt(0);pending.Add(new Entry{target=target,x=x,y=y,z=z,at=now,swing=current});
   }
   public bool Confirm(string target,float x,float y,float z,long now)=>Confirm(target,x,y,z,now,now,target+":"+now);
   public bool Confirm(string target,float x,float y,float z,long acceptedTicks,long now,string receipt){
    Prune(now);if(!Finite(x)||!Finite(y)||!Finite(z)||string.IsNullOrEmpty(receipt)||acceptedTicks>now+2500000L||(now-acceptedTicks)/10000000d>EventLifetime||receipts.ContainsKey(receipt))return false;
    var expired=new List<string>();foreach(var pair in receipts)if((now-pair.Value)/10000000d>ContactLifetime)expired.Add(pair.Key);foreach(var key in expired)receipts.Remove(key);
    if(receipts.Count>=256)return false;receipts.Add(receipt,now);
    // Match the submitted target AND original contact point, not a current AI
    // target or an unrelated bell/DoT hit. An older swing keeps its own latch.
    Entry closest=null;long delta=long.MaxValue;
    foreach(var p in pending){float dx=p.x-x,dy=p.y-y,dz=p.z-z;if(p.target!=target||dx*dx+dy*dy+dz*dz>.0004f||p.at>acceptedTicks+2500000L||(acceptedTicks-p.at)/10000000d>EventLifetime)continue;
     long distance=Math.Abs(acceptedTicks-p.at);if(distance<delta){closest=p;delta=distance;}}
    if(closest==null||closest.swing.delivered)return false;closest.swing.delivered=true;return true;
   }
  }
  public static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
 }
}
