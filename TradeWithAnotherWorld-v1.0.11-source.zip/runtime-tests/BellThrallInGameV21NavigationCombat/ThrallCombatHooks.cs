using System.Reflection;using HarmonyLib;
namespace BlackAbbey.BellThrall {
 public static class ThrallCombatHooks {
  static readonly FieldInfo CurrentAttack=AccessTools.Field(typeof(Humanoid),"m_currentAttack"),AttackOwner=AccessTools.Field(typeof(Attack),"m_character");
  static ThrallCombat Own(Attack a){var h=AttackOwner.GetValue(a) as Humanoid;return h?h.GetComponent<ThrallCombat>():null;}
  [HarmonyPatch(typeof(Humanoid),"StartAttack")]
  static class Start {static bool Prefix(Humanoid __instance,ref bool __result){var c=__instance.GetComponent<ThrallCombat>();if(!c)return true;var motion=__instance.GetComponent<ThrallSourceMotion>();if(c.CanStartMelee&&motion&&motion.PrepareMelee())return true;__result=false;return false;}static void Postfix(Humanoid __instance,bool __result){if(__result)__instance.GetComponent<ThrallCombat>()?.BeginAttack(CurrentAttack.GetValue(__instance) as Attack);else __instance.GetComponent<ThrallSourceMotion>()?.DiscardPreparedMelee();}}
  [HarmonyPatch(typeof(Attack),"DoMeleeAttack")]
  static class Melee {static bool Prefix(Attack __instance){var c=Own(__instance);if(!c)return true;c.NativeTrigger();return false;}}
  [HarmonyPatch(typeof(Attack),"DoAreaAttack")]
  static class Area {static bool Prefix(Attack __instance){var c=Own(__instance);if(!c)return true;c.NativeTrigger();return false;}}
  [HarmonyPatch(typeof(CharacterAnimEvent),"Speed")]
  static class Speed {static void Prefix(CharacterAnimEvent __instance,ref float __0){var c=__instance.GetComponentInParent<ThrallCombat>();if(!c||__instance.GetComponentInParent<ThrallSourceMotion>())return;var h=__instance.GetComponentInParent<Humanoid>();if(c.MeleeActive||(h&&h.InAttack()))__0*=ThrallCombatPolicy.AttackSpeed;}}
  [HarmonyPatch(typeof(CharacterAnimEvent),"TrailOn")]
  static class TrailOn {static bool Prefix(CharacterAnimEvent __instance)=>!__instance.GetComponentInParent<ThrallCombat>();}
  [HarmonyPatch(typeof(MonsterAI),"UpdateAI")]
  static class Hold {
   static bool Prefix(MonsterAI __instance,ref bool __result,out bool __state){__state=false;var c=__instance.GetComponent<ThrallCombat>();if(!c)return true;if(c.BellActive||c.MotionBlocking){c.StopForBell();__result=true;return false;}__instance.GetComponent<ThrallTactics>()?.BeginNativeUpdate();__state=true;return true;}
   static void Postfix(MonsterAI __instance,float __0,bool __state){if(__state)__instance.GetComponent<ThrallTactics>()?.AfterNativeUpdate(__0);}
  }
  [HarmonyPatch(typeof(BaseAI),"Flee")]
  static class ObserveFlee {static void Prefix(BaseAI __instance){__instance.GetComponent<ThrallTactics>()?.ObserveNativePriority();}}
  [HarmonyPatch(typeof(BaseAI),"RandomMovementArroundPoint")]
  static class ObserveWander {static void Prefix(BaseAI __instance){__instance.GetComponent<ThrallTactics>()?.ObserveNativePriority();}}
  [HarmonyPatch(typeof(BaseAI),"AvoidFire")]
  static class ObserveFire {static void Postfix(BaseAI __instance,bool __result){if(__result)__instance.GetComponent<ThrallTactics>()?.ObserveNativePriority();}}
  [HarmonyPatch(typeof(BaseAI),"MoveToWater")]
  static class ObserveWater {static void Prefix(BaseAI __instance){__instance.GetComponent<ThrallTactics>()?.ObserveNativePriority();}}
  [HarmonyPatch(typeof(BaseAI),"MoveAwayAndDespawn")]
  static class ObserveDespawn {static void Prefix(BaseAI __instance){__instance.GetComponent<ThrallTactics>()?.ObserveNativePriority();}}
  [HarmonyPatch(typeof(Character),nameof(Character.ApplyDamage))]
  static class RangedResponse {
   static void Prefix(Character __instance,out float __state){__state=__instance?__instance.GetHealth():0;}
   static void Postfix(Character __instance,HitData hit,float __state){ThrallSourceMotion.Safe(()=>{if(__instance)__instance.GetComponent<ThrallTactics>()?.ConfirmRangedHit(hit,__state);});}
  }
  [HarmonyPatch(typeof(Character),"UpdateRotation")]
  static class TrackFacing {static void Prefix(Character __instance,ref float __0){if(__instance)__instance.GetComponent<ThrallSourceMotion>()?.PrepareFacing(ref __0);}}
  [HarmonyPatch(typeof(Humanoid),"GetAttackSpeedFactorRotation")]
  static class TrackWindup {static void Postfix(Humanoid __instance,ref float __result){var motion=__instance?__instance.GetComponent<ThrallSourceMotion>():null;if(motion&&motion.WindupTracking)__result=System.Math.Max(motion.BetweenComboStrikes?.90f:.65f,__result);}}
  [HarmonyPatch(typeof(Character),"ApplyRootMotion")]
  static class SourceAdvance {static void Postfix(Character __instance,ref UnityEngine.Vector3 __0){if(__instance)__instance.GetComponent<ThrallSourceMotion>()?.ApplySourceRootMotion(ref __0);}}
  [HarmonyPatch(typeof(CharacterAnimEvent),"OnAnimatorMove")]
  static class NativeRoot {static bool Prefix(CharacterAnimEvent __instance){var motion=__instance?__instance.GetComponentInParent<ThrallSourceMotion>():null;return !motion||!motion.Ready;}}
  [HarmonyPatch(typeof(Character),nameof(Character.OnDeath))]
  static class SourceDeath {static void Prefix(Character __instance){ThrallSourceMotion.Safe(()=>{if(__instance)__instance.GetComponent<ThrallSourceMotion>()?.NativeDeath();});}}
 }
}
