using System;
using UnityEngine;using HarmonyLib;

namespace BlackAbbey.BellThrall {
 // Uses the existing Character walking/Rigidbody pipeline. It never writes
 // Transform position, applies vertical animation motion or queues blocked travel.
 public sealed class ThrallAttackTravel {
  const float Skin=.035f,StepUp=.32f,MaximumDrop=.48f;
  readonly Transform actor;readonly CapsuleCollider body;
  static readonly AccessTools.FieldRef<Character,float> NativeSlippage=AccessTools.FieldRefAccess<Character,float>("m_slippage");
  readonly Character character;readonly Rigidbody nativeBody;
  readonly ThrallAttackTravelClock clock=new ThrallAttackTravelClock();
  readonly RaycastHit[] obstacles=new RaycastHit[48],floors=new RaycastHit[24];
  int blocked;float commanded,gain=1;string lastBlocked="";
  int observedRoute=-1,physicsSamples,positionDiscontinuities,frictionTicks;Vector3 firstPosition,lastPosition;float observedPath,peakPhysicalSpeed,lastMovingFriction;
  static int Solid=>ThrallCombat.SolidMask;
  static int Obstructions=>Solid|LayerMask.GetMask("character","character_net","character_noenv","character_ghost");
  static bool Cosmetic(Collider collider)=>collider&&(collider.GetComponentInParent<ThrallCorpsePhysicsMarker>()||collider.GetComponentInParent<ThrallCorpseMotion>());
  public ThrallAttackTravel(Transform actor,CapsuleCollider body){this.actor=actor;this.body=body;character=actor.GetComponent<Character>();nativeBody=actor.GetComponent<Rigidbody>();}
  public void Reset(){clock.Reset();blocked=0;commanded=0;lastBlocked="";gain=1;observedRoute=-1;physicsSamples=positionDiscontinuities=frictionTicks=0;observedPath=peakPhysicalSpeed=lastMovingFriction=0;}
  Vector3 Position=>nativeBody?nativeBody.position:actor.position;
  void Observe(){
   if(observedRoute<0)return;var position=Position;float distance=Vector3.ProjectOnPlane(position-lastPosition,Vector3.up).magnitude;
   if(distance<=.5f)observedPath+=distance;else positionDiscontinuities++;
   lastPosition=position;if(nativeBody)peakPhysicalSpeed=Mathf.Max(peakPhysicalSpeed,Vector3.ProjectOnPlane(nativeBody.linearVelocity,Vector3.up).magnitude);
  }
  public void Apply(ref Vector3 velocity,int routeSerial,int packetSerial,float from,float at,ThrallAttackAdvanceProfile profile,float dt,bool eligible,bool restored,bool grounded,Quaternion heading,float routeGain){
   if(observedRoute!=routeSerial){observedRoute=routeSerial;firstPosition=lastPosition=Position;observedPath=peakPhysicalSpeed=0;physicsSamples=positionDiscontinuities=frictionTicks=0;}else Observe();physicsSamples++;
   gain=routeGain;var step=clock.Consume(routeSerial,packetSerial,from,at,profile,dt,!eligible||restored,routeGain);
   // Native gravity/Y and later pushback/platform forces remain native.
   velocity.x=velocity.z=0;
   if(!eligible||restored||step.Length<=0)return;
   if(!grounded||!body||!body.enabled){blocked++;lastBlocked="not grounded or body unavailable";return;}
   var delta=heading*new Vector3(ThrallSizePolicy.World(step.Right),0,ThrallSizePolicy.World(step.Forward));delta.y=0;
   float requested=delta.magnitude;if(requested<=.00001f)return;var direction=delta/requested;
   var bounds=body.bounds;float radius=Mathf.Max(.05f,Mathf.Max(bounds.extents.x,bounds.extents.z)-.015f);
   // Inset the query vertically as well as radially. A sweep beginning in
   // floor contact can report a zero-distance, horizontal initial-overlap hit.
   // The actual native body and the three floor-support probes stay unchanged.
   float offset=Mathf.Max(0,bounds.extents.y-radius-Skin);var lower=bounds.center-Vector3.up*offset;var upper=bounds.center+Vector3.up*offset;
   int count=Physics.CapsuleCastNonAlloc(lower,upper,radius,direction,obstacles,requested+Skin,Obstructions,QueryTriggerInteraction.Ignore);
   float allowed=requested;
   if(count>=obstacles.Length){blocked++;lastBlocked="obstruction query saturated";return;}
   for(int i=0;i<count;i++){
    var hit=obstacles[i];if(!hit.collider||hit.collider.transform.IsChildOf(actor)||Cosmetic(hit.collider)||hit.normal.y>.65f)continue;
    float limit=Mathf.Max(0,hit.distance-Skin);if(limit<allowed)lastBlocked="solid: "+hit.collider.name;allowed=Mathf.Min(allowed,limit);
   }
   delta=direction*allowed;
   var foot=bounds.center;foot.y=bounds.min.y;
   var side=Vector3.Cross(Vector3.up,direction)*radius*.55f;
   if(allowed>0&&(!Floor(foot+delta)||!Floor(foot+delta+side)||!Floor(foot+delta-side))){allowed=0;lastBlocked="floor support";}
   if(allowed<requested-.00001f)blocked++;
   if(!ThrallMotorPolicy.MayMove(eligible,restored,grounded,body.enabled,allowed))return;
   // UpdateBodyFriction ran earlier with moveDir=zero (source attack hold),
   // selecting standing0.8/Maximum. This admitted step uses the actual native
   // moving0.4*(1-slippage)/Multiply branch, on this collider's own instance.
   // The next native UpdateBodyFriction restores ordinary idle/death handling.
   if(character){float friction=ThrallMotorPolicy.MovingFriction(NativeSlippage(character));var material=body.material;material.staticFriction=material.dynamicFriction=friction;material.frictionCombine=PhysicsMaterialCombine.Multiply;lastMovingFriction=friction;frictionTicks++;}
   var horizontal=direction*(allowed/dt);velocity.x=horizontal.x;velocity.z=horizontal.z;commanded+=allowed;
  }
  bool Floor(Vector3 foot){
   int count=Physics.RaycastNonAlloc(foot+Vector3.up*StepUp,Vector3.down,floors,StepUp+MaximumDrop,Solid,QueryTriggerInteraction.Ignore);
   if(count>=floors.Length)return false;
   for(int i=0;i<count;i++){var hit=floors[i];if(hit.collider&&!hit.collider.transform.IsChildOf(actor)&&!Cosmetic(hit.collider)&&hit.normal.y>=.65f)return true;}
   return false;
  }
  public object Snapshot(){Observe();return new{attemptedMetres=ThrallSizePolicy.World(clock.UsedDistance),lateralMetres=ThrallSizePolicy.World(clock.UsedLateral),commandedMetres=commanded,observedBodyPathMetres=observedPath,observedBodyNetMetres=observedRoute>=0?Vector3.ProjectOnPlane(Position-firstPosition,Vector3.up).magnitude:0,peakPhysicalSpeed,physicsSamples,positionDiscontinuities,frictionTicks,lastMovingFriction,movingFrictionCombine="Multiply",bodyKinematic=nativeBody&&nativeBody.isKinematic,bodyConstraints=nativeBody?nativeBody.constraints.ToString():"unavailable",blockedSteps=blocked,lastBlocked,routeGain=gain,routeBudget=ThrallSizePolicy.World(ThrallAttackTravelPolicy.RouteDistance),speedLimit=ThrallSizePolicy.World(ThrallAttackTravelPolicy.MaximumSpeed)};}
 }
}
