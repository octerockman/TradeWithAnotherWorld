using System;using System.Collections.Generic;
namespace BlackAbbey.BellThrall {
 // These four already-admitted fitted attacks carry real forward reference
 // curves. Original intake flags rejected their vertical/airborne source
 // features wholesale. This adaptation admits only the horizontal curve;
 // current owner/ground/capsule/floor/clearance and route caps still govern it.
 public static class ThrallAttackAdvanceAdmission {
  static readonly HashSet<string> ForwardAdaptations=new HashSet<string>{"a000_003004","a000_003015","a000_003024","a000_004100"};
  static readonly Dictionary<ThrallAttackAdvanceProfile,ThrallAttackAdvanceProfile> prepared=new Dictionary<ThrallAttackAdvanceProfile,ThrallAttackAdvanceProfile>();
  public static bool CanAdapt(ThrallMotionDescriptor d){
   var p=d?.attackAdvance;if(d==null||p==null||!ForwardAdaptations.Contains(d.id)||p.sourceProfileId!=d.id||p.classification!="advance"||!ThrallMotionPolicy.CombatReady(d)||ThrallMotionPolicy.IsRaised(d.id)||p.times==null||p.times.Length<2||p.times.Length>2000||p.right?.Length!=p.times.Length||p.forward?.Length!=p.times.Length||!ThrallMotionPolicy.Finite(d.duration)||d.duration<=0||Math.Abs(p.times[0])>.00001f||Math.Abs(p.times[p.times.Length-1]-d.duration)>.0001f)return false;
   float maximum=p.forward[0];for(int i=0;i<p.times.Length;i++){if(!ThrallMotionPolicy.Finite(p.times[i])||!ThrallMotionPolicy.Finite(p.forward[i])||!ThrallMotionPolicy.Finite(p.right[i])||(i>0&&p.times[i]<=p.times[i-1]))return false;maximum=Math.Max(maximum,p.forward[i]);}
   return maximum-p.forward[0]>.05f;
  }
  public static ThrallAttackAdvanceProfile For(ThrallMotionDescriptor d){
   var p=d?.attackAdvance;if(p==null||p.eligible||!CanAdapt(d))return p;
   if(prepared.TryGetValue(p,out var cached))return cached;
   var result=new ThrallAttackAdvanceProfile{eligible=true,sourceProfileId=p.sourceProfileId,classification=p.classification,eligibilityReasons=p.eligibilityReasons,times=p.times,right=p.right,forward=p.forward};
   prepared.Add(p,result);return result;
  }
 }
}
