using System;
using System.Collections.Generic;
using HarmonyLib;
using System.Linq;
using System.Reflection;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbey.BellThrall {
 // Presentation observer only. Damage still belongs to the victim's native
 // RPC_Damage/ApplyDamage path; no HitData gameplay field carries audio data.
 [DefaultExecutionOrder(1000)]
 public sealed class ThrallAudio:MonoBehaviour {
  const string EventRpc="BT_AudioEventV1",ContactRpc="BT_AudioContactV1";
  static readonly HashSet<ThrallAudio> actors=new HashSet<ThrallAudio>();
  static readonly List<GameObject> tails=new List<GameObject>();
  static long confirmationSequence;
  readonly ThrallAudioPolicy.Gate gate=new ThrallAudioPolicy.Gate();
  readonly ThrallAudioPolicy.Contacts contacts=new ThrallAudioPolicy.Contacts();
  ZNetView view;Humanoid human;MonsterAI ai;ThrallCombat combat;ThrallSourceMotion motion;
  readonly ThrallAudioEventPolicy.EventLedger sourceEvents=new ThrallAudioEventPolicy.EventLedger();
  readonly ThrallAudioEventPolicy.VoiceGate voiceGate=new ThrallAudioEventPolicy.VoiceGate();
  sealed class FootProbe {public Transform Bone;public Vector3 LastPlant,LastObserved;public bool Seeded;public readonly ThrallAudioEventPolicy.FootPlantLatch Latch=new ThrallAudioEventPolicy.FootPlantLatch();public void Reset(){Seeded=false;Latch.Reset();}}
  FootProbe[] feet;AudioSource air,gear,footAudio;int stepSerial,staggerSerial,weightPacket,lastWeightRoute;int[] arcWeights=Array.Empty<int>();
  float nextBreath,nextHurt,footQuietUntil,nextLeather,nextFrame;bool wasStaggered;uint identity;int sourceAirPlayed,sourceEffortsSent,stepsPlayed,voicesPlayed,footFloorQueries;string lastVoice="";readonly HashSet<int> loggedCues=new HashSet<int>();
  AudioSource breath,voice,warning,impact;Transform voiceAnchor,bellAnchor;
  bool bound,ready,armedLife,wasAlerted,wasOwner,dead,warningHandled;long seenBell,ownerId;int outgoing;
  Vector3 previous;float quietUntil;int emitted,received,contactAccepted;
  static bool callbackFailed;
  public static long Now=>ZNet.instance?ZNet.instance.GetTime().Ticks:DateTime.UtcNow.Ticks;
  bool Owner=>ready&&view&&view.IsValid()&&view.IsOwner()&&wasOwner&&view.GetZDO().GetOwner()==ownerId;
  static bool Finite(Vector3 p)=>ThrallAudioPolicy.Finite(p.x)&&ThrallAudioPolicy.Finite(p.y)&&ThrallAudioPolicy.Finite(p.z);
  public static void Safe(Action action){try{action();}catch(Exception e){if(callbackFailed)return;callbackFailed=true;ThrallCombat.Log?.Invoke("BT_AUDIO_CALLBACK_FAILED "+e.GetBaseException().Message);}}
  void Awake(){view=GetComponent<ZNetView>();human=GetComponent<Humanoid>();ai=GetComponent<MonsterAI>();combat=GetComponent<ThrallCombat>();motion=GetComponent<ThrallSourceMotion>();}
  void OnEnable(){Safe(()=>{if(ready)Resume();});}
  void Start(){Safe(Initialize);}
  void Initialize(){
   if(ready||!view||!view.IsValid()||!human||!ai||!combat||!ThrallEffects.Idle)return;
   var animator=GetComponentInChildren<Animator>(true);voiceAnchor=animator?animator.GetBoneTransform(HumanBodyBones.Head):null;if(!voiceAnchor)voiceAnchor=transform;
   bellAnchor=Array.Find(GetComponentsInChildren<Transform>(true),t=>t.name=="BT1_Bell_Hinge")??voiceAnchor;
   breath=Source(voiceAnchor,"BT Idle Breathing");breath.clip=ThrallEffects.Idle;breath.loop=false;breath.volume=0;
   identity=unchecked((uint)view.GetZDO().m_uid.ToString().GetStableHashCode());
   voice=Source(voiceAnchor,"BT Voice");warning=Source(bellAnchor,"BT Bell Warning");impact=Source(transform,"BT Confirmed Hammer Body");
   air=Source(voiceAnchor,"BT Source Hammer Air");gear=Source(bellAnchor,"BT Burdened Gear");footAudio=Source(transform,"BT Source Foot Plants");
   feet=new[]{"LeftFoot","RightFoot"}.Select(n=>new FootProbe{Bone=Array.Find(GetComponentsInChildren<Transform>(true),t=>t.name==n)}).ToArray();
   foreach(var native in GetComponentsInChildren<FootStep>(true))native.enabled=false;
   if(!bound){view.Register<ZPackage>(EventRpc,Receive);view.Register<ZPackage>(ContactRpc,ReceiveContact);bound=true;}
   ready=true;actors.Add(this);Resume();
  }
  static AudioSource Source(Transform parent,string name){var go=new GameObject(name);go.transform.SetParent(parent,false);var s=ThrallEffects.Audio(go.transform);s.dopplerLevel=0;s.pitch=1;s.priority=100;return s;}
  void Resume(){
   if(!view||!view.IsValid())return;
   gate.Enable(Now);contacts.Clear();sourceEvents.Clear();voiceGate.Reset();if(feet!=null)foreach(var f in feet)f.Reset();weightPacket=lastWeightRoute=0;arcWeights=Array.Empty<int>();nextBreath=Time.time+.8f+(identity%17)*.05f;footQuietUntil=Time.time+.4f;wasStaggered=human&&human.IsStaggering();previous=transform.position;wasAlerted=ai&&ai.IsAlerted();
   ownerId=view.GetZDO().GetOwner();wasOwner=view.IsOwner();seenBell=combat?combat.BellStarted:view.GetZDO().GetLong("bt_bell_start",0);warningHandled=true;quietUntil=Time.time+.3f;
   // Restored already-dead records cannot arm a new death sound.
   if(human&&!human.IsDead()&&human.GetHealth()>0)armedLife=true;
  }
  void Update(){Safe(Tick);}
  void Tick(){
   if(!ready){Initialize();return;}if(!gate.Active||!view||!view.IsValid()){StopAttached();return;}
   long currentOwner=view.GetZDO().GetOwner();if(currentOwner!=ownerId||view.IsOwner()!=wasOwner){StopAttached();Resume();return;}
   bool live=human&&!human.IsDead()&&human.GetHealth()>0&&!dead;if(live)armedLife=true;
   bool teleported=(transform.position-previous).sqrMagnitude>9;previous=transform.position;
   if(teleported){StopAttached();Resume();quietUntil=Time.time+.6f;return;}
   if(!live){StopAttached();return;}
   bool alerted=ai.IsAlerted();if(Owner&&alerted&&!wasAlerted)Send(ThrallAudioPolicy.Cue.Alert,voiceAnchor.position);wasAlerted=alerted;
   long start=combat.BellStarted;bool active=combat.BellActive;float elapsed=combat.BellElapsed,ringTime=combat.BellRingTime;
   if(start!=seenBell){seenBell=start;warningHandled=false;}
   if(!warningHandled&&ThrallBellVariantPolicy.Warning(start,gate.EnabledAt,elapsed,ringTime,active,live,human.IsStaggering())){
    warningHandled=true;warning.Stop();warning.clip=ThrallEffects.Frame;warning.time=Mathf.Min(Mathf.Max(0,elapsed-ThrallBellVariantPolicy.WarningStart(ringTime)),Mathf.Max(0,warning.clip.length-.01f));warning.Play();quietUntil=Time.time+Mathf.Max(0,ThrallBellVariantPolicy.WarningEnd(ringTime)-elapsed);
   }
   if(active&&start>=gate.EnabledAt&&elapsed>=ThrallBellVariantPolicy.HeaveStart(ringTime)&&elapsed<ThrallBellVariantPolicy.HeaveEnd(ringTime)&&!human.IsStaggering()&&sourceEvents.Take("bell-heave:"+start,Time.time)&&Owner)Send(ThrallAudioPolicy.Cue.BellHeave,voiceAnchor.position);
   if(!active||human.IsStaggering()||elapsed>=ThrallBellVariantPolicy.WarningAdmissionEnd(ringTime))warningHandled=true;
   // The warning belongs to the windup, never a cancelled or released pulse.
   if(warning.isPlaying&&(!active||human.IsStaggering()||elapsed>=ThrallBellVariantPolicy.WarningEnd(ringTime)))warning.Stop();
   bool staggering=human.IsStaggering();
   if(Owner&&staggering&&!wasStaggered)Send(((++staggerSerial+(int)(identity%2))%2)==0?ThrallAudioPolicy.Cue.StaggerA:ThrallAudioPolicy.Cue.StaggerB,voiceAnchor.position);
   wasStaggered=staggering;
   bool quiet=Time.time>=quietUntil&&!voice.isPlaying&&!combat.MeleeActive&&!human.InAttack()&&!active&&!staggering&&human.IsOnGround();
   if(!quiet){if(breath.isPlaying){breath.Stop();breath.volume=0;}}
   else if(Time.time>=nextBreath&&!breath.isPlaying){breath.clip=alerted?ThrallEffects.CombatBreath:ThrallEffects.Idle;breath.volume=alerted?.55f:.8f;breath.time=0;breath.Play();nextBreath=Time.time+breath.clip.length+(alerted?3.4f:3f)+(identity%11)*.13f;}
  }
  void LateUpdate(){Safe(FootPlants);}
  void FootPlants(){
   if(!Owner||dead||!human.IsOnGround()||combat.BellActive||!motion||!motion.Ready||Time.time<footQuietUntil){if(feet!=null)foreach(var f in feet)f.Reset();return;}
   if(feet==null)return;
   foreach(var f in feet){
    if(!f.Bone)continue;Vector3 at=f.Bone.position;
    // Stable planted idle feet need no floor query; action/turn/gait motion still
    // reaches the same final-pose ray and lift/replant gate on its moving frames.
    if(f.Seeded&&!motion.Busy&&(at-f.LastObserved).sqrMagnitude<.000001f)continue;
    f.LastObserved=at;footFloorQueries++;
    if(!Finite(at)||!Physics.Raycast(at+Vector3.up*.10f,Vector3.down,out var floor,.8f,ThrallCombat.SolidMask,QueryTriggerInteraction.Ignore)||floor.normal.y<.45f){f.Reset();continue;}
    if(!f.Seeded){f.LastPlant=at;f.Seeded=true;}
    float travel=Vector3.ProjectOnPlane(at-f.LastPlant,Vector3.up).magnitude;
    if(!f.Latch.Observe(Time.time,Mathf.Max(0,at.y-floor.point.y),travel,true))continue;
    f.LastPlant=at;var cue=(ThrallAudioPolicy.Cue)((int)ThrallAudioPolicy.Cue.StepA+(int)((identity+(uint)stepSerial++)%3));Send(cue,floor.point);
   }
  }
  int ArcWeight(ThrallSourceMotion source,float at,bool followup){
   float a=Mathf.Max(0,at-.12f),b=Mathf.Min(source.CurrentDuration,at+.14f);
   if(source.WeaponPoseAt(a,out var first,out _)&&source.WeaponPoseAt(b,out var last,out _)){
    Vector3 delta=last.MultiplyPoint3x4(ThrallCombat.HeadShape.localPosition)-first.MultiplyPoint3x4(ThrallCombat.HeadShape.localPosition);
    if(delta.y<-.16f&&-delta.y>Vector3.ProjectOnPlane(delta,Vector3.up).magnitude*.8f)return 2;
   }
   return followup?0:1;
  }
  // Invoked at Combat order950 before EndContactFrame consumes source crossings.
  public void SourceFrame(ThrallSourceMotion source){
   if(!ready||dead||!gate.Active||!source||!source.AudioAttackAllowed||source.AudioPacketTicks<gate.EnabledAt)return;
   var events=source.AudioSwishTimes;int count=Math.Min(16,events.Length);if(count==0)return;
   if(weightPacket!=source.AudioPacketSerial){bool follow=lastWeightRoute==source.AttackSerial;weightPacket=source.AudioPacketSerial;lastWeightRoute=source.AttackSerial;arcWeights=new int[count];for(int i=0;i<count;i++)arcWeights[i]=ArcWeight(source,events[i],follow||i>0);}
   float previous=source.PreviousSampleTime,current=source.SampleTime;string prefix=source.AttackSerial+":"+source.AudioPacketSerial+":";
   for(int i=0;i<count;i++){
    int weight=arcWeights[i];float lead=weight==2?.30f:weight==0?.12f:.22f;float effortAt=Mathf.Max(source.AudioFrom,events[i]-lead);
    if(ThrallAudioEventPolicy.Crossed(previous,current,effortAt)&&sourceEvents.Take(prefix+"voice:"+i,Time.time)&&Owner){sourceEffortsSent++;Send(weight==2?ThrallAudioPolicy.Cue.OverheadEffort:weight==0?ThrallAudioPolicy.Cue.QuickEffort:ThrallAudioPolicy.Cue.HammerEffort,voiceAnchor.position);}
    if(ThrallAudioEventPolicy.Crossed(previous,current,events[i])&&sourceEvents.Take(prefix+"air:"+i,Time.time)){
     var clip=ThrallEffects.Air(weight,source.AudioPacketSerial+i);if(clip){air.transform.position=combat.HammerAudioPoint;air.PlayOneShot(clip,.72f);sourceAirPlayed++;}
    }
   }
   var windows=source.ContactWindows;if(windows.Length==0)return;float recoveryAt=windows.Max(w=>w.end)+.12f;
   if(recoveryAt<source.AudioTo&&ThrallAudioEventPolicy.Crossed(previous,current,recoveryAt)&&sourceEvents.Take(prefix+"pullback",Time.time)&&ThrallEffects.RecoveryAir.Length>0){
    if(source.WeaponPoseAt(Mathf.Max(0,recoveryAt-.05f),out var a,out _)&&source.WeaponPoseAt(Mathf.Min(source.CurrentDuration,recoveryAt+.05f),out var b,out _)&&(b.MultiplyPoint3x4(ThrallCombat.HeadShape.localPosition)-a.MultiplyPoint3x4(ThrallCombat.HeadShape.localPosition)).sqrMagnitude>.0025f){air.transform.position=combat.HammerAudioPoint;air.PlayOneShot(ThrallEffects.RecoveryAir[source.AudioPacketSerial%ThrallEffects.RecoveryAir.Length],.35f);}
   }
  }

  public void BeginSwing(){
   if(!Owner||dead||!gate.Active)return;contacts.Begin(Now);
  }
  public void RecordSubmission(Character target,Vector3 point){
   if(!Owner||dead||!gate.Active||!target||!Finite(point))return;var v=target.GetComponent<ZNetView>();if(!v||!v.IsValid())return;
   contacts.Add(v.GetZDO().m_uid.ToString(),point.x,point.y,point.z,Now);
  }
  void Send(ThrallAudioPolicy.Cue cue,Vector3 point){
   if(!Owner||!gate.Active||!Finite(point)||(dead&&cue!=ThrallAudioPolicy.Cue.Death))return;
   var p=new ZPackage();p.Write(++outgoing);p.Write((int)cue);p.Write(Now);p.Write(point);emitted++;if(loggedCues.Add((int)cue))ThrallCombat.Log?.Invoke("BT_AUDIO_EVENT role="+cue+" source="+(motion?motion.CurrentClipId:"")+" sequence="+outgoing);
   view.InvokeRPC(ZNetView.Everybody,EventRpc,p);
  }
  void Receive(long sender,ZPackage p){Safe(()=>{
   if(!ready||!gate.Active||!view||!view.IsValid()||view.GetZDO().GetOwner()!=ownerId||view.IsOwner()!=wasOwner)return;
   int sequence=p.ReadInt(),cue=p.ReadInt();long ticks=p.ReadLong();var point=p.ReadVector3();
   if(!Finite(point)||(point-transform.position).sqrMagnitude>144||!gate.Accept(sender,view.GetZDO().GetOwner(),sequence,ticks,Now,cue,dead))return;
   received++;switch((ThrallAudioPolicy.Cue)cue){
    case ThrallAudioPolicy.Cue.Alert:Speak(ThrallEffects.Alert,cue);break;
    case ThrallAudioPolicy.Cue.HammerEffort:Speak(ThrallEffects.Effort,cue);break;
    case ThrallAudioPolicy.Cue.QuickEffort:Speak(ThrallEffects.QuickEffort,cue);break;
    case ThrallAudioPolicy.Cue.OverheadEffort:Speak(ThrallEffects.OverheadEffort,cue);break;
    case ThrallAudioPolicy.Cue.HurtLight:Speak(ThrallEffects.HurtLight,cue);break;
    case ThrallAudioPolicy.Cue.HurtHeavy:Speak(ThrallEffects.HurtHeavy,cue);break;
    case ThrallAudioPolicy.Cue.StaggerA:case ThrallAudioPolicy.Cue.StaggerB:Speak(ThrallEffects.Staggers[cue-(int)ThrallAudioPolicy.Cue.StaggerA],cue);break;
    case ThrallAudioPolicy.Cue.BellHeave:Speak(ThrallEffects.BellHeave,cue);break;
    case ThrallAudioPolicy.Cue.StepA:case ThrallAudioPolicy.Cue.StepB:case ThrallAudioPolicy.Cue.StepC:PlayStep(cue-(int)ThrallAudioPolicy.Cue.StepA,point);break;
    case ThrallAudioPolicy.Cue.HammerBody:impact.transform.position=point;impact.PlayOneShot(ThrallEffects.Body);break;
    case ThrallAudioPolicy.Cue.Death:PlayDeath(point);break;
   }
  });}
  void PlayStep(int variant,Vector3 point){
   if(dead||variant<0||variant>=ThrallEffects.Steps.Length)return;footAudio.transform.position=point;footAudio.PlayOneShot(ThrallEffects.Steps[variant],.85f);stepsPlayed++;
   if(Time.time>=nextLeather&&ThrallEffects.Leather){gear.PlayOneShot(ThrallEffects.Leather,.25f);nextLeather=Time.time+1.4f;}
   if(Time.time>=nextFrame&&ThrallEffects.Frame&&!combat.BellActive){gear.PlayOneShot(ThrallEffects.Frame,.16f);nextFrame=Time.time+3.2f;}
  }
  void Speak(AudioClip clip,int cue){if(dead||!clip||!voiceGate.Take(ThrallAudioEventPolicy.Priority(cue),Time.time,clip.length,voice.isPlaying))return;breath.Stop();breath.volume=0;voice.Stop();voice.clip=clip;voice.Play();voicesPlayed++;lastVoice=clip.name;quietUntil=Time.time+clip.length+.25f;}
  public void Hurt(float lost){
   if(!Owner||dead||lost<=0||Time.time<nextHurt||human.IsDead()||human.IsStaggering())return;nextHurt=Time.time+1f;
   Send(lost>=human.GetMaxHealth()*.06f?ThrallAudioPolicy.Cue.HurtHeavy:ThrallAudioPolicy.Cue.HurtLight,voiceAnchor.position);
  }
  public static void ConfirmDamage(Character victim,HitData hit,float before){Safe(()=>{
   if(!victim||hit==null||hit.m_ranged||before<=0||victim.GetHealth()>=before||hit.GetTotalPhysicalDamage()<=0)return;
   var v=victim.GetComponent<ZNetView>();if(!v||!v.IsValid()||!v.IsOwner())return;
   var attacker=hit.GetAttacker();var a=attacker?attacker.GetComponent<ThrallAudio>():null;if(!a||!a.ready||!a.gate.Active||a.dead||!a.view||!a.view.IsValid()||a.combat.BellActive||!Finite(hit.m_point))return;
   long at=Now;string receipt=v.GetZDO().m_uid+":"+at+":"+(++confirmationSequence);
   if(a.Owner){a.AcceptContact(v.GetZDO().m_uid,hit.m_point,at,at,receipt);return;}
   var p=new ZPackage();p.Write(v.GetZDO().m_uid);p.Write(hit.m_point);p.Write(at);p.Write(receipt);a.view.InvokeRPC(ContactRpc,p);
  });}
  void ReceiveContact(long sender,ZPackage p){Safe(()=>{
   if(!Owner||dead||!gate.Active)return;var victim=p.ReadZDOID();var point=p.ReadVector3();long at=p.ReadLong();string receipt=p.ReadString();
   if(receipt.Length>160||at<gate.EnabledAt||!Finite(point))return;
   var root=ZNetScene.instance?ZNetScene.instance.FindInstance(victim):null;var v=root?root.GetComponent<ZNetView>():null;
   if(!v||!v.IsValid()||v.GetZDO().GetOwner()!=sender||!root.GetComponent<Character>())return;
   AcceptContact(victim,point,at,Now,sender+":"+receipt);
  });}
  void AcceptContact(ZDOID target,Vector3 point,long at,long now,string receipt){
   if(!Owner||dead||!gate.Active||combat.BellActive||at<gate.EnabledAt||!Finite(point)||(point-transform.position).sqrMagnitude>144)return;
   if(contacts.Confirm(target.ToString(),point.x,point.y,point.z,at,now,receipt)){contactAccepted++;Send(ThrallAudioPolicy.Cue.HammerBody,point);}
  }
  public void NativeDeath(){
   if(!Owner||!armedLife||dead||!gate.Active)return;
   var at=voiceAnchor?voiceAnchor.position:transform.position;PlayDeath(at);Send(ThrallAudioPolicy.Cue.Death,at);
  }
  void PlayDeath(Vector3 at){
   if(!armedLife||!gate.TakeDeath())return;dead=true;contacts.Clear();StopAttached();
   tails.RemoveAll(t=>!t);while(tails.Count>=24){Object.Destroy(tails[0]);tails.RemoveAt(0);}
   var tail=new GameObject("BT Detached Death Audio");tail.transform.position=at;var s=ThrallEffects.Audio(tail.transform);s.dopplerLevel=0;s.clip=ThrallEffects.Death;s.Play();ThrallCorpseAudio.FollowDeathVoice(human.GetInstanceID(),s);tails.Add(tail);Object.Destroy(tail,ThrallEffects.Death.length+.25f);
  }
  void StopAttached(){if(breath){breath.Stop();breath.volume=0;}if(voice)voice.Stop();if(warning)warning.Stop();if(impact)impact.Stop();if(air)air.Stop();if(gear)gear.Stop();if(footAudio)footAudio.Stop();}
  void OnDisable(){gate.Disable();contacts.Clear();StopAttached();}
  void OnDestroy(){if(bound&&view){view.Unregister(EventRpc);view.Unregister(ContactRpc);}actors.Remove(this);bound=false;}
  public object Snapshot()=>new{ready,bound,owner=Owner,dead,emitted,received,contactAccepted,sourceEffortsSent,sourceAirPlayed,stepsPlayed,voicesPlayed,lastVoice,footFloorQueries,breathing=breath&&breath.isPlaying,warning=warning&&warning.isPlaying};
  public static void Shutdown(){foreach(var a in actors)if(a){a.gate.Disable();a.StopAttached();}actors.Clear();foreach(var t in tails)if(t)Object.Destroy(t);tails.Clear();ThrallCorpseAudio.Shutdown();callbackFailed=false;}
 }
 public static class ThrallAudioHooks {
  // Only the own actor is suppressed. Keep native effect arrays intact for RPC safety.
  [HarmonyPatch] static class OwnNativeFootsteps {
   static System.Collections.Generic.IEnumerable<MethodBase> TargetMethods()=>AccessTools.GetDeclaredMethods(typeof(FootStep)).Where(m=>m.Name=="OnFoot");
   static bool Prefix(FootStep __instance)=>!__instance||!__instance.GetComponentInParent<ThrallAudio>();
  }

  [HarmonyPatch(typeof(Character),nameof(Character.ApplyDamage))]
  static class Damage {
   static void Prefix(Character __instance,out float __state){__state=0;try{if(__instance)__state=__instance.GetHealth();}catch{}}
   static void Postfix(Character __instance,HitData hit,float __state){ThrallAudio.ConfirmDamage(__instance,hit,__state);ThrallAudio.Safe(()=>{if(__instance&&__state>__instance.GetHealth())__instance.GetComponent<ThrallAudio>()?.Hurt(__state-__instance.GetHealth());});}
  }
  [HarmonyPatch(typeof(Character),nameof(Character.OnDeath))]
  static class Death {static void Prefix(Character __instance){ThrallAudio.Safe(()=>{if(__instance)__instance.GetComponent<ThrallAudio>()?.NativeDeath();});}}
 }
}
