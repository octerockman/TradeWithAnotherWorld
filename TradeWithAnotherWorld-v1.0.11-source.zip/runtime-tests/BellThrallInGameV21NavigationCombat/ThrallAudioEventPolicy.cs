using System;
using System.Collections.Generic;
namespace BlackAbbey.BellThrall {
 // Presentation-only policies; these never change damage, movement or AI.
 public static class ThrallAudioEventPolicy {
  public static bool Crossed(float previous,float current,float at)=>Finite(previous)&&Finite(current)&&Finite(at)&&current>=previous&&previous<at&&current>=at&&current-at<=.35f;
  public static bool Finite(float v)=>!float.IsNaN(v)&&!float.IsInfinity(v);
  public sealed class EventLedger {
   readonly Dictionary<string,float> seen=new Dictionary<string,float>();
   public void Clear()=>seen.Clear();
   public bool Take(string key,float now,float lifetime=12){
    if(string.IsNullOrEmpty(key)||key.Length>160||!Finite(now)||!Finite(lifetime)||lifetime<=0)return false;
    var expired=new List<string>();foreach(var p in seen)if(now<p.Value||now-p.Value>lifetime)expired.Add(p.Key);foreach(var k in expired)seen.Remove(k);
    if(seen.ContainsKey(key)||seen.Count>=256)return false;seen.Add(key,now);return true;
   }
  }
  public sealed class FootPlantLatch {
   bool seeded,lifted;float baseline,last=-100;
   public void Reset(){seeded=lifted=false;last=-100;}
   public bool Observe(float now,float height,float travel,bool grounded){
    if(!Finite(now)||!Finite(height)||!Finite(travel)||height<0||height>.8f||travel<0||!grounded){Reset();return false;}
    if(!seeded){seeded=true;baseline=height;return false;}
    baseline=Math.Min(baseline,height);
    if(height>baseline+.08f)lifted=true;
    if(!lifted||height>baseline+.055f||travel<.08f||now-last<.25f)return false;
    lifted=false;last=now;baseline=height;return true;
   }
  }
  public static int Priority(int cue){
   switch((ThrallAudioPolicy.Cue)cue){
    case ThrallAudioPolicy.Cue.Death:return 10;
    case ThrallAudioPolicy.Cue.StaggerA:case ThrallAudioPolicy.Cue.StaggerB:return 6;
    case ThrallAudioPolicy.Cue.BellHeave:return 5;
    case ThrallAudioPolicy.Cue.HurtHeavy:return 4;
    case ThrallAudioPolicy.Cue.Alert:case ThrallAudioPolicy.Cue.HammerEffort:case ThrallAudioPolicy.Cue.QuickEffort:case ThrallAudioPolicy.Cue.OverheadEffort:return 3;
    case ThrallAudioPolicy.Cue.HurtLight:return 2;
    default:return 0;
   }
  }
  public sealed class VoiceGate {
   int priority;float until,last=-100;
   public void Reset(){priority=0;until=0;last=-100;}
   public bool Take(int next,float now,float duration,bool playing){
    if(next<=0||!Finite(now)||!Finite(duration)||duration<=0)return false;
    if(playing&&now<until&&(next<priority||next==priority&&now-last<.24f))return false;
    priority=next;until=now+duration;last=now;return true;
   }
  }
 }
}
