using System;using System.Linq;using System.Collections.Generic;using System.IO;using UnityEngine;
namespace BlackAbbey.BellThrall {
 public sealed class ThrallWeaponShape {
  public Vector3 localPosition,halfExtents;public Quaternion localRotation;public int section;
  static List<Vector3> Clip(List<Vector3> input,float z,bool lower){var output=new List<Vector3>();if(input.Count==0)return output;var a=input[input.Count-1];bool ain=lower?a.z>=z:a.z<=z;foreach(var b in input){bool bin=lower?b.z>=z:b.z<=z;if(ain!=bin)output.Add(Vector3.LerpUnclamped(a,b,(z-a.z)/(b.z-a.z)));if(bin)output.Add(b);a=b;ain=bin;}return output;}
  public static ThrallWeaponShape[] Fit(ThrallPayload payload){
   var head=ThrallHeadShape.Fit(payload);Quaternion rotation=head.localRotation,inverse=Quaternion.Inverse(rotation);int handId=payload.nodes.Single(n=>n.name=="RightHand").id;var triangles=new List<Vector3[]>();
   foreach(var r in payload.renderers.Where(r=>r.name.Contains("Maul"))){int joint=Array.IndexOf(r.boneNodeIds,handId);if(joint<0||r.weights.Any(w=>w.boneIndex0!=joint||w.weight0<.9999f))throw new InvalidDataException("Expected rigid actual hammer skin bind");var bind=new Matrix4x4();for(int k=0;k<16;k++)bind[k/4,k%4]=r.bindposes[joint].values[k];var vertices=new Vector3[r.positions.Length/3];for(int i=0;i<vertices.Length;i++)vertices[i]=inverse*bind.MultiplyPoint3x4(new Vector3(r.positions[i*3],r.positions[i*3+1],r.positions[i*3+2]));for(int i=0;i<r.triangles.Length;i+=3)triangles.Add(new[]{vertices[r.triangles[i]],vertices[r.triangles[i+1]],vertices[r.triangles[i+2]]});}
   float min=triangles.Min(t=>t.Min(v=>v.z)),max=triangles.Max(t=>t.Max(v=>v.z));var parts=new List<ThrallWeaponShape>();
   for(int i=0;i<6;i++){float lo=Mathf.Lerp(min,max,i/6f),hi=Mathf.Lerp(min,max,(i+1)/6f);var points=new List<Vector3>();foreach(var t in triangles)points.AddRange(Clip(Clip(t.ToList(),lo,true),hi,false));if(points.Count==0)continue;var bounds=new Bounds(points[0],Vector3.zero);foreach(var v in points)bounds.Encapsulate(v);parts.Add(new ThrallWeaponShape{section=i,localPosition=rotation*bounds.center,halfExtents=bounds.extents+Vector3.one*.035f,localRotation=rotation});}
   if(parts.Count!=6)throw new InvalidDataException("Incomplete fitted hammer sections");return parts.ToArray();
  }
  public static Vector3 Point(Collider collider,Vector3 at)=>collider is MeshCollider mesh&&!mesh.convex?collider.bounds.ClosestPoint(at):collider.ClosestPoint(at);
 }
}
