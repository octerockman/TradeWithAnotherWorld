using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;
using UnityEngine.AI;
using Object = UnityEngine.Object;

namespace BlackAbbey.BellThrall
{
    // The installed native tile bake spans Y=-500..5500. Abbey test rooms are
    // at Y~8000. Give only each own owner-controlled Thrall a private nav agent
    // and local collider bake; keep native AI choices, caching and steering.
    public sealed class ThrallDungeonNavigation : MonoBehaviour
    {
        public const float DungeonAltitude = 7000f;
        const float RegionSpan = 72f, RegionSnap = 12f, RefreshSeconds = 1.5f;
        static readonly HashSet<ThrallDungeonNavigation> Active = new HashSet<ThrallDungeonNavigation>();
        static readonly MethodInfo NativeGetSettings = AccessTools.Method(typeof(Pathfinding), "GetSettings");
        static readonly FieldInfo LastNativeFindTime = AccessTools.Field(typeof(BaseAI), "m_lastFindPathTime");
        static readonly MethodInfo GetPathMethod = AccessTools.Method(typeof(Pathfinding), "GetPath", new[] { typeof(Vector3), typeof(Vector3), typeof(List<Vector3>), typeof(Pathfinding.AgentType), typeof(bool), typeof(bool), typeof(bool) });
        static readonly MethodInfo HavePathMethod = AccessTools.Method(typeof(Pathfinding), "HavePath", new[] { typeof(Vector3), typeof(Vector3), typeof(Pathfinding.AgentType) });
        BaseAI ai; Character character; ZNetView view; CapsuleCollider capsule;
        Action<string> log;
        NavMeshBuildSettings settings;
        NavMeshData data; NavMeshDataInstance instance;
        AsyncOperation pending;
        List<NavMeshBuildSource> retainedBuildSources;
        readonly NavMeshPath path = new NavMeshPath();
        Bounds worldBounds;
        Vector3 origin;
        bool settingsCreated, ready, released;
        int sourceMask, sourceCount, checks, builds, completed, queries, successes, failures, cacheRefreshes, lastCornerCount;
        ulong sourceSignature;
        float nextRefresh;
        float measuredHeight, measuredRadius, buildStarted, longestBuild, nextQueryLog;
        Vector3 lastFrom, lastTo;
        string failure, lastPathStatus, floorName;
        public bool Ready => ready;

        public static ThrallDungeonNavigation Attach(GameObject actor, Action<string> logger = null)
        {
            if (!actor || !actor.GetComponent<ThrallInstance>()) return null;
            var existing = actor.GetComponent<ThrallDungeonNavigation>(); if (existing) return existing;
            var result = actor.AddComponent<ThrallDungeonNavigation>();
            result.ai = actor.GetComponent<BaseAI>(); result.character = actor.GetComponent<Character>();
            result.view = actor.GetComponent<ZNetView>(); result.capsule = actor.GetComponent<CapsuleCollider>();
            result.log = logger; Active.Add(result); return result;
        }
        bool Eligible => ai && character && !character.IsDead() && view && view.IsValid() && view.IsOwner()
            && GetComponent<ThrallInstance>() && transform.position.y > DungeonAltitude;
        static bool Finite(Vector3 p) => !(float.IsNaN(p.x) || float.IsNaN(p.y) || float.IsNaN(p.z)
            || float.IsInfinity(p.x) || float.IsInfinity(p.y) || float.IsInfinity(p.z));
        static float[] V(Vector3 v) => new[] { v.x, v.y, v.z };
        void Update()
        {
            if (!Eligible) { if (settingsCreated) Release("ownership, altitude or lifecycle changed"); return; }
            if (released) released = false;
            try
            {
                if (!settingsCreated && Time.realtimeSinceStartup < nextRefresh) return;
                if (!settingsCreated) Initialize();
                if (pending != null)
                {
                    if (!pending.isDone) return;
                    pending = null; retainedBuildSources = null; completed++;
                    if (!instance.valid) { instance = NavMesh.AddNavMeshData(data); instance.owner = gameObject; }
                    ready = instance.valid;
                    if (!ready) throw new InvalidOperationException("Own completed nav data did not register.");
                    failure = null;
                    longestBuild = Mathf.Max(longestBuild, Time.realtimeSinceStartup - buildStarted);
                    // A native failed request can otherwise stay cached for5s.
                    // Only invalidate this own actor's cache after its bake.
                    LastNativeFindTime.SetValue(ai, Time.time - 6f); cacheRefreshes++;
                    log?.Invoke("BT_DUNGEON_NAV_READY sources=" + sourceCount + " agent=" + settings.agentTypeID + " height=" + measuredHeight + " radius=" + measuredRadius);
                }
                if (Time.realtimeSinceStartup < nextRefresh) return;
                nextRefresh = Time.realtimeSinceStartup + RefreshSeconds;
                Refresh();
            }
            catch (Exception error)
            {
                failure = error.Message; Release("local nav initialization/build failed");
                nextRefresh = Time.realtimeSinceStartup + 5f;
                log?.Invoke("BT_DUNGEON_NAV_FAILED " + error);
            }
        }
        void Initialize()
        {
            if (!capsule || !Pathfinding.instance || NativeGetSettings == null || LastNativeFindTime == null)
                throw new InvalidOperationException("Actual native pathfinder, capsule or cache API unavailable.");
            int layer = LayerMask.NameToLayer("static_solid");
            if (layer < 0 || (Pathfinding.instance.m_layers.value & (1 << layer)) == 0)
                throw new InvalidOperationException("Authored room layer is absent from native static geometry mask.");
            sourceMask = 1 << layer;
            var nativeAgent = NativeGetSettings.Invoke(Pathfinding.instance, new object[] { ai.m_pathAgentType });
            var nativeBuild = (NavMeshBuildSettings)AccessTools.Field(nativeAgent.GetType(), "m_build").GetValue(nativeAgent);
            measuredHeight = capsule.bounds.size.y;
            measuredRadius = Mathf.Max(capsule.bounds.extents.x, capsule.bounds.extents.z);
            if (measuredHeight < .2f || measuredHeight > 5 || measuredRadius < .05f || measuredRadius > 2)
                throw new InvalidOperationException("Own world capsule dimensions are invalid.");
            settings = ThrallNavigationGeometry.Create(capsule,nativeBuild); settingsCreated = true;
            origin = Snapped(transform.position);
            data = new NavMeshData(settings.agentTypeID) { name = "HM Own Dungeon Navigation", position = origin, rotation = Quaternion.identity };
            instance = default;
            ready = false; nextRefresh = 0;
        }
        static Vector3 Snapped(Vector3 p) => new Vector3(Mathf.Round(p.x / RegionSnap), Mathf.Round(p.y / RegionSnap), Mathf.Round(p.z / RegionSnap)) * RegionSnap;
        void Refresh()
        {
            checks++;
            var center = Snapped(transform.position);
            var bounds = new Bounds(center, Vector3.one * RegionSpan);
            var sources = new List<NavMeshBuildSource>();
            NavMeshBuilder.CollectSources(bounds, sourceMask, NavMeshCollectGeometry.PhysicsColliders, 0, new List<NavMeshBuildMarkup>(), sources);
            sources.RemoveAll(s => s.component is Collider c && (!c.enabled || c.isTrigger || !c.gameObject.activeInHierarchy));
            if (sources.Count == 0 || sources.Count > 4096) throw new InvalidOperationException("No valid bounded dungeon collision sources, or source limit exceeded.");
            // Collection order is normalized so unchanged geometry does not
            // cause another bake. Door movement/enabling changes this hash.
            sources.Sort((a, b) => (a.component ? a.component.GetInstanceID() : 0).CompareTo(b.component ? b.component.GetInstanceID() : 0));
            ulong signature = Signature(sources);
            if (Physics.Raycast(transform.position + Vector3.up * .5f, Vector3.down, out var floor, 3f, sourceMask, QueryTriggerInteraction.Ignore))
                floorName = floor.collider ? floor.collider.name : null;
            if (ready && signature == sourceSignature && worldBounds.center == center) return;
            sourceCount = sources.Count; sourceSignature = signature; worldBounds = bounds;
            retainedBuildSources = sources;
            pending = NavMeshBuilder.UpdateNavMeshDataAsync(data, settings, retainedBuildSources, new Bounds(center - origin, Vector3.one * RegionSpan));
            buildStarted = Time.realtimeSinceStartup; builds++;
            if (pending == null) throw new InvalidOperationException("Own asynchronous nav bake did not start.");
        }
        static ulong Signature(List<NavMeshBuildSource> sources)
        {
            unchecked
            {
                ulong hash = 1469598103934665603;
                foreach (var source in sources)
                {
                    hash = (hash ^ (uint)(source.component ? source.component.GetInstanceID() : 0)) * 1099511628211;
                    hash = (hash ^ (uint)(source.sourceObject ? source.sourceObject.GetInstanceID() : 0)) * 1099511628211;
                    hash = (hash ^ (uint)source.shape) * 1099511628211;
                    hash = (hash ^ (uint)source.area) * 1099511628211;
                    hash = (hash ^ (uint)source.size.GetHashCode()) * 1099511628211;
                    var matrix = source.transform;
                    for (int i = 0; i < 16; i++) hash = (hash ^ (uint)matrix[i].GetHashCode()) * 1099511628211;
                }
                return hash;
            }
        }
        bool Calculate(Vector3 from, Vector3 to, List<Vector3> result, bool requireFullPath)
        {
            queries++; lastFrom=from; lastTo=to; if (result != null) result.Clear(); lastCornerCount = 0;
            if (!ready || !Finite(from) || !Finite(to) || !worldBounds.Contains(from) || !worldBounds.Contains(to))
                return QueryFailed("not ready or outside own bounded data");
            var filter = new NavMeshQueryFilter { agentTypeID = settings.agentTypeID, areaMask = 1 };
            if (!NavMesh.SamplePosition(from, out var start, 1.25f, filter) || !NavMesh.SamplePosition(to, out var end, 1.25f, filter)
                || Mathf.Abs(start.position.y - from.y) > .8f || Mathf.Abs(end.position.y - to.y) > .8f)
                return QueryFailed("endpoint absent from same-floor own nav surface");
            bool found = NavMesh.CalculatePath(start.position, end.position, filter, path);
            lastPathStatus = path.status.ToString();
            if (!found || path.status == NavMeshPathStatus.PathInvalid || (requireFullPath && path.status != NavMeshPathStatus.PathComplete))
                return QueryFailed("native query "+path.status);
            var corners = path.corners; lastCornerCount = corners.Length;
            // A complete nearby/coincident endpoint may have one corner.
            // HavePath asks reachability, not whether there is another turn.
            if (corners.Length < 1) return QueryFailed("native query has no corners");
            if (result != null) result.AddRange(corners);
            successes++;
            if(successes<=3)log?.Invoke("BT_DUNGEON_NAV_QUERY_OK queries="+queries+" corners="+lastCornerCount+" status="+lastPathStatus+" from="+from+" to="+to);
            return true;
        }
        bool QueryFailed(string reason)
        {
            failures++;lastPathStatus=reason;
            if(Time.time>=nextQueryLog){nextQueryLog=Time.time+3;log?.Invoke("BT_DUNGEON_NAV_QUERY_FAILED reason="+reason+" queries="+queries+" failures="+failures+" ready="+ready+" from="+lastFrom+" to="+lastTo);}
            return false;
        }
        public object ProbeRoute(Vector3 from, Vector3 to)
        {
            var corners = new List<Vector3>(); bool result = Calculate(from, to, corners, true);
            return new { passed = result, from = V(from), to = V(to), corners = corners.Select(V).ToArray(), status = lastPathStatus, navigation = Snapshot() };
        }
        public bool TryRouteForProof(Vector3 from, Vector3 to, List<Vector3> corners, bool requireFullPath = true) => Calculate(from, to, corners, requireFullPath);
        public bool TryProbePath(Vector3 start, Vector3 goal, out List<Vector3> corners)
        { corners = new List<Vector3>(); return Calculate(start, goal, corners, true); }
        public static object TargetDiagnostics(GameObject actor, Character target)
        {
            if (!actor || !target) return new { available = false };
            var character = actor.GetComponent<Character>(); var ai = actor.GetComponent<BaseAI>();
            if (!character || !ai) return new { available = false };
            object Read(string name) => AccessTools.Field(ai.GetType(), name)?.GetValue(ai);
            object Call(string name)
            {
                try { return AccessTools.Method(typeof(BaseAI), name, new[] { typeof(Character) })?.Invoke(ai, new object[] { target }); }
                catch (Exception error) { return error.GetBaseException().Message; }
            }
            Vector3 eye = character.m_eye ? character.m_eye.position : character.GetCenterPoint();
            Vector3 targetEye = target.IsCrouching() || !target.m_eye ? target.GetCenterPoint() : target.m_eye.position;
            int mask = (int)AccessTools.Field(typeof(BaseAI), "m_viewBlockMask").GetValue(null);
            Vector3 delta = targetEye - eye;
            var occluders = Physics.RaycastAll(eye, delta.normalized, delta.magnitude, mask, QueryTriggerInteraction.UseGlobal)
                .OrderBy(hit => hit.distance).Select(hit => new { name = hit.collider ? hit.collider.name : null,
                    layer = hit.collider ? LayerMask.LayerToName(hit.collider.gameObject.layer) : null,
                    trigger = hit.collider && hit.collider.isTrigger, point = V(hit.point), hit.distance }).ToArray();
            var nativeCharacter = Read("m_character") as Character;
            var nativeView = Read("m_nview") as ZNetView;
            object playing;
            try { playing = AccessTools.Method(AccessTools.TypeByName("CinematicsManager"), "IsPlaying")?.Invoke(null, null); }
            catch (Exception error) { playing = error.GetBaseException().Message; }
            return new { available = true, readOnly = true, characterInGlobalList = Character.GetAllCharacters().Contains(character),
                targetInGlobalList = Character.GetAllCharacters().Contains(target), actorCharacter = character.m_name,
                actorFaction = character.GetFaction().ToString(), targetFaction = target.GetFaction().ToString(),
                character.m_aiCannotTargetOthers, targetSkip = target.m_aiSkipTarget, actorTamed = character.IsTamed(), targetTamed = target.IsTamed(),
                aiEnabled = ai.enabled, aiActive = ai.isActiveAndEnabled, sleeping = ai.IsSleeping(), alerted = ai.IsAlerted(),
                referencedCharacterIsOwn = nativeCharacter == character, referencedViewIsOwn = nativeView == actor.GetComponent<ZNetView>(),
                nativeViewOwner = nativeView && nativeView.IsValid() && nativeView.IsOwner(),
                canSee = Call("CanSeeTarget"), canHear = Call("CanHearTarget"), canSense = Call("CanSenseTarget"),
                enemy = AccessTools.Method(typeof(BaseAI), "IsEnemy", new[] { typeof(Character), typeof(Character) }).Invoke(null, new object[] { character, target }),
                passiveMobs = ZoneSystem.instance && ZoneSystem.instance.GetGlobalKey(GlobalKeys.PassiveMobs), cinematicsPlaying = playing,
                actorPosition = V(actor.transform.position), actorForward = V(actor.transform.forward), eye = V(eye), targetEye = V(targetEye),
                angle = Vector3.Angle(target.transform.position - actor.transform.position, actor.transform.forward),
                viewRange = ai.m_viewRange, viewAngle = ai.m_viewAngle, hearingRange = ai.m_hearRange,
                stealthFactor = target.GetStealthFactor(), targetNoise = target.GetNoiseRange(), targetGhost = target.InGhostMode(), targetCrouched = target.IsCrouching(),
                viewBlockMask = mask, viewBlockLayers = Enumerable.Range(0, 32).Where(i => (mask & (1 << i)) != 0).Select(LayerMask.LayerToName).ToArray(), occluders,
                updateTargetTimer = Read("m_updateTargetTimer"), timeSinceSensed = Read("m_timeSinceSensedTargetCreature"),
                lastNativeFindTime = Read("m_lastFindPathTime"), lastNativeFindResult = Read("m_lastFindPathResult"),
                aggravated = Read("m_aggravated"), passiveAggressive = ai.m_passiveAggresive,
                scope = "Reads native sensory/faction/target gates and real eye-line occluders only; does not call FindEnemy/UpdateTarget/SetTarget, alter world flags or force AI." };
        }
        public object Snapshot() => new { eligible = this && Eligible, ready, building = pending != null && !pending.isDone,
            agentTypeId = settingsCreated ? settings.agentTypeID : -1, measuredHeight, measuredRadius, buildHeight = settingsCreated ? settings.agentHeight : 0,
            buildRadius = settingsCreated ? settings.agentRadius : 0, sources = sourceCount, sourceMask, geometryChecks = checks, builds, completed, queries, successes, failures,
            lastPathStatus, lastCornerCount, lastFrom=V(lastFrom), lastTo=V(lastTo), cacheRefreshes, longestBuildSeconds = longestBuild, failure, floor = floorName,
            boundsCenter = V(worldBounds.center), boundsSize = V(worldBounds.size), released,
            nativeBakeCenterY = 2500, nativeBakeHeight = 6000, nativeUnmodified = true,
            scope = "Own owner-controlled high-altitude Thrall only. Private nav agent/data from actual static_solid physics colliders. Native FindPath cache and MoveTo steering retained; no forced target/movement/teleport or global tile/mask edits." };
        void Release(string reason)
        {
            if (data) NavMeshBuilder.Cancel(data);
            pending = null; retainedBuildSources = null;
            if (instance.valid) instance.Remove();
            if (data) Object.Destroy(data); data = null;
            if (settingsCreated) NavMesh.RemoveSettings(settings.agentTypeID);
            settingsCreated = false; ready = false; released = true;
            log?.Invoke("BT_DUNGEON_NAV_RELEASE " + reason);
        }
        void OnDisable() { if (settingsCreated) Release("disabled"); }
        void OnDestroy() { if (settingsCreated) Release("destroyed"); Active.Remove(this); }
        public static void Shutdown() { foreach (var item in Active.ToArray()) if (item && item.settingsCreated) item.Release("plugin shutdown"); }

        static ThrallDungeonNavigation Own(BaseAI owner)
        {
            if (!owner || !owner.GetComponent<ThrallInstance>() || owner.transform.position.y <= DungeonAltitude) return null;
            var navigation = owner.GetComponent<ThrallDungeonNavigation>();
            return navigation && navigation.Eligible ? navigation : null;
        }
        // Scope only the query made by this BaseAI call. Native caching and
        // MoveTo remain in place. Prefixes cooperate with Monk's existing
        // path-call transpiler rather than replacing that call a second time.
        [ThreadStatic] static BaseAI queryOwner;
        static void Push(BaseAI owner,out BaseAI previous){previous=queryOwner;queryOwner=owner;}
        static Exception Pop(Exception error,BaseAI previous){queryOwner=previous;return error;}
        [HarmonyPatch(typeof(BaseAI), "FindPath")]
        static class FindPathScope {
            static void Prefix(BaseAI __instance,out BaseAI __state)=>Push(__instance,out __state);
            static Exception Finalizer(Exception __exception,BaseAI __state)=>Pop(__exception,__state);
        }
        [HarmonyPatch(typeof(BaseAI), "HavePath")]
        static class HavePathScope {
            static void Prefix(BaseAI __instance,out BaseAI __state)=>Push(__instance,out __state);
            static Exception Finalizer(Exception __exception,BaseAI __state)=>Pop(__exception,__state);
        }
        [HarmonyPatch(typeof(Pathfinding), "GetPath", new[]{typeof(Vector3),typeof(Vector3),typeof(List<Vector3>),typeof(Pathfinding.AgentType),typeof(bool),typeof(bool),typeof(bool)})]
        static class GetPathHook {
            static bool Prefix(Vector3 __0,Vector3 __1,List<Vector3> __2,bool __6,ref bool __result){
                var own=Own(queryOwner);if(!own)return true;
                __result=own.Calculate(__0,__1,__2,__6);return false;
            }
        }
        [HarmonyPatch(typeof(Pathfinding), "HavePath", new[]{typeof(Vector3),typeof(Vector3),typeof(Pathfinding.AgentType)})]
        static class HavePathHook {
            static bool Prefix(Vector3 __0,Vector3 __1,ref bool __result){
                var own=Own(queryOwner);if(!own)return true;
                __result=own.Calculate(__0,__1,null,true);return false;
            }
        }
    }
}
