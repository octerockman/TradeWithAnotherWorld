using System;using System.Collections.Generic;using System.Linq;using Newtonsoft.Json;using UnityEngine;
namespace BlackAbbey.BellThrall {
 [DefaultExecutionOrder(900)]
 public sealed class ThrallSourceMotion:MonoBehaviour {
  const string StateKey="bt_source_motion_v1",DeathRpc="BT_SourceDeathV1";
  public static ThrallSourceBank Bank;public static ThrallReceiveShape[] ReceiveShapes;public static Action<string> Log;
  readonly ThrallMotionPolicy.Gate gate=new ThrallMotionPolicy.Gate();
  readonly ThrallLocomotionPlayback locomotion=new ThrallLocomotionPlayback();
  readonly Queue<ThrallMotionRouteStep> plan=new Queue<ThrallMotionRouteStep>();
  readonly Vector3[] sampled=new Vector3[58],blendPositions=new Vector3[58];
  readonly Quaternion[] sampledRotations=new Quaternion[58],blendRotations=new Quaternion[58];
  readonly ThrallPresentedPoseCache presented=new ThrallPresentedPoseCache();readonly float[] presentedP=new float[174],presentedQ=new float[232];
  readonly Collider[] clearance=new Collider[64];
  ThrallAttackTravel advance;ThrallSourceClip preparedAttack;ThrallTacticsCandidate preparedTactic;long preparedOwner;float preparedTime,routeTravelGain=1;string lastTravelResult="";
  Transform[] bones;Transform visual,poseParent;Animator animator;Humanoid human;MonsterAI ai;ZNetView view;ThrallCombat combat;ThrallReceiveVolumes receive;
  ThrallSourceClip action,display;ThrallMotionPacket packet;string packetText="",bodyState="standing",displayId="";
  Vector3 previousPosition,previousForward;float phase,blendStarted,actionPrevious,actionNow;
  long owner;int serial,actionSerial,attackCursor,hurtCursor,deathCursor,effortSerial;bool ready,bound,disabled,dead,swish,contact,wasStaggering,restoredVisualOnly,hasBodyHold,routeRestored,finalPosePresented,armedLife,recoveryAttempted;
  double gaitDistancePhase;float moved,yawDelta,filteredYawRate;int trackedActionSerial;bool trackingCommitted,trackingWindup;Vector3 committedHeading;string observedKind="",turnId;uint identity;int turnSerial,handIndex,leftFootIndex,rightFootIndex;bool turning;Vector3 presentedRootPosition,presentedRootScale,presentedLeft,presentedRight;Quaternion presentedRootRotation;
  readonly ThrallReactionGate reactionGate=new ThrallReactionGate();
  int trackingPacket,trackingGroup=-1;bool strikeWasCommitted;string trackingPhase="none";
  static long Now=>ThrallAudio.Now;
  bool Owner=>owner!=0&&ready&&!disabled&&!dead&&human&&!human.IsDead()&&view&&view.IsValid()&&view.IsOwner()&&view.GetZDO().GetOwner()==owner;
  public bool Ready=>ready&&!disabled;
  public bool Busy=>action!=null&&!dead;
  public bool SourceAttackActive=>Busy&&(observedKind=="Entry"||observedKind=="Attack"||observedKind=="Recovery");
  public bool Blocking=>hasBodyHold||Busy&&(SourceAttackActive||observedKind=="Reaction"||observedKind=="Context");
  public string CurrentClipId=>displayId;
  public float SampleTime=>actionNow;
  public float CurrentDuration=>action?.duration??0;
  public float PreviousSampleTime=>actionPrevious;
  public bool ContactActive=>ThrallMotionPolicy.CanEmitEffects(SourceAttackActive&&observedKind=="Attack"&&contact,restoredVisualOnly,!dead&&!human.IsStaggering());
  public bool SwishCrossed=>ThrallMotionPolicy.CanEmitEffects(SourceAttackActive&&observedKind=="Attack"&&swish,restoredVisualOnly,!dead);
  public bool CanBeginAttack=>Ready&&!Busy&&!hasBodyHold&&!dead&&Bank.Clips.Values.Any(c=>ThrallMotionPolicy.CombatReady(c.Descriptor)&&CanEnter(c.Descriptor));
  public ThrallMotionWindow[] ContactWindows=>action?.Descriptor.contactWindows??Array.Empty<ThrallMotionWindow>();
  public int AttackSerial=>ThrallMotionPolicy.CanEmitEffects(observedKind=="Attack",restoredVisualOnly,!dead)?effortSerial:0;
  public bool AudioFramesAllowed=>Ready&&!dead&&!restoredVisualOnly&&packet!=null&&!human.IsStaggering();
  public bool AudioAttackAllowed=>AudioFramesAllowed&&observedKind=="Attack";
  public int AudioPacketSerial=>packet?.serial??0;
  public long AudioPacketTicks=>packet?.ticks??0;
  public float AudioFrom=>packet?.from??0;
  public float AudioTo=>packet?.to??0;
  public float[] AudioSwishTimes=>action?.Descriptor.swishTimes??Array.Empty<float>();
  public float Recovery=>action?.Descriptor.recovery??ThrallCombatPolicy.Recovery;
  void Awake(){human=GetComponent<Humanoid>();ai=GetComponent<MonsterAI>();view=GetComponent<ZNetView>();combat=GetComponent<ThrallCombat>();animator=GetComponentInChildren<Animator>(true);}
  void Start(){try{Initialize();}catch(Exception e){Fail(e);}}
  void Initialize(){
   if(Bank==null||!human||!view||!view.IsValid()||!animator){enabled=false;return;}
   visual=animator.transform;var named=visual.GetComponentsInChildren<Transform>(true).GroupBy(t=>t.name).ToDictionary(g=>g.Key,g=>g.First());
   if(Bank.Manifest.boneNames.Any(n=>!named.ContainsKey(n))){enabled=false;Log?.Invoke("BT_SOURCE_BIND_FAILED actor disabled; own bones unavailable");return;}
   bones=Bank.Manifest.boneNames.Select(n=>named[n]).ToArray();poseParent=bones[0].parent;if(!poseParent)throw new InvalidOperationException("Animated-root parent unavailable");animator.applyRootMotion=false;
   handIndex=Array.IndexOf(Bank.Manifest.boneNames,"RightHand");leftFootIndex=Array.IndexOf(Bank.Manifest.boneNames,"LeftFoot");rightFootIndex=Array.IndexOf(Bank.Manifest.boneNames,"RightFoot");
   receive=new ThrallReceiveVolumes(transform,named,ReceiveShapes,named.ContainsKey("BT_Head_Hit")?named["BT_Head_Hit"].gameObject.layer:gameObject.layer);
   Bank.Sample(Bank.Clips["a000_000020"],0,sampled,sampledRotations);for(int i=0;i<58;i++){bones[i].localPosition=sampled[i];bones[i].localRotation=sampledRotations[i];}CachePresentedPose();
   receive.Enable();advance=new ThrallAttackTravel(transform,GetComponent<CapsuleCollider>());
   identity=unchecked((uint)view.GetZDO().m_uid.ToString().GetStableHashCode());attackCursor=(int)(identity%40);hurtCursor=(int)(identity%42);deathCursor=(int)(identity%10);
   human.m_onDamaged+=Damaged;view.Register<string>(DeathRpc,ReceiveDeath);bound=true;ready=true;Resume();
  }
  void OnEnable(){if(ready)Resume();}
  void Resume(){
   DiscardPreparedMelee();routeTravelGain=1;
   if(!view||!view.IsValid())return;disabled=false;owner=view.GetZDO().GetOwner();serial=Math.Max(serial,view.GetZDO().GetInt("bt_source_serial",0));gate.Enable(owner,Now);packetText="";plan.Clear();action=null;display=null;displayId="";phase=0;
   locomotion.Reset();advance?.Reset();filteredYawRate=0;trackedActionSerial=trackingPacket=0;trackingGroup=-1;strikeWasCommitted=false;trackingPhase="none";trackingCommitted=trackingWindup=false;
   bodyState=view.GetZDO().GetString("bt_source_body_state","standing");hasBodyHold=false;routeRestored=false;previousPosition=transform.position;previousForward=transform.forward;wasStaggering=human&&human.IsStaggering();reactionGate.Reset(Time.time,wasStaggering);
   if(human&&!human.IsDead()&&human.GetHealth()>0)armedLife=true;
   receive?.Enable();
   Observe(true);
   recoveryAttempted=false;if(action==null&&!ThrallMotionPolicy.Standing(bodyState))RestoreContextPose();
  }
  void Damaged(float amount,Character attacker){
   if(!Owner||amount<=0||!reactionGate.TryOrdinary(Time.time,action!=null&&observedKind=="Reaction",human.IsStaggering(),combat&&combat.BellActive,SourceAttackActive))return;
   BeginReaction(false);
  }
  void BeginReaction(bool native){
   if(!Owner||Bank==null)return;
   // A native forced stagger breaks the old context. CaptureBlend below retains
   // the actual presented pose; no actor translation/rotation is assigned here.
   string state=native&&!ThrallMotionPolicy.Standing(bodyState)?"standing":bodyState;
   var preferred=native?ThrallReactionPolicy.NativeIds:ThrallReactionPolicy.OrdinaryIds;
   var candidates=preferred.Where(id=>Bank.Clips.ContainsKey(id)).Select(id=>Bank.Clips[id]).Where(c=>c.Descriptor.category=="HurtAndKnockdown"&&c.Descriptor.contextSupported&&c.Descriptor.autonomousEligible&&ThrallMotionPolicy.Compatible(state,c.Descriptor.startState)&&ThrallMotionPolicy.Standing(c.Descriptor.endState)).ToArray();
   if(candidates.Length==0){Log?.Invoke("BT_REACTION_UNAVAILABLE native="+native+" state="+state);return;}
   var chosen=candidates[(hurtCursor++)%candidates.Length];plan.Clear();routeRestored=false;actionSerial=0;bodyState=state;
   Begin(chosen.id,"Reaction");reactionGate.Admit(Time.time,chosen.duration,native);
   Log?.Invoke("BT_REACTION_BEGIN native="+native+" clip="+chosen.id+" duration="+chosen.duration+" nextOrdinary="+reactionGate.NextOrdinaryAt);
  }
  public IEnumerable<ThrallMotionDescriptor> TacticalDescriptors(bool physicalClearance=true){
   if(Bank==null)yield break;
   foreach(var clip in Bank.Clips.Values.OrderBy(c=>c.id)){var d=clip.Descriptor;
    if(d.category=="Attacks"&&ThrallMotionPolicy.CombatReady(d)&&CanEnter(d)&&(!physicalClearance||!d.requiresClearance||HasVisualClearance(d)))yield return d;
   }
  }
  public void DiscardPreparedMelee(){preparedAttack=null;preparedTactic=null;preparedOwner=0;}
  public bool PrepareMelee(){
   DiscardPreparedMelee();if(!Owner||Busy||combat&&combat.BellActive)return false;
   var tactics=GetComponent<ThrallTactics>();if(!tactics)return false;
   var choice=tactics.Choose(TacticalDescriptors());if(choice.Kind!=ThrallTacticsKind.Attack||choice.Selected==null||!Bank.Clips.TryGetValue(choice.Selected.RouteId,out var clip))return false;
   preparedAttack=clip;preparedTactic=choice.Selected;preparedOwner=owner;preparedTime=Time.time;return true;
  }
  public bool TryBeginMelee(string nativeToken){
   if(!Owner||Busy||combat&&combat.BellActive){DiscardPreparedMelee();return false;}
   if(preparedAttack==null||preparedOwner!=owner||Time.time-preparedTime>.25f){if(!PrepareMelee())return false;}
   var clip=preparedAttack;var selected=preparedTactic;DiscardPreparedMelee();var d=clip.Descriptor;
   if(!ThrallMotionPolicy.CombatReady(d)||!CanEnter(d))return false;
   plan.Clear();routeRestored=false;actionSerial=0;EnqueueHelpers(d,true);plan.Enqueue(new ThrallMotionRouteStep{id=clip.id,kind="Attack"});EnqueueHelpers(d,false);
   routeTravelGain=PlannedTravelGain();Next();if(!SourceAttackActive)return false;GetComponent<ThrallTactics>()?.Commit(selected);return true;
  }
  bool HasVisualClearance(ThrallMotionDescriptor d){
   // Only explicitly flagged large body moves use this check. Ordinary weapon
   // arcs use the existing wall-aware hammer sweep and native navigation.
   if(d.bodyBoundsUnityMin?.Length!=3||d.bodyBoundsUnityMax?.Length!=3)return false;var min=ThrallVisual.V(d.bodyBoundsUnityMin)*ThrallSizePolicy.Multiplier;var max=ThrallVisual.V(d.bodyBoundsUnityMax)*ThrallSizePolicy.Multiplier;min.y=Mathf.Max(.25f,min.y);max+=Vector3.one*.10f;min.x-=.10f;min.z-=.10f;var half=(max-min)*.5f;if(half.x<=0||half.y<=0||half.z<=0)return false;var rootScale=transform.lossyScale;half=Vector3.Scale(half,new Vector3(Mathf.Abs(rootScale.x),Mathf.Abs(rootScale.y),Mathf.Abs(rootScale.z)));
   int count=Physics.OverlapBoxNonAlloc(transform.TransformPoint((min+max)*.5f),half,clearance,transform.rotation,ThrallCombat.SolidMask,QueryTriggerInteraction.Ignore);
   if(count>=clearance.Length)return false;for(int i=0;i<count;i++)if(clearance[i]&&!clearance[i].transform.IsChildOf(transform))return false;return true;
  }
  public bool RequestContext(string id){
   if(!Owner||Busy||combat&&combat.BellActive||!Bank.Clips.TryGetValue(id,out var clip)||clip.Descriptor.category=="Death")return false;
   if(!clip.Descriptor.contextSupported||clip.Descriptor.requiresClearance&&!HasVisualClearance(clip.Descriptor))return false;
   bool damaging=ThrallMotionPolicy.CombatReady(clip.Descriptor)&&CanEnter(clip.Descriptor);if(!CanEnter(clip.Descriptor,false))return false;
   plan.Clear();routeRestored=false;actionSerial=0;EnqueueHelpers(clip.Descriptor,true);plan.Enqueue(new ThrallMotionRouteStep{id=id,kind=damaging?"Attack":"Context"});EnqueueHelpers(clip.Descriptor,false);if(!damaging){var steps=plan.ToArray();plan.Clear();foreach(var step in steps){step.kind="Context";plan.Enqueue(step);}}routeTravelGain=PlannedTravelGain();Next();return true;
  }
  bool CanEnter(ThrallMotionDescriptor d,bool requireEvents=true){
   if(requireEvents)foreach(var segment in (d.entrySegments??Array.Empty<ThrallMotionSegment>()).Concat(d.exitSegments??Array.Empty<ThrallMotionSegment>()))if(string.Equals(segment.kind,"attack",StringComparison.OrdinalIgnoreCase)&&(!Bank.Clips.TryGetValue(segment.id,out var attack)||!ThrallMotionPolicy.CombatReady(attack.Descriptor)||!(attack.Descriptor.contactWindows??Array.Empty<ThrallMotionWindow>()).Any(w=>w.end>=segment.start&&w.start<=segment.end)))return false;
   if(d.entrySegments!=null&&d.entrySegments.Length>0){var s=d.entrySegments[0];return Bank.Clips.TryGetValue(s.id,out var c)&&ThrallMotionPolicy.Compatible(bodyState,s.startState??c.Descriptor.startState);}
   var entry=ThrallMotionPolicy.EntryHelpers(d);return entry.Length>0?ThrallMotionPolicy.Compatible(bodyState,Bank.Clips[entry[0]].Descriptor.startState):ThrallMotionPolicy.Compatible(bodyState,d.startState);
  }
  void EnqueueHelpers(ThrallMotionDescriptor d,bool entering){
   var segments=entering?d.entrySegments:d.exitSegments;if(segments!=null&&segments.Length>0){foreach(var s in segments)plan.Enqueue(new ThrallMotionRouteStep{id=s.id,kind=string.Equals(s.kind,"attack",StringComparison.OrdinalIgnoreCase)?"Attack":entering?"Entry":"Recovery",start=s.start,end=s.end,startState=s.startState,endState=s.endState});return;}
   foreach(string id in entering?ThrallMotionPolicy.EntryHelpers(d):ThrallMotionPolicy.ExitHelpers(d))plan.Enqueue(new ThrallMotionRouteStep{id=id,kind=entering?"Entry":"Recovery"});
  }
  float PlannedTravelGain(){return ThrallAttackTravelPolicy.RouteGain(plan.Where(s=>s.kind=="Attack").Select(s=>new ThrallAttackTravelSegment{Profile=ThrallAttackAdvanceAdmission.For(Bank.Clips[s.id].Descriptor),From=s.start,To=s.end<0?Bank.Clips[s.id].duration:s.end}));}
  void Next(){if(!Owner)return;if(plan.Count>0){var next=plan.Dequeue();Begin(next.id,next.kind,next.start,next.end,next.startState,next.endState);}else ClearAction(true);}
  void Begin(string id,string kind,float from=0,float to=-1,string startState=null,string endState=null){
   if(!Owner||!Bank.Clips.TryGetValue(id,out var clip))return;
   if(to<0)to=clip.duration;if(!ThrallMotionPolicy.Finite(from)||!ThrallMotionPolicy.Finite(to)||from<0||to>clip.duration+.0001f||to<=from||!ThrallMotionPolicy.Compatible(bodyState,startState??clip.Descriptor.startState)){plan.Clear();ClearAction(true);return;}
   var previous=ReadPacket(view.GetZDO().GetString(StateKey,""));serial=Math.Max(Math.Max(serial,view.GetZDO().GetInt("bt_source_serial",0)),previous?.serial??0)+1;
   if(actionSerial<=0)actionSerial=serial;var value=new ThrallMotionPacket{serial=serial,actionSerial=actionSerial,ticks=Now,id=id,kind=kind,rate=1,from=from,to=to,startState=startState??clip.Descriptor.startState,endState=endState??clip.Descriptor.endState,remaining=plan.ToArray()};string text=JsonConvert.SerializeObject(value);
   view.GetZDO().Set("bt_source_serial",serial);view.GetZDO().Set(StateKey,text);packetText=text;Adopt(clip,value,false);
   human.SetMoveDir(Vector3.zero);human.SetRun(false);
  }
  static ThrallMotionPacket ReadPacket(string text){if(string.IsNullOrEmpty(text)||text.Length>2048)return null;try{return JsonConvert.DeserializeObject<ThrallMotionPacket>(text,new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MaxDepth=8});}catch{return null;}}
  void Observe(bool restored=false){
   if(!view||!view.IsValid())return;string text=view.GetZDO().GetString(StateKey,"");if(text==packetText)return;packetText=text;var value=ReadPacket(text);
   if(value==null||value.kind=="Death"||!Bank.Clips.TryGetValue(value.id??"",out var clip)||!ThrallMotionPolicy.Finite(value.rate)||value.rate<.5f||value.rate>1.5f||!ThrallMotionPolicy.Finite(value.from)||!ThrallMotionPolicy.Finite(value.to)||value.from<0||value.to<=value.from||value.to>clip.duration+.0001f||!new[]{"Entry","Attack","Recovery","Reaction","Context"}.Contains(value.kind))return;
   if(value.remaining!=null&&(value.remaining.Length>12||value.remaining.Any(s=>s==null||!Bank.Clips.TryGetValue(s.id??"",out var next)||!ThrallMotionPolicy.Finite(s.start)||!ThrallMotionPolicy.Finite(s.end)||s.start<0||s.start>=next.duration||s.end!=-1&&(s.end<=s.start||s.end>next.duration+.0001f)||!new[]{"Entry","Attack","Recovery","Context"}.Contains(s.kind))))return;
   if(gate.Accept(owner,value.serial,value.ticks,Now,(value.to-value.from)/value.rate,restored)){Adopt(clip,value,true);if(view.IsOwner()&&value.remaining!=null){foreach(var s in value.remaining)plan.Enqueue(s);}}
  }
  void Adopt(ThrallSourceClip clip,ThrallMotionPacket value,bool catchUp){
   if(trackedActionSerial!=value.actionSerial){trackedActionSerial=value.actionSerial;trackingPacket=0;trackingGroup=-1;strikeWasCommitted=false;trackingCommitted=false;committedHeading=transform.forward;}
   trackingWindup=false;locomotion.Reset();
   CaptureBlend();serial=Math.Max(serial,value.serial);bodyState=value.startState??clip.Descriptor.startState;action=clip;packet=value;actionSerial=value.actionSerial;observedKind=value.kind;displayId=clip.id;display=clip;effortSerial=value.kind=="Attack"?value.actionSerial:0;
   actionNow=value.from+ThrallMotionPolicy.SampleTime(ThrallMotionPolicy.Elapsed(value.ticks,Now,value.rate),value.to-value.from,false);actionPrevious=catchUp?actionNow:value.from-.0001f;contact=false;swish=false;hasBodyHold=false;finalPosePresented=false;if(catchUp&&view.IsOwner())routeRestored=true;restoredVisualOnly=routeRestored;
   if(!catchUp)gate.Serial=value.serial;
  }
  void CaptureBlend(){if(!presented.Ready)return;presented.Copy(presentedP,presentedQ);for(int i=0;i<58;i++){int p=i*3,q=i*4;blendPositions[i]=new Vector3(presentedP[p],presentedP[p+1],presentedP[p+2]);blendRotations[i]=new Quaternion(presentedQ[q],presentedQ[q+1],presentedQ[q+2],presentedQ[q+3]);}blendStarted=Time.time;}
  public void CachePresentedPose(){if(bones==null||!poseParent)return;for(int i=0;i<58;i++){int p=i*3,q=i*4;var position=bones[i].localPosition;var rotation=bones[i].localRotation;presentedP[p]=position.x;presentedP[p+1]=position.y;presentedP[p+2]=position.z;presentedQ[q]=rotation.x;presentedQ[q+1]=rotation.y;presentedQ[q+2]=rotation.z;presentedQ[q+3]=rotation.w;}presented.Store(presentedP,presentedQ);presentedRootPosition=poseParent.position;presentedRootRotation=poseParent.rotation;presentedRootScale=poseParent.lossyScale;if(leftFootIndex>=0)presentedLeft=poseParent.InverseTransformPoint(bones[leftFootIndex].position);if(rightFootIndex>=0)presentedRight=poseParent.InverseTransformPoint(bones[rightFootIndex].position);receive?.UpdatePose();}
  void ClearAction(bool publish){
   if(Owner&&SourceAttackActive&&!restoredVisualOnly&&advance!=null){lastTravelResult=JsonConvert.SerializeObject(advance.Snapshot());Log?.Invoke("BT_SOURCE_TRAVEL_RESULT route="+actionSerial+" "+lastTravelResult);}
   trackingWindup=false;trackingCommitted=false;trackedActionSerial=trackingPacket=0;trackingGroup=-1;strikeWasCommitted=false;trackingPhase="none";locomotion.Reset();
   string heldId=action?.id??displayId;float heldTime=actionNow;hasBodyHold=!ThrallMotionPolicy.Standing(bodyState);if(hasBodyHold)CaptureBlend();action=null;packet=null;observedKind="";effortSerial=0;contact=swish=false;display=null;
   if(publish&&view&&view.IsValid()&&view.IsOwner()){view.GetZDO().Set(StateKey,"");view.GetZDO().Set("bt_source_body_state",bodyState);view.GetZDO().Set("bt_source_hold_clip",hasBodyHold?heldId:"");view.GetZDO().Set("bt_source_hold_time",hasBodyHold?heldTime:0);packetText="";}
  }
  void AppendRecovery(){var route=ThrallMotionPolicy.RecoveryPath(bodyState,Bank.Clips.Values.Select(c=>c.Descriptor).OrderBy(c=>c.id).ToArray());if(route!=null)foreach(string id in route)plan.Enqueue(new ThrallMotionRouteStep{id=id,kind="Recovery"});}
  void RestoreContextPose(){
   var z=view.GetZDO();string id=z.GetString("bt_source_hold_clip","");float time=z.GetFloat("bt_source_hold_time",0);if(!Bank.Clips.TryGetValue(id,out var hold)){hold=Bank.Clips.Values.Where(c=>c.Descriptor.startState==bodyState).OrderBy(c=>c.Descriptor.category=="IdleAndHolds"?0:1).ThenBy(c=>c.id).FirstOrDefault();time=0;}
   if(hold!=null){Bank.Sample(hold,Mathf.Clamp(time,0,hold.duration),sampled,sampledRotations);for(int i=0;i<58;i++){bones[i].localPosition=sampled[i];bones[i].localRotation=sampledRotations[i];}CachePresentedPose();displayId=hold.id;actionNow=time;}
   hasBodyHold=true;CaptureBlend();
  }
  public void CancelAction(bool recover=true){
   var pending=plan.ToArray();plan.Clear();if(Owner&&recover&&action!=null&&packet!=null){routeRestored=false;actionSerial=0;
    if(actionNow<packet.to-.0001f)plan.Enqueue(new ThrallMotionRouteStep{id=action.id,kind="Recovery",start=Math.Max(packet.from,actionNow),end=packet.to,startState=bodyState,endState=packet.endState??action.Descriptor.endState});else bodyState=packet.endState??action.Descriptor.endState;
    foreach(var step in pending){step.kind="Recovery";plan.Enqueue(step);}if(plan.Count==0)AppendRecovery();if(plan.Count>0){Next();return;}
   }ClearAction(Owner);
  }
  void Update(){
   if(!ready||disabled||dead||!view||!view.IsValid())return;
   long newOwner=view.GetZDO().GetOwner();if(newOwner!=owner){Resume();return;}
   Observe();if(human.IsDead())return;if(human.GetHealth()>0)armedLife=true;
   bool staggered=human.IsStaggering();bool newNativeEpisode=reactionGate.TryNative(staggered);if(Owner&&newNativeEpisode)BeginReaction(true);wasStaggering=staggered;
   if(combat&&combat.BellActive&&!staggered){if(action!=null)CancelAction(false);return;}
   if(action!=null&&packet!=null&&ThrallMotionPolicy.CanComplete(ThrallMotionPolicy.Elapsed(packet.ticks,Now,packet.rate),packet.to-packet.from,finalPosePresented)){
    bodyState=packet.endState??action.Descriptor.endState??"standing";
    recoveryAttempted=false;if(Owner){if(plan.Count==0&&!ThrallMotionPolicy.Standing(bodyState))AppendRecovery();Next();}
    else if(ThrallMotionPolicy.Elapsed(packet.ticks,Now,packet.rate)>packet.to-packet.from+.4f)ClearAction(false);
   }
   if(Owner&&action==null&&!ThrallMotionPolicy.Standing(bodyState)&&!recoveryAttempted){recoveryAttempted=true;AppendRecovery();if(plan.Count>0){routeRestored=false;actionSerial=0;Next();}}
   if(Owner&&action==null&&!hasBodyHold&&ThrallMotionPolicy.Standing(bodyState)&&!human.InAttack()&&!human.IsStaggering()){
    bool upright=!ai.IsAlerted()&&Vector3.ProjectOnPlane(human.GetVelocity(),Vector3.up).sqrMagnitude<.0064f&&((Now/10000000L/18+identity)%3)==0;string transition=upright&&bodyState!="upright-neutral"?"a000_001020":!upright&&bodyState=="upright-neutral"?"a000_001040":null;
    if(transition!=null&&Bank.Clips.TryGetValue(transition,out var posture)&&posture.Descriptor.contextSupported){plan.Clear();actionSerial=0;routeRestored=false;Begin(transition,"Context");}
   }
  }
  // Called only for this actor by the native Character.UpdateRotation prefix.
  // SetLookDir feeds native collision/rotation behavior, never teleports yaw.
  public bool WindupTracking=>trackingWindup&&Owner&&SourceAttackActive&&!trackingCommitted;
  public bool BetweenComboStrikes=>WindupTracking&&strikeWasCommitted;
  void RefreshTrackingState(){
   if(!SourceAttackActive||packet==null||action==null){trackingWindup=false;return;}
   float at=packet.from+ThrallMotionPolicy.SampleTime(ThrallMotionPolicy.Elapsed(packet.ticks,Now,packet.rate),packet.to-packet.from,false);
   if(restoredVisualOnly||observedKind=="Recovery"){
    if(!trackingCommitted)committedHeading=transform.forward;trackingCommitted=true;trackingPacket=packet.serial;trackingGroup=-2;trackingPhase=restoredVisualOnly?"restored-hold":"recovery-hold";return;
   }
   var phase=observedKind=="Entry"?new ThrallTrackingPhase(true,false,-1,0,0):ThrallTrackingPolicy.Evaluate(packet.from,packet.to,action.Descriptor.contactWindows,at);
   if(!phase.Valid){if(!trackingCommitted)committedHeading=transform.forward;trackingCommitted=true;trackingPhase="invalid-hold";return;}
   if(phase.Locked){
    if(!trackingCommitted||trackingPacket!=packet.serial||trackingGroup!=phase.Group)committedHeading=transform.forward;
    trackingCommitted=true;strikeWasCommitted=true;trackingPacket=packet.serial;trackingGroup=phase.Group;trackingPhase="committed";
   }else{trackingCommitted=false;trackingPacket=packet.serial;trackingGroup=-1;trackingPhase=strikeWasCommitted?"combo-retarget":"windup";}
  }
  public void PrepareFacing(ref float angleSpeed){
   trackingWindup=false;
   if(!Owner||human.IsStaggering()||combat&&combat.BellActive)return;
   if(!SourceAttackActive&&(GetComponent<ThrallTactics>()?.Positioning??false)){angleSpeed=ThrallPlaybackPolicy.TrackingTurnSpeed(angleSpeed,false);return;}
   if(SourceAttackActive&&packet!=null){RefreshTrackingState();if(trackingCommitted){human.SetLookDir(committedHeading,0);return;}}
   else if(action!=null||hasBodyHold||human.InAttack())return;
   var target=ai?ai.GetTargetCreature():null;if(!target||target.IsDead()||target.InGhostMode())return;
   var direction=Vector3.ProjectOnPlane(target.GetCenterPoint()-human.GetCenterPoint(),Vector3.up);if(direction.sqrMagnitude<.0001f)return;
   human.SetLookDir(direction,0);angleSpeed=SourceAttackActive&&strikeWasCommitted?ThrallPlaybackPolicy.ComboTurnSpeed(angleSpeed):ThrallPlaybackPolicy.TrackingTurnSpeed(angleSpeed,locomotion.ClipId=="a000_002100");trackingWindup=SourceAttackActive;
  }
  public void ApplySourceRootMotion(ref Vector3 velocity){
   if(!Owner||advance==null)return;
   if(!SourceAttackActive||packet==null||action==null){advance.Reset();return;}
   float at=packet.from+ThrallMotionPolicy.SampleTime(ThrallMotionPolicy.Elapsed(packet.ticks,Now,packet.rate),packet.to-packet.from,false);
   var profile=ThrallAttackAdvanceAdmission.For(action.Descriptor);
   bool eligible=observedKind=="Attack"&&ThrallMotionPolicy.CombatReady(action.Descriptor)&&profile?.eligible==true&&!human.IsStaggering();
   RefreshTrackingState();var heading=trackingCommitted?Quaternion.LookRotation(committedHeading,Vector3.up):transform.rotation;
   advance.Apply(ref velocity,actionSerial,packet.serial,packet.from,at,profile,Time.fixedDeltaTime,eligible,restoredVisualOnly,human.IsOnGround(),heading,routeTravelGain);
  }
  void LateUpdate(){try{PoseLate();}catch(Exception e){Fail(e);}}
  void PoseLate(){
   if(!ready||disabled||dead||!view||!view.IsValid()||human.IsDead())return;
   var displacement=Vector3.ProjectOnPlane(transform.position-previousPosition,Vector3.up);moved=displacement.magnitude;
   yawDelta=Vector3.SignedAngle(previousForward,transform.forward,Vector3.up);previousPosition=transform.position;previousForward=transform.forward;
   ThrallSourceClip selected;float time;
   if(action==null&&hasBodyHold&&!(combat&&combat.BellActive)){for(int i=0;i<58;i++){bones[i].localPosition=blendPositions[i];bones[i].localRotation=blendRotations[i];int s=i*3;bones[i].localScale=new Vector3(Bank.Manifest.restScales[s],Bank.Manifest.restScales[s+1],Bank.Manifest.restScales[s+2]);}contact=swish=false;return;}
   if(action!=null&&packet!=null){selected=action;actionNow=packet.from+ThrallMotionPolicy.SampleTime(ThrallMotionPolicy.Elapsed(packet.ticks,Now,packet.rate),packet.to-packet.from,false);time=actionNow;
    contact=observedKind=="Attack"&&(selected.Descriptor.contactWindows??Array.Empty<ThrallMotionWindow>()).Any(w=>ThrallMotionPolicy.ContactSegment(actionPrevious,actionNow,w,out _,out _));
    swish=observedKind=="Attack"&&(selected.Descriptor.swishTimes??Array.Empty<float>()).Any(t=>ThrallMotionPolicy.Crossed(actionPrevious,actionNow,t));
   }else{
    // Native velocity persists between fixed/network ticks; transform displacement does not.
    var local=transform.InverseTransformDirection(Vector3.ProjectOnPlane(human.GetVelocity(),Vector3.up));
    var walk=Bank.Clips["a000_002300"];float walkSpeed=walk.Descriptor.strideDistance/Mathf.Max(.1f,walk.duration);
    locomotion.Update(ThrallSizePolicy.Authored(local.z),ThrallSizePolicy.Authored(local.x),ThrallSizePolicy.Authored(moved),walkSpeed,Time.deltaTime);float speed=locomotion.Speed;string id=locomotion.ClipId;
    float yawRate=yawDelta/Mathf.Max(.001f,Time.deltaTime);filteredYawRate+=(yawRate-filteredYawRate)*ThrallPlaybackPolicy.Smoothing(Time.deltaTime,.06f);bool nowTurning=!locomotion.Moving&&Math.Abs(filteredYawRate)>=12;
    if(nowTurning&&!turning){var target=ai?ai.GetTargetCreature():null;float bearing=target?Vector3.SignedAngle(transform.forward,Vector3.ProjectOnPlane(target.transform.position-transform.position,Vector3.up),Vector3.up):0;turnId=ThrallMotionPolicy.Turn(yawDelta,Math.Abs(bearing)>120,((identity+(uint)(turnSerial++))%2)==0);}
    bool settleTurn=!nowTurning&&turning&&speed<.08f&&display!=null&&display.Descriptor.category=="Turns"&&phase<.9999f;
    turning=nowTurning||settleTurn;
    if(combat&&combat.BellActive)id="a000_000020";
    else if(nowTurning||settleTurn)id=turnId;
    else if(speed<.08f&&bodyState=="upright-neutral")id="a000_000000";
    selected=Bank.Clips[id];if(display!=selected){bool gait=selected.Descriptor.category=="WalkRun";float nextPhase=gait?Bank.NearestSupportPhase(selected,presentedLeft,presentedRight,phase):0;CaptureBlend();phase=nextPhase;if(gait&&selected.Descriptor.locomotionDistance!=null)gaitDistancePhase=ThrallLocomotionDistance.DistanceAtTime(selected.Descriptor.locomotionDistance,phase*selected.duration)/selected.Descriptor.strideDistance;display=selected;displayId=id;}
    if(selected.Descriptor.category=="WalkRun"){
     if(selected.Descriptor.locomotionDistance!=null){gaitDistancePhase=(gaitDistancePhase+locomotion.DistanceStep/selected.Descriptor.strideDistance)%1d;phase=ThrallLocomotionDistance.TimeAtDistance(selected.Descriptor.locomotionDistance,gaitDistancePhase*selected.Descriptor.strideDistance)/selected.duration;}
     else phase=ThrallMotionPolicy.AdvanceDistancePhase(phase,locomotion.DistanceStep,selected.Descriptor.strideDistance,Time.deltaTime);
    }
    else if(selected.Descriptor.category=="Turns"){float degrees=Math.Abs(selected.Descriptor.yawDegrees);if(degrees<1)degrees=id.EndsWith("002",StringComparison.Ordinal)||id.EndsWith("003",StringComparison.Ordinal)||id.EndsWith("012",StringComparison.Ordinal)||id.EndsWith("013",StringComparison.Ordinal)?180:90;phase=Mathf.Clamp01(phase+(settleTurn?Time.deltaTime/selected.duration:Math.Abs(yawDelta)/degrees));}
    else phase=(phase+Time.deltaTime/selected.duration)%1;
    time=phase*selected.duration;contact=swish=false;
   }
   Bank.Sample(selected,time,sampled,sampledRotations);float blend=Mathf.Clamp01((Time.time-blendStarted)/ThrallMotionPolicy.Transition);blend=blend*blend*(3-2*blend);
   for(int i=0;i<58;i++){bones[i].localPosition=Vector3.Lerp(blendPositions[i],sampled[i],blend);bones[i].localRotation=Quaternion.Slerp(blendRotations[i],sampledRotations[i],blend);int s=i*3;bones[i].localScale=new Vector3(Bank.Manifest.restScales[s],Bank.Manifest.restScales[s+1],Bank.Manifest.restScales[s+2]);}
  }
  // Combat consumes the same already-rendered sample once at order950.
  public void EndContactFrame(){finalPosePresented=action!=null&&packet!=null&&actionNow>=packet.to-.00001f;actionPrevious=actionNow;swish=false;}
  public bool WeaponPoseAt(float sourceTime,out Matrix4x4 hand,out Quaternion rotation){
   hand=Matrix4x4.identity;rotation=Quaternion.identity;if(action==null||packet==null||handIndex<0)return false;
   float fraction=actionNow>actionPrevious?Mathf.Clamp01((sourceTime-actionPrevious)/(actionNow-actionPrevious)):1;
   var rootPosition=Vector3.Lerp(presentedRootPosition,poseParent.position,fraction);var rootRotation=Quaternion.Slerp(presentedRootRotation,poseParent.rotation,fraction);var rootScale=Vector3.Lerp(presentedRootScale,poseParent.lossyScale,fraction);
   float age=Time.time-blendStarted-(actionNow-sourceTime)/packet.rate;float weight=Mathf.Clamp01(age/ThrallMotionPolicy.Transition);weight=weight*weight*(3-2*weight);
   hand=Bank.BoneMatrix(action,sourceTime,handIndex,Matrix4x4.TRS(rootPosition,rootRotation,rootScale),rootRotation,blendPositions,blendRotations,weight,out rotation);return true;
  }
  public void NativeDeath(){
   if(!ready||disabled||dead||!armedLife||!view||!view.IsValid())return;
   if(view.IsOwner()){
    var choices=Bank.Clips.Values.Where(c=>c.Descriptor.category=="Death"&&ThrallMotionPolicy.Compatible(bodyState,c.Descriptor.startState)).OrderBy(c=>c.id).ToArray();
    if(choices.Length==0)choices=new[]{Bank.Clips["a000_007600"]};var selected=choices[(deathCursor++)%choices.Length];
    presented.Copy(presentedP,presentedQ);float entry=Bank.NearestDeathTime(selected,presentedP,presentedQ);int next=Math.Max(Math.Max(serial,view.GetZDO().GetInt("bt_source_serial",0)),ReadPacket(view.GetZDO().GetString(StateKey,""))?.serial??0)+1;var value=new ThrallMotionPacket{serial=next,actionSerial=next,ticks=Now,id=selected.id,kind="Death",rate=1,from=entry,to=selected.duration};string text=JsonConvert.SerializeObject(value);view.GetZDO().Set("bt_source_serial",next);view.GetZDO().Set(StateKey,text);CreateDeath(selected,value);view.InvokeRPC(ZNetView.Everybody,DeathRpc,text);
   }
  }
  void ReceiveDeath(long sender,string text){Safe(()=>{if(!ready||disabled||dead||!armedLife||sender==0||!view||!view.IsValid()||sender!=view.GetZDO().GetOwner())return;var value=ReadPacket(text);if(value==null||value.kind!="Death"||value.ticks<gate.EnabledAt||!Bank.Clips.TryGetValue(value.id??"",out var clip)||clip.Descriptor.category!="Death"||!ThrallMotionPolicy.Finite(value.from)||value.from<0||value.from>clip.duration||Math.Abs((Now-value.ticks)/10000000d)>1)return;CreateDeath(clip,value);});}
  void CreateDeath(ThrallSourceClip clip,ThrallMotionPacket value){if(dead)return;Bank.Hydrate(clip);presented.Copy(presentedP,presentedQ);receive?.Disable();ThrallCorpseMotion.Create(visual,Bank,clip,value.ticks,value.from,presentedP,presentedQ);dead=true;plan.Clear();contact=swish=false;foreach(var skin in visual.GetComponentsInChildren<Renderer>(true))skin.enabled=false;Log?.Invoke("BT_SOURCE_DEATH clip="+clip.id+" entry="+value.from+" deathClipSeconds="+clip.duration+" completionDelaySeconds=2.5");}
  void OnDisable(){receive?.Disable();disabled=true;gate.Disable();plan.Clear();action=null;contact=swish=false;}
  void OnDestroy(){receive?.Dispose();if(human)human.m_onDamaged-=Damaged;if(bound&&view)view.Unregister(DeathRpc);bound=false;}
  void Fail(Exception e){receive?.Disable();disabled=true;ready=false;gate.Disable();plan.Clear();action=null;contact=swish=false;enabled=false;Log?.Invoke("BT_SOURCE_DISABLED "+e.GetBaseException().Message);}
  public object Snapshot()=>new{ready,disabled,sourceClip=CurrentClipId,bodyState,kind=observedKind,sample=actionNow,restoredVisualOnly,loadedClips=Bank?.HydratedCount??0,loadedBytes=Bank?.HydratedBytes??0,contactReady=Bank?.Clips.Values.Count(c=>ThrallMotionPolicy.CombatReady(c.Descriptor))??0,receiveHitVolumes=receive?.Snapshot(),locomotionClip=locomotion.ClipId,locomotionSpeed=locomotion.Speed,locomotionPhase=phase,gaitStateChanges=locomotion.StateChanges,phaseLeadMetres=Math.Max(0,-locomotion.DistanceDebt),trackingCommitted,trackingWindup,trackingPhase,trackingPacket,trackingGroup,nativeStaggering=wasStaggering,nativeReactionEpisodes=reactionGate.NativeEpisodes,ordinaryReactionEpisodes=reactionGate.OrdinaryEpisodes,nextOrdinaryReaction=reactionGate.NextOrdinaryAt,attackAdvance=advance?.Snapshot()};
  public static void Shutdown(){foreach(var motion in UnityEngine.Object.FindObjectsByType<ThrallSourceMotion>(FindObjectsSortMode.None))if(motion)motion.enabled=false;ThrallCorpseMotion.Shutdown();Bank=null;ReceiveShapes=null;callbackFailed=false;}
  static bool callbackFailed;
  public static void Safe(Action action){try{action();}catch(Exception e){if(callbackFailed)return;callbackFailed=true;Log?.Invoke("BT_SOURCE_CALLBACK_FAILED "+e.GetBaseException().Message);}}
 }
}
