using System;using System.Collections.Generic;using System.IO;using System.Linq;using UnityEngine;
#if !UNITY_EDITOR
using Newtonsoft.Json;
#endif
namespace BlackAbbey.BellThrall {
 [Serializable]public sealed class BellFrame{public float[] positions,rotations;}
 [Serializable]public sealed class BellMotionBank{public string schema,sourceAction;public FileRecord sourceNative;public string[] boneNames;public int fps;public float duration,ringTime;public BellFrame[] frames;public bool containsVanillaClips;}
 [Serializable]public sealed class ContactAttack {public string token,clip;public float frontReach,release;}
 [Serializable]public sealed class ThrallContactProfile {
  public string visualSha256;public ContactAttack[] attacks;
  public static ThrallContactProfile Read(string path){
#if UNITY_EDITOR
   return JsonUtility.FromJson<ThrallContactProfile>(File.ReadAllText(path));
#else
   return JsonConvert.DeserializeObject<ThrallContactProfile>(File.ReadAllText(path),new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MaxDepth=32});
#endif
  }
 }
 public static class ThrallBellMotion {
  public static BellMotionBank ReadVariant(string path){
   var b=JsonConvert.DeserializeObject<BellMotionBank>(File.ReadAllText(path),new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MaxDepth=32});
   if(b==null||b.schema!="bell-thrall.bell-motion.v1"||b.containsVanillaClips||b.boneNames?.Length!=58||b.boneNames.Distinct().Count()!=58||b.frames?.Length!=124||b.fps!=30||!ThrallMotionPolicy.Finite(b.duration)||Math.Abs(b.duration-4.1f)>.001f||!ThrallMotionPolicy.Finite(b.ringTime)||b.ringTime<=.25f||b.ringTime>=b.duration-.30f||b.sourceNative==null||string.IsNullOrEmpty(b.sourceAction))throw new InvalidDataException("Unexpected approved bell variant");
   foreach(var f in b.frames){if(f?.positions?.Length!=174||f.rotations?.Length!=232||f.positions.Concat(f.rotations).Any(v=>!ThrallMotionPolicy.Finite(v)))throw new InvalidDataException("Invalid variant pose data");for(int i=0;i<58;i++){int q=i*4;float norm=0;for(int j=0;j<4;j++)norm+=f.rotations[q+j]*f.rotations[q+j];if(Math.Abs(norm-1)>.002f)throw new InvalidDataException("Invalid variant quaternion");}}
   return b;
  }
  public static BellMotionBank Read(string path){
#if UNITY_EDITOR
   var b=JsonUtility.FromJson<BellMotionBank>(File.ReadAllText(path));
#else
   var b=JsonConvert.DeserializeObject<BellMotionBank>(File.ReadAllText(path),new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MaxDepth=32});
#endif
   if(b==null||b.schema!="bell-thrall.bell-motion.v1"||b.containsVanillaClips||b.boneNames?.Length!=58||b.frames?.Length!=124||Math.Abs(b.ringTime-ThrallCombatPolicy.RingTime)>.001f||Math.Abs(b.duration-ThrallCombatPolicy.BellDuration)>.001f)throw new InvalidDataException("Unexpected own bell motion inventory");
   foreach(var f in b.frames)if(f.positions?.Length!=58*3||f.rotations?.Length!=58*4||f.positions.Concat(f.rotations).Any(v=>float.IsNaN(v)||float.IsInfinity(v)))throw new InvalidDataException("Invalid bell pose data");return b;
  }
  public static void Apply(BellMotionBank b,Dictionary<string,Transform> named,float time,float weight){float frame=Mathf.Clamp01(time/b.duration)*(b.frames.Length-1);int lo=Mathf.FloorToInt(frame),hi=Mathf.Min(lo+1,b.frames.Length-1);float t=frame-lo;var a=b.frames[lo];var z=b.frames[hi];for(int i=0;i<b.boneNames.Length;i++){var bone=named[b.boneNames[i]];int p=i*3,q=i*4;var pos=Vector3.Lerp(new Vector3(a.positions[p],a.positions[p+1],a.positions[p+2]),new Vector3(z.positions[p],z.positions[p+1],z.positions[p+2]),t);var rot=Quaternion.Slerp(new Quaternion(a.rotations[q],a.rotations[q+1],a.rotations[q+2],a.rotations[q+3]),new Quaternion(z.rotations[q],z.rotations[q+1],z.rotations[q+2],z.rotations[q+3]),t);bone.localPosition=Vector3.Lerp(bone.localPosition,pos,weight);bone.localRotation=Quaternion.Slerp(bone.localRotation,rot,weight);bone.localScale=Vector3.Lerp(bone.localScale,Vector3.one,weight);}}
 }
 public sealed class ThrallHeadShape {
  public Vector3 localPosition,halfExtents;public Quaternion localRotation;public int headVertices;
  public static ThrallHeadShape Fit(ThrallPayload p){var world=new Dictionary<int,Matrix4x4>();var named=new Dictionary<string,Matrix4x4>();foreach(var n in p.nodes){var m=Matrix4x4.TRS(ThrallVisual.V(n.position),ThrallVisual.Q(n.rotation),ThrallVisual.V(n.scale));world[n.id]=n.parentId<0?m:world[n.parentId]*m;named[n.name]=world[n.id];}
   var hand=named["RightHand"];var main=hand.inverse.MultiplyPoint3x4(named["BT1_Maul_Main_Grip"].GetColumn(3));var tip=hand.inverse.MultiplyPoint3x4(named["BT1_Maul_Impact"].GetColumn(3));var axis=(tip-main).normalized;var rotation=Quaternion.LookRotation(axis,Mathf.Abs(Vector3.Dot(axis,Vector3.up))>.9f?Vector3.right:Vector3.up);var points=new List<Vector3>();int rightId=p.nodes.Single(n=>n.name=="RightHand").id;foreach(var r in p.renderers.Where(r=>r.name.Contains("Maul"))){int joint=Array.IndexOf(r.boneNodeIds,rightId);if(joint<0||r.weights.Any(w=>w.boneIndex0!=joint||w.weight0<.9999f))throw new InvalidDataException("Expected rigid main-hand hammer weights");var bind=new Matrix4x4();for(int k=0;k<16;k++)bind[k/4,k%4]=r.bindposes[joint].values[k];for(int i=0;i<r.positions.Length;i+=3)points.Add(bind.MultiplyPoint3x4(new Vector3(r.positions[i],r.positions[i+1],r.positions[i+2])));}
   float min=points.Min(v=>Vector3.Dot(v,axis)),max=points.Max(v=>Vector3.Dot(v,axis));var selected=points.Where(v=>Vector3.Dot(v,axis)>=min+(max-min)*.72f).ToArray();var first=Quaternion.Inverse(rotation)*selected[0];var bounds=new Bounds(first,Vector3.zero);foreach(var v in selected)bounds.Encapsulate(Quaternion.Inverse(rotation)*v);return new ThrallHeadShape{localPosition=rotation*bounds.center,localRotation=rotation,halfExtents=bounds.extents+Vector3.one*.015f,headVertices=selected.Length};
  }
 }
}
