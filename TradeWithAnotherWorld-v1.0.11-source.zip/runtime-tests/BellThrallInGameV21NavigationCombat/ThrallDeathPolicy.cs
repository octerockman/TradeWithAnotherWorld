using System;
namespace BlackAbbey.BellThrall {
 // Same rest/smoke timing as the Abbey Guard, after the selected death fall.
 public static class ThrallDeathPolicy {
  public const float RestSeconds=2.5f,SmokeStartSeconds=1.8f,MinimumSmokeLead=.5f,SmokeTailSeconds=1.1f;
  public const float SmokeMinLifetime=2f,SmokeMaxLifetime=2.2f,FloorGap=.006f,ProbeInterval=.12f;
  public const int MaximumCorpses=6,MaximumPuffs=8;
  public const float MaximumSettleWait=4f;
  public const float PoseBlendSeconds=.12f;
  // The saved source fall can be supported by cloth/back gear while anatomy
  // remains suspended. Transfer the presented pose to gravity after the entry
  // blend, rather than holding a nonphysical clone until the source clip ends.
  public static bool BeginPhysics(float age,bool laterFrame)=>laterFrame&&!float.IsNaN(age)&&!float.IsInfinity(age)&&age>=PoseBlendSeconds;
  public static float Remaining(float duration,float entry,float elapsed)=>Math.Max(0,duration-entry-Math.Max(0,elapsed));
  public static bool Hide(float age,float remaining,float smokeAge,bool particles,bool laterFrame)=>age>=remaining+RestSeconds&&smokeAge>=MinimumSmokeLead&&particles&&laterFrame;
  public static float Lifetime(float remaining)=>Math.Max(0,remaining)+MaximumSettleWait+MinimumSmokeLead+1f;
  public static float Settle(float current,float target,ref float fallSpeed,float dt){
   if(float.IsNaN(current)||float.IsInfinity(current)||float.IsNaN(target)||float.IsInfinity(target)||dt<=0||dt>.25f)return current;
   if(current<=target){fallSpeed=0;return target;}fallSpeed=Math.Min(8f,fallSpeed+9.81f*dt);return Math.Max(target,current-fallSpeed*dt);
  }
 }
}
