using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbey.BellThrall {
 public enum ThrallTacticsKind { None, Attack, Approach, Face, Reposition }
 public enum ThrallTacticsSide { None, Left, Right, Retreat }

 // This value is prepared once by the owner adapter. Distances are planar and
 // use one consistent origin convention in both the snapshot and route bounds.
 public sealed class ThrallTacticsSnapshot {
  public bool Owner, Alive=true, TargetValid=true, Visible=true, Grounded=true, Staggered, Blocking;
  public float DistanceMetres, BearingDegrees, HealthFraction=1, NowSeconds, SourceMetresPerUnit=1;
  public uint Seed;
  public int LastAct; // Most recently committed candidate.CooldownKey.
  public string LastRoute;
  public IReadOnlyDictionary<int,float> CooldownUntil;
  // Secondary sword repertoire is an explicit hammer adaptation. No special
  // effect16500, breath, wound phase, or state-specific move is invented.
  public float SecondaryWeightScale=.30f;
  public bool AllowHeldReleaseAdaptation;
 }

 // The adapter must first check CombatReady, compatible helpers and physical
 // clearance. Measured bounds include the already-budgeted source advance.
 public sealed class ThrallTacticsRoute {
  public string Id;
  public float MinDistanceMetres, MaxDistanceMetres, MaxBearingDegrees=90;
  public bool Ready=true;
 }
 public sealed class ThrallTacticsCandidate {
  public string RouteId;
  public int SourceGoal, SourceAct, SourceCommand, CooldownKey;
  public float Weight, CooldownSeconds, MinDistanceMetres, MaxDistanceMetres, MaxBearingDegrees;
  public bool Adapted;
 }
 public sealed class ThrallTacticsDecision {
  public ThrallTacticsKind Kind;
  public ThrallTacticsSide Side;
  public string Reason;
  public ThrallTacticsCandidate Selected;
  public ThrallTacticsCandidate[] Ranked=Array.Empty<ThrallTacticsCandidate>();
  public float SuggestedDistanceMetres, SuggestedSeconds;
 }

 // Pure policy: no Unity, actor mutation, physics, damage, motion or clock owner.
 // Provenance: ai-completion-v7/research/decompiled/214010_battle.dec.lua
 // (Activate, Acts01-04/20-26, Interrupt5031/5033) and source-tae-attacks.json.
 // TAE verifies command->clip names; source distances require an explicit local
 // conversion. Ranked is a deterministic weighted permutation, NOT weight-sort.
 // Commit a selected candidate's cooldown only after its source route begins.
 public static class ThrallTacticsPolicy {
  static readonly HashSet<string> AdmittedIds=new HashSet<string>(StringComparer.Ordinal) {
   "a000_003000","a000_003001","a000_003002","a000_003003","a000_003004",
   "a000_003005","a000_003006","a000_003007","a000_003008","a000_003009",
   "a000_003010","a000_003011","a000_003012","a000_003013","a000_003015",
   "a000_003016","a000_003017","a000_003018","a000_003021","a000_003022",
   "a000_003023","a000_003024","a000_003025","a000_003026","a000_003030",
   "a000_003031","a000_003033","a000_004100","a000_004101"
  };
  public static bool AutonomousRoute(string id)=>id!=null&&AdmittedIds.Contains(id);
  static bool Finite(float n)=>!float.IsNaN(n)&&!float.IsInfinity(n);
  static float Bearing(float degrees){degrees%=360;return degrees>180?degrees-360:degrees< -180?degrees+360:degrees;}
  static bool Valid(ThrallTacticsSnapshot s)=>s!=null&&s.Owner&&s.Alive&&s.TargetValid&&s.Grounded&&!s.Staggered&&!s.Blocking&&Finite(s.DistanceMetres)&&s.DistanceMetres>=0&&Finite(s.BearingDegrees)&&Finite(s.HealthFraction)&&s.HealthFraction>0&&s.HealthFraction<=1&&Finite(s.NowSeconds)&&s.NowSeconds>=0&&Finite(s.SourceMetresPerUnit)&&s.SourceMetresPerUnit>.0001f&&Finite(s.SecondaryWeightScale)&&s.SecondaryWeightScale>=0&&s.SecondaryWeightScale<=1;
  static ThrallTacticsDecision Move(ThrallTacticsKind kind,string reason,float distance=0)=>new ThrallTacticsDecision{Kind=kind,Reason=reason,SuggestedDistanceMetres=distance};

  // Exact ordinary axe weights before state-specific effects and admission.
  // Act20's3020 has no admitted damage phase in the current bank; it is not
  // silently replaced by another attack. Act2's held loop is opt-in below.
  public static float SourceWeight(int act,float distance){
   if(!Finite(distance)||distance<0)return 0;
   if(distance>=6)return act==42?100:0;
   if(distance<2){switch(act){case 2:return 10;case 3:return 5;case 4:return 20;case 20:return 10;case 21:return 20;case 22:return 20;case 26:return 5;default:return 0;}}
   if(distance<4){switch(act){case 1:return 20;case 2:return 30;case 3:return 5;case 4:return 20;case 20:return 20;case 26:return 5;default:return 0;}}
   switch(act){case 1:return 20;case 2:return 40;case 3:return 5;case 20:return 30;case 26:return 5;default:return 0;}
  }
  public static float SecondarySourceWeight(int act,float distance){
   if(!Finite(distance)||distance<0)return 0;
   if(distance>=15)return act==42?100:0;
   if(distance>=6)return act==4||act==42?50:0;
   if(distance<2){switch(act){case 3:return 5;case 5:return 25;case 20:return 5;case 21:return 25;case 22:return 10;case 26:return 5;default:return 0;}}
   if(distance<4){switch(act){case 1:return 20;case 2:return 15;case 3:return 5;case 6:return 20;case 7:return 5;case 20:return 10;case 21:return 10;case 26:return 5;default:return 0;}}
   switch(act){case 1:return 25;case 2:return 10;case 3:return 5;case 4:return 20;case 6:return 20;case 7:return 5;case 20:return 10;case 26:return 5;default:return 0;}
  }
  public static int CooldownKey(int goal,int act){
   if(goal==214000){switch(act){case 1:return 3000;case 2:return 3003;case 3:return 3004;case 4:return 3005;case 5:return 3007;case 6:return 3030;case 7:return 3008;}}
   else {switch(act){case 1:return 3010;case 2:return 3014;case 3:return 3015;case 4:return 3012;}}
   switch(act){case 20:return 3020;case 21:return 3021;case 22:return 3022;case 23:return 3025;case 24:return goal==214000?3026:3036;case 25:return 3023;case 26:return 3024;case 27:return 3027;case 28:return 3028;default:return 0;}
  }
  static float BaseCooldown(int goal,int act){
   if(goal==214000){switch(act){case 2:case 6:return 5;case 3:return 20;case 4:case 5:return 10;case 7:return 25;}}
   else {switch(act){case 2:return 30;case 3:return 20;}}
   switch(act){case 20:case 21:case 22:case 27:return 5;case 23:case 25:return 10;case 24:return 30;case 26:return 20;case 28:return 15;default:return 0;}
  }
  public static float CooldownSeconds(int act,uint seed)=>CooldownSeconds(214010,act,seed);
  public static float CooldownSeconds(int goal,int act,uint seed){float basis=BaseCooldown(goal,act);return basis<=0?0:basis+Mix(seed^(uint)CooldownKey(goal,act)*0x9e3779b9u)%(goal==214000&&act>=2&&act<=7?11u:6u);}
  static bool Cooling(ThrallTacticsSnapshot s,int goal,int act){if(s.CooldownUntil==null||!s.CooldownUntil.TryGetValue(CooldownKey(goal,act),out var until))return false;return !Finite(until)||until>s.NowSeconds;}
  static bool RouteValid(ThrallTacticsRoute r)=>r!=null&&r.Ready&&AutonomousRoute(r.Id)&&Finite(r.MinDistanceMetres)&&Finite(r.MaxDistanceMetres)&&Finite(r.MaxBearingDegrees)&&r.MinDistanceMetres>=0&&r.MaxDistanceMetres>r.MinDistanceMetres&&r.MaxBearingDegrees>=0&&r.MaxBearingDegrees<=180;
  static bool InEnvelope(ThrallTacticsSnapshot s,ThrallTacticsRoute r)=>s.DistanceMetres>=r.MinDistanceMetres&&s.DistanceMetres<=r.MaxDistanceMetres&&Math.Abs(Bearing(s.BearingDegrees))<=r.MaxBearingDegrees;
  static uint Mix(uint v){v^=v>>16;v*=0x7feb352du;v^=v>>15;v*=0x846ca68bu;return v^(v>>16);}
  struct Random {uint state;public Random(uint seed){state=Mix(seed)^0xa341316cu;if(state==0)state=1;}public double Unit(){state^=state<<13;state^=state>>17;state^=state<<5;return state/4294967296d;}}

  public static ThrallTacticsDecision Decide(ThrallTacticsSnapshot s,IEnumerable<ThrallTacticsRoute> available){
   if(!Valid(s))return Move(ThrallTacticsKind.None,"inactive, non-owner, blocked or invalid snapshot");
   if(!s.Visible)return Move(ThrallTacticsKind.Approach,"no clear target sight; native acquisition/navigation only");
   float distance=s.DistanceMetres/s.SourceMetresPerUnit;
   if(Math.Abs(Bearing(s.BearingDegrees))>90)return Move(ThrallTacticsKind.Face,"target outside forward hemisphere");
   // The ordinary axe approaches beyond6. A verified sword long approach
   // attack may remain eligible only within its measured physical envelope.
   if(distance>=15||distance>=6&&s.SecondaryWeightScale<=0)return Move(ThrallTacticsKind.Approach,"214010 ordinary Act42",4*s.SourceMetresPerUnit);
   var routes=(available??Enumerable.Empty<ThrallTacticsRoute>()).Where(RouteValid).GroupBy(r=>r.Id,StringComparer.Ordinal).ToDictionary(g=>g.Key,g=>g.OrderBy(r=>r.MaxDistanceMetres).ThenByDescending(r=>r.MinDistanceMetres).ThenBy(r=>r.MaxBearingDegrees).First(),StringComparer.Ordinal);
   var candidates=new List<ThrallTacticsCandidate>();
   // Act1:5031 chooses3011 within3,3018 within8;5033 then chooses3013
   //30%/3016 otherwise at close range. Existing full routes for3013/3016
   // include3010->3011.3018 has a compatible3010 prefix but no complete
   //3018->3016 route, so finish that admitted route instead of splicing poses.
   AddFamily(s,routes,candidates,1,SourceWeight(1,distance),distance<=3?
    new[]{new Endpoint("a000_003013",3013,.3f),new Endpoint("a000_003016",3016,.7f)}:
    new[]{new Endpoint("a000_003018",3018,1)},new[]{new Endpoint("a000_003011",3011,1),new Endpoint("a000_003010",3010,1)});
   if(s.AllowHeldReleaseAdaptation)AddFamily(s,routes,candidates,2,SourceWeight(2,distance),new[]{new Endpoint("a000_003033",3033,1,true)},null);
   AddFamily(s,routes,candidates,3,SourceWeight(3,distance),new[]{new Endpoint("a000_003015",3015,1)},null);
   // Act4's3012->3017 continuation cannot use the current3017 helper prefix
   //(3010/3011), so retain the complete3012 route without false source chaining.
   AddFamily(s,routes,candidates,4,SourceWeight(4,distance),new[]{new Endpoint("a000_003012",3012,1)},null);
   AddFamily(s,routes,candidates,21,SourceWeight(21,distance),new[]{new Endpoint("a000_003021",3021,1)},null);
   AddFamily(s,routes,candidates,22,SourceWeight(22,distance),new[]{new Endpoint("a000_003022",3022,1)},null);
   AddFamily(s,routes,candidates,26,SourceWeight(26,distance),new[]{new Endpoint("a000_003024",3024,1)},null);
   // Retain the requested sword motions at lower weight, with exact source
   // ordinary tables. Source3006 has no compatible3003/3005 helper prefix;
   // its admitted complete standalone use is explicitly marked an adaptation.
   float secondary=s.SecondaryWeightScale;
   AddFamily(s,routes,candidates,1,secondary*SecondarySourceWeight(1,distance),new[]{new Endpoint("a000_003009",3009,.3f),new Endpoint("a000_003002",3002,.7f)},new[]{new Endpoint("a000_003001",3001,1),new Endpoint("a000_003000",3000,1)},214000);
   AddFamily(s,routes,candidates,2,secondary*SecondarySourceWeight(2,distance),new[]{new Endpoint("a000_003003",3003,.4f),new Endpoint("a000_003006",3006,.6f,true)},null,214000);
   AddFamily(s,routes,candidates,3,secondary*SecondarySourceWeight(3,distance),new[]{new Endpoint("a000_003004",3004,1)},null,214000);
   AddFamily(s,routes,candidates,4,secondary*SecondarySourceWeight(4,distance),new[]{new Endpoint("a000_003005",3005,.4f),new Endpoint("a000_003006",3006,.6f,true)},null,214000);
   AddFamily(s,routes,candidates,5,secondary*SecondarySourceWeight(5,distance),new[]{new Endpoint("a000_003007",3007,1)},null,214000);
   AddFamily(s,routes,candidates,6,secondary*SecondarySourceWeight(6,distance),new[]{new Endpoint("a000_003031",3031,1)},new[]{new Endpoint("a000_003030",3030,1)},214000);
   AddFamily(s,routes,candidates,7,secondary*SecondarySourceWeight(7,distance),new[]{new Endpoint("a000_003008",3008,1)},null,214000);
   AddFamily(s,routes,candidates,21,secondary*SecondarySourceWeight(21,distance),new[]{new Endpoint("a000_003021",3021,1)},null,214000);
   AddFamily(s,routes,candidates,22,secondary*SecondarySourceWeight(22,distance),new[]{new Endpoint("a000_003022",3022,1)},null,214000);
   AddFamily(s,routes,candidates,26,secondary*SecondarySourceWeight(26,distance),new[]{new Endpoint("a000_003024",3024,1)},null,214000);
   if(candidates.Count==0){
    var viable=routes.Values.ToArray();
    if(viable.Length>0&&viable.All(r=>s.DistanceMetres>r.MaxDistanceMetres))return Move(ThrallTacticsKind.Approach,"outside every admitted measured reach",viable.Max(r=>r.MaxDistanceMetres));
    if(viable.Length>0&&viable.All(r=>s.DistanceMetres<r.MinDistanceMetres))return new ThrallTacticsDecision{Kind=ThrallTacticsKind.Reposition,Side=ThrallTacticsSide.Retreat,Reason="inside every admitted minimum reach",SuggestedDistanceMetres=.4f*s.SourceMetresPerUnit,SuggestedSeconds=.6f};
    if(viable.Length>0&&viable.All(r=>Math.Abs(Bearing(s.BearingDegrees))>r.MaxBearingDegrees))return Move(ThrallTacticsKind.Face,"outside admitted attack bearings");
    return Move(distance>=6?ThrallTacticsKind.Approach:ThrallTacticsKind.None,"no admitted source action or cooldown ready",distance>=6?4*s.SourceMetresPerUnit:0);
   }
   if(distance>=6){float approach=SourceWeight(42,distance)+s.SecondaryWeightScale*SecondarySourceWeight(42,distance);var random=new Random(s.Seed^0x42u);if(random.Unit()*(approach+candidates.Sum(c=>c.Weight))<approach)return Move(ThrallTacticsKind.Approach,"source Act42 weighted against admitted sword reach",4*s.SourceMetresPerUnit);}
   var ranked=Rank(candidates,s.Seed);return new ThrallTacticsDecision{Kind=ThrallTacticsKind.Attack,Selected=ranked[0],Ranked=ranked,Reason="c2140 weighted complete route: axe primary, sword supplement"};
  }
  sealed class Endpoint {public readonly string Id;public readonly int Command;public readonly float Share;public readonly bool Adapted;public Endpoint(string id,int command,float share,bool adapted=false){Id=id;Command=command;Share=share;Adapted=adapted;}}
  static void AddFamily(ThrallTacticsSnapshot s,Dictionary<string,ThrallTacticsRoute> routes,List<ThrallTacticsCandidate> result,int act,float weight,Endpoint[] endpoints,Endpoint[] fallback,int goal=214010){
   if(weight<=0||Cooling(s,goal,act))return;
   var legal=endpoints.Where(e=>routes.TryGetValue(e.Id,out var r)&&InEnvelope(s,r)).ToArray();
   if(legal.Length==0&&fallback!=null){foreach(var e in fallback){if(routes.TryGetValue(e.Id,out var r)&&InEnvelope(s,r)){legal=new[]{e};break;}}}
   if(legal.Length==0)return;float shares=legal.Sum(e=>e.Share);
   foreach(var e in legal){var r=routes[e.Id];float adjusted=weight*e.Share/shares;if(s.LastAct==CooldownKey(goal,act))adjusted*=.35f;if(s.LastRoute==e.Id)adjusted*=.5f;if(!Finite(adjusted)||adjusted<=0)continue;
    result.Add(new ThrallTacticsCandidate{RouteId=e.Id,SourceGoal=goal,SourceAct=act,SourceCommand=e.Command,CooldownKey=CooldownKey(goal,act),Weight=adjusted,CooldownSeconds=CooldownSeconds(goal,act,s.Seed),MinDistanceMetres=r.MinDistanceMetres,MaxDistanceMetres=r.MaxDistanceMetres,MaxBearingDegrees=r.MaxBearingDegrees,Adapted=e.Adapted||goal==214000});}
  }
  static ThrallTacticsCandidate[] Rank(List<ThrallTacticsCandidate> candidates,uint seed){
   var pending=candidates.OrderBy(c=>c.SourceGoal).ThenBy(c=>c.SourceAct).ThenBy(c=>c.SourceCommand).ThenBy(c=>c.RouteId,StringComparer.Ordinal).ToList();var ranked=new List<ThrallTacticsCandidate>();var random=new Random(seed);
   while(pending.Count>0){double cursor=random.Unit()*pending.Sum(c=>(double)c.Weight);int index=pending.Count-1;for(int i=0;i<pending.Count;i++){cursor-=pending[i].Weight;if(cursor<0){index=i;break;}}ranked.Add(pending[index]);pending.RemoveAt(index);}
   return ranked.ToArray();
  }

  // A bounded end-of-route adaptation of ordinary5025 positioning: at3.5-6
  // source units it chooses approach/sideway50:50. It never interrupts motion,
  // adds source attack damage, jumps or dodges. The owner adapter must verify a
  // native path and may decline the suggestion. GenericAfterAttackAct is not
  // used: the source normally returns GetWellSpace_Odds=0.
  public static ThrallTacticsDecision AfterAction(ThrallTacticsSnapshot s){
   if(!Valid(s)||!s.Visible)return Move(ThrallTacticsKind.None,"no safe completed-route spacing opportunity");
   float distance=s.DistanceMetres/s.SourceMetresPerUnit;
   if(Math.Abs(Bearing(s.BearingDegrees))>90)return Move(ThrallTacticsKind.Face,"reacquire forward target after route");
   if(distance<=3.5f||distance>=6)return Move(ThrallTacticsKind.None,"outside ordinary5025 spacing band");
   var random=new Random(s.Seed^0x5025u);if(random.Unit()<.5)return Move(ThrallTacticsKind.Approach,"bounded5025 completion adaptation",3*s.SourceMetresPerUnit);
   return new ThrallTacticsDecision{Kind=ThrallTacticsKind.Reposition,Side=random.Unit()<.5?ThrallTacticsSide.Left:ThrallTacticsSide.Right,Reason="bounded5025 sideway completion adaptation",SuggestedDistanceMetres=.6f*s.SourceMetresPerUnit,SuggestedSeconds=.7f};
  }
  // Deferred after a confirmed ranged hit, not an INTERUPT_Shoot replica.
  // The adapter waits until the complete route/recovery ends and enforces its
  //3-8s cooldown. Ordinary native MoveTo only: no dodge clip/invulnerability.
  public static ThrallTacticsDecision AfterRangedHit(ThrallTacticsSnapshot s){
   if(!Valid(s)||!s.Visible||s.DistanceMetres/s.SourceMetresPerUnit<=5)return Move(ThrallTacticsKind.None,"no safe deferred ranged response");
   var random=new Random(s.Seed^0x60026003u);return new ThrallTacticsDecision{Kind=ThrallTacticsKind.Reposition,Side=random.Unit()<.5?ThrallTacticsSide.Left:ThrallTacticsSide.Right,Reason="deferred confirmed-ranged-hit navigation adaptation",SuggestedDistanceMetres=.6f*s.SourceMetresPerUnit,SuggestedSeconds=.7f};
  }
 }
}
