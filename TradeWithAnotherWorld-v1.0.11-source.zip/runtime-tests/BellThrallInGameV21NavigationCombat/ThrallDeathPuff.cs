using System;using System.Collections.Generic;using System.Linq;using Jotunn.Managers;using UnityEngine;using UnityEngine.Rendering;using Object=UnityEngine.Object;
namespace BlackAbbey.BellThrall {
 // Borrowed Greyling smoke material, same red palette as the Abbey Guard.
 public sealed class ThrallDeathPuff:MonoBehaviour {
  static Material material;static bool attempted;static readonly List<ThrallDeathPuff> puffs=new List<ThrallDeathPuff>();
  ParticleSystem particles;bool released;float expires;public float Began{get;private set;}public int StartedFrame{get;private set;}
  readonly ParticleSystem.Particle[] buffer=new ParticleSystem.Particle[48];public bool HasParticles=>particles&&particles.particleCount>0;
  static bool Prepare(){
   if(material)return true;if(attempted)return false;attempted=true;
   var native=PrefabManager.Instance.GetPrefab("Greyling");var effects=native?native.GetComponent<Character>()?.m_deathEffects?.m_effectPrefabs:null;
   var source=(effects??Array.Empty<EffectList.EffectData>()).Where(e=>e?.m_prefab).SelectMany(e=>e.m_prefab.GetComponentsInChildren<ParticleSystemRenderer>(true)).Where(r=>r.sharedMaterial&&r.sharedMaterial.shader&&r.sharedMaterial.shader.isSupported).OrderByDescending(r=>r.name.IndexOf("smoke",StringComparison.OrdinalIgnoreCase)>=0||r.sharedMaterial.name.IndexOf("smoke",StringComparison.OrdinalIgnoreCase)>=0).FirstOrDefault();
   if(!source){ThrallSourceMotion.Log?.Invoke("BT_DEATH_PUFF_UNAVAILABLE native Greyling smoke missing; bounded cosmetic cleanup retained");return false;}
   material=new Material(source.sharedMaterial){name="BT Own Orange Red Death Smoke"};if(material.HasProperty("_TintColor"))material.SetColor("_TintColor",Color.white);if(material.HasProperty("_Color"))material.SetColor("_Color",Color.white);return true;
  }
  public static ThrallDeathPuff Create(Bounds coverage,bool fullSized){
   if(!Prepare())return null;puffs.RemoveAll(p=>!p);if(puffs.Count>=ThrallDeathPolicy.MaximumPuffs){var old=puffs.FirstOrDefault(p=>p.released);if(!old)return null;puffs.Remove(old);Object.Destroy(old.gameObject);}
   var node=new GameObject("BT Own Red Despawn Puff");node.transform.position=coverage.center;var ps=node.AddComponent<ParticleSystem>();ps.Stop(true,ParticleSystemStopBehavior.StopEmittingAndClear);float scale=Mathf.Clamp(coverage.size.magnitude/3f,.85f,1.8f);
   var main=ps.main;main.loop=false;main.playOnAwake=false;main.duration=.35f;main.simulationSpace=ParticleSystemSimulationSpace.Local;main.cullingMode=ParticleSystemCullingMode.AlwaysSimulate;main.startLifetime=new ParticleSystem.MinMaxCurve(ThrallDeathPolicy.SmokeMinLifetime,ThrallDeathPolicy.SmokeMaxLifetime);main.startSpeed=new ParticleSystem.MinMaxCurve(.2f,.45f);main.startSize=new ParticleSystem.MinMaxCurve(.35f*scale,.65f*scale);main.startRotation=new ParticleSystem.MinMaxCurve(0,Mathf.PI*2);main.startColor=new ParticleSystem.MinMaxGradient(new Color(.7f,.10f,.025f,.7f),new Color(1,.32f,.07f,.85f));main.gravityModifier=-.025f;main.maxParticles=48;
   var emission=ps.emission;emission.rateOverTime=0;emission.rateOverDistance=0;emission.SetBursts(Array.Empty<ParticleSystem.Burst>());var shape=ps.shape;shape.shapeType=ParticleSystemShapeType.Box;shape.scale=new Vector3(Mathf.Max(.65f*scale,coverage.size.x),Mathf.Max(.35f*scale,coverage.size.y),Mathf.Max(.65f*scale,coverage.size.z));shape.randomDirectionAmount=1;
   var color=ps.colorOverLifetime;color.enabled=true;var gradient=new Gradient();gradient.SetKeys(new[]{new GradientColorKey(Color.white,0),new GradientColorKey(new Color(.65f,.19f,.12f),1)},new[]{new GradientAlphaKey(.8f,0),new GradientAlphaKey(.9f,.2f),new GradientAlphaKey(.85f,.65f),new GradientAlphaKey(0,1)});color.color=gradient;
   var size=ps.sizeOverLifetime;size.enabled=true;size.size=new ParticleSystem.MinMaxCurve(1,new AnimationCurve(new Keyframe(0,.35f),new Keyframe(.2f,1),new Keyframe(.65f,1.35f),new Keyframe(1,1.7f)));
   var renderer=ps.GetComponent<ParticleSystemRenderer>();renderer.sharedMaterial=material;renderer.renderMode=ParticleSystemRenderMode.Billboard;renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;
   var puff=node.AddComponent<ThrallDeathPuff>();puff.particles=ps;puff.Began=Time.time;puff.StartedFrame=Time.frameCount;puff.expires=Time.time+5f;puffs.Add(puff);ps.Play();ps.Emit(38);
   if(fullSized){size.enabled=false;int count=ps.GetParticles(puff.buffer);for(int i=0;i<count;i++)puff.buffer[i].startSize=Mathf.Max(puff.buffer[i].startSize,.8f*scale);ps.SetParticles(puff.buffer,count);}return puff;
  }
  public void Release(){if(released)return;released=true;int count=particles?particles.GetParticles(buffer):0;for(int i=0;i<count;i++)buffer[i].remainingLifetime=Mathf.Max(buffer[i].remainingLifetime,ThrallDeathPolicy.SmokeTailSeconds);if(particles)particles.SetParticles(buffer,count);expires=Mathf.Max(Began+ThrallDeathPolicy.SmokeMaxLifetime+.25f,Time.time+ThrallDeathPolicy.SmokeTailSeconds+.25f);}
  void Update(){if(Time.time>=expires)Object.Destroy(gameObject);}
  void OnDestroy(){puffs.Remove(this);}
  public static void Shutdown(){foreach(var puff in puffs.ToArray())if(puff)Object.Destroy(puff.gameObject);puffs.Clear();if(material)Object.Destroy(material);material=null;attempted=false;}
 }
}
