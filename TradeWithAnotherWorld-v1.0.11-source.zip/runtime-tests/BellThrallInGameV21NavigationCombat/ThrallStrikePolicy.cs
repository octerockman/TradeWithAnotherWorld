using System;using System.Collections.Generic;
namespace BlackAbbey.BellThrall {
 // Physical arcs only: no tracking lead-in, pose/speed changes or damage math.
 // Compute once per admitted packet, then retain group index in strike identity.
 public static class ThrallStrikePolicy {
  static bool Finite(float v)=>!float.IsNaN(v)&&!float.IsInfinity(v);
  public static ThrallMotionWindow[] Groups(float from,float to,ThrallMotionWindow[] windows){
   if(!Finite(from)||!Finite(to)||from<0||to<=from||windows==null||windows.Length>64)throw new ArgumentException("Invalid strike packet bounds or contact inventory");
   var clipped=new List<ThrallMotionWindow>(windows.Length);
   foreach(var w in windows){
    if(w==null||!Finite(w.start)||!Finite(w.end)||w.start<0||w.end<w.start)throw new ArgumentException("Invalid strike contact window");
    if(w.end<from||w.start>to)continue;
    clipped.Add(new ThrallMotionWindow{start=Math.Max(from,w.start),end=Math.Min(to,w.end)});
   }
   if(clipped.Count==0)return Array.Empty<ThrallMotionWindow>();
   clipped.Sort((a,b)=>{int order=a.start.CompareTo(b.start);return order!=0?order:a.end.CompareTo(b.end);});
   var groups=new List<ThrallMotionWindow>(clipped.Count);
   foreach(var w in clipped){
    if(groups.Count==0||w.start>groups[groups.Count-1].end)groups.Add(w);
    else groups[groups.Count-1].end=Math.Max(groups[groups.Count-1].end,w.end);
   }
   return groups.ToArray();
  }
 }
}
