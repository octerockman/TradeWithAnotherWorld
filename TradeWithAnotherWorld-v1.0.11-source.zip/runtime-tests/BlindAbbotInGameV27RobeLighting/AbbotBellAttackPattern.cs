using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace BlackAbbey.BlindAbbot
{
    [Serializable] public sealed class AbbotBellPattern
    {
        public string clip,eventId,kind,provenance;public float radius,length,width,angle,delay,duration,speed,fieldDuration,fieldRadius;public int count;
        public int[] behaviorJudgeIds;
    }
    public struct AbbotBellEmission
    {
        public string Kind;public Vector3 Center,Direction;public float Delay,Duration,Radius,Length,Width,Speed,FieldDuration,FieldRadius;
    }
    // Delivery shapes are deliberately bell powers. Exact source behavior
    // references and accepted contact clocks remain beside each adaptation.
    // This policy never reads scene state, changes animation or sends damage.
    public static class AbbotBellAttackPattern
    {
        public static void Validate(AbbotBellPattern p,AbbotCombatShapeBank bank)
        {
            if(p==null||bank.FindEvent(p.clip,p.eventId)==null||string.IsNullOrEmpty(p.provenance))throw new InvalidDataException("Bell shape has no source contact");
            if(p.kind!="frontBurst"&&p.kind!="targetField"&&p.kind!="fan"&&p.kind!="groundBurst"&&p.kind!="pulse")throw new InvalidDataException("Unknown bell delivery");
            foreach(float n in new[]{p.radius,p.length,p.width,p.angle,p.delay,p.duration,p.speed,p.fieldDuration,p.fieldRadius})if(!AbbotCombatShapeBank.Valid(n)||n<0)throw new InvalidDataException("Invalid bell shape value");
            if(p.radius>24||p.length>24||p.width>3||p.angle>150||p.delay>5||p.duration<=0||p.duration>10||p.count<1||p.count>9||p.speed>100||p.fieldDuration>8||p.fieldRadius>5)throw new InvalidDataException("Unbounded bell delivery");
        }
        public static AbbotBellEmission[] Build(AbbotBellPattern p,Vector3 origin,Vector3 forward,Vector3 target)
        {
            if(p==null)return Array.Empty<AbbotBellEmission>();forward.y=0;if(forward.sqrMagnitude<1e-6f)forward=Vector3.forward;forward.Normalize();
            var targetDelta=target-origin;targetDelta.y=0;var aim=targetDelta.sqrMagnitude>1e-6f?targetDelta.normalized:forward;
            if(p.kind=="targetField")
            {
                var point=origin+aim*Math.Min(p.length,targetDelta.magnitude);
                return new[]{Emission(p,point,aim)};
            }
            if(p.kind=="frontBurst"||p.kind=="groundBurst")return new[]{Emission(p,origin+forward*p.length,forward)};
            if(p.kind=="pulse")return new[]{Emission(p,origin,forward)};
            var result=new List<AbbotBellEmission>();
            for(int i=0;i<p.count;i++){float radians=(p.count==1?0:-p.angle*.5f+p.angle*i/(p.count-1))*(float)Math.PI/180f;float s=(float)Math.Sin(radians),c=(float)Math.Cos(radians);var direction=new Vector3(aim.x*c+aim.z*s,0,aim.z*c-aim.x*s);result.Add(Emission(p,origin,direction));}
            return result.ToArray();
        }
        static AbbotBellEmission Emission(AbbotBellPattern p,Vector3 center,Vector3 direction)=>new AbbotBellEmission{Kind=p.kind,Center=center,Direction=direction,Delay=p.delay,Duration=p.duration,Radius=p.radius,Length=p.length,Width=p.width,Speed=p.speed,FieldDuration=p.fieldDuration,FieldRadius=p.fieldRadius};
        public static float ActiveSeconds(AbbotBellEmission e)=>e.Delay+(e.Kind=="fan"&&e.Speed>0?Math.Min(e.Duration,e.Length/e.Speed)+e.FieldDuration:e.Duration+(e.Kind=="targetField"?e.FieldDuration:0));
        public static bool Contains(AbbotBellEmission e,Vector3 point,float targetRadius,float elapsed,float previousElapsed=-1)
        {
            if(!AbbotCombatShapeBank.Valid(elapsed)||!AbbotCombatShapeBank.Valid(targetRadius)||targetRadius<0||elapsed<e.Delay||elapsed>ActiveSeconds(e))return false;
            var d=point-e.Center;d.y=0;
            if(e.Kind=="fan")
            {
                float flight=e.Speed>0?Math.Min(e.Duration,e.Length/e.Speed):e.Duration;
                float along=Vector3.Dot(d,e.Direction),side=(d-e.Direction*along).magnitude;
                float head=e.Speed>0?Math.Min(e.Length,(elapsed-e.Delay)*e.Speed):e.Length;
                float tail=e.Speed>0?Math.Max(0,head-e.Width*2):0;
                if(e.Speed>0&&previousElapsed>=0)tail=Math.Min(tail,Math.Max(0,Math.Min(e.Length,Math.Max(0,previousElapsed-e.Delay)*e.Speed)-e.Width));
                if(e.Speed>0&&elapsed-e.Delay>=flight)
                {
                    var landed=e.Center+e.Direction*Math.Min(e.Length,e.Speed*flight);var field=point-landed;field.y=0;
                    if(e.FieldDuration>0&&field.magnitude<=e.FieldRadius+targetRadius)return true;
                    // A tick crossing the landing point must still test the
                    // final flight interval. Later field ticks do not leave
                    // the entire path active behind the landed projectile.
                    if(previousElapsed<0||previousElapsed-e.Delay>=flight)return false;
                }
                return along>=tail-targetRadius&&along<=head+targetRadius&&side<=e.Width+targetRadius;
            }
            if(e.Kind=="pulse"||e.Kind=="groundBurst")
            {
                float now=Mathf.Clamp01((elapsed-e.Delay)/e.Duration)*e.Radius;
                float old=previousElapsed<0?0:Mathf.Clamp01((previousElapsed-e.Delay)/e.Duration)*e.Radius;
                return d.magnitude>=Math.Max(0,old-targetRadius)&&d.magnitude<=now+targetRadius;
            }
            float radius=e.Kind=="targetField"&&elapsed>e.Delay+e.Duration?e.FieldRadius:e.Radius;
            return d.magnitude<=radius+targetRadius;
        }
    }
}
