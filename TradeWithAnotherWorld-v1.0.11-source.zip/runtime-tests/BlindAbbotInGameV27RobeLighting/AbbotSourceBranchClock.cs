using System;
using System.Linq;

namespace BlackAbbey.BlindAbbot
{
    // This cursor schedules authored opportunities, not the length of a combo.
    // A declined opportunity is consumed once; a later opportunity remains
    // available at its own time. Each newly entered clip owns a fresh cursor.
    public sealed class AbbotSourceBranchClock
    {
        // A long frame may cross several whole clips. Yielding after this many
        // transitions preserves the active clip and its clock for the next
        // Update; it never forces a valid chain to finish or recover.
        public const int MaximumTransitionsPerUpdate=8;
        readonly AbbotSourceWindow[] windows;
        int next;
        float elapsed=-1;
        public int Consumed=>next;
        public int Remaining=>windows.Length-next;
        public float NextBoundary(float duration)=>next<windows.Length?Math.Min(duration,windows[next].DecisionAt):duration;
        public AbbotSourceBranchClock(AbbotSourceWindow[] sourceWindows,bool terminal=false)
        {
            if(sourceWindows==null||sourceWindows.Length>64)throw new ArgumentException("Invalid source branch windows");
            if(sourceWindows.Any(w=>w==null||!Finite(w.start)||!Finite(w.end)||!Finite(w.DecisionAt)||w.start<0||w.DecisionAt<0||w.DecisionAt>w.start||w.end<w.start))throw new ArgumentException("Invalid source branch time");
            windows=terminal?new AbbotSourceWindow[0]:sourceWindows.OrderBy(w=>w.DecisionAt).ThenBy(w=>w.sourceEventIndex).ToArray();
        }
        public bool TryNext(float time,out AbbotSourceWindow window)
        {
            if(!Finite(time)||time<0)throw new ArgumentOutOfRangeException(nameof(time));
            window=null;
            if(time<elapsed)return false;
            elapsed=time;
            if(next>=windows.Length||windows[next].DecisionAt>time)return false;
            // Consume before the caller performs any decision/effect callback.
            window=windows[next++];return true;
        }
        public static bool TryBranchStart(float clipAt,float offset,out float nextAt)
        {
            nextAt=clipAt+offset;
            // No move-count or total-duration cutoff: only malformed or
            // float-collapsed, nonadvancing clocks are refused.
            return Finite(clipAt)&&Finite(offset)&&offset>0&&Finite(nextAt)&&nextAt>clipAt;
        }
        static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
    }
}
