using System;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbey.BlindAbbot
{
    // Attach only to this module's spawned Abbot. A native prefab by itself is
    // never protected, and a non-owning peer cannot change an actor's life.
    public sealed class AbbotHealthGuard : MonoBehaviour
    {
        Character actor;
        AbbotHealthPolicy policy;
        Action depleted;
        bool pendingDepletion;
        public AbbotLifeStage Mode => policy?.Stage ?? AbbotLifeStage.Released;
        public bool FirstBar => Mode == AbbotLifeStage.FirstBar;
        public bool TransitionProtected => Mode == AbbotLifeStage.Transition;
        public float OriginalMaximum => policy?.OriginalMaximum ?? 0;
        public float FinalMaximum => policy?.FinalMaximum ?? 0;
        internal bool Authoritative
        {
            get
            {
                if (!actor || !enabled || policy == null) return false;
                var view = actor.GetComponent<ZNetView>();
                return view && view.IsValid() && view.IsOwner();
            }
        }
        public void Bind(Character ownActor, float originalMaximum, Action onFirstBarDepleted)
        {
            if (!ownActor || ownActor.gameObject != gameObject || policy != null) throw new InvalidOperationException("Bind one own Abbot instance once.");
            actor = ownActor; policy = new AbbotHealthPolicy(originalMaximum); depleted = onFirstBarDepleted;
            if (!Authoritative) throw new InvalidOperationException("Abbot health initialization requires a valid owner ZDO.");
            actor.SetMaxHealth(originalMaximum); actor.SetHealth(originalMaximum);
        }
        public bool BeginTransition()
        {
            if (!Authoritative || !policy.BeginTransition()) return false;
            actor.SetHealth(AbbotHealthPolicy.SurvivalFloor); return true;
        }
        public bool RefillLastToll()
        {
            if (!Authoritative || !policy.RefillLastToll()) return false;
            // Native SetMaxHealth writes ZDO maximum; SetHealth then fills the
            // new bar. m_health is only the prefab base, not live HP storage.
            actor.SetMaxHealth(policy.FinalMaximum); actor.SetHealth(policy.FinalMaximum); return true;
        }
        public void Release() { pendingDepletion = false; depleted = null; policy?.Release(); }
        internal void Filter(ref float requested)
        {
            if (!Authoritative) return;
            requested = policy.FilterHealth(requested, actor.GetHealth(), out bool first);
            if (first) pendingDepletion = true;
        }
        internal void DispatchDepletion()
        {
            if (!Authoritative || !pendingDepletion) return;
            pendingDepletion = false;
            // The original native setter has completed. Callback cannot be
            // overwritten by the setter if it changes the controller state.
            depleted?.Invoke();
        }
        internal bool PermitDeathCheck()
        {
            if (!Authoritative || !policy.ProtectsLife || actor.GetHealth() > AbbotHealthPolicy.SurvivalFloor) return true;
            actor.SetHealth(AbbotHealthPolicy.SurvivalFloor); return false;
        }
        void OnDestroy() { Release(); }
        static AbbotHealthGuard Own(Character character) => character ? character.GetComponent<AbbotHealthGuard>() : null;

        [HarmonyPatch(typeof(Character), nameof(Character.SetHealth))]
        static class SetHealthPatch
        {
            [HarmonyPrefix, HarmonyPriority(Priority.Last)]
            static void Prefix(Character __instance, ref float health) { Own(__instance)?.Filter(ref health); }
            [HarmonyPostfix]
            static void Postfix(Character __instance) { Own(__instance)?.DispatchDepletion(); }
        }
        [HarmonyPatch(typeof(Character), "CheckDeath")]
        static class CheckDeathPatch
        {
            [HarmonyPrefix, HarmonyPriority(Priority.First)]
            static bool Prefix(Character __instance) => Own(__instance)?.PermitDeathCheck() ?? true;
        }
        [HarmonyPatch(typeof(Character), "RPC_Damage")]
        static class TransitionRpcDamagePatch
        {
            [HarmonyPrefix]
            static bool Prefix(Character __instance)
            {
                var own = Own(__instance); return !(own && own.Authoritative && own.TransitionProtected);
            }
        }
        [HarmonyPatch(typeof(Character), nameof(Character.ApplyDamage))]
        static class TransitionDirectDamagePatch
        {
            [HarmonyPrefix]
            static bool Prefix(Character __instance)
            {
                var own = Own(__instance); return !(own && own.Authoritative && own.TransitionProtected);
            }
        }
        [HarmonyPatch(typeof(Character), "RPC_Stagger")]
        static class TransitionStaggerPatch
        {
            [HarmonyPrefix]
            static bool Prefix(Character __instance)
            {
                var own = Own(__instance); return !(own && own.Authoritative && own.TransitionProtected);
            }
        }
    }
}
