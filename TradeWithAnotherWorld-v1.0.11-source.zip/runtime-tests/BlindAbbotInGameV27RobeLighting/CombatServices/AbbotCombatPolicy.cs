using System;
using System.Collections.Generic;

namespace BlackAbbey.BlindAbbot
{
    public enum AbbotLifeStage { FirstBar, Transition, LastToll, Released }

    // Pure encounter-owned lifetime policy, used by the actual native hooks.
    public sealed class AbbotHealthPolicy
    {
        public const float SurvivalFloor = .1f;
        public const float FinalFraction = .4f;
        public float OriginalMaximum { get; }
        public float FinalMaximum => OriginalMaximum * FinalFraction;
        public AbbotLifeStage Stage { get; private set; } = AbbotLifeStage.FirstBar;
        public bool ProtectsLife => Stage == AbbotLifeStage.FirstBar || Stage == AbbotLifeStage.Transition;
        public AbbotHealthPolicy(float originalMaximum)
        {
            if (!Finite(originalMaximum) || originalMaximum <= 1) throw new ArgumentOutOfRangeException(nameof(originalMaximum));
            OriginalMaximum = originalMaximum;
        }
        public float FilterHealth(float requested, float current, out bool firstDepletion)
        {
            firstDepletion = false;
            if (Stage == AbbotLifeStage.Released) return requested;
            if (float.IsNaN(requested)) requested = Finite(current) ? current : SurvivalFloor;
            if (Stage == AbbotLifeStage.Transition) return SurvivalFloor;
            if (Stage == AbbotLifeStage.FirstBar && requested <= SurvivalFloor)
            {
                Stage = AbbotLifeStage.Transition; firstDepletion = true; return SurvivalFloor;
            }
            float maximum = Stage == AbbotLifeStage.LastToll ? FinalMaximum : OriginalMaximum;
            return Math.Max(0, Math.Min(maximum, requested));
        }
        public bool BeginTransition()
        {
            if (Stage != AbbotLifeStage.FirstBar) return false;
            Stage = AbbotLifeStage.Transition; return true;
        }
        public bool RefillLastToll()
        {
            if (Stage != AbbotLifeStage.Transition) return false;
            Stage = AbbotLifeStage.LastToll; return true;
        }
        public void Release() { Stage = AbbotLifeStage.Released; }
        static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
    }

    public static class AbbotStaminaPolicy
    {
        public const float RitualCap = .25f, RegenerationMultiplier = .5f;
        public static float DrainToQuarter(float current, float maximum)
        {
            if (float.IsNaN(current) || float.IsInfinity(current) || float.IsNaN(maximum) || float.IsInfinity(maximum) || current < 0 || maximum <= 0) return 0;
            return Math.Max(0, current - maximum * RitualCap);
        }
        public static void ModifyRegeneration(ref float value) { value *= RegenerationMultiplier; }
    }

    // Profile identity survives replacement of the local Player on death.
    // Losing/removing the status does not rearm the stamina drain.
    public sealed class AbbotRitualLedger
    {
        readonly HashSet<long> affected = new HashSet<long>();
        public bool Ended { get; private set; }
        public int AffectedCount => affected.Count;
        public bool ContactOnce(long profileId) => !Ended && affected.Add(profileId);
        public bool WasAffected(long profileId) => !Ended && affected.Contains(profileId);
        public void End() { Ended = true; affected.Clear(); }
    }
}
