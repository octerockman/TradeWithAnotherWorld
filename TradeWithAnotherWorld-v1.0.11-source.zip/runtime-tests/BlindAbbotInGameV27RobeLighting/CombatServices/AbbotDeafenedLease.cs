using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbey.BlindAbbot
{
    public sealed class SE_AbbotDeafened : StatusEffect
    {
        public override void ModifyStaminaRegen(ref float staminaMultiplier) => AbbotStaminaPolicy.ModifyRegeneration(ref staminaMultiplier);
    }

    // One status instance per player, with a set of encounter owners. Two
    // overlapping owned encounters still produce .5, never .5 * .5.
    public sealed class AbbotDeafenedLease : IDisposable
    {
        public const string EffectName = "StudioOtherworld_BlindAbbot_Deafened_v1";
        static readonly Dictionary<int, SharedState> States = new Dictionary<int, SharedState>();
        static readonly List<AbbotDeafenedLease> Live = new List<AbbotDeafenedLease>();
        static readonly MethodInfo NativeUseStamina = AccessTools.Method(typeof(Player), "RPC_UseStamina", new[] { typeof(long), typeof(float) });
        static SE_AbbotDeafened template;
        static Texture2D iconTexture;
        static Sprite icon;
        readonly string token;
        readonly AbbotRitualLedger ledger = new AbbotRitualLedger();
        readonly Dictionary<int, Player> leased = new Dictionary<int, Player>();
        bool disposed;
        public int AffectedCount => ledger.AffectedCount;
        public string LastError { get; private set; }
        public bool Disposed => disposed;

        sealed class SharedState
        {
            internal Player Player;
            internal StatusEffect Effect;
            internal readonly HashSet<string> Owners = new HashSet<string>(StringComparer.Ordinal);
        }

        public AbbotDeafenedLease(string encounterToken)
        {
            if (string.IsNullOrWhiteSpace(encounterToken)) throw new ArgumentException("An owned encounter token is required.", nameof(encounterToken));
            foreach (var existing in Live) if (!existing.disposed && existing.token == encounterToken) throw new InvalidOperationException("Use a unique active encounter token.");
            if (NativeUseStamina == null) throw new MissingMethodException("Pinned owner-local Player.RPC_UseStamina(long,float) is unavailable.");
            token = encounterToken; Live.Add(this);
        }

        public bool Contact(Player player)
        {
            if (disposed || !EligibleLocal(player)) return false;
            if (ledger.ContactOnce(player.GetPlayerID()))
            {
                float delta = AbbotStaminaPolicy.DrainToQuarter(player.GetStamina(), player.GetMaxStamina());
                // Public UseStamina applies Game.m_staminaRate. Calling the
                // verified private owner-local body with the exact delta keeps
                // the requested25% cap independent of difficulty settings and
                // preserves the native stamina regeneration-delay side effect.
                if (delta > 0) NativeUseStamina.Invoke(player, new object[] { 0L, delta });
            }
            return Acquire(player);
        }
        public bool ContactPlayerOnceForRitual(Player player) => Contact(player);

        public bool Ensure(Player player)
        {
            if (disposed || !EligibleLocal(player) || !ledger.WasAffected(player.GetPlayerID())) return false;
            return Acquire(player);
        }
        public bool EnsureActiveDebuff(Player player) => Ensure(player);

        public void Tick(Func<Player, bool> eligible)
        {
            if (disposed) return;
            var remove = new List<int>();
            foreach (var pair in leased)
                if (!EligibleLocal(pair.Value) || eligible == null || !eligible(pair.Value)) remove.Add(pair.Key);
            foreach (int id in remove) { ReleaseShared(id, token); leased.Remove(id); }
            var current = Player.m_localPlayer;
            if (EligibleLocal(current) && eligible != null && eligible(current)) Ensure(current);
        }

        bool Acquire(Player player)
        {
            var manager = player.GetSEMan(); if (manager == null) return false;
            int id = player.GetInstanceID(), hash = EffectName.GetStableHashCode();
            var existing = manager.GetStatusEffect(hash);
            if (existing && !(existing is SE_AbbotDeafened))
            {
                LastError = "Status-name collision; unrelated effect was preserved."; return false;
            }
            if (!existing)
            {
                EnsureTemplate(); existing = manager.AddStatusEffect(template, false, 0, 0, 0);
                if (!(existing is SE_AbbotDeafened)) { LastError = "Native status manager did not add the owned Deafened effect."; return false; }
            }
            if (!States.TryGetValue(id, out var shared) || shared.Player != player)
                States[id] = shared = new SharedState { Player = player };
            shared.Effect = existing; shared.Owners.Add(token); leased[id] = player; LastError = null; return true;
        }

        static bool EligibleLocal(Player player)
        {
            if (!player || player != Player.m_localPlayer || player.IsDead() || player.IsTeleporting()) return false;
            var view = player.GetComponent<ZNetView>(); return view && view.IsValid() && view.IsOwner();
        }

        static void EnsureTemplate()
        {
            if (template) return;
            template = ScriptableObject.CreateInstance<SE_AbbotDeafened>(); template.name = EffectName;
            template.m_name = "Deafened"; template.m_tooltip = "The great bell rings within you.\nStamina regeneration reduced by50% for the remainder of this fight.";
            template.m_ttl = 0; template.m_flashIcon = false; template.m_cooldownIcon = false;
            if (!icon)
            {
                // Small original procedural bell silhouette for native HUD.
                iconTexture = new Texture2D(32, 32, TextureFormat.RGBA32, false) { name = "BA Own Deafened Bell Icon", filterMode = FilterMode.Point };
                var pixels = new Color[32 * 32];
                for (int y = 0; y < 32; y++) for (int x = 0; x < 32; x++)
                {
                    float xx = x - 15.5f;
                    bool body = y >= 8 && y <= 24 && Mathf.Abs(xx) <= 3 + (24 - y) * .45f;
                    bool rim = y >= 7 && y <= 9 && Mathf.Abs(xx) <= 12;
                    bool crown = y >= 25 && y <= 28 && Mathf.Abs(xx) <= 2;
                    bool clapper = y >= 3 && y <= 6 && Mathf.Abs(xx) <= 2;
                    pixels[y * 32 + x] = body || rim || crown || clapper ? new Color(.93f, .57f, .13f, 1) : Color.clear;
                }
                iconTexture.SetPixels(pixels); iconTexture.Apply(false, true);
                icon = Sprite.Create(iconTexture, new Rect(0, 0, 32, 32), new Vector2(.5f, .5f), 32); icon.name = "BA Own Deafened Bell Icon";
            }
            template.m_icon = icon;
        }

        static void ReleaseShared(int id, string owner)
        {
            if (!States.TryGetValue(id, out var shared)) return;
            shared.Owners.Remove(owner); if (shared.Owners.Count != 0) return;
            States.Remove(id);
            if (!shared.Player) return;
            var manager = shared.Player.GetSEMan();
            // Remove the exact object only. If another mod replaced it, leave
            // that different status untouched even when its hash matches.
            if (manager != null && shared.Effect && manager.GetStatusEffect(EffectName.GetStableHashCode()) == shared.Effect)
                manager.RemoveStatusEffect(shared.Effect, true);
        }

        public void Dispose()
        {
            if (disposed) return; disposed = true; ledger.End();
            foreach (int id in leased.Keys) ReleaseShared(id, token);
            leased.Clear(); Live.Remove(this);
        }
        public static void ShutdownAll()
        {
            foreach (var lease in new List<AbbotDeafenedLease>(Live)) lease.Dispose();
            States.Clear();
            if (template) Object.Destroy(template); if (icon) Object.Destroy(icon); if (iconTexture) Object.Destroy(iconTexture);
            template = null; icon = null; iconTexture = null;
        }
    }
}
