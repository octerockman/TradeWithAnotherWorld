using System;

namespace BlackAbbey.BlindAbbot
{
    public readonly struct AbbotHearingPoint
    {
        public readonly float X,Y,Z;
        public AbbotHearingPoint(float x,float y,float z){X=x;Y=y;Z=z;}
        public bool IsFinite=>AbbotHearingPolicy.Finite(X)&&AbbotHearingPolicy.Finite(Y)&&AbbotHearingPolicy.Finite(Z);
    }
    public readonly struct AbbotSoundObservation
    {
        public readonly long PlayerId;
        public readonly bool Eligible,Audible,Revealed;
        public readonly float Distance,NativeNoiseRange;
        // This is an observed point only, never a quiet player's live position.
        public readonly AbbotHearingPoint Position;
        public AbbotSoundObservation(long playerId,bool eligible,bool audible,bool revealed,float distance,float nativeNoiseRange,AbbotHearingPoint position)
        {PlayerId=playerId;Eligible=eligible;Audible=audible;Revealed=revealed;Distance=distance;NativeNoiseRange=nativeNoiseRange;Position=position;}
    }
    public enum AbbotHearingSource { None,NativeSound,ListenReveal,Memory }
    public readonly struct AbbotHearingState
    {
        public readonly AbbotHearingSource Source;
        public readonly long PlayerId;
        public readonly AbbotHearingPoint Position;
        public readonly double ObservedAt,Strength;
        public bool HasLocation=>Source!=AbbotHearingSource.None;
        public bool HasFreshSound=>Source==AbbotHearingSource.NativeSound;
        public bool IsReveal=>Source==AbbotHearingSource.ListenReveal;
        public bool HasMemory=>Source==AbbotHearingSource.Memory;
        public bool HasFreshObservation=>HasFreshSound||IsReveal;
        internal AbbotHearingState(AbbotHearingSource source,long playerId,AbbotHearingPoint position,double observedAt,double strength)
        {Source=source;PlayerId=playerId;Position=position;ObservedAt=observedAt;Strength=strength;}
    }

    // Pure, encounter-owned sound selection. No sight, proximity/heartbeat,
    // damage prerequisite, player coordinate query, or skill-derived bonus.
    public sealed class AbbotHearingPolicy
    {
        public const float MaximumDistance=40;
        public const double MemorySeconds=5;
        AbbotSoundObservation best;bool active,hasBest;double now,lastFrame=-1;
        AbbotHearingState remembered;
        public AbbotHearingState Current{get;private set;}

        public void BeginFrame(double time)
        {
            active=false;hasBest=false;best=default;
            if(!Finite(time)||time<0){Clear();return;}
            if(lastFrame>time){remembered=default;Current=default;}
            if(remembered.HasLocation&&time>=remembered.ObservedAt+MemorySeconds){remembered=default;Current=default;}
            now=time;lastFrame=time;active=true;
        }
        public bool Consider(AbbotSoundObservation candidate)
        {
            if(!active||!candidate.Eligible||candidate.PlayerId==0||!Finite(candidate.Distance)||candidate.Distance<0||candidate.Distance>MaximumDistance||!Finite(candidate.NativeNoiseRange)||candidate.NativeNoiseRange<0)return false;
            bool native=candidate.Audible&&NativeAudible(candidate.NativeNoiseRange,candidate.Distance,MaximumDistance);
            if(!native&&!candidate.Revealed||!candidate.Position.IsFinite)return false;
            // Recompute the native predicate; a malformed Audible flag cannot
            // grant a quiet target. Revealed is the caller's explicit ability gate.
            candidate=new AbbotSoundObservation(candidate.PlayerId,true,native,candidate.Revealed,candidate.Distance,candidate.NativeNoiseRange,candidate.Position);
            if(!hasBest||Better(candidate,best)){best=candidate;hasBest=true;}
            return true;
        }
        bool Better(AbbotSoundObservation candidate,AbbotSoundObservation incumbent)
        {
            if(candidate.Audible!=incumbent.Audible)return candidate.Audible;
            double a=candidate.Audible?PerceivedStrength(candidate.NativeNoiseRange,candidate.Distance):0;
            double b=incumbent.Audible?PerceivedStrength(incumbent.NativeNoiseRange,incumbent.Distance):0;
            if(a!=b)return a>b;
            bool priorA=candidate.PlayerId==remembered.PlayerId,priorB=incumbent.PlayerId==remembered.PlayerId;
            if(priorA!=priorB)return priorA;
            return candidate.PlayerId<incumbent.PlayerId;
        }
        public AbbotHearingState EndFrame()
        {
            if(!active)return Current;active=false;
            if(hasBest)
            {
                remembered=new AbbotHearingState(best.Audible?AbbotHearingSource.NativeSound:AbbotHearingSource.ListenReveal,best.PlayerId,best.Position,now,best.Audible?PerceivedStrength(best.NativeNoiseRange,best.Distance):0);
                Current=remembered;
            }
            else if(remembered.HasLocation&&now<remembered.ObservedAt+MemorySeconds)
                Current=new AbbotHearingState(AbbotHearingSource.Memory,remembered.PlayerId,remembered.Position,remembered.ObservedAt,remembered.Strength);
            else{remembered=default;Current=default;}
            return Current;
        }
        public void Clear(){best=default;remembered=default;Current=default;active=hasBest=false;lastFrame=-1;now=0;}
        public static bool NativeAudible(float noiseRange,float distance,float maximumDistance=MaximumDistance)
            =>Finite(noiseRange)&&Finite(distance)&&Finite(maximumDistance)&&noiseRange>0&&distance>=0&&maximumDistance>0&&distance<=maximumDistance&&distance<noiseRange;
        // Native noise is a radius, not a measured dB value. This bounded inverse
        // distance proxy ranks perceived strength without changing audibility.
        public static double PerceivedStrength(float noiseRange,float distance)
            =>Finite(noiseRange)&&Finite(distance)&&noiseRange>0&&distance>=0?noiseRange/(1.0+distance):0;
        internal static bool Finite(double value)=>!double.IsNaN(value)&&!double.IsInfinity(value);
    }
}
