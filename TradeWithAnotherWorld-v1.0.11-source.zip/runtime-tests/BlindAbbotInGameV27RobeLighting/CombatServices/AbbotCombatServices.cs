using System;
using UnityEngine;

namespace BlackAbbey.BlindAbbot
{
    public struct AbbotHearingSample
    {
        public Player Player;
        public long PlayerId;
        public bool Eligible, Audible, Crouching, Running, Attacking;
        public float Distance, NativeNoiseRange, Speed;
        public bool Revealed;
        public double PerceivedStrength;
        public AbbotSoundObservation Observation;
        // Only populated by native audibility or the explicit Listen ability.
        public Vector3 HeardPosition;
    }

    public static class AbbotCombatServices
    {
        public static bool NativeHit(Character attacker, Character victim, float blunt, float spirit, float push,
            Vector3 point, bool blockable = true, bool dodgeable = true)
        {
            if (!attacker || !victim || attacker == victim || attacker.IsDead() || victim.IsDead()) return false;
            var view = attacker.GetComponent<ZNetView>();
            if (!view || !view.IsValid() || !view.IsOwner()) return false;
            if (!Finite(blunt) || !Finite(spirit) || !Finite(push) || blunt < 0 || spirit < 0 || push < 0 || !Finite(point.x) || !Finite(point.y) || !Finite(point.z)) return false;
            var direction = victim.GetCenterPoint() - attacker.GetCenterPoint();
            if (direction.sqrMagnitude < .00001f) direction = attacker.transform.forward;
            var hit = new HitData { m_blockable = blockable, m_dodgeable = dodgeable, m_point = point,
                m_dir = direction.normalized, m_pushForce = push, m_backstabBonus = 1, m_staggerMultiplier = 1,
                m_hitType = HitData.HitType.EnemyHit };
            hit.m_damage.m_blunt = blunt; hit.m_damage.m_spirit = spirit; hit.SetAttacker(attacker);
            // Native RPC_Damage performs actual roll invincibility, directional
            // block/parry, armor/resistance, attacker and difficulty handling.
            victim.Damage(hit); return true;
        }

        public static AbbotHearingSample Snapshot(Player candidate, Vector3 listener, float maximumDistance = 40, bool reveal = false)
        {
            var result = new AbbotHearingSample { Player = candidate };
            if (!candidate || candidate.IsDead() || candidate.InGhostMode() || candidate.IsTeleporting() || candidate.InDebugFlyMode() ||
                !Finite(listener.x) || !Finite(listener.y) || !Finite(listener.z) || !Finite(maximumDistance) || maximumDistance <= 0) return result;
            var view = candidate.GetComponent<ZNetView>(); if (!view || !view.IsValid()) return result;
            var point = candidate.transform.position;
            if (!Finite(point.x) || !Finite(point.y) || !Finite(point.z)) return result;
            result.Distance = Vector3.Distance(listener, point);
            maximumDistance = Mathf.Min(maximumDistance, AbbotHearingPolicy.MaximumDistance);
            if (!Finite(result.Distance) || result.Distance > maximumDistance) return result;
            result.PlayerId = candidate.GetPlayerID(); if (result.PlayerId == 0) return result;
            result.Eligible = true;
            float noise = candidate.GetNoiseRange(); result.NativeNoiseRange = Finite(noise) ? Mathf.Max(0, noise) : 0;
            result.Crouching = candidate.IsCrouching(); result.Running = candidate.IsRunning(); result.Attacking = candidate.InAttack();
            result.Speed = candidate.GetVelocity().magnitude;
            result.Audible = AbbotHearingPolicy.NativeAudible(result.NativeNoiseRange, result.Distance, maximumDistance);
            result.Revealed = reveal;
            result.PerceivedStrength = result.Audible ? AbbotHearingPolicy.PerceivedStrength(result.NativeNoiseRange, result.Distance) : 0;
            if (result.Audible || result.Revealed) result.HeardPosition = point;
            result.Observation = new AbbotSoundObservation(result.PlayerId, result.Eligible, result.Audible, result.Revealed,
                result.Distance, result.NativeNoiseRange, new AbbotHearingPoint(result.HeardPosition.x, result.HeardPosition.y, result.HeardPosition.z));
            return result;
        }
        static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
    }
}
