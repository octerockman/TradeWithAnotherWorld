using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace BlackAbbey.BlindAbbot
{
    [Serializable] public sealed class AbbotReferencePoint { public float time,x,y,z,yawDegrees; }
    [Serializable] public sealed class AbbotRepertoireClip
    {
        public string id,role,selection;public float duration,strideMetres,sourceYawDegrees;
        public bool fullBodyAllowed,loopCandidate,extractedYawEmbeddedInPose,requiresAirPreparation;
        public AbbotReferencePoint[] trajectory;
    }
    [Serializable] public sealed class AbbotRepertoireData
    {
        public string schema;public float fittedLengthScale;public AbbotRepertoireClip[] clips;
        public string[] excluded,ceremonyOnly,overlayOnly;
    }
    // Reference motion was separate from HKX bone poses. Keep it separate:
    // source pose arrays remain unchanged; native Character alone owns travel.
    public sealed class AbbotMotionRepertoire
    {
        readonly Dictionary<string,AbbotRepertoireClip> byId;
        public AbbotRepertoireData Data{get;}
        public AbbotMotionRepertoire(AbbotRepertoireData data,MotionBank motions)
        {
            if(data==null||data.schema!="blind-abbot.motion-repertoire.v1"||motions?.clips==null||data.clips==null||data.clips.Length!=motions.clips.Length||data.clips.Length>128
                ||!Finite(data.fittedLengthScale)||data.fittedLengthScale<=0||data.fittedLengthScale>4||data.excluded==null||data.ceremonyOnly==null||data.overlayOnly==null)
                throw new InvalidDataException("Invalid source motion repertoire envelope");
            Data=data;byId=new Dictionary<string,AbbotRepertoireClip>(StringComparer.Ordinal);
            foreach(var c in data.clips){
                var native=motions.clips.FirstOrDefault(m=>m.name==c?.id);
                if(c==null||native==null||byId.ContainsKey(c.id)||!Finite(c.duration)||Math.Abs(c.duration-native.duration)>.001f||!Finite(c.strideMetres)||c.strideMetres<0||c.strideMetres>100||!Finite(c.sourceYawDegrees)||Math.Abs(c.sourceYawDegrees)>720||c.trajectory==null||c.trajectory.Length>4000
                    ||c.fullBodyAllowed&&(data.excluded.Contains(c.id)||data.overlayOnly.Contains(c.id)))throw new InvalidDataException("Invalid repertoire clip: "+c?.id);
                float prior=-1;
                foreach(var p in c.trajectory){if(p==null||!Finite(p.time)||p.time<0||p.time<prior||p.time>c.duration+.04f||!Finite(p.x)||!Finite(p.y)||!Finite(p.z)||!Finite(p.yawDegrees)||Math.Abs(p.x)>100||Math.Abs(p.y)>100||Math.Abs(p.z)>100||Math.Abs(p.yawDegrees)>720)throw new InvalidDataException("Invalid source reference path: "+c.id);prior=p.time;}
                byId.Add(c.id,c);
            }
        }
        public static AbbotMotionRepertoire Load(string path,MotionBank motions)
        {
            if(new FileInfo(path).Length>8*1024*1024)throw new InvalidDataException("Oversized source motion repertoire");
            return new AbbotMotionRepertoire(JsonConvert.DeserializeObject<AbbotRepertoireData>(File.ReadAllText(path),new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MetadataPropertyHandling=MetadataPropertyHandling.Ignore,MaxDepth=20}),motions);
        }
        public AbbotRepertoireClip Find(string id)=>id!=null&&byId.TryGetValue(id,out var c)?c:null;
        public float SampleYaw(string id,float normalized)
        {
            var c=Find(id);if(c==null||!c.fullBodyAllowed||c.extractedYawEmbeddedInPose||!Finite(normalized))return 0;
            var p=c.trajectory;if(p.Length==0)return c.sourceYawDegrees*Math.Max(0,Math.Min(1,normalized));
            float time=Math.Max(0,Math.Min(1,normalized))*c.duration;
            if(time<=p[0].time)return p[0].yawDegrees;
            int lo=0,hi=p.Length-1;
            while(hi-lo>1){int mid=(lo+hi)/2;if(p[mid].time<=time)lo=mid;else hi=mid;}
            if(time>=p[hi].time)return p[hi].yawDegrees;
            float span=p[hi].time-p[lo].time;return span<=0?p[hi].yawDegrees:p[lo].yawDegrees+(p[hi].yawDegrees-p[lo].yawDegrees)*(time-p[lo].time)/span;
        }
        static bool Finite(float n)=>!float.IsNaN(n)&&!float.IsInfinity(n);
    }
}
