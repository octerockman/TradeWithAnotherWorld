using System;
using System.Linq;
using System.Reflection;

namespace BlackAbbey.BlindAbbot
{
    internal static class AbbotBalanceBridge
    {
        static MethodInfo bind;
        internal static float Bind(Character actor,float configuredMaximum)
        {
            if(bind==null)
            {
                var helper=AppDomain.CurrentDomain.GetAssemblies().Select(a=>a.GetType("BlackAbbeySixRooms.RuntimeTestPlugin")).Single(t=>t!=null);
                bind=helper.GetMethod("BindBossBalance",BindingFlags.Public|BindingFlags.Static,null,new[]{typeof(Character),typeof(float)},null);
                if(bind==null)throw new MissingMethodException("Install the paired dungeon balance update before starting the Abbot encounter.");
            }
            return (float)bind.Invoke(null,new object[]{actor,configuredMaximum});
        }
    }
}
