using System;
#if !INVOCATION_FX_POLICY_ONLY
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;
#endif

namespace BlackAbbey.BlindAbbot
{
    // Pure timing/budget and mask recipe: the offline checks compile this exact
    // code without Unity, never an imitation of the production policy.
    public sealed class AbbotBellInvocationFxPolicy
    {
        public const int VaporLimit = 44, EmberLimit = 12, MaskSize = 64;
        public const float MaximumActiveSeconds = 18, StrikeSeconds = .28f;
        public const float VaporLifetime = 1, EmberLifetime = .48f;
        public const float VaporMaximumSize = .25f, EmberMaximumSize = .045f;
        public const float MaximumPalmOffset = .35f;
        public bool Active { get; private set; }
        public double Started { get; private set; }
        public float Anticipation { get; private set; }
        double lastStrike = double.NegativeInfinity;
        static bool Finite(double value) => !double.IsNaN(value) && !double.IsInfinity(value);
        static float Clamp(float value, float minimum, float maximum) => Math.Max(minimum, Math.Min(maximum, value));
        public static bool ValidPalmOffset(float x, float y, float z) => Finite(x) && Finite(y) && Finite(z)
            && (double)x * x + (double)y * y + (double)z * z <= (double)MaximumPalmOffset * MaximumPalmOffset;

        public bool Begin(double now, float anticipationSeconds)
        {
            End();
            if (!Finite(now)) return false;
            Started = now;
            Anticipation = Finite(anticipationSeconds) ? Clamp(anticipationSeconds, .1f, 12) : .1f;
            Active = true;
            return true;
        }
        public bool Alive(double now)
        {
            if (Active && (!Finite(now) || now < Started || now - Started >= MaximumActiveSeconds)) End();
            return Active;
        }
        public bool Strike(double now)
        {
            if (!Alive(now) || now - lastStrike < .2) return false;
            lastStrike = now;
            return true;
        }
        public bool Sample(double now, out float vaporRate, out float emberRate)
        {
            vaporRate = emberRate = 0;
            if (!Alive(now)) return false;
            float charge = Clamp((float)((now - Started) / Anticipation), 0, 1);
            float pulse = Clamp(1 - (float)((now - lastStrike) / StrikeSeconds), 0, 1);
            vaporRate = 12 + 12 * charge + 4 * pulse;
            emberRate = 3 + 4 * charge + 5 * pulse;
            return true;
        }
        public void End() { Active = false; lastStrike = double.NegativeInfinity; }

        // White RGB, cloudy alpha, zero-alpha perimeter. No downloaded texture,
        // imagegen, global random state, or hidden dependency is involved.
        public static byte[] BuildMaskRgba()
        {
            var pixels = new byte[MaskSize * MaskSize * 4];
            for (int y = 0; y < MaskSize; y++) for (int x = 0; x < MaskSize; x++)
            {
                double u = (x + .5) / MaskSize * 2 - 1, v = (y + .5) / MaskSize * 2 - 1;
                double radius = Math.Sqrt(u * u + v * v), angle = Math.Atan2(v, u);
                double edge = Math.Max(0, 1 - radius);
                double cloud = .70 + .17 * Math.Sin(u * 8 + Math.Sin(v * 6)) + .13 * Math.Sin(v * 13 - u * 5);
                double curl = .73 + .27 * Math.Sin(angle * 3 + radius * 11 + u * 2);
                double alpha = Math.Min(1, Math.Pow(edge, 1.5) * Math.Max(.15, cloud) * curl * 1.55);
                if (x == 0 || y == 0 || x == MaskSize - 1 || y == MaskSize - 1) alpha = 0;
                int index = (y * MaskSize + x) * 4;
                pixels[index] = pixels[index + 1] = pixels[index + 2] = 255;
                pixels[index + 3] = (byte)Math.Round(alpha * 255, MidpointRounding.AwayFromZero);
            }
            return pixels;
        }
    }

#if !INVOCATION_FX_POLICY_ONLY
    // One private left-hand cosmetic. This owns only its child node, material
    // and tiny texture, and never touches the supplied hand or actor properties.
    public sealed class AbbotBellInvocationFx : MonoBehaviour
    {
        const string NodeName = "BA left hand great bell invocation";
        readonly AbbotBellInvocationFxPolicy policy = new AbbotBellInvocationFxPolicy();
        ParticleSystem vapor, embers;
        Material material;
        Texture2D mask;
        Transform hand;
        [SerializeField] Vector3 localPalmOffset;
        bool ready, released;
        float lastVaporRate = -1, lastEmberRate = -1;
        static bool reportedUnavailable;

        public Vector3 LocalPalmOffset => localPalmOffset;
        // In the supplied hand's local Unity basis/metres, not world up. The
        // semantic L_Hand is a wrist: the caller supplies measured palm center.
        public bool SetPalmOffset(Vector3 localOffset)
        {
            if (released || !AbbotBellInvocationFxPolicy.ValidPalmOffset(localOffset.x, localOffset.y, localOffset.z)) return false;
            localPalmOffset = localOffset;
            transform.localPosition = localPalmOffset;
            return true;
        }

        public static AbbotBellInvocationFx Attach(Transform leftHand)
        {
            if (!leftHand) return null;
            var prior = leftHand.Find(NodeName);
            var existing = prior ? prior.GetComponent<AbbotBellInvocationFx>() : null;
            if (existing && !existing.released) return existing;
            // Sprites/Default is already used by the Abbot's owned tells. Its
            // transparent vertex-color pass supports this RGBA mask. Refuse an
            // opaque/color-only fallback that would draw hard square billboards.
            var shader = Shader.Find("Sprites/Default");
            if (!shader || !shader.isSupported)
            {
                if (!reportedUnavailable) { Debug.LogWarning("BA left-hand invocation unavailable: supported transparent sprite shader missing."); reportedUnavailable = true; }
                return null;
            }
            var root = new GameObject(NodeName);
            root.SetActive(false);
            root.layer = leftHand.gameObject.layer;
            root.transform.SetParent(leftHand, false);
            var effect = root.AddComponent<AbbotBellInvocationFx>();
            effect.enabled = false;
            try
            {
                effect.hand = leftHand;
                effect.Initialize(shader);
                root.SetActive(true);
                return effect;
            }
            catch (Exception error)
            {
                // Cosmetic failure must not prevent the boss from binding.
                if (!reportedUnavailable) { Debug.LogWarning("BA left-hand invocation initialization failed: " + error.Message); reportedUnavailable = true; }
                effect.Release();
                return null;
            }
        }

        void Initialize(Shader shader)
        {
            mask = new Texture2D(AbbotBellInvocationFxPolicy.MaskSize, AbbotBellInvocationFxPolicy.MaskSize, TextureFormat.RGBA32, false, true)
            { name = "BA invocation procedural soft vapor mask v1", wrapMode = TextureWrapMode.Clamp, filterMode = FilterMode.Bilinear };
            mask.LoadRawTextureData(AbbotBellInvocationFxPolicy.BuildMaskRgba());
            mask.Apply(false, true);
            material = new Material(shader) { name = "BA invocation red orange vapor v1", mainTexture = mask, color = Color.white, renderQueue = 3000 };
            vapor = CreateParticles("Curled red orange vapor", false);
            embers = CreateParticles("Subtle ember core", true);
            ready = true;
        }

        ParticleSystem CreateParticles(string label, bool core)
        {
            var node = new GameObject(label); node.layer = gameObject.layer;
            node.transform.SetParent(transform, false);
            var particles = node.AddComponent<ParticleSystem>();
            particles.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            particles.useAutoRandomSeed = false; particles.randomSeed = core ? 8321u : 14923u;
            var main = particles.main;
            main.loop = true; main.playOnAwake = false; main.duration = 2;
            main.simulationSpace = ParticleSystemSimulationSpace.Local;
            main.scalingMode = ParticleSystemScalingMode.Local;
            main.cullingMode = ParticleSystemCullingMode.AlwaysSimulate;
            main.maxParticles = core ? AbbotBellInvocationFxPolicy.EmberLimit : AbbotBellInvocationFxPolicy.VaporLimit;
            main.startLifetime = new ParticleSystem.MinMaxCurve(core ? .22f : .55f, core ? AbbotBellInvocationFxPolicy.EmberLifetime : AbbotBellInvocationFxPolicy.VaporLifetime);
            main.startSpeed = 0;
            main.startSize = new ParticleSystem.MinMaxCurve(core ? .018f : .10f, core ? AbbotBellInvocationFxPolicy.EmberMaximumSize : .18f);
            main.startRotation = new ParticleSystem.MinMaxCurve(0, Mathf.PI * 2);
            main.startColor = core ? new ParticleSystem.MinMaxGradient(new Color(1, .22f, .025f, .72f), new Color(1, .47f, .065f, .8f))
                : new ParticleSystem.MinMaxGradient(new Color(.65f, .035f, .008f, .36f), new Color(1, .19f, .018f, .52f));
            main.gravityModifier = 0;
            var emission = particles.emission; emission.rateOverTime = 0; emission.rateOverDistance = 0;
            emission.SetBursts(Array.Empty<ParticleSystem.Burst>());
            var shape = particles.shape; shape.enabled = true; shape.shapeType = ParticleSystemShapeType.Sphere;
            shape.radius = core ? .025f : .045f;
            var velocity = particles.velocityOverLifetime; velocity.enabled = false; velocity.space = ParticleSystemSimulationSpace.Local;
            // Unity requires coherent XYZ curve modes, including zero axes.
            // Configure while disabled so no intermediate partial state plays.
            velocity.x = new ParticleSystem.MinMaxCurve(0, 0);
            velocity.y = new ParticleSystem.MinMaxCurve(core ? .10f : .14f, core ? .23f : .26f);
            velocity.z = new ParticleSystem.MinMaxCurve(0, 0);
            velocity.orbitalX = new ParticleSystem.MinMaxCurve(0, 0);
            float orbit = core ? -.7f : 1.6f;
            velocity.orbitalY = new ParticleSystem.MinMaxCurve(orbit, orbit);
            velocity.orbitalZ = new ParticleSystem.MinMaxCurve(0, 0);
            velocity.enabled = true;
            var noise = particles.noise; noise.enabled = true; noise.quality = ParticleSystemNoiseQuality.Low;
            noise.strength = core ? .018f : .065f; noise.frequency = 2.3f; noise.scrollSpeed = .5f; noise.damping = true;
            var spin = particles.rotationOverLifetime; spin.enabled = true; spin.z = core ? -1.2f : .85f;
            var color = particles.colorOverLifetime; color.enabled = true;
            var gradient = new Gradient();
            gradient.SetKeys(new[] { new GradientColorKey(Color.white, 0), new GradientColorKey(core ? new Color(1, .4f, .06f) : new Color(.55f, .11f, .035f), 1) },
                new[] { new GradientAlphaKey(0, 0), new GradientAlphaKey(1, .15f), new GradientAlphaKey(core ? .7f : .65f, .55f), new GradientAlphaKey(0, 1) });
            color.color = gradient;
            var size = particles.sizeOverLifetime; size.enabled = true;
            size.size = new ParticleSystem.MinMaxCurve(1, new AnimationCurve(new Keyframe(0, .4f), new Keyframe(.35f, 1), new Keyframe(1, core ? .2f : 1.38f)));
            var renderer = particles.GetComponent<ParticleSystemRenderer>(); renderer.sharedMaterial = material;
            renderer.renderMode = ParticleSystemRenderMode.Billboard;
            renderer.shadowCastingMode = ShadowCastingMode.Off; renderer.receiveShadows = false;
            renderer.lightProbeUsage = LightProbeUsage.Off; renderer.reflectionProbeUsage = ReflectionProbeUsage.Off;
            renderer.motionVectorGenerationMode = MotionVectorGenerationMode.ForceNoMotion;
            renderer.maxParticleSize = .045f;
            return particles;
        }

        public void Begin(float anticipationSeconds)
        {
            if (!ready || released || !hand || !hand.gameObject.activeInHierarchy) return;
            ClearParticles();
            if (!policy.Begin(Time.timeAsDouble, anticipationSeconds)) return;
            transform.localPosition = localPalmOffset;
            transform.rotation = Quaternion.identity;
            enabled = true;
            ApplyRates(Time.timeAsDouble);
            vapor.Play(false); embers.Play(false);
            vapor.Emit(2); embers.Emit(1);
        }
        public void Strike()
        {
            if (!ready || released || !hand || !policy.Strike(Time.timeAsDouble)) return;
            transform.rotation = Quaternion.identity;
            vapor.Emit(4); embers.Emit(3);
            ApplyRates(Time.timeAsDouble);
        }
        void LateUpdate()
        {
            if (!hand || !ApplyRates(Time.timeAsDouble)) { End(); return; }
            // World-up vapor while its origin follows the animated hand. Only
            // this owned child rotates; no bone, gesture or authored Action does.
            transform.rotation = Quaternion.identity;
        }
        bool ApplyRates(double now)
        {
            if (!policy.Sample(now, out var vaporRate, out var emberRate)) return false;
            if (Mathf.Abs(lastVaporRate - vaporRate) > .1f) { var emission = vapor.emission; emission.rateOverTime = vaporRate; lastVaporRate = vaporRate; }
            if (Mathf.Abs(lastEmberRate - emberRate) > .1f) { var emission = embers.emission; emission.rateOverTime = emberRate; lastEmberRate = emberRate; }
            return true;
        }
        public void End() { policy.End(); ClearParticles(); enabled = false; }
        void ClearParticles()
        {
            if (vapor) vapor.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            if (embers) embers.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            lastVaporRate = lastEmberRate = -1;
        }
        public void Release()
        {
            if (released) return;
            released = true; End(); DestroyOwnedResources(); Object.Destroy(gameObject);
        }
        void OnDisable() { policy.End(); ClearParticles(); }
        void OnDestroy()
        {
            policy.End(); ClearParticles(); DestroyOwnedResources();
        }
        void DestroyOwnedResources()
        {
            // Initialization can fail while the private root is still inactive.
            // Unity need not call OnDestroy for a never-active object, so Release
            // also takes this idempotent path. End deliberately keeps assets.
            ready = false;
            if (material) Object.Destroy(material);
            material = null;
            if (mask) Object.Destroy(mask);
            mask = null;
        }
    }
#endif
}
