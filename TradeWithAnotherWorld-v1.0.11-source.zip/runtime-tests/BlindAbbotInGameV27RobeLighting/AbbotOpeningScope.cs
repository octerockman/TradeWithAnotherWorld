namespace BlackAbbey.BlindAbbot
{
    // One logical room encounter may replace its actor. Keep the successful
    // opening allowance with the room, not with that disposable actor/audio.
    // No save file, cross-run/static state or new encounter lifecycle is added.
    public sealed class AbbotOpeningScope
    {
        public string Group{get;private set;}
        public bool HasPlayed=>Group!=null;
        public bool RecordPlayed(string group)
        {
            if(HasPlayed||!AbbotAudioPolicy.IsOpening(group))return false;
            Group=group;return true;
        }
        public void Reset(){Group=null;}
    }
}
