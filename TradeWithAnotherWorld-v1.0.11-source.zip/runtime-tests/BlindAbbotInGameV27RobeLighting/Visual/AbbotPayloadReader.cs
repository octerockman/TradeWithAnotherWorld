using System;
using System.IO;
using System.IO.Compression;
using System.Globalization;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace BlackAbbey.BlindAbbot
{
    // Only owned DTOs are read. No runtime type metadata or game-owned art.
    public static class AbbotPayloadReader
    {
        public const int MaximumBytes=256*1024*1024;
        static T Deserialize<T>(string text) {
            if(string.IsNullOrWhiteSpace(text)||text.Length>MaximumBytes)throw new InvalidDataException("Empty/oversized Abbot data");
            try {var serializer=JsonSerializer.Create(new JsonSerializerSettings{ContractResolver=new DefaultContractResolver(),TypeNameHandling=TypeNameHandling.None,MetadataPropertyHandling=MetadataPropertyHandling.Ignore,MaxDepth=64,Culture=CultureInfo.InvariantCulture,CheckAdditionalContent=true});using(var reader=new JsonTextReader(new StringReader(text.TrimStart('\ufeff'))))return serializer.Deserialize<T>(reader);}
            catch(JsonException e){throw new InvalidDataException("Malformed Abbot data",e);}
        }
        // Stream large reviewed banks instead of keeping compressed bytes,
        // a second decompressed byte array and a UTF16 copy at the same time.
        sealed class BoundedStream:Stream{
            readonly Stream inner;long read;public BoundedStream(Stream input){inner=input;}
            public override bool CanRead=>true;public override bool CanSeek=>false;public override bool CanWrite=>false;public override long Length=>throw new NotSupportedException();public override long Position{get=>read;set=>throw new NotSupportedException();}
            public override int Read(byte[] b,int o,int c){int n=inner.Read(b,o,c);read+=n;if(read>MaximumBytes)throw new InvalidDataException("Abbot decompression limit");return n;}public override void Flush(){}public override long Seek(long o,SeekOrigin p)=>throw new NotSupportedException();public override void SetLength(long n)=>throw new NotSupportedException();public override void Write(byte[] b,int o,int c)=>throw new NotSupportedException();
        }
        static T ReadFile<T>(string path){
            if(new FileInfo(path).Length>MaximumBytes)throw new InvalidDataException("Oversized Abbot source");
            using(var file=File.OpenRead(path))using(var input=path.EndsWith(".gz",StringComparison.OrdinalIgnoreCase)?(Stream)new GZipStream(file,CompressionMode.Decompress):file)using(var bounded=new BoundedStream(input))using(var stream=new StreamReader(bounded,System.Text.Encoding.UTF8,true,65536))using(var reader=new JsonTextReader(stream)){
                var serializer=JsonSerializer.Create(new JsonSerializerSettings{ContractResolver=new DefaultContractResolver(),TypeNameHandling=TypeNameHandling.None,MetadataPropertyHandling=MetadataPropertyHandling.Ignore,MaxDepth=64,Culture=CultureInfo.InvariantCulture,CheckAdditionalContent=true});try{return serializer.Deserialize<T>(reader);}catch(JsonException e){throw new InvalidDataException("Malformed Abbot stream",e);}}
        }
        public static AbbotPayload Read(string path)=>Validate(ReadFile<AbbotPayload>(path));
        public static AbbotPayload Parse(string text)=>Validate(Deserialize<AbbotPayload>(text));
        static AbbotPayload Validate(AbbotPayload p){
            if(p==null||p.schema!="blind-abbot.runtime-visual.v1"||p.nodes==null||p.nodes.Length<4||p.nodes.Length>512||p.renderers==null||p.renderers.Length<1||p.renderers.Length>128||p.materials==null||p.materials.Length<1||p.materials.Length>128||p.totalTriangles<1||p.totalTriangles>2000000||p.containsGameOwnedMeshes||p.containsAnimationClips)throw new InvalidDataException("Abbot source inventory mismatch");
            if(p.sourceNative==null||!Hex(p.sourceNative.sha256)||p.nodes.Any(n=>n==null)||p.renderers.Any(r=>r==null)||p.materials.Any(m=>m==null))throw new InvalidDataException("Incomplete Abbot authority/data");
            foreach(var m in p.materials)foreach(var map in new[]{m.diffuse,m.normal,m.metallicGloss,m.emission})if(map!=null&&(!Hex(map.sha256)||string.IsNullOrWhiteSpace(map.path)))throw new InvalidDataException("Incomplete Abbot map");
            foreach(var m in p.materials)if(m.colorMultiplier!=null&&(m.colorMultiplier.Length!=4||m.colorMultiplier.Any(x=>float.IsNaN(x)||float.IsInfinity(x)||x<0||x>2)))throw new InvalidDataException("Invalid Abbot local surface multiplier");
            if(p.nodes.Select(n=>n.id).Distinct().Count()!=p.nodes.Length||p.nodes.Select(n=>n.name).Distinct().Count()!=p.nodes.Length||p.renderers.Sum(r=>r.triangleCount)!=p.totalTriangles)throw new InvalidDataException("Abbot duplicated nodes or triangle receipt mismatch");
            if(p.semanticNodes==null||!Finite(p.bodyHeight)||!Finite(p.staffHeight)||p.bodyHeight<1||p.bodyHeight>8||p.staffHeight<=0||p.staffHeight>12)throw new InvalidDataException("Abbot semantic/scale contract missing");
            foreach(string key in new[]{"Head","RightHand","LeftHand","Spine2","LeftShoulder","RightShoulder","LeftFoot","RightFoot","StaffTip"})
                if(!p.semanticNodes.TryGetValue(key,out var node)||!p.nodes.Any(n=>n.name==node))throw new InvalidDataException("Abbot semantic node missing: "+key);
            if(p.contacts==null||p.contacts.Length!=4||p.defaultFamily<0||p.defaultFamily>3||p.staffTipPositions?.Length!=4||p.contacts.Any(c=>c==null||c.role!="contact")||p.renderers.Any(r=>r.familyId<0||r.familyId>3)||p.contacts.Select(c=>c.familyId).Distinct().Count()!=4)throw new InvalidDataException("Reviewed four-bind contact contract missing");
            for(int family=0;family<4;family++)if(p.renderers.Count(r=>r.familyId==family&&r.role=="scarf")!=2||p.renderers.Count(r=>r.familyId==family&&r.role=="body")!=1||p.staffTipPositions[family]?.Length!=3||p.staffTipPositions[family].Any(x=>!Finite(x)))throw new InvalidDataException("Reviewed garment family incomplete");
            if(p.items==null)p.items=Array.Empty<MeshRecord>();return p;
        }
        public static MotionBank ReadMotion(string path) {
            var bank=ReadFile<MotionBank>(path);
            if(bank==null||bank.schema!="blind-abbot.motion.v1"||bank.boneNames==null||bank.boneNames.Length<4||bank.boneNames.Length>256||bank.boneNames.Any(string.IsNullOrWhiteSpace)||bank.boneNames.Distinct().Count()!=bank.boneNames.Length||bank.clips==null||bank.clips.Length<8||bank.clips.Length>128||bank.clips.Any(c=>c==null)||bank.clips.Select(c=>c.name).Distinct().Count()!=bank.clips.Length||bank.fps!=30||bank.containsVanillaClips||bank.sourceNative==null||!Hex(bank.sourceNative.sha256))throw new InvalidDataException("Abbot motion inventory mismatch");
            foreach(var c in bank.clips){if(c==null||c.familyId<0||c.familyId>3||string.IsNullOrWhiteSpace(c.name)||!Finite(c.duration)||c.duration<=0||c.duration>120||c.frames==null||c.frames.Length<2||c.frames.Length>3601)throw new InvalidDataException("Invalid Abbot clip");foreach(var f in c.frames){if(f?.positions?.Length!=bank.boneNames.Length*3||f.rotations?.Length!=bank.boneNames.Length*4||f.positions.Concat(f.rotations).Any(v=>!Finite(v))||f.scales!=null&&(f.scales.Length!=bank.boneNames.Length*3||f.scales.Any(v=>!Finite(v)||v<=0||v>10)))throw new InvalidDataException("Malformed Abbot motion frame");for(int i=0;i<bank.boneNames.Length;i++){int q=i*4;float norm=f.rotations[q]*f.rotations[q]+f.rotations[q+1]*f.rotations[q+1]+f.rotations[q+2]*f.rotations[q+2]+f.rotations[q+3]*f.rotations[q+3];if(Math.Abs(norm-1)>.003)throw new InvalidDataException("Nonunit motion rotation");}}}
            if(bank.aliases!=null)foreach(var alias in bank.aliases)if(!bank.clips.Any(c=>c.name==alias.Value))throw new InvalidDataException("Unknown role motion: "+alias.Key);
            return bank;
        }
        public static string ReadBoundedText(string path){
            if(new FileInfo(path).Length>MaximumBytes)throw new InvalidDataException("Oversized Abbot data");
            if(!path.EndsWith(".gz",StringComparison.OrdinalIgnoreCase))return File.ReadAllText(path);
            using(var input=File.OpenRead(path))using(var zip=new GZipStream(input,CompressionMode.Decompress))using(var memory=new MemoryStream()){
                var buffer=new byte[65536];int count;while((count=zip.Read(buffer,0,buffer.Length))>0){if(memory.Length+count>MaximumBytes)throw new InvalidDataException("Abbot motion decompression limit");memory.Write(buffer,0,count);}return System.Text.Encoding.UTF8.GetString(memory.ToArray());}
        }
        static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
        static bool Hex(string s)=>s!=null&&s.Length==64&&s.All(c=>c>='0'&&c<='9'||c>='a'&&c<='f');
    }
}
