using System;
using System.Collections.Generic;
namespace BlackAbbey.BlindAbbot
{
    [Serializable]public sealed class MotionFrame{public float[] positions,rotations,scales;}
    [Serializable]public sealed class MotionClip{public string name;public int familyId;public float duration;public bool loop;public MotionFrame[] frames;}
    [Serializable]public sealed class MotionBank{public string schema;public FileRecord sourceNative;public string[] boneNames;public int fps;public MotionClip[] clips;public bool containsVanillaClips;public Dictionary<string,string> aliases;}
}
