using System;
using System.Collections.Generic;
namespace BlackAbbey.BlindAbbot
{
    [Serializable] public sealed class FileRecord { public string path,sha256; }
    [Serializable] public sealed class NodeRecord {public int id,parentId;public string name;public float[] position,rotation,scale;}
    [Serializable] public sealed class LimitRecord {public bool useDefaultValues;public float[] min,max,center;public float axisLength;}
    [Serializable] public sealed class HumanRecord {public string boneName,humanName;public LimitRecord limit;}
    [Serializable] public sealed class SkeletonRecord {public string name;public float[] position,rotation,scale;}
    [Serializable] public sealed class Description {public HumanRecord[] human;public SkeletonRecord[] skeleton;public float upperArmTwist,lowerArmTwist,upperLegTwist,lowerLegTwist,armStretch,legStretch,feetSpacing;public bool hasTranslationDoF;}
    [Serializable] public sealed class WeightRecord {public int boneIndex0,boneIndex1,boneIndex2,boneIndex3;public float weight0,weight1,weight2,weight3;}
    [Serializable] public sealed class MatrixRecord {public float[] values;}
    [Serializable] public sealed class MeshRecord {
        public string name,type,materialId,role,attachmentName;public int familyId,vertexCount,triangleCount,rootBoneNodeId;
        public float[] positions,normals,tangents,uv,boundsCenter,boundsSize,position,rotation,scale;
        public int[] triangles,boneNodeIds;public WeightRecord[] weights;public MatrixRecord[] bindposes;
    }
    [Serializable] public sealed class MaterialRecord {public string id,nativeName;public FileRecord diffuse,normal,metallicGloss,emission;public float[] baseColor,colorMultiplier;public float roughness,metallic,emissionStrength;public bool proceduralBake;}
    [Serializable] public sealed class AbbotPayload {public string schema;public FileRecord sourceNative;public NodeRecord[] nodes;public Description humanDescription;public MeshRecord[] renderers,items,contacts;public int defaultFamily;public float[][] staffTipPositions;public MaterialRecord[] materials;public int bodyTriangles,totalTriangles;public bool containsGameOwnedMeshes,containsAnimationClips;public Dictionary<string,string> semanticNodes;public float bodyHeight,staffHeight;}

}
