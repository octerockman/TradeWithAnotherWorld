using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
namespace BlackAbbey.BlindAbbot
{
    // AI supplies the source phase. This component owns the displayed skeleton,
    // including transitions, without reading a pose another Animator has written.
    [DefaultExecutionOrder(12000)]
    public sealed class AbbotPoseDriver:MonoBehaviour
    {
        AbbotVisual visual;
        Transform[] bones;
        Vector3[] start, displayedPositions, transitionPositions,startScales,displayedScales,transitionScales;
        Quaternion[] rest, displayedRotations, transitionRotations;
        string[] names;
        MotionFrame grip;
        readonly Dictionary<string, MotionClip> clips = new Dictionary<string, MotionClip>();
        MotionClip current;
        AbbotPoseGrounding grounding;
        float phase, weight = 1, transitionElapsed, transitionSeconds;
        bool hasPose;

        public bool IsDriving => current != null;
        public string CurrentMotion => current?.name;
        public float TransitionProgress => transitionSeconds <= 0 ? 1 : Mathf.Clamp01(transitionElapsed / transitionSeconds);

        public void Initialize(AbbotVisual v, MotionBank bank)
        {
            if (bank.sourceNative.sha256 != v.Payload.sourceNative.sha256)
                throw new InvalidDataException("Visual and motion authority differ");
            visual = v;
            grounding = new AbbotPoseGrounding(v);
            clips.Clear(); current = null; hasPose = false;
            names = bank.boneNames;
            bones = new Transform[names.Length];
            start = new Vector3[bones.Length]; rest = new Quaternion[bones.Length];
            displayedPositions = new Vector3[bones.Length]; displayedRotations = new Quaternion[bones.Length];
            transitionPositions = new Vector3[bones.Length]; transitionRotations = new Quaternion[bones.Length];
            startScales=new Vector3[bones.Length];displayedScales=new Vector3[bones.Length];transitionScales=new Vector3[bones.Length];
            for (int i = 0; i < bones.Length; i++)
            {
                bones[i] = v.Named[names[i]];
                start[i] = displayedPositions[i] = transitionPositions[i] = bones[i].localPosition;
                rest[i] = displayedRotations[i] = transitionRotations[i] = bones[i].localRotation;
                startScales[i]=displayedScales[i]=transitionScales[i]=bones[i].localScale;
            }
            foreach (var clip in bank.clips) clips.Add(clip.name, clip);
            if(bank.aliases!=null)foreach(var alias in bank.aliases)clips.Add(alias.Key,clips[alias.Value]);
            grip = clips["idle"].frames[0];
            // Character's native motor reads current/next Animator state tags
            // for CanMove and IsStaggering. Keep that state machine advancing;
            // disabling it can leave a spawn/freeze/stagger gate latched. This
            // driver still writes every sampled bone last in LateUpdate, so the
            // displayed body/staff use the authored source, not native clips.
            if(visual.Animator)visual.Animator.enabled=true;
        }

        public void SetMotion(string name, float normalizedTime, float blend = 1,float transitionDuration=-1)
        {
            if (!clips.TryGetValue(name, out var requested)) throw new ArgumentException("Unknown Abbot motion: " + name);
            if (!Finite(normalizedTime) || !Finite(blend)||!Finite(transitionDuration)||transitionDuration< -1||transitionDuration>1.5f) throw new ArgumentException("Nonfinite/invalid Abbot phase, weight or transition");
            if (requested != current)
            {
                // Interrupted transitions start at the last displayed result.
                // Native look/foot IK may have changed the live bones meanwhile.
                Array.Copy(displayedPositions, transitionPositions, bones.Length);
                Array.Copy(displayedRotations, transitionRotations, bones.Length);
                Array.Copy(displayedScales,transitionScales,bones.Length);
                transitionElapsed = 0;
                transitionSeconds = hasPose ? transitionDuration>=0?transitionDuration:Duration(name) : 0;
                current = requested;
            }
            phase = Mathf.Clamp01(normalizedTime); weight = Mathf.Clamp01(blend);
            Apply();
        }

        public void ClearMotion()
        {
            current = null; hasPose = false;
            if (visual?.Animator) visual.Animator.enabled = true;
        }

        public void ConfigureGrounding(Transform roomRoot, float floorLocalY = .025f)
        { grounding?.Configure(roomRoot, floorLocalY); }
        public object GroundingSnapshot() => grounding?.Snapshot();
        // Final-pose corpse baking requests an immediate, measured support update.
        public void RefreshGrounding() { Apply(0, true); }

        // Offline trajectory checks use this same clocked path as LateUpdate.
        // Repeated requests in Update do not advance a transition twice.
        public void Advance(float deltaTime)
        {
            if (!Finite(deltaTime) || deltaTime < 0) throw new ArgumentOutOfRangeException(nameof(deltaTime));
            transitionElapsed = Mathf.Min(transitionSeconds, transitionElapsed + deltaTime);
            Apply(deltaTime);
        }
        void LateUpdate() { Advance(Time.deltaTime); }
        static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        static float Duration(string name)
        {
            switch (name)
            {
                case "idle": case "walk": case "stumble": return .26f;
                case "staff_slam": case "staff_sweep": case "great_bell_strike":
                case "bell_brace": case "listen": return .20f;
                default: return .24f;
            }
        }
        void Apply(float groundDelta = 0, bool snapGround = false)
        {
            if (visual == null) return;
            if (current == null)
            {
                for (int i = 0; i < bones.Length; i++)
                {
                    if (names[i].StartsWith("CTRL_") || names[i].StartsWith("AUX_"))
                    { bones[i].localPosition = start[i]; bones[i].localRotation = rest[i]; }
                    if (names[i].StartsWith("RightHand") && names[i] != "RightHand")
                    {
                        int q = i * 4;
                        bones[i].localRotation = new Quaternion(grip.rotations[q], grip.rotations[q + 1], grip.rotations[q + 2], grip.rotations[q + 3]);
                    }
                }
                grounding?.Apply(null, 0, groundDelta, snapGround);
                return;
            }
            float f = phase * (current.frames.Length - 1);
            int a = Mathf.FloorToInt(f), b = Mathf.Min(a + 1, current.frames.Length - 1);
            float t = f - a, u = TransitionProgress;
            // Fixed source snapshot and elapsed time: duplicate writes and frame
            // rate cannot turn this into exponential live-transform smoothing.
            float eased = u * u * (3 - 2 * u);
            var x = current.frames[a]; var y = current.frames[b];
            for (int i = 0; i < bones.Length; i++)
            {
                int p = i * 3, q = i * 4;
                var position = Vector3.Lerp(new Vector3(x.positions[p], x.positions[p + 1], x.positions[p + 2]), new Vector3(y.positions[p], y.positions[p + 1], y.positions[p + 2]), t);
                var rotation = Quaternion.Slerp(new Quaternion(x.rotations[q], x.rotations[q + 1], x.rotations[q + 2], x.rotations[q + 3]), new Quaternion(y.rotations[q], y.rotations[q + 1], y.rotations[q + 2], y.rotations[q + 3]), t);
                position = Vector3.Lerp(transitionPositions[i], position, eased * weight);
                rotation = Quaternion.Slerp(transitionRotations[i], rotation, eased * weight);
                bones[i].localPosition = displayedPositions[i] = position;
                bones[i].localRotation = displayedRotations[i] = rotation;
                var sx=x.scales==null?startScales[i]:new Vector3(x.scales[p],x.scales[p+1],x.scales[p+2]);var sy=y.scales==null?startScales[i]:new Vector3(y.scales[p],y.scales[p+1],y.scales[p+2]);
                bones[i].localScale=displayedScales[i]=Vector3.Lerp(transitionScales[i],Vector3.Lerp(sx,sy,t),eased*weight);
            }
            grounding?.Apply(current.name, phase, groundDelta, snapGround);
            hasPose = true;
        }
    }
}
