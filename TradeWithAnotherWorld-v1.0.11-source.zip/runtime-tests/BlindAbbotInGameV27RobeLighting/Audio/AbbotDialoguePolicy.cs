using System;
using System.Collections.Generic;

namespace BlackAbbey.BlindAbbot
{
    public enum AbbotDialogueEvent
    {
        DoorSealed, CandlesKindled, FirstApproach, Fracture, LastToll, PlayerKill, Death,
        StaffSlam, StaffSweep, BellPulse, BellRupture, ListenReveal, Hurt,
        StaffEffort, HurtEffort, CollapseEffort, Pant
    }

    // All times use the same monotonic DSP clock. EventId identifies one actual
    // occurrence, not an Update tick. AttackIndex counts actual move starts.
    public struct AbbotDialogueContext
    {
        public double Now, OccurredAt, WordsEndAt;
        public AbbotPhase Phase;
        public long EventId;
        public int AttackIndex;
        public bool PlayerPresent, HeardTarget, CausedByBoss;
        public float PreviousHealthFraction, HealthFraction;
    }

    public readonly struct AbbotDialogueDecision
    {
        public readonly bool Allowed, Interrupt, IsEffort;
        public readonly string Reason, Group;
        public readonly AbbotVoicePriority Priority;
        public readonly double LatestStartDsp;
        internal readonly AbbotDialoguePolicy Owner;
        internal readonly AbbotDialogueEvent Event;
        internal readonly AbbotDialogueContext Context;
        internal readonly long Revision;

        internal AbbotDialogueDecision(AbbotDialoguePolicy owner, AbbotDialogueEvent kind,
            AbbotDialogueContext context, long revision, string reason)
        {
            Owner=owner;Event=kind;Context=context;Revision=revision;Reason=reason;
            Allowed=reason==null;Group=AbbotDialoguePolicy.Group(kind);
            Priority=AbbotDialoguePolicy.Priority(kind);IsEffort=AbbotDialoguePolicy.Effort(kind);
            Interrupt=kind==AbbotDialogueEvent.LastToll||kind==AbbotDialogueEvent.Death||kind==AbbotDialogueEvent.CollapseEffort;
            LatestStartDsp=context.OccurredAt+AbbotDialoguePolicy.Expiry(kind);
        }
    }

    // Encounter-local dialogue admission only. It never schedules playback or
    // alters combat. A dropped occurrence expires; silence is an intended result.
    public sealed class AbbotDialoguePolicy
    {
        public const double SpokenStartGapSeconds=24, SpokenRestSeconds=16;
        public const double MilestoneRestSeconds=2.5, EffortGapSeconds=8, EffortWordGapSeconds=1.2;
        public const double AttackFamilyGapSeconds=36, HurtGapSeconds=45, ListenGapSeconds=35;
        public const int FeaturedAttackStride=3;
        readonly HashSet<long> committedEvents=new HashSet<long>();
        readonly HashSet<AbbotDialogueEvent> milestones=new HashSet<AbbotDialogueEvent>();
        readonly Dictionary<string,double> groupDue=new Dictionary<string,double>(StringComparer.Ordinal);
        double lastCommit=-1,lastSpoken=-1000,lastWordsEnd=-1000,lastEffort=-1000;
        bool introUsed;
        long revision;

        public AbbotDialogueDecision CanSpeak(AbbotDialogueEvent kind,AbbotDialogueContext context)
        {
            string reason=Reason(kind,context);
            return new AbbotDialogueDecision(this,kind,context,revision,reason);
        }

        string Reason(AbbotDialogueEvent kind,AbbotDialogueContext c)
        {
            if(!Enum.IsDefined(typeof(AbbotDialogueEvent),kind)||!Finite(c.Now)||!Finite(c.OccurredAt)||
                !Finite(c.WordsEndAt)||c.Now<0||c.OccurredAt<0||c.WordsEndAt<0||c.EventId<=0||c.OccurredAt>c.Now)
                return "invalid_event_context";
            if(c.Now<lastCommit)return "clock_rewind";
            if(c.Now>c.OccurredAt+Expiry(kind))return "expired_event";
            if(committedEvents.Contains(c.EventId))return "event_already_spoken";
            if(!ValidCause(kind,c))return "wrong_event_context";
            if(Introduction(kind)&&introUsed)return "intro_budget_used";
            if(OneShot(kind)&&milestones.Contains(kind))return "milestone_already_spoken";
            if(!Effort(kind)&&kind!=AbbotDialogueEvent.Death&&kind!=AbbotDialogueEvent.LastToll&&!c.PlayerPresent&&kind!=AbbotDialogueEvent.PlayerKill)
                return "no_listener";

            double wordsEnd=Math.Max(lastWordsEnd,c.WordsEndAt>0?c.WordsEndAt:-1000);
            if(kind==AbbotDialogueEvent.Death||kind==AbbotDialogueEvent.LastToll)return null;
            if(kind==AbbotDialogueEvent.CollapseEffort)
                return c.Now-lastEffort<EffortGapSeconds?"effort_rest":null;
            if(c.Now<wordsEnd)return "spoken_words_busy";
            if(Effort(kind))
            {
                if(c.Now<wordsEnd+EffortWordGapSeconds)return "effort_near_words";
                return c.Now-lastEffort<EffortGapSeconds?"effort_rest":null;
            }
            if(kind==AbbotDialogueEvent.Fracture)
                return c.Now<wordsEnd+MilestoneRestSeconds?"milestone_rest":null;
            if(Introduction(kind))return null;
            if(Attack(kind)&&(c.AttackIndex<=0||(c.AttackIndex-1)%FeaturedAttackStride!=0))return "nonfeatured_attack";
            if(c.Now<lastSpoken+SpokenStartGapSeconds||c.Now<wordsEnd+SpokenRestSeconds)return "spoken_rest";
            return groupDue.TryGetValue(Group(kind),out double due)&&c.Now<due?"group_rest":null;
        }

        // Call only after the exact decision's audio Request succeeded. A failed
        // Request consumes nothing, and a decision cannot be committed twice.
        public bool Commit(AbbotDialogueDecision decision,double speechSeconds)
        {
            if(!decision.Allowed||!ReferenceEquals(decision.Owner,this)||decision.Revision!=revision||
                !Finite(speechSeconds)||speechSeconds<0||speechSeconds>60||committedEvents.Contains(decision.Context.EventId))return false;
            var c=decision.Context;var kind=decision.Event;
            committedEvents.Add(c.EventId);lastCommit=c.Now;revision++;
            if(Introduction(kind))introUsed=true;
            if(OneShot(kind))milestones.Add(kind);
            if(Effort(kind))lastEffort=c.Now;
            else
            {
                lastSpoken=c.Now;lastWordsEnd=c.Now+speechSeconds;
                double gap=Attack(kind)?AttackFamilyGapSeconds:kind==AbbotDialogueEvent.Hurt?HurtGapSeconds:kind==AbbotDialogueEvent.ListenReveal?ListenGapSeconds:SpokenStartGapSeconds;
                groupDue[decision.Group]=c.Now+gap;
            }
            return true;
        }

        public void Reset()
        {
            committedEvents.Clear();milestones.Clear();groupDue.Clear();introUsed=false;
            lastCommit=-1;lastSpoken=lastWordsEnd=lastEffort=-1000;revision++;
        }

        static bool ValidCause(AbbotDialogueEvent kind,AbbotDialogueContext c)
        {
            bool combat=c.Phase==AbbotPhase.Service||c.Phase==AbbotPhase.Fracture||c.Phase==AbbotPhase.LastToll;
            switch(kind)
            {
                case AbbotDialogueEvent.DoorSealed:case AbbotDialogueEvent.CandlesKindled:return c.Phase==AbbotPhase.Waiting;
                case AbbotDialogueEvent.FirstApproach:return c.Phase==AbbotPhase.Service&&c.HeardTarget;
                case AbbotDialogueEvent.Fracture:return c.Phase==AbbotPhase.Fracture&&Health(c)&&c.PreviousHealthFraction>AbbotEncounterPolicy.FractureFraction&&c.HealthFraction<=AbbotEncounterPolicy.FractureFraction;
                case AbbotDialogueEvent.LastToll:case AbbotDialogueEvent.CollapseEffort:case AbbotDialogueEvent.Pant:return c.Phase==AbbotPhase.Ritual;
                case AbbotDialogueEvent.Death:return c.Phase==AbbotPhase.Dying;
                case AbbotDialogueEvent.PlayerKill:return combat&&c.CausedByBoss;
                case AbbotDialogueEvent.Hurt:case AbbotDialogueEvent.HurtEffort:return combat&&Health(c)&&c.HealthFraction<c.PreviousHealthFraction;
                case AbbotDialogueEvent.ListenReveal:return combat&&c.PlayerPresent;
                default:return combat&&c.PlayerPresent&&c.HeardTarget;
            }
        }
        static bool Health(AbbotDialogueContext c)=>Finite(c.PreviousHealthFraction)&&Finite(c.HealthFraction)&&c.PreviousHealthFraction>=0&&c.PreviousHealthFraction<=1&&c.HealthFraction>=0&&c.HealthFraction<=1;
        static bool Finite(double value)=>!double.IsNaN(value)&&!double.IsInfinity(value);
        internal static bool Introduction(AbbotDialogueEvent kind)=>kind==AbbotDialogueEvent.DoorSealed||kind==AbbotDialogueEvent.CandlesKindled||kind==AbbotDialogueEvent.FirstApproach;
        internal static bool OneShot(AbbotDialogueEvent kind)=>Introduction(kind)||kind==AbbotDialogueEvent.Fracture||kind==AbbotDialogueEvent.LastToll||kind==AbbotDialogueEvent.Death||kind==AbbotDialogueEvent.CollapseEffort;
        internal static bool Attack(AbbotDialogueEvent kind)=>kind==AbbotDialogueEvent.StaffSlam||kind==AbbotDialogueEvent.StaffSweep||kind==AbbotDialogueEvent.BellPulse||kind==AbbotDialogueEvent.BellRupture;
        internal static bool Effort(AbbotDialogueEvent kind)=>kind==AbbotDialogueEvent.StaffEffort||kind==AbbotDialogueEvent.HurtEffort||kind==AbbotDialogueEvent.CollapseEffort||kind==AbbotDialogueEvent.Pant;
        internal static double Expiry(AbbotDialogueEvent kind)
        {
            if(Attack(kind))return .65;
            switch(kind)
            {
                case AbbotDialogueEvent.Fracture:return 4;
                case AbbotDialogueEvent.DoorSealed:case AbbotDialogueEvent.FirstApproach:case AbbotDialogueEvent.PlayerKill:return 2;
                case AbbotDialogueEvent.LastToll:case AbbotDialogueEvent.Death:return 1.5;
                case AbbotDialogueEvent.CandlesKindled:return 1.5;
                default:return .5;
            }
        }
        internal static string Group(AbbotDialogueEvent kind)
        {
            switch(kind)
            {
                case AbbotDialogueEvent.DoorSealed:return "entrance";
                case AbbotDialogueEvent.CandlesKindled:return "candle";
                case AbbotDialogueEvent.FirstApproach:return "advance";
                case AbbotDialogueEvent.Fracture:return "escalation";
                case AbbotDialogueEvent.LastToll:return "finalTransition";
                case AbbotDialogueEvent.PlayerKill:return "playerKill";
                case AbbotDialogueEvent.Death:return "death";
                case AbbotDialogueEvent.StaffSlam:return "staffSlam";
                case AbbotDialogueEvent.StaffSweep:return "staffSweep";
                case AbbotDialogueEvent.BellPulse:return "bellWarning";
                case AbbotDialogueEvent.BellRupture:return "bellAttack";
                case AbbotDialogueEvent.ListenReveal:return "listen";
                case AbbotDialogueEvent.Hurt:return "hurt";
                case AbbotDialogueEvent.StaffEffort:return "staffEffort";
                case AbbotDialogueEvent.HurtEffort:return "hurtEffort";
                case AbbotDialogueEvent.CollapseEffort:return "collapseEffort";
                case AbbotDialogueEvent.Pant:return "pant";
                default:return null;
            }
        }
        internal static AbbotVoicePriority Priority(AbbotDialogueEvent kind)
        {
            if(kind==AbbotDialogueEvent.Death)return AbbotVoicePriority.Death;
            if(kind==AbbotDialogueEvent.LastToll||kind==AbbotDialogueEvent.CollapseEffort)return AbbotVoicePriority.Ritual;
            if(kind==AbbotDialogueEvent.Fracture)return AbbotVoicePriority.Attack;
            if(Introduction(kind))return AbbotVoicePriority.Intro;
            if(Effort(kind))return AbbotVoicePriority.Effort;
            if(kind==AbbotDialogueEvent.Hurt)return AbbotVoicePriority.Hurt;
            return AbbotVoicePriority.Attack;
        }
    }
}
