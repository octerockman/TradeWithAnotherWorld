using System;
using System.Collections.Generic;

namespace BlackAbbey.BlindAbbot
{
    public enum AbbotVoicePriority { Effort=10,Hurt=20,Ambient=30,Attack=60,Intro=80,Ritual=90,Death=100 }
    public static class AbbotAudioPolicy
    {
        public static readonly string[] RequiredGroups = {
            "entrance","candle","advance","bellWarning","bellAttack","staffSlam","staffSweep",
            "listen","hurt","escalation","finalTransition","death","playerKill","staffEffort","hurtEffort",
            "collapseEffort","pant","greatBell","carriedBell","frameCreak"
        };
        // Core budget excludes the separately bounded room-acoustic field.
        public const int MaximumVoiceLanes=2,MaximumFoleyVoices=3,MaximumSources=MaximumVoiceLanes+MaximumFoleyVoices+1+AbbotGreatBellPolicy.MaximumOrdinaryBellLanes;
        public const float VoiceTailGapSeconds=.18f,VoiceDuck=.18f,AttackReservationSeconds=5.5f,VoiceMaximumDistance=64;
        public struct VoiceSlot {public double endsAt,speechEndsAt;public bool spoken;public AbbotVoicePriority priority;}
        public static bool IsVoice(string group) => group != "greatBell" && group != "carriedBell" && group != "frameCreak";
        public static bool IsEffort(string group)=>group=="staffEffort"||group=="hurtEffort"||group=="collapseEffort"||group=="pant";
        public static bool IsOpening(string group)=>group=="entrance"||group=="candle"||group=="advance";
        public static AbbotVoicePriority DefaultPriority(string group)
        {
            switch(group)
            {
                case "death":return AbbotVoicePriority.Death;
                case "collapseEffort":case "pant":case "finalTransition":case "escalation":return AbbotVoicePriority.Ritual;
                case "entrance":case "candle":case "advance":return AbbotVoicePriority.Intro;
                case "bellWarning":case "bellAttack":case "staffSlam":case "staffSweep":return AbbotVoicePriority.Attack;
                case "hurt":return AbbotVoicePriority.Hurt;
                case "staffEffort":case "hurtEffort":return AbbotVoicePriority.Effort;
                default:return AbbotVoicePriority.Ambient;
            }
        }
        public static float Cooldown(string group)
        {
            switch (group)
            {
                case "entrance": case "candle": case "advance": return 30;
                case "death": return 60;
                case "listen": return 14;
                case "hurt": return 12;
                case "playerKill": return 8;
                case "escalation": case "finalTransition": return 20;
                case "greatBell": return 8;
                case "carriedBell": return .45f; // Authored final triplet at0.0,.6,1.2seconds.
                case "frameCreak": return 2;
                case "staffEffort": case "hurtEffort": case "collapseEffort": case "pant": return 6;
                default: return 2.5f;
            }
        }
        public static bool Finite(float x) => !float.IsNaN(x) && !float.IsInfinity(x);
        // Piecewise linear normalized to64m: full through16m, .85 at32m.
        public static float VoiceAttenuation(float distance)
        {
            if(!Finite(distance))return 0;float x=Math.Max(0,distance)/VoiceMaximumDistance;
            if(x<=.25f)return 1;if(x<=.5f)return 1-(x-.25f)*.6f;
            if(x<=.75f)return .85f-(x-.5f)*1.2f;return Math.Max(0,.55f-(x-.75f)*2.2f);
        }
        public static int SelectVoiceLane(double now,AbbotVoicePriority priority,bool effort,bool interrupt,VoiceSlot[] slots,double reactionBlockedUntil,out string reason)
        {
            reason=null;
            if(slots==null||slots.Length!=MaximumVoiceLanes){reason="invalid_lanes";return -1;}
            if(interrupt&&priority>=AbbotVoicePriority.Ritual)return 0;
            if(priority<=AbbotVoicePriority.Ambient&&now<reactionBlockedUntil){reason="attack_reserved";return -1;}
            for(int i=0;i<slots.Length;i++)if(slots[i].spoken&&now<slots[i].speechEndsAt){reason="spoken_words_busy";return -1;}
            if(effort)for(int i=0;i<slots.Length;i++)if(now<slots[i].endsAt){reason="effort_would_occupy_tail_lane";return -1;}
            for(int i=0;i<slots.Length;i++)if(now>=slots[i].endsAt)return i;
            int oldest=0;for(int i=1;i<slots.Length;i++)if(slots[i].endsAt<slots[oldest].endsAt)oldest=i;
            return oldest;
        }
        public sealed class Gate
        {
            readonly Dictionary<string,double> next = new Dictionary<string,double>(StringComparer.Ordinal);
            double lastTime = -1;
            // Defense at the playback boundary, in addition to contextual
            // dialogue admission. Direct Play/Request callers share one opening
            // family allowance; force and clock rewinds cannot replay it.
            public string OpeningGroup {get;private set;}
            public bool Allows(string group,double now,bool voiceBusy,bool force)
            {
                return Reason(group,now,force)==null&&(force||!voiceBusy);
            }
            public string Reason(string group,double now,bool force)
            {
                if(double.IsNaN(now)||double.IsInfinity(now)||now<0||Array.IndexOf(RequiredGroups,group)<0)return "invalid_event_or_time";
                if(now<lastTime)next.Clear();lastTime=now;
                if(IsOpening(group)&&OpeningGroup!=null)return "opening_family_used";
                return !force&&next.TryGetValue(group,out var due)&&now<due?"event_cooldown":null;
            }
            public void Commit(string group,double now) { next[group]=now+Cooldown(group);if(IsOpening(group))OpeningGroup=group; }
            public void Reset() { next.Clear();lastTime=-1;OpeningGroup=null; }
        }
    }
}
