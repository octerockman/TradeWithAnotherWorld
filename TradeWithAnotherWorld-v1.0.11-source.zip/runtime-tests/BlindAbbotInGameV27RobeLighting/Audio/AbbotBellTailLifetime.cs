using System;
using System.Collections.Generic;
using UnityEngine;

namespace BlackAbbey.BlindAbbot
{
    // Room-owned bell decays can finish after the actor's native final death.
    // The room destroys its children on unload; plugin shutdown stops them too.
    public sealed class AbbotBellTailLifetime:MonoBehaviour
    {
        static readonly HashSet<AbbotBellTailLifetime> Active=new HashSet<AbbotBellTailLifetime>();
        double until;
        public static void Arm(GameObject root,double end)
        {
            if(!root||double.IsNaN(end)||double.IsInfinity(end))return;
            var owner=root.GetComponent<AbbotBellTailLifetime>();if(!owner)owner=root.AddComponent<AbbotBellTailLifetime>();
            owner.until=AbbotGreatBellPolicy.DetachedTailDeadline(AudioSettings.dspTime,end);Active.Add(owner);
        }
        void Update(){if(AudioSettings.dspTime>=until)StopAndDestroy();}
        void StopAndDestroy(){foreach(var source in GetComponentsInChildren<AudioSource>(true))if(source)source.Stop();Active.Remove(this);Destroy(gameObject);}
        public static void ShutdownAll(){foreach(var owner in new List<AbbotBellTailLifetime>(Active))if(owner)owner.StopAndDestroy();Active.Clear();}
        public static void StopRoom(Transform room){if(!room)return;foreach(var owner in new List<AbbotBellTailLifetime>(Active))if(owner&&owner.transform.IsChildOf(room))owner.StopAndDestroy();}
        void OnDestroy(){Active.Remove(this);}
    }
}
