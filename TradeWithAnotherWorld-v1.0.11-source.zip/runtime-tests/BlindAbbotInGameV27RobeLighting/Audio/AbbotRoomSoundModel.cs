using System;

namespace BlackAbbey.BlindAbbot
{
    // Pure room model shared by the live audio thread and the WAV preview tool.
    // First/second order image sources plus a damped diffuse late field. This is
    // a bounded approximation of the authored chamber, not a wave-equation solver.
    public readonly struct RoomVector
    {
        public readonly double X,Y,Z;
        public RoomVector(double x,double y,double z){X=x;Y=y;Z=z;}
        public static RoomVector operator +(RoomVector a,RoomVector b)=>new RoomVector(a.X+b.X,a.Y+b.Y,a.Z+b.Z);
        public static RoomVector operator -(RoomVector a,RoomVector b)=>new RoomVector(a.X-b.X,a.Y-b.Y,a.Z-b.Z);
        public static RoomVector operator *(RoomVector a,double b)=>new RoomVector(a.X*b,a.Y*b,a.Z*b);
        public double Dot(RoomVector a)=>X*a.X+Y*a.Y+Z*a.Z;
        public double Length=>Math.Sqrt(Dot(this));
        public RoomVector Unit=>Length>1e-9?this*(1/Length):new RoomVector(0,0,0);
    }
    public readonly struct RoomPlane
    {
        public readonly RoomVector Point,Normal;public readonly double Reflectivity;
        public RoomPlane(RoomVector point,RoomVector normal,double reflectivity=.68){Point=point;Normal=normal.Unit;Reflectivity=reflectivity;}
        public RoomVector Mirror(RoomVector p)=>p-Normal*(2*(p-Point).Dot(Normal));
    }
    public readonly struct RoomTap
    {
        public readonly double Seconds,Left,Right;
        public RoomTap(double seconds,double left,double right){Seconds=seconds;Left=left;Right=right;}
    }
    public sealed class RoomAcousticPlan
    {
        public const double SpeedOfSound=343,DecaySeconds=3.1,TailSeconds=4.2;
        public readonly RoomTap[] Taps;public readonly double LateGain;
        public RoomAcousticPlan(RoomTap[] taps,double lateGain){Taps=taps;LateGain=lateGain;}
        public static RoomPlane[] FallbackPlanes()=>new[]{
            new RoomPlane(new RoomVector(-12.055,0,0),new RoomVector(1,0,0)),new RoomPlane(new RoomVector(12.055,0,0),new RoomVector(-1,0,0)),
            new RoomPlane(new RoomVector(0,0,.012),new RoomVector(0,0,1)),new RoomPlane(new RoomVector(0,0,32.0004),new RoomVector(0,0,-1)),
            new RoomPlane(new RoomVector(0,.025,0),new RoomVector(0,1,0),.58),new RoomPlane(new RoomVector(0,14.50,0),new RoomVector(0,-1,0),.72)};
        public static RoomAcousticPlan Build(RoomVector source,RoomVector listener,RoomVector listenerRight,RoomPlane[] planes)
        {
            if(planes==null||planes.Length!=6)throw new ArgumentException("Six chamber boundaries required");
            var taps=new RoomTap[24];double direct=(source-listener).Length;int at=0;
            for(int i=0;i<6;i++)taps[at++]=(source-planes[i].Point).Dot(planes[i].Normal)*(listener-planes[i].Point).Dot(planes[i].Normal)>0?Tap(planes[i].Mirror(source),listener,listenerRight,direct,.17*planes[i].Reflectivity):new RoomTap();
            // Adjacent boundaries contribute a denser field; no repeated-word tape.
            for(int i=0;i<6;i++)for(int j=i+1;j<6;j++)if(i/2!=j/2)
                taps[at++]=Tap(planes[j].Mirror(planes[i].Mirror(source)),listener,listenerRight,direct,.040*planes[i].Reflectivity*planes[j].Reflectivity);
            for(int i=0;i<6;i+=2)for(int direction=0;direction<2;direction++)if(at<taps.Length){int a=i+direction,b=i+1-direction;taps[at++]=Tap(planes[b].Mirror(planes[a].Mirror(source)),listener,listenerRight,direct,.024*planes[a].Reflectivity*planes[b].Reflectivity);}
            double distanceGain=Attenuation(direct);
            return new RoomAcousticPlan(taps,.075*distanceGain);
        }
        static RoomTap Tap(RoomVector image,RoomVector listener,RoomVector right,double direct,double energy)
        {
            var direction=image-listener;double length=direction.Length;
            if(length<direct-1e-6)return new RoomTap(); // Noncausal ordered image in a sloped/non-box vault.
            double gain=energy*Math.Pow((8+direct)/(8+length),1.1)*Attenuation(direct);
            double pan=Math.Max(-.95,Math.Min(.95,direction.Unit.Dot(right.Unit)));
            return new RoomTap(Math.Max(.001,(length-direct)/SpeedOfSound),gain*Math.Sqrt((1-pan)*.5),gain*Math.Sqrt((1+pan)*.5));
        }
        public static double Attenuation(double d){double x=Math.Max(0,d)/64;if(x<=.25)return 1;if(x<=.5)return 1-(x-.25)*.6;if(x<=.75)return .85-(x-.5)*1.2;return Math.Max(0,.55-(x-.75)*2.2);}
    }
    public sealed class RoomVoiceStream
    {
        public readonly float[] Samples;public readonly long StartSample,StopSample,FadeStart,FadeEnd;public readonly double Gain;
        public RoomVoiceStream(float[] samples,long start,double gain,long stop=long.MaxValue,long fadeStart=0,long fadeEnd=0){Samples=samples;StartSample=start;Gain=gain;StopSample=stop;FadeStart=fadeStart;FadeEnd=fadeEnd;}
        public RoomVoiceStream Stop(long at)=>new RoomVoiceStream(Samples,StartSample,Gain,Math.Min(at,StopSample),FadeStart,FadeEnd);
        public RoomVoiceStream Fade(long at,long end)=>new RoomVoiceStream(Samples,StartSample,Gain,Math.Min(end,StopSample),at,end);
    }
    public sealed class RoomSoundState
    {
        public readonly RoomAcousticPlan Plan;public readonly RoomVoiceStream[] Voices;public readonly double Mix;public readonly int Generation;
        public RoomSoundState(RoomAcousticPlan plan,RoomVoiceStream[] voices,double mix,int generation){Plan=plan;Voices=voices;Mix=mix;Generation=generation;}
    }
    public sealed class AbbotRoomSoundProcessor
    {
        readonly int sampleRate,mask;readonly float[] history;readonly float[][] late=new float[8][];
        readonly int[] lateAt=new int[8];readonly double[] lateLow=new double[8],lateRead=new double[8],feedback=new double[8];
        readonly double[] delays=new double[24],left=new double[24],right=new double[24],low=new double[24];
        int write,generation=int.MinValue;long expectedSample=-1;double mix;
        public AbbotRoomSoundProcessor(int rate)
        {
            if(rate<22050||rate>192000)throw new ArgumentOutOfRangeException(nameof(rate));sampleRate=rate;int length=1;while(length<rate)length<<=1;history=new float[length];mask=length-1;
            double[] times={.0311,.0377,.0431,.0493,.0557,.0617,.0713,.0797};
            for(int i=0;i<8;i++){int n=(int)(times[i]*rate)|1;late[i]=new float[n];feedback[i]=Math.Pow(.001,times[i]/RoomAcousticPlan.DecaySeconds);}
        }
        // No allocations, locks, Unity object access or file I/O in this path.
        public void Render(float[] output,int channels,long firstSample,RoomSoundState state)
        {
            if(output==null||channels<1||output.Length%channels!=0)throw new ArgumentException("Interleaved output required");
            if(state==null||state.Plan==null){Array.Clear(output,0,output.Length);return;}
            if(generation!=state.Generation||expectedSample>=0&&Math.Abs(firstSample-expectedSample)>1){Array.Clear(history,0,history.Length);for(int i=0;i<8;i++){Array.Clear(late[i],0,late[i].Length);lateAt[i]=0;lateLow[i]=0;}Array.Clear(low,0,low.Length);Array.Clear(delays,0,delays.Length);Array.Clear(left,0,left.Length);Array.Clear(right,0,right.Length);write=0;mix=0;generation=state.Generation;}
            double smoothing=1-Math.Exp(-1.0/(sampleRate*.035)),damping=1-Math.Exp(-2*Math.PI*2200/sampleRate);
            for(int frame=0;frame<output.Length/channels;frame++)
            {
                long clock=firstSample+frame;double input=0;
                foreach(var voice in state.Voices)
                {
                    if(voice==null||clock<voice.StartSample||clock>=voice.StopSample)continue;
                    double index=(clock-voice.StartSample)*(48000.0/sampleRate);int a=(int)index;
                    if(a>=0&&a<voice.Samples.Length){int b=Math.Min(a+1,voice.Samples.Length-1);double envelope=voice.FadeEnd>0?Math.Max(0,Math.Min(1,(voice.FadeEnd-clock)/(double)Math.Max(1,voice.FadeEnd-voice.FadeStart))):1;input+=(voice.Samples[a]+(voice.Samples[b]-voice.Samples[a])*(index-a))*voice.Gain*envelope;}
                }
                history[write]=(float)input;double l=0,r=0,early=0;
                for(int i=0;i<24;i++)
                {
                    var tap=state.Plan.Taps[i];double target=Math.Min(history.Length-4,Math.Max(1,tap.Seconds*sampleRate));
                    if(delays[i]==0)delays[i]=target;
                    delays[i]+=Math.Max(-.025,Math.Min(.025,target-delays[i]));left[i]+=(tap.Left-left[i])*smoothing;right[i]+=(tap.Right-right[i])*smoothing;
                    double position=write-delays[i];int a=(int)Math.Floor(position);double t=position-a;
                    double value=history[a&mask]*(1-t)+history[(a+1)&mask]*t;low[i]+=(value-low[i])*damping;
                    l+=low[i]*left[i];r+=low[i]*right[i];early+=low[i]*(left[i]+right[i])*.5;
                }
                double sum=0;
                for(int i=0;i<8;i++){lateLow[i]+=(late[i][lateAt[i]]-lateLow[i])*damping;lateRead[i]=lateLow[i];sum+=lateRead[i];}
                double diffuseL=0,diffuseR=0;
                for(int i=0;i<8;i++)
                {
                    double scattered=lateRead[i]-.25*sum;
                    late[i][lateAt[i]]=(float)(scattered*feedback[i]+(input*.12+early*.10)*(i%2==0?1:-1));
                    lateAt[i]=(lateAt[i]+1)%late[i].Length;
                    diffuseL+=lateRead[i]*(i%2==0?1:-.7);diffuseR+=lateRead[i]*(i%3==0?1:-.6);
                }
                mix+=(state.Mix-mix)*smoothing;l=(l+diffuseL*state.Plan.LateGain)*mix;r=(r+diffuseR*state.Plan.LateGain)*mix;
                l=Math.Max(-.28,Math.Min(.28,l));r=Math.Max(-.28,Math.Min(.28,r));
                int at=frame*channels;if(channels==1)output[at]=(float)((l+r)*.5);else{output[at]=(float)l;output[at+1]=(float)r;for(int c=2;c<channels;c++)output[at+c]=0;}
                write=(write+1)&mask;
            }
            expectedSample=firstSample+output.Length/channels;
        }
    }
}
