using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

namespace BlackAbbey.BlindAbbot
{
    // Own actor presentation; encounter authority and authored cue times remain external.
    public sealed class AbbotAudioController:MonoBehaviour
    {
        sealed class Lane
        {
            public AudioSource source;public double endsAt,speechEndsAt,fadeStart,fadeEnd;public float baseGain;
            public bool fixedPoint,spoken;public Vector3 point;public string group,cue;public AbbotVoicePriority priority;
        }
        public sealed class Telemetry
        {
            public bool ready,enabled,released,voiceBusy;public int allocatedSources,played,dropped,requested,tailRecycles,bellTailRecycles;
            public double voiceEndsAtDsp,wordsEndAtDsp,deathVoiceEndsAtDsp;public float voiceGain;
            public string lastVoiceId,mixerName,failure,lastDropReason,openingGroup,openingCue;public int coreAllocatedSources,coreSourceBudget,roomAcousticSources;
            public Dictionary<string,int> groupCommands,cueCommands,groupRequests,groupDrops,dropReasons;
        }
        public event Action<float,float> DuckRequested;
        public event Action<string,string,float> EventPlayed;
        public event Action<string,string> EventDropped;
        public bool Ready=>initialized&&!released&&bank!=null&&bank.Ready&&mixer;
        public bool VoiceBusy=>Ready&&mixEnabled&&AudioSettings.dspTime<WordsEndAtDsp;
        public double VoiceEndsAtDsp {get{double end=roomSound?roomSound.TailUntil:0;foreach(var lane in voices)if(lane!=null)end=Math.Max(end,lane.endsAt);return end;}}
        public double WordsEndAtDsp {get{double end=0;foreach(var lane in voices)if(lane!=null&&lane.spoken)end=Math.Max(end,lane.speechEndsAt);return end;}}
        public double VoiceAvailableAtDsp=>WordsEndAtDsp>0?WordsEndAtDsp+AbbotAudioPolicy.VoiceTailGapSeconds:0;
        public double DeathVoiceEndsAtDsp {get;private set;}
        public double GreatBellEndsAtDsp=>greatBell?.endsAt??0;
        public double AudioEndsAtDsp {get{double end=Math.Max(VoiceEndsAtDsp,GreatBellEndsAtDsp);foreach(var lane in roomBells)if(lane!=null)end=Math.Max(end,lane.endsAt);foreach(var lane in foley)if(lane!=null)end=Math.Max(end,lane.endsAt);return end;}}
        public string LastVoiceId {get;private set;}
        public string OpeningCue {get;private set;}
        public string LastDropReason {get;private set;}
        public string Failure {get;private set;}
        AbbotAudioBank bank;AudioMixerGroup mixer;Transform head;GameObject audioRoot,bellRoot;AbbotRoomAcoustics roomSound;Vector3 roomBellPoint;bool hasRoomBell,preserveBellTails;
        Lane greatBell;readonly Lane[] voices=new Lane[AbbotAudioPolicy.MaximumVoiceLanes],foley=new Lane[AbbotAudioPolicy.MaximumFoleyVoices];
        readonly Lane[] roomBells=new Lane[AbbotGreatBellPolicy.MaximumOrdinaryBellLanes];readonly double[] bellEnds=new double[AbbotGreatBellPolicy.MaximumOrdinaryBellLanes];
        readonly AbbotAudioPolicy.VoiceSlot[] slots=new AbbotAudioPolicy.VoiceSlot[AbbotAudioPolicy.MaximumVoiceLanes];
        readonly AbbotAudioPolicy.Gate gate=new AbbotAudioPolicy.Gate();
        readonly AbbotAudioPolicy.Gate bellGate=new AbbotAudioPolicy.Gate();
        readonly Dictionary<string,string> previous=new Dictionary<string,string>(StringComparer.Ordinal);
        readonly Dictionary<string,int> groupCommands=new Dictionary<string,int>(StringComparer.Ordinal),cueCommands=new Dictionary<string,int>(StringComparer.Ordinal),
            groupRequests=new Dictionary<string,int>(StringComparer.Ordinal),groupDrops=new Dictionary<string,int>(StringComparer.Ordinal),dropReasons=new Dictionary<string,int>(StringComparer.Ordinal);
        Action<string> log;System.Random random;bool initialized,released,mixEnabled=true;float volume=1,voiceGain=1;int played,dropped,requested,tailRecycles,bellTailRecycles;
        double reactionBlockedUntil;

        public static AbbotAudioController Attach(GameObject actor,AbbotAudioBank bank,Transform head,AudioMixerGroup mixer,Action<string> log=null)
        {
            if(!actor||!actor.activeInHierarchy||bank==null||!bank.Ready||!mixer){log?.Invoke("BA_AUDIO_ACTOR_UNAVAILABLE: requires active own actor, warm bank and native SFX mixer.");return null;}
            var prior=actor.GetComponent<AbbotAudioController>();if(prior&&prior.Ready)return prior;
            if(prior)prior.Release();var result=prior?prior:actor.AddComponent<AbbotAudioController>();
            try{result.Initialize(bank,head,mixer,log);return result;}
            catch(Exception error){result.Failure=error.Message;result.Release();log?.Invoke("BA_AUDIO_ACTOR_UNAVAILABLE "+error);return null;}
        }
        void Initialize(AbbotAudioBank b,Transform h,AudioMixerGroup output,Action<string> logger)
        {
            bank=b;head=h;mixer=output;log=logger;released=false;random=new System.Random(GetInstanceID()^Environment.TickCount);
            preserveBellTails=false;hasRoomBell=false;roomBellPoint=Vector3.zero;bellRoot=null;roomSound=null;greatBell=null;
            Array.Clear(roomBells,0,roomBells.Length);Array.Clear(foley,0,foley.Length);Array.Clear(bellEnds,0,bellEnds.Length);
            audioRoot=new GameObject("BA_Abbot_Own_Audio");audioRoot.transform.SetParent(transform,false);
            for(int i=0;i<voices.Length;i++){voices[i]=NewLane("Voice_"+i,35,5,AbbotAudioPolicy.VoiceMaximumDistance);SetVoiceRolloff(voices[i].source);}
            initialized=true;gate.Reset();bellGate.Reset();log?.Invoke("BA_AUDIO_ACTOR_READY dryVoices=2 bellLanes=lazy_room_owned bank="+bank.ManifestHash+" mixer="+mixer.name);
        }
        public void AttachRoom(Transform room,Vector3 bellContact)
        {
            if(roomSound)return;if(!Ready||!room||!AbbotAudioPolicy.Finite(bellContact.x)||!AbbotAudioPolicy.Finite(bellContact.y)||!AbbotAudioPolicy.Finite(bellContact.z))throw new InvalidOperationException("Own room acoustics requires a ready actor, room and great-bell anchor");
            roomBellPoint=bellContact;hasRoomBell=true;bellRoot=new GameObject("BA Abbot | room great-bell chimes");bellRoot.transform.SetParent(room,false);
            var go=new GameObject("BA Voice | geometry room field");go.transform.SetParent(audioRoot.transform,false);roomSound=go.AddComponent<AbbotRoomAcoustics>();roomSound.Initialize(room,head,mixer);
            log?.Invoke("BA_AUDIO_ROOM_READY acousticSources="+roomSound.GetComponentsInChildren<AudioSource>(true).Length+" coreSourceBudget="+AbbotAudioPolicy.MaximumSources+" bakedVoiceEcho=false");
        }
        Lane NewLane(string name,int priority,float minimum,float maximum,Transform parent=null)
        {
            var go=new GameObject("BA Audio | "+name);go.transform.SetParent(parent?parent:audioRoot.transform,false);var s=go.AddComponent<AudioSource>();
            s.playOnAwake=false;s.loop=false;s.spatialBlend=1;s.dopplerLevel=0;s.rolloffMode=AudioRolloffMode.Logarithmic;s.minDistance=minimum;s.maxDistance=maximum;
            s.pitch=1;s.volume=0;s.priority=priority;s.reverbZoneMix=0;s.outputAudioMixerGroup=mixer;return new Lane{source=s};
        }
        public static void SetVoiceRolloff(AudioSource source)
        {
            if(!source)return;source.rolloffMode=AudioRolloffMode.Custom;source.maxDistance=AbbotAudioPolicy.VoiceMaximumDistance;
            var points=new[]{new Keyframe(0,1),new Keyframe(.25f,1),new Keyframe(.5f,.85f),new Keyframe(.75f,.55f),new Keyframe(1,0)};
            for(int i=0;i<points.Length;i++)
            {
                if(i>0)points[i].inTangent=(points[i].value-points[i-1].value)/(points[i].time-points[i-1].time);
                if(i<points.Length-1)points[i].outTangent=(points[i+1].value-points[i].value)/(points[i+1].time-points[i].time);
            }
            source.SetCustomCurve(AudioSourceCurveType.CustomRolloff,new AnimationCurve(points));
        }
        public void Configure(bool enabled,float gain=1,float voiceGain=1)
        {
            mixEnabled=enabled;volume=AbbotAudioPolicy.Finite(gain)?Mathf.Clamp01(gain):0;this.voiceGain=AbbotAudioPolicy.Finite(voiceGain)?Mathf.Clamp01(voiceGain):0;
            if(roomSound)roomSound.Configure(enabled?volume*this.voiceGain:0);
            if(!enabled||volume<=0){StopVoice();StopFoley();}else if(this.voiceGain<=0)StopVoice();
        }
        Vector3 HeadPoint=>head?head.position:transform.position+Vector3.up*2.05f;
        void Position(Lane lane,bool voiceLane=false)
        {
            if(lane==null||!lane.source)return;lane.source.transform.position=lane.fixedPoint?lane.point:HeadPoint;
            float fade=1;if(lane.fadeEnd>0){fade=(float)Math.Max(0,Math.Min(1,(lane.fadeEnd-AudioSettings.dspTime)/(lane.fadeEnd-lane.fadeStart)));if(fade<=0)StopLane(lane);}
            lane.source.volume=mixEnabled?lane.baseGain*volume*(voiceLane?voiceGain:1)*fade:0;
        }
        void Update(){if(!Ready)return;foreach(var lane in voices)Position(lane,true);Position(greatBell);foreach(var lane in roomBells)Position(lane);foreach(var lane in foley)Position(lane);}
        public bool Play(string eventName,bool force=false,Vector3? worldPoint=null,double? occurredAtDsp=null)=>Request(eventName,AbbotAudioPolicy.DefaultPriority(eventName),worldPoint,force,double.PositiveInfinity,occurredAtDsp);
        // Starts immediately or reports a drop. No stale attack queues or random word cuts.
        public bool Request(string eventName,AbbotVoicePriority priority,Vector3? worldPoint=null,bool interrupt=false,double latestStartDsp=double.PositiveInfinity,double? occurredAtDsp=null)
        {
            double now=AudioSettings.dspTime;requested++;Increment(groupRequests,eventName??"<null>");
            if(!Ready||!mixEnabled||volume<=0)return Drop(eventName,"disabled_or_unready",now);
            if(AbbotGreatBellPolicy.Suppressed(eventName))return Drop(eventName,"personal_frame_removed",now);
            bool ordinaryBell=AbbotGreatBellPolicy.IsOrdinary(eventName),isBell=AbbotGreatBellPolicy.IsBell(eventName);
            if(isBell&&!hasRoomBell)return Drop(eventName,"missing_room_bell_anchor",now);
            bool isVoice=AbbotAudioPolicy.IsVoice(eventName),effort=AbbotAudioPolicy.IsEffort(eventName);
            double startsAt=isVoice&&roomSound?now+.060:now;
            if(double.IsNaN(latestStartDsp)||startsAt>latestStartDsp)return Drop(eventName,"expired_event",now);
            if(!Enum.IsDefined(typeof(AbbotVoicePriority),priority))return Drop(eventName,"invalid_priority",now);
            bool canInterrupt=interrupt&&(!isVoice||priority>=AbbotVoicePriority.Ritual);
            double eventTime=ordinaryBell?AbbotGreatBellPolicy.OccurredAt(now,occurredAtDsp):now;var eventGate=ordinaryBell?bellGate:gate;
            var reason=eventGate.Reason(eventName,eventTime,canInterrupt);if(reason!=null)return Drop(eventName,reason,now);
            if(isVoice&&voiceGain<=0)return Drop(eventName,"voice_muted",now);
            if(isVoice&&priority==AbbotVoicePriority.Attack)reactionBlockedUntil=Math.Max(reactionBlockedUntil,now+AbbotAudioPolicy.AttackReservationSeconds);
            Lane selected=null;
            if(isVoice)
            {
                for(int i=0;i<slots.Length;i++){var lane=voices[i];slots[i]=new AbbotAudioPolicy.VoiceSlot{endsAt=lane.endsAt,speechEndsAt=lane.speechEndsAt,spoken=lane.spoken,priority=lane.priority};}
                int index=AbbotAudioPolicy.SelectVoiceLane(now,priority,effort,canInterrupt,slots,reactionBlockedUntil,out reason);
                if(index<0)return Drop(eventName,reason,now);
                if(!canInterrupt&&now<VoiceAvailableAtDsp)return Drop(eventName,"word_gap",now);
                if(canInterrupt)
                {
                    index=now>=voices[0].endsAt?0:now>=voices[1].endsAt?1:voices[0].endsAt<voices[1].endsAt?0:1;
                    FadeVoice(now);
                }
                selected=voices[index];
                if(now<selected.endsAt)tailRecycles++;
            }
            else if(eventName=="greatBell")
            {
                if(greatBell==null)greatBell=NewLane("Greatbell_ritual",45,16,80,bellRoot.transform);
                if(now<greatBell.endsAt&&!canInterrupt)return Drop(eventName,"great_bell_busy",now);selected=greatBell;
            }
            else if(ordinaryBell)
            {
                for(int i=0;i<roomBells.Length;i++)bellEnds[i]=roomBells[i]?.endsAt??0;
                int index=AbbotGreatBellPolicy.SelectOrdinaryLane(now,bellEnds);
                if(roomBells[index]==null)roomBells[index]=NewLane("Greatbell_chime_"+index,90,16,80,bellRoot.transform);
                selected=roomBells[index];if(now<selected.endsAt)bellTailRecycles++;
            }
            else
            {
                for(int i=0;i<foley.Length;i++)if(foley[i]==null||now>=foley[i].endsAt){if(foley[i]==null)foley[i]=NewLane("Foley_"+i,120,3,40);selected=foley[i];break;}
                if(selected==null)return Drop(eventName,"foley_lanes_busy",now);
            }
            previous.TryGetValue(eventName,out var last);var cue=bank.Pick(AbbotGreatBellPolicy.CueGroup(eventName),random,last);if(cue==null||!cue.Clip||!selected.source)return Drop(eventName,"missing_cue_or_lane",now);
            selected.source.Stop();selected.source.clip=cue.Clip;selected.source.pitch=1;selected.source.loop=false;
            var captured=AbbotGreatBellPolicy.CapturePoint(eventName,hasRoomBell?(AbbotGreatBellPolicy.Point?)new AbbotGreatBellPolicy.Point(roomBellPoint.x,roomBellPoint.y,roomBellPoint.z):null,new AbbotGreatBellPolicy.Point(HeadPoint.x,HeadPoint.y,HeadPoint.z),worldPoint.HasValue?(AbbotGreatBellPolicy.Point?)new AbbotGreatBellPolicy.Point(worldPoint.Value.x,worldPoint.Value.y,worldPoint.Value.z):null);
            selected.fixedPoint=isBell||worldPoint.HasValue;selected.point=new Vector3((float)captured.X,(float)captured.Y,(float)captured.Z);
            selected.group=eventName;selected.cue=cue.id;selected.baseGain=cue.gain*(ordinaryBell?AbbotGreatBellPolicy.OrdinaryBellGain:1);selected.endsAt=startsAt+cue.Clip.length+.035;
            selected.spoken=isVoice&&!effort;selected.speechEndsAt=selected.spoken?startsAt+cue.speechSeconds+.035:0;selected.priority=priority;selected.fadeStart=selected.fadeEnd=0;
            Position(selected,isVoice);
            if(isVoice&&roomSound){roomSound.Begin(Array.IndexOf(voices,selected),cue.Samples,startsAt,cue.gain);selected.source.PlayScheduled(startsAt);}else selected.source.Play();
            previous[eventName]=cue.id;eventGate.Commit(eventName,eventTime);
            if(AbbotAudioPolicy.IsOpening(eventName))
            {
                OpeningCue=cue.id;
                log?.Invoke("BA_AUDIO_OPENING_COMMIT group="+eventName+" take="+cue.id+" actor="+GetInstanceID());
            }
            if(isVoice)
            {
                LastVoiceId=cue.id;if(eventName=="death")DeathVoiceEndsAtDsp=selected.endsAt+(roomSound?RoomAcousticPlan.TailSeconds:0);
                if(!effort&&!canInterrupt)foreach(var other in voices)if(other!=selected&&!other.spoken&&now<other.endsAt){other.fadeStart=now;other.fadeEnd=now+.16;if(roomSound)roomSound.FadeLane(Array.IndexOf(voices,other),now,.16);}
                // Speech and effort leave the ongoing music gain and playback untouched.
            }
            else if(AbbotGreatBellPolicy.DucksMusic(eventName))InvokeDuck(.12f,3.2f);
            played++;Increment(groupCommands,eventName);Increment(cueCommands,cue.id);LastDropReason=null;
            log?.Invoke("BA_AUDIO_PLAY event="+eventName+" take="+cue.id+" speech="+cue.speechSeconds.ToString("F2")+" full="+cue.duration.ToString("F2")+" priority="+priority);
            try{EventPlayed?.Invoke(eventName,cue.id,cue.Clip.length);}catch(Exception error){log?.Invoke("BA_AUDIO_EVENT_OBSERVER_FAILED "+error.Message);}return true;
        }
        bool Drop(string group,string reason,double now)
        {
            group=group??"<null>";dropped++;LastDropReason=reason;Increment(groupDrops,group);Increment(dropReasons,reason);
            if(group=="death")DeathVoiceEndsAtDsp=now;
            log?.Invoke("BA_AUDIO_DROP event="+group+" reason="+reason);
            try{EventDropped?.Invoke(group,reason);}catch(Exception error){log?.Invoke("BA_AUDIO_DROP_OBSERVER_FAILED "+error.Message);}return false;
        }
        void InvokeDuck(float value,float seconds){try{DuckRequested?.Invoke(value,seconds);}catch(Exception error){log?.Invoke("BA_AUDIO_DUCK_OBSERVER_FAILED "+error.Message);}}
        static void Increment(Dictionary<string,int> rows,string key){rows.TryGetValue(key,out var n);rows[key]=n+1;}
        static void StopLane(Lane lane){if(lane==null)return;if(lane.source)lane.source.Stop();lane.endsAt=lane.speechEndsAt=lane.fadeStart=lane.fadeEnd=0;}
        void FadeVoice(double now){foreach(var lane in voices)if(lane!=null&&now<lane.endsAt){lane.spoken=false;lane.speechEndsAt=0;lane.fadeStart=now;lane.fadeEnd=now+.04;lane.endsAt=lane.fadeEnd;if(roomSound)roomSound.FadeLane(Array.IndexOf(voices,lane),now,.04);}}
        public void StopVoice(){foreach(var lane in voices)StopLane(lane);if(roomSound)roomSound.StopInputs();if(DeathVoiceEndsAtDsp>AudioSettings.dspTime)DeathVoiceEndsAtDsp=AudioSettings.dspTime;}
        public void StopFoley(){StopBellLanes();foreach(var lane in foley)StopLane(lane);}
        void StopBellLanes(){StopLane(greatBell);foreach(var lane in roomBells)StopLane(lane);}
        public void FinishBellTails()
        {
            if(!Ready||!bellRoot)return;double end=GreatBellEndsAtDsp;foreach(var lane in roomBells)if(lane!=null)end=Math.Max(end,lane.endsAt);
            if(end<=AudioSettings.dspTime)return;preserveBellTails=true;AbbotBellTailLifetime.Arm(bellRoot,end);
        }
        public Telemetry Snapshot()=>new Telemetry{ready=Ready,enabled=mixEnabled,released=released,voiceBusy=VoiceBusy,
            allocatedSources=(audioRoot?audioRoot.GetComponentsInChildren<AudioSource>(true).Length:0)+(bellRoot?bellRoot.GetComponentsInChildren<AudioSource>(true).Length:0),played=played,dropped=dropped,requested=requested,tailRecycles=tailRecycles,bellTailRecycles=bellTailRecycles,
            coreAllocatedSources=(audioRoot?audioRoot.GetComponentsInChildren<AudioSource>(true).Length:0)+(bellRoot?bellRoot.GetComponentsInChildren<AudioSource>(true).Length:0)-(roomSound?roomSound.GetComponentsInChildren<AudioSource>(true).Length:0),coreSourceBudget=AbbotAudioPolicy.MaximumSources,roomAcousticSources=roomSound?roomSound.GetComponentsInChildren<AudioSource>(true).Length:0,
            voiceEndsAtDsp=VoiceEndsAtDsp,wordsEndAtDsp=WordsEndAtDsp,deathVoiceEndsAtDsp=DeathVoiceEndsAtDsp,lastVoiceId=LastVoiceId,voiceGain=voiceGain,mixerName=mixer?mixer.name:null,failure=Failure,lastDropReason=LastDropReason,openingGroup=gate.OpeningGroup,openingCue=OpeningCue,
            groupCommands=new Dictionary<string,int>(groupCommands),cueCommands=new Dictionary<string,int>(cueCommands),groupRequests=new Dictionary<string,int>(groupRequests),groupDrops=new Dictionary<string,int>(groupDrops),dropReasons=new Dictionary<string,int>(dropReasons)};
        public void Release(){if(released)return;StopVoice();foreach(var lane in foley)StopLane(lane);if(!preserveBellTails){StopBellLanes();if(bellRoot)Destroy(bellRoot);}bellRoot=null;released=true;initialized=false;gate.Reset();bellGate.Reset();OpeningCue=null;reactionBlockedUntil=0;hasRoomBell=false;if(audioRoot)Destroy(audioRoot);audioRoot=null;}
        void OnDisable()=>Release();void OnDestroy()=>Release();
    }
}
