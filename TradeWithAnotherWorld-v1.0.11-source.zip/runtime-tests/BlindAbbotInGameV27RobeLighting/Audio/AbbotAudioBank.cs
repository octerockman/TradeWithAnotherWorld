using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbey.BlindAbbot
{
    // Synchronous main-thread prewarm before encounter creation. No gameplay loads.
    public sealed class AbbotAudioBank:IDisposable
    {
        public sealed class ClipRecord
        {
            public string id,category,path,sha256,lineId,text;
            public int frames,sampleRate,channels,bits,take;
            public double duration,speechSeconds;
            public bool loop;
            public float gain,pitchMin=1,pitchMax=1,runtimeGain=1;
            [JsonIgnore]public float PlaybackPeak;
            [JsonIgnore]public AudioClip Clip;
            [JsonIgnore]public float[] Samples;
        }
#pragma warning disable 0649 // Populated by the bounded JSON manifest reader.
        sealed class Manifest { public string schema;public ClipRecord[] clips;public Dictionary<string,string[]> groups; }
#pragma warning restore 0649
        static readonly Dictionary<string,AbbotAudioBank> Cache=new Dictionary<string,AbbotAudioBank>(StringComparer.OrdinalIgnoreCase);
        readonly Dictionary<string,ClipRecord> clips=new Dictionary<string,ClipRecord>(StringComparer.Ordinal);
        readonly Dictionary<string,ClipRecord[]> groups=new Dictionary<string,ClipRecord[]>(StringComparer.Ordinal);
        public bool Ready {get;private set;}
        public string Failure {get;private set;}
        public string ManifestHash {get;private set;}
        public int ClipCount=>clips.Count;
        public long DecodedFrames {get;private set;}
        public long PcmBytes {get;private set;}
        bool disposed;
        public static AbbotAudioBank Initialize(string manifestPath,Action<string> log=null)
        {
            AbbotAudioBank bank;
            try
            {
                string path=Path.GetFullPath(manifestPath);
                if(Cache.TryGetValue(path,out bank)&&bank.Ready&&!bank.disposed)return bank;
                bank?.Dispose();bank=new AbbotAudioBank();
                try{bank.Load(path);Cache[path]=bank;log?.Invoke("BA_AUDIO_BANK_READY clips="+bank.ClipCount+" pcmBytes="+bank.PcmBytes+" manifest="+bank.ManifestHash);}
                catch(Exception error){bank.Clear();bank.Failure=error.Message;log?.Invoke("BA_AUDIO_BANK_UNAVAILABLE "+error);}
                return bank;
            }
            catch(Exception error){bank=new AbbotAudioBank();bank.Failure=error.Message;log?.Invoke("BA_AUDIO_BANK_UNAVAILABLE "+error.Message);return bank;}
        }
        void Load(string path)
        {
            if(new FileInfo(path).Length>512*1024)throw new InvalidDataException("Oversized Abbot audio manifest.");
            var raw=File.ReadAllBytes(path);ManifestHash=Hash(raw);
            var m=JsonConvert.DeserializeObject<Manifest>(Encoding.UTF8.GetString(raw).TrimStart('\ufeff'));
            if(m==null||m.schema!="blind-abbot.audio-bank.v3-dry"||m.clips==null||m.clips.Length!=50||m.groups==null||m.groups.Count!=AbbotAudioPolicy.RequiredGroups.Length)
                throw new InvalidDataException("Requires checked50-cue Abbot bank and20event groups.");
            var directory=Path.GetDirectoryName(path);
            foreach(var r in m.clips)
            {
                if(r==null||string.IsNullOrWhiteSpace(r.id)||clips.ContainsKey(r.id)||
                   (r.category!="voice"&&r.category!="bell"&&r.category!="foley")||string.IsNullOrEmpty(r.path)||Path.GetFileName(r.path)!=r.path||r.path.Contains("..")||Path.IsPathRooted(r.path)||
                   !r.path.EndsWith(".wav",StringComparison.OrdinalIgnoreCase)||!ValidHash(r.sha256)||r.sampleRate!=48000||r.channels!=1||r.bits!=16||r.frames<=0||r.frames>48000*30||r.loop||
                   !AbbotAudioPolicy.Finite(r.gain)||r.gain<0||r.gain>1||!AbbotAudioPolicy.Finite(r.runtimeGain)||r.runtimeGain<.5f||r.runtimeGain>2.819f||
                   r.pitchMin!=1||r.pitchMax!=1||double.IsNaN(r.duration)||double.IsInfinity(r.duration)||Math.Abs(r.duration-r.frames/48000d)>.001||
                   double.IsNaN(r.speechSeconds)||double.IsInfinity(r.speechSeconds)||r.speechSeconds<=0||r.speechSeconds>r.duration||
                   r.runtimeGain!=1||Math.Abs(r.speechSeconds-r.duration)>.001)
                    throw new InvalidDataException("Invalid Abbot cue: "+r?.id);
                var full=Path.Combine(directory,r.path);
                if((File.GetAttributes(full)&FileAttributes.ReparsePoint)!=0||new FileInfo(full).Length>4*1024*1024)throw new InvalidDataException("Invalid Abbot audio dependency.");
                var bytes=File.ReadAllBytes(full);PcmBytes+=bytes.Length;
                if(PcmBytes>48*1024*1024||!string.Equals(Hash(bytes),r.sha256,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("Abbot bank budget/hash mismatch: "+r.id);
                var samples=DecodePcm16(bytes,r.frames);
                for(int i=0;i<samples.Length;i++){samples[i]*=r.runtimeGain;r.PlaybackPeak=Math.Max(r.PlaybackPeak,Math.Abs(samples[i]));}
                if(r.category=="voice"&&r.PlaybackPeak>.65001f)throw new InvalidDataException("Abbot voice gain exceeds checked headroom: "+r.id);
                var clip=AudioClip.Create("BA Own | "+r.id,samples.Length,1,48000,false);
                if(!clip||!clip.SetData(samples,0)){if(clip)Object.Destroy(clip);throw new InvalidDataException("AudioClip rejected: "+r.id);}
                r.Clip=clip;r.Samples=samples;clips.Add(r.id,r);DecodedFrames+=samples.Length;
            }
            var used=new HashSet<string>(StringComparer.Ordinal);int voices=0;
            foreach(var r in clips.Values)if(r.category=="voice")voices++;
            if(voices!=46)throw new InvalidDataException("The bank must retain all46starred voice takes.");
            foreach(var key in AbbotAudioPolicy.RequiredGroups)
            {
                if(!m.groups.TryGetValue(key,out var ids)||ids==null||ids.Length==0)throw new InvalidDataException("Missing Abbot cue group: "+key);
                var records=new ClipRecord[ids.Length];var unique=new HashSet<string>(StringComparer.Ordinal);
                for(int i=0;i<ids.Length;i++)
                {
                    if(!unique.Add(ids[i])||!clips.TryGetValue(ids[i],out records[i])||AbbotAudioPolicy.IsVoice(key)!=(records[i].category=="voice"))throw new InvalidDataException("Bad Abbot event reference: "+key);
                    used.Add(ids[i]);
                }
                groups.Add(key,records);
            }
            if(used.Count!=clips.Count)throw new InvalidDataException("Unreferenced Abbot cue.");
            Ready=true;
        }
        public ClipRecord Pick(string group,System.Random random,string previousId=null)
        {
            if(!Ready||disposed||!groups.TryGetValue(group,out var rows))return null;
            if(rows.Length==1)return rows[0];int index=random.Next(rows.Length);
            if(rows[index].id==previousId)index=(index+1+random.Next(rows.Length-1))%rows.Length;
            return rows[index];
        }
        public string[] GetGroupIds(string name)
        {
            if(!groups.TryGetValue(name,out var rows))return new string[0];var ids=new string[rows.Length];for(int i=0;i<ids.Length;i++)ids[i]=rows[i].id;return ids;
        }
        public static float[] DecodePcm16(byte[] bytes,int expectedFrames)
        {
            if(bytes==null||bytes.Length<44||bytes.Length>4*1024*1024||!Tag(bytes,0,"RIFF")||!Tag(bytes,8,"WAVE")||U32(bytes,4)+8L!=bytes.Length)throw new InvalidDataException("Invalid Abbot RIFF envelope.");
            bool format=false,data=false;int start=0,count=0;
            for(long at=12;at<bytes.Length;)
            {
                if(at+8>bytes.Length)throw new InvalidDataException("Truncated Abbot WAV.");
                int p=(int)at;uint length=U32(bytes,p+4);long end=at+8+length,padded=end+(length&1);
                if(padded>bytes.Length)throw new InvalidDataException("WAV chunk outside RIFF.");
                if(Tag(bytes,p,"fmt "))
                {
                    if(format||(length!=16&&length!=18)||U16(bytes,p+8)!=1||U16(bytes,p+10)!=1||U32(bytes,p+12)!=48000||U32(bytes,p+16)!=96000||U16(bytes,p+20)!=2||U16(bytes,p+22)!=16)throw new InvalidDataException("Requires mono48k PCM16.");
                    format=true;
                }
                if(Tag(bytes,p,"data")){if(data||length==0||length%2!=0||length/2!=expectedFrames)throw new InvalidDataException("Abbot PCM frames differ.");data=true;start=p+8;count=(int)length/2;}
                at=padded;
            }
            if(!format||!data)throw new InvalidDataException("Missing Abbot PCM format/data.");
            var samples=new float[count];double energy=0;
            for(int i=0;i<count;i++){short value=(short)U16(bytes,start+i*2);if(value==short.MinValue||value==short.MaxValue)throw new InvalidDataException("Fullscale Abbot PCM.");samples[i]=value/32768f;energy+=samples[i]*samples[i];}
            if(energy<1e-12)throw new InvalidDataException("Silent Abbot cue.");return samples;
        }
        static bool Tag(byte[] b,int p,string s){if(p<0||p+s.Length>b.Length)return false;for(int i=0;i<s.Length;i++)if(b[p+i]!=s[i])return false;return true;}
        static uint U32(byte[] b,int p)=>(uint)(b[p]|b[p+1]<<8|b[p+2]<<16|b[p+3]<<24);
        static int U16(byte[] b,int p)=>b[p]|b[p+1]<<8;
        static bool ValidHash(string x){if(x==null||x.Length!=64)return false;foreach(char c in x)if(!Uri.IsHexDigit(c))return false;return true;}
        static string Hash(byte[] bytes){using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(bytes)).Replace("-","").ToLowerInvariant();}
        void Clear(){Ready=false;foreach(var r in clips.Values)if(r.Clip)Object.Destroy(r.Clip);clips.Clear();groups.Clear();}
        public void Dispose(){if(disposed)return;disposed=true;Clear();}
        public static void Shutdown(){foreach(var bank in Cache.Values)bank.Dispose();Cache.Clear();}
    }
}
