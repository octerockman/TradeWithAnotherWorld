using System;

namespace BlackAbbey.BlindAbbot
{
    // Used by the real audio controller. Logical triggers retain their own
    // timing/priority; both bell categories select the deep room-bell cue.
    public static class AbbotGreatBellPolicy
    {
        public const int MaximumOrdinaryBellLanes=6;
        public const float OrdinaryBellGain=.6f;
        public struct Point
        {
            public double X,Y,Z;
            public Point(double x,double y,double z){X=x;Y=y;Z=z;}
        }
        public static bool IsBell(string logicalEvent)=>logicalEvent=="carriedBell"||logicalEvent=="greatBell";
        public static bool IsOrdinary(string logicalEvent)=>logicalEvent=="carriedBell";
        public static bool Suppressed(string logicalEvent)=>logicalEvent=="frameCreak";
        public static string CueGroup(string logicalEvent)=>IsBell(logicalEvent)?"greatBell":logicalEvent;
        public static bool DucksMusic(string logicalEvent)=>logicalEvent=="greatBell";
        public static bool IsInvocationSourceEvent(string kind)=>kind=="bellPulse"||kind=="cast"||kind=="listenReveal";
        public static Point CapturePoint(string logicalEvent,Point? roomBell,Point actorHead,Point? requestedPoint)
        {
            if(IsBell(logicalEvent))return roomBell??throw new InvalidOperationException("No room great-bell anchor");
            return requestedPoint??actorHead;
        }
        // Free lane first; if saturated recycle only the oldest ordinary bell
        // tail. New onsets are never dropped behind a long cathedral decay.
        public static int SelectOrdinaryLane(double now,double[] ends)
        {
            if(!Finite(now)||ends==null||ends.Length!=MaximumOrdinaryBellLanes)throw new ArgumentException("Invalid bell-lane clock/inventory");
            int oldest=0;for(int i=0;i<ends.Length;i++){if(!Finite(ends[i]))throw new ArgumentException("Nonfinite bell tail");if(now>=ends[i])return i;if(ends[i]<ends[oldest])oldest=i;}return oldest;
        }
        public static double OccurredAt(double now,double? authored)
        {
            if(!Finite(now)||authored.HasValue&&!Finite(authored.Value))throw new ArgumentException("Invalid bell event clock");
            return authored.HasValue?Math.Max(0,Math.Min(now,authored.Value)):now;
        }
        public static double DetachedTailDeadline(double now,double end)
        {
            if(!Finite(now)||!Finite(end))throw new ArgumentException("Invalid bell-tail deadline");return Math.Min(now+30,Math.Max(now,end));
        }
        static bool Finite(double x)=>!double.IsNaN(x)&&!double.IsInfinity(x);
    }
}
