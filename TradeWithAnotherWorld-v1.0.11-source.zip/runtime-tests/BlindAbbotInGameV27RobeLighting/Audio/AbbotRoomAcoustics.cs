using System;
using System.Threading;
using UnityEngine;
using UnityEngine.Audio;

namespace BlackAbbey.BlindAbbot
{
    // Separate wet emitter lets reflections decay after a dry line is stopped.
    // Only this owned boss voice is affected; native SFX/Master routing is retained.
    public sealed class AbbotRoomAcoustics : MonoBehaviour
    {
        Transform room,head;AudioSource source;AudioClip silence;AbbotRoomSoundProcessor processor;
        sealed class RenderBinding{public readonly RoomSoundState State;public readonly AbbotRoomSoundProcessor Processor;public readonly int Rate;public RenderBinding(RoomSoundState state,AbbotRoomSoundProcessor processor,int rate){State=state;Processor=processor;Rate=rate;}}
        RenderBinding binding;RoomAcousticPlan plan;readonly RoomVoiceStream[] streams=new RoomVoiceStream[2];
        readonly RaycastHit[] hits=new RaycastHit[96];int rate,generation,livePlanes;float nextProbe;double tailUntil;float gain=1;
        static readonly string[] Families={"wall_and_piers","vault_and_upperwall","floor_and_dais","choir_stone","delta_masonry","hall_masonry","boss_door","glass_story"};
        static readonly Vector3[] Directions={Vector3.left,Vector3.right,Vector3.back,Vector3.forward,Vector3.down,Vector3.up};
        public double TailUntil=>tailUntil;
        public int MeasuredPlanes=>livePlanes;
        public bool Ready=>processor!=null&&source&&room&&head;
        public void Initialize(Transform ownerRoom,Transform mouth,AudioMixerGroup mixer)
        {
            room=ownerRoom;head=mouth;rate=AudioSettings.outputSampleRate;if(rate<22050)rate=48000;
            processor=new AbbotRoomSoundProcessor(rate);source=gameObject.AddComponent<AudioSource>();source.playOnAwake=false;source.loop=true;
            source.spatialBlend=0;source.dopplerLevel=0;source.reverbZoneMix=0;source.priority=75;source.volume=1;source.outputAudioMixerGroup=mixer;
            silence=AudioClip.Create("BA voice room clock | silent stereo",rate,2,rate,false);source.clip=silence;Refresh();
            AudioSettings.OnAudioConfigurationChanged+=ConfigurationChanged;
        }
        void ConfigurationChanged(bool deviceChanged)
        {
            int currentRate=AudioSettings.outputSampleRate;if(currentRate<22050)return;
            // Native dry sources own their playback. Restart only the wet field;
            // never replay an old line after a device or DSP-clock reset.
            if(source)source.Stop();for(int i=0;i<2;i++)streams[i]=null;tailUntil=0;generation++;rate=currentRate;
            processor=new AbbotRoomSoundProcessor(rate);var old=silence;silence=AudioClip.Create("BA voice room clock | silent stereo",rate,2,rate,false);if(source)source.clip=silence;if(old)Destroy(old);Refresh();
        }
        public void Configure(float value){gain=Mathf.Clamp01(value);Publish();}
        public void Begin(int lane,float[] samples,double startDsp,float cueGain)
        {
            if(!Ready||lane<0||lane>=2||samples==null)throw new InvalidOperationException("Room voice not ready");
            if(!source.isPlaying){generation++;source.PlayScheduled(Math.Max(AudioSettings.dspTime+.005,startDsp-.025));}
            streams[lane]=new RoomVoiceStream(samples,(long)Math.Round(startDsp*rate),cueGain);
            tailUntil=Math.Max(tailUntil,startDsp+samples.Length/48000.0+RoomAcousticPlan.TailSeconds);Refresh();
        }
        public void StopInputs()
        {
            long at=(long)Math.Round(AudioSettings.dspTime*rate);
            for(int i=0;i<2;i++)if(streams[i]!=null)streams[i]=streams[i].Stop(at);
            tailUntil=Math.Min(tailUntil,AudioSettings.dspTime+RoomAcousticPlan.TailSeconds);Publish();
        }
        public void FadeLane(int lane,double atDsp,double seconds)
        {
            if(lane<0||lane>=2||streams[lane]==null)return;
            streams[lane]=streams[lane].Fade((long)Math.Round(atDsp*rate),(long)Math.Round((atDsp+seconds)*rate));Publish();
        }
        void Update()
        {
            if(!Ready)return;
            if(Time.unscaledTime>=nextProbe){nextProbe=Time.unscaledTime+.25f;Refresh();}
            if(source.isPlaying&&AudioSettings.dspTime>tailUntil){source.Stop();for(int i=0;i<2;i++)streams[i]=null;Publish();}
        }
        static RoomVector V(Vector3 p)=>new RoomVector(p.x,p.y,p.z);
        void Refresh()
        {
            if(!room||!head)return;var camera=Camera.main;
            Vector3 ear=camera?camera.transform.position:head.position+room.forward*10;
            Vector3 right=camera?camera.transform.right:room.right;
            var planes=RoomAcousticPlan.FallbackPlanes();livePlanes=0;int layer=LayerMask.NameToLayer("static_solid");
            if(layer>=0)for(int i=0;i<6;i++)
            {
                var direction=room.TransformDirection(Directions[i]);int n=Physics.RaycastNonAlloc(head.position,direction,hits,48,1<<layer,QueryTriggerInteraction.Ignore);float nearest=49;RaycastHit chosen=new RaycastHit();
                for(int j=0;j<n;j++)
                {
                    var h=hits[j];if(!h.collider||!h.collider.transform.IsChildOf(room)||h.distance>=nearest||!Architecture(h.collider.name))continue;
                    chosen=h;nearest=h.distance;
                }
                if(nearest>48)continue;
                var point=room.InverseTransformPoint(chosen.point);var normal=room.InverseTransformDirection(chosen.normal).normalized;
                var mouth=room.InverseTransformPoint(head.position);if(Vector3.Dot(mouth-point,normal)<0)normal=-normal;
                planes[i]=new RoomPlane(V(point),V(normal),i==4?.58:.68);livePlanes++;
            }
            var localEar=room.InverseTransformPoint(ear);
            plan=RoomAcousticPlan.Build(V(room.InverseTransformPoint(head.position)),V(localEar),V(room.InverseTransformDirection(right)),planes);
            inside=localEar.x>=-14&&localEar.x<=14&&localEar.y>=-.5&&localEar.y<=17&&localEar.z>=-.5&&localEar.z<=33;Publish();
        }
        bool inside=true;
        static bool Architecture(string name){if(string.IsNullOrEmpty(name)||!name.StartsWith("Collider | collision_",StringComparison.Ordinal))return false;foreach(var family in Families)if(name.IndexOf("collision_"+family,StringComparison.Ordinal)>=0)return true;return false;}
        void Publish(){if(plan==null||processor==null)return;Volatile.Write(ref binding,new RenderBinding(new RoomSoundState(plan,new[]{streams[0],streams[1]},inside?gain:0,generation),processor,rate));}
        void OnAudioFilterRead(float[] data,int channels)
        {
            var current=Volatile.Read(ref binding);if(current==null){Array.Clear(data,0,data.Length);return;}
            current.Processor.Render(data,channels,(long)Math.Round(AudioSettings.dspTime*current.Rate),current.State);
        }
        void OnDestroy(){AudioSettings.OnAudioConfigurationChanged-=ConfigurationChanged;if(source)source.Stop();if(silence)Destroy(silence);Volatile.Write(ref binding,null);processor=null;}
    }
}
