using System;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbey.BlindAbbot
{
    // Added only after this module's encounter/health owner binds. Ordinary
    // Skeletons, players and remote peers never receive a posture override.
    public sealed class AbbotPoiseProfile : MonoBehaviour
    {
        Character actor;
        AbbotHealthGuard health;
        public bool Authoritative=>actor&&enabled&&health&&health.Authoritative;
        public static AbbotPoiseProfile Configure(Humanoid ownActor)
        {
            if(!ownActor)throw new ArgumentNullException(nameof(ownActor));
            var profile=ownActor.GetComponent<AbbotPoiseProfile>();
            if(!profile){profile=ownActor.gameObject.AddComponent<AbbotPoiseProfile>();profile.Bind(ownActor);}
            else profile.Refresh();
            return profile;
        }
        public void Bind(Character ownActor)
        {
            if(actor||!ownActor||ownActor.gameObject!=gameObject)throw new InvalidOperationException("Bind one own Abbot posture profile");
            var guard=ownActor.GetComponent<AbbotHealthGuard>();
            if(!guard||!guard.Authoritative||!ownActor.GetComponent<AbbotEncounterController>())throw new InvalidOperationException("Abbot posture requires its bound native encounter owner");
            actor=ownActor;health=guard;Refresh();
        }
        public void Refresh()
        {
            if(!Authoritative)return;
            double factor=AbbotPoisePolicy.Factor(actor.GetMaxHealth());
            if(!double.IsNaN(factor)&&!double.IsInfinity(factor)&&factor>0&&factor<=float.MaxValue)actor.m_staggerDamageFactor=(float)factor;
        }
        static AbbotPoiseProfile Own(Character actor)=>actor?actor.GetComponent<AbbotPoiseProfile>():null;
        [HarmonyPatch(typeof(Character),"AddStaggerDamage")]
        static class AddStaggerDamagePatch
        {
            // Keep the actual native accumulator, received stagger multiplier,
            // status modifiers, decay, pushback and reward path unchanged.
            [HarmonyPrefix,HarmonyPriority(Priority.First)]
            static void Prefix(Character __instance){Own(__instance)?.Refresh();}
        }
        [HarmonyPatch(typeof(Character),nameof(Character.SetMaxHealth))]
        static class MaximumHealthPatch
        {
            [HarmonyPostfix]
            static void Postfix(Character __instance){Own(__instance)?.Refresh();}
        }
    }
}
