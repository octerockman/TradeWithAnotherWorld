using System;
using System.Collections.Generic;

namespace BlackAbbey.BlindAbbot
{
    public enum AbbotPhase { Waiting, Service, Fracture, Ritual, LastToll, Dying, Defeated, Cancelled }
    public enum AbbotMove { None, Slam, Sweep, Pulse, Rupture, Listen, TripleToll }
    public enum AbbotRitualStep { Kneel, Rise, Stumble, Strike, Wave, Refill }
    public sealed class AbbotMoveSpec
    {
        public AbbotMove Move; public string Motion, Voice;
        public float Duration, HitAt, Recovery, Range, Arc, Blunt, Spirit, Push;
    }
    // This policy is used by the live controller and the offline boundary tests.
    public static class AbbotEncounterPolicy
    {
        public const float BodyScale=1.2f, BodyHeight=3f, StaffHeightFraction=1.76334f;
        public const float CapsuleHeight=3f,CapsuleRadius=.50f,CapsuleCenterY=1.5f;
        // Full source reference-motion arc * exact fitted-body scale. Actor
        // travel remains code-owned; no extracted displacement is added twice.
        public const float WalkSpeed=2.2f,StumbleSpeed=1.5f,WalkStride=4.006633f,StumbleStride=4.006633f;
        public const float RitualX=0,RitualY=.025f,RitualZ=25.5f;
        public const float SlamRange=3f,SweepRange=3.25f;
        public static bool NearSpawn(float x,float y,float z)=>Math.Abs(x)<=20&&y>=-3&&y<=8&&z>=-18&&z<=40;
        public const float FractureFraction=.7f, RitualFloor=.1f, FinalFraction=.4f;
        public const float RitualKneelSeconds=5f, RitualRiseSeconds=2f;
        // Ceremony strike duration/contact now come from the source/FK plan.
        public const float RitualWaveSeconds=4.2f, RitualRefillSeconds=1.4f;
        public static AbbotPhase CombatPhase(float fraction,bool finalBar) => finalBar?AbbotPhase.LastToll:fraction<=FractureFraction?AbbotPhase.Fracture:AbbotPhase.Service;
        public static AbbotMoveSpec Spec(AbbotMove move)
        {
            switch(move){
                case AbbotMove.Slam:return new AbbotMoveSpec{Move=move,Motion="staff_slam",Voice="staffSlam",Duration=2.45f,HitAt=1.52f,Recovery=1.45f,Range=SlamRange,Arc=48,Blunt=70,Spirit=8,Push=40};
                case AbbotMove.Sweep:return new AbbotMoveSpec{Move=move,Motion="staff_sweep",Voice="staffSweep",Duration=2.10f,HitAt=1.22f,Recovery=1.15f,Range=SweepRange,Arc=155,Blunt=46,Spirit=6,Push=30};
                case AbbotMove.Pulse:return new AbbotMoveSpec{Move=move,Motion="bell_brace",Voice="bellWarning",Duration=3.35f,HitAt=1.7f,Recovery=1.4f,Range=14,Arc=360,Blunt=32,Spirit=15,Push=25};
                case AbbotMove.Rupture:return new AbbotMoveSpec{Move=move,Motion="bell_brace",Voice="bellAttack",Duration=3.8f,HitAt=1.8f,Recovery=1.45f,Range=16,Arc=44,Blunt=40,Spirit=12,Push=18};
                case AbbotMove.Listen:return new AbbotMoveSpec{Move=move,Motion="listen",Voice="listen",Duration=3.5f,HitAt=2.8f,Recovery=.6f,Range=40};
                case AbbotMove.TripleToll:return new AbbotMoveSpec{Move=move,Motion="bell_brace",Voice="bellAttack",Duration=5.8f,HitAt=1.8f,Recovery=2.5f,Range=17,Arc=360,Blunt=25,Spirit=13,Push=20};
                default:throw new ArgumentOutOfRangeException(nameof(move));
            }
        }
        public static bool Allowed(AbbotPhase phase,AbbotMove move)
        {
            if(phase!=AbbotPhase.Service&&phase!=AbbotPhase.Fracture&&phase!=AbbotPhase.LastToll)return false;
            if(move==AbbotMove.None)return false;
            if(move==AbbotMove.TripleToll)return phase==AbbotPhase.LastToll;
            if(move==AbbotMove.Rupture)return phase!=AbbotPhase.Service;
            return true;
        }
        public static AbbotMove Choose(AbbotPhase phase,float distance,bool heard,AbbotMove previous,Random random)
        {
            var choices=new List<AbbotMove>();
            if(distance<=SlamRange&&heard){choices.Add(AbbotMove.Slam);choices.Add(AbbotMove.Slam);}
            if(distance<=SweepRange&&heard){choices.Add(AbbotMove.Sweep);choices.Add(AbbotMove.Sweep);}
            if(distance<=16){choices.Add(AbbotMove.Pulse);if(phase!=AbbotPhase.Service)choices.Add(AbbotMove.Rupture);if(phase==AbbotPhase.LastToll)choices.Add(AbbotMove.TripleToll);}
            if(!heard||choices.Count==0)choices.Add(AbbotMove.Listen);
            if(choices.Count>1)choices.RemoveAll(x=>x==previous);
            return choices[random.Next(choices.Count)];
        }
        public static bool Crossing(float previousRadius,float radius,float distance,float band=.6f) => distance>=previousRadius-band&&distance<=radius+band;
        public static float RitualRadius(float elapsed) => Math.Max(0,Math.Min(1,elapsed/RitualWaveSeconds))*44;
        public static float BellDegrees(float elapsed)
        {
            if(elapsed<0||elapsed>=12)return 0;
            return (float)(3*Math.Sin(elapsed*3.4)*Math.Exp(-elapsed*.32));
        }
        public static bool WithinArena(float x,float y,float z) => Math.Abs(x)<=12.4f&&y>=-.5f&&y<=5.0f&&z>=0&&z<=32.4f;
    }
}
