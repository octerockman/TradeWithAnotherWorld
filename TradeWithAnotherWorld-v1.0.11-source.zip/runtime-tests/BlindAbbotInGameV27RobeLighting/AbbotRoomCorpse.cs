using System;
using System.Collections.Generic;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbey.BlindAbbot
{
    // Inert, room-owned final presentation. Native Character death still runs
    // exactly once. No Character, Animator, physics body or expiry clock is
    // attached to the corpse, so it cannot attack, drift or fall off the room.
    public sealed class AbbotRoomCorpse:MonoBehaviour
    {
        readonly List<Object> resources=new List<Object>();
        public static AbbotRoomCorpse Freeze(Transform room,AbbotVisual visual)
        {
            if(!room||visual==null||!visual.Root)throw new ArgumentException("Final Abbot presentation missing");
            visual.RefreshGrounding();
            var root=new GameObject("BA_Abbot_Final_Corpse");root.transform.SetParent(room,false);
            root.layer=visual.Root.gameObject.layer;var result=root.AddComponent<AbbotRoomCorpse>();
            try{
                var materials=new Dictionary<Material,Material>();
                foreach(var source in visual.Skins){
                    if(!source||!source.sharedMesh)continue;
                    var mesh=new Mesh{name=source.name+"_final_pose"};result.resources.Add(mesh);
                    // Bake includes the current source pose and the measured
                    // grounding offset. Convert its vertices into room space,
                    // avoiding nonuniform parent-scale decomposition.
                    source.BakeMesh(mesh,false);
                    visual.BakeSkirtInto(source,mesh);
                    var matrix=root.transform.worldToLocalMatrix*source.transform.localToWorldMatrix;
                    var vertices=mesh.vertices;for(int i=0;i<vertices.Length;i++)vertices[i]=matrix.MultiplyPoint3x4(vertices[i]);mesh.vertices=vertices;
                    var normals=mesh.normals;var normalMatrix=matrix.inverse.transpose;for(int i=0;i<normals.Length;i++)normals[i]=normalMatrix.MultiplyVector(normals[i]).normalized;mesh.normals=normals;
                    mesh.RecalculateBounds();mesh.RecalculateTangents();
                    var part=new GameObject(source.name);part.layer=root.layer;part.transform.SetParent(root.transform,false);
                    part.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=part.AddComponent<MeshRenderer>();
                    var copies=new List<Material>();foreach(var original in source.sharedMaterials){
                        if(!materials.TryGetValue(original,out var copy)){copy=new Material(original){name=original.name+"_corpse"};materials.Add(original,copy);result.resources.Add(copy);}copies.Add(copy);
                    }
                    renderer.sharedMaterials=copies.ToArray();renderer.shadowCastingMode=source.shadowCastingMode;renderer.receiveShadows=source.receiveShadows;
                }
                return result;
            }catch{Object.Destroy(root);throw;}
        }
        void OnDestroy(){foreach(var resource in resources)if(resource)Object.Destroy(resource);resources.Clear();}
    }
}
