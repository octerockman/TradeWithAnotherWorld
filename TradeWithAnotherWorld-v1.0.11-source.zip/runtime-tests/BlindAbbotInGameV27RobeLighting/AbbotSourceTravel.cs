using System;

namespace BlackAbbey.BlindAbbot
{
    public struct AbbotTravelDelta
    {
        public double Right,Forward,From,To;
        public bool Discarded;
        public double Length=>Math.Sqrt(Right*Right+Forward*Forward);
    }
    // The sidecar is already in fitted world metres: raw Havok XYZ became
    // (-X,Y,-Z)*heightReferenceScale during the checked export. Applying that
    // scale or coordinate conversion here a second time would be incorrect.
    // Horizontal reference travel is distinct from unchanged local bone poses.
    public sealed class AbbotSourceTravel
    {
        public const double MaximumInterval=.15;
        AbbotRepertoireClip clip;
        double consumed;
        public bool Active=>clip!=null;
        public double ConsumedTime=>consumed;
        public string ClipId=>clip?.id;
        public void Begin(AbbotRepertoireClip source,double initialTime=0)
        {
            if(source==null||source.trajectory==null||!Finite(source.duration)||source.duration<=0||!Finite(initialTime)||initialTime<0||initialTime>source.duration)
                throw new ArgumentException("Invalid source travel clip/clock");
            clip=source;consumed=initialTime;
        }
        public AbbotTravelDelta Consume(double time,bool discard=false)
        {
            if(clip==null)return default;
            if(!Finite(time))return new AbbotTravelDelta{From=consumed,To=consumed,Discarded=true};
            double at=Math.Max(0,Math.Min(clip.duration,time)),before=consumed;
            if(at<before)return new AbbotTravelDelta{From=before,To=before,Discarded=true};
            consumed=at;
            // Consume first, including blocked/staggered/restored intervals.
            // A later successful query cannot replay a stored displacement.
            if(discard||at-before>MaximumInterval)return new AbbotTravelDelta{From=before,To=at,Discarded=true};
            var a=Sample(clip,before);var b=Sample(clip,at);
            return new AbbotTravelDelta{Right=b.Right-a.Right,Forward=b.Forward-a.Forward,From=before,To=at};
        }
        public void End(){clip=null;consumed=0;}
        public static AbbotTravelDelta Sample(AbbotRepertoireClip source,double time)
        {
            if(source?.trajectory==null||source.trajectory.Length==0||!Finite(time))return default;
            var points=source.trajectory;double at=Math.Max(0,Math.Min(source.duration,time));
            if(at<=points[0].time)return new AbbotTravelDelta{Right=points[0].x,Forward=points[0].z,To=at};
            int lo=0,hi=points.Length-1;
            while(hi-lo>1){int mid=(lo+hi)/2;if(points[mid].time<=at)lo=mid;else hi=mid;}
            if(at>=points[hi].time)return new AbbotTravelDelta{Right=points[hi].x,Forward=points[hi].z,To=at};
            double span=points[hi].time-points[lo].time,t=span>0?(at-points[lo].time)/span:1;
            return new AbbotTravelDelta{Right=points[lo].x+(points[hi].x-points[lo].x)*t,Forward=points[lo].z+(points[hi].z-points[lo].z)*t,To=at};
        }
        public static double CastRadius(double radius)=>Math.Max(.05,radius-.04);
        // Retain the ORIGINAL native capsule radius for endpoint spacing.
        // Using the inset radius here cancels the sole clearance and can make
        // floor contact appear as a zero-distance horizontal obstruction.
        public static double HemisphereOffset(double halfHeight,double originalRadius)=>Math.Max(0,halfHeight-originalRadius);
        public static double MovingFriction(double slippage)=>.4*(1-slippage);
        static bool Finite(double value)=>!double.IsNaN(value)&&!double.IsInfinity(value);
    }
}
