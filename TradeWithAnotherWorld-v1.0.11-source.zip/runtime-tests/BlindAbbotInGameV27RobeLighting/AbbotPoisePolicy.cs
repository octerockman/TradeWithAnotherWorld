using System;

namespace BlackAbbey.BlindAbbot
{
    // Every frozen48000 NPC variation has110 source posture. Six native
    // Valheim damage units per source point is the existing Knight project
    // calibration, not a claim of identical cross-game weapon balance.
    public static class AbbotPoisePolicy
    {
        public const double SourcePosture=110,NativeUnitsPerPoint=6;
        public const double NativeThreshold=SourcePosture*NativeUnitsPerPoint;
        public static double Factor(double maximumHealth)=>Finite(maximumHealth)&&maximumHealth>0?NativeThreshold/maximumHealth:double.NaN;
        public static double Normalize(double nativeAccumulation)=>Finite(nativeAccumulation)?Math.Max(0,Math.Min(SourcePosture,nativeAccumulation/NativeUnitsPerPoint)):0;
        static bool Finite(double n)=>!double.IsNaN(n)&&!double.IsInfinity(n);
    }
}
