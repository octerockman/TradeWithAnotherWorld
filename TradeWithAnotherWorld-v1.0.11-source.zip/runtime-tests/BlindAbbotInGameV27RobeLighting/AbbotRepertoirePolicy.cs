using System;
using System.Collections.Generic;

namespace BlackAbbey.BlindAbbot
{
    public enum AbbotManeuver { None, PivotLeft, PivotRight, StrafeLeft, StrafeRight }

    // Selection only: this policy never reads a Player or changes a Transform.
    // Native motor/collision and the source-pose driver keep their own authority.
    public static class AbbotRepertoirePolicy
    {
        public const float PivotThresholdDegrees=65f, LargePivotThresholdDegrees=135f;
        public const float StrafeMinimumDistance=3.5f, StrafeMaximumDistance=8f;
        public const float ContactTurnLead=.12f, ContactTurnTail=.10f;

        public static bool CombatPhase(AbbotPhase phase) => phase==AbbotPhase.Service||phase==AbbotPhase.Fracture||phase==AbbotPhase.LastToll;

        // The caller supplies a current valid target observation. Jesse's
        // combat-test mode uses the eligible player's current position; future
        // perception policies can withhold observation without editing clips.
        // Each contact commits separately, so long combos can turn between hits.
        public static float AttackTurnDegreesPerSecond(bool freshObservation,float sourceElapsed,float sourceDuration,IEnumerable<AbbotSourceEvent> sourceEvents)
        {
            if(!freshObservation||!Finite(sourceElapsed)||!Finite(sourceDuration)||sourceDuration<=0||sourceElapsed>sourceDuration)return 0;
            bool futureContact=false;
            if(sourceEvents!=null)foreach(var contact in sourceEvents)
            {
                if(contact==null||!Finite(contact.time)||!Finite(contact.end)||contact.end<contact.time)continue;
                if(sourceElapsed>=contact.time-ContactTurnLead&&sourceElapsed<=contact.end+ContactTurnTail)return 0;
                if(sourceElapsed<contact.time-ContactTurnLead)futureContact=true;
            }
            // Full source speed remains unchanged; this is only actor facing.
            return sourceElapsed<0||futureContact?100f:55f;
        }

        // A native stagger is supplied as a rising edge, never as a continuously
        // true Animator tag. Hurt poses cannot be restarted by successive chips.
        // Existing attack commitment determines whether its pending events can
        // be cancelled; ritual, health depletion and death always take priority.
        public static bool CanStartReaction(AbbotPhase phase,bool tookDamage,bool nativeStaggerStarted,bool reactionActive,bool attackActive,bool attackInterruptible,float now,float nextReactionAt)
        {
            return CombatPhase(phase)&&(tookDamage||nativeStaggerStarted)&&!reactionActive&&(!attackActive||attackInterruptible)&&Finite(now)&&Finite(nextReactionAt)&&now>=nextReactionAt;
        }

        // Signed heading follows Unity's SignedAngle(currentForward, aim, up):
        // positive is the right turn. A retained point may orient a pivot;
        // strafe requires a current observation. The combat-test controller
        // supplies its current target directly. The consumer must validate the
        // lateral destination/capsule and owns choice/cadence, not this helper.
        public static AbbotManeuver ChooseManeuver(AbbotPhase phase,bool hasLocation,bool freshObservation,float distance,float signedHeadingDegrees,bool cooldownReady,bool tryStrafe,bool preferLeft)
        {
            if(!CombatPhase(phase)||!hasLocation||!cooldownReady||!Finite(distance)||distance<0||!Finite(signedHeadingDegrees))return AbbotManeuver.None;
            float heading=Math.Abs(signedHeadingDegrees);
            if(distance>1.25f&&heading>=PivotThresholdDegrees)return signedHeadingDegrees<0?AbbotManeuver.PivotLeft:AbbotManeuver.PivotRight;
            if(!freshObservation||distance<StrafeMinimumDistance||distance>StrafeMaximumDistance||heading>35||!tryStrafe)return AbbotManeuver.None;
            return preferLeft?AbbotManeuver.StrafeLeft:AbbotManeuver.StrafeRight;
        }

        public static bool LargePivot(float signedHeadingDegrees)=>Finite(signedHeadingDegrees)&&Math.Abs(signedHeadingDegrees)>=LargePivotThresholdDegrees;

        // The recovered common HKS battle-walk table maps left/right to
        // ANIME_ID_WALK_BATTLE(2000)+2/+3. Act24 requests SidewayMove; it does
        // not request character Event20010/20011. Those contextual events have
        // lateral reference travel but are not ordinary target-facing gaits.
        public static string TacticalStrafeMotion(bool left)=>left?"a000_002002":"a000_002003";

        static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
    }
}
