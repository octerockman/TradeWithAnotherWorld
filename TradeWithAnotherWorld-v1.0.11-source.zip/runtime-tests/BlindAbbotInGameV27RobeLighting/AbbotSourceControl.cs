using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace BlackAbbey.BlindAbbot
{
    [Serializable] public sealed class AbbotControlWindow { public int sourceEventIndex,flag;public float start,end; }
    [Serializable] public sealed class AbbotTurnWindow { public int sourceEventIndex,unknown;public float start,end,rate;public bool lockOnCheck; }
    [Serializable] public sealed class AbbotFixedDirectionWindow { public int sourceEventIndex;public float start,end;public bool enabled; }
    [Serializable] public sealed class AbbotPoiseWindow { public int sourceEventIndex,toughnessParamId,toughnessType;public float start,end,damageRatio; }
    [Serializable] public sealed class AbbotSourceControlClip
    {
        public string id;public float duration;public AbbotControlWindow[] flags;public AbbotTurnWindow[] turnRates;
        public AbbotFixedDirectionWindow[] fixedDirections;public AbbotPoiseWindow[] poise;
    }
    [Serializable] public sealed class AbbotSourceControlData
    {
        public string schema,interpretation;public FileRecord sourceEvents,sourceNative;public AbbotSourceControlClip[] clips;
    }

    // Independent source channels. Combo23 is not movement78, step79 or queued
    // attack86. TAE224 is a source turn-rate envelope, not a damage-contact gate.
    // The CommonAttack native implementation is opaque: unknown arguments and
    // poise795 records are retained as evidence, never assigned new semantics.
    public sealed class AbbotSourceControl
    {
        static readonly HashSet<int> AllowedFlags=new HashSet<int>{7,23,24,78,79,86,110};
        readonly Dictionary<string,AbbotSourceControlClip> clips=new Dictionary<string,AbbotSourceControlClip>(StringComparer.Ordinal);
        public AbbotSourceControlData Data{get;}
        public AbbotSourceControl(AbbotSourceControlData data,MotionBank motions)
        {
            Data=data??throw new InvalidDataException("Missing source control data");
            if(data.schema!="blind-abbot.source-control.v1"||motions?.clips==null||data.sourceNative==null||string.IsNullOrWhiteSpace(data.sourceNative.sha256)||data.sourceNative.sha256!=motions.sourceNative?.sha256
                ||data.sourceEvents==null||string.IsNullOrWhiteSpace(data.sourceEvents.sha256)||data.clips==null||data.clips.Length!=motions.clips.Length)
                throw new InvalidDataException("Source control authority/inventory mismatch");
            foreach(var clip in data.clips)
            {
                var motion=motions.clips.FirstOrDefault(c=>c.name==clip?.id);
                if(clip==null||string.IsNullOrWhiteSpace(clip.id)||clips.ContainsKey(clip.id)||motion==null||!Finite(clip.duration)||clip.duration<=0||Math.Abs(clip.duration-motion.duration)>.001f
                    ||clip.flags==null||clip.turnRates==null||clip.fixedDirections==null||clip.poise==null
                    ||clip.flags.Length>128||clip.turnRates.Length>64||clip.fixedDirections.Length>64||clip.poise.Length>64)
                    throw new InvalidDataException("Invalid source control clip: "+clip?.id);
                foreach(var w in clip.flags)if(w==null||!AllowedFlags.Contains(w.flag)||!Window(w.start,w.end,w.sourceEventIndex))throw new InvalidDataException("Invalid source action flag: "+clip.id);
                foreach(var w in clip.turnRates)if(w==null||!Window(w.start,w.end,w.sourceEventIndex)||!Finite(w.rate)||w.rate<0||w.rate>3600||w.unknown<0||w.unknown>255)throw new InvalidDataException("Invalid source turn rate: "+clip.id);
                for(int i=0;i<clip.turnRates.Length;i++)for(int j=i+1;j<clip.turnRates.Length;j++)
                {
                    var a=clip.turnRates[i];var b=clip.turnRates[j];
                    if(Math.Max(a.start,b.start)<Math.Min(a.end,b.end)&&(a.rate!=b.rate||a.lockOnCheck!=b.lockOnCheck))throw new InvalidDataException("Ambiguous simultaneous source turn rates: "+clip.id);
                }
                foreach(var w in clip.fixedDirections)if(w==null||!Window(w.start,w.end,w.sourceEventIndex))throw new InvalidDataException("Invalid source direction window: "+clip.id);
                foreach(var w in clip.poise)if(w==null||!Window(w.start,w.end,w.sourceEventIndex)||!Finite(w.damageRatio)||w.damageRatio<0||w.damageRatio>100||w.toughnessParamId<0||w.toughnessParamId>255||w.toughnessType<0||w.toughnessType>255)throw new InvalidDataException("Invalid source poise record: "+clip.id);
                clips.Add(clip.id,clip);
            }
        }
        public static AbbotSourceControl Load(string path,MotionBank motions)
        {
            if(new FileInfo(path).Length>2*1024*1024)throw new InvalidDataException("Oversized source control data");
            var data=JsonConvert.DeserializeObject<AbbotSourceControlData>(File.ReadAllText(path),new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MetadataPropertyHandling=MetadataPropertyHandling.Ignore,MaxDepth=24});
            return new AbbotSourceControl(data,motions);
        }
        public AbbotSourceControlClip Find(string id)=>id!=null&&clips.TryGetValue(id,out var c)?c:null;
        public bool FlagOpen(string id,float elapsed,int flag)
        {
            var clip=Find(id);if(clip==null||!Finite(elapsed)||elapsed<0||!AllowedFlags.Contains(flag))return false;
            if(elapsed>=clip.duration)return Transition(flag);
            return clip.flags.Any(w=>w.flag==flag&&Active(elapsed,w.start,w.end,clip.duration));
        }
        public float FirstOpenAtOrAfter(string id,float minimum,int flag)
        {
            var clip=Find(id);if(clip==null||!Transition(flag)||!Finite(minimum)||minimum<0)return float.PositiveInfinity;
            if(minimum>=clip.duration)return clip.duration;
            float first=clip.duration;
            foreach(var w in clip.flags)if(w.flag==flag){float at=Math.Max(minimum,w.start);if(at<Math.Min(clip.duration,w.end))first=Math.Min(first,at);}
            return first;
        }
        // Only the caller's real pending intent determines which channel to
        // ask for. Do not cut unconsumed contact or branch events at this time.
        public bool MayYield(string id,float elapsed,int flag,float protectedUntil)
            =>Finite(protectedUntil)&&protectedUntil>=0&&elapsed>=protectedUntil&&FlagOpen(id,elapsed,flag);
        public float TrackingDegreesPerSecond(string id,float elapsed,bool hasTarget,float nativeDefaultTurnRate)
        {
            var clip=Find(id);if(clip==null||!hasTarget||!Finite(elapsed)||elapsed<0||elapsed>=clip.duration)return 0;
            if(FlagOpen(id,elapsed,7)||FlagOpen(id,elapsed,110))return 0;
            // Named TAE703 fixes the rotation direction during its actual
            // window. It does not rotate bones or apply external root yaw.
            if(clip.fixedDirections.Any(w=>w.enabled&&Active(elapsed,w.start,w.end,clip.duration)))return 0;
            AbbotTurnWindow selected=null;
            foreach(var w in clip.turnRates)if(Active(elapsed,w.start,w.end,clip.duration)&&(selected==null||w.sourceEventIndex>selected.sourceEventIndex))selected=w;
            // Current c4800 AI records use IsLockOnCheck=false. If future data
            // needs player lock-on semantics, do not invent a positive AI rate.
            if(selected!=null)return selected.lockOnCheck?0:selected.rate;
            return Finite(nativeDefaultTurnRate)&&nativeDefaultTurnRate>=0?nativeDefaultTurnRate:0;
        }
        // This gate concerns only our presentation/cancellation. Native damage,
        // native posture accumulation and its stagger result remain authority.
        public bool AllowsStaggerPresentation(string id,float elapsed,bool nativeStaggerStarted)
            =>nativeStaggerStarted&&Find(id)!=null&&Finite(elapsed)&&elapsed>=0&&!FlagOpen(id,elapsed,24);
        static bool Transition(int flag)=>flag==23||flag==78||flag==79||flag==86;
        static bool Active(float at,float start,float end,float duration)=>at>=start&&at<Math.Min(end,duration);
        static bool Window(float start,float end,int index)=>Finite(start)&&Finite(end)&&start>=0&&end>start&&end<=100.001f&&index>=0;
        static bool Finite(float v)=>!float.IsNaN(v)&&!float.IsInfinity(v);
    }
}
