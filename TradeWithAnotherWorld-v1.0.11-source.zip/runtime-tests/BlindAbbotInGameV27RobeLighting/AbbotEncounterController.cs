using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbey.BlindAbbot
{
    public sealed class AbbotEncounterController:MonoBehaviour
    {
        public AbbotPhase Phase{get;private set;}=AbbotPhase.Waiting;
        public bool IsBound=>room;
        public bool Ready=>room&&actor&&guard&&visual!=null&&audio&&audio.Ready&&nav&&nav.Ready;
        AbbotRoomBridge room;Humanoid actor;ZNetView view;AbbotHealthGuard guard;AbbotVisual visual;AbbotAudioController audio;AbbotDungeonNavigation nav;AbbotEffects effects;AbbotDeafenedLease deafened;
        AbbotBellInvocationFx invocationFx;AbbotSourceCombat combat;AbbotNativeTravelMotor sourceTravel;
        AbbotSourceControl sourceControl;
        readonly AbbotCombatExecutionLedger execution=new AbbotCombatExecutionLedger();
        AbbotSourceDecision recoveryDecision;float recoveryHeading;
        bool openingCastPending,fractureTollPending,fractureTollUsed,pivotCounterPending;
        string observedMotion;float observedMotionTime;
        float staffElapsed;Vector3 staffActorPosition;Quaternion staffActorRotation;
        readonly Dictionary<int,HashSet<long>> staffVictims=new Dictionary<int,HashSet<long>>();
        readonly Dictionary<int,HashSet<IDestructible>> staffPews=new Dictionary<int,HashSet<IDestructible>>();
        readonly Collider[] staffObstacles=new Collider[64];
        static readonly float[] StaffPewFractions={0f,.25f,.5f,.75f,1f};
        readonly System.Random random=new System.Random();
        AbbotMoveSpec move;AbbotMove previous;float moveAt,nextMoveAt,nextRoute,voiceAt=-100,lastHealth;
        AbbotSourceClip sourceClip;AbbotSourceTransition followup;AbbotEventCursor sourceEvents;AbbotSourceBranchClock sourceBranches;int chainClips;string previousSource;
        bool sourceStarted;
        sealed class PendingSourceAttack
        {
            public AbbotSourceClip Clip;public Player Target;public AbbotPhase Phase;
            public int Chain;public bool Terminal,Run;public float At,Seconds,Range,LastMotionAt;public Vector3 LastPosition;
            public AbbotSourceDecision AfterAttack;
        }
        PendingSourceAttack pendingSourceAttack;AbbotSourceDecision sourceAfterAttack;
        Vector3 targetPoint,aim;bool targetAvailable,hit,allowDeath,finalBar,bound,started;
        Player target;
        // Jesse requested direct player tracking while combat is being tested.
        // The hearing-only policy remains preserved in the sealed V13 source;
        // this candidate neither polls noise nor starts Listen/search pauses.
        bool nativeStaggeredLast,nativeStaggering;string reactionMotion;
        bool unhandledNativeStagger;float nativeTurnSpeed;
        const float SourceDefaultTurnSpeed=80f; // Exact c4800 NPC TurnVelocity.
        float reactionAt,reactionDuration,nextReactionAt;
        AbbotManeuver maneuver=AbbotManeuver.None;AbbotRepertoireClip maneuverClip;
        Vector3 maneuverForward,maneuverGoal,maneuverLastPosition;
        float maneuverAt,maneuverLastMotionAt,maneuverTravel,maneuverSeconds;
        int strafeSide;AbbotSourceDecision travelDecision;
        float travelDecisionAt,travelLastMotionAt,travelDistance,travelGoalAt;Vector3 travelGoal,travelLastPosition;
        float introAt,phaseAt,stepAt,waveAt,lastWaveRadius,deathEnds;int triple;
        AbbotRitualStep ritualStep;List<Vector3> path;int pathIndex;
        Vector3 lastWalkPosition;float lastWalkTime=-100,walkPhase,idlePhase;bool walkWasStumble,walkWasRun;
        bool moveVoiceStarted,playerWasAlive,pendingPlayerKill;float playerKillDue=-100,lastOwnHitAt=-100;
        readonly AbbotDialoguePolicy dialogue=new AbbotDialoguePolicy();long dialogueSequence,moveDialogueId,killDialogueId;int attackIndex;
        double moveDialogueAt,killDialogueAt,openingAt;bool openingAttempted,restoredActive,approachObserved;AbbotDialogueEvent openingEvent;
        readonly List<Wave> waves=new List<Wave>();readonly List<Rupture> ruptures=new List<Rupture>();
        readonly List<BellHazard> bellHazards=new List<BellHazard>();
        sealed class BellHazard{public string Clip;public AbbotBellEmission Emission;public float At,Previous=-1;public AbbotMoveSpec Spec;public HashSet<long> Hit;}
        sealed class Wave{public Vector3 Center;public float At,Duration,Radius,Last;public AbbotMoveSpec Spec;public HashSet<long> Hit=new HashSet<long>();}
        sealed class Rupture{public Vector3 Center,Direction;public float At;public AbbotMoveSpec Spec;}
        static readonly System.Reflection.MethodInfo CheckDeath=AccessTools.Method(typeof(Character),"CheckDeath");
        static readonly System.Reflection.MethodInfo IsStaggering=AccessTools.Method(typeof(Character),"IsStaggering");
        static readonly System.Reflection.FieldInfo LastHit=AccessTools.Field(typeof(Character),"m_lastHit");
        bool Authoritative=>view&&view.IsValid()&&view.IsOwner();
        public bool OwnsTacticalFacing=>bound&&Authoritative&&targetAvailable&&AbbotRepertoirePolicy.CombatPhase(Phase)
            &&(maneuver==AbbotManeuver.StrafeLeft||maneuver==AbbotManeuver.StrafeRight||travelDecision?.Kind==AbbotSourceDecisionKind.Retreat);
        public void Bind(AbbotRoomBridge owner,float maximum)
        {
            if(bound||!owner)throw new InvalidOperationException("Own Abbot binds exactly once");
            room=owner;actor=GetComponent<Humanoid>();view=GetComponent<ZNetView>();
            if(!actor||!Authoritative)throw new InvalidOperationException("Native owner actor not ready");
            nativeTurnSpeed=SourceDefaultTurnSpeed;actor.m_turnSpeed=nativeTurnSpeed;
            visual=AbbotPlugin.BindVisual(transform.Find("Visual"));
            visual.ConfigureGrounding(room.RoomRoot,.025f);
            combat=AbbotPlugin.SourceCombat.CreateSession();
            sourceControl=AbbotPlugin.SourceControl;
            visual.MotionObserved=(id,elapsed)=>{observedMotion=id;observedMotionTime=elapsed;combat.ObserveMotion(id,elapsed,Time.time);};
            invocationFx=AbbotBellInvocationFx.Attach(visual.Semantic("LeftHand"));
            // Measured rigid-palm center from the actual V13 skinned body,
            // expressed in L_Hand-local Unity metres; no bone/Action changes.
            invocationFx?.SetPalmOffset(new Vector3(-.073530489f,-.017818811f,.005370613f));
            audio=AbbotAudioController.Attach(gameObject,AbbotPlugin.AudioBank,visual.Semantic("Head"),AbbotPlugin.NativeMixer,AbbotPlugin.Log);
            if(!audio||!audio.Ready)throw new InvalidOperationException("Starred audio is not ready");
            audio.AttachRoom(room.RoomRoot,room.BellContact);
            audio.Configure(true,AbbotPlugin.AudioVolume,AbbotPlugin.BossVoiceGain);audio.DuckRequested+=room.Duck;
            audio.EventPlayed+=(eventName,cue,duration)=>{room.Opening.RecordPlayed(eventName);if(AbbotGreatBellPolicy.IsOrdinary(eventName))room.ChimeGreatBell();AbbotPlugin.Log("BA_ABBOT_AUDIO_EVENT room="+room.InstanceId+" actor="+GetInstanceID()+" phase="+Phase+" event="+eventName+" cue="+cue+" seconds="+duration);};
            guard=gameObject.AddComponent<AbbotHealthGuard>();guard.Bind(actor,maximum,BeginRitual);
            AbbotPoiseProfile.Configure(actor);
            nav=AbbotDungeonNavigation.Attach(gameObject,AbbotPlugin.Log);
            effects=gameObject.AddComponent<AbbotEffects>();effects.Initialize(room);
            deafened=new AbbotDeafenedLease("BA-Abbot-"+GetInstanceID());bound=true;phaseAt=Time.time;lastHealth=maximum;
            sourceTravel=AbbotNativeTravelMotor.Attach(gameObject,AbbotPlugin.Repertoire,()=>bound&&Authoritative&&sourceClip!=null&&sourceStarted&&AbbotRepertoirePolicy.CombatPhase(Phase)&&room&&room.Players().Length>0,AbbotPlugin.Log);
            var facing=room.BellContact-transform.position;facing.y=0;
            if(facing.sqrMagnitude>.001f){var rotation=Quaternion.LookRotation(facing.normalized,room.RoomRoot.up);transform.rotation=rotation;var body=GetComponent<Rigidbody>();if(body)body.rotation=rotation;actor.SetLookDir(facing.normalized);}
            visual.SetMotion("idle",0);visual.SetEmber(.35f);
            visual.EnableScarfCloth(AbbotPlugin.Log);
            AbbotPlugin.Log("BA_ABBOT_BOUND room="+room.InstanceId+" max="+maximum+" final="+(maximum*.4f));
        }
        public void ObserveRoomStage(string stage)
        {
            // A restored Active room resumes combat; new entrances start at
            // the doorway, independently of the later door/candle trigger.
            if(started||!Ready||stage!="Active")return;
            started=true;introAt=Time.time;openingAt=AudioSettings.dspTime;restoredActive=stage=="Active";
            openingEvent=random.Next(2)==0?AbbotDialogueEvent.DoorSealed:AbbotDialogueEvent.CandlesKindled;Stop();
        }
        public void ObserveEntrance()
        {
            if(started||!Ready||Phase!=AbbotPhase.Waiting||room.Players().Length==0)return;
            started=true;introAt=Time.time;openingAt=AudioSettings.dspTime;
            openingEvent=random.Next(2)==0?AbbotDialogueEvent.DoorSealed:AbbotDialogueEvent.CandlesKindled;
            Stop();visual.SetMotion("a000_003005",0,1,.18f);
            AbbotPlugin.Log("BA_ABBOT_ENTRANCE_BEGIN clip=a000_003005 threshold=room-doorway");
        }
        void Update()
        {
            if(!bound||!Authoritative||!room){pendingSourceAttack=null;sourceAfterAttack=null;return;}
            actor.m_turnSpeed=nativeTurnSpeed;
            audio.Configure(true,AbbotPlugin.AudioVolume,AbbotPlugin.BossVoiceGain);
            if(Phase==AbbotPhase.Cancelled||Phase==AbbotPhase.Defeated)return;
            if(Phase==AbbotPhase.Dying){TickDying();return;}
            float currentHealth=actor.GetHealth(),previousHealth=lastHealth;bool tookDamage=currentHealth<previousHealth;lastHealth=currentHealth;
            nativeStaggering=IsStaggering!=null&&(bool)IsStaggering.Invoke(actor,null);
            bool staggerStarted=nativeStaggering&&!nativeStaggeredLast;nativeStaggeredLast=nativeStaggering;
            if(staggerStarted)unhandledNativeStagger=true;
            if(!nativeStaggering)unhandledNativeStagger=false;
            TickWaves();TickRuptures();TickBellHazards();
            if(Phase==AbbotPhase.Ritual){TickRitual();return;}
            if(finalBar)deafened.Tick(p=>room&&room.Eligible(p));
            if(Phase==AbbotPhase.Waiting){TickIntro(tookDamage,staggerStarted);return;}
            ObservePlayerDeath();
            var players=room.Players();TrackTarget(players);
            if(players.Length==0){PauseCombatClocks(Time.deltaTime);Stop();PoseIdle();return;}
            var next=AbbotEncounterPolicy.CombatPhase(actor.GetHealth()/guard.OriginalMaximum,finalBar);
            if(next!=Phase){Phase=next;if(next==AbbotPhase.Fracture){fractureTollPending=!fractureTollUsed;Speak(AbbotDialogueEvent.Fracture,++dialogueSequence,AudioSettings.dspTime,previousHealth/guard.OriginalMaximum,currentHealth/guard.OriginalMaximum);}visual.SetEmber(finalBar?1.3f:.85f);}
            if(!approachObserved&&targetAvailable){approachObserved=true;if(!restoredActive)Speak(AbbotDialogueEvent.FirstApproach,++dialogueSequence,AudioSettings.dspTime);}
            if(tookDamage)Speak(AbbotDialogueEvent.Hurt,++dialogueSequence,AudioSettings.dspTime,previousHealth/guard.OriginalMaximum,currentHealth/guard.OriginalMaximum);
            if(TryStartReaction(tookDamage,unhandledNativeStagger)||reactionMotion!=null){TickReaction();return;}
            if(nativeStaggering){PauseCombatClocks(Time.deltaTime);Stop();return;}
            if(pendingSourceAttack!=null){TickPendingSourceAttack();return;}
            if(maneuver!=AbbotManeuver.None){TickManeuver();return;}
            if(travelDecision!=null){TickTravelDecision();return;}
            if(move!=null){TickMove();return;}
            if(nativeStaggering||Time.time<nextMoveAt){Stop();PoseIdle();if(!nativeStaggering&&targetAvailable)FaceBounded(targetPoint,55);return;}
            if(TryContextualAction())return;
            float distance=targetAvailable?Horizontal(transform.position,targetPoint):999;
            var toTarget=targetPoint-transform.position;toTarget.y=0;
            float heading=targetAvailable?Vector3.SignedAngle(transform.forward,toTarget,Vector3.up):0;
            SetSourceDecisionContext();
            var choice=combat.ChooseDecision(Phase,distance,heading,targetAvailable,previousSource,random,Time.time);
            if(choice!=null&&BeginDecision(choice,heading))return;
            // An obstructed maneuver yields back to the weighted decision
            // table; it never retries nav every rendered frame or waits stuck.
            nextMoveAt=Time.time+.25f;Stop();PoseIdle();if(targetAvailable)FaceBounded(targetPoint,100);
        }
        void TickIntro(bool tookDamage,bool staggerStarted)
        {
            Stop();
            if(!started){if(tookDamage||staggerStarted)ObserveEntrance();else{PoseIdle();return;}}
            if(!started)return;
            float duration=visual.MotionDuration("a000_003005"),elapsed=Time.time-introAt;
            bool interrupted=tookDamage||staggerStarted;
            if(!restoredActive&&!interrupted)visual.SetMotion("a000_003005",Mathf.Clamp01(elapsed/duration));
            // One real opening beat, after the door slam. Saved Active encounters
            // do not replay an entrance, and dialogue never delays combat timing.
            if(!restoredActive&&!openingAttempted&&Time.time-introAt>=1&&(room.Stage=="Lighting"||room.Stage=="Active")){openingAttempted=true;Speak(openingEvent,++dialogueSequence,AudioSettings.dspTime);}
            if(restoredActive||interrupted||elapsed>=duration){Phase=AbbotPhase.Service;phaseAt=Time.time;nextMoveAt=Time.time;openingCastPending=!restoredActive&&!interrupted;TrackTarget(room.Players());if(interrupted)TryStartReaction(tookDamage,staggerStarted);AbbotPlugin.Log("BA_ABBOT_COMBAT_STARTED entrance="+(interrupted?"interrupted":restoredActive?"restored":"completed"));}
        }
        void TrackTarget(Player[] players)
        {
            var previousTarget=target;
            // Keep one eligible target through a phrase instead of switching
            // between nearby players every frame. Loss/death leaves no stale
            // position target; room.Players supplies the room eligibility gate.
            if(!target||target.IsDead()||!players.Contains(target))
                target=players.Where(p=>p&&!p.IsDead()).OrderBy(p=>Horizontal(transform.position,p.transform.position)).FirstOrDefault();
            targetAvailable=target;
            if(targetAvailable)targetPoint=target.transform.position;
            if(previousTarget!=target)
            {
                if(pendingSourceAttack!=null)EndPendingSourceAttack("target-changed");
                sourceAfterAttack=null;
                AbbotPlugin.Log("BA_ABBOT_TARGET mode=direct-combat-test player="+(target?target.GetPlayerID():0));
            }
        }
        void SetSourceDecisionContext(){if(observedMotion!=null)combat.ObserveMotion(observedMotion,observedMotionTime,Time.time);}
        void PauseCombatClocks(float seconds)
        {
            if(seconds<=0)return;
            if(move!=null){moveAt+=seconds;sourceTravel?.PauseClock(seconds);}
            staffActorPosition=transform.position;staffActorRotation=transform.rotation;
            if(pendingSourceAttack!=null){pendingSourceAttack.At+=seconds;pendingSourceAttack.LastMotionAt+=seconds;}
            if(reactionMotion!=null)reactionAt+=seconds;
            if(maneuver!=AbbotManeuver.None){maneuverAt+=seconds;maneuverLastMotionAt+=seconds;}
            if(travelDecision!=null){travelDecisionAt+=seconds;travelLastMotionAt+=seconds;}
            if(nextMoveAt>Time.time-seconds)nextMoveAt+=seconds;
        }
        bool TryContextualAction()
        {
            if(!targetAvailable)return false;
            if(Phase!=AbbotPhase.Service)openingCastPending=false;
            string id=null,context=null;
            if(fractureTollPending&&!fractureTollUsed){id="a000_003023";context="Abbey Fracture great-bell triplet (source Act35 adaptation)";}
            else if(openingCastPending){id="a000_003000";context="Abbey uninterrupted introduction opening (source Act01 adaptation)";}
            else if(pivotCounterPending){pivotCounterPending=false;id="a000_003021";context="Abbey close counter after large pivot (source CP3 adaptation)";}
            if(id==null)return false;
            var choice=combat.ChooseContextual(id,Phase,Horizontal(transform.position,targetPoint),targetAvailable,Time.time);
            if(choice==null)return false;
            if(id=="a000_003023"){fractureTollPending=false;fractureTollUsed=true;}
            if(id=="a000_003000")openingCastPending=false;
            AbbotPlugin.Log("BA_ABBOT_CONTEXT_ACTION clip="+id+" context="+context);
            return BeginDecision(choice,0);
        }
        void BeginMove(AbbotMove type)
        {
            sourceTravel?.EndClip("presentation-change");invocationFx?.End();
            sourceClip=null;followup=null;sourceEvents=null;sourceBranches=null;pendingSourceAttack=null;sourceAfterAttack=null;chainClips=0;
            if(type==AbbotMove.Listen){move=null;Stop();PoseIdle();return;}
            move=AbbotEncounterPolicy.Spec(type);previous=type;moveAt=Time.time;hit=false;triple=0;aim=targetAvailable?targetPoint:transform.position+transform.forward*3;Stop();FaceBounded(aim,100);
            attackIndex++;moveDialogueId=++dialogueSequence;moveDialogueAt=AudioSettings.dspTime;
            moveVoiceStarted=false;TryAttackVoice();
            if(type==AbbotMove.Pulse||type==AbbotMove.TripleToll||type==AbbotMove.Rupture)invocationFx?.Begin(move.HitAt);
            if(type==AbbotMove.Pulse||type==AbbotMove.TripleToll)effects.BellWarning(transform.position,move.Range,move.HitAt);
        }
        void TickMove()
        {
            if(sourceClip!=null){TickSourceMove();return;}
            Stop();float elapsed=Time.time-moveAt;
            TryAttackVoice();
            visual.SetMotion(move.Motion,Mathf.Clamp01(elapsed/move.Duration));
            if(!hit&&elapsed>=move.HitAt){hit=true;switch(move.Move){
                case AbbotMove.Slam:case AbbotMove.Sweep:StaffHit(move);Speak(AbbotDialogueEvent.StaffEffort,++dialogueSequence,AudioSettings.dspTime);break;
                case AbbotMove.Pulse:invocationFx?.Strike();AddPulse(move);break;
                case AbbotMove.TripleToll:invocationFx?.Strike();AddPulse(move);triple=1;break;
                case AbbotMove.Rupture:invocationFx?.Strike();ScheduleRuptures(move);break;
                case AbbotMove.Listen:break; // Disabled during direct-target combat testing.
            }}
            if(move.Move==AbbotMove.TripleToll&&triple>0&&triple<3&&elapsed>=move.HitAt+triple*.6f){invocationFx?.Strike();AddPulse(move);triple++;}
            if(elapsed>=move.Duration){sourceTravel?.EndClip("presentation-change");invocationFx?.End();nextMoveAt=Time.time+move.Recovery;move=null;}
        }
        void BeginSourceMove(AbbotSourceClip clip,float began,int chain,bool terminal=false,bool startsAct=false,AbbotSourceDecision afterAttack=null)
        {
            sourceTravel?.EndClip("presentation-change");invocationFx?.End();
            recoveryDecision=null;execution.Committed(clip.id);
            staffElapsed=0;staffActorPosition=transform.position;staffActorRotation=transform.rotation;staffVictims.Clear();staffPews.Clear();
            strafeSide=0;travelDecision=null;maneuver=AbbotManeuver.None;maneuverClip=null;
            pendingSourceAttack=null;sourceAfterAttack=afterAttack;if(startsAct)combat.RecordActChoice();
            sourceClip=clip;move=clip.Spec();previous=move.Move;previousSource=clip.id;moveAt=began+clip.prepareSeconds;chainClips=chain;hit=false;sourceStarted=false;
            sourceEvents=new AbbotEventCursor(clip.events.Select(e=>e.time).ToArray());aim=targetAvailable?targetPoint:transform.position+transform.forward*3;Stop();FaceBounded(aim,100);
            followup=null;sourceBranches=new AbbotSourceBranchClock(clip.windows,terminal);
            attackIndex++;moveDialogueId=++dialogueSequence;moveDialogueAt=AudioSettings.dspTime+Mathf.Max(0,moveAt-Time.time);moveVoiceStarted=false;
            visual.SetMotion(sourceClip.id,0,1,clip.prepareSeconds>0?clip.prepareSeconds:.24f);
            var firstBell=clip.events.FirstOrDefault(e=>AbbotGreatBellPolicy.IsInvocationSourceEvent(e.kind));if(firstBell!=null)invocationFx?.Begin(clip.prepareSeconds+firstBell.time);
            if(Time.time>=moveAt)StartSourcePresentation();
            AbbotPlugin.Log("BA_ABBOT_SOURCE_CLIP id="+clip.id+" chain="+chain+" branch="+(sourceBranches.Remaining==0?"recovery":"pending-source-window")+" terminal="+terminal);
        }
        void TickSourceMove()
        {
            Stop();
            for(int step=0;step<AbbotSourceBranchClock.MaximumTransitionsPerUpdate&&sourceClip!=null;step++)
            {
                float elapsed=Mathf.Max(0,Time.time-moveAt);
                TrackSourceFacing(Time.time-moveAt);
                if(Time.time<moveAt){visual.SetMotion(sourceClip.id,0,1,sourceClip.prepareSeconds);return;}
                if(!sourceStarted)StartSourcePresentation();
                while(followup==null&&sourceBranches.TryNext(elapsed,out var window))
                {
                    // Preserve contact-before-branch ordering during a long
                    // frame. Only this crossed effect window is decided now;
                    // declining it cannot draw a later window early.
                    float boundary=Mathf.Min(window.DecisionAt,sourceClip.duration);
                    visual.SetMotion(sourceClip.id,boundary/sourceClip.duration);
                    sourceEvents.Advance(boundary,DispatchSourceEvent);
                    float distance=targetAvailable?Horizontal(transform.position,targetPoint):999;
                    followup=combat.ChooseFollowupAt(sourceClip,Phase,distance,targetAvailable,window.sourceEffect,random,Time.time);
                    UpdateSourceTravelLimit();
                    AbbotPlugin.Log("BA_ABBOT_SOURCE_BRANCH_CHOICE clip="+sourceClip.id+" effect="+window.sourceEffect+" next="+(followup?.to??"continue-current-clip")+" elapsed="+elapsed.ToString("F3"));
                }
                float branch=followup==null?sourceClip.duration:followup.start;
                float displayed=Mathf.Min(elapsed,branch);
                visual.SetMotion(sourceClip.id,displayed/sourceClip.duration);
                sourceEvents.Advance(displayed,DispatchSourceEvent);
                TickSourceStaffContacts(displayed);
                if(elapsed<branch){TryYieldSourceRecovery(elapsed);return;}
                if(followup!=null)
                {
                    // Range/target/phase can change after the sequence started.
                    // Reject a stale branch and finish this source recovery;
                    // never truncate its tail or re-roll an unrelated attack.
                    if(!FollowupStillEligible(followup)){AbbotPlugin.Log("BA_ABBOT_SOURCE_BRANCH_CANCEL clip="+sourceClip.id+" next="+followup.to+" reason=target-range-or-phase");followup=null;UpdateSourceTravelLimit();continue;}
                    if(!AbbotSourceBranchClock.TryBranchStart(moveAt,branch,out float at))
                    {
                        // Corrupt/nonadvancing data must not spin in one Update.
                        // Finish this valid current clip; do not invent a new
                        // move-count cap for otherwise advancing source routes.
                        AbbotPlugin.Log("BA_ABBOT_SOURCE_BRANCH_CANCEL clip="+sourceClip.id+" next="+followup.to+" reason=nonadvancing-source-clock");followup=null;UpdateSourceTravelLimit();continue;
                    }
                    var edge=followup;var next=combat.Find(edge.to);sourceEvents.Cancel();
                    int nextChain=chainClips==int.MaxValue?int.MaxValue:chainClips+1;
                    if(edge.approach)
                    {
                        // Keep the source's chosen successor instead of
                        // excluding it from the route because this actor has
                        // shorter reach. Native navigation closes the distance
                        // before any new source contact can be committed.
                        if(edge.startsAct)combat.RecordActChoice();
                        BeginPendingSourceAttack(next,nextChain,edge.final,edge.approachSeconds,edge.approachRange,edge.approachRun,null);
                        return;
                    }
                    execution.Completed(sourceClip.id);BeginSourceMove(next,at,nextChain,edge.final,edge.startsAct);continue;
                }
                execution.Completed(sourceClip.id);
                sourceTravel?.EndClip();invocationFx?.End();nextMoveAt=moveAt+sourceClip.duration+move.Recovery;sourceClip=null;sourceEvents=null;sourceBranches=null;move=null;
                var after=sourceAfterAttack??recoveryDecision;sourceAfterAttack=null;recoveryDecision=null;if(after!=null&&targetAvailable)BeginDecision(after,0);return;
            }
            // Transition budget exhausted: retain sourceClip/moveAt/cursors.
            // Next Update continues this same chain rather than ending it.
        }
        void TrackSourceFacing(float elapsed)
        {
            sourceTravel?.SetHeading(transform.rotation);
            float rate=sourceControl.TrackingDegreesPerSecond(sourceClip.id,elapsed,targetAvailable,SourceDefaultTurnSpeed);
            actor.m_turnSpeed=rate;
            if(rate<=0){actor.SetLookDir(transform.forward);return;}
            aim=targetPoint;var direction=aim-transform.position;direction.y=0;
            // Supply the full desired heading. A tiny per-frame look offset
            // invokes native NPC near-angle easing twice and barely turns.
            // Native rotation/collision/ownership still perform the actual yaw.
            if(direction.sqrMagnitude>.001f)actor.SetLookDir(direction.normalized);
        }
        bool TryYieldSourceRecovery(float elapsed)
        {
            if(sourceClip==null||followup!=null||sourceBranches.Remaining>0||!targetAvailable)return false;
            float protectedUntil=sourceClip.events.Length==0?0:sourceClip.events.Max(e=>e.end);
            if(elapsed<protectedUntil)return false;
            if(sourceAfterAttack!=null)
            {
                if(!sourceControl.MayYield(sourceClip.id,elapsed,78,protectedUntil))return false;
                var queued=sourceAfterAttack;sourceAfterAttack=null;recoveryDecision=null;execution.Completed(sourceClip.id);
                sourceTravel?.EndClip();invocationFx?.End();sourceEvents?.Cancel();sourceClip=null;sourceEvents=null;sourceBranches=null;move=null;
                return BeginDecision(queued,0);
            }
            if(sourceControl.MayYield(sourceClip.id,elapsed,86,protectedUntil)
                &&(fractureTollPending||openingCastPending))
            {
                execution.Completed(sourceClip.id);sourceTravel?.EndClip();invocationFx?.End();sourceEvents?.Cancel();
                sourceClip=null;sourceEvents=null;sourceBranches=null;move=null;recoveryDecision=null;
                return TryContextualAction();
            }
            bool any=sourceControl.FlagOpen(sourceClip.id,elapsed,86)||sourceControl.FlagOpen(sourceClip.id,elapsed,78)||sourceControl.FlagOpen(sourceClip.id,elapsed,79);
            if(!any)return false;
            if(recoveryDecision==null){
                var direction=targetPoint-transform.position;direction.y=0;recoveryHeading=Vector3.SignedAngle(transform.forward,direction,Vector3.up);
                SetSourceDecisionContext();recoveryDecision=combat.ChooseDecision(Phase,Horizontal(transform.position,targetPoint),recoveryHeading,targetAvailable,previousSource,random,Time.time);
            }
            if(recoveryDecision==null)return false;
            int channel=recoveryDecision.Kind==AbbotSourceDecisionKind.Attack?86:recoveryDecision.Kind==AbbotSourceDecisionKind.Pivot?79:78;
            if(!sourceControl.MayYield(sourceClip.id,elapsed,channel,protectedUntil))return false;
            var next=recoveryDecision;recoveryDecision=null;execution.Completed(sourceClip.id);
            sourceTravel?.EndClip();invocationFx?.End();sourceEvents?.Cancel();sourceClip=null;sourceEvents=null;sourceBranches=null;move=null;
            return BeginDecision(next,recoveryHeading);
        }
        bool FollowupStillEligible(AbbotSourceTransition edge)
        {
            if(!targetAvailable||!target||target.IsDead())return false;
            var clip=combat.Find(edge.to);
            float distance=Horizontal(transform.position,targetPoint);
            return clip!=null&&AbbotRepertoirePolicy.CombatPhase(Phase)
                &&Phase>=(AbbotPhase)Enum.Parse(typeof(AbbotPhase),clip.minimumPhase)
                &&distance>=edge.minDistance&&distance<=edge.maxDistance
                &&distance>=clip.minDistance;
        }
        void BeginPendingSourceAttack(AbbotSourceClip clip,int chain,bool terminal,float seconds,float range,bool run,AbbotSourceDecision afterAttack)
        {
            sourceTravel?.EndClip("presentation-change");invocationFx?.End();sourceEvents?.Cancel();sourceClip=null;followup=null;sourceEvents=null;sourceBranches=null;move=null;sourceAfterAttack=null;
            maneuver=AbbotManeuver.None;maneuverClip=null;travelDecision=null;strafeSide=0;path=null;nextRoute=0;
            pendingSourceAttack=new PendingSourceAttack{Clip=clip,Target=target,Phase=Phase,Chain=chain,Terminal=terminal,Run=run,At=Time.time,Seconds=seconds,Range=range,LastMotionAt=Time.time,LastPosition=transform.position,AfterAttack=afterAttack};
            execution.Approached(clip.id);
            AbbotPlugin.Log("BA_ABBOT_SOURCE_APPROACH clip="+clip.id+" chain="+chain+" seconds="+seconds.ToString("F3")+" range="+range.ToString("F3")+" run="+run);
            TickPendingSourceAttack();
        }
        void TickPendingSourceAttack()
        {
            var pending=pendingSourceAttack;if(pending==null)return;
            bool valid=targetAvailable&&target&&target==pending.Target&&!target.IsDead()&&AbbotRepertoirePolicy.CombatPhase(Phase);
            if(!valid)
            {EndPendingSourceAttack("target-phase-or-stagger");return;}
            float distance=Horizontal(transform.position,targetPoint);
            bool timeout=Time.time-pending.At>=pending.Seconds;
            float moved=Horizontal(transform.position,pending.LastPosition);
            if(moved>.005f)pending.LastMotionAt=Time.time;pending.LastPosition=transform.position;
            var outcome=AbbotCombatExecution.Approach(valid,nativeStaggering,nav&&nav.Ready,distance<=pending.Range,timeout,Time.time-pending.LastMotionAt>.7f);
            if(outcome==AbbotApproachOutcome.Pause){pending.At+=Time.deltaTime;pending.LastMotionAt=Time.time;Stop();return;}
            if(outcome==AbbotApproachOutcome.Commit)
            {
                // The contact timeline starts only now. Movement time is not
                // replayed as missed attacks or used to redraw the decision.
                pendingSourceAttack=null;Stop();path=null;nextRoute=0;
                BeginSourceMove(pending.Clip,Time.time,pending.Chain,pending.Terminal,false,pending.AfterAttack);return;
            }
            if(outcome==AbbotApproachOutcome.Cancel){EndPendingSourceAttack("native-route-blocked");return;}
            MoveToward(targetPoint,false,pending.Run);
        }
        void EndPendingSourceAttack(string reason)
        {
            if(pendingSourceAttack!=null){execution.Cancelled(pendingSourceAttack.Clip.id,reason);AbbotPlugin.Log("BA_ABBOT_SOURCE_APPROACH_CANCEL clip="+pendingSourceAttack.Clip.id+" reason="+reason);}
            pendingSourceAttack=null;sourceAfterAttack=null;Stop();PoseIdle();path=null;nextRoute=0;nextMoveAt=Time.time;
        }
        bool TryStartReaction(bool tookDamage,bool staggerStarted)
        {
            float elapsed=Time.time-moveAt;
            // HP loss still produces its hurt audio, but no longer invents a
            // full-body interruption. A genuine native posture break owns the
            // interruption; retained source armor flags are not an invented
            // global immunity to damage or posture accumulation.
            if(!AbbotCombatExecution.DamageReaction(AbbotRepertoirePolicy.CombatPhase(Phase),staggerStarted,reactionMotion!=null))return false;
            string chosen="a000_006100";
            // The staged role bank must contain the actual source reaction.
            // Missing source data is never substituted with a looping gait.
            if(!visual.HasMotion(chosen))return false;
            unhandledNativeStagger=false;
            if(sourceClip!=null)execution.Cancelled(sourceClip.id,"native-stagger");
            recoveryDecision=null;sourceTravel?.EndClip("presentation-change");invocationFx?.End();sourceEvents?.Cancel();sourceClip=null;followup=null;sourceBranches=null;pendingSourceAttack=null;sourceAfterAttack=null;move=null;
            maneuver=AbbotManeuver.None;maneuverClip=null;travelDecision=null;
            reactionMotion=chosen;reactionAt=Time.time;reactionDuration=visual.MotionDuration(chosen);
            nextReactionAt=Time.time+reactionDuration;
            nextMoveAt=Time.time+reactionDuration;path=null;nextRoute=0;
            Stop();visual.SetMotion(chosen,0,1,.12f);
            AbbotPlugin.Log("BA_ABBOT_SOURCE_REACTION id="+chosen+" cause="+(staggerStarted?"native-stagger":"damage")+" duration="+reactionDuration.ToString("F3"));
            return true;
        }
        string DirectionalReaction()
        {
            Vector3 force=Vector3.zero;
            try{var last=LastHit?.GetValue(actor) as HitData;if(last!=null)force=last.m_dir;}catch{}
            force.y=0;
            if(force.sqrMagnitude>.001f){float side=Vector3.Dot(force.normalized,transform.right);if(side<-.45f)return "a000_006002";if(side>.45f)return "a000_006003";}
            return "a000_006001";
        }
        void TickReaction()
        {
            if(reactionMotion==null)return;
            Stop();float elapsed=Time.time-reactionAt;
            // Source reference displacement is not reapplied: native damage
            // knockback and the unchanged capsule remain physical authority.
            visual.SetMotion(reactionMotion,Mathf.Clamp01(elapsed/reactionDuration));
            if(elapsed>=reactionDuration)reactionMotion=null;
        }
        bool BeginDecision(AbbotSourceDecision choice,float heading)
        {
            switch(choice.Kind)
            {
                case AbbotSourceDecisionKind.Attack:
                    if(choice.Clip==null)return false;
                    execution.Selected(choice.Clip.id);
                    // The original Act increments its counter before queuing
                    // Approach_Act_Flex; ComboRepeat is not another Act choice.
                    combat.RecordActChoice();
                    AbbotSourceDecision afterAttack=choice.PostApproachSeconds>0?new AbbotSourceDecision{Kind=AbbotSourceDecisionKind.Approach,SourceAct=15,Seconds=choice.PostApproachSeconds,DesiredRange=choice.PostApproachRange,ApproachRun=true}:null;
                    if(choice.ApproachSeconds>0&&Horizontal(transform.position,targetPoint)>choice.DesiredRange)
                    {BeginPendingSourceAttack(choice.Clip,1,false,choice.ApproachSeconds,choice.DesiredRange,choice.ApproachRun,afterAttack);return true;}
                    BeginSourceMove(choice.Clip,Time.time,1,false,false,afterAttack);return true;
                case AbbotSourceDecisionKind.Pivot:
                    if(Mathf.Abs(heading)<AbbotRepertoirePolicy.PivotThresholdDegrees){FaceBounded(targetPoint,100);return false;}
                    return TryBeginManeuver(heading<0?AbbotManeuver.PivotLeft:AbbotManeuver.PivotRight);
                case AbbotSourceDecisionKind.Strafe:
                    // Source Number3 retains the orbiting side until an attack
                    // starts; it is not re-rolled every frame or every segment.
                    if(strafeSide==0)strafeSide=random.Next(2)==0?-1:1;
                    return TryBeginManeuver(strafeSide<0?AbbotManeuver.StrafeLeft:AbbotManeuver.StrafeRight,true,choice.Seconds);
                case AbbotSourceDecisionKind.Approach:
                case AbbotSourceDecisionKind.Retreat:
                    if(!nav||!nav.Ready)return false;
                    travelDecision=choice;travelDecisionAt=Time.time;travelDistance=0;travelLastPosition=transform.position;
                    travelLastMotionAt=Time.time;travelGoalAt=0;path=null;nextRoute=0;
                    TickTravelDecision();return true;
                default:return false;
            }
        }
        void TickTravelDecision()
        {
            if(travelDecision==null)return;
            if(!targetAvailable||!AbbotRepertoirePolicy.CombatPhase(Phase)||Time.time-travelDecisionAt>=travelDecision.Seconds){EndTravelDecision();return;}
            float moved=Horizontal(transform.position,travelLastPosition);travelDistance+=moved;
            if(moved>.005f)travelLastMotionAt=Time.time;
            travelLastPosition=transform.position;
            if(Time.time-travelLastMotionAt>.7f){EndTravelDecision();return;}
            float distance=Horizontal(transform.position,targetPoint);
            if(travelDecision.Kind==AbbotSourceDecisionKind.Approach)
            {
                // Plain Act22 and the queued Act15 approach preserve their
                // source goal. Reach clamping belongs only to a specifically
                // chosen attack waiting above, never to tactical travel itself.
                float stopRange=travelDecision.DesiredRange;
                if(distance<=stopRange){EndTravelDecision();return;}
                MoveToward(targetPoint,false,travelDecision.ApproachRun);return;
            }
            if(distance>=travelDecision.DesiredRange){EndTravelDecision();return;}
            if(Time.time>=travelGoalAt||Horizontal(transform.position,travelGoal)<.15f)
            {
                travelGoalAt=Time.time+.65f;var away=transform.position-targetPoint;away.y=0;
                if(away.sqrMagnitude<.001f)away=-transform.forward;
                if(!TryStraightGoal(away.normalized,Mathf.Min(2.8f,Mathf.Max(.6f,travelDecision.DesiredRange-distance)),out travelGoal)){EndTravelDecision();return;}
            }
            var direction=travelGoal-transform.position;direction.y=0;
            actor.m_walkSpeed=AbbotEncounterPolicy.WalkSpeed;actor.SetWalk(true);actor.SetRun(false);actor.SetMoveDir(direction.normalized);
            FaceBounded(targetPoint,100);visual.SetMotion("a000_002001",(travelDistance/AbbotEncounterPolicy.WalkStride)%1);
        }
        void EndTravelDecision()
        {
            travelDecision=null;Stop();PoseIdle();path=null;nextRoute=0;nextMoveAt=Time.time;
        }
        bool TryBeginManeuver(AbbotManeuver requested,bool longStrafe=false,float seconds=3.5f)
        {
            if(!AbbotRepertoirePolicy.CombatPhase(Phase)||!targetAvailable||nativeStaggering||move!=null||reactionMotion!=null||maneuver!=AbbotManeuver.None||AbbotPlugin.Repertoire==null)return false;
            bool pivot=requested==AbbotManeuver.PivotLeft||requested==AbbotManeuver.PivotRight;
            bool left=requested==AbbotManeuver.PivotLeft||requested==AbbotManeuver.StrafeLeft;
            if(!pivot&&requested!=AbbotManeuver.StrafeLeft&&requested!=AbbotManeuver.StrafeRight)return false;
            string id;
            if(pivot){var toTarget=targetPoint-transform.position;toTarget.y=0;float heading=Vector3.SignedAngle(transform.forward,toTarget,Vector3.up);bool large=AbbotRepertoirePolicy.LargePivot(heading);id=left?(large?"a000_005002":"a000_005000"):(large?"a000_005003":"a000_005001");}
            else id=AbbotRepertoirePolicy.TacticalStrafeMotion(left);
            var clip=AbbotPlugin.Repertoire.Find(id);
            if(clip==null||!clip.fullBodyAllowed||!visual.HasMotion(id)||clip.duration<=0||!pivot&&clip.strideMetres<=0||pivot&&clip.extractedYawEmbeddedInPose)return false;
            var goal=transform.position;
            if(!pivot&&!TryLateralGoal(left,out goal))return false;
            maneuver=requested;maneuverClip=clip;maneuverAt=Time.time;
            maneuverForward=transform.forward;maneuverForward.y=0;maneuverForward.Normalize();
            maneuverGoal=goal;maneuverLastPosition=transform.position;maneuverLastMotionAt=Time.time;maneuverTravel=0;
            maneuverSeconds=pivot?clip.duration:Mathf.Clamp(seconds,.5f,4);
            path=null;nextRoute=0;Stop();visual.SetMotion(id,0,1,.16f);
            AbbotPlugin.Log("BA_ABBOT_SOURCE_MANEUVER id="+id+" kind="+requested+" duration="+maneuverSeconds.ToString("F3")+" goal="+goal);
            return true;
        }
        bool TryLateralGoal(bool left,out Vector3 goal)
        {
            Vector3 side=transform.right*(left?-1:1);side.y=0;side.Normalize();
            return TryStraightGoal(side,2.8f,out goal);
        }
        bool TryStraightGoal(Vector3 direction,float maximum,out Vector3 goal)
        {
            goal=transform.position;if(!nav||!nav.Ready)return false;
            foreach(float fraction in new[]{1f,.72f,.43f})
            {
                float distance=maximum*fraction;var candidate=transform.position+direction*distance;
                if(!nav.TryProbePath(transform.position,candidate,out var corners)||corners==null||corners.Count<2)continue;
                // A strafe is a clear lateral corridor, not a route around a
                // column that would make the side-step face travel direction.
                bool straight=true;
                foreach(var corner in corners){var delta=corner-transform.position;delta.y=0;float along=Vector3.Dot(delta,direction);if(along<-.3f||along>distance+.3f||(delta-direction*along).magnitude>.4f){straight=false;break;}}
                int layer=LayerMask.NameToLayer("static_solid");
                if(!straight||layer<0)continue;
                float radius=AbbotEncounterPolicy.CapsuleRadius-.02f;
                if(Physics.CapsuleCast(transform.position+Vector3.up*(AbbotEncounterPolicy.CapsuleRadius+.02f),transform.position+Vector3.up*(AbbotEncounterPolicy.CapsuleHeight-AbbotEncounterPolicy.CapsuleRadius+.02f),radius,direction,out _,distance,1<<layer,QueryTriggerInteraction.Ignore))continue;
                goal=candidate;return true;
            }
            return false;
        }
        void TickManeuver()
        {
            if(maneuverClip==null||!targetAvailable||!AbbotRepertoirePolicy.CombatPhase(Phase)){EndManeuver();return;}
            float elapsed=Time.time-maneuverAt;
            bool pivot=maneuver==AbbotManeuver.PivotLeft||maneuver==AbbotManeuver.PivotRight;
            if(pivot)
            {
                Stop();float phase=Mathf.Clamp01(elapsed/maneuverClip.duration);
                // These source005poses have zero external Master yaw. The
                // separately extracted reference yaw is consumed once by the
                // native Character motor; source bones never get a second turn.
                var desired=Quaternion.AngleAxis(AbbotPlugin.Repertoire.SampleYaw(maneuverClip.id,phase),Vector3.up)*maneuverForward;
                actor.SetLookDir(desired);visual.SetMotion(maneuverClip.id,phase);
                if(elapsed>=maneuverClip.duration&&(Vector3.Angle(transform.forward,desired)<6||elapsed>=maneuverClip.duration+.4f))EndManeuver();
                return;
            }
            float travelled=Horizontal(transform.position,maneuverLastPosition);maneuverTravel+=travelled;
            if(travelled>.005f)maneuverLastMotionAt=Time.time;
            maneuverLastPosition=transform.position;
            float remaining=Horizontal(transform.position,maneuverGoal);
            if(elapsed>=maneuverSeconds||Time.time-maneuverLastMotionAt>.5f){EndManeuver();return;}
            if(remaining<.15f)
            {
                if(maneuverSeconds-elapsed<.35f||!TryLateralGoal(maneuver==AbbotManeuver.StrafeLeft,out maneuverGoal)){EndManeuver();return;}
                remaining=Horizontal(transform.position,maneuverGoal);
            }
            var direction=maneuverGoal-transform.position;direction.y=0;
            actor.m_walkSpeed=Mathf.Min(AbbotEncounterPolicy.WalkSpeed,Mathf.Max(.35f,remaining*2));
            actor.SetWalk(true);actor.SetRun(false);actor.SetMoveDir(direction.normalized);FaceBounded(targetPoint,100);
            visual.SetMotion(maneuverClip.id,(maneuverTravel/maneuverClip.strideMetres)%1);
        }
        void EndManeuver()
        {
            if(maneuverClip!=null&&(maneuverClip.id=="a000_005002"||maneuverClip.id=="a000_005003")&&Time.time-maneuverAt>=maneuverClip.duration)pivotCounterPending=true;
            maneuver=AbbotManeuver.None;maneuverClip=null;Stop();PoseIdle();path=null;nextRoute=0;nextMoveAt=Time.time;
        }
        void StartSourcePresentation()
        {
            sourceTravel?.BeginClip(sourceClip.id,moveAt,transform.rotation);UpdateSourceTravelLimit();
            sourceStarted=true;combat.RecordUse(sourceClip.id,Time.time,false);TryAttackVoice();var firstBell=sourceClip.events.FirstOrDefault(e=>e.kind=="bellPulse");if(firstBell!=null)effects.BellWarning(transform.position,move.Range,firstBell.time);
        }
        void UpdateSourceTravelLimit(){if(sourceClip!=null&&sourceBranches!=null)sourceTravel?.LimitClipTo(followup?.start??sourceBranches.NextBoundary(sourceClip.duration));}
        void DispatchSourceEvent(int index)
        {
            // Update/Bell stages only execute on the native owner. Keep the
            // gate here as well so no future presentation consumer can hit.
            if(!Authoritative||sourceClip==null||move==null)return;
            var cue=sourceClip.events[index];
            double occurred=AudioSettings.dspTime-Math.Max(0,Time.time-(moveAt+cue.time));
            if(AbbotGreatBellPolicy.IsInvocationSourceEvent(cue.kind))invocationFx?.Strike();
            switch(cue.kind)
            {
                case "staffHit":Speak(AbbotDialogueEvent.StaffEffort,++dialogueSequence,AudioSettings.dspTime);break;
                case "groundShatter":case "bellPulse":case "cast":AddBellPattern(cue,move,occurred);break;
                case "listenReveal":audio.Play("carriedBell",false,null,occurred);break;
            }
            AbbotPlugin.Log("BA_ABBOT_SOURCE_EVENT clip="+sourceClip.id+" id="+cue.id+" kind="+cue.kind+" sourceSeconds="+cue.time.ToString("F3"));
        }
        void TickSourceStaffContacts(float elapsed)
        {
            if(sourceClip==null||!Authoritative||elapsed<staffElapsed)return;
            var bank=AbbotPlugin.CombatShapes;var profile=bank.Find(sourceClip.id);
            if(profile==null)return;
            float prior=staffElapsed;
            var currentPosition=transform.position;var currentRotation=transform.rotation;
            var players=room.Players();
            // A stalled frame cannot inflict the whole historical swing at
            // once. Source velocity likewise discards stalled intervals.
            if(elapsed-prior>AbbotSourceTravel.MaximumInterval)prior=elapsed;
            for(int eventIndex=0;eventIndex<sourceClip.events.Length;eventIndex++)
            {
                var cue=sourceClip.events[eventIndex];if(cue.kind!="staffHit"||elapsed<cue.time||prior>cue.end)continue;
                float from=Mathf.Max(prior,cue.time),to=Mathf.Min(elapsed,cue.end);if(to<from)continue;
                if(!staffVictims.TryGetValue(eventIndex,out var victims))staffVictims.Add(eventIndex,victims=new HashSet<long>());
                if(!staffPews.TryGetValue(eventIndex,out var pews))staffPews.Add(eventIndex,pews=new HashSet<IDestructible>());
                int steps=Mathf.Max(1,Mathf.CeilToInt((to-from)/AbbotWeaponContact.MaximumSampleStep));
                var before=WorldStaff(bank,from,prior,elapsed,currentPosition,currentRotation);
                for(int step=1;step<=steps;step++)
                {
                    float at=Mathf.Lerp(from,to,(float)step/steps);var after=WorldStaff(bank,at,prior,elapsed,currentPosition,currentRotation);
                    foreach(var player in players)
                    {
                        if(victims.Contains(player.GetPlayerID()))continue;
                        TargetCapsule(player,out var a,out var b,out float radius);
                        if(!AbbotWeaponContact.SweptTouches(before,after,bank.weapon,a,b,radius)||!WeaponLineClear(player.GetCenterPoint()))continue;
                        victims.Add(player.GetPlayerID());Hit(player,move,true,true);execution.Contact(sourceClip.id);
                    }
                    HitSweptPews(before,after,bank.weapon,pews);
                    before=after;
                }
            }
            staffElapsed=elapsed;staffActorPosition=currentPosition;staffActorRotation=currentRotation;
        }
        AbbotStaffPose WorldStaff(AbbotCombatShapeBank bank,float at,float prior,float elapsed,Vector3 position,Quaternion rotation)
        {
            float fraction=elapsed>prior?Mathf.Clamp01((at-prior)/(elapsed-prior)):1;
            return bank.SampleStaff(sourceClip.id,at).Transform(Vector3.Lerp(staffActorPosition,position,fraction),Quaternion.Slerp(staffActorRotation,rotation,fraction));
        }
        static void TargetCapsule(Player player,out Vector3 a,out Vector3 b,out float radius)
        {
            var capsule=player.GetComponent<CapsuleCollider>();
            if(capsule&&capsule.enabled){var bounds=capsule.bounds;radius=Mathf.Max(bounds.extents.x,bounds.extents.z);float half=Mathf.Max(0,bounds.extents.y-radius);a=bounds.center-Vector3.up*half;b=bounds.center+Vector3.up*half;}
            else{radius=.3f;a=player.transform.position+Vector3.up*.3f;b=player.GetCenterPoint()+Vector3.up*.3f;}
        }
        bool WeaponLineClear(Vector3 targetCenter)
        {
            int mask=LayerMask.GetMask("static_solid","piece","terrain");
            return mask!=0&&!Physics.Linecast(actor.GetCenterPoint(),targetCenter,mask,QueryTriggerInteraction.Ignore);
        }
        void HitSweptPews(AbbotStaffPose before,AbbotStaffPose after,AbbotWeaponProfile weapon,HashSet<IDestructible> seen)
        {
            var bounds=new Bounds(before.Butt,Vector3.zero);bounds.Encapsulate(before.Tip);bounds.Encapsulate(after.Butt);bounds.Encapsulate(after.Tip);bounds.Expand(.6f);
            int mask=LayerMask.GetMask("Default","static_solid","Default_small","piece");
            int count=Physics.OverlapBoxNonAlloc(bounds.center,bounds.extents,staffObstacles,Quaternion.identity,mask,QueryTriggerInteraction.Ignore);
            for(int i=0;i<count;i++)
            {
                var collider=staffObstacles[i];if(!collider)continue;
                var destructible=collider.GetComponentInParent<IDestructible>();var component=destructible as Component;
                if(!component||!component.transform.IsChildOf(room.RoomRoot)||component.GetType().FullName!="BlackAbbeySixRooms.AbbeyBreakablePew"||seen.Contains(destructible))continue;
                bool contact=false;Vector3 point=collider.bounds.center;
                foreach(float fraction in StaffPewFractions)
                {
                    var sample=Vector3.Lerp(after.Butt,after.Tip,fraction);
                    if(AbbotPewContact.TryClosestPoint(collider,sample,out var closest)&&AbbotWeaponContact.SweptTouches(before,after,weapon,closest,closest,.01f)){point=closest;contact=true;break;}
                }
                if(!contact)continue;seen.Add(destructible);
                var hitData=new HitData{m_point=point,m_dir=transform.forward,m_pushForce=move.Push,m_hitType=HitData.HitType.EnemyHit};hitData.m_damage.m_blunt=move.Blunt*AbbotPlugin.DamageMultiplier;hitData.SetAttacker(actor);destructible.Damage(hitData);
            }
        }
        void AddGroundShatter(AbbotMoveSpec spec)
        {
            var center=transform.position+transform.forward*1.2f;
            waves.Add(new Wave{At=Time.time,Duration=1.25f,Radius=Mathf.Min(spec.Range,12),Center=center,Spec=spec});effects.Ring(center,Mathf.Min(spec.Range,12),1.25f,false);
        }
        void AddBellPattern(AbbotSourceEvent cue,AbbotMoveSpec spec,double occurred)
        {
            var pattern=AbbotPlugin.CombatShapes.FindPattern(sourceClip.id,cue.id);
            if(pattern==null){AbbotPlugin.Log("BA_ABBOT_BELL_SHAPE_MISSING clip="+sourceClip.id+" event="+cue.id);return;}
            float born=moveAt+cue.time,age=Mathf.Max(0,Time.time-born);
            var origin=transform.position;
            if(pattern.kind=="groundBurst")
            {
                // Ground resonance starts below the actual fitted staff tip,
                // rather than an unrelated circle centered on the actor.
                origin=AbbotPlugin.CombatShapes.SampleStaff(sourceClip.id,cue.time).Transform(transform).Tip;
                var local=room.RoomRoot.InverseTransformPoint(origin);
                var top=room.RoomRoot.TransformPoint(new Vector3(local.x,3.5f,local.z));
                int mask=LayerMask.GetMask("static_solid");
                origin.y=mask!=0&&Physics.Raycast(top,Vector3.down,out var ground,5,mask,QueryTriggerInteraction.Ignore)?ground.point.y:room.RoomRoot.position.y;
            }
            var sharedHits=new HashSet<long>();
            foreach(var emission in AbbotBellAttackPattern.Build(pattern,origin,transform.forward,aim))
            {
                // Descriptors are bounded/validated at module registration.
                // One cast's fan shares damage admission across its rays.
                if(bellHazards.Count>=64){AbbotPlugin.Log("BA_ABBOT_BELL_SHAPE_BUDGET");break;}
                // Keep source contact time during ordinary frame stalls. Do
                // not retroactively hit present players for an old expired
                // burst after an exceptional (>0.5s) stall.
                if(age>.5f&&age>AbbotBellAttackPattern.ActiveSeconds(emission))continue;
                bellHazards.Add(new BellHazard{Clip=sourceClip.id,Emission=emission,At=born,Previous=age>.15f?age-.15f:-1,Spec=spec,Hit=sharedHits});
                AbbotBellPatternFx.Spawn(transform,room,emission,born);
            }
            audio.Play("carriedBell",false,null,occurred);
        }
        void TickBellHazards()
        {
            if(bellHazards.Count==0)return;var players=room.Players();
            for(int i=bellHazards.Count-1;i>=0;i--)
            {
                var hazard=bellHazards[i];float elapsed=Time.time-hazard.At;
                float total=AbbotBellAttackPattern.ActiveSeconds(hazard.Emission);
                float sample=Mathf.Min(elapsed,total);
                foreach(var player in players)
                {
                    long id=player.GetPlayerID();if(hazard.Hit.Contains(id))continue;
                    TargetCapsule(player,out _,out _,out float radius);
                    if(!AbbotBellAttackPattern.Contains(hazard.Emission,player.transform.position,radius,sample,hazard.Previous))continue;
                    var center=hazard.Emission.Center+Vector3.up*.8f;
                    int mask=LayerMask.GetMask("static_solid","piece","terrain");
                    if(mask==0||Physics.Linecast(center,player.GetCenterPoint(),mask,QueryTriggerInteraction.Ignore))continue;
                    hazard.Hit.Add(id);Hit(player,hazard.Spec,false,true);execution.Contact(hazard.Clip);
                }
                hazard.Previous=elapsed;
                if(elapsed>=total)bellHazards.RemoveAt(i);
            }
        }
        void TryAttackVoice()
        {
            if(sourceClip!=null&&!sourceStarted)return;
            if(move==null||moveVoiceStarted)return;moveVoiceStarted=true;
            if(move.Move==AbbotMove.Listen)return;
            var kind=move.Move==AbbotMove.Slam?AbbotDialogueEvent.StaffSlam:move.Move==AbbotMove.Sweep?AbbotDialogueEvent.StaffSweep:move.Move==AbbotMove.Pulse?AbbotDialogueEvent.BellPulse:AbbotDialogueEvent.BellRupture;
            Speak(kind,moveDialogueId,moveDialogueAt);
        }
        bool Speak(AbbotDialogueEvent kind,long eventId,double occurred,float previousFraction=1,float currentFraction=1,bool ownKill=false)
        {
            if(AbbotDialoguePolicy.Introduction(kind)&&room.Opening.HasPlayed){AbbotPlugin.Log("BA_ABBOT_DIALOGUE_SKIP event="+kind+" occurrence="+eventId+" reason=room_opening_budget_used");return false;}
            double now=AudioSettings.dspTime;
            // Dialogue's historical HeardTarget field means target-available
            // in this explicitly hearing-disabled combat candidate.
            var context=new AbbotDialogueContext{Now=now,OccurredAt=Math.Min(now,occurred),WordsEndAt=audio.WordsEndAtDsp,Phase=Phase,EventId=eventId,AttackIndex=attackIndex,PlayerPresent=room&&room.Players().Length>0,HeardTarget=targetAvailable,CausedByBoss=ownKill,PreviousHealthFraction=previousFraction,HealthFraction=currentFraction};
            var decision=dialogue.CanSpeak(kind,context);
            if(!decision.Allowed){AbbotPlugin.Log("BA_ABBOT_DIALOGUE_SKIP event="+kind+" occurrence="+eventId+" reason="+decision.Reason);return false;}
            if(!audio.Request(decision.Group,decision.Priority,null,decision.Interrupt,decision.LatestStartDsp))return false;
            if(!dialogue.Commit(decision,Math.Max(0,audio.WordsEndAtDsp-now)))throw new InvalidOperationException("Successful dialogue must commit its exact admission");
            AbbotPlugin.Log("BA_ABBOT_DIALOGUE_CAUSE event="+kind+" occurrence="+eventId+" phase="+Phase+" attack="+attackIndex);return true;
        }
        bool InStaffArc(Vector3 point,AbbotMoveSpec spec){var d=point-transform.position;d.y=0;return d.magnitude<=spec.Range&&Vector3.Angle(transform.forward,d)<=spec.Arc*.5f;}
        void StaffHit(AbbotMoveSpec spec)
        {
            foreach(var p in room.Players())if(InStaffArc(p.transform.position,spec))Hit(p,spec,true,true);
            // Authoritative native pew damage, once per destructible, with the
            // real attacker. Stone walls have no IDestructible and are skipped.
            var seen=new HashSet<IDestructible>();
            foreach(var c in Physics.OverlapSphere(transform.position+transform.forward*1.5f,2,~0,QueryTriggerInteraction.Ignore)){
                if(c.GetComponentInParent<Character>())continue;var d=c.GetComponentInParent<IDestructible>();var owned=d as Component;
                if(!owned||!owned.transform.IsChildOf(room.RoomRoot)||owned.GetType().FullName!="BlackAbbeySixRooms.AbbeyBreakablePew"||seen.Contains(d))continue;
                if(!AbbotPewContact.TryClosestPoint(c,transform.position,out var arcPoint)||!InStaffArc(arcPoint,spec)
                    ||!AbbotPewContact.TryClosestPoint(c,visual.StaffTip.position,out var impactPoint))continue;
                seen.Add(d);
                var h=new HitData{m_point=impactPoint,m_dir=transform.forward,m_pushForce=spec.Push,m_hitType=HitData.HitType.EnemyHit};h.m_damage.m_blunt=spec.Blunt*AbbotPlugin.DamageMultiplier;h.SetAttacker(actor);d.Damage(h);
            }
        }
        void Hit(Player p,AbbotMoveSpec spec,bool block,bool dodge){if(AbbotCombatServices.NativeHit(actor,p,spec.Blunt*AbbotPlugin.DamageMultiplier,spec.Spirit*AbbotPlugin.DamageMultiplier,spec.Push,p.GetCenterPoint(),block,dodge))lastOwnHitAt=Time.time;}
        void ObservePlayerDeath()
        {
            var p=Player.m_localPlayer;if(p&&!p.IsDead()&&room.Eligible(p))playerWasAlive=true;
            if(p&&p.IsDead()&&playerWasAlive){playerWasAlive=false;if(Time.time-lastOwnHitAt<=4&&OwnNativeKill(p)){pendingPlayerKill=true;playerKillDue=Time.time+.45f;killDialogueId=++dialogueSequence;killDialogueAt=AudioSettings.dspTime;}}
            if(pendingPlayerKill&&Time.time>=playerKillDue){pendingPlayerKill=false;Speak(AbbotDialogueEvent.PlayerKill,killDialogueId,killDialogueAt,1,1,true);}
        }
        bool OwnNativeKill(Player player)
        {
            // Match the native death attribution, not merely a recently sent
            // attack that may have been blocked or dodged. Unknown means silence.
            if(!actor||LastHit==null)return false;try{return (LastHit.GetValue(player) as HitData)?.GetAttacker()==actor;}catch{return false;}
        }
        void AddPulse(AbbotMoveSpec spec,double? occurred=null)
        {
            var center=transform.position;audio.Play("carriedBell",false,null,occurred);
            waves.Add(new Wave{At=Time.time,Duration=1.9f,Radius=spec.Range,Center=center,Spec=spec});effects.Ring(center,spec.Range,1.9f,false);
        }
        void TickWaves()
        {
            for(int i=waves.Count-1;i>=0;i--){var w=waves[i];float radius=Mathf.Clamp01((Time.time-w.At)/w.Duration)*w.Radius;
                foreach(var p in room.Players())if(!w.Hit.Contains(p.GetPlayerID())&&AbbotEncounterPolicy.Crossing(w.Last,radius,Horizontal(w.Center,p.transform.position))){w.Hit.Add(p.GetPlayerID());Hit(p,w.Spec,false,true);}
                w.Last=radius;if(Time.time-w.At>=w.Duration)waves.RemoveAt(i);}
        }
        void ScheduleRuptures(AbbotMoveSpec spec,double? occurred=null)
        {
            var direction=aim-transform.position;direction.y=0;if(direction.sqrMagnitude<.1f)direction=transform.forward;direction.Normalize();
            foreach(float angle in new[]{-22f,0,22f}){var d=Quaternion.AngleAxis(angle,Vector3.up)*direction;ruptures.Add(new Rupture{At=Time.time+.9f,Center=transform.position,Direction=d,Spec=spec});effects.Rupture(transform.position,d,spec.Range,2.8f);}
            audio.Play("carriedBell",false,null,occurred);
        }
        void TickRuptures()
        {
            var struck=new HashSet<long>();
            for(int i=ruptures.Count-1;i>=0;i--){var r=ruptures[i];if(Time.time<r.At)continue;
                foreach(var p in room.Players()){var d=p.transform.position-r.Center;d.y=0;float along=Vector3.Dot(d,r.Direction),side=(d-r.Direction*along).magnitude;if(along>=0&&along<=r.Spec.Range&&side<=.65f&&struck.Add(p.GetPlayerID()))Hit(p,r.Spec,false,true);}ruptures.RemoveAt(i);}
        }
        void BeginRitual()
        {
            if(!bound||finalBar||Phase==AbbotPhase.Ritual||Phase==AbbotPhase.Dying||Phase==AbbotPhase.Defeated)return;
            sourceTravel?.EndClip("presentation-change");invocationFx?.End();
            openingCastPending=fractureTollPending=pivotCounterPending=false;recoveryDecision=null;bellHazards.Clear();ClearBellPatternFx();
            sourceEvents?.Cancel();sourceClip=null;followup=null;sourceBranches=null;pendingSourceAttack=null;sourceAfterAttack=null;move=null;reactionMotion=null;maneuver=AbbotManeuver.None;maneuverClip=null;travelDecision=null;waves.Clear();ruptures.Clear();effects.Clear();Stop();Phase=AbbotPhase.Ritual;phaseAt=Time.time;ritualStep=AbbotRitualStep.Kneel;stepAt=Time.time;path=null;
            Speak(AbbotDialogueEvent.CollapseEffort,++dialogueSequence,AudioSettings.dspTime);visual.SetEmber(1.2f);AbbotPlugin.Log("BA_ABBOT_LAST_TOLL_BEGIN health="+actor.GetHealth());
        }
        void NextStep(AbbotRitualStep step){ritualStep=step;stepAt=Time.time;hit=false;path=null;nextRoute=0;}
        Vector3 RitualGoal {get{var g=combat.Data.ritual.goal;return room.RoomRoot.TransformPoint(new Vector3(g[0],g[1],g[2]));}}
        Vector3 RitualFacing=>Quaternion.AngleAxis(combat.Data.ritual.facingYaw,room.RoomRoot.up)*room.RoomRoot.forward;
        void AlignRitualContact()
        {
            // The navigation approach has already arrived within4.5cm. Settle
            // only this ceremonial actor root, never a hand/Weapon/source curve.
            var goal=RitualGoal;var rotation=Quaternion.LookRotation(RitualFacing,room.RoomRoot.up);transform.SetPositionAndRotation(goal,rotation);
            var body=GetComponent<Rigidbody>();if(body){body.position=goal;body.rotation=rotation;body.linearVelocity=Vector3.zero;body.angularVelocity=Vector3.zero;}actor.SetLookDir(RitualFacing);
        }
        void TickRitual()
        {
            float elapsed=Time.time-stepAt;deafened.Tick(p=>room&&room.Eligible(p));
            switch(ritualStep){
                // The selected source bank has a staff-supported hunch rather
                // than a true kneel. Hold the loaded part, then use its recovery;
                // preserve the accepted ritual timing and mechanics explicitly.
                case AbbotRitualStep.Kneel:Stop();visual.SetMotion("kneel_pant",.74f*Mathf.Clamp01(elapsed/3));if(elapsed>=AbbotEncounterPolicy.RitualKneelSeconds){Speak(AbbotDialogueEvent.LastToll,++dialogueSequence,AudioSettings.dspTime);NextStep(AbbotRitualStep.Rise);}break;
                case AbbotRitualStep.Rise:Stop();visual.SetMotion("stand",.74f+.26f*Mathf.Clamp01(elapsed/AbbotEncounterPolicy.RitualRiseSeconds));if(elapsed>=AbbotEncounterPolicy.RitualRiseSeconds)NextStep(AbbotRitualStep.Stumble);break;
                case AbbotRitualStep.Stumble:
                    var goal=RitualGoal;
                    if(Horizontal(transform.position,goal)>.045f){MoveToward(goal,true);}
                    else{Stop();Face(goal+RitualFacing);PoseIdle();if(AudioSettings.dspTime>=audio.VoiceAvailableAtDsp&&Vector3.Angle(transform.forward,RitualFacing)<3){AlignRitualContact();NextStep(AbbotRitualStep.Strike);}}break;
                case AbbotRitualStep.Strike:
                    var ceremony=combat.Data.ritual;Stop();Face(RitualGoal+RitualFacing);visual.SetMotion("great_bell_strike",Mathf.Clamp01(elapsed/ceremony.duration));
                    if(!hit&&elapsed>=ceremony.hitSeconds){hit=true;audio.StopVoice();audio.Play("greatBell",true,room.BellContact);room.RingGreatBell();waveAt=Time.time;lastWaveRadius=0;effects.Ring(room.BellContact,44,AbbotEncounterPolicy.RitualWaveSeconds,true);}
                    if(hit)TickRitualWave();if(elapsed>=ceremony.duration)NextStep(AbbotRitualStep.Wave);break;
                case AbbotRitualStep.Wave:Stop();PoseIdle();TickRitualWave();if(Time.time-waveAt>=AbbotEncounterPolicy.RitualWaveSeconds)NextStep(AbbotRitualStep.Refill);break;
                case AbbotRitualStep.Refill:Stop();PoseIdle();if(elapsed>=AbbotEncounterPolicy.RitualRefillSeconds&&guard.RefillLastToll()){finalBar=true;Phase=AbbotPhase.LastToll;phaseAt=Time.time;nextMoveAt=Time.time+1.2f;visual.SetEmber(1.4f);AbbotPlugin.Log("BA_ABBOT_LAST_TOLL_REFILLED current="+actor.GetHealth()+" max="+actor.GetMaxHealth());}break;
            }
        }
        void TickRitualWave()
        {
            float radius=AbbotEncounterPolicy.RitualRadius(Time.time-waveAt);foreach(var p in room.Players())if(AbbotEncounterPolicy.Crossing(lastWaveRadius,radius,Horizontal(room.BellContact,p.transform.position)))deafened.Contact(p);lastWaveRadius=radius;
        }
        void MoveToward(Vector3 goal,bool stumble,bool run=false)
        {
            if(!nav||!nav.Ready){Stop();PoseIdle();return;}
            // Final small approach retains the resized native capsule. The
            // strike stands in front of the platform, outside the low clapper.
            if(stumble&&Horizontal(transform.position,goal)<=.65f){var direct=goal-transform.position;direct.y=0;int layer=LayerMask.NameToLayer("static_solid");float radius=AbbotEncounterPolicy.CapsuleRadius-.02f;
                if(layer>=0&&!Physics.CapsuleCast(transform.position+Vector3.up*(AbbotEncounterPolicy.CapsuleRadius+.02f),transform.position+Vector3.up*(AbbotEncounterPolicy.CapsuleHeight-AbbotEncounterPolicy.CapsuleRadius+.02f),radius,direct.normalized,out _,direct.magnitude,1<<layer,QueryTriggerInteraction.Ignore)){Walk(direct,true,Mathf.Clamp(direct.magnitude*2,.35f,AbbotEncounterPolicy.StumbleSpeed));return;}}
            if(Time.time>=nextRoute){nextRoute=Time.time+1;pathIndex=0;if(!nav.TryProbePath(transform.position,goal,out path)||path.Count==0){path=null;Stop();PoseIdle();if(stumble&&Time.time-stepAt>10&&Time.time-voiceAt>10){AbbotPlugin.Log("BA_ABBOT_RITUAL_ROUTE_WAIT; protected actor, no teleport. "+nav.Snapshot());voiceAt=Time.time;}return;}}
            if(path==null||path.Count==0||pathIndex>=path.Count){Stop();PoseIdle();return;}
            while(pathIndex<path.Count-1&&Horizontal(transform.position,path[pathIndex])<.45f)pathIndex++;
            var d=path[pathIndex]-transform.position;d.y=0;if(d.sqrMagnitude<.02f){Stop();PoseIdle();return;}Walk(d,stumble,-1,run);
        }
        void Walk(Vector3 direction,bool stumble,float approachSpeed=-1,bool run=false)
        {
            // Both combat and the slower ceremonial approach use the actual
            // source walk002300, phased by its measured4.006633m full stride.
            //008300 is a one-shot stumble, not a traversing walk loop.
            var fast=run&&!stumble?AbbotPlugin.Repertoire?.Find("a000_002100"):null;
            bool fastGait=fast!=null&&fast.fullBodyAllowed&&fast.strideMetres>0&&fast.duration>0&&visual.HasMotion(fast.id);
            float stride=fastGait?fast.strideMetres:AbbotEncounterPolicy.WalkStride;
            if(Time.time-lastWalkTime<.25f&&walkWasStumble==stumble&&walkWasRun==fastGait)walkPhase=(walkPhase+Horizontal(transform.position,lastWalkPosition)/stride)%1;
            else if(walkWasStumble!=stumble||walkWasRun!=fastGait)walkPhase=0;
            lastWalkPosition=transform.position;lastWalkTime=Time.time;walkWasStumble=stumble;walkWasRun=fastGait;
            actor.m_walkSpeed=approachSpeed>0?approachSpeed:stumble?AbbotEncounterPolicy.StumbleSpeed:AbbotEncounterPolicy.WalkSpeed;
            if(fastGait)actor.m_runSpeed=fast.strideMetres/fast.duration;
            actor.SetWalk(!fastGait);actor.SetMoveDir(direction.normalized);actor.SetRun(fastGait);actor.SetLookDir(direction.normalized);visual.SetMotion(fastGait?fast.id:"walk",walkPhase);
        }
        void PoseIdle(){idlePhase=(idlePhase+Time.deltaTime/visual.MotionDuration("idle"))%1;visual.SetMotion("idle",idlePhase);}
        void Stop(){if(actor){actor.SetMoveDir(Vector3.zero);actor.SetRun(false);actor.SetWalk(false);}}
        void Face(Vector3 point){var d=point-transform.position;d.y=0;if(d.sqrMagnitude>.001f)actor.SetLookDir(d.normalized);}
        void FaceBounded(Vector3 point,float degreesPerSecond)
        {
            var desired=point-transform.position;desired.y=0;if(desired.sqrMagnitude<=.001f)return;
            // Native Character rotation already bounds yaw and eases near the
            // target. Supplying another tiny per-frame yaw double-eases it.
            actor.m_turnSpeed=Mathf.Min(nativeTurnSpeed,Mathf.Max(0,degreesPerSecond));
            actor.SetLookDir(desired.normalized);
        }
        static float Horizontal(Vector3 a,Vector3 b){a.y=b.y=0;return Vector3.Distance(a,b);}
        bool PermitDeath()
        {
            if(!bound||!Authoritative||allowDeath)return true;
            if(Phase==AbbotPhase.Cancelled||Phase==AbbotPhase.Defeated)return true;
            if(Phase==AbbotPhase.Waiting||Phase==AbbotPhase.Ritual||!finalBar){if(actor.GetHealth()<=.1f){actor.SetHealth(.1f);if(started&&Phase!=AbbotPhase.Ritual)BeginRitual();}return false;}
            if(actor.GetHealth()<=0&&Phase!=AbbotPhase.Dying)BeginDying();
            return Phase!=AbbotPhase.Dying;
        }
        void BeginDying()
        {
            sourceTravel?.EndClip("presentation-change");invocationFx?.End();
            recoveryDecision=null;bellHazards.Clear();ClearBellPatternFx();
            Phase=AbbotPhase.Dying;phaseAt=Time.time;actor.SetHealth(.1f);sourceEvents?.Cancel();sourceClip=null;followup=null;sourceBranches=null;pendingSourceAttack=null;sourceAfterAttack=null;move=null;reactionMotion=null;maneuver=AbbotManeuver.None;maneuverClip=null;travelDecision=null;waves.Clear();ruptures.Clear();effects.Clear();Stop();deafened.Dispose();Speak(AbbotDialogueEvent.Death,++dialogueSequence,AudioSettings.dspTime);audio.Play("carriedBell",true);deathEnds=Time.time+visual.MotionDuration("death");visual.SetMotion("death",0);AbbotPlugin.Log("BA_ABBOT_FINAL_DEATH_PRESENTATION");
        }
        void TickDying()
        {
            Stop();visual.SetMotion("death",Mathf.Clamp01((Time.time-phaseAt)/visual.MotionDuration("death")));visual.SetEmber(Mathf.Clamp01(1-(Time.time-phaseAt)/4));
            if(Time.time<deathEnds||AudioSettings.dspTime<audio.DeathVoiceEndsAtDsp)return;
            // Freeze the actual final skinned presentation before native death
            // removes the living actor. The room owns this inert corpse until
            // its completed dungeon is left/reset/unloaded; no despawn timer.
            visual.SetMotion("death",1,1,0);room.KeepCorpse(visual);
            Phase=AbbotPhase.Defeated;allowDeath=true;guard.Release();audio.FinishBellTails();room.Complete();actor.m_deathAnimation=false;actor.SetHealth(0);CheckDeath.Invoke(actor,null);AbbotPlugin.Log("BA_ABBOT_DEFEATED final bar only; native death, room unlocked/victory; corpse retained by room; rewards remain TBD.");
        }
        public void Cancel(string reason)
        {
            recoveryDecision=null;bellHazards.Clear();ClearBellPatternFx();
            if(!bound||Phase==AbbotPhase.Cancelled)return;Phase=AbbotPhase.Cancelled;sourceTravel?.EndClip("presentation-change");invocationFx?.End();sourceEvents?.Cancel();sourceClip=null;followup=null;sourceBranches=null;pendingSourceAttack=null;sourceAfterAttack=null;reactionMotion=null;maneuver=AbbotManeuver.None;maneuverClip=null;travelDecision=null;Stop();guard?.Release();deafened?.Dispose();if(effects)effects.Clear();if(audio)audio.Release();if(room)room.ActorGone(this);bound=false;
            AbbotPlugin.Log("BA_ABBOT_CANCELLED "+reason);if(view&&view.IsValid()&&view.IsOwner()&&ZNetScene.instance)ZNetScene.instance.Destroy(gameObject);else Object.Destroy(gameObject);
        }
        public string Status()=>"BA_ABBOT_STATE room="+(room?room.InstanceId:"none")+" phase="+Phase+" ritual="+ritualStep+" hp="+(actor?actor.GetHealth():0)+" final="+finalBar+" nav="+(nav&&nav.Ready)+" move="+(move?.Move.ToString()??"none")+" targeting=direct-combat-test target="+targetAvailable+" reaction="+(reactionMotion??"none")+" maneuver="+maneuver+" travel="+(travelDecision?.Kind.ToString()??"none")+" execution="+Newtonsoft.Json.JsonConvert.SerializeObject(execution.Snapshot())+" motor="+MotorStatus()+" audio="+(audio?Newtonsoft.Json.JsonConvert.SerializeObject(audio.Snapshot()):"unavailable");
        void ClearBellPatternFx(){foreach(var fx in GetComponentsInChildren<AbbotBellPatternFx>(true))if(fx)Object.Destroy(fx.gameObject);}
        string MotorStatus()
        {
            // Read-only, command-triggered diagnostics. Never force movement,
            // native animation tags or root transforms.
            var animator=visual?.Animator;var body=GetComponent<Rigidbody>();
            bool initialized=animator&&animator.isInitialized;
            return Newtonsoft.Json.JsonConvert.SerializeObject(new{
                position=new[]{transform.position.x,transform.position.y,transform.position.z},
                forward=new[]{transform.forward.x,transform.forward.y,transform.forward.z},
                velocity=body?new[]{body.linearVelocity.x,body.linearVelocity.y,body.linearVelocity.z}:null,
                kinematic=body&&body.isKinematic,nativeAnimatorEnabled=animator&&animator.enabled,
                nativeAnimatorInitialized=initialized,nativeStateTag=initialized?animator.GetCurrentAnimatorStateInfo(0).tagHash:0,
                sampledMotion=visual?.CurrentMotion,navigation=nav?nav.Snapshot():null,sourceTravel=sourceTravel?sourceTravel.Snapshot():null,grounding=visual?.GroundingSnapshot(),scarfCloth=visual?.ScarfClothSnapshot()});
        }
        void OnDestroy(){invocationFx?.Release();deafened?.Dispose();if(audio)audio.Release();visual?.Dispose();if(room)room.ActorGone(this);bound=false;}
        static AbbotEncounterController Own(Character c)=>c?c.GetComponent<AbbotEncounterController>():null;
        // Native CharacterAnimEvent forwards Animator.deltaPosition even when
        // applyRootMotion is false. Source poses own presentation; requested
        // native Character movement owns travel. Suppress only this callback,
        // only for a bound sampled Abbot. Keep native Animator state evaluation
        // and Character movement/turning/stagger gates, including other actors.
        [HarmonyPatch(typeof(CharacterAnimEvent),"OnAnimatorMove")]
        static class SourceRootMotionGate
        {
            [HarmonyPrefix] static bool Prefix(CharacterAnimEvent __instance)
            {
                var own=__instance?__instance.GetComponentInParent<AbbotEncounterController>():null;
                return !own||!own.bound||own.visual==null||!own.visual.IsDrivingSourceMotion;
            }
        }
        [HarmonyPatch(typeof(Character),"CheckDeath")]
        static class DeathGate{[HarmonyPrefix,HarmonyPriority(Priority.First+10)]static bool Prefix(Character __instance)=>Own(__instance)?.PermitDeath()??true;}
        [HarmonyPatch(typeof(Character),"OnDeath")]
        static class DirectDeathGate{[HarmonyPrefix,HarmonyPriority(Priority.First+10)]static bool Prefix(Character __instance)=>Own(__instance)?.PermitDeath()??true;}
        [HarmonyPatch(typeof(Character),"RPC_Damage")]
        static class PresentationDamageGate{[HarmonyPrefix]static bool Prefix(Character __instance){var own=Own(__instance);return !own||!own.bound||!own.Authoritative||own.Phase!=AbbotPhase.Dying;}}
        [HarmonyPatch(typeof(Character),nameof(Character.ApplyDamage))]
        static class PresentationDirectDamageGate{[HarmonyPrefix]static bool Prefix(Character __instance){var own=Own(__instance);return !own||!own.bound||!own.Authoritative||own.Phase!=AbbotPhase.Dying;}}
    }
}
