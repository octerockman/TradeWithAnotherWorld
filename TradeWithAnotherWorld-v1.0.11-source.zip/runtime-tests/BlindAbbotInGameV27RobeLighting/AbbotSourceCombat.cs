using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace BlackAbbey.BlindAbbot
{
    [Serializable] public sealed class AbbotSourceEvent { public string id,kind,evidence;public int sourceEventIndex;public float time,end; }
    [Serializable] public sealed class AbbotSourceTransition { public string to,condition,evidence;public float start,end,minDistance,maxDistance,weight,sourceTime;public int sourceEffect;public bool final,startsAct,approach,approachRun;public float approachSeconds,approachRange; }
    [Serializable] public sealed class AbbotSourceWindow {public int sourceEffect,sourceEventIndex;public float start,end,sourceTime,sourceEnd;public float decisionTime=-1;public float DecisionAt=>decisionTime>=0?decisionTime:start;}
    [Serializable] public sealed class AbbotSourceStateEffect {public string motion,evidence;public int effect,sourceEventIndex;public float start,end,seconds;}
    [Serializable] public sealed class AbbotSourceClip
    {
        public string id,role,move,minimumPhase;public float duration,recovery,entryWeight,minDistance,maxDistance,interruptBefore,prepareSeconds;
        public bool requiresHeard;public AbbotSourceEvent[] events;public AbbotSourceTransition[] transitions;public AbbotSourceWindow[] windows;
        public AbbotMoveSpec Spec()
        {
            var spec=AbbotEncounterPolicy.Spec((AbbotMove)Enum.Parse(typeof(AbbotMove),move));
            spec.Motion=id;spec.Duration=duration;spec.Recovery=recovery;spec.HitAt=events.Length>0?events[0].time:duration;return spec;
        }
    }
    [Serializable] public sealed class AbbotSourceCombatData
    {
        public string schema,adaptationNote;public FileRecord sourceNative,sourceEvents;
        public string[] excluded;public AbbotSourceClip[] clips;
        public AbbotRitualContact ritual;
        public AbbotOriginalAiData sourceAI;
        public AbbotSourceStateEffect[] sourceStates;
    }
    [Serializable] public sealed class AbbotSourceCooldown {public string clip;public float seconds,reducedWeight;public int act,weightAct;}
    [Serializable] public sealed class AbbotSourceAct {public int act;public string clip;}
    [Serializable] public sealed class AbbotOriginalAiData {public string schema,combatTargetPolicy;public float fittedDistanceScale;public AbbotSourceAct[] sourceActMap;public AbbotSourceCooldown[] cooldowns;}
    public enum AbbotSourceDecisionKind { Attack, Pivot, Strafe, Approach, Retreat }
    public sealed class AbbotSourceDecision {public AbbotSourceDecisionKind Kind;public AbbotSourceClip Clip;public int SourceAct;public float Seconds,DesiredRange,ApproachSeconds,PostApproachSeconds,PostApproachRange;public bool ApproachRun;}
    [Serializable] public sealed class AbbotRitualContact {public string motion,sourcePolicy;public float duration,hitSeconds,facingYaw;public float[] goal,contactRoom,sourceSocket;}

    // Recovered c4800 Lua supplies original decisions/SpEffect successors; TAE
    // supplies contact/trigger times. Fitted reach, custom phases/ritual and
    // great-bell spell substitution remain an explicit Abbey adaptation.
    public sealed class AbbotSourceCombat
    {
        static readonly string[] Removed={"a000_003001","a000_003022","a000_003028","a000_003032","a000_003034","a000_003036"};
        static readonly HashSet<string> EventKinds=new HashSet<string>{"staffHit","groundShatter","bellPulse","cast","listenReveal"};
        readonly Dictionary<string,AbbotSourceClip> byId;
        readonly AbbotMotionRepertoire repertoire;
        readonly AbbotCombatShapeBank shapes;
        readonly Dictionary<string,float> lastUsed=new Dictionary<string,float>(StringComparer.Ordinal);
        readonly Dictionary<int,float> stateExpires=new Dictionary<int,float>();
        string observedMotion;float observedMotionAt=-1;
        float decisionClock;int attackCount;
        public AbbotSourceCombatData Data{get;}
        AbbotSourceCombat(AbbotSourceCombat source){Data=source.Data;byId=source.byId;repertoire=source.repertoire;shapes=source.shapes;}
        // The plugin holds validated shared data; timers/counters belong to one
        // actor/session and must never leak into another boss or dungeon run.
        public AbbotSourceCombat CreateSession()=>new AbbotSourceCombat(this);
        public AbbotSourceCombat(AbbotSourceCombatData data,MotionBank motions,AbbotMotionRepertoire repertoire=null,AbbotCombatShapeBank shapes=null)
        {
            this.repertoire=repertoire;this.shapes=shapes;
            Data=data??throw new InvalidDataException("Missing source combat data");
            if(data.schema!="blind-abbot.source-combat.v1"||motions==null||data.sourceNative?.sha256!=motions.sourceNative?.sha256||data.clips==null||data.clips.Length<5||data.clips.Length>64||data.excluded==null||Removed.Any(id=>!data.excluded.Contains(id)))throw new InvalidDataException("Source combat authority/inventory mismatch");
            byId=new Dictionary<string,AbbotSourceClip>(StringComparer.Ordinal);
            if(data.sourceAI!=null&&(data.sourceAI.schema!="blind-abbot.original-ai-adaptation.v1"||!Finite(data.sourceAI.fittedDistanceScale)||data.sourceAI.fittedDistanceScale<=0||data.sourceAI.fittedDistanceScale>4||data.sourceAI.cooldowns==null||data.sourceAI.sourceActMap==null))throw new InvalidDataException("Invalid original AI adaptation");
            if(data.sourceAI?.cooldowns!=null)foreach(var cooldown in data.sourceAI.cooldowns)if(cooldown==null||string.IsNullOrEmpty(cooldown.clip)||!Finite(cooldown.seconds)||cooldown.seconds<0||cooldown.seconds>120||!Finite(cooldown.reducedWeight)||cooldown.reducedWeight<0||cooldown.reducedWeight>20||cooldown.act<1||cooldown.act>100||cooldown.weightAct<1||cooldown.weightAct>100)throw new InvalidDataException("Invalid source cooldown");
            var ceremony=data.ritual;
            if(ceremony==null||ceremony.motion!="a000_003002"||motions.aliases==null||!motions.aliases.TryGetValue("great_bell_strike",out var alias)||alias!=ceremony.motion||!motions.clips.Any(c=>c.name==alias&&Math.Abs(c.duration-ceremony.duration)<.001f)||!Finite(ceremony.hitSeconds)||ceremony.hitSeconds<=0||ceremony.hitSeconds>=ceremony.duration||ceremony.facingYaw!=90||!Vector(ceremony.goal)||!Vector(ceremony.contactRoom)||!Vector(ceremony.sourceSocket)||Math.Abs(ceremony.goal[0])>2||ceremony.goal[1]<0||ceremony.goal[1]>1||ceremony.goal[2]<23||ceremony.goal[2]>29)throw new InvalidDataException("Invalid ceremonial source/contact contract");
            foreach(var clip in data.clips)
            {
                var motion=motions.clips.FirstOrDefault(c=>c.name==clip?.id);
                if(clip==null||string.IsNullOrWhiteSpace(clip.id)||byId.ContainsKey(clip.id)||Removed.Contains(clip.id)||data.excluded.Contains(clip.id)||motion==null||!Finite(clip.duration)||Math.Abs(clip.duration-motion.duration)>.04f||!Finite(clip.recovery)||clip.recovery<0||clip.recovery>8||!Finite(clip.entryWeight)||clip.entryWeight<0||clip.entryWeight>20||!Finite(clip.minDistance)||!Finite(clip.maxDistance)||clip.minDistance<0||clip.maxDistance<clip.minDistance||clip.maxDistance>40||clip.events==null||clip.events.Length>64||clip.transitions==null||clip.transitions.Length>16)throw new InvalidDataException("Invalid source combat clip: "+clip?.id);
                if(!Enum.TryParse<AbbotMove>(clip.move,out var kind)||kind==AbbotMove.None||!Enum.TryParse<AbbotPhase>(clip.minimumPhase,out var phase)||!CombatPhase(phase))throw new InvalidDataException("Invalid source combat role: "+clip.id);
                var ids=new HashSet<string>();float prior=-1;
                foreach(var e in clip.events){if(e==null||string.IsNullOrWhiteSpace(e.id)||!ids.Add(e.id)||!EventKinds.Contains(e.kind)||string.IsNullOrWhiteSpace(e.evidence)||!Finite(e.time)||!Finite(e.end)||e.time<0||e.time<prior||e.end<e.time||e.end>clip.duration+.01f)throw new InvalidDataException("Invalid source contact event: "+clip.id);prior=e.time;}
                if(!Finite(clip.interruptBefore)||clip.interruptBefore<0||clip.interruptBefore>clip.duration)throw new InvalidDataException("Invalid source commitment: "+clip.id);
                if(!Finite(clip.prepareSeconds)||clip.prepareSeconds<0||clip.prepareSeconds>1.5f)throw new InvalidDataException("Invalid authored entry preparation: "+clip.id);
                if(clip.windows==null||clip.windows.Length>32)throw new InvalidDataException("Missing source opportunities: "+clip.id);
                foreach(var w in clip.windows)if(w==null||!Finite(w.start)||!Finite(w.end)||!Finite(w.sourceTime)||!Finite(w.sourceEnd)||!Finite(w.DecisionAt)||w.DecisionAt<0||w.DecisionAt>w.start||w.start<0||w.start>clip.duration||w.end<w.start||w.end>clip.duration+.01f||w.sourceTime<0||w.sourceEnd<w.sourceTime)throw new InvalidDataException("Invalid source opportunity: "+clip.id);
                byId.Add(clip.id,clip);
            }
            foreach(var clip in data.clips)foreach(var t in clip.transitions)
            {
                float lastImpact=clip.events.Length==0?0:clip.events.Max(e=>e.end);
                if(t==null||!byId.ContainsKey(t.to)||t.to==clip.id||!Finite(t.start)||!Finite(t.end)||t.start<lastImpact||t.end<t.start||t.end>clip.duration+.01f||!Finite(t.weight)||t.weight<=0||t.weight>20||t.minDistance<0||t.maxDistance<t.minDistance||t.maxDistance>40||(t.condition!="heard"&&t.condition!="target")||string.IsNullOrWhiteSpace(t.evidence))throw new InvalidDataException("Invalid source combat edge: "+clip.id);
            }
            if(data.sourceStates!=null)foreach(var state in data.sourceStates)
                if(state==null||string.IsNullOrEmpty(state.motion)||!motions.clips.Any(m=>m.name==state.motion)||(state.effect!=10610&&state.effect!=10611&&state.effect!=10612)||!Finite(state.start)||!Finite(state.end)||!Finite(state.seconds)||state.start<0||state.end<state.start||state.seconds<=0||state.seconds>30||string.IsNullOrEmpty(state.evidence))throw new InvalidDataException("Invalid source combat state");
        }
        public static AbbotSourceCombat Load(string path,MotionBank motions,AbbotMotionRepertoire repertoire=null,AbbotCombatShapeBank shapes=null)
        {
            if(new FileInfo(path).Length>2*1024*1024)throw new InvalidDataException("Oversized combat graph");
            var data=JsonConvert.DeserializeObject<AbbotSourceCombatData>(File.ReadAllText(path),new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MetadataPropertyHandling=MetadataPropertyHandling.Ignore,MaxDepth=24});return new AbbotSourceCombat(data,motions,repertoire,shapes);
        }
        public AbbotSourceClip Find(string id)=>byId.TryGetValue(id,out var clip)?clip:null;
        public void RecordUse(string id,float now,bool countAct=true){if(Find(id)==null||!Finite(now))return;lastUsed[id]=now;decisionClock=now;if(countAct&&attackCount<int.MaxValue)attackCount++;}
        public void RecordActChoice(){if(attackCount<int.MaxValue)attackCount++;}
        public float Passed(string id,float now)=>lastUsed.TryGetValue(id,out var used)?Math.Max(0,now-used):float.PositiveInfinity;
        public int AttackCount=>attackCount;

        // AddSpEffect TAE windows are application opportunities, not effect
        // lifetimes. Actual10610/11/12 PARAM durations are5/10/10seconds.
        // Re-entering a gait/loop applies once at its crossed source marker;
        // leaving the gait does not silently erase the remaining effect.
        public void ObserveMotion(string motion,float elapsed,float now)
        {
            if(!Finite(elapsed)||elapsed<0||!Finite(now))return;
            bool entered=motion!=observedMotion||elapsed<observedMotionAt-.001f;
            float prior=entered?-1:observedMotionAt;
            if(Data.sourceStates!=null)foreach(var state in Data.sourceStates)
                if(state.motion==motion&&state.start>prior&&state.start<=elapsed)
                    stateExpires[state.effect]=Math.Max(stateExpires.TryGetValue(state.effect,out var until)?until:float.NegativeInfinity,now-Math.Max(0,elapsed-state.start)+state.seconds);
            observedMotion=motion;observedMotionAt=elapsed;
        }
        public bool SourceEffectActive(int effect,float now)=>Finite(now)&&stateExpires.TryGetValue(effect,out float until)&&now<until;

        // These are explicitly named Abbey encounter contexts. None enters
        // the ordinary random act table. Parent owns one-shot milestone gates.
        public AbbotSourceDecision ChooseContextual(string id,AbbotPhase phase,float distance,bool targetAvailable,float now)
        {
            if(!targetAvailable||!CombatPhase(phase)||!Finite(distance)||distance<0||!Finite(now))return null;
            var clip=Find(id);if(clip==null)return null;
            int act;
            if(id=="a000_003000"){if(phase!=AbbotPhase.Service)return null;act=1;}
            else if(id=="a000_003023"){if(phase!=AbbotPhase.Fracture)return null;act=35;}
            else if(id=="a000_003021"){if(Passed(id,now)<30||distance>PhysicalStartRange(id))return null;act=0;}
            else return null;
            return new AbbotSourceDecision{Kind=AbbotSourceDecisionKind.Attack,Clip=clip,SourceAct=act};
        }

        // One source-weighted roll chooses combat OR repositioning. Original
        // source phase flags are intentionally mapped to the existing Abbey
        // phases; no original health/ritual transition is imported.
        public AbbotSourceDecision ChooseDecision(AbbotPhase phase,float distance,float signedHeading,bool targetAvailable,string previous,Random random,float now)
        {
            if(!CombatPhase(phase)||!targetAvailable||!Finite(distance)||distance<0||!Finite(signedHeading)||!Finite(now))return null;
            decisionClock=now;
            if(Data.sourceAI==null){var legacy=ChooseEntry(phase,distance,true,previous,random);return legacy==null?Approach():new AbbotSourceDecision{Kind=AbbotSourceDecisionKind.Attack,Clip=legacy};}
            float scale=Data.sourceAI.fittedDistanceScale,d=distance/scale,a=Math.Abs(signedHeading);bool enhanced=phase!=AbbotPhase.Service;
            var weights=new Dictionary<int,float>();
            Action<int,float> set=(act,w)=>weights[act]=w;
            if(enhanced){
                if(a>=150){set(5,50);set(9,30);set(15,phase==AbbotPhase.LastToll?0:10);}
                else if(d>=17){set(8,30);set(11,30);set(16,35);set(22,40);}
                else if(d>=11){set(2,10);set(4,10);set(5,10);set(6,10);set(8,30);set(11,30);set(16,30);set(22,30);set(24,25);}
                else if(d>=6){set(4,10);set(5,10);set(6,10);set(7,20);set(8,30);set(9,20);set(11,20);set(12,20);set(16,20);set(24,25);}
                else {set(4,20);set(5,20);set(9,30);set(10,50);set(11,20);set(15,10);set(17,35);set(23,50);}
            }else{
                if(a>=150){set(15,35);set(21,55);}
                else if(a>=80){set(15,10);set(21,30);set(signedHeading<0?5:4,60);}
                else if(d>=20){set(2,20);set(6,20);set(11,40);set(22,20);}
                else if(d>=13){set(2,10);set(6,30);set(11,30);set(22,30);set(24,25);}
                else if(d>=5){set(2,10);set(4,10);set(5,10);set(6,25);set(7,20);set(11,30);set(22,10);set(23,30);set(24,25);}
                else {set(4,30);set(5,20);set(10,40);set(11,10);set(15,15);set(17,25);set(23,50);}
            }
            if(SourceEffectActive(10610,now)||SourceEffectActive(10611,now))set(23,0);
            if(SourceEffectActive(10610,now)||SourceEffectActive(10612,now))set(24,0);
            if(weights.ContainsKey(23))weights[23]*=attackCount<=3?1:attackCount<=5?1.2f:attackCount<=8?1.5f:2;
            if(weights.ContainsKey(24))weights[24]*=attackCount<=3?1:attackCount<=5?1.5f:attackCount<=8?3:4;
            // Preserve the literal ordered SetCoolTime assignments, including
            // the source's repeated writes to Act2 using other act weights.
            // Act2 remains excluded by Jesse; do not silently repair source Lua.
            foreach(var cooldown in Data.sourceAI.cooldowns){
                int destination=cooldown.act;
                if(destination==0)continue;
                float originalWeight=weights.TryGetValue(cooldown.weightAct,out var value)?value:0;
                weights[destination]=originalWeight<=0?0:Passed(cooldown.clip,now)<=cooldown.seconds?cooldown.reducedWeight:originalWeight;
            }
            // This source suppression occurs after its cooldown assignments.
            if(d<3){set(5,0);set(11,0);}
            var choices=new List<AbbotSourceDecision>();var choiceWeights=new List<float>();
            foreach(var pair in weights){
                if(pair.Value<=0)continue;
                if(pair.Key>=21&&pair.Key<=24){var kind=pair.Key==21?AbbotSourceDecisionKind.Pivot:pair.Key==22?AbbotSourceDecisionKind.Approach:pair.Key==23?AbbotSourceDecisionKind.Retreat:AbbotSourceDecisionKind.Strafe;choices.Add(new AbbotSourceDecision{Kind=kind,SourceAct=pair.Key,Seconds=3,DesiredRange=pair.Key==21?60:pair.Key==22?6.5f*scale:0,ApproachRun=pair.Key==22||pair.Key==23});choiceWeights.Add(pair.Value);continue;}
                var act=Data.sourceAI.sourceActMap.FirstOrDefault(x=>x.act==pair.Key);var clip=act==null?null:Find(act.clip);
                if(!EntryEligible(clip,phase,distance,pair.Key))continue;
                float weight=pair.Value;
                if(weight<=0)continue;
                choices.Add(new AbbotSourceDecision{Kind=AbbotSourceDecisionKind.Attack,Clip=clip,SourceAct=pair.Key});choiceWeights.Add(weight);
            }
            if(choices.Count==0)return Approach();
            double pick=random.NextDouble()*choiceWeights.Sum();int selected=choices.Count-1;for(int i=0;i<choices.Count;i++){pick-=choiceWeights[i];if(pick<=0){selected=i;break;}}
            var decision=choices[selected];
            // Source action parameters are drawn after selecting that act;
            // discarded candidates must not consume duration/range draws.
            if(decision.SourceAct==22)decision.Seconds=random.Next(2,5);
            if(decision.SourceAct==23)decision.DesiredRange=random.Next(5,7)*scale;
            if(decision.Kind==AbbotSourceDecisionKind.Strafe){attackCount=0;decision.Seconds=random.Next(3,5);}
            if(decision.Kind==AbbotSourceDecisionKind.Attack)ConfigureApproach(decision,phase,distance,signedHeading,random);
            return decision;
        }
        static bool HasEntryApproach(int act)=>act==4||act==5||act==6||act==7||act==10||act==11||act==12;
        bool EntryEligible(AbbotSourceClip clip,AbbotPhase phase,float distance,int act)=>PhaseEligible(clip,phase,true)&&Finite(distance)&&distance>=clip.minDistance;
        float PhysicalStop(AbbotSourceClip clip)=>Math.Max(.6f,PhysicalStartRange(clip.id)-AbbotSourceReach.ContactSkin);
        public float PhysicalStartRange(string id){var clip=Find(id);return clip==null?0:AbbotSourceReach.StartRange(clip,repertoire?.Find(id),shapes);}
        public bool StartEligible(AbbotSourceClip clip,AbbotPhase phase,float distance,bool targetAvailable)=>PhaseEligible(clip,phase,targetAvailable)&&Finite(distance)&&distance>=clip.minDistance&&distance<=PhysicalStartRange(clip.id);
        void ConfigureApproach(AbbotSourceDecision choice,AbbotPhase phase,float distance,float heading,Random random)
        {
            float scale=Data.sourceAI.fittedDistanceScale,radius=AbbotEncounterPolicy.CapsuleRadius/scale,d=distance/scale;
            if(HasEntryApproach(choice.SourceAct)){
                float sourceStop=choice.SourceAct==4?7:choice.SourceAct==5||choice.SourceAct==7?8.5f:choice.SourceAct==6?18:choice.SourceAct==10?4:choice.SourceAct==11?16:7.8f;
                choice.ApproachRun=d>=sourceStop-radius+10||(phase!=AbbotPhase.Service&&d>=sourceStop-radius);
                choice.ApproachSeconds=choice.SourceAct==4||choice.SourceAct==5||choice.SourceAct==11?.5f:choice.SourceAct==12?(choice.ApproachRun?8:4):1;
                // Preserve the original goal lifetime/run choice. Its stop is
                // bounded by the unchanged hit shape plus measured fitted
                // travel up to the first contact, with the existing .1m skin.
                choice.DesiredRange=Math.Max(.6f,Math.Min(sourceStop*scale-AbbotEncounterPolicy.CapsuleRadius,PhysicalStop(choice.Clip)));
            }
            // Act15 contains no pre-approach call. Its one conditional queued
            // approach is AFTER3016, in the left90degree sector, chance60%.
            if(choice.SourceAct==15&&heading>=-135&&heading<=-45&&d<=7-radius&&random.Next(1,101)<=60){choice.PostApproachSeconds=random.Next(2,6);choice.PostApproachRange=6.5f*scale;}
        }
        static AbbotSourceDecision Approach()=>new AbbotSourceDecision{Kind=AbbotSourceDecisionKind.Approach,SourceAct=22,Seconds=3,DesiredRange=2.8f};
        public AbbotSourceClip ChooseEntry(AbbotPhase phase,float distance,bool heard,string previous,Random random)
        {
            if(!heard)return null; // Serialized legacy name: current target availability in combat-test mode.
            var choices=Data.clips.Where(c=>c.entryWeight>0&&Eligible(c,phase,distance,heard)).ToArray();
            return Weighted(choices,c=>c.entryWeight,random);
        }
        public AbbotSourceTransition ChooseFollowup(AbbotSourceClip from,AbbotPhase phase,float distance,bool heard,int chainClips,Random random,float now=float.NaN)
        {
            if(Finite(now))decisionClock=now;
            if(from==null||!heard)return null;
            if(Data.sourceAI!=null){
                float d=distance/Data.sourceAI.fittedDistanceScale;
                foreach(var group in from.transitions.GroupBy(t=>t.sourceEffect).OrderBy(g=>g.Min(t=>t.start))){
                    // Compatibility entry point only: one source opportunity.
                    // Runtime evaluates each later window at its own time.
                    return ChooseFollowupAt(from,phase,distance,heard,group.Key,random,now);
                }return null;
            }
            // An opening after a completed sequence is deliberate. Escalation
            // changes choices, not playback speed or every recovery window.
            if(random.NextDouble()>(phase==AbbotPhase.Service?.38:phase==AbbotPhase.Fracture?.56:.70))return null;
            return Weighted(from.transitions.Where(t=>distance>=t.minDistance&&distance<=t.maxDistance&&Eligible(Find(t.to),phase,distance,heard)).ToArray(),t=>t.weight,random);
        }
        public AbbotSourceTransition ChooseFollowupAt(AbbotSourceClip from,AbbotPhase phase,float distance,bool targetAvailable,int sourceEffect,Random random,float now=float.NaN)
        {
            if(Finite(now))decisionClock=now;
            if(from==null||!targetAvailable||!CombatPhase(phase)||!Finite(distance)||distance<0||random==null)return null;
            int destination=SourceDestination(sourceEffect,phase,distance/Data.sourceAI.fittedDistanceScale,random);
            if(destination==0)return null;
            string id="a000_"+destination.ToString("D6");
            var edge=from.transitions.FirstOrDefault(t=>t.sourceEffect==sourceEffect&&t.to==id);
            // A removed, unsupported or physically unreachable chosen successor
            // ends this opportunity. Never redraw to force a longer combo.
            var clip=Find(id);
            if(edge==null||distance<edge.minDistance||distance>edge.maxDistance||!PhaseEligible(clip,phase,true))return null;
            // Source conditions choose the attack; native geometry/contact
            // decides whether it hits. Do not insert a15second walk between
            // ComboRepeat clips or discard a selected attack for moving range.
            var selected=new AbbotSourceTransition{to=edge.to,condition=edge.condition,evidence=edge.evidence,start=edge.start,end=edge.end,minDistance=edge.minDistance,maxDistance=edge.maxDistance,weight=edge.weight,sourceTime=edge.sourceTime,sourceEffect=edge.sourceEffect,final=edge.final,startsAct=edge.startsAct};
            return selected;
        }
        int SourceDestination(int effect,AbbotPhase phase,float d,Random random)
        {
            bool enhanced=phase!=AbbotPhase.Service;Func<int> roll=()=>random.Next(1,101);Func<bool> closeCast=()=>{int localRoll=roll();return Passed("a000_003011",decisionClock)>=30&&localRoll>50;};
            if(effect==-7)return phase==AbbotPhase.LastToll?3025:0;
            if(effect==10607){int r=roll();return d<25?(r>60?3022:r>30?3027:0):0;}
            if(effect==10620)return d>10&&roll()<=50?3020:3028;
            if(effect==10608)return d>7?3030:0;
            if(effect==10601)return d<=30?3034:0;
            if(effect==10606){float radius=AbbotEncounterPolicy.CapsuleRadius/Data.sourceAI.fittedDistanceScale,enchantment=phase==AbbotPhase.LastToll?6:0;return enhanced&&d>=7-radius&&d<=enchantment+22-radius?3031:0;}
            if(effect==10602){if(d>45)return 0;if(d<=4)return closeCast()?3011:roll()>50?3024:3012;if(d<6)return roll()>30?3012:roll()>50?3014:3001;int r=roll();return r>70?3014:r>40?3001:0;}
            if(effect==10605){if(d>45)return 0;int r=roll();if(d<=5)return Passed("a000_003011",decisionClock)>=30&&r>50?3011:r>40?3024:3012;if(d<9)return r<60?3012:3029;if(d<18)return r<50?3014:3029;return 0;}
            if(effect==10603){if(d>45)return 0;int r=roll();if(d<=4){if(closeCast())return 3011;int q=roll();return q>66?3026:q>33?3013:3017;}if(d<6)return roll()>30?3013:roll()>50?3015:3001;return r>70?3015:r>40?3001:0;}
            if(effect==10600){int r=roll();if(enhanced&&r>40){if(d>45)return 0;if(d<4)return closeCast()?3011:3024;if(Passed("a000_003020",decisionClock)>=30)return 3020;return roll()>50?3014:3001;}if(d<4)return closeCast()?3011:3024;return r>50?(roll()>50?3014:3001):0;}
            if(effect==10604){int r=roll();if(enhanced&&r>40){if(d<=4)return 3026;if(d>6&&d<15)return roll()>40?3029:roll()>50?3015:3001;return 0;}int normalRoll=roll();if(d<=3)return 3026;return normalRoll>60?(roll()>50?3015:3001):0;}
            if(effect==16456){int r=roll();if(enhanced)return r>50&&Passed("a000_003020",decisionClock)>=20?3020:r>30?3008:3027;return d<=8?(r>30?3009:0):3008;}
            return 0;
        }
        // Abbey effects keep their fitted hit shapes. Original distance bands
        // may choose an approach, but cannot make a16m rupture reach24m.
        public static bool Eligible(AbbotSourceClip c,AbbotPhase phase,float distance,bool heard)=>c!=null&&CombatPhase(phase)&&phase>=(AbbotPhase)Enum.Parse(typeof(AbbotPhase),c.minimumPhase)&&distance>=c.minDistance&&distance<=c.maxDistance&&distance<=c.Spec().Range&&(!c.requiresHeard||heard);
        static bool PhaseEligible(AbbotSourceClip c,AbbotPhase phase,bool targetAvailable)=>c!=null&&CombatPhase(phase)&&phase>=(AbbotPhase)Enum.Parse(typeof(AbbotPhase),c.minimumPhase)&&(!c.requiresHeard||targetAvailable);
        static bool CombatPhase(AbbotPhase phase)=>phase==AbbotPhase.Service||phase==AbbotPhase.Fracture||phase==AbbotPhase.LastToll;
        static T Weighted<T>(T[] values,Func<T,float> weight,Random random) where T:class {if(values.Length==0)return null;double pick=random.NextDouble()*values.Sum(v=>weight(v));foreach(var value in values){pick-=weight(value);if(pick<=0)return value;}return values[values.Length-1];}
        static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
        static bool Vector(float[] value)=>value!=null&&value.Length==3&&value.All(Finite);
    }
}
