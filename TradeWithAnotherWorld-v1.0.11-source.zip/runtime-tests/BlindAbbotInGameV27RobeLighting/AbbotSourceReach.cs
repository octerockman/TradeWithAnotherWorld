using System;
using UnityEngine;

namespace BlackAbbey.BlindAbbot
{
    // Admission follows the fitted staff's active source timeline, rather
    // than treating the actor origin as a three-metre weapon. The native
    // collision motor alone supplies physical source travel at runtime.
    public static class AbbotSourceReach
    {
        public const float ContactSkin=.1f;
        public const float AdmissionTargetRadius=.30f;
        public static float StartRange(AbbotSourceClip clip,AbbotRepertoireClip path,AbbotCombatShapeBank shapes=null)
        {
            if(clip==null)return 0;
            var sampled=shapes?.Find(clip.id);
            if(sampled!=null&&path!=null&&path.id==clip.id&&path.fullBodyAllowed)
            {
                if(shapes.startRanges.TryGetValue(clip.id,out var cached))return cached;
                float reachable=0;bool hasStaff=false;
                foreach(var e in sampled.events)
                {
                    if(e.kind!="staffHit")continue;hasStaff=true;
                    int steps=Math.Max(1,(int)Math.Ceiling((e.end-e.start)/AbbotWeaponContact.MaximumSampleStep));
                    var start=AbbotSourceTravel.Sample(path,0);
                    for(int i=0;i<=steps;i++)
                    {
                        float t=e.start+(e.end-e.start)*i/steps;var p=shapes.SampleStaff(clip.id,t);var root=AbbotSourceTravel.Sample(path,t);
                        var delta=new Vector3((float)(root.Right-start.Right),0,(float)(root.Forward-start.Forward));
                        foreach(var part in shapes.weapon.segments)
                        {
                            var a=Vector3.Lerp(p.Butt,p.Tip,part.fromFraction)+delta;var b=Vector3.Lerp(p.Butt,p.Tip,part.toFraction)+delta;
                            float r=part.radius+AdmissionTargetRadius;
                            int divisions=Math.Max(1,(int)Math.Ceiling((b-a).magnitude/.025f));
                            for(int k=0;k<=divisions;k++)
                            {
                                var point=Vector3.Lerp(a,b,(float)k/divisions);
                                if(point.y< -part.radius||point.y>2f+part.radius)continue;
                                // Conservative standing-capsule admission. The
                                // actual player capsule and height are checked
                                // in full3D by the live swept contact consumer.
                                if(Math.Abs(point.x)>r)continue;
                                float z=point.z+(float)Math.Sqrt(Math.Max(0,r*r-point.x*point.x));
                                reachable=Math.Max(reachable,z);
                            }
                        }
                    }
                }
                if(hasStaff){shapes.startRanges[clip.id]=reachable;return reachable;}
            }
            // Spell admission retains the already approved range; it never
            // invents reach from a non-contact staff flourish.
            float radius=Math.Min(clip.maxDistance,clip.Spec().Range);
            if(!Finite(radius)||radius<=0)return 0;
            if(path==null||path.id!=clip.id||!path.fullBodyAllowed||path.trajectory==null||path.trajectory.Length==0)return radius;
            float contact=float.PositiveInfinity;
            if(clip.events!=null)foreach(var e in clip.events)
                if(e!=null&&Damaging(e.kind)&&Finite(e.time)&&e.time>=0)contact=Math.Min(contact,e.time);
            if(!Finite(contact))return radius;
            var at=AbbotSourceTravel.Sample(path,contact);
            double lateralSquared=at.Right*at.Right,radiusSquared=(double)radius*radius;
            if(lateralSquared>radiusSquared)return 0;
            double forward=at.Forward+Math.Sqrt(Math.Max(0,radiusSquared-lateralSquared));
            return Finite(forward)?(float)Math.Max(0,forward):0;
        }
        public static bool Damaging(string kind)=>kind=="staffHit"||kind=="groundShatter"||kind=="bellPulse"||kind=="cast";
        static bool Finite(double value)=>!double.IsNaN(value)&&!double.IsInfinity(value);
    }
}
