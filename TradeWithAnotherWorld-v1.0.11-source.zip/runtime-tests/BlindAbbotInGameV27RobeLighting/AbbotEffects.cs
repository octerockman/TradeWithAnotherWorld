using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using Object=UnityEngine.Object;

namespace BlackAbbey.BlindAbbot
{
    // All temporary geometry has an encounter owner, a bounded lifetime and no
    // colliders. No textures, rooms or global lighting are changed.
    public sealed class AbbotEffects:MonoBehaviour
    {
        const int RingSegments=64;
        static readonly Vector3[] RingDirections=BuildDirections();
        static readonly int[] RingIndices=BuildIndices();
        static Vector3[] BuildDirections(){var values=new Vector3[RingSegments];for(int i=0;i<RingSegments;i++){float a=i*Mathf.PI*2/RingSegments;values[i]=new Vector3(Mathf.Cos(a),0,Mathf.Sin(a));}return values;}
        static int[] BuildIndices(){var values=new int[RingSegments*6];for(int i=0;i<RingSegments;i++){int k=i*6,v=i*2,w=((i+1)%RingSegments)*2;values[k]=v;values[k+1]=w;values[k+2]=v+1;values[k+3]=v+1;values[k+4]=w;values[k+5]=w+1;}return values;}
        readonly List<Effect> effects=new List<Effect>();Material material;AbbotRoomBridge room;
        sealed class Effect { public GameObject Root;public Mesh Mesh;public LineRenderer Line;public Vector3 Center,Forward;public float Start,Duration,Radius;public bool Ring,Ritual,Listening,Warning; public Vector3[] Vertices; public Color[] Colors; }
        public void Initialize(AbbotRoomBridge owner)
        {
            room=owner;var shader=Shader.Find("Sprites/Default")??Shader.Find("Unlit/Color");
            if(!shader)throw new InvalidOperationException("Owned warning shader unavailable");
            material=new Material(shader){name="BA Abbot amber warning"};
        }
        float Floor(Vector3 p)
        {
            var local=room.RoomRoot.InverseTransformPoint(p);var top=room.RoomRoot.TransformPoint(new Vector3(local.x,3.5f,local.z));
            int layer=LayerMask.NameToLayer("static_solid");
            if(layer>=0&&Physics.Raycast(top,Vector3.down,out var hit,5,1<<layer,QueryTriggerInteraction.Ignore))return hit.point.y+.035f;
            return room.RoomRoot.position.y+.04f;
        }
        public void Ring(Vector3 center,float radius,float duration,bool ritual)
        {
            var go=new GameObject(ritual?"BA Last Toll amber wave":"BA carried bell pulse");go.transform.SetParent(transform,false);
            var mesh=new Mesh{name="BA bounded pulse"};go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=material;renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;
            var e=new Effect{Root=go,Mesh=mesh,Center=center,Start=Time.time,Duration=duration,Radius=radius,Ring=true,Ritual=ritual,Vertices=new Vector3[RingSegments*2],Colors=new Color[RingSegments*2]};
            // Fixed topology and per-effect buffers: no frame-local arrays or index rebuilds.
            mesh.MarkDynamic();mesh.vertices=e.Vertices;mesh.colors=e.Colors;mesh.triangles=RingIndices;effects.Add(e);
        }
        // Listen never marks a floor hazard: a small pale ripple at head height
        // has no collision/damage and does not depict its full40m sensing range.
        public void ListenTell(Vector3 center,float duration)
        {
            Ring(center,2.2f,duration,false);var e=effects[effects.Count-1];e.Listening=true;e.Root.name="BA Listen pale head ripple (non-damaging)";
        }
        // Red-orange floor perimeter stays still during bell preparation. Its
        // later expanding wave is still the only damaging bell presentation.
        public void BellWarning(Vector3 center,float radius,float duration)
        {
            Ring(center,radius,duration,false);var e=effects[effects.Count-1];e.Warning=true;e.Root.name="BA damaging bell perimeter warning";
        }
        public void Rupture(Vector3 origin,Vector3 direction,float length,float duration)
        {
            var go=new GameObject("BA floor rupture warning");go.transform.SetParent(transform,false);var line=go.AddComponent<LineRenderer>();line.sharedMaterial=material;line.useWorldSpace=true;line.positionCount=17;line.startWidth=.1f;line.endWidth=.25f;line.shadowCastingMode=ShadowCastingMode.Off;
            var e=new Effect{Root=go,Line=line,Center=origin,Forward=direction.normalized,Start=Time.time,Duration=duration,Radius=length};effects.Add(e);
            for(int i=0;i<17;i++){var p=origin+e.Forward*(length*i/16);p.y=Floor(p);line.SetPosition(i,p);}
        }
        void Update()
        {
            for(int n=effects.Count-1;n>=0;n--){var e=effects[n];float t=(Time.time-e.Start)/e.Duration;if(t>=1||!room){DestroyEffect(e);effects.RemoveAt(n);continue;}
                var color=e.Listening?new Color(.68f,.73f,.75f,(1-t)*.3f):new Color(1,e.Ritual?.52f:.16f,e.Ritual?.055f:.01f,e.Warning?.2f+.55f*t:Mathf.Clamp01((1-t)*1.4f));
                if(e.Ring){float r=e.Warning?e.Radius:Mathf.Max(.15f,e.Radius*t),band=e.Listening?.035f:e.Warning?.1f:.3f;
                    for(int i=0;i<RingSegments;i++){var direction=RingDirections[i];for(int j=0;j<2;j++){var p=e.Center+direction*(r+(j==0?-band:band));p.y=e.Listening?e.Center.y:Floor(p);e.Vertices[i*2+j]=transform.InverseTransformPoint(p);e.Colors[i*2+j]=color;}}
                    e.Mesh.vertices=e.Vertices;e.Mesh.colors=e.Colors;e.Mesh.RecalculateBounds();
                }else{float intensity=t<.32f?.35f+.2f*Mathf.Sin(t*70):1;e.Line.startColor=e.Line.endColor=new Color(1,.12f,.008f,intensity*(1-t));}
            }
        }
        static void DestroyEffect(Effect e){if(e.Root)Object.Destroy(e.Root);if(e.Mesh)Object.Destroy(e.Mesh);}
        public void Clear(){foreach(var e in effects)DestroyEffect(e);effects.Clear();}
        void OnDestroy(){Clear();if(material)Object.Destroy(material);}
    }
}
