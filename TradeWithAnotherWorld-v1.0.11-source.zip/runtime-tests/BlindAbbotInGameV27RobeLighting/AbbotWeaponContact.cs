using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using UnityEngine;

namespace BlackAbbey.BlindAbbot
{
    [Serializable] public sealed class AbbotWeaponSegment { public float fromFraction,toFraction,radius; }
    [Serializable] public sealed class AbbotWeaponProfile { public float[] butt,tip;public float length;public AbbotWeaponSegment[] segments; }
    [Serializable] public sealed class AbbotStaffSample { public float time;public float[] butt,tip; }
    [Serializable] public sealed class AbbotContactShapeEvent {public string id,kind,provenance;public float start,end;public AbbotSourceShapeBinding[] sourceBindings;}
    [Serializable] public sealed class AbbotSourceShapeBinding {public int eventIndex;public string type;public float start,end;public Dictionary<string,object> parameters;}
    [Serializable] public sealed class AbbotContactShapeClip { public string id;public float duration;public AbbotStaffSample[] samples;public AbbotContactShapeEvent[] events; }
    public struct AbbotStaffPose
    {
        public Vector3 Butt,Tip;
        public AbbotStaffPose(Vector3 butt,Vector3 tip){Butt=butt;Tip=tip;}
        public AbbotStaffPose Transform(Transform actor)=>new AbbotStaffPose(actor.TransformPoint(Butt),actor.TransformPoint(Tip));
        public AbbotStaffPose Transform(Vector3 origin,Quaternion heading)=>new AbbotStaffPose(origin+heading*Butt,origin+heading*Tip);
        public static AbbotStaffPose Lerp(AbbotStaffPose a,AbbotStaffPose b,float t)=>new AbbotStaffPose(Vector3.Lerp(a.Butt,b.Butt,t),Vector3.Lerp(a.Tip,b.Tip,t));
    }
    [Serializable] public sealed class AbbotCombatShapeBank
    {
        public string schema,sampleSpace;public string[] excluded;public AbbotWeaponProfile weapon;public AbbotContactShapeClip[] clips;public AbbotBellPattern[] patterns;
        Dictionary<string,AbbotContactShapeClip> lookup;
        internal readonly Dictionary<string,float> startRanges=new Dictionary<string,float>(StringComparer.Ordinal);
        public static AbbotCombatShapeBank Load(string path)
        {
            var bank=JsonConvert.DeserializeObject<AbbotCombatShapeBank>(File.ReadAllText(path));bank.Validate();return bank;
        }
        public void Validate()
        {
            if(schema!="black-abbey.abbot-combat-shapes.v1"||weapon?.segments==null||weapon.segments.Length!=8||clips==null||clips.Length<1)throw new InvalidDataException("Missing fitted Abbot collision data");
            if(!Valid(weapon.length)||weapon.length<1||weapon.length>8)throw new InvalidDataException("Invalid staff length");
            float prior=0;
            foreach(var s in weapon.segments){if(s==null||!Valid(s.fromFraction)||!Valid(s.toFraction)||!Valid(s.radius)||Math.Abs(s.fromFraction-prior)>.00001||s.toFraction<=s.fromFraction||s.toFraction>1||s.radius<0||s.radius>.75)throw new InvalidDataException("Invalid measured staff profile");prior=s.toFraction;}
            if(Math.Abs(prior-1)>.00001)throw new InvalidDataException("Incomplete staff profile");
            lookup=new Dictionary<string,AbbotContactShapeClip>(StringComparer.Ordinal);
            foreach(var c in clips)
            {
                if(c==null||string.IsNullOrEmpty(c.id)||lookup.ContainsKey(c.id)||excluded!=null&&excluded.Contains(c.id)||!Valid(c.duration)||c.duration<=0||c.samples==null||c.samples.Length<2||c.samples.Length>10000||c.events==null)throw new InvalidDataException("Invalid/duplicate combat shape clip");
                float last=-1;foreach(var s in c.samples){if(s==null||!Valid(s.time)||s.time<0||s.time<=last||s.time>c.duration+.0001)throw new InvalidDataException("Nonchronological weapon samples");V(s.butt);V(s.tip);last=s.time;}
                if(c.samples[0].time!=0||Math.Abs(last-c.duration)>.0001)throw new InvalidDataException("Incomplete staff timeline");
                var ids=new HashSet<string>();foreach(var e in c.events)if(e==null||string.IsNullOrEmpty(e.id)||!ids.Add(e.id)||!Valid(e.start)||!Valid(e.end)||e.start<0||e.end<e.start||e.end>c.duration+.0001)throw new InvalidDataException("Invalid/duplicate staff event");
                lookup.Add(c.id,c);
            }
            if(patterns==null)patterns=Array.Empty<AbbotBellPattern>();
            foreach(var p in patterns)AbbotBellAttackPattern.Validate(p,this);
        }
        public AbbotContactShapeClip Find(string id){if(lookup==null)Validate();return id!=null&&lookup.TryGetValue(id,out var c)?c:null;}
        public AbbotContactShapeEvent FindEvent(string clip,string id)=>Find(clip)?.events.FirstOrDefault(e=>e.id==id);
        public AbbotBellPattern FindPattern(string clip,string id)=>patterns?.FirstOrDefault(p=>p.clip==clip&&p.eventId==id);
        public AbbotStaffPose SampleStaff(string id,float time)
        {
            var c=Find(id);if(c==null||!Valid(time))throw new ArgumentException("Missing staff clip/nonfinite time");
            var ss=c.samples;time=Math.Max(0,Math.Min(c.duration,time));int lo=0,hi=ss.Length-1;
            while(hi-lo>1){int mid=(lo+hi)/2;if(ss[mid].time<=time)lo=mid;else hi=mid;}
            float t=ss[hi].time>ss[lo].time?(time-ss[lo].time)/(ss[hi].time-ss[lo].time):0;
            return new AbbotStaffPose(Vector3.Lerp(V(ss[lo].butt),V(ss[hi].butt),t),Vector3.Lerp(V(ss[lo].tip),V(ss[hi].tip),t));
        }
        public static Vector3 V(float[] v){if(v==null||v.Length!=3||v.Any(x=>!Valid(x)||Math.Abs(x)>100))throw new InvalidDataException("Invalid fitted staff sample");return new Vector3(v[0],v[1],v[2]);}
        public static bool Valid(float v)=>!float.IsNaN(v)&&!float.IsInfinity(v);
    }
    // A swept shaft is a ruled quadrilateral. Its two triangles plus the
    // measured local radius are tested against the actual target capsule.
    // The parent samples the source timeline at <=1/120s while active, so a
    // fast strike cannot teleport from one side of a player to the other.
    public static class AbbotWeaponContact
    {
        public const float MaximumSampleStep=1f/120f;
        public static bool SweptTouches(AbbotStaffPose previous,AbbotStaffPose current,AbbotWeaponProfile weapon,Vector3 capsuleStart,Vector3 capsuleEnd,float capsuleRadius)
        {
            if(weapon?.segments==null||!AbbotCombatShapeBank.Valid(capsuleRadius)||capsuleRadius<0)return false;
            foreach(var part in weapon.segments)
            {
                var a=Vector3.Lerp(previous.Butt,previous.Tip,part.fromFraction);var b=Vector3.Lerp(previous.Butt,previous.Tip,part.toFraction);
                var c=Vector3.Lerp(current.Butt,current.Tip,part.toFraction);var d=Vector3.Lerp(current.Butt,current.Tip,part.fromFraction);
                float radius=capsuleRadius+part.radius;
                if(SegmentTriangleSquared(capsuleStart,capsuleEnd,a,b,c)<=radius*radius||SegmentTriangleSquared(capsuleStart,capsuleEnd,a,c,d)<=radius*radius)return true;
            }
            return false;
        }
        public static float SegmentTriangleSquared(Vector3 p,Vector3 q,Vector3 a,Vector3 b,Vector3 c)
        {
            var normal=Vector3.Cross(b-a,c-a);float n=normal.sqrMagnitude;
            if(n>1e-12f)
            {
                float d=Vector3.Dot(normal,q-p);if(Math.Abs(d)>1e-9f){float t=Vector3.Dot(normal,a-p)/d;if(t>=0&&t<=1){var hit=p+(q-p)*t;if(InTriangle(hit,a,b,c,normal))return 0;}}
            }
            return Math.Min(Math.Min(PointTriangleSquared(p,a,b,c),PointTriangleSquared(q,a,b,c)),Math.Min(SegmentSegmentSquared(p,q,a,b),Math.Min(SegmentSegmentSquared(p,q,b,c),SegmentSegmentSquared(p,q,c,a))));
        }
        static bool InTriangle(Vector3 p,Vector3 a,Vector3 b,Vector3 c,Vector3 normal)
        {const float eps=-1e-7f;return Vector3.Dot(Vector3.Cross(b-a,p-a),normal)>=eps&&Vector3.Dot(Vector3.Cross(c-b,p-b),normal)>=eps&&Vector3.Dot(Vector3.Cross(a-c,p-c),normal)>=eps;}
        static float PointTriangleSquared(Vector3 p,Vector3 a,Vector3 b,Vector3 c)
        {
            var ab=b-a;var ac=c-a;var ap=p-a;float d1=Vector3.Dot(ab,ap),d2=Vector3.Dot(ac,ap);
            if(d1<=0&&d2<=0)return ap.sqrMagnitude;
            var bp=p-b;float d3=Vector3.Dot(ab,bp),d4=Vector3.Dot(ac,bp);if(d3>=0&&d4<=d3)return bp.sqrMagnitude;
            float vc=d1*d4-d3*d2;if(vc<=0&&d1>=0&&d3<=0){float v=d1/(d1-d3);return (p-(a+v*ab)).sqrMagnitude;}
            var cp=p-c;float d5=Vector3.Dot(ab,cp),d6=Vector3.Dot(ac,cp);if(d6>=0&&d5<=d6)return cp.sqrMagnitude;
            float vb=d5*d2-d1*d6;if(vb<=0&&d2>=0&&d6<=0){float w=d2/(d2-d6);return (p-(a+w*ac)).sqrMagnitude;}
            float va=d3*d6-d5*d4;if(va<=0&&(d4-d3)>=0&&(d5-d6)>=0){float w=(d4-d3)/((d4-d3)+(d5-d6));return (p-(b+w*(c-b))).sqrMagnitude;}
            float denom=va+vb+vc;if(Math.Abs(denom)<1e-12f)return Math.Min(SegmentSegmentSquared(p,p,a,b),Math.Min(SegmentSegmentSquared(p,p,b,c),SegmentSegmentSquared(p,p,c,a)));
            return (p-(a+ab*(vb/denom)+ac*(vc/denom))).sqrMagnitude;
        }
        public static float SegmentSegmentSquared(Vector3 p1,Vector3 q1,Vector3 p2,Vector3 q2)
        {
            const float eps=1e-12f;var d1=q1-p1;var d2=q2-p2;var r=p1-p2;float a=Vector3.Dot(d1,d1),e=Vector3.Dot(d2,d2),f=Vector3.Dot(d2,r),s,t;
            if(a<=eps&&e<=eps)return r.sqrMagnitude;
            if(a<=eps){s=0;t=Clamp(f/e);}else{float c=Vector3.Dot(d1,r);if(e<=eps){t=0;s=Clamp(-c/a);}else{float b=Vector3.Dot(d1,d2),denom=a*e-b*b;s=denom>eps?Clamp((b*f-c*e)/denom):0;t=(b*s+f)/e;if(t<0){t=0;s=Clamp(-c/a);}else if(t>1){t=1;s=Clamp((b-c)/a);}}}
            return ((p1+d1*s)-(p2+d2*t)).sqrMagnitude;
        }
        static float Clamp(float x)=>Math.Max(0,Math.Min(1,x));
    }
}
