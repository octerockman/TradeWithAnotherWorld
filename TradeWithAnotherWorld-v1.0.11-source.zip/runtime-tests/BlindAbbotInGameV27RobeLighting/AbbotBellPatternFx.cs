using UnityEngine;
using UnityEngine.Rendering;

namespace BlackAbbey.BlindAbbot
{
    // One bounded visual for one authoritative bell emission. Its position,
    // arrival and expiry use the same descriptor as the damage consumer.
    public sealed class AbbotBellPatternFx:MonoBehaviour
    {
        AbbotBellEmission emission;AbbotRoomBridge room;float began;LineRenderer line;Material material;
        Vector3 cachedCenter;float cachedRadius=-1;
        const int Segments=48;
        public static void Spawn(Transform owner,AbbotRoomBridge room,AbbotBellEmission emission,float began)
        {
            var go=new GameObject("BA great-bell "+emission.Kind);go.transform.SetParent(owner,false);
            var fx=go.AddComponent<AbbotBellPatternFx>();fx.emission=emission;fx.room=room;fx.began=began;
            var shader=Shader.Find("Sprites/Default")??Shader.Find("Unlit/Color");
            if(!shader){Destroy(go);return;}
            fx.material=new Material(shader){name="BA bell resonance bounded shape"};
            fx.line=go.AddComponent<LineRenderer>();fx.line.sharedMaterial=fx.material;fx.line.useWorldSpace=true;
            fx.line.shadowCastingMode=ShadowCastingMode.Off;fx.line.receiveShadows=false;fx.line.textureMode=LineTextureMode.Stretch;
            fx.line.startWidth=fx.line.endWidth=.065f;
        }
        Vector3 Floor(Vector3 p)
        {
            int mask=LayerMask.GetMask("static_solid");
            var local=room.RoomRoot.InverseTransformPoint(p);
            var top=room.RoomRoot.TransformPoint(new Vector3(local.x,3.5f,local.z));
            if(mask!=0&&Physics.Raycast(top,Vector3.down,out var hit,5,mask,QueryTriggerInteraction.Ignore))p.y=hit.point.y+.045f;
            else p.y=room.RoomRoot.position.y+.045f;
            return p;
        }
        void Update()
        {
            float elapsed=Time.time-began,total=AbbotBellAttackPattern.ActiveSeconds(emission);
            if(!room||elapsed>total){Destroy(gameObject);return;}
            bool warning=elapsed<emission.Delay;float active=Mathf.Max(0,elapsed-emission.Delay);
            float alpha=warning?.24f:Mathf.Clamp01((total-elapsed)*2)*.75f;
            line.startColor=line.endColor=new Color(1,.12f,.015f,alpha);
            if(emission.Kind=="fan")
            {
                float flight=emission.Speed>0?Mathf.Min(emission.Duration,emission.Length/emission.Speed):emission.Duration;
                float along=warning?0:emission.Speed>0?Mathf.Min(emission.Length,active*emission.Speed):emission.Length;
                if(!warning&&active>=flight){Circle(emission.Center+emission.Direction*along,emission.FieldRadius);return;}
                line.loop=false;line.positionCount=2;line.startWidth=line.endWidth=Mathf.Max(.065f,emission.Width*.35f);
                line.SetPosition(0,Floor(emission.Center+emission.Direction*Mathf.Max(0,along-Mathf.Max(.2f,emission.Width*2))));
                line.SetPosition(1,Floor(emission.Center+emission.Direction*(along+.02f)));return;
            }
            float radius=emission.Radius;
            if(!warning&&emission.Kind=="targetField"&&active>emission.Duration)radius=emission.FieldRadius;
            if(!warning&&(emission.Kind=="pulse"||emission.Kind=="groundBurst"))radius*=Mathf.Clamp01(active/emission.Duration);
            Circle(emission.Center,Mathf.Max(.08f,radius));
        }
        void Circle(Vector3 center,float radius)
        {
            if(line.loop&&cachedRadius==radius&&cachedCenter==center)return;
            cachedCenter=center;cachedRadius=radius;
            line.loop=true;line.positionCount=Segments;line.startWidth=line.endWidth=.065f;
            for(int i=0;i<Segments;i++){float angle=i*Mathf.PI*2/Segments;line.SetPosition(i,Floor(center+new Vector3(Mathf.Cos(angle),0,Mathf.Sin(angle))*radius));}
        }
        void OnDestroy(){if(material)Destroy(material);}
    }
}
