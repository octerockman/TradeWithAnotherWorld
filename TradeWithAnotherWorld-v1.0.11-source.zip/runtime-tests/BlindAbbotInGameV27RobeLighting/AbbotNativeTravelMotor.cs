using System;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbey.BlindAbbot
{
    // Own-actor adapter for the same Character.ApplyRootMotion(ref velocity)
    // pipeline used by the installed Knight. No Transform/Rigidbody position
    // writes, no raw Y animation force, no global CanMove/friction override.
    public sealed class AbbotNativeTravelMotor:MonoBehaviour
    {
        const float Skin=.035f,StepUp=.32f,MaximumDrop=.48f;
        static readonly AccessTools.FieldRef<Character,float> NativeSlippage=AccessTools.FieldRefAccess<Character,float>("m_slippage");
        readonly RaycastHit[] obstacles=new RaycastHit[64],floors=new RaycastHit[24];
        readonly AbbotSourceTravel clock=new AbbotSourceTravel();
        AbbotMotionRepertoire repertoire;Humanoid human;ZNetView view;Rigidbody body;CapsuleCollider capsule;
        Func<bool> eligible;Action<string> log;
        Quaternion heading;float clipAt,phaseLimit;
        string clipId,gate="not started";bool observing;
        int serial,physicsSamples,discardedIntervals,blockedSteps,floorStops,solidStops,frictionTicks,positionDiscontinuities;
        float requestedMetres,admittedMetres,observedPath,observedNet,peakPhysicalSpeed,lastMovingFriction;
        Vector3 firstPosition,lastPosition;
        object lastClip;
        public bool Active=>clock.Active;
        public static AbbotNativeTravelMotor Attach(GameObject actor,AbbotMotionRepertoire motions,Func<bool> eligibility,Action<string> logger=null)
        {
            if(!actor||!actor.GetComponent<AbbotEncounterController>()||motions==null||eligibility==null)throw new InvalidOperationException("Own Abbot travel authority missing");
            var existing=actor.GetComponent<AbbotNativeTravelMotor>();if(existing)return existing;
            var result=actor.AddComponent<AbbotNativeTravelMotor>();
            result.human=actor.GetComponent<Humanoid>();result.view=actor.GetComponent<ZNetView>();result.body=actor.GetComponent<Rigidbody>();result.capsule=actor.GetComponent<CapsuleCollider>();
            if(!result.human||!result.view||!result.body||!result.capsule)throw new InvalidOperationException("Own native travel body missing");
            result.repertoire=motions;result.eligible=eligibility;result.log=logger;return result;
        }
        // Controller usage: BeginClip at actual source playback start; set the
        // first LimitClipTo to the earliest unresolved effect window (or end).
        // Advance that ceiling only after declining a window. A selected branch
        // ends this motor before beginning its successor; no full-clip tail is
        // appended. SetHeading may refresh only the actual permitted facing.
        public void BeginClip(string id,float began,Quaternion facing)
        {
            if(!Finite(began))throw new ArgumentException("Invalid source playback clock");
            var source=repertoire.Find(id);
            if(source==null||!source.fullBodyAllowed||source.trajectory.Length==0)throw new InvalidOperationException("Missing source attack trajectory: "+id);
            EndClip("next source clip");
            clock.Begin(source);clipId=id;clipAt=began;phaseLimit=0;SetHeading(facing);serial++;
            physicsSamples=discardedIntervals=blockedSteps=floorStops=solidStops=frictionTicks=positionDiscontinuities=0;
            requestedMetres=admittedMetres=observedPath=observedNet=peakPhysicalSpeed=lastMovingFriction=0;
            firstPosition=lastPosition=Position;observing=true;gate="awaiting first source window limit";
        }
        public void LimitClipTo(float sourceTime)
        {
            if(!clock.Active)return;
            var source=repertoire.Find(clipId);
            if(!Finite(sourceTime)||sourceTime<0||sourceTime>source.duration+.001f)throw new ArgumentException("Invalid source travel ceiling");
            // Never rewind an already consumed interval. An initial zero limit
            // fails closed if a controller forgets to provide a branch boundary.
            phaseLimit=Mathf.Max(phaseLimit,Mathf.Min(source.duration,sourceTime));
        }
        public void SetHeading(Quaternion facing)
        {
            Vector3 forward=facing*Vector3.forward;forward.y=0;
            if(!Finite(forward)||forward.sqrMagnitude<.0001f)throw new ArgumentException("Invalid source heading");
            heading=Quaternion.LookRotation(forward.normalized,Vector3.up);
        }
        public void PauseClock(float seconds)
        {
            if(clock.Active&&Finite(seconds)&&seconds>0)clipAt+=seconds;
        }
        public void EndClip(string reason="source ended")
        {
            if(!clock.Active)return;
            ObserveBody();gate=reason;lastClip=CurrentSnapshot();clock.End();clipId=null;observing=false;
        }
        bool Owner=>view&&view.IsValid()&&view.IsOwner();
        Vector3 Position=>body?body.position:transform.position;
        void FixedUpdate(){if(observing)ObserveBody();}
        void ObserveBody()
        {
            if(!observing)return;
            Vector3 position=Position;float distance=Vector3.ProjectOnPlane(position-lastPosition,Vector3.up).magnitude;
            // Report displacement discontinuities separately from measured body
            // path. Commanded travel is never represented as observed movement.
            if(distance<=4)observedPath+=distance;else positionDiscontinuities++;
            lastPosition=position;observedNet=Vector3.ProjectOnPlane(position-firstPosition,Vector3.up).magnitude;
            if(body)peakPhysicalSpeed=Mathf.Max(peakPhysicalSpeed,Vector3.ProjectOnPlane(body.linearVelocity,Vector3.up).magnitude);
        }
        public void ApplySourceVelocity(ref Vector3 velocity)
        {
            if(!clock.Active)return;
            ObserveBody();physicsSamples++;
            double at=Math.Min(phaseLimit,Math.Max(0,Time.time-clipAt));
            bool nativeReady=Owner&&human&&!human.IsDead()&&!human.IsStaggering()&&!human.InDodge()&&human.CanMove()&&body&&!body.isKinematic&&capsule&&capsule.enabled;
            bool authority=nativeReady&&eligible();
            var step=clock.Consume(at,!authority);
            if(!authority){discardedIntervals++;gate="native owner/lifecycle/movement gate";return;}
            // Parent source combat deliberately keeps m_moveDir zero. The
            // admitted source step replaces only native horizontal velocity;
            // gravity, pushback/platform handling and Y remain native.
            velocity.x=velocity.z=0;
            if(step.Discarded){discardedIntervals++;gate="stalled/restored source clock";return;}
            if(step.Length<=.0000001){gate="source stationary phase or pending branch";return;}
            Vector3 delta=heading*new Vector3((float)step.Right,0,(float)step.Forward);delta.y=0;
            requestedMetres+=delta.magnitude;
            float allowed=Allowed(delta);
            if(allowed<=.000001f){blockedSteps++;return;}
            delta=delta.normalized*allowed;
            // Match the native moving-friction branch already proven by the
            // Knight. Standing Maximum/0.8 was selected earlier while the
            // source attack holds moveDir=zero; next native tick restores normal
            // idle/stagger/death handling on this collider's own material.
            float friction=(float)AbbotSourceTravel.MovingFriction(NativeSlippage(human));
            var material=capsule.material;material.staticFriction=material.dynamicFriction=friction;material.frictionCombine=PhysicsMaterialCombine.Multiply;
            lastMovingFriction=friction;frictionTicks++;
            float dt=Time.fixedDeltaTime;
            if(!Finite(dt)||dt<=0){gate="invalid native fixed interval";return;}
            velocity.x=delta.x/dt;velocity.z=delta.z/dt;admittedMetres+=allowed;gate="source travel admitted";
        }
        float Allowed(Vector3 delta)
        {
            float distance=delta.magnitude;
            if(!human.IsOnGround()){floorStops++;gate="not grounded";return 0;}
            if(distance<=.000001f)return 0;
            var bounds=capsule.bounds;float originalRadius=Mathf.Max(bounds.extents.x,bounds.extents.z);
            float radius=(float)AbbotSourceTravel.CastRadius(originalRadius),offset=(float)AbbotSourceTravel.HemisphereOffset(bounds.extents.y,originalRadius);
            Vector3 direction=delta/distance;
            int solids=LayerMask.GetMask("Default","static_solid","Default_small","piece","terrain","vehicle");
            int obstructions=solids|LayerMask.GetMask("character","character_net","character_noenv","character_ghost");
            if(solids==0||obstructions==0){gate="native solid masks unavailable";return 0;}
            int count=Physics.CapsuleCastNonAlloc(bounds.center+Vector3.up*offset,bounds.center-Vector3.up*offset,radius,direction,obstacles,distance+Skin,obstructions,QueryTriggerInteraction.Ignore);
            if(count>=obstacles.Length){solidStops++;gate="saturated obstacle query";return 0;}
            float allowed=distance;
            for(int i=0;i<count;i++){
                var hit=obstacles[i];if(!hit.collider||hit.collider.transform.IsChildOf(transform)||hit.normal.y>.65f)continue;
                allowed=Mathf.Min(allowed,Mathf.Max(0,hit.distance-Skin));
            }
            if(allowed<distance-.000001f){solidStops++;gate="solid obstruction";}
            Vector3 sole=bounds.center;sole.y=bounds.min.y;
            Vector3 side=Vector3.Cross(Vector3.up,direction)*(radius*.55f);
            // Probe the path as well as the endpoint so a fast original lunge
            // cannot skip a floor gap merely because its far end is supported.
            int segments=Mathf.Max(1,Mathf.CeilToInt(allowed/Mathf.Max(.15f,radius*.55f)));
            if(segments>64){floorStops++;gate="unsupported oversized source step";return 0;}
            for(int i=1;i<=segments;i++){
                Vector3 foot=sole+direction*(allowed*i/segments);
                if(!Floor(foot,solids)||!Floor(foot+side,solids)||!Floor(foot-side,solids)){
                    floorStops++;gate="no supported floor along source step";return 0;
                }
            }
            return allowed;
        }
        bool Floor(Vector3 foot,int mask)
        {
            int count=Physics.RaycastNonAlloc(foot+Vector3.up*StepUp,Vector3.down,floors,StepUp+MaximumDrop,mask,QueryTriggerInteraction.Ignore);
            if(count>=floors.Length)return false;
            for(int i=0;i<count;i++){var hit=floors[i];if(hit.collider&&!hit.collider.transform.IsChildOf(transform)&&hit.normal.y>=.65f)return true;}
            return false;
        }
        object CurrentSnapshot()=>new{clip=clipId,serial,sourceConsumedSeconds=clock.ConsumedTime,phaseLimit,requestedMetres,admittedMetres,observedBodyPathMetres=observedPath,observedBodyNetMetres=observedNet,peakPhysicalSpeed,physicsSamples,discardedIntervals,blockedSteps,floorStops,solidStops,frictionTicks,lastMovingFriction,movingFrictionCombine="Multiply",positionDiscontinuities,bodyKinematic=body&&body.isKinematic,bodyConstraints=body?body.constraints.ToString():"unavailable",gate};
        public object Snapshot(){ObserveBody();return new{active=Active,current=CurrentSnapshot(),lastClip,physicalClaim="Observed body displacement is distinct from requested/admitted source metres; gameplay contact and appearance await Jesse."};}
        static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
        static bool Finite(Vector3 value)=>Finite(value.x)&&Finite(value.y)&&Finite(value.z);
        void OnDestroy(){clock.End();observing=false;}
    }
    static class AbbotNativeTravelHooks
    {
        [HarmonyPatch(typeof(Character),"ApplyRootMotion")]
        static class Travel
        {
            [HarmonyPostfix] static void Postfix(Character __instance,ref Vector3 __0)=>__instance.GetComponent<AbbotNativeTravelMotor>()?.ApplySourceVelocity(ref __0);
        }
    }
}
