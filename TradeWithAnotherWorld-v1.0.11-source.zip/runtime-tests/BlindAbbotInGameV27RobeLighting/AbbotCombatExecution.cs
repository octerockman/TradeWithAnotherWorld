using System;
using System.Collections.Generic;

namespace BlackAbbey.BlindAbbot
{
    public enum AbbotApproachOutcome { Continue, Commit, Cancel, Pause }

    // A source ApproachTarget is followed by the queued attack even when its
    // short lifetime expires. Reach describes where to stop approaching, not
    // permission to erase the queued action. Actual contacts can still miss.
    public static class AbbotCombatExecution
    {
        public static AbbotApproachOutcome Approach(bool validTargetAndPhase,bool nativeStagger,bool routeReady,bool stopReached,bool lifetimeExpired,bool blocked)
        {
            if(!validTargetAndPhase)return AbbotApproachOutcome.Cancel;
            if(nativeStagger)return AbbotApproachOutcome.Pause;
            if(stopReached||lifetimeExpired)return AbbotApproachOutcome.Commit;
            if(blocked)return AbbotApproachOutcome.Cancel;
            return routeReady?AbbotApproachOutcome.Continue:AbbotApproachOutcome.Pause;
        }
        public static bool DamageReaction(bool combatPhase,bool nativeStaggerStarted,bool reactionActive)
            =>combatPhase&&nativeStaggerStarted&&!reactionActive;
    }

    // Bounded per-actor diagnostic totals. Selections, approaches, contacts and
    // completed actions are distinct; requested travel is not proof of a hit.
    public sealed class AbbotCombatExecutionLedger
    {
        public sealed class Counts { public int selected,approached,committed,completed,cancelled,contacts; }
        readonly Dictionary<string,Counts> counts=new Dictionary<string,Counts>(StringComparer.Ordinal);
        public string LastReason{get;private set;}="none";
        Counts For(string id)
        {
            if(string.IsNullOrWhiteSpace(id))return null;
            if(!counts.TryGetValue(id,out var c)){
                if(counts.Count>=32)return null;
                counts.Add(id,c=new Counts());
            }
            return c;
        }
        static void Increment(ref int n){if(n<int.MaxValue)n++;}
        public void Selected(string id){var c=For(id);if(c!=null)Increment(ref c.selected);}
        public void Approached(string id){var c=For(id);if(c!=null)Increment(ref c.approached);}
        public void Committed(string id){var c=For(id);if(c!=null)Increment(ref c.committed);}
        public void Completed(string id){var c=For(id);if(c!=null)Increment(ref c.completed);}
        public void Cancelled(string id,string reason){var c=For(id);if(c!=null)Increment(ref c.cancelled);LastReason=reason??"unknown";}
        public void Contact(string id){var c=For(id);if(c!=null)Increment(ref c.contacts);}
        public object Snapshot()=>new{counts,lastReason=LastReason};
    }
}
