using System;

namespace BlackAbbey.BlindAbbot
{
    // One cursor belongs to one committed clip instance. It is independent of
    // frame rate: a time step may cross any number of ordered event starts.
    // Authority belongs to the controller, not to this clock.
    public sealed class AbbotEventCursor
    {
        readonly float[] times;
        int next;
        float elapsed = -1;
        public int Consumed => next;
        public int Count => times.Length;
        public float Elapsed => elapsed;

        public AbbotEventCursor(float[] eventTimes)
        {
            if(eventTimes == null || eventTimes.Length > 1024) throw new ArgumentException("Invalid event timeline");
            times = (float[])eventTimes.Clone();
            for(int i=0;i<times.Length;i++)
                if(!Finite(times[i]) || times[i]<0 || i>0 && times[i]<times[i-1])
                    throw new ArgumentException("Event starts must be finite, nonnegative and sorted");
        }

        public void Advance(float time, Action<int> dispatch)
        {
            if(!Finite(time) || time<0) throw new ArgumentOutOfRangeException(nameof(time));
            if(dispatch == null) throw new ArgumentNullException(nameof(dispatch));
            // Repeated updates and a caller's backwards clock correction never
            // replay consumed events. Starting a new clip creates a new cursor.
            if(time<elapsed) return;
            elapsed = time;
            while(next<times.Length && times[next]<=time)
            {
                int index = next++;
                // Commit before callbacks: a reentrant update cannot fire this
                // event twice. A failed effect is not retried as duplicate damage.
                dispatch(index);
            }
        }

        public void Cancel() { next = times.Length; }
        static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
    }
}
