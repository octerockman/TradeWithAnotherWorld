using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace BlackAbbey.BlindAbbot
{
    // Registration-time, clone-only repair. Mixer resolution must happen first;
    // the owned Dark Abbot audio sources are attached later by the encounter.
    // Native prefab references and retained EffectData entries are never edited.
    public static class AbbotNativeEffects
    {
        static readonly HashSet<string> SkeletonSounds=new HashSet<string>(StringComparer.Ordinal)
        {
            "sfx_skeleton_hit","sfx_skeleton_basic_death","sfx_skeleton_basic_verse_attack",
            "sfx_skeleton_basic_verse_idle","sfx_skeleton_alerted","sfx_skeleton_idle"
        };
        static readonly MethodInfo CopyEntry=typeof(object).GetMethod("MemberwiseClone",BindingFlags.Instance|BindingFlags.NonPublic);

        public sealed class Review
        {
            public int removedSoundEntries,replacedHitParticles,removedDirectClips,unknownAudioSources;
            public string bloodPrefab;
        }
        public static bool IsSkeletonSound(string name)=>name!=null&&SkeletonSounds.Contains(name);
        public static bool IsSkeletonClip(string name)=>name!=null&&(
            name=="Skeleton_Death_BoneHit1"||name=="Skeleton_Death_BoneHit2"||name=="Skeleton_Death_BoneHit3"||name=="Skeleton_Hit_Bone1"||
            name.StartsWith("Enemy_Skeleton_Basic_Verse_Attack_",StringComparison.Ordinal)||
            name.StartsWith("Enemy_Skeleton_Basic_Verse_Idle_",StringComparison.Ordinal));

        public static Review Apply(GameObject native,GameObject own,GameObject blood,Action<string> log=null)
        {
            if(!native||!own||native==own)throw new InvalidOperationException("Native-effects repair requires a distinct owned clone.");
            var character=own.GetComponent<Humanoid>();var ai=own.GetComponent<MonsterAI>();
            if(!character||!ai)throw new InvalidOperationException("Owned Humanoid/MonsterAI unavailable.");
            if(!blood||blood.name!="vfx_BloodHit"||blood.GetComponentsInChildren<ParticleSystem>(true).Length==0||
               blood.GetComponentInChildren<Character>(true)||blood.GetComponentInChildren<Ragdoll>(true)||blood.GetComponentInChildren<Aoe>(true))
                throw new InvalidOperationException("Native vfx_BloodHit particle prefab unavailable; no dust/tinted substitute admitted.");
            var review=new Review{bloodPrefab=blood.name};
            // These lists belong to this Character/AI instance. Filtering allocates
            // new arrays; replacing the hit entry clones all native placement flags.
            character.m_hitEffects=Filter(character.m_hitEffects,"m_hitEffects",blood,true,review,log);
            character.m_critHitEffects=Filter(character.m_critHitEffects,"m_critHitEffects",blood,false,review,log);
            character.m_backstabHitEffects=Filter(character.m_backstabHitEffects,"m_backstabHitEffects",blood,false,review,log);
            character.m_deathEffects=Filter(character.m_deathEffects,"m_deathEffects",blood,false,review,log);
            ai.m_idleSound=Filter(ai.m_idleSound,"m_idleSound",blood,false,review,log);
            ai.m_alertedEffects=Filter(ai.m_alertedEffects,"m_alertedEffects",blood,false,review,log);
            ai.m_wakeupEffects=Filter(ai.m_wakeupEffects,"m_wakeupEffects",blood,false,review,log);
            ai.m_sleepEffects=Filter(ai.m_sleepEffects,"m_sleepEffects",blood,false,review,log);
            StripDirectSkeletonClips(own,review,log);
            log?.Invoke("BA_ABBOT_NATIVE_EFFECTS_READY skeletonEntriesRemoved="+review.removedSoundEntries+
                " nativeBlood="+review.bloodPrefab+" replacedDust="+review.replacedHitParticles+
                " directClipsRemoved="+review.removedDirectClips+" unknownAudioSources="+review.unknownAudioSources+
                " footfallsAndOwnedAudioRetained=true");
            return review;
        }
        static EffectList Filter(EffectList input,string field,GameObject blood,bool ordinaryHit,Review review,Action<string> log)
        {
            var result=new List<EffectList.EffectData>();bool hasBlood=false;
            foreach(var entry in input?.m_effectPrefabs??Array.Empty<EffectList.EffectData>())
            {
                if(entry?.m_prefab==null){result.Add(entry);continue;}
                string name=entry.m_prefab.name;
                if(IsSkeletonSound(name)){review.removedSoundEntries++;log?.Invoke("BA_ABBOT_NATIVE_SOUND_REMOVED field="+field+" prefab="+name);continue;}
                if(ordinaryHit&&name=="vfx_skeleton_hit")
                {
                    var copy=(EffectList.EffectData)CopyEntry.Invoke(entry,null);copy.m_prefab=blood;
                    result.Add(copy);hasBlood=true;review.replacedHitParticles++;continue;
                }
                if(ordinaryHit&&entry.m_prefab==blood)hasBlood=true;
                result.Add(entry);
            }
            // Keep a native red response even if another Skeleton revision no
            // longer has the known dust entry. Never remove its unknown effects.
            if(ordinaryHit&&!hasBlood)result.Add(new EffectList.EffectData{m_prefab=blood,m_enabled=true});
            return new EffectList{m_effectPrefabs=result.ToArray()};
        }
        static void StripDirectSkeletonClips(GameObject own,Review review,Action<string> log)
        {
            // The inspected current Skeleton hierarchy has zero such direct
            // emitters. Handle only proven clip identities if a later template
            // gains one; unknown sources are named in diagnostics and retained.
            var handled=new HashSet<AudioSource>();
            foreach(var sfx in own.GetComponentsInChildren<ZSFX>(true))
            {
                var clips=sfx.m_audioClips??Array.Empty<AudioClip>();var kept=clips.Where(c=>!c||!IsSkeletonClip(c.name)).ToArray();
                int removed=clips.Length-kept.Length;
                if(removed>0)
                {
                    sfx.m_audioClips=kept;review.removedDirectClips+=removed;
                    if(!kept.Any(c=>c))
                    {
                        sfx.enabled=false;
                        var audio=sfx.GetComponent<AudioSource>();
                        if(audio&&(!audio.clip||IsSkeletonClip(audio.clip.name)))
                        {audio.Stop();audio.clip=null;audio.playOnAwake=false;audio.enabled=false;handled.Add(audio);}
                    }
                }
                if(kept.Any(c=>c)||removed==0)
                {
                    review.unknownAudioSources++;
                    log?.Invoke("BA_ABBOT_NATIVE_AUDIO_UNCLASSIFIED path="+Path(sfx.transform,own.transform)+
                        " emitter=ZSFX clips="+(kept.Any(c=>c)?string.Join(",",kept.Where(c=>c).Select(c=>c.name)):"<none>")+" action=retained");
                }
            }
            foreach(var audio in own.GetComponentsInChildren<AudioSource>(true))
            {
                if(handled.Contains(audio))continue;
                if(audio.clip&&IsSkeletonClip(audio.clip.name))
                {audio.Stop();audio.clip=null;audio.playOnAwake=false;review.removedDirectClips++;continue;}
                // An AudioSource driven by an already diagnosed ZSFX is not a
                // second unknown. No volume, mixer, footstep or listener edits.
                if(!audio.GetComponent<ZSFX>()||audio.clip)
                {
                    review.unknownAudioSources++;
                    log?.Invoke("BA_ABBOT_NATIVE_AUDIO_UNCLASSIFIED path="+Path(audio.transform,own.transform)+
                        " emitter=AudioSource clip="+(audio.clip?audio.clip.name:"<none>")+" action=retained");
                }
            }
        }
        static string Path(Transform child,Transform root)
        {string path=child.name;while(child!=root&&child.parent){child=child.parent;path=child.name+"/"+path;}return path;}
    }
}
