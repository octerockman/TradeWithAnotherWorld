using UnityEngine;

namespace BlackAbbey.BlindAbbot
{
    // Call only after the encounter has identified its own breakable pew.
    // Native pew art deliberately uses nonconvex MeshColliders. PhysX does not
    // support Collider.ClosestPoint for those meshes; keep their shape intact.
    public static class AbbotPewContact
    {
        public static bool TryClosestPoint(Collider collider, Vector3 origin, out Vector3 point)
        {
            point = default;
            if (!collider || !collider.enabled || !collider.gameObject.activeInHierarchy || !Finite(origin)) return false;
            // This is a conservative AABB contact for an already overlapping
            // owned pew, not a claim of exact nearest triangle/surface contact.
            // Primitive and convex-mesh contacts retain the native narrow phase.
            point = collider is MeshCollider mesh && !mesh.convex
                ? collider.bounds.ClosestPoint(origin)
                : collider.ClosestPoint(origin);
            return Finite(point);
        }

        static bool Finite(Vector3 p) => !(float.IsNaN(p.x) || float.IsNaN(p.y) || float.IsNaN(p.z)
            || float.IsInfinity(p.x) || float.IsInfinity(p.y) || float.IsInfinity(p.z));
    }
}
