using System;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbey.BlindAbbot
{
    // Native UpdateRotation normally faces a nonzero movement direction before
    // considering lookYaw. For our owned strafe/backstep only, let the same
    // native rotation routine use the full player-facing look target instead.
    // Restore the exact movement vector before the surrounding walking motor
    // continues. Position, velocity, contacts and other actors stay native.
    [HarmonyPatch(typeof(Character),"UpdateRotation")]
    internal static class AbbotTacticalFacing
    {
        internal struct CallState { internal bool Pending;internal Vector3 Movement; }

        [HarmonyPrefix]
        internal static void Prefix(Character __instance,ref Vector3 ___m_moveDir,out CallState __state)
        {
            __state=default;
            if(!__instance)return;
            var encounter=__instance.GetComponent<AbbotEncounterController>();
            if(!encounter||!encounter.OwnsTacticalFacing)return;
            __state=new CallState{Pending=true,Movement=___m_moveDir};
            ___m_moveDir=Vector3.zero;
        }

        [HarmonyPostfix]
        internal static void Postfix(ref Vector3 ___m_moveDir,ref CallState __state)=>Restore(ref ___m_moveDir,ref __state);

        [HarmonyFinalizer]
        internal static Exception Finalizer(Exception __exception,ref Vector3 ___m_moveDir,ref CallState __state)
        {
            Restore(ref ___m_moveDir,ref __state);
            return __exception;
        }

        static void Restore(ref Vector3 movement,ref CallState state)
        {
            if(!state.Pending)return;
            movement=state.Movement;state.Pending=false;
        }
    }
}
