using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbey.BlindAbbot
{
    // Additive, source-bound bridge. Never replaces the dungeon helper or its
    // door, music, candle, persistence or room-loading state machines.
    public sealed class AbbotRoomBridge:MonoBehaviour
    {
        public const string RoomSource="869bac079de49440aebe2c2dd5cabbbce2e0040173eb65977d0f1ae57fd8efb4";
        static readonly Dictionary<object,AbbotRoomBridge> States=new Dictionary<object,AbbotRoomBridge>();
        static Type runtimeType,stateType;static FieldInfo roomField,stateField,pivotsField,accessField,musicField;
        static PropertyInfo currentProperty;static MethodInfo completeMethod,resetMethod;
        MonoBehaviour runtime;object state,music;Func<Humanoid,bool> access;
        Transform bell,clapper;Quaternion bellRest,clapperRest;float ringAt=-100,duckUntil,duckGain=1,duckCurrent=1;
        bool bound,failed;float retryAt,ringStrength=1;AbbotRoomCorpse corpse;
        public Transform RoomRoot=>transform;
        public string InstanceId{get;private set;}
        public AbbotEncounterController Actor{get;private set;}
        public AbbotOpeningScope Opening{get;}=new AbbotOpeningScope();
        public string Stage=>state==null?"Unavailable":currentProperty.GetValue(state)?.ToString();
        public Vector3 BellContact=>RoomRoot.TransformPoint(new Vector3(.16f,3.815f,27.61f));
        public Vector3 RitualGoal=>RoomRoot.TransformPoint(new Vector3(AbbotEncounterPolicy.RitualX,AbbotEncounterPolicy.RitualY,AbbotEncounterPolicy.RitualZ));
        public bool Ready=>bound&&Actor&&Actor.Ready;
        public static bool HooksReady{get;private set;}
        public static void InstallHooks(Harmony harmony)
        {
            try{
                var asm=AppDomain.CurrentDomain.GetAssemblies().Single(a=>a.GetType("BlackAbbeySixRooms.R09RoomRuntime")!=null);
                runtimeType=asm.GetType("BlackAbbeySixRooms.R09RoomRuntime");stateType=asm.GetType("BlackAbbeySixRooms.R09EncounterState");
                roomField=RequiredField(runtimeType,"room");stateField=RequiredField(runtimeType,"encounter");pivotsField=RequiredField(runtimeType,"pivots");accessField=RequiredField(runtimeType,"canInteract");musicField=RequiredField(runtimeType,"music");
                currentProperty=AccessTools.Property(stateType,"Current")??throw new MissingMemberException("R09 stage");completeMethod=RequiredMethod(runtimeType,"CompleteEncounter");resetMethod=RequiredMethod(runtimeType,"ResetEncounter");
                Patch(harmony,RequiredMethod(runtimeType,"Update"),nameof(BeforeRoomUpdate),null);
                Patch(harmony,RequiredMethod(runtimeType,"ResetEncounter"),null,nameof(AfterReset));
                Patch(harmony,completeMethod,null,nameof(AfterComplete));
                Patch(harmony,RequiredMethod(stateType,"Observe"),nameof(BeforeObserve),null);
                Patch(harmony,RequiredMethod(asm.GetType("BlackAbbeySixRooms.BossMusicRuntime"),"Gain"),null,nameof(AfterMusicGain));
                HooksReady=true;AbbotPlugin.Log("BA_ABBOT_BRIDGE_READY helper="+asm.GetName().Version+" source="+RoomSource);
            }catch(Exception e){HooksReady=false;AbbotPlugin.Log("BA_ABBOT_BRIDGE_FAILED; own encounter not armed: "+e);}
        }
        static FieldInfo RequiredField(Type t,string name)=>AccessTools.Field(t,name)??throw new MissingFieldException(t?.FullName,name);
        static MethodInfo RequiredMethod(Type t,string name)=>AccessTools.Method(t,name)??throw new MissingMethodException(t?.FullName,name);
        static void Patch(Harmony h,MethodInfo m,string prefix,string postfix)=>h.Patch(m,prefix==null?null:new HarmonyMethod(typeof(AbbotRoomBridge),prefix),postfix==null?null:new HarmonyMethod(typeof(AbbotRoomBridge),postfix));
        static void BeforeRoomUpdate(MonoBehaviour __instance)
        {
            if(!AbbotPlugin.EncounterEnabled||!HooksReady)return;
            var bridge=__instance.GetComponent<AbbotRoomBridge>();if(!bridge)bridge=__instance.gameObject.AddComponent<AbbotRoomBridge>();
            if(!bridge.bound&&!bridge.failed)bridge.Bind(__instance);
            if(bridge.bound)bridge.EnsureActor();
        }
        static void BeforeObserve(object __instance,ref bool eligible)
        {
            if(!AbbotPlugin.EncounterEnabled)return;
            // Do not shut the doors on an actor/payload/nav failure.
            eligible=eligible&&States.TryGetValue(__instance,out var bridge)&&bridge&&bridge.Ready;
        }
        static void AfterReset(MonoBehaviour __instance,bool __result){if(__result)__instance.GetComponent<AbbotRoomBridge>()?.ResetOwned();}
        static void AfterComplete(MonoBehaviour __instance,bool __result){if(__result){var b=__instance.GetComponent<AbbotRoomBridge>();if(b&&b.Actor&&b.Actor.Phase!=AbbotPhase.Defeated)b.Actor.Cancel("helper debug completion");}}
        static void AfterMusicGain(object __instance,ref float __result)
        {
            foreach(var b in States.Values)if(b&&ReferenceEquals(b.music,__instance)){float target=Time.time<b.duckUntil?b.duckGain:1;b.duckCurrent=Mathf.MoveTowards(b.duckCurrent,target,Time.unscaledDeltaTime*(target<b.duckCurrent?5:1.4f));__result*=b.duckCurrent;break;}
        }
        void Bind(MonoBehaviour source)
        {
            try{
                var loaded=roomField.GetValue(source)??throw new InvalidOperationException("Missing loaded R09");
                var manifest=RequiredField(loaded.GetType(),"Manifest").GetValue(loaded);
                if((string)RequiredField(manifest.GetType(),"roomId").GetValue(manifest)!="R09"||(string)RequiredField(manifest.GetType(),"sourceSha256").GetValue(manifest)!=RoomSource)throw new InvalidOperationException("Unreviewed R09 source");
                var root=(GameObject)RequiredField(loaded.GetType(),"Root").GetValue(loaded);if(root!=gameObject)throw new InvalidOperationException("Unexpected R09 root");
                InstanceId=(string)RequiredField(loaded.GetType(),"InstanceId").GetValue(loaded);
                var pivots=(Dictionary<string,Transform>)pivotsField.GetValue(source);bell=pivots["bell_casting"];clapper=pivots["bell_clapper"];
                if(!bell||!clapper||Vector3.Distance(bell.localPosition,new Vector3(0,10.12f,29.5f))>.005f)throw new InvalidOperationException("Great bell rest-pivot contract changed");
                bellRest=bell.localRotation;clapperRest=clapper.localRotation;runtime=source;state=stateField.GetValue(source);music=musicField.GetValue(source);access=(Func<Humanoid,bool>)accessField.GetValue(source);
                if(state==null||access==null)throw new InvalidOperationException("R09 encounter contract disabled/missing");
                States.Add(state,this);bound=true;
            }catch(Exception e){failed=true;AbbotPlugin.Log("BA_ABBOT_ROOM_REJECTED "+e);}
        }
        void EnsureActor()
        {
            if(Actor||Stage=="Completed"||!AbbotPlugin.Ready||Time.time<retryAt||!PlayerNearForSpawn())return;
            retryAt=Time.time+5;
            try{Actor=AbbotPlugin.Spawn(this);}catch(Exception e){AbbotPlugin.Log("BA_ABBOT_SPAWN_FAILED doors remain unarmed: "+e);}
        }
        void Update()
        {
            if(!bound)return;
            if(!AbbotPlugin.EncounterEnabled){if(Stage=="Lighting"||Stage=="Active")resetMethod.Invoke(runtime,null);if(Actor)Actor.Cancel("disabled by config");return;}
            EnsureActor();
            if(Actor&&Ready&&(Stage=="Lighting"||Stage=="Active"))Actor.ObserveRoomStage(Stage);
            if(Actor&&Ready)Actor.ObserveEntrance();
            if(ringAt>=0&&bell&&clapper){float elapsed=Time.time-ringAt;bell.localRotation=bellRest*Quaternion.AngleAxis(AbbotEncounterPolicy.BellDegrees(elapsed)*ringStrength,Vector3.right);clapper.localRotation=clapperRest*Quaternion.AngleAxis(AbbotEncounterPolicy.BellDegrees(elapsed)*4.75f*ringStrength,Vector3.right);if(elapsed>=12){RestoreBell();}}
        }
        public bool Eligible(Player p,bool requireAlive=true)
        {
            if(!bound||!p||p!=Player.m_localPlayer||!gameObject.activeInHierarchy||requireAlive&&p.IsDead()||p.InGhostMode()||p.IsTeleporting())return false;
            if(!access(p))return false;var v=RoomRoot.InverseTransformPoint(p.transform.position);return AbbotEncounterPolicy.WithinArena(v.x,v.y,v.z);
        }
        public Player[] Players()=>Eligible(Player.m_localPlayer)?new[]{Player.m_localPlayer}:Array.Empty<Player>();
        public bool PlayerNearForSpawn()
        {
            var p=Player.m_localPlayer;if(!bound||!p||p.IsDead()||p.IsTeleporting()||!access(p))return false;
            var v=RoomRoot.InverseTransformPoint(p.transform.position);return AbbotEncounterPolicy.NearSpawn(v.x,v.y,v.z);
        }
        public void Duck(float gain,float duration){duckGain=Mathf.Clamp01(gain);duckUntil=Time.time+Mathf.Max(0,duration);}
        public void RingGreatBell(){ringAt=Time.time;ringStrength=1;AbbotPlugin.Log("BA_ABBOT_GREAT_BELL_STRIKE point="+BellContact);}
        public void ChimeGreatBell()
        {
            if(ringAt>=0&&ringStrength>=1)return;
            // Presentation only: the actor's central room-bell route has already
            // played this source-timed onset. Never create a second answer sound.
            ringAt=Time.time;ringStrength=.2f;
        }
        public void Complete(){if(bound)completeMethod.Invoke(runtime,null);}
        public void KeepCorpse(AbbotVisual visual){if(!corpse){try{corpse=AbbotRoomCorpse.Freeze(RoomRoot,visual);AbbotPlugin.Log("BA_ABBOT_CORPSE_RETAINED room="+InstanceId+" lifetime=completed-dungeon-room");}catch(Exception error){AbbotPlugin.Log("BA_ABBOT_CORPSE_FAILED native death still proceeds: "+error);}}}
        public static void ReleaseModule(){foreach(var b in States.Values.ToArray())if(b){if(b.bound&&(b.Stage=="Lighting"||b.Stage=="Active"))resetMethod.Invoke(b.runtime,null);b.ResetOwned();}HooksReady=false;}
        public void ActorGone(AbbotEncounterController actor){if(Actor==actor)Actor=null;}
        void RestoreBell(){if(bell)bell.localRotation=bellRest;if(clapper)clapper.localRotation=clapperRest;ringAt=-100;}
        void ResetOwned(){AbbotBellTailLifetime.StopRoom(transform);if(corpse)Object.Destroy(corpse.gameObject);corpse=null;if(Actor)Actor.Cancel("explicit R09 reset");Actor=null;Opening.Reset();RestoreBell();duckUntil=0;retryAt=Time.time+.1f;}
        void OnDisable(){AbbotBellTailLifetime.StopRoom(transform);}
        void OnDestroy(){if(state!=null)States.Remove(state);if(Actor)Actor.Cancel("R09 unloaded");RestoreBell();bound=false;}
    }
}
