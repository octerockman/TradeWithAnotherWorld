using System;
using System.IO;
using UnityEngine;

namespace BlackAbbey.BlindAbbot
{
    // V97's complete fitted model is authored facing -Z; Character and the
    // already normalized source travel/control data use +Z. Convert only this
    // exact reviewed model at the presentation/contact boundary. Bone-local
    // samples, bindposes, handedness, scale and world-space steering stay intact.
    internal static class AbbotModelFrame
    {
        internal const string NativeHash="a6613da0663d7267a7f2097e13b97c15682070404309c093c89df688cdeb4852";
        internal const string ShapeHash="710ff48f4e04749f37f4545067423bec27f8a88b8adc528a8c01e8860659ecf2";
        internal static bool Applies(AbbotPayload payload)=>payload?.sourceNative?.sha256==NativeHash;

        internal static void AlignVisual(AbbotVisual visual)
        {
            if(!Applies(visual.Payload))return;
            // Construct restores node0 from the immutable payload. BindClone
            // inherits the corrected Transform and must not apply this twice.
            var root=visual.Payload.nodes[0];
            if(root.id!=0||root.name!="Visual"||root.rotation==null||root.rotation.Length!=4
                ||root.rotation[0]!=0||root.rotation[1]!=0||root.rotation[2]!=0||root.rotation[3]!=1)
                throw new InvalidDataException("V97 model root differs from reviewed facing contract");
            visual.Root.localRotation=new Quaternion(0,1,0,0);
        }

        internal static AbbotCombatShapeBank LoadCombat(string path,AbbotPayload payload)
        {
            var bank=AbbotCombatShapeBank.Load(path);
            if(!Applies(payload))return bank;
            if(AbbotVisual.Hash(path)!=ShapeHash)
                throw new InvalidDataException("V97 weapon contacts differ from reviewed facing contract");
            // These points are in Visual-root space, unlike the already
            // forward-normalized trajectory sidecar. Transform both endpoints
            // at every phase so the measured hit surface stays on the staff.
            Turn(bank.weapon.butt);Turn(bank.weapon.tip);
            foreach(var clip in bank.clips)foreach(var sample in clip.samples){Turn(sample.butt);Turn(sample.tip);}
            bank.startRanges.Clear();bank.Validate();
            return bank;
        }

        static void Turn(float[] point)
        {
            if(point==null||point.Length!=3||!AbbotCombatShapeBank.Valid(point[0])
                ||!AbbotCombatShapeBank.Valid(point[1])||!AbbotCombatShapeBank.Valid(point[2]))
                throw new InvalidDataException("Invalid V97 contact point");
            point[0]=-point[0];point[2]=-point[2];
        }
    }
}
