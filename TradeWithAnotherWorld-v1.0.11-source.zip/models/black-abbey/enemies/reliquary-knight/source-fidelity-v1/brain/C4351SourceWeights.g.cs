// Generated numeric selection table from pinned local435100 source.
// This is not a game-VM implementation. See source-ai-map.json for scope.
using System.Collections.Generic;
namespace BlackAbbey.ReliquaryKnight
{
    public sealed partial class C4351BattleBrain
    {
        public Dictionary<int,int> RawSourceWeights(SenseFrame s)
        {
            var w = new Dictionary<int,int>();
            if (SelfEffect(s, 14476) == true && SelfEffect(s, 14473) == true)
            {
                if (SourceDistance(s) >= 20)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        SetWeights(w, 10, 70, 11, 0);
                    }
                    else
                    {
                        SetWeights(w, 20, 0, 21, 0, 22, 0, 23, 100, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 15)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        SetWeights(w, 10, 100, 11, 0);
                    }
                    else
                    {
                        SetWeights(w, 20, 0, 21, 0, 22, 0, 23, 100, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 10)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        SetWeights(w, 10, 100, 11, 0);
                    }
                    else
                    {
                        SetWeights(w, 20, 0, 21, 0, 22, 0, 23, 100, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 6)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        SetWeights(w, 10, 100, 11, 0);
                    }
                    else
                    {
                        SetWeights(w, 20, 0, 21, 0, 22, 0, 23, 100, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                }
                else if (InCone(s, 0, 120, 100))
                {
                    SetWeights(w, 10, 0, 11, 100);
                }
                else
                {
                    SetWeights(w, 20, 0, 21, 0, 22, 0, 23, 100, 24, 0, 25, 0, 26, 0, 27, 0);
                }
            }
            else if (SelfEffect(s, 14476) == true && SelfEffect(s, 14474) == true)
            {
                if (SourceDistance(s) >= 20)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        SetWeights(w, 7, 100);
                    }
                    else
                    {
                        SetWeights(w, 20, 100, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 15)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        SetWeights(w, 7, 100);
                    }
                    else
                    {
                        SetWeights(w, 20, 100, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 9)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        SetWeights(w, 7, 100);
                    }
                    else
                    {
                        SetWeights(w, 20, 100, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 8)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        if (s.TargetGuarding == true)
                        {
                            SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 50, 6, 30, 7, 0, 20, 20, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                        else if (s.TargetGuarding == false)
                        {
                            SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 50, 6, 30, 7, 0, 20, 20, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                    }
                    else
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 20, 100, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 5)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        if (s.TargetGuarding == true)
                        {
                            SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 50, 6, 20, 20, 30, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                        else if (s.TargetGuarding == false)
                        {
                            SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 20, 6, 50, 20, 30, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                    }
                    else
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 100, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 4)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        if (SelfEffect(s, 14475) == true)
                        {
                            if (s.TargetGuarding == true)
                            {
                                SetWeights(w, 1, 10, 2, 0, 3, 0, 4, 0, 5, 30, 6, 0, 16, 100, 20, 0, 21, 0, 22, 60, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == false)
                            {
                                SetWeights(w, 1, 30, 2, 0, 3, 0, 4, 0, 5, 20, 6, 0, 16, 100, 20, 0, 21, 0, 22, 50, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                        }
                        else if (SelfEffect(s, 14475) == false)
                        {
                            if (s.TargetGuarding == true)
                            {
                                SetWeights(w, 1, 10, 2, 0, 3, 0, 4, 0, 5, 30, 6, 0, 20, 0, 21, 0, 22, 60, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == false)
                            {
                                SetWeights(w, 1, 30, 2, 0, 3, 0, 4, 0, 5, 20, 6, 0, 20, 0, 21, 0, 22, 50, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                        }
                    }
                    else if (InCone(s, -90, 120, 100))
                    {
                        SetWeights(w, 1, 30, 2, 0, 3, 0, 4, 0, 5, 20, 6, 0, 7, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 50, 26, 0, 27, 0);
                    }
                    else if (InCone(s, 90, 120, 100))
                    {
                        SetWeights(w, 1, 30, 2, 0, 3, 0, 4, 0, 5, 20, 6, 0, 7, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 50, 26, 0, 27, 0);
                    }
                    else
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 100, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 2.5)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        if (SelfEffect(s, 14475) == true)
                        {
                            if (s.SourceTargetEffect51 == true)
                            {
                                SetWeights(w, 1, 50, 2, 0, 3, 0, 4, 50, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == true)
                            {
                                SetWeights(w, 1, 10, 2, 0, 3, 0, 4, 40, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 50, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == false)
                            {
                                SetWeights(w, 1, 40, 2, 0, 3, 20, 4, 10, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 30, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                        }
                        else if (SelfEffect(s, 14475) == false)
                        {
                            if (s.SourceTargetEffect51 == true)
                            {
                                SetWeights(w, 1, 50, 2, 0, 3, 0, 4, 50, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == true)
                            {
                                SetWeights(w, 1, 10, 2, 0, 3, 0, 4, 40, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 50, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == false)
                            {
                                SetWeights(w, 1, 40, 2, 0, 3, 20, 4, 10, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 30, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                        }
                    }
                    else if (InCone(s, -90, 120, 100))
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 10, 5, 0, 6, 0, 7, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 60, 26, 0, 27, 0);
                    }
                    else if (InCone(s, 90, 120, 100))
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 10, 5, 0, 6, 0, 7, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 60, 26, 0, 27, 0);
                    }
                    else
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 10, 5, 0, 6, 0, 7, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 60, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 1.5)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        if (SelfEffect(s, 14475) == true)
                        {
                            if (s.SourceTargetEffect51 == true)
                            {
                                SetWeights(w, 1, 50, 2, 0, 3, 0, 4, 50, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == true)
                            {
                                SetWeights(w, 1, 20, 2, 0, 3, 20, 4, 0, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 40, 22, 0, 23, 0, 24, 0, 25, 20, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == false)
                            {
                                SetWeights(w, 1, 60, 2, 0, 3, 40, 4, 0, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                        }
                        else if (SelfEffect(s, 14475) == false)
                        {
                            if (s.SourceTargetEffect51 == true)
                            {
                                SetWeights(w, 1, 50, 2, 0, 3, 0, 4, 50, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == true)
                            {
                                SetWeights(w, 1, 20, 2, 0, 3, 20, 4, 0, 5, 0, 6, 0, 15, 100, 20, 0, 21, 40, 22, 0, 23, 0, 24, 0, 25, 20, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == false)
                            {
                                SetWeights(w, 1, 60, 2, 0, 3, 40, 4, 0, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                        }
                    }
                    else if (InCone(s, -90, 120, 100))
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 0, 5, 0, 6, 0, 7, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 70, 26, 0, 27, 0);
                    }
                    else if (InCone(s, 90, 120, 100))
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 0, 5, 0, 6, 0, 7, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 70, 26, 0, 27, 0);
                    }
                    else
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 0, 5, 0, 6, 0, 7, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 70, 27, 0);
                    }
                }
                else if (InCone(s, 0, 120, 100))
                {
                    if (SelfEffect(s, 14475) == true)
                    {
                        if (s.SourceTargetEffect51 == true)
                        {
                            SetWeights(w, 1, 50, 2, 0, 3, 0, 4, 50, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                        else if (s.TargetGuarding == true)
                        {
                            SetWeights(w, 1, 0, 2, 50, 3, 0, 4, 0, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 30, 22, 0, 23, 0, 24, 0, 25, 20, 26, 0, 27, 0);
                        }
                        else if (s.TargetGuarding == false)
                        {
                            SetWeights(w, 1, 30, 2, 50, 3, 20, 4, 0, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                    }
                    else if (SelfEffect(s, 14475) == false)
                    {
                        if (s.SourceTargetEffect51 == true)
                        {
                            SetWeights(w, 1, 50, 2, 0, 3, 0, 4, 50, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                        else if (s.TargetGuarding == true)
                        {
                            SetWeights(w, 1, 0, 2, 50, 3, 0, 4, 0, 5, 0, 6, 0, 15, 100, 20, 0, 21, 30, 22, 0, 23, 0, 24, 0, 25, 20, 26, 0, 27, 0);
                        }
                        else if (s.TargetGuarding == false)
                        {
                            SetWeights(w, 1, 30, 2, 50, 3, 20, 4, 0, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                    }
                }
                else if (InCone(s, -90, 120, 100))
                {
                    SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 0, 5, 0, 6, 0, 7, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 70, 26, 0, 27, 0);
                }
                else if (InCone(s, 90, 120, 100))
                {
                    SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 0, 5, 0, 6, 0, 7, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 70, 26, 0, 27, 0);
                }
                else
                {
                    SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 0, 5, 0, 6, 0, 7, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 70, 27, 0);
                }
            }
            else if (SelfEffect(s, 14477) == true)
            {
                if (SourceDistance(s) >= 20)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 50, 6, 30, 20, 20, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                    else
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 20, 100, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 15)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 50, 6, 30, 20, 20, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                    else
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 20, 100, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 9)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        if (s.TargetGuarding == true)
                        {
                            SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 50, 6, 30, 20, 20, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                        else if (s.TargetGuarding == false)
                        {
                            SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 50, 6, 30, 20, 20, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                    }
                    else
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 20, 100, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 8)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        if (s.TargetGuarding == true)
                        {
                            SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 50, 6, 30, 20, 20, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                        else if (s.TargetGuarding == false)
                        {
                            SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 40, 6, 40, 20, 20, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                    }
                    else
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 20, 100, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 5)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        if (s.TargetGuarding == true)
                        {
                            SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 50, 6, 20, 20, 30, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                        else if (s.TargetGuarding == false)
                        {
                            SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 20, 6, 50, 20, 30, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                    }
                    else
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 100, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 4)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        if (SelfEffect(s, 14475) == true)
                        {
                            if (s.TargetGuarding == true)
                            {
                                SetWeights(w, 1, 10, 2, 0, 3, 0, 4, 0, 5, 30, 6, 0, 16, 100, 20, 0, 21, 0, 22, 60, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == false)
                            {
                                SetWeights(w, 1, 30, 2, 0, 3, 0, 4, 0, 5, 20, 6, 0, 16, 100, 20, 0, 21, 0, 22, 50, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                        }
                        else if (SelfEffect(s, 14475) == false)
                        {
                            if (s.TargetGuarding == true)
                            {
                                SetWeights(w, 1, 10, 2, 0, 3, 0, 4, 0, 5, 30, 6, 0, 20, 0, 21, 0, 22, 60, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == false)
                            {
                                SetWeights(w, 1, 30, 2, 0, 3, 0, 4, 0, 5, 20, 6, 0, 20, 0, 21, 0, 22, 50, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                        }
                    }
                    else if (InCone(s, -90, 120, 100))
                    {
                        SetWeights(w, 1, 30, 2, 0, 3, 0, 4, 0, 5, 20, 6, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 50, 26, 0, 27, 0);
                    }
                    else if (InCone(s, 90, 120, 100))
                    {
                        SetWeights(w, 1, 30, 2, 0, 3, 0, 4, 0, 5, 20, 6, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 50, 26, 0, 27, 0);
                    }
                    else
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 100, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 2.5)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        if (SelfEffect(s, 14475) == true)
                        {
                            if (s.SourceTargetEffect51 == true)
                            {
                                SetWeights(w, 1, 50, 2, 0, 3, 0, 4, 50, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == true)
                            {
                                SetWeights(w, 1, 10, 2, 0, 3, 0, 4, 40, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 50, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == false)
                            {
                                SetWeights(w, 1, 40, 2, 0, 3, 20, 4, 10, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 30, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                        }
                        else if (SelfEffect(s, 14475) == false)
                        {
                            if (s.SourceTargetEffect51 == true)
                            {
                                SetWeights(w, 1, 50, 2, 0, 3, 0, 4, 50, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == true)
                            {
                                SetWeights(w, 1, 10, 2, 0, 3, 0, 4, 40, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 50, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == false)
                            {
                                SetWeights(w, 1, 40, 2, 0, 3, 20, 4, 10, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 30, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                        }
                    }
                    else if (InCone(s, -90, 120, 100))
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 10, 5, 0, 6, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 60, 26, 0, 27, 0);
                    }
                    else if (InCone(s, 90, 120, 100))
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 10, 5, 0, 6, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 60, 26, 0, 27, 0);
                    }
                    else
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 10, 5, 0, 6, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 60, 27, 0);
                    }
                }
                else if (SourceDistance(s) >= 1.5)
                {
                    if (InCone(s, 0, 120, 100))
                    {
                        if (SelfEffect(s, 14475) == true)
                        {
                            if (s.SourceTargetEffect51 == true)
                            {
                                SetWeights(w, 1, 50, 2, 0, 3, 0, 4, 50, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == true)
                            {
                                SetWeights(w, 1, 20, 2, 0, 3, 20, 4, 0, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 40, 22, 0, 23, 0, 24, 0, 25, 20, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == false)
                            {
                                SetWeights(w, 1, 60, 2, 0, 3, 40, 4, 0, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                        }
                        else if (SelfEffect(s, 14475) == false)
                        {
                            if (s.SourceTargetEffect51 == true)
                            {
                                SetWeights(w, 1, 50, 2, 0, 3, 0, 4, 50, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == true)
                            {
                                SetWeights(w, 1, 20, 2, 0, 3, 20, 4, 0, 5, 0, 6, 0, 15, 100, 20, 0, 21, 40, 22, 0, 23, 0, 24, 0, 25, 20, 26, 0, 27, 0);
                            }
                            else if (s.TargetGuarding == false)
                            {
                                SetWeights(w, 1, 60, 2, 0, 3, 40, 4, 0, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                            }
                        }
                    }
                    else if (InCone(s, -90, 120, 100))
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 0, 5, 0, 6, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 70, 26, 0, 27, 0);
                    }
                    else if (InCone(s, 90, 120, 100))
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 0, 5, 0, 6, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 70, 26, 0, 27, 0);
                    }
                    else
                    {
                        SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 0, 5, 0, 6, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 70, 27, 0);
                    }
                }
                else if (InCone(s, 0, 120, 100))
                {
                    if (SelfEffect(s, 14475) == true)
                    {
                        if (s.SourceTargetEffect51 == true)
                        {
                            SetWeights(w, 1, 50, 2, 0, 3, 0, 4, 50, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                        else if (s.TargetGuarding == true)
                        {
                            SetWeights(w, 1, 0, 2, 50, 3, 0, 4, 0, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 30, 22, 0, 23, 0, 24, 0, 25, 20, 26, 0, 27, 0);
                        }
                        else if (s.TargetGuarding == false)
                        {
                            SetWeights(w, 1, 30, 2, 50, 3, 20, 4, 0, 5, 0, 6, 0, 15, 100, 16, 150, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                    }
                    else if (SelfEffect(s, 14475) == false)
                    {
                        if (s.SourceTargetEffect51 == true)
                        {
                            SetWeights(w, 1, 50, 2, 0, 3, 0, 4, 50, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                        else if (s.TargetGuarding == true)
                        {
                            SetWeights(w, 1, 0, 2, 50, 3, 0, 4, 0, 5, 0, 6, 0, 15, 100, 20, 0, 21, 30, 22, 0, 23, 0, 24, 0, 25, 20, 26, 0, 27, 0);
                        }
                        else if (s.TargetGuarding == false)
                        {
                            SetWeights(w, 1, 30, 2, 50, 3, 20, 4, 0, 5, 0, 6, 0, 15, 100, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0);
                        }
                    }
                }
                else if (InCone(s, -90, 120, 100))
                {
                    SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 0, 5, 0, 6, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 70, 26, 0, 27, 0);
                }
                else if (InCone(s, 90, 120, 100))
                {
                    SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 0, 5, 0, 6, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 70, 26, 0, 27, 0);
                }
                else
                {
                    SetWeights(w, 1, 0, 2, 0, 3, 30, 4, 0, 5, 0, 6, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 70, 27, 0);
                }
            }
            return w;
        }
    }
}
