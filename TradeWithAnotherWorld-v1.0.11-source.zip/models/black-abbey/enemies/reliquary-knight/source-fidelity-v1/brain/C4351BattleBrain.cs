// Engine-neutral, bounded adaptation of recovered435100 sword/shield decisions.
// Original code remains private. This module does not execute the game VM,
// create hitboxes/projectiles, drive transforms, or claim a complete AI port.
using System;
using System.Collections.Generic;

namespace BlackAbbey.ReliquaryKnight
{
    public enum DecisionKind { Idle, Move, StartClip, HoldClip, ExternalReaction }
    public enum MotionPhase { None, Preparation, Active, Recovery }
    public enum MovementKind { None, Approach, Retreat, CircleLeft, CircleRight, Turn }

    public sealed class EventWindow
    {
        public int EffectId;
        public double Start;
        public double End;
    }

    public sealed class ClipSpec
    {
        public int CommandId;
        public string ClipId = "";
        public double Duration;
        // Admission is the adapter's explicit approval, not inferred from an ID.
        public bool AutonomousAllowed;
        public bool IsAdditive;
        public EventWindow[] BranchEffects = new EventWindow[0];
        public EventWindow[] ComboCancelWindows = new EventWindow[0];
        public EventWindow[] AttackWindows = new EventWindow[0];
    }

    public sealed class SenseFrame
    {
        public double NowSeconds;
        public double DistanceWorld;
        // Positive yaw puts the target to the actor's right; source cones use
        // full horizontal widths. Vertical/floor admission belongs to adapter.
        public double FacingDegrees;
        public bool TargetValid = true;
        public bool TargetGuarding;
        public bool TargetAttacking; // perception only; NOT source effect51.
        public bool TargetUsingItem;
        public bool TargetFiredProjectile;
        public bool SuccessfulGuard;
        public bool WasDamaged;
        public bool GuardBroken;
        public bool SourceTargetEffect51;
        public bool SourceAsleepOrLadder;
        public bool PathReady = true;
        public bool AttackAdmission = true;
        public bool CanGuard = true;
        public bool CanMoveForward = true;
        public bool CanMoveBackward = true;
        public bool CanMoveLeft = true;
        public bool CanMoveRight = true;
        // Feedback belongs to one movement goal. A completed pivot inside an
        // approach does not complete the enclosing approach or its attack.
        public int MovementGoalId;
        public bool MovementBlocked;
        public bool MovementCompleted;
        public double MovementProgress;
        public int PreviousActionId; // telemetry; source has no new anti-repeat rule.
        // null => actual primaryNpc43510000's14477 baseline. Explicit arrays
        // replace it, preserving opaque source flags without inventing semantics.
        public int[] SourceSelfEffects;
        // Source clip seconds, not frame/30. Negative => monotonic clock fallback.
        public double CurrentClipTime = -1;
        public int[] ActivatedSourceEffects = new int[0];
    }

    public sealed class Decision
    {
        public DecisionKind Kind;
        public int SourceActionId;
        public int CommandId = -1;
        public string ClipId = "";
        public MovementKind Movement;
        public MovementKind GoalMovement;
        public int GoalId;
        public string MovementClipId = "";
        public double StopDistanceWorld;
        public double GoalSecondsRemaining;
        public bool GuardRequested;
        public int GuardChancePercent;
        public bool RunRequested;
        public double TargetTurnDegrees;
        public double TurnClipNominalDegrees;
        public bool Committed;
        public bool InSource5039Lock;
        public MotionPhase Phase;
        public int QueuedSuccessorCommand = -1;
        public string Provenance = "";
    }

    public sealed partial class C4351BattleBrain
    {
        private readonly Dictionary<int,ClipSpec> _clips = new Dictionary<int,ClipSpec>();
        private readonly Dictionary<int,double> _performed = new Dictionary<int,double>();
        private readonly HashSet<int> _observed = new HashSet<int>();
        private readonly HashSet<int> _externalActive = new HashSet<int>();
        private readonly double _scale;
        private readonly double _radius;
        private uint _rng;
        private ClipSpec _current;
        private int _currentAction;
        private double _started;
        private double _lastClipTime = -1;
        private double _lastNow = -1;
        private int _pendingCommand = -1;
        private int _pendingAction;
        private int _approachCommand = -1;
        private int _approachAction;
        private double _approachStop;
        private double _approachUntil;
        private bool _approachRun;
        private MovementKind _movement;
        private int _movementAction;
        private double _movementUntil;
        private double _movementStop;
        private bool _afterStepCircle;
        private double _deferredCircleSeconds = -1;
        private MovementKind _deferredCircleDirection;
        private int _deferredCircleAction;
        private string _movementProvenance = "";
        private int _goalSerial, _movementGoalId, _approachGoalId;
        private MovementKind _blockedMovement;
        private double _blockedUntil, _pausedGoalSeconds, _goalProgress;
        private string _lastGoalResult = "none";

        public C4351BattleBrain(uint seed, IEnumerable<ClipSpec> clips,
            double sourceUnitsToWorld = 1, double sourceHitRadius = .5)
        {
            if (!Finite(sourceUnitsToWorld) || sourceUnitsToWorld <= 0) throw new ArgumentOutOfRangeException("sourceUnitsToWorld");
            if (!Finite(sourceHitRadius) || sourceHitRadius < 0) throw new ArgumentOutOfRangeException("sourceHitRadius");
            _scale=sourceUnitsToWorld;_radius=sourceHitRadius;_rng=seed==0?0x9E3779B9u:seed;
            _repertoireRng=_rng^0xA341316Cu;if(_repertoireRng==0)_repertoireRng=0x85EBCA6Bu;
            foreach (var c in clips)
            {
                if (c == null || c.IsAdditive || String.IsNullOrEmpty(c.ClipId) || !Finite(c.Duration) || c.Duration <= 0) continue;
                if (_clips.ContainsKey(c.CommandId)) throw new ArgumentException("Duplicate TAE command, not duplicate pose: "+c.CommandId);
                _clips.Add(c.CommandId,c);
            }
            ResetObservers();
        }

        public int CurrentCommandId { get { return _current==null?-1:_current.CommandId; } }
        public int QueuedSuccessorCommand { get { return _pendingCommand; } }
        public double SourceUnitsToWorld { get { return _scale; } }
        public int CurrentGoalId { get { return _approachCommand>=0?_approachGoalId:_movement!=MovementKind.None?_movementGoalId:0; } }
        public string LastGoalResult { get { return _lastGoalResult; } }
        public double PausedGoalSeconds { get { return _pausedGoalSeconds; } }
        public double LastMovementProgress { get { return _goalProgress; } }
        // Contexts pause only movement/approach budgets. Attack source clocks
        // and cooldown timestamps retain their original physical/wall time.
        public void PauseGoalClock(double nowSeconds)
        {
            if(!Finite(nowSeconds)||nowSeconds<0||nowSeconds<_lastNow)throw new ArgumentException("Monotonic finite goal pause time required.");
            if(_lastNow>=0){double dt=nowSeconds-_lastNow;
                if(_approachCommand>=0)_approachUntil+=dt;
                if(_movement!=MovementKind.None)_movementUntil+=dt;
                if(_approachCommand>=0||_movement!=MovementKind.None)_pausedGoalSeconds+=dt;
            }
            _lastNow=nowSeconds;
        }
        int NextGoal(){_goalSerial=_goalSerial==int.MaxValue?1:_goalSerial+1;_goalProgress=0;return _goalSerial;}
        bool MovementAllowed(MovementKind movement,SenseFrame s)
        {
            if(movement==MovementKind.None)return false;
            if(_blockedMovement==movement&&s.NowSeconds<_blockedUntil)return false;
            if(movement==MovementKind.Turn)return s.AttackAdmission;
            return movement==MovementKind.Approach?s.PathReady&&s.CanMoveForward:
                movement==MovementKind.Retreat?s.CanMoveBackward:
                movement==MovementKind.CircleLeft?s.CanMoveLeft:s.CanMoveRight;
        }
        void ConsumeMovementFeedback(SenseFrame s)
        {
            bool approach=_approachCommand>=0&&s.MovementGoalId==_approachGoalId;
            bool movement=_movement!=MovementKind.None&&s.MovementGoalId==_movementGoalId;
            if(s.MovementGoalId<=0||!approach&&!movement)return;
            if(Finite(s.MovementProgress)&&s.MovementProgress>=0)_goalProgress=Math.Max(_goalProgress,s.MovementProgress);
            if(s.MovementBlocked){
                _blockedMovement=approach?MovementKind.Approach:_movement;_blockedUntil=s.NowSeconds+.75;
                if(approach){_approachCommand=-1;_approachGoalId=0;}
                if(movement){_movement=MovementKind.None;_movementGoalId=0;}
                _lastGoalResult="blocked; replanning";
            }else if(movement&&s.MovementCompleted){_movement=MovementKind.None;_movementGoalId=0;_lastGoalResult="completed";}
            // An approach's own distance predicate starts its queued attack.
            // Ignore completion of a temporary facing pivot within that goal.
        }
        private static bool Finite(double x) { return !Double.IsNaN(x) && !Double.IsInfinity(x); }
        private double SourceDistance(SenseFrame s) { return Math.Max(0,s.DistanceWorld/_scale); }
        private bool SelfEffect(SenseFrame s,int effect)
        {
            if (s.SourceSelfEffects==null) return effect==14477;
            return Array.IndexOf(s.SourceSelfEffects,effect)>=0;
        }
        private static double Angle(double yaw)
        { double angle=yaw%360;if(angle>180)angle-=360;if(angle< -180)angle+=360;return angle; }
        private bool InCone(SenseFrame s,double centre,double fullWidth,double maxSourceDistance)
        {
            double angle=Angle(s.FacingDegrees-centre);
            return SourceDistance(s)<=maxSourceDistance && Math.Abs(angle)<=fullWidth*.5;
        }
        private static void SetWeights(Dictionary<int,int> w,params int[] pairs)
        { for(int i=0;i<pairs.Length;i+=2)w[pairs[i]]=pairs[i+1]; }
        private int Roll(int max)
        {
            // Reproducible local RNG; seed/sample sequence is an adaptation,
            // source probabilities/relative weights are retained separately.
            _rng^=_rng<<13;_rng^=_rng>>17;_rng^=_rng<<5;
            return 1+(int)(_rng%(uint)max);
        }
        private double RandomTime(double min,double max) { return min+(max-min)*(Roll(10000)-1)/9999.0; }
        private void ResetObservers()
        { _observed.Clear();_observed.Add(5030);_observed.Add(5032);_observed.Add(5039); }
        private void ObserveAction(int action)
        {
            ResetObservers();
            if(action==1){_observed.Add(5025);_observed.Add(5026);}
            if(action==2){_observed.Add(5027);_observed.Add(5031);}
            if(action==3)_observed.Add(5028);
            if(action==5)_observed.Add(5029);
            if(action==15)_observed.Add(5035);
        }
        public void ReportAttackPerformed(int commandId,double nowSeconds)
        { if(!Finite(nowSeconds))throw new ArgumentOutOfRangeException("nowSeconds");_performed[commandId]=nowSeconds; }
        private bool Cooling(int command,double seconds,double now)
        { double time;return _performed.TryGetValue(command,out time) && now-time<=seconds; }
        private static readonly int[,] Cooldowns = new int[,] {
            {1,3000,10,1},{2,3003,5,1},{3,3004,10,1},{4,3005,15,1},{4,3015,15,1},
            {5,3006,15,1},{5,3016,15,1},{6,3009,10,1},{7,3020,1,1},{10,3000,5,1},
            {11,3020,1,1},{15,3022,15,1},{16,3024,20,1},{25,6001,4,0},{26,6002,4,0},{26,6003,4,0}};
        public Dictionary<int,int> SourceWeightsWithCooldowns(SenseFrame s)
        {
            var w=RawSourceWeights(s);
            for(int i=0;i<Cooldowns.GetLength(0);i++)
            {
                int act=Cooldowns[i,0],value;
                if(w.TryGetValue(act,out value) && value>0 && Cooling(Cooldowns[i,1],Cooldowns[i,2],s.NowSeconds))w[act]=Cooldowns[i,3];
            }
            return w;
        }
        private int Variant(SenseFrame s,int normal,int source14475) { return SelfEffect(s,14475)?source14475:normal; }
        private int CommandForAction(int action,SenseFrame s)
        {
            switch(action){case 1:return 3000;case 2:return 3003;case 3:return 3004;
                case 4:return Variant(s,3005,3015);case 5:return Variant(s,3006,3016);case 6:return 3009;
                case 15:return 3022;case 16:return 3024;case 25:return 6001;
                case 26:return Angle(s.FacingDegrees)>=0?6002:6003;default:return -1;}
        }
        private bool Admitted(int command,SenseFrame s)
        {
            ClipSpec c;bool exists=_clips.TryGetValue(command,out c) && c.AutonomousAllowed && !c.IsAdditive;
            if(command==6000)return exists && s.AttackAdmission && s.CanMoveForward;
            if(command==6001)return exists && s.AttackAdmission && s.CanMoveBackward;
            if(command==6002)return exists && s.AttackAdmission && s.CanMoveLeft;
            if(command==6003)return exists && s.AttackAdmission && s.CanMoveRight;
            return exists && s.AttackAdmission;
        }
        private bool Is5039Locked(SenseFrame s,double elapsed)
        {
            if(SelfEffect(s,5039))return true;
            if(_current!=null)foreach(var w in _current.BranchEffects)if(w.EffectId==5039 && elapsed>=w.Start && elapsed<w.End)return true;
            return false;
        }
        private bool CancelOpen(double elapsed)
        { if(_current!=null)foreach(var w in _current.ComboCancelWindows)if(elapsed>=w.Start && elapsed<w.End)return true;return false; }
        private Decision Hold(SenseFrame s,double elapsed)
        {
            MotionPhase phase=_current.AttackWindows.Length==0?MotionPhase.None:MotionPhase.Preparation;double lastEnd=-1;
            foreach(var w in _current.AttackWindows){lastEnd=Math.Max(lastEnd,w.End);if(elapsed>=w.Start && elapsed<w.End)phase=MotionPhase.Active;}
            if(phase!=MotionPhase.Active && lastEnd>=0 && elapsed>=lastEnd)phase=MotionPhase.Recovery;
            return new Decision{Kind=DecisionKind.HoldClip,SourceActionId=_currentAction,CommandId=_current.CommandId,ClipId=_current.ClipId,
                Committed=true,InSource5039Lock=Is5039Locked(s,elapsed),Phase=phase,QueuedSuccessorCommand=_pendingCommand,
                GoalSecondsRemaining=Math.Max(0,_current.Duration-elapsed),Provenance="Current source clip commitment/recovery; successors wait for own command cancel window."};
        }
        private Decision Start(int command,int action,SenseFrame s,string why,bool resetObservers)
        {
            if(!Admitted(command,s))return Idle(s,"Unavailable/unapproved/additive command was not admitted.");
            _current=_clips[command];_currentAction=action;_started=s.NowSeconds;_lastClipTime=-1;
            _pendingCommand=-1;_approachCommand=-1;_approachGoalId=0;_movement=MovementKind.None;_movementGoalId=0;_externalActive.Clear();_deferredCircleSeconds=-1;
            if(command!=6001)_afterStepCircle=false;
            if(resetObservers)ObserveAction(action);
            ReportAttackPerformed(command,s.NowSeconds);
            int primary=KnightAttackRepertoire.ParentCommand(action,command);
            if(primary!=command){ReportAttackPerformed(primary,s.NowSeconds);why+=" "+KnightAttackRepertoire.Provenance(command);}
            return new Decision{Kind=DecisionKind.StartClip,SourceActionId=action,CommandId=command,ClipId=_current.ClipId,
                Committed=true,InSource5039Lock=Is5039Locked(s,0),Phase=_current.AttackWindows.Length>0?MotionPhase.Preparation:MotionPhase.None,Provenance=why};
        }
        private Decision Idle(SenseFrame s,string why)
        { bool guard=s.CanGuard && !s.GuardBroken;return new Decision{Kind=DecisionKind.Idle,GuardRequested=guard,GuardChancePercent=guard?100:0,MovementClipId=Pose(guard?30:20),Provenance=why}; }
        private string Pose(int command) { ClipSpec c;return _clips.TryGetValue(command,out c)?c.ClipId:""; }
        public int TurnCommandFor(SenseFrame s,out double nominalDegrees)
        {
            double angle=Angle(s.FacingDegrees),size=Math.Abs(angle);nominalDegrees=0;
            if(size<45)return -1;
            int dir=size<67.5?(angle<0?4:5):size<135?(angle<0?0:1):(angle<0?2:3);
            int[] styles=s.CanGuard?new[]{2,0,1}:new[]{0,1,2};
            foreach(int style in styles)
            {
                int command=5000+style*10+dir;
                if(_clips.ContainsKey(command)){nominalDegrees=dir>=4?45:dir>=2?180:90;return command;}
                if(dir>=4)
                {
                    command=5000+style*10+(dir==4?0:1);
                    if(_clips.ContainsKey(command)){nominalDegrees=90;return command;}
                }
            }
            return -1;
        }
        private Decision Move(SenseFrame s,MovementKind move,double stop,double until,string why,bool run=false)
        {
            MovementKind goalMovement=move;
            int basis=s.CanGuard?2030:2000;
            int clip=move==MovementKind.Approach?(run?(s.CanGuard?2130:2100):basis):move==MovementKind.Retreat?basis+1:move==MovementKind.CircleLeft?basis+2:move==MovementKind.CircleRight?basis+3:s.CanGuard?30:20;
            double nominal=0;
            if(move==MovementKind.Approach || move==MovementKind.Turn)
            {
                int turn=TurnCommandFor(s,out nominal);
                if(turn>=0){move=MovementKind.Turn;clip=turn;run=false;why+=" CommonHKS ExecTurn selects an available source pivot before forward gait.";}
            }
            if(!MovementAllowed(move,s)){
                if(_approachCommand>=0){_approachCommand=-1;_approachGoalId=0;}
                _movement=MovementKind.None;_movementGoalId=0;_lastGoalResult="clearance/path unavailable; replanning";
                return Idle(s,"Adapter path/clearance admission ends this source movement goal.");
            }
            return new Decision{Kind=DecisionKind.Move,SourceActionId=_approachCommand>=0?_approachAction:_movementAction,Movement=move,GoalMovement=goalMovement,GoalId=_approachCommand>=0?_approachGoalId:_movementGoalId,MovementClipId=Pose(clip),StopDistanceWorld=stop*_scale,
                GoalSecondsRemaining=Math.Max(0,until-s.NowSeconds),GuardRequested=s.CanGuard,GuardChancePercent=s.CanGuard?100:0,RunRequested=run,
                TargetTurnDegrees=Angle(s.FacingDegrees),TurnClipNominalDegrees=nominal,QueuedSuccessorCommand=_approachCommand,Provenance=why};
        }
        private void PlanMovement(SenseFrame s,MovementKind move,double seconds,double stop,string why,int action=0)
        { _movement=move;_movementGoalId=NextGoal();_movementAction=action;_movementUntil=s.NowSeconds+seconds;_movementStop=stop;_movementProvenance=why; }
        private bool MovementActionAllowed(int action,SenseFrame s)
        {
            if(action==20){double nominal;return MovementAllowed(MovementKind.Approach,s)||MovementAllowed(MovementKind.Turn,s)&&TurnCommandFor(s,out nominal)>=0;}
            if(action==21)return MovementAllowed(MovementKind.Retreat,s)||MovementAllowed(MovementKind.CircleLeft,s)||MovementAllowed(MovementKind.CircleRight,s);
            if(action==22)return MovementAllowed(MovementKind.CircleLeft,s)||MovementAllowed(MovementKind.CircleRight,s);
            if(action==23){double nominal;return MovementAllowed(MovementKind.Turn,s)&&TurnCommandFor(s,out nominal)>=0;}
            return false;
        }
        private void BeginDeferredCircle(SenseFrame s)
        {
            PlanMovement(s,_deferredCircleDirection,_deferredCircleSeconds,0,"Source branch circle entered at its explicit movement cancellation channel.",_deferredCircleAction);
            _deferredCircleSeconds=-1;_afterStepCircle=false;_current=null;_pendingCommand=-1;
        }
        private int Circle(SenseFrame s,int action=0,bool deferUntilRecovery=false,double minimumSeconds=2.5,double maximumSeconds=3.5)
        {
            MovementKind direction=Roll(2)==1?MovementKind.CircleLeft:MovementKind.CircleRight;
            if(direction==MovementKind.CircleLeft && !MovementAllowed(direction,s))direction=MovementKind.CircleRight;
            if(direction==MovementKind.CircleRight && !MovementAllowed(direction,s))direction=MovementKind.CircleLeft;
            double seconds=RandomTime(minimumSeconds,maximumSeconds);
            if(deferUntilRecovery){_deferredCircleSeconds=seconds;_deferredCircleDirection=direction;_deferredCircleAction=action;return -2;}
            PlanMovement(s,direction,seconds,0,"Source435100 guarded sideway goal; adapter supplies safe path.",action);return -2;
        }
        private int Branch(int effect,SenseFrame s,int roll)
        {
            if(!_observed.Contains(effect))return -1;
            if(effect==5025 && InCone(s,0,180,4))return 3001;
            if(effect==5026 || effect==5028)
            {
                if(InCone(s,0,180,3))return s.SourceTargetEffect51 || roll<=60?Variant(s,3007,3017):3002;
                if(InCone(s,0,180,4.5) && (s.SourceTargetEffect51 || roll<=80))return 3002;
            }
            if(effect==5027 && InCone(s,0,180,4) && s.TargetGuarding && roll<=90)return 3013;
            if(effect==5029)
            {
                if(InCone(s,0,160,3))return s.SourceTargetEffect51 || roll<=50?Variant(s,3008,3018):Variant(s,3010,3019);
                if(InCone(s,0,360,4.5) && (s.SourceTargetEffect51 || roll<=90))return Variant(s,3010,3019);
            }
            if(effect==5030 && InCone(s,0,180,4) && s.TargetGuarding)
            { if(Admitted(6001,s))_afterStepCircle=roll>80;return 6001; }
            if(effect==5031 || effect==5032)
            {
                if(InCone(s,0,180,3.5))return -1;
                if(InCone(s,0,180,5))
                { if(roll<=60){_observed.Add(5029);return Variant(s,3006,3016);}return Circle(s,_currentAction,true); }
                if(InCone(s,0,180,8))
                {
                    int first=s.TargetGuarding?(effect==5031?40:50):30;
                    int second=effect==5031?70:80;
                    if(roll<=first){_observed.Add(5029);return Variant(s,3006,3016);}
                    if(roll<=second)return 3009;return Circle(s,_currentAction,true);
                }
            }
            if(effect==5035 && InCone(s,0,180,4.5) && !s.TargetGuarding && roll<=90)return 3023;
            return -1;
        }
        private Decision ExternalInterrupt(SenseFrame s,bool locked)
        {
            if(locked || !(s.SuccessfulGuard || s.WasDamaged || s.TargetUsingItem || s.TargetFiredProjectile))return null;int roll=Roll(100);
            bool itemRelevant=s.TargetUsingItem && InCone(s,0,120,20);
            bool shootRelevant=s.TargetFiredProjectile && InCone(s,0,120,20);
            bool guardRelevant=s.SuccessfulGuard && InCone(s,0,140,4);
            if(!itemRelevant && !shootRelevant && guardRelevant && Admitted(3011,s))
                return Start(3011,0,s,"Source successful-guard interrupt counter3011, not a parry.",false);
            if(!itemRelevant && !shootRelevant && !guardRelevant && s.WasDamaged && InCone(s,0,120,4))
            {
                if(roll<=50)
                {
                    if(s.CanMoveBackward)PlanMovement(s,MovementKind.Retreat,2,10,"Source damaged interrupt:50% guarded leave goal toward distance10.");
                    else Circle(s,0,false,2,2.5);
                    _current=null;_pendingCommand=-1;return Move(s,_movement,_movementStop,_movementUntil,_movementProvenance);
                }
                if(Admitted(6001,s))return Start(6001,0,s,"Source damaged interrupt backward safety step.",false);
            }
            if(s.TargetUsingItem)
            {
                int cmd=-1;
                if(InCone(s,0,120,5)){if(roll<=80)cmd=3000;}
                else if(InCone(s,0,120,8)){if(roll<=50)cmd=3009;else if(roll<=80)cmd=Variant(s,3006,3016);}
                else if(InCone(s,0,120,9)){if(roll<=80)cmd=Variant(s,3006,3016);}
                else if(InCone(s,0,120,20) && roll<=80){_current=null;_pendingCommand=-1;PlanMovement(s,MovementKind.Approach,3,4,"Source item-use interrupt guarded approach4.");return Move(s,_movement,4,_movementUntil,_movementProvenance);}
                if(cmd>=0 && Admitted(cmd,s)){if(cmd==3000){_observed.Add(5025);_observed.Add(5026);}if(cmd==3006||cmd==3016)_observed.Add(5029);return Start(cmd,0,s,"Source item-use interrupt.",false);}
            }
            if(s.TargetFiredProjectile && !itemRelevant)
            {
                if(InCone(s,0,120,4.5) && roll<=80 && Admitted(3000,s)){_observed.Add(5025);_observed.Add(5026);return Start(3000,0,s,"Source shoot interrupt close counter.",false);}
                if(InCone(s,0,120,9) && roll<=40){int cmd=Angle(s.FacingDegrees)>=0?6002:6003;if(Admitted(cmd,s))return Start(cmd,0,s,"Source shoot interrupt lateral safety step.",false);}
                else if(InCone(s,0,120,20) && roll<=80){_current=null;_pendingCommand=-1;PlanMovement(s,MovementKind.Approach,3,3.5,"Source shoot interrupt guarded approach3.5.");return Move(s,_movement,3.5,_movementUntil,_movementProvenance);}
            }
            return null;
        }

        public Decision Tick(SenseFrame s)
        {
            if(s==null || !Finite(s.NowSeconds) || !Finite(s.DistanceWorld) || !Finite(s.FacingDegrees) || s.NowSeconds<0)throw new ArgumentException("Finite senses and nonnegative absolute time required.");
            if(s.NowSeconds<_lastNow)throw new ArgumentException("Time must be monotonic; create/reset a brain for a new replay.");_lastNow=s.NowSeconds;
            if(s.GuardBroken || s.SourceAsleepOrLadder)
            { _current=null;_pendingCommand=-1;_approachCommand=-1;_approachGoalId=0;_movement=MovementKind.None;_movementGoalId=0;_deferredCircleSeconds=-1;_afterStepCircle=false;return new Decision{Kind=DecisionKind.ExternalReaction,Provenance="Native/source guard-break, ladder or sleep owns interruption; no invented reaction clip."}; }
            ConsumeMovementFeedback(s);
            double elapsed=_current==null?0:s.CurrentClipTime>=0?s.CurrentClipTime:s.NowSeconds-_started;
            if(!Finite(elapsed) || elapsed<0)throw new ArgumentException("Invalid source clip time.");
            if(_current!=null && elapsed+1e-7>=_current.Duration)
            {
                _current=null;
                if(_deferredCircleSeconds>=0)BeginDeferredCircle(s);
                else if(_afterStepCircle){_afterStepCircle=false;Circle(s);}
                if(_pendingCommand>=0 && s.TargetValid && Admitted(_pendingCommand,s))return Start(_pendingCommand,_pendingAction,s,"Queued source successor after actual pose completion.",false);
                _pendingCommand=-1;
            }
            if(!s.TargetValid)return _current!=null?Hold(s,elapsed):Idle(s,"No valid target; no autonomous attack admission.");
            // Primary sourceNpc43510000 profile is14477. Alternate ranged/stance
            // branches remain research tables, not silently enabled behavior.
            if(!SelfEffect(s,14477))return _current!=null?Hold(s,elapsed):Idle(s,"Unsupported source stance context; primary14477 consumer only.");
            var interrupt=ExternalInterrupt(s,_current!=null && Is5039Locked(s,elapsed));if(interrupt!=null)return interrupt;
            if(_current!=null)
            {
                if(elapsed+1e-7<_lastClipTime)throw new ArgumentException("Source clip time must advance monotonically within a committed clip.");
                var triggered=new HashSet<int>();
                foreach(var ev in _current.BranchEffects)
                    if(ev.EffectId>=5025 && ev.EffectId<=5035 && ev.Start>_lastClipTime && ev.Start<=elapsed)triggered.Add(ev.EffectId);
                var external=new HashSet<int>(s.ActivatedSourceEffects??new int[0]);
                foreach(int effect in external)if(!_externalActive.Contains(effect))triggered.Add(effect);
                _externalActive.Clear();foreach(int effect in external)_externalActive.Add(effect);
                var ordered=new List<int>(triggered);ordered.Sort();
                foreach(int effect in ordered)
                {int cmd=Branch(effect,s,Roll(100));if(cmd>=0 && Admitted(cmd,s)){_pendingCommand=cmd;_pendingAction=_currentAction;}}
                _lastClipTime=elapsed;
                if(_pendingCommand>=0 && CancelOpen(elapsed) && Admitted(_pendingCommand,s))return Start(_pendingCommand,_pendingAction,s,"Source branch successor admitted at command-specific AI combo cancel window.",false);
                if(_deferredCircleSeconds>=0 && !Is5039Locked(s,elapsed) && KnightTransitionPolicy.RecoveryMove(_current,elapsed)){
                    BeginDeferredCircle(s);return Move(s,_movement,_movementStop,_movementUntil,_movementProvenance);
                }
                return Hold(s,elapsed);
            }
            if(_approachCommand>=0)
            {
                if(SourceDistance(s)<=_approachStop && Admitted(_approachCommand,s)){_lastGoalResult="approach reached";return Start(RepertoireVariant(_approachCommand,_approachAction,s),_approachAction,s,"Source attack approach reached its source-radius stop.",true);}
                if(s.NowSeconds<_approachUntil)return Move(s,MovementKind.Approach,_approachStop,_approachUntil,"Source Approach_Act_Flex guarded approach, maximum3seconds.",_approachRun);
                _approachCommand=-1;_approachGoalId=0;_lastGoalResult="approach timed out; replanning";
            }
            if(_movement!=MovementKind.None && s.NowSeconds<_movementUntil)
            {
                if((_movement==MovementKind.Approach && SourceDistance(s)<=_movementStop) || (_movement==MovementKind.Retreat && SourceDistance(s)>=_movementStop) || (_movement==MovementKind.Turn && Math.Abs(Angle(s.FacingDegrees))<=90)){_movement=MovementKind.None;_movementGoalId=0;_lastGoalResult="completed";}
                else return Move(s,_movement,_movementStop,_movementUntil,_movementProvenance,_movement==MovementKind.Approach);
            }
            else if(_movement!=MovementKind.None){_movement=MovementKind.None;_movementGoalId=0;_lastGoalResult="movement lifetime completed";}
            var weights=SourceWeightsWithCooldowns(s);var admitted=new List<int>();int sum=0;
            foreach(var pair in weights)
            {
                if(pair.Value<=0)continue;int cmd=CommandForAction(pair.Key,s);
                bool allowed=cmd>=0?Admitted(cmd,s):MovementActionAllowed(pair.Key,s);
                if(allowed){admitted.Add(pair.Key);sum+=pair.Value;}
            }
            if(sum<=0)return Idle(s,"Source weights have no approved/available candidate; hold guard rather than invent an attack.");
            admitted.Sort();int pick=Roll(sum),chosen=admitted[0];
            foreach(int act in admitted){pick-=weights[act];if(pick<=0){chosen=act;break;}}
            int command=CommandForAction(chosen,s);
            if(command>=0)
            {
                command=RepertoireVariant(command,chosen,s);
                bool approach=chosen==1 || chosen==3 || chosen==4 || chosen==5 || chosen==6 || chosen==15 || chosen==16;
                double range=(chosen==1||chosen==15||chosen==16?5:chosen==3||chosen==4?4:chosen==5?9:8)-_radius;
                if(approach && SourceDistance(s)>range)
                { _approachCommand=command;_approachGoalId=NextGoal();_approachAction=chosen;_approachStop=range;_approachUntil=s.NowSeconds+3;_approachRun=SourceDistance(s)>=range+10 || Roll(100)<=40;return Move(s,MovementKind.Approach,range,_approachUntil,"Source action approach radius; guard odds100, run odds40 within approach band.",_approachRun); }
                return Start(command,chosen,s,"Weighted435100 sword/shield source action after admission/cooldowns.",true);
            }
            if(chosen==20)PlanMovement(s,MovementKind.Approach,3,5,"SourceAct20 guarded approach to distance5.",20);
            else if(chosen==21){if(MovementAllowed(MovementKind.Retreat,s))PlanMovement(s,MovementKind.Retreat,2,10,"SourceAct21 guarded leave toward distance10.",21);else Circle(s,21,false,2,2.5);}
            else if(chosen==22)Circle(s,22);
            else if(chosen==23)PlanMovement(s,MovementKind.Turn,2.5,0,"SourceAct23 guarded turn with90degree completion.",23);
            return Move(s,_movement,_movementStop,_movementUntil,_movementProvenance,_movement==MovementKind.Approach);
        }
    }
}
