namespace BlackAbbey.ReliquaryKnight {
 // An idle source decision owns no combat work when its target is inadmissible.
 // Native AI must retain its already-computed search/chase movement and facing.
 public static class KnightIdleHandoffPolicy {
  public static bool NativeSearch(Decision decision,SenseFrame senses)=>decision!=null&&senses!=null&&decision.Kind==DecisionKind.Idle&&!senses.TargetValid;
 }
}
