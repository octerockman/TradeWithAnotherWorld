using System;
using HarmonyLib;
using UnityEngine;
namespace BlackAbbey.ReliquaryKnight {
 public static class KnightDefenseHooks {
  sealed class BlockScope {
   public Humanoid Defender;public HitData Hit;public bool NativeAccepted;public BlockScope Previous;
   public readonly KnightBlockOutcomeSample Outcome=new KnightBlockOutcomeSample();
  }
  [ThreadStatic]static BlockScope current;
  static KnightDefense Defense(Character h)=>h?h.GetComponent<KnightDefense>():null;
  [HarmonyPatch(typeof(Humanoid),"BlockAttack")]
  static class Block {
   static void Prefix(Humanoid __instance,HitData __0,out BlockScope __state){
    __state=new BlockScope{Defender=__instance,Hit=__0,Previous=current};current=__state;
   }
   static void Postfix(Humanoid __instance,BlockScope __state){
    try {
     if(__state==null||!__state.Outcome.Known)return;
     var view=__instance.GetComponent<ZNetView>();if(!view||!view.IsValid()||!view.IsOwner())return;
     bool failed=__state.Outcome.Failed;
     if(!failed){__instance.GetComponent<KnightCombat>()?.SuccessfulGuard();return;}
     var defense=Defense(__instance);
     if(defense&&defense.Own&&!__state.Outcome.PoiseFailed&&!__state.NativeAccepted)defense.ExhaustionStagger(__state.Hit.m_dir);
     KnightGuardBreakWitness.FailedBlock(__instance);
    } finally {if(__state!=null)current=__state.Previous;}
   }
   static Exception Finalizer(Exception __exception,BlockScope __state){if(__state!=null)current=__state.Previous;return __exception;}
  }
  [HarmonyPatch(typeof(Character),"AddStaggerDamage")]
  static class ProcessedBlock {
   static void Prefix(Character __instance){Defense(__instance)?.RefreshNativePosture();}
   static void Postfix(Character __instance,bool __result){if(current!=null&&current.Defender==__instance)current.Outcome.PoiseResult(__result);}
  }
  [HarmonyPatch(typeof(Character),"UseStamina")]
  static class GuardSpend {
   static bool Prefix(Character __instance,float __0){if(current==null||current.Defender!=__instance)return true;var d=Defense(__instance);if(!d||!d.Own)return true;d.SpendGuard(__0);return false;}
  }
  [HarmonyPatch(typeof(Character),"AddStamina")]
  static class GuardRestore {
   static bool Prefix(Character __instance,float __0){if(current==null||current.Defender!=__instance)return true;var d=Defense(__instance);if(!d||!d.Own)return true;d.RestoreGuard(__0);return false;}
  }
  [HarmonyPatch(typeof(Character),"HaveStamina")]
  static class GuardAvailability {
   static bool Prefix(Character __instance,float __0,ref bool __result){if(current==null||current.Defender!=__instance)return true;var d=Defense(__instance);if(!d||!d.Own)return true;__result=d.HasGuard(__0);return false;}
   static void Postfix(Character __instance,float __0,bool __result){CaptureNativeStamina(__instance,__0,__result);}
  }
  [HarmonyPatch(typeof(Player),"HaveStamina")]
  static class PlayerStaminaResult {
   static void Postfix(Player __instance,float __0,bool __result){CaptureNativeStamina(__instance,__0,__result);}
  }
  static void CaptureNativeStamina(Character defender,float amount,bool result){
   // Native v12 samples this once immediately after AddStaggerDamage. A later
   // perfect-block stamina drain/refund must not rewrite the actual outcome.
   if(current==null||current.Defender!=defender)return;
   current.Outcome.StaminaResult(amount,result);
  }
  [HarmonyPatch(typeof(Character),"RPC_Stagger")]
  static class AcceptedStagger {
   static void Prefix(Character __instance,out bool __state){__state=__instance.IsStaggering();}
   static void Postfix(Character __instance,bool __state,bool __runOriginal){
    if(__runOriginal&&!__state&&current!=null&&current.Defender==__instance)current.NativeAccepted=true;
   }
  }
 }
}
