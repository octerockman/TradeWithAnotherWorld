using System;
namespace BlackAbbey.ReliquaryKnight
{
    public static class KnightPoisePolicy
    {
        public const float BlockedBuildupMultiplier = 1.25f;
        public static double Threshold(double maxHealth) => KnightDefensePolicy.NativePostureThreshold;
        public static double Contribution(double nativeContribution, bool insideThisDefendersBlock)
            => insideThisDefendersBlock && nativeContribution > 0 && !double.IsNaN(nativeContribution) && !double.IsInfinity(nativeContribution)
                ? nativeContribution * BlockedBuildupMultiplier : nativeContribution;
    }
}
