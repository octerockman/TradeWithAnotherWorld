using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbey.ReliquaryKnight
{
    // Source poses are evaluated before the continuous world-space contact pass.
    [DefaultExecutionOrder(1100)]
    public sealed class KnightCombat : MonoBehaviour
    {
        public static Action<string> Log;
        internal static readonly HashSet<KnightCombat> Actors = new HashSet<KnightCombat>();
        internal static readonly AccessTools.FieldRef<Character, bool> BlockInput = AccessTools.FieldRefAccess<Character, bool>("m_blocking");
        public static readonly int SolidMask = LayerMask.GetMask("Default", "static_solid", "Default_small", "piece", "terrain", "vehicle");
        public static readonly int HitMask = SolidMask | LayerMask.GetMask("character", "character_net", "character_noenv", "character_ghost", "piece_nonsolid");
        readonly Collider[] overlap = new Collider[128];
        readonly RaycastHit[] casts = new RaycastHit[128];
        readonly Dictionary<int, HashSet<int>> hits = new Dictionary<int, HashSet<int>>();
        readonly HashSet<HashSet<int>> soundedWorldWindows = new HashSet<HashSet<int>>();
        readonly List<EventWindow> attackWindows = new List<EventWindow>();
        readonly List<ClipSpec> runtimeClips = new List<ClipSpec>();
        Humanoid human; MonsterAI ai; ZNetView view; IKnightCombatHost host; C4351BattleBrain brain; KnightDefense defense;
        bool wasOwner, guarded, itemUsed, projectileFired, failed, inNativeAI, nativePriority, corpseCreated;
        int damageSerial = int.MinValue, observedSerial = int.MinValue, lastAction;
        double consumedTime;
        Character guardTarget;
        float lastGuardPerception = float.NegativeInfinity;
        Vector3 previousRoot;
        const int QueriesPerFrame = 512;
        int queriesRemaining, budgetExhaustions;
        int starts, submissions, solidStops, nativeSuppressed, skippedCatchups;
        int nativeSearchHandoffs;
        string status = "awaiting host";
        public bool Ready => !failed && host != null && host.Ready;
        public bool Own => human && view && view.IsValid() && view.IsOwner() && human.GetHealth() > 0 && !human.IsDead();
        public bool SuppressNativeAttack => true; // component identity is the gate, including failed/unconfigured actors
        bool ContactAdmitted => host != null && KnightContactAdmission.Admitted(Own && Ready, host.ContextActive, damageSerial, host.Serial, human.IsStaggering());
        public Decision LastDecision { get; private set; }

        void Awake() { human = GetComponent<Humanoid>(); ai = GetComponent<MonsterAI>(); view = GetComponent<ZNetView>(); defense = GetComponent<KnightDefense>(); }
        void OnEnable() { Actors.Add(this); }
        void OnDisable()
        {
            Actors.Remove(this); ReleaseGuard(); damageSerial = int.MinValue;
            // Remote replicas may receive only native actor destruction after the
            // owner's death. A positive-health zone unload never creates a corpse.
            try { if (human && human.GetHealth() <= 0) CreateCorpseOnce(); }
            catch (Exception) { /* Native replica ZDO can already be disposed on unload. */ }
        }

        public void Configure(IKnightCombatHost motionHost, double sourceUnitsToWorld)
        {
            if (motionHost == null || double.IsNaN(sourceUnitsToWorld) || double.IsInfinity(sourceUnitsToWorld) || sourceUnitsToWorld <= 0)
                throw new ArgumentException("Knight combat requires a ready source host and finite coherent scale.");
            host = motionHost; Scale = sourceUnitsToWorld; failed = false; wasOwner = false; status = "configured";
        }
        public double Scale { get; private set; } = .7846479068218638;

        void NewOwner()
        {
            // A changed owner never replays restored attack windows. New attacks must
            // be explicitly started by this authority before any contact can submit.
            uint seed = unchecked((uint)gameObject.GetInstanceID());
            if (view && view.IsValid()) seed = unchecked((uint)view.GetZDO().m_uid.ToString().GetStableHashCode());
            runtimeClips.Clear();
            foreach (var c in KnightSourceData.Clips)
                runtimeClips.Add(new ClipSpec { CommandId = c.CommandId, ClipId = c.ClipId, Duration = c.Duration,
                    AutonomousAllowed = KnightAttackRepertoire.Autonomous(c), IsAdditive = c.IsAdditive,
                    BranchEffects = c.BranchEffects, ComboCancelWindows = c.ComboCancelWindows, AttackWindows = c.AttackWindows });
            brain = new C4351BattleBrain(seed, runtimeClips, Scale, .5);
            damageSerial = int.MinValue; observedSerial = host.Serial; consumedTime = host.ClipTime;
            previousRoot = transform.position; guarded = itemUsed = projectileFired = false;
            hits.Clear(); soundedWorldWindows.Clear(); attackWindows.Clear();
        }

        public void BeginNativeAI() { inNativeAI = true; nativePriority = false; }
        public void ObserveNativePriority() { if (inNativeAI) nativePriority = true; }
        public void ObserveNativeWander()
        {
            if (!inNativeAI) return;
            // Native RandomMovementArroundPoint also implements combat circling.
            // Preserve native search/wander only without our live visible target.
            var t = ai ? ai.GetTargetCreature() : null;
            bool combatTarget = human && ai && ai.IsAlerted() && t && !t.IsDead() && t.GetHealth() > 0
                && !t.InGhostMode() && BaseAI.IsEnemy(human, t) && ai.CanSeeTarget(t);
            if (!combatTarget) nativePriority = true;
        }

        // Called by the MonsterAI postfix. Native sensing, alerting, damage, motor
        // physics and native priority decisions still execute; native attacks do not.
        public void AfterNativeAI(float dt)
        {
            inNativeAI = false;
            if (!Ready || !Own) { if (wasOwner) ReleaseGuard(); wasOwner = false; return; }
            try
            {
                if (!wasOwner) { NewOwner(); wasOwner = true; }
                bool nativeReaction = human.IsStaggering() || human.InDodge() || !human.CanMove() || nativePriority;
                var target = ai ? ai.GetTargetCreature() : null;
                bool valid = target && !target.IsDead() && target.GetHealth() > 0 && !target.InGhostMode() && BaseAI.IsEnemy(human, target);
                Vector3 to = valid ? Vector3.ProjectOnPlane(target.transform.position - transform.position, Vector3.up) : Vector3.zero;
                bool visible = valid && ai && ai.IsAlerted() && ai.CanSeeTarget(target);
                bool grounded = human.IsOnGround();
                var s = new SenseFrame {
                    NowSeconds = Time.time, DistanceWorld = to.magnitude,
                    FacingDegrees = to.sqrMagnitude > .00001f ? Vector3.SignedAngle(transform.forward, to, Vector3.up) : 0,
                    TargetValid = valid && visible && Mathf.Abs(target.transform.position.y - transform.position.y) < 2f,
                    TargetGuarding = valid && target.IsBlocking(), TargetAttacking = valid && target.InAttack(),
                    SuccessfulGuard = guarded, TargetUsingItem = itemUsed, TargetFiredProjectile = projectileFired,
                    GuardBroken = human.IsStaggering(), SourceAsleepOrLadder = nativeReaction || ai && ai.IsSleeping(),
                    PathReady = grounded && host.PathReady, AttackAdmission = grounded && !nativeReaction,
                    CanGuard = valid && visible && human.LeftItem != null && !nativeReaction && (!defense || defense.GuardAvailable),
                    CanMoveForward = grounded && host.CanMoveForward, CanMoveBackward = grounded && host.CanMoveBackward,
                    CanMoveLeft = grounded && host.CanMoveLeft, CanMoveRight = grounded && host.CanMoveRight,
                    PreviousActionId = lastAction, CurrentClipTime = host.ClipTime,
                    MovementGoalId = (host as KnightActor)?.MovementGoalId ?? 0,
                    MovementBlocked = (host as KnightActor)?.MovementBlocked ?? false,
                    MovementCompleted = (host as KnightActor)?.MovementCompleted ?? false,
                    MovementProgress = (host as KnightActor)?.MovementProgress ?? 0,
                    // Proven source51 is the opponent's guard-break vulnerability.
                    SourceTargetEffect51 = valid && KnightDefense.TargetGuardBroken(target)
                };
                guardTarget = valid && visible ? target : null;
                lastGuardPerception = Time.time;
                // A source raise/lower or confirmed native reaction owns its
                // presentation until the host completes it. Keep perception
                // current, but never select an attack behind that context.
                if (host.ContextActive)
                {
                    brain.PauseGoalClock(Time.time);
                    damageSerial = int.MinValue;
                    if (nativePriority && host.GuardPoseRequested)
                    {
                        if (brain != null) LastDecision = brain.Tick(new SenseFrame { NowSeconds = Time.time, DistanceWorld = 0,
                            FacingDegrees = 0, TargetValid = false, SourceAsleepOrLadder = true });
                        ReleaseGuard(); host.InterruptForNativeReaction(); status = "native priority interrupted guard context";
                    }
                    else { UpdateGuard(); status = "source context"; }
                    return;
                }
                // The brain holds these actor-local records by reference. Update
                // only admission, preserving every source weight/cooldown/observer.
                // Shared generated source records and event arrays stay unchanged.
                foreach (var c in runtimeClips)
                {
                    var source = KnightSourceData.ByCommand[c.CommandId];
                    c.AutonomousAllowed = KnightAttackRepertoire.Autonomous(source) && host.CanStart(source);
                }
                LastDecision = brain.Tick(s); guarded = itemUsed = projectileFired = false;
                if(KnightIdleHandoffPolicy.NativeSearch(LastDecision,s)){
                    damageSerial=int.MinValue;hits.Clear();soundedWorldWindows.Clear();attackWindows.Clear();
                    ReleaseGuard();host.YieldToNativeSearch();nativeSearchHandoffs++;
                    status="native search: "+(!valid?"no live enemy target":!visible?"target not visible":"target height outside source attack admission");return;
                }
                if (LastDecision.Kind == DecisionKind.ExternalReaction)
                {
                    damageSerial = int.MinValue; ReleaseGuard(); if (!nativePriority) host.StopMovement(); host.InterruptForNativeReaction(); status = "native reaction"; return;
                }
                if (LastDecision.Kind == DecisionKind.StartClip)
                {
                    ClipSpec clip;
                    if (!KnightSourceData.ByCommand.TryGetValue(LastDecision.CommandId, out clip) || !KnightAttackRepertoire.Autonomous(clip) || clip.IsAdditive || !host.CanStart(clip))
                    {
                        // Admission was checked immediately before Tick. A changing
                        // host invalidating it here cannot safely commit the brain.
                        Fail("Source travel/pose admission changed during selection"); return;
                    }
                    ReleaseGuard();
                    if (!host.TryPlay(clip, false)) { Fail("Selected source clip could not start: " + clip.CommandId); return; }
                    damageSerial = host.Serial; observedSerial = host.Serial; consumedTime = 0;
                    previousRoot = transform.position; hits.Clear(); soundedWorldWindows.Clear(); BuildAttackWindows(clip); lastAction = LastDecision.SourceActionId; starts++;
                    Log?.Invoke("RK_SOURCE_START command=" + clip.CommandId + " clip=" + clip.ClipId + " duration=" + clip.Duration);
                }
                host.ApplyDecision(LastDecision, valid ? target : null, Mathf.Clamp(dt, .001f, .1f));
                UpdateGuard(); status = LastDecision.Kind + ":" + LastDecision.CommandId;
            }
            catch (Exception e) { Fail(e.GetBaseException().Message); }
        }
        void BuildAttackWindows(ClipSpec clip)
        {
            attackWindows.Clear();
            // Parallel BehaviorJudge entries describe one contact activation. Merge
            // overlapping source intervals; never multiply damage by those aliases.
            attackWindows.AddRange(KnightCombatTiming.DamageWindows(clip));
        }
        void UpdateGuard()
        {
            if (!human || !view || !view.IsValid() || !view.IsOwner()) return;
            bool capable = human.LeftItem != null && !human.IsStaggering() && !human.InDodge() && human.CanMove()
                && (!defense || defense.GuardAvailable);
            bool liveTarget = guardTarget && ai && ai.IsAlerted() && ai.GetTargetCreature() == guardTarget
                && !guardTarget.IsDead() && guardTarget.GetHealth() > 0 && !guardTarget.InGhostMode()
                && Time.time - lastGuardPerception <= .5f;
            BlockInput(human) = host != null && (host.ContextActive
                ? Ready && Own && capable && liveTarget && host.GuardPoseRequested && KnightSourceData.GuardActive(host.CommandId, host.ClipTime)
                : KnightGuardPolicy.Requested(Ready && Own, capable, liveTarget, LastDecision, host.CommandId, host.ClipTime, host.Serial, damageSerial));
        }
        // The native block update runs on every owner physics step and publishes
        // its internal/Animator/ZDO state. Re-evaluate source phase first, instead
        // of leaving an old AI-tick guard input latched through a phase change.
        public void BeforeNativeBlock() { try { UpdateGuard(); } catch (Exception e) { ReleaseGuard(); Fail("Guard refresh: " + e.GetBaseException().Message); } }
        void ReleaseGuard() { if (human && view && view.IsValid() && view.IsOwner()) BlockInput(human) = false; }
        public void NativeSuppressed() { nativeSuppressed++; }
        public void SuccessfulGuard(){
            if(!Own||human.IsStaggering()||defense&&!defense.CanCounter)return;
            guarded=true;
            if(host is KnightActor actor)actor.ReleaseGuardTransitionForCounter();
        }
        // Only the validated native perfect-parry observer calls this entry.
        // Ordinary damage and full-poise stagger have no source pose handler.
        internal void BeginConfirmedParry()
        {
            if (!Own || !Ready || !human.IsStaggering() || !(host is KnightActor actor)) return;
            damageSerial = int.MinValue; hits.Clear(); soundedWorldWindows.Clear(); attackWindows.Clear();
            guarded = itemUsed = projectileFired = false; ReleaseGuard();
            if (brain != null) LastDecision = brain.Tick(new SenseFrame { NowSeconds = Time.time,
                SourceAsleepOrLadder = true });
            actor.BeginParriedPresentation(); status = "confirmed native parry";
        }
        public void NativeDeath()
        {
            damageSerial = int.MinValue; ReleaseGuard();
            try { CreateCorpseOnce(); host?.InterruptForNativeReaction(); }
            catch (Exception e) { Log?.Invoke("RK_DEATH_PRESENTATION_SKIPPED " + e.GetBaseException().Message); }
        }
        void CreateCorpseOnce() { if (!corpseCreated) { corpseCreated = true; host?.BeginDeathPresentation(); } }
        internal void TargetEvent(Character actor, bool shot)
        {
            if (!Own || !Ready || !ai || ai.GetTargetCreature() != actor) return;
            if (shot) projectileFired = true; else itemUsed = true;
        }

        void LateUpdate()
        {
            if (!ContactAdmitted || human.InDodge() || !human.IsOnGround()) return;
            try
            {
                queriesRemaining = QueriesPerFrame;
                double now = host.ClipTime;
                if (!Finite(now) || now < consumedTime || observedSerial != host.Serial) { consumedTime = now; observedSerial = host.Serial; skippedCatchups++; return; }
                // Pauses, restored state and teleports must not replay old damage.
                if (now - consumedTime > .5 || Vector3.Distance(previousRoot, transform.position) > 3f)
                { consumedTime = now; previousRoot = transform.position; skippedCatchups++; return; }
                for (int index = 0; index < attackWindows.Count; index++)
                {
                    double from, end;
                    if (!KnightCombatTiming.Overlap(attackWindows[index], consumedTime, now, out from, out end)) continue;
                    if (!hits.TryGetValue(index, out var ledger)) { ledger = new HashSet<int>(); hits.Add(index, ledger); }
                    int steps = Mathf.Clamp((int)Math.Ceiling((end - from) * 120), 1, 60);
                    for (int n = 0; n < steps && queriesRemaining > 0 && ContactAdmitted; n++)
                    {
                        double a = from + (end - from) * n / steps, b = from + (end - from) * (n + 1) / steps;
                        // The blade-only fit starts beyond the real hilt. At
                        // point-blank range the visible guard/grip can strike
                        // first; sweep those exact compact parts before a far
                        // blade-tip floor stop, with the same target ledger.
                        if(CloseHiltAdmitted()&&host is KnightActor actor)
                            for(int hilt=0;hilt<3&&queriesRemaining>0&&ContactAdmitted;hilt++) {
                                KnightContactPose hiltBefore,hiltAfter;
                                if(!actor.TryHiltContactPose(host.CommandId,a,hilt,out hiltBefore)||!actor.TryHiltContactPose(host.CommandId,b,hilt,out hiltAfter))break;
                                if(Sweep(hiltBefore,hiltAfter,ledger,a,b))break;
                            }
                        // The host fits geometry on the actual equipment bone. Absent
                        // sockets fail closed, without a substitute radius hitbox.
                        for (int part = 0; part < 8; part++)
                        {
                            KnightContactPose before, after;
                            if (!host.TryContactPose(host.CommandId, a, part, out before) || !host.TryContactPose(host.CommandId, b, part, out after)) break;
                            if (Sweep(before, after, ledger,a,b)) break;
                        }
                    }
                }
                if (queriesRemaining <= 0) budgetExhaustions++;
                consumedTime = now; previousRoot = transform.position; UpdateGuard();
            }
            catch (Exception e) { Fail(e.GetBaseException().Message); }
        }

        bool CloseHiltAdmitted()
        {
            bool live=guardTarget&&ai&&ai.GetTargetCreature()==guardTarget&&!guardTarget.IsDead()&&!guardTarget.InGhostMode()&&guardTarget.GetHealth()>0;
            if(!live)return false;
            Vector3 offset=guardTarget.transform.position-transform.position;
            Vector3 planar=Vector3.ProjectOnPlane(offset,Vector3.up);
            float facing=planar.sqrMagnitude>.000001f?Vector3.Dot(transform.forward,planar.normalized):1;
            return KnightCloseContactPolicy.Admitted(host.CommandId,live,planar.sqrMagnitude,facing,offset.y,KnightScaleProfile.BodyMultiplier);
        }

        bool Sweep(KnightContactPose a, KnightContactPose b, HashSet<int> ledger,double sourceFrom,double sourceTo)
        {
            if (!ValidPose(a) || !ValidPose(b)) return true;
            var half = Vector3.Max(a.HalfExtents, b.HalfExtents);
            float min = Mathf.Max(.015f, Mathf.Min(half.x, half.y, half.z));
            float distance = Vector3.Distance(a.Center, b.Center);
            int divisions = Mathf.Clamp(Mathf.CeilToInt(Mathf.Max(distance / min, Quaternion.Angle(a.Rotation, b.Rotation) / 5)), 1, 32);
            Vector3 previous = a.Center;
            for (int i = 0; i <= divisions; i++)
            {
                if (!ContactAdmitted) return true;
                float t = i / (float)divisions; var at = Vector3.Lerp(a.Center, b.Center, t); var rotation = Quaternion.Slerp(a.Rotation, b.Rotation, t); var delta = at - previous;
                if (delta.sqrMagnitude > .000001f)
                {
                    if (queriesRemaining-- <= 0) return true;
                    int count = Physics.BoxCastNonAlloc(previous, half, delta.normalized, casts, rotation, delta.magnitude, HitMask, QueryTriggerInteraction.Ignore);
                    if (count == casts.Length) return true; // saturated query fails closed
                    // Resolve nearer solid contact before any character behind it.
                    Array.Sort(casts, 0, count, HitOrder.Instance);
                    for (int j = 0; j < count; j++)
                    {
                        double fraction = Mathf.Clamp01(casts[j].distance / delta.magnitude);
                        double sample = sourceFrom + (sourceTo - sourceFrom) * ((i - 1 + fraction) / divisions);
                        if (Contact(casts[j].collider, previous, at, ledger,sample)) return true;
                    }
                }
                if (queriesRemaining-- <= 0) return true;
                int found = Physics.OverlapBoxNonAlloc(at, half, overlap, rotation, HitMask, QueryTriggerInteraction.Ignore);
                if (found == overlap.Length) return true;
                double overlapTime=sourceFrom+(sourceTo-sourceFrom)*t;
                for (int j = 0; j < found; j++) if (Contact(overlap[j], previous, at, ledger,overlapTime)) return true;
                previous = at;
            }
            return false;
        }
        sealed class HitOrder : IComparer<RaycastHit> { public static readonly HitOrder Instance = new HitOrder(); public int Compare(RaycastHit a, RaycastHit b) => a.distance.CompareTo(b.distance); }
        bool Contact(Collider collider, Vector3 from, Vector3 at, HashSet<int> ledger,double sourceTime)
        {
            if (!ContactAdmitted) return true;
            if (!collider || collider.transform.IsChildOf(transform)) return false;
            var targetObject = collider.attachedRigidbody ? collider.attachedRigidbody.gameObject : collider.gameObject;
            var destructible = targetObject.GetComponent<IDestructible>() ?? collider.GetComponentInParent<IDestructible>();
            var component = destructible as Component;
            bool solid = (SolidMask & (1 << collider.gameObject.layer)) != 0;
            if (!component) { if (solid) { solidStops++; SoundSolid(collider,at,ledger); } return solid; }
            if (component.transform.IsChildOf(transform)) return false;
            var character = component.GetComponent<Character>();
            if (character && (!BaseAI.IsEnemy(human, character) || character.IsDead() || character.InGhostMode())) return false;
            if (ledger.Contains(component.GetInstanceID())) return solid;
            Vector3 point = collider.ClosestPoint(at);
            if (!Finite(point)) return true;
            if (Physics.Linecast(human.GetCenterPoint(), point, out var cover, SolidMask, QueryTriggerInteraction.Ignore)
                && cover.collider != collider && !cover.collider.transform.IsChildOf(component.transform) && !cover.collider.transform.IsChildOf(transform))
            { solidStops++; return true; }
            var weapon = host.GetDamageItem(host.CommandId);
            if (weapon == null || weapon.m_shared == null) return true;
            var attack = weapon.m_shared.m_attack;
            var hit = new HitData {
                m_point = point, m_dir = (at - from).sqrMagnitude > .00001f ? (at - from).normalized : transform.forward,
                m_hitCollider = collider, m_pushForce = weapon.m_shared.m_attackForce * (attack?.m_forceMultiplier ?? 1),
                m_staggerMultiplier = attack?.m_staggerMultiplier ?? 1,
                m_backstabBonus = 1, m_blockable = true, m_dodgeable = true, m_hitType = HitData.HitType.EnemyHit
            };
            hit.m_damage = weapon.GetDamage(); hit.m_damage.Modify(attack?.m_damageMultiplier ?? 1);
            if (!Finite(hit.GetTotalDamage()) || hit.GetTotalDamage() <= 0 || !Finite(hit.m_dir) || !Finite(hit.m_pushForce)) return true;
            hit.SetAttacker(human); ledger.Add(component.GetInstanceID());
            // Native target Damage owns directional block/parry, dodge, armor,
            // stagger, resistance and the target's own network authority.
            KnightAudioContact.RecordSubmission(human,character,point);
            KnightParryPresentation.RecordSubmission(human,character,hit,sourceTime);
            destructible.Damage(hit); submissions++;
            if(solid&&!character)SoundSolid(collider,point,ledger);
            if (solid) solidStops++;
            return solid;
        }
        void SoundSolid(Collider collider,Vector3 point,HashSet<int> ledger)
        {
            // Separate audio ledger leaves every damage decision untouched.
            // One world impact per source attack window prevents sweep chatter.
            if(soundedWorldWindows.Add(ledger))try { GetComponent<KnightAudio>()?.SolidContact(point,KnightAudio.Surface(collider)); }
            catch(Exception e) { Log?.Invoke("RK_WORLD_AUDIO_SKIPPED "+e.GetBaseException().Message); }
        }
        static bool Finite(double x) => !double.IsNaN(x) && !double.IsInfinity(x);
        static bool Finite(Vector3 v) => Finite(v.x) && Finite(v.y) && Finite(v.z);
        static bool ValidPose(KnightContactPose p) => Finite(p.Center) && Finite(p.HalfExtents) && p.HalfExtents.x > 0 && p.HalfExtents.y > 0 && p.HalfExtents.z > 0
            && p.HalfExtents.sqrMagnitude < 9 && Finite(p.Rotation.x) && Finite(p.Rotation.y) && Finite(p.Rotation.z) && Finite(p.Rotation.w)
            && p.Rotation.x*p.Rotation.x+p.Rotation.y*p.Rotation.y+p.Rotation.z*p.Rotation.z+p.Rotation.w*p.Rotation.w > .5f
            && p.Rotation.x*p.Rotation.x+p.Rotation.y*p.Rotation.y+p.Rotation.z*p.Rotation.z+p.Rotation.w*p.Rotation.w < 1.5f;
        void Fail(string reason)
        {
            failed = true; status = "disabled: " + reason; damageSerial = int.MinValue; ReleaseGuard(); host?.StopMovement();
            Log?.Invoke("RK_COMBAT_DISABLED " + reason);
        }
        public string Diagnostics()=>"brain="+status+" starts="+starts+" hitsSubmitted="+submissions+" solidStops="+solidStops+" nativeAttacksSuppressed="+nativeSuppressed+" catchupsSkipped="+skippedCatchups+" queryBudgetExhaustions="+budgetExhaustions+" nativeSearchHandoffs="+nativeSearchHandoffs+" customDamageReactions=false parryPresentation=true nativeFlee=false effect51="+KnightDefense.TargetGuardBroken(guardTarget)+" goal="+(brain?.CurrentGoalId??0)+" goalResult="+(brain?.LastGoalResult??"none")+" goalPaused="+(brain?.PausedGoalSeconds??0).ToString("F2")+" "+(defense?defense.Diagnostics():"")+" "+GetComponent<KnightParryPresentation>()?.Diagnostics();
    }
}
