namespace BlackAbbey.ReliquaryKnight {
 public static class KnightParryReceiptPolicy {
  // Exact originating contact identity is mandatory. A newer successful parry
  // must never bind to an older off-window hit against the same opponent.
  public static bool Matches(long expected,long candidate,bool sameVictim,bool unused,double ageSeconds)
   =>expected>0&&expected==candidate&&sameVictim&&unused&&KnightDefensePolicy.Finite(ageSeconds)&&ageSeconds>=-.25&&ageSeconds<=KnightParryEpisode.LifetimeSeconds;
 }
}
