using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbey.ReliquaryKnight
{
    public static class KnightCombatHooks
    {
        static readonly FieldInfo AttackOwner = AccessTools.Field(typeof(Attack), "m_character");
        internal sealed class NativeBlockScope { public Humanoid Defender; public NativeBlockScope Previous; }
        [ThreadStatic] static NativeBlockScope currentBlock;
        static KnightCombat For(Attack attack) { var h = AttackOwner.GetValue(attack) as Humanoid; return h ? h.GetComponent<KnightCombat>() : null; }
        [HarmonyPatch(typeof(MonsterAI), nameof(MonsterAI.UpdateAI))]
        static class AI
        {
            static void Prefix(MonsterAI __instance) { __instance.GetComponent<KnightCombat>()?.BeginNativeAI(); }
            static void Postfix(MonsterAI __instance, float dt) { __instance.GetComponent<KnightCombat>()?.AfterNativeAI(dt); }
        }
        [HarmonyPatch(typeof(BaseAI), "Flee")]
        static class Flee
        {
            // This enemy never flees. Source backsteps/circling use their own
            // target-facing motor and do not pass through native Flee.
            static bool Prefix(BaseAI __instance) => !__instance.GetComponent<KnightCombat>();
        }
        [HarmonyPatch(typeof(BaseAI), "RandomMovementArroundPoint")]
        static class Wander { static void Prefix(BaseAI __instance) { __instance.GetComponent<KnightCombat>()?.ObserveNativeWander(); } }
        [HarmonyPatch(typeof(Humanoid), nameof(Humanoid.StartAttack))]
        static class Start
        {
            static bool Prefix(Humanoid __instance, ref bool __result)
            {
                var c = __instance.GetComponent<KnightCombat>(); if (!c || !c.SuppressNativeAttack) return true;
                c.NativeSuppressed(); __result = false; return false;
            }
        }
        [HarmonyPatch(typeof(Attack), "DoMeleeAttack")]
        static class Melee { static bool Prefix(Attack __instance) { var c = For(__instance); if (!c || !c.SuppressNativeAttack) return true; c.NativeSuppressed(); return false; } }
        [HarmonyPatch(typeof(Attack), "DoAreaAttack")]
        static class Area { static bool Prefix(Attack __instance) { var c = For(__instance); if (!c || !c.SuppressNativeAttack) return true; c.NativeSuppressed(); return false; } }
        [HarmonyPatch(typeof(Humanoid), "BlockAttack")]
        static class Block
        {
            static void Prefix(Humanoid __instance, out NativeBlockScope __state) { __state = new NativeBlockScope { Defender = __instance, Previous = currentBlock }; currentBlock = __state; }
            // KnightDefenseHooks owns the genuine successful-block receipt;
            // native __result alone is also true for a processed guard break.
            static void Postfix(Humanoid __instance, bool __result, NativeBlockScope __state) { if (__state != null) currentBlock = __state.Previous; }
            static Exception Finalizer(Exception __exception, NativeBlockScope __state) { if (__state != null) currentBlock = __state.Previous; return __exception; }
        }
        [HarmonyPatch(typeof(Character), "AddStaggerDamage")]
        static class BlockingPoise
        {
            static void Prefix(Character __instance, ref float __0)
            {
                // Modify the native contribution already computed for this exact
                // defender's block. Never make a second AddStaggerDamage call.
                if (currentBlock == null || currentBlock.Defender != __instance) return;
                var knight = __instance.GetComponent<KnightCombat>();
                if (knight && knight.Own) __0 = (float)KnightPoiseProfile.Contribution(__0, true);
            }
        }
        [HarmonyPatch(typeof(Humanoid), "UpdateBlock")]
        static class RefreshBlock { static void Prefix(Humanoid __instance) { __instance.GetComponent<KnightCombat>()?.BeforeNativeBlock(); } }
        [HarmonyPatch(typeof(Character), nameof(Character.OnDeath))]
        static class Death { static void Prefix(Character __instance) { if (__instance) __instance.GetComponent<KnightCombat>()?.NativeDeath(); } }
        [HarmonyPatch(typeof(Humanoid), nameof(Humanoid.ConsumeItem))]
        static class Consumed { static void Postfix(Humanoid __instance, bool __result) { if (__result) Notify(__instance, false); } }
        [HarmonyPatch(typeof(Player), nameof(Player.ConsumeItem))]
        static class PlayerConsumed { static void Postfix(Player __instance, bool __result) { if (__result) Notify(__instance, false); } }
        [HarmonyPatch(typeof(Projectile), nameof(Projectile.Setup))]
        static class Fired { static void Postfix(Character __0) { Notify(__0, true); } }
        static void Notify(Character actor, bool shot)
        {
            if (!actor) return;
            foreach (var c in KnightCombat.Actors) if (c) c.TargetEvent(actor, shot);
        }
    }
}
