using System;
namespace BlackAbbey.ReliquaryKnight {
 // Supplemental measured sword-hilt contact only at the body's front. It
 // shares the normal attack window, target ledger and native damage result.
 public static class KnightCloseContactPolicy {
  public const double BodyDistancePerMultiplier=.90;
  public const double MinimumFacingDot=.35;
  public static bool Admitted(int command,bool liveTarget,double planarDistanceSquared,double forwardDot,double heightDifference,double bodyMultiplier){
   if(command<3000||command>=4000||command==3003||command==3030||!liveTarget||bodyMultiplier<=0||double.IsNaN(bodyMultiplier)||double.IsInfinity(bodyMultiplier)||double.IsNaN(planarDistanceSquared)||double.IsInfinity(planarDistanceSquared)||double.IsNaN(forwardDot)||double.IsInfinity(forwardDot)||double.IsNaN(heightDifference)||double.IsInfinity(heightDifference))return false;
   double distance=BodyDistancePerMultiplier*bodyMultiplier;
   return planarDistanceSquared>=0&&planarDistanceSquared<=distance*distance&&forwardDot>=MinimumFacingDot&&Math.Abs(heightDifference)<=bodyMultiplier;
  }
 }
}
