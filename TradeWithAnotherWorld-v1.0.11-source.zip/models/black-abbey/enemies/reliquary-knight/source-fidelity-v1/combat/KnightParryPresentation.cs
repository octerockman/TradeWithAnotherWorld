using System;
using System.Collections.Generic;
using UnityEngine;

namespace BlackAbbey.ReliquaryKnight
{
    // This owns no motor, AI loop, damage callback or general hit reaction.
    // Native perfect block + own outgoing contact + accepted native stagger
    // must all agree before the one narrow 8500 presentation is requested.
    [DefaultExecutionOrder(1090)]
    public sealed class KnightParryPresentation : MonoBehaviour
    {
        const string HintRpc = "RK_ParryPresentationV2";
        const string ContactRpc = "RK_ParryContactV2";
        sealed class Submission { public ZDOID Victim; public long At,ContactId; public bool Used, NativeChecked; public int Command,Serial; public double SourceTime; public Vector3 Point,Direction; }
        readonly List<Submission> submissions = new List<Submission>();
        readonly Dictionary<string, long> receipts = new Dictionary<string, long>();
        readonly KnightParryEpisode episode = new KnightParryEpisode();
        Humanoid human;
        ZNetView view;
        KnightCombat combat;
        KnightActor actor;
        bool bound, wasOwner;
        long owner, enabledAt;
        long nativeSender, hintSender;
        Vector3 nativeDirection, hintDirection;
        int confirmed, rejected, nativeAccepted,sourceParriesAllowed,sourceParriesRejected,sourceParriesUnknown;
        static long sequence,contactSequence;
        static bool reportedFailure;
        static long Now => ZNet.instance ? ZNet.instance.GetTime().Ticks : DateTime.UtcNow.Ticks;
        static bool Finite(Vector3 v) => !float.IsNaN(v.x) && !float.IsInfinity(v.x)
            && !float.IsNaN(v.y) && !float.IsInfinity(v.y) && !float.IsNaN(v.z) && !float.IsInfinity(v.z);
        bool Own => bound && isActiveAndEnabled && view && view.IsValid() && view.IsOwner()
            && wasOwner && owner == view.GetZDO().GetOwner() && human && !human.IsDead() && human.GetHealth() > 0;

        internal static void Safe(Action call)
        {
            try { call(); }
            catch (Exception e)
            {
                if (reportedFailure) return;
                reportedFailure = true;
                KnightActor.Log?.Invoke("RK_PARRY_PRESENTATION_SKIPPED " + e.GetBaseException().Message);
            }
        }
        void Awake()
        {
            human = GetComponent<Humanoid>(); view = GetComponent<ZNetView>();
            combat = GetComponent<KnightCombat>(); actor = GetComponent<KnightActor>();
        }
        void Start() { Safe(Bind); }
        void Bind()
        {
            if (bound || !view || !view.IsValid() || !human || !combat || !actor) return;
            view.Register<ZPackage>(HintRpc, Receive); view.Register<ZPackage>(ContactRpc,ReceiveContact); bound = true; ResetOwner();
        }
        void ResetOwner()
        {
            submissions.Clear(); receipts.Clear(); episode.Reset(); enabledAt = Now; nativeSender = hintSender = 0;
            owner = view && view.IsValid() ? view.GetZDO().GetOwner() : 0;
            wasOwner = view && view.IsValid() && view.IsOwner();
        }
        void SyncOwner()
        {
            if (!bound) Bind();
            if (bound && view && view.IsValid() && (owner != view.GetZDO().GetOwner() || wasOwner != view.IsOwner())) ResetOwner();
        }
        void Update()
        {
            Safe(() =>
            {
                SyncOwner();
                if (!Own) { episode.Reset(); Prune(Now); return; }
                Prune(Now);
                bool matching = (nativeSender == hintSender || nativeSender == 0 && hintSender == owner)
                    && (nativeDirection - hintDirection).sqrMagnitude < .0004f;
                if (combat.Ready && actor.Ready && episode.Tick(Time.time, human.IsStaggering(), matching))
                {
                    combat.BeginConfirmedParry(); confirmed++;
                }
            });
        }
        void Prune(long now)
        {
            submissions.RemoveAll(s => now < s.At || (now - s.At) / (double)TimeSpan.TicksPerSecond > KnightParryEpisode.LifetimeSeconds);
            var expired = new List<string>();
            foreach (var pair in receipts)
                if (now < pair.Value || (now - pair.Value) / (double)TimeSpan.TicksPerSecond > 8) expired.Add(pair.Key);
            foreach (string key in expired) receipts.Remove(key);
        }
        // Root calls this only on its already-admitted physical source contact,
        // immediately before handing that exact hit to native target Damage.
        public static void RecordSubmission(Character attacker, Character victim,HitData hit,double sourceTime)
        {
            Safe(() =>
            {
                var parry = attacker ? attacker.GetComponent<KnightParryPresentation>() : null;
                if (!parry || !victim || hit==null || !KnightDefensePolicy.Finite(sourceTime) || !Finite(hit.m_point) || !Finite(hit.m_dir)) return;
                parry.SyncOwner();
                var victimView = victim.GetComponent<ZNetView>();
                if (!parry.Own || !parry.combat.Ready || !victimView || !victimView.IsValid()) return;
                long now = Now; parry.Prune(now);
                if (parry.submissions.Count >= 64) parry.submissions.RemoveAt(0);
                var entry=new Submission { Victim = victimView.GetZDO().m_uid, At = now, ContactId=++contactSequence,Command=parry.actor.CommandId,Serial=parry.actor.Serial,SourceTime=sourceTime,Point=hit.m_point,Direction=hit.m_dir };
                parry.submissions.Add(entry);
                long peer=victimView.GetZDO().GetOwner();
                if(peer!=0&&peer!=parry.owner){
                    var p=new ZPackage();p.Write(2);p.Write(entry.Victim);p.Write(entry.At);p.Write(entry.ContactId);p.Write(entry.Command);p.Write(entry.Serial);p.Write(entry.SourceTime);p.Write(entry.Point);p.Write(entry.Direction);
                    // Same routed peer, queued before the native Damage
                    // call. Defender-side gating uses this exact contact's source
                    // time, never a delayed replica animation clock.
                    parry.view.InvokeRPC(peer,ContactRpc,p);
                }
            });
        }
        void ReceiveContact(long sender,ZPackage p){
            Safe(()=>{
                SyncOwner();if(!bound||!view||!view.IsValid()||sender==0||sender!=view.GetZDO().GetOwner()||p==null||p.ReadInt()!=2)return;
                var entry=new Submission{Victim=p.ReadZDOID(),At=p.ReadLong(),ContactId=p.ReadLong(),Command=p.ReadInt(),Serial=p.ReadInt(),SourceTime=p.ReadDouble(),Point=p.ReadVector3(),Direction=p.ReadVector3()};
                long now=Now;Prune(now);ClipSpec spec;
                var targetObject=ZNetScene.instance?ZNetScene.instance.FindInstance(entry.Victim):null;
                var targetView=targetObject?targetObject.GetComponent<ZNetView>():null;
                if(!targetView||!targetView.IsValid()||!targetView.IsOwner()||entry.ContactId<=0||entry.Serial<0||entry.At<enabledAt||entry.At>now+TimeSpan.TicksPerSecond/4
                    ||(now-entry.At)/(double)TimeSpan.TicksPerSecond>KnightParryEpisode.LifetimeSeconds||!Finite(entry.Point)||!Finite(entry.Direction)
                    ||!KnightSourceData.ByCommand.TryGetValue(entry.Command,out spec)||!KnightDefensePolicy.Finite(entry.SourceTime)||entry.SourceTime<0||entry.SourceTime>spec.Duration+.000001
                    ||(entry.Point-transform.position).sqrMagnitude>144)return;
                if(submissions.Count>=64)submissions.RemoveAt(0);submissions.Add(entry);
            });
        }
        // Called only inside the native defender BlockAttack -> attacker.Stagger
        // call. Ordinary body-poise/guard-break staggers never use this filter.
        internal static bool AllowNativeParry(Character attacker,Character blocker,HitData hit,out long contactId){
            contactId=0;
            var parry=attacker?attacker.GetComponent<KnightParryPresentation>():null;
            if(!parry||!blocker||hit==null)return true;
            parry.SyncOwner();var blockerView=blocker.GetComponent<ZNetView>();
            if(!parry.bound||!blockerView||!blockerView.IsValid()||!blockerView.IsOwner())return true;
            long now=Now;parry.Prune(now);Submission match=null;
            foreach(var item in parry.submissions){
                if(item.NativeChecked||item.Victim!=blocker.GetZDOID()||(item.Point-hit.m_point).sqrMagnitude>.0004f||(item.Direction-hit.m_dir).sqrMagnitude>.0004f)continue;
                if(match==null||item.At>match.At)match=item;
            }
            if(match==null){parry.sourceParriesUnknown++;return true;}
            match.NativeChecked=true;contactId=match.ContactId;bool allowed=KnightParryWindows.Allows(match.Command,match.SourceTime);
            if(allowed)parry.sourceParriesAllowed++;else parry.sourceParriesRejected++;
            return allowed;
        }
        // Receipt of native RPC_Stagger is only evidence. It never dispatches
        // an ordinary stagger pose and never invokes native Stagger itself.
        internal void NativeAccepted(long sender, Vector3 direction, bool wasAlreadyStaggering)
        {
            SyncOwner();
            if (!Own || wasAlreadyStaggering || !Finite(direction)) return;
            direction.y = 0; nativeDirection = direction; nativeSender = sender;
            episode.NativeAccepted(Time.time, false); nativeAccepted++;
        }
        internal static void PerfectBlock(Character attacker, Character blocker, Vector3 direction,long contactId)
        {
            if (!attacker || !blocker || !Finite(direction) || contactId<=0) return;
            var parry = attacker.GetComponent<KnightParryPresentation>();
            var blockerView = blocker.GetComponent<ZNetView>();
            if (!parry || !blockerView || !blockerView.IsValid() || !blockerView.IsOwner()) return;
            parry.SyncOwner();
            if (!parry.bound || !parry.view || !parry.view.IsValid()) return;
            long at = Now, seq = ++sequence;
            if (parry.Own) { parry.Accept(blockerView.GetZDO().GetOwner(), blocker.GetZDOID(), at, seq, direction,contactId); return; }
            var p = new ZPackage(); p.Write(2); p.Write(blocker.GetZDOID()); p.Write(at); p.Write(seq);p.Write(contactId); p.Write(direction);
            // Like native Stagger, the default route targets the attacker owner.
            parry.view.InvokeRPC(HintRpc, p);
        }
        void Receive(long sender, ZPackage p)
        {
            Safe(() =>
            {
                SyncOwner();
                if (!Own || sender == 0 || p == null || p.ReadInt() != 2) return;
                ZDOID blocker = p.ReadZDOID(); long at = p.ReadLong(), seq = p.ReadLong();
                long contactId=p.ReadLong();Accept(sender, blocker, at, seq, p.ReadVector3(),contactId);
            });
        }
        void Accept(long sender, ZDOID blockerId, long at, long seq, Vector3 direction,long contactId)
        {
            if (!Own || seq <= 0 || contactId<=0 || sender == 0 || !Finite(direction)) return;
            long now = Now; Prune(now);
            string receipt = sender + ":" + blockerId + ":" + seq;
            var obj = ZNetScene.instance ? ZNetScene.instance.FindInstance(blockerId) : null;
            var blocker = obj ? obj.GetComponent<Character>() : null;
            var blockerView = obj ? obj.GetComponent<ZNetView>() : null;
            if (at < enabledAt || at > now + TimeSpan.TicksPerSecond / 4
                || (now - at) / (double)TimeSpan.TicksPerSecond > KnightParryEpisode.LifetimeSeconds
                || receipts.ContainsKey(receipt) || receipts.Count >= 128
                || !blocker || !blockerView || !blockerView.IsValid() || blockerView.GetZDO().GetOwner() != sender
                || blocker.IsDead() || !BaseAI.IsEnemy(human, blocker)
                || (blocker.transform.position - transform.position).sqrMagnitude > 144) { rejected++; return; }
            Submission match = null;
            foreach (var item in submissions)
                if(KnightParryReceiptPolicy.Matches(contactId,item.ContactId,item.Victim==blockerId,!item.Used,(at-item.At)/(double)TimeSpan.TicksPerSecond)){match=item;break;}
            if (match == null || !KnightParryWindows.Allows(match.Command,match.SourceTime)) { rejected++; return; }
            match.Used = true; receipts.Add(receipt, now);
            direction.y = 0; hintDirection = direction; hintSender = sender;
            episode.PerfectBlockHint(Time.time);
        }
        void OnDisable() { episode.Reset(); submissions.Clear(); receipts.Clear(); enabledAt = Now; }
        void OnEnable() { if (bound) ResetOwner(); }
        void OnDestroy() { if (bound && view){view.Unregister(HintRpc);view.Unregister(ContactRpc);} bound = false; }
        public string Diagnostics() => "parryConfirmed=" + confirmed + " parryRejected=" + rejected + " nativeReceipts=" + nativeAccepted+" sourceParryAllowed="+sourceParriesAllowed+" sourceParryRejected="+sourceParriesRejected+" sourceParryUnknown="+sourceParriesUnknown;
    }
}
