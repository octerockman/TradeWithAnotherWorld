using System;
using System.Collections.Generic;

namespace BlackAbbey.ReliquaryKnight
{
    public static class KnightCombatTiming
    {
        public static List<EventWindow> DamageWindows(ClipSpec clip)
        {
            var result = new List<EventWindow>();
            var ordered = new List<EventWindow>(clip.AttackWindows);
            ordered.Sort((a, b) => a.Start.CompareTo(b.Start));
            foreach (var w in ordered)
            {
                if (w.Start >= clip.Duration || w.End <= w.Start) continue;
                var next = new EventWindow { Start = Math.Max(0, w.Start), End = Math.Min(clip.Duration, w.End) };
                if (result.Count > 0 && next.Start <= result[result.Count - 1].End)
                    result[result.Count - 1].End = Math.Max(next.End, result[result.Count - 1].End);
                else result.Add(next);
            }
            return result;
        }
        public static bool Overlap(EventWindow window, double previous, double current, out double start, out double end)
        {
            start = Math.Max(previous, window.Start); end = Math.Min(current, window.End);
            return !double.IsNaN(start) && !double.IsNaN(end) && !double.IsInfinity(start) && !double.IsInfinity(end) && end > start;
        }
    }
}
