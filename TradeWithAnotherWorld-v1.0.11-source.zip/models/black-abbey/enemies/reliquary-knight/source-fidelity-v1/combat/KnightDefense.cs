using System;
using HarmonyLib;
using UnityEngine;
namespace BlackAbbey.ReliquaryKnight {
 // Resource adapter only. Body damage/status handling and actual stagger are
 // native; guard endurance fills the otherwise empty NPC stamina methods.
 [DefaultExecutionOrder(1080)]
 public sealed class KnightDefense:MonoBehaviour {
  static readonly AccessTools.FieldRef<Character,float> NativePosture=AccessTools.FieldRefAccess<Character,float>("m_staggerDamage");
  readonly KnightGuardEndurance endurance=new KnightGuardEndurance();
  Humanoid human;ZNetView view;bool wasOwner;long owner;float nextPublish,exhaustionPendingUntil;
  public bool Own=>human&&view&&view.IsValid()&&view.IsOwner()&&!human.IsDead()&&human.GetHealth()>0;
  public bool GuardAvailable{get{SyncOwner();return Own&&endurance.Available;}}
  public bool CanCounter=>GuardAvailable&&human&&!human.IsStaggering()&&NativePosture(human)<KnightDefensePolicy.NativePostureThreshold;
  void Awake(){human=GetComponent<Humanoid>();view=GetComponent<ZNetView>();SyncOwner();}
  void SyncOwner(){
   if(!view||!view.IsValid())return;
   bool own=Own;long current=view.GetZDO().GetOwner();
   if(current!=owner||own!=wasOwner){owner=current;wasOwner=own;exhaustionPendingUntil=0;if(own)endurance.Load(view.GetZDO().GetFloat("rk_guard_v1",120),view.GetZDO().GetBool("rk_guard_recover_v1",false),Time.time);}
  }
  void Update(){
   SyncOwner();if(!Own)return;
   Refresh();
   if(Time.time>=nextPublish){nextPublish=Time.time+.5f;Publish();}
  }
  void Refresh(){
   SyncOwner();
   if(!Own)return;
   RefreshNativePosture();
   endurance.Advance(Time.time,human.IsBlocking(),human.IsStaggering());
  }
  internal void RefreshNativePosture(){SyncOwner();if(Own)human.m_staggerDamageFactor=(float)KnightDefensePolicy.Factor(human.GetMaxHealth());}
  void Publish(){if(Own){view.GetZDO().Set("rk_guard_v1",(float)endurance.Guard);view.GetZDO().Set("rk_guard_recover_v1",endurance.Recovering);}}
  internal void SpendGuard(float amount){if(!Own)return;Refresh();endurance.Spend(amount,Time.time);Publish();}
  internal void RestoreGuard(float amount){if(!Own)return;Refresh();endurance.Restore(amount);Publish();}
  internal bool HasGuard(float amount){Refresh();return Own&&endurance.Available&&endurance.Has(amount);}
  internal void ExhaustionStagger(Vector3 direction){
   if(!Own||endurance.Has(0)||human.IsStaggering()||Time.time<exhaustionPendingUntil)return;
   exhaustionPendingUntil=Time.time+1.5f;human.Stagger(direction);
  }
  public static bool TargetGuardBroken(Character target)=>KnightGuardBreakWitness.Active(target);
  public string Diagnostics()=>"guard="+endurance.Guard.ToString("F1")+"/120 guardRecover="+endurance.Recovering+" posture="+(human?KnightDefensePolicy.NormalizePosture(NativePosture(human)).ToString("F1"):"0")+"/65";
 }
}
