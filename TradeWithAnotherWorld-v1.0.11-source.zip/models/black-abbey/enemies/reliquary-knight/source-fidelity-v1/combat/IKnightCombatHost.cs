using UnityEngine;

namespace BlackAbbey.ReliquaryKnight
{
    // Root-owned motion/motor adapter. All times are actual, unscaled source seconds.
    // Contact positions are already in world space, including actor travel exactly once.
    public interface IKnightCombatHost
    {
        bool Ready { get; }
        bool ContextActive { get; }
        bool GuardPoseRequested { get; }
        int CommandId { get; }
        int Serial { get; }
        string ClipId { get; }
        double ClipTime { get; }
        double PreviousClipTime { get; }
        bool PathReady { get; }
        bool CanMoveForward { get; }
        bool CanMoveBackward { get; }
        bool CanMoveLeft { get; }
        bool CanMoveRight { get; }
        bool CanStart(ClipSpec clip);
        bool TryPlay(ClipSpec clip, bool loop);
        void ApplyDecision(Decision decision, Character target, float dt);
        void StopMovement();
        void InterruptForNativeReaction();
        void YieldToNativeSearch();
        void BeginDeathPresentation();
        // Return false when no fitted contact is available for this exact command.
        bool TryContactPose(int commandId, double time, int index, out KnightContactPose pose);
        ItemDrop.ItemData GetDamageItem(int commandId);
    }

    public struct KnightContactPose
    {
        public Vector3 Center;
        public Quaternion Rotation;
        public Vector3 HalfExtents;
    }
}
