namespace BlackAbbey.ReliquaryKnight
{
    // A source guard is a current action request, never a latched native input.
    // This pure policy is used immediately before native UpdateBlock synchronizes
    // the result into the hidden Animator and the network blocking flag.
    public static class KnightGuardPolicy
    {
        public static bool Requested(bool readyOwner, bool nativeCapable, bool liveCombatTarget,
            Decision decision, int command, double time, int serial, int attackSerial)
        {
            if (!readyOwner || !nativeCapable || !liveCombatTarget || decision == null
                || !KnightSourceData.GuardActive(command, time)) return false;
            bool committed = decision.Committed && decision.CommandId == command && attackSerial == serial;
            bool posture = decision.GuardRequested && !decision.Committed
                && (decision.Kind == DecisionKind.Idle || decision.Kind == DecisionKind.Move);
            return committed || posture;
        }
    }
}
