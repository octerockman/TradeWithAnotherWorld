using System;
namespace BlackAbbey.ReliquaryKnight {
 // Normalized source capacities with a conservative Valheim calibration. The
 // native body accumulator, status modifiers, decay and rewards remain native.
 public static class KnightDefensePolicy {
  public const double GuardCapacity=120,GuardRecoveryPerSecond=21,GuardRecoveryDelay=1;
  public const double GuardResume=24,BodyPostureCapacity=65,NativePostureUnitsPerPoint=6;
  public const double NativePostureThreshold=BodyPostureCapacity*NativePostureUnitsPerPoint;
  public static double Factor(double maxHealth)=>Finite(maxHealth)&&maxHealth>0?NativePostureThreshold/maxHealth:.6;
  public static double NormalizePosture(double nativeValue)=>Finite(nativeValue)?Math.Max(0,Math.Min(BodyPostureCapacity,nativeValue/NativePostureUnitsPerPoint)):0;
  public static bool Finite(double x)=>!double.IsNaN(x)&&!double.IsInfinity(x);
 }
 public sealed class KnightGuardEndurance {
  double guard=KnightDefensePolicy.GuardCapacity,last=double.NaN,lastSpend=double.NegativeInfinity;
  bool recovering;
  public double Guard=>guard;
  public bool Available=>!recovering&&guard>0;
  public bool Recovering=>recovering;
  public void Reset(){guard=KnightDefensePolicy.GuardCapacity;last=double.NaN;lastSpend=double.NegativeInfinity;recovering=false;}
  public void Load(double value,bool recovery,double now){guard=KnightDefensePolicy.Finite(value)?Math.Max(0,Math.Min(KnightDefensePolicy.GuardCapacity,value)):KnightDefensePolicy.GuardCapacity;recovering=recovery||guard<=0;last=now;lastSpend=now;}
  public void Advance(double now,bool guarding,bool nativeStaggering){
   if(!KnightDefensePolicy.Finite(now)){Reset();return;}
   if(!KnightDefensePolicy.Finite(last)||now<last){last=now;return;}
   double from=Math.Max(last,lastSpend+KnightDefensePolicy.GuardRecoveryDelay),dt=Math.Max(0,now-from);last=now;
   if(!guarding&&!nativeStaggering)guard=Math.Min(KnightDefensePolicy.GuardCapacity,guard+dt*KnightDefensePolicy.GuardRecoveryPerSecond);
   if(recovering&&guard>=KnightDefensePolicy.GuardResume)recovering=false;
  }
  public void Spend(double amount,double now){
   if(!KnightDefensePolicy.Finite(amount)||amount<=0||!KnightDefensePolicy.Finite(now))return;
   guard=Math.Max(0,guard-amount);lastSpend=now;
   if(guard<=0)recovering=true;
  }
  public void Restore(double amount){if(KnightDefensePolicy.Finite(amount)&&amount>0)guard=Math.Min(KnightDefensePolicy.GuardCapacity,guard+amount);}
  public bool Has(double amount)=>KnightDefensePolicy.Finite(amount)&&guard>Math.Max(0,amount);
 }
 public sealed class KnightGuardBreakEpisode {
  public const double VulnerabilitySeconds=1.5666667222976685;
  long untilTicks;
  public long UntilTicks=>untilTicks;
  public void Reset(){untilTicks=0;}
  public void Load(long expiryTicks){untilTicks=expiryTicks;}
  // Jesse's adaptation is broader than ER's tagged guard-break animation:
  // any actual processed failed player block opens this AI decision window.
  // It creates no animation, damage bonus or player stagger.
  public void FailedProcessedBlock(long nowTicks){if(nowTicks>0&&nowTicks<long.MaxValue-20000000)untilTicks=nowTicks+(long)(VulnerabilitySeconds*TimeSpan.TicksPerSecond);}
  public bool Active(long nowTicks)=>nowTicks>0&&untilTicks>nowTicks&&MarkerActive((untilTicks-nowTicks)/(double)TimeSpan.TicksPerSecond);
  public static bool MarkerActive(double secondsRemaining)=>KnightDefensePolicy.Finite(secondsRemaining)&&secondsRemaining>0&&secondsRemaining<=VulnerabilitySeconds+.25;
 }
 public static class KnightBlockOutcomePolicy {
  public static bool Failed(bool processed,bool poiseFailed,bool haveStamina)=>processed&&(poiseFailed||!haveStamina);
  public static bool Succeeded(bool processed,bool poiseFailed,bool haveStamina)=>processed&&!poiseFailed&&haveStamina;
 }
 public sealed class KnightBlockOutcomeSample {
  public bool Processed{get;private set;}
  public bool PoiseFailed{get;private set;}
  public bool StaminaCaptured{get;private set;}
  public bool NativeStamina{get;private set;}
  public bool Known=>Processed&&StaminaCaptured;
  public bool Failed=>Known&&KnightBlockOutcomePolicy.Failed(Processed,PoiseFailed,NativeStamina);
  public bool Succeeded=>Known&&KnightBlockOutcomePolicy.Succeeded(Processed,PoiseFailed,NativeStamina);
  public void PoiseResult(bool failed){Processed=true;PoiseFailed|=failed;}
  public void StaminaResult(float amount,bool result){if(!Processed||StaminaCaptured||amount!=0)return;StaminaCaptured=true;NativeStamina=result;}
 }
}
