using System;

namespace BlackAbbey.ReliquaryKnight
{
    // Matches two independently ordered native receipts. Ordinary damage or
    // stagger alone never admits a visual; only a confirmed perfect block can.
    public sealed class KnightParryEpisode
    {
        public const double LifetimeSeconds = 1.5;
        double nativeUntil = double.NegativeInfinity, hintUntil = double.NegativeInfinity;
        bool sawNativeTag, presented;
        public void Reset() { nativeUntil = hintUntil = double.NegativeInfinity; sawNativeTag = presented = false; }
        public void NativeAccepted(double now, bool alreadyStaggering)
        {
            if (alreadyStaggering || presented || !Finite(now)) return;
            // Repeated native triggers before Animator enters its tag cannot
            // extend a candidate indefinitely.
            if (nativeUntil < now) nativeUntil = now + LifetimeSeconds;
        }
        public void PerfectBlockHint(double now)
        {
            if (!presented && Finite(now)) hintUntil = now + LifetimeSeconds;
        }
        public bool Tick(double now, bool nativeStaggering, bool matchingEvidence = true)
        {
            if (!Finite(now)) { Reset(); return false; }
            if (sawNativeTag && !nativeStaggering) { Reset(); return false; }
            if (nativeStaggering) sawNativeTag = true;
            if (presented || !nativeStaggering || !matchingEvidence || now > nativeUntil || now > hintUntil) return false;
            presented = true; hintUntil = double.NegativeInfinity;
            return true;
        }
        static bool Finite(double n) => !double.IsNaN(n) && !double.IsInfinity(n);
    }
}
