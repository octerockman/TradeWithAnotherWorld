namespace BlackAbbey.ReliquaryKnight
{
    // Body posture keeps the native accumulator, modifiers, decay and rewards.
    // Its fixed threshold no longer grows with max HP; shield endurance is separate.
    public static class KnightPoiseProfile
    {
        public const float BlockedBuildupMultiplier = KnightPoisePolicy.BlockedBuildupMultiplier;
        public static void Configure(Humanoid human) { if (human) human.m_staggerDamageFactor = (float)KnightDefensePolicy.Factor(human.m_health); }
        public static double Threshold(double maxHealth) => KnightPoisePolicy.Threshold(maxHealth);
        public static double Contribution(double nativeContribution, bool insideThisDefendersBlock)
            => KnightPoisePolicy.Contribution(nativeContribution, insideThisDefendersBlock);
    }
}
