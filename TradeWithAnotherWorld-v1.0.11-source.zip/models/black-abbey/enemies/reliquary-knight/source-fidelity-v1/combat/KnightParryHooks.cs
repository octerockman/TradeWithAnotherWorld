using System;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbey.ReliquaryKnight
{
    public static class KnightParryHooks
    {
        sealed class BlockScope
        {
            public Humanoid Blocker;
            public Character Attacker;
            public HitData Hit;
            public bool NativeParryCall;
            public Vector3 Direction;
            public long ContactId;
            public BlockScope Previous;
        }
        [ThreadStatic] static BlockScope current;

        [HarmonyPatch(typeof(Humanoid), "BlockAttack")]
        static class NativeBlock
        {
            static void Prefix(Humanoid __instance,HitData __0, Character __1, out BlockScope __state)
            {
                __state = new BlockScope { Blocker = __instance, Attacker = __1, Hit=__0, Previous = current }; current = __state;
            }
            static void Postfix(Humanoid __instance, bool __result, BlockScope __state)
            {
                if (__state != null) current = __state.Previous;
                if (__result && __state != null && __state.NativeParryCall)
                    KnightParryPresentation.Safe(() => KnightParryPresentation.PerfectBlock(__state.Attacker, __instance, __state.Direction,__state.ContactId));
            }
            static Exception Finalizer(Exception __exception, BlockScope __state)
            {
                if (__state != null) current = __state.Previous; return __exception;
            }
        }
        // Actual installed BlockAttack has exactly one attacker.Stagger call,
        // after the successful timed-block gates. This observes that native call
        // without replacing, re-triggering or modifying it.
        [HarmonyPatch(typeof(Character), "Stagger")]
        static class PerfectBlockCall
        {
            static bool Prefix(Character __instance, out bool __state)
            {
                __state = current != null && current.Attacker == __instance && !__instance.IsStaggering();
                if(__state&&!KnightParryPresentation.AllowNativeParry(__instance,current.Blocker,current.Hit,out current.ContactId)){__state=false;return false;}
                return true;
            }
            static void Postfix(Character __instance, Vector3 __0, bool __state,bool __runOriginal)
            {
                if (__runOriginal && __state && current != null && current.Attacker == __instance) { current.NativeParryCall = true; current.Direction = __0; }
            }
        }
        [HarmonyPatch(typeof(Character), "RPC_Stagger")]
        static class NativeAcceptedReceipt
        {
            static void Prefix(Character __instance, out bool __state) { __state = __instance.IsStaggering(); }
            static void Postfix(Character __instance, long __0, Vector3 __1, bool __state,bool __runOriginal)
            {
                var parry = __instance ? __instance.GetComponent<KnightParryPresentation>() : null;
                if (__runOriginal && parry) KnightParryPresentation.Safe(() => parry.NativeAccepted(__0, __1, __state));
            }
        }
    }
}
