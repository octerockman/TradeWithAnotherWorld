using System;
using UnityEngine;
namespace BlackAbbey.ReliquaryKnight {
 // Only the authoritative player publishes this short-lived perception mark.
 // It requires a real processed failed block. Per Jesse's explicit adaptation,
 // stamina failure also counts even when native code does not stagger the
 // player. It changes AI perception only, never player movement or damage.
 public sealed class KnightGuardBreakWitness:MonoBehaviour {
  const string Marker="rk_guardbroken_v1";
  readonly KnightGuardBreakEpisode episode=new KnightGuardBreakEpisode();
  Character character;ZNetView view;long owner;bool wasOwner,marked;
  static long Now=>ZNet.instance?ZNet.instance.GetTime().Ticks:DateTime.UtcNow.Ticks;
  bool Own=>character&&character.IsPlayer()&&view&&view.IsValid()&&view.IsOwner()&&!character.IsDead();
  void Awake(){character=GetComponent<Character>();view=GetComponent<ZNetView>();SyncOwner();}
  void SyncOwner(){
   if(!view||!view.IsValid())return;
   bool own=Own;long current=view.GetZDO().GetOwner();
   if(current!=owner||own!=wasOwner){owner=current;wasOwner=own;episode.Load(view.GetZDO().GetLong(Marker,0));marked=own&&episode.Active(Now);}
  }
  internal static void FailedBlock(Character defender){
   if(!defender||!defender.IsPlayer())return;
   var v=defender.GetComponent<ZNetView>();if(!v||!v.IsValid()||!v.IsOwner())return;
   var witness=defender.GetComponent<KnightGuardBreakWitness>()??defender.gameObject.AddComponent<KnightGuardBreakWitness>();
   witness.SyncOwner();
   witness.episode.FailedProcessedBlock(Now);witness.view.GetZDO().Set(Marker,witness.episode.UntilTicks);witness.marked=true;
  }
  void Update(){
   if(!view||!view.IsValid())return;
   SyncOwner();if(!Own)return;
   if(marked&&!episode.Active(Now)){view.GetZDO().Set(Marker,0L);marked=false;episode.Reset();}
  }
  public static bool Active(Character target){
   if(!target||!target.IsPlayer()||target.IsDead())return false;
   var view=target.GetComponent<ZNetView>();if(!view||!view.IsValid())return false;
   long expiry=view.GetZDO().GetLong(Marker,0),now=Now;if(now<=0||expiry<=now)return false;long remaining=expiry-now;
   return KnightGuardBreakEpisode.MarkerActive(remaining/(double)TimeSpan.TicksPerSecond);
  }
  void OnDisable(){if(Own&&marked)view.GetZDO().Set(Marker,0L);marked=false;episode.Reset();}
 }
}
