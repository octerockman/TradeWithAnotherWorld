namespace BlackAbbey.ReliquaryKnight {
 // Contact safety only; no damage-reaction animation or behavior handler.
 public static class KnightContactAdmission {
  public static bool Admitted(bool readyOwner,bool contextActive,int damageSerial,int currentSerial,bool nativeStaggering)=>readyOwner&&!contextActive&&damageSerial==currentSerial&&!nativeStaggering;
 }
}
