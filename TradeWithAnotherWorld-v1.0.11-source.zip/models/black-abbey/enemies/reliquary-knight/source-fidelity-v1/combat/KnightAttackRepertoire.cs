using System;
namespace BlackAbbey.ReliquaryKnight {
 // User-directed physical variants recovered from two supplied sibling sword
 // brains. Primary435100 action/movement/guard weights remain unchanged.
 public static class KnightAttackRepertoire {
  public const int ChancePercent=30;
  public static bool Autonomous(ClipSpec c){
   if(c==null||c.IsAdditive)return false;
   if(c.AutonomousAllowed)return true;
   return c.AttackWindows!=null&&c.AttackWindows.Length>0&&
    (c.CommandId==3030&&c.ClipId=="a000_003030"&&Math.Abs(c.Duration-2.5)<.00001||
     c.CommandId==3034&&c.ClipId=="a000_003034"&&Math.Abs(c.Duration-2.866667)<.00001);
  }
  public static bool Additional(int command)=>command==3030||command==3034;
  public static bool UsesShield(int command)=>command==3003||command==3030;
  public static int Candidate(int action,int command)=>action==15&&command==3022?3030:action==3&&command==3004?3034:-1;
  public static int ParentCommand(int action,int command)=>action==15&&command==3030?3022:action==3&&command==3034?3004:command;
  public static double CooldownSeconds(int command)=>command==3030?15:command==3034?5:0;
  public static string Provenance(int command)=>command==3030?"User-directed physical shield3030 variant recovered from435600Act15; own15second cooldown, no projectile or borrowed spell effects.":command==3034?"User-directed physical sword3034 variant recovered from435420Act12; own5second cooldown, no projectile or borrowed spell effects.":"";
 }
 public sealed partial class C4351BattleBrain {
  uint _repertoireRng;
  int RepertoireRoll(){_repertoireRng^=_repertoireRng<<13;_repertoireRng^=_repertoireRng>>17;_repertoireRng^=_repertoireRng<<5;return 1+(int)(_repertoireRng%100);}
  int RepertoireVariant(int command,int action,SenseFrame s){
   int candidate=KnightAttackRepertoire.Candidate(action,command);
   double range=(action==15?5:4)-_radius;
   if(candidate<0||!Admitted(candidate,s)||Math.Abs(Angle(s.FacingDegrees))>60||SourceDistance(s)>range||Cooling(candidate,KnightAttackRepertoire.CooldownSeconds(candidate),s.NowSeconds))return command;
   return RepertoireRoll()<=KnightAttackRepertoire.ChancePercent?candidate:command;
  }
 }
}
