using HarmonyLib;
namespace BlackAbbey.ReliquaryKnight {
 public static class KnightDeathHealthHooks {
  [HarmonyPatch(typeof(Character),nameof(Character.SetHealth))]
  static class HealthZero {
   static void Prefix(Character __instance,out float __state){__state=__instance?__instance.GetHealth():0;}
   static void Postfix(Character __instance,float __state){if(__instance)KnightAudio.Safe(()=>__instance.GetComponent<KnightAudio>()?.MarkHealthZero(__state));}
  }
 }
}
