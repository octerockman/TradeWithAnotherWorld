using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Object=UnityEngine.Object;
namespace BlackAbbey.ReliquaryKnight {
 [DefaultExecutionOrder(1150)]
 public sealed class KnightAudio:MonoBehaviour {
  const string EventRpc="RK_AudioEventV1";
  static readonly HashSet<KnightAudio> actors=new HashSet<KnightAudio>();
  static readonly List<GameObject> tails=new List<GameObject>();
  static bool callbackFailed;
  ZNetView view;Humanoid human;MonsterAI ai;KnightActor actor;KnightCombat combat;
  AudioSource voice;readonly List<AudioSource> foley=new List<AudioSource>();int foleySlot;
  Transform head,sword,shield;System.Random random;int identity;
  bool bound,ready,wasOwner,dead,armedLife,wasAlerted,deathPlayed,pendingWarning,pendingRecovery;
  long ownerId,enabledAt,healthZeroTicks;int outgoing,receivedSequence,observedSerial=int.MinValue;
  double observedTime;float sampledAt,quietUntil,nextSpeech,nextEffort,nextHurt,nextGuardSpeech,nextIdle,nextGear,nextCloth,nextStep,nextWorld;
  int lastAttackAction=int.MinValue;float lastAttackAt;Vector3 previousRoot;Quaternion previousRotation;
  readonly Dictionary<string,float> lineTimes=new Dictionary<string,float>();readonly Dictionary<string,float> cueTimes=new Dictionary<string,float>();
  readonly HashSet<string> sourceEvents=new HashSet<string>();
  Foot[] feet;GameObject deathTail;Transform deathAnchor;
  int emitted,received,steps,swings,spoken;
  sealed class Foot {public Transform Bone;public bool Seeded,Lifted;public float BaseHeight;public Vector3 LastPlant,LastRoot,Observed;public Quaternion LastRotation;}
  public static long Now=>ZNet.instance?ZNet.instance.GetTime().Ticks:DateTime.UtcNow.Ticks;
  public bool Owner=>ready&&isActiveAndEnabled&&view&&view.IsValid()&&view.IsOwner()&&wasOwner&&view.GetZDO().GetOwner()==ownerId;
  static bool Finite(Vector3 p)=>!float.IsNaN(p.x)&&!float.IsNaN(p.y)&&!float.IsNaN(p.z)&&!float.IsInfinity(p.x)&&!float.IsInfinity(p.y)&&!float.IsInfinity(p.z);
  public static void Safe(Action action){try{action();}catch(Exception e){if(callbackFailed)return;callbackFailed=true;KnightCombat.Log?.Invoke("RK_AUDIO_CALLBACK_SKIPPED "+e.GetBaseException().Message);}}
  public static void Prepare(string folder)=>KnightAudioBank.Prepare(folder);
  void Awake(){view=GetComponent<ZNetView>();human=GetComponent<Humanoid>();ai=GetComponent<MonsterAI>();actor=GetComponent<KnightActor>();combat=GetComponent<KnightCombat>();}
  void Start(){Safe(Initialize);}
  void OnEnable(){if(ready)Safe(Resume);}
  void Initialize(){
   if(ready||!view||!view.IsValid()||!human||!ai||!actor||!actor.Ready||KnightAudioBank.Cues.Count!=59)return;
   var rig=transform.Find("RK_VisualRig");if(!rig)return;var nodes=rig.GetComponentsInChildren<Transform>(true);
   head=Array.Find(nodes,t=>t.name=="Head")??transform;sword=Array.Find(nodes,t=>t.name=="R_Sword")??head;shield=Array.Find(nodes,t=>t.name=="L_Shield")??head;
   identity=view.GetZDO().m_uid.ToString().GetStableHashCode()&int.MaxValue;random=new System.Random(identity);
   // These sources are outside the cloned visual rig; corpse creation cannot copy/restart them.
   voice=KnightAudioBank.Source(transform,"RK Approved Voice");voice.maxDistance=18;
   for(int i=0;i<6;i++){var s=KnightAudioBank.Source(transform,"RK Equipment "+i);s.maxDistance=14;foley.Add(s);}
   feet=new[]{"L_Foot","R_Foot"}.Select(n=>new Foot{Bone=Array.Find(nodes,t=>t.name==n)}).ToArray();
   if(!bound){view.Register<ZPackage>(EventRpc,Receive);bound=true;}ready=true;actors.Add(this);Resume();
  }
  void Resume(){if(!view||!view.IsValid())return;ownerId=view.GetZDO().GetOwner();wasOwner=view.IsOwner();enabledAt=Now;outgoing=receivedSequence=0;observedSerial=actor?actor.Serial:int.MinValue;observedTime=actor?actor.ClipTime:0;sampledAt=Time.time;sourceEvents.Clear();cueTimes.Clear();previousRoot=transform.position;previousRotation=transform.rotation;quietUntil=Time.time+.35f;nextIdle=Time.time+45+(identity%31);wasAlerted=ai&&ai.IsAlerted();lastAttackAction=int.MinValue;
   pendingWarning=pendingRecovery=false;if(feet!=null)foreach(var f in feet)f.Seeded=f.Lifted=false;if(human&&!human.IsDead()&&human.GetHealth()>0)armedLife=true;
  }
  void Update(){Safe(Tick);}
  void Tick(){
   if(!ready){Initialize();return;}if(!view||!view.IsValid())return;
   if(ownerId!=view.GetZDO().GetOwner()||wasOwner!=view.IsOwner()){StopAttached();Resume();return;}
   if(!Finite(transform.position)||(transform.position-previousRoot).sqrMagnitude>9){StopAttached();Resume();return;}
   previousRoot=transform.position;
   if(!human||human.IsDead()||human.GetHealth()<=0||dead)return;armedLife=true;
   if(voice)voice.transform.position=head?head.position:human.GetCenterPoint();
   bool alert=ai.IsAlerted();var target=ai.GetTargetCreature();bool realAlert=alert&&target&&!target.IsDead()&&target.GetHealth()>0&&!target.InGhostMode()&&BaseAI.IsEnemy(human,target)&&ai.CanSeeTarget(target);
   if(Owner&&realAlert&&!wasAlerted)pendingWarning=true;
   if(!realAlert)pendingWarning=false;
   if(Owner&&pendingWarning&&Time.time>=quietUntil){pendingWarning=false;Say("warning",1f,25);}wasAlerted=realAlert;
   if(Owner&&pendingRecovery&&!human.IsStaggering()&&!actor.ContextActive){pendingRecovery=false;Say("recover",.15f,12);}
   if(Owner&&!alert&&Time.time>=nextIdle){nextIdle=Time.time+50+random.Next(40);Say("rare_idle",.25f,30);}
   float turn=Quaternion.Angle(previousRotation,transform.rotation);previousRotation=transform.rotation;
   if(Owner&&turn>2&&!human.IsStaggering()&&Time.time>=nextGear){Group("armor_move",human.GetCenterPoint());nextGear=Time.time+2;}
  }
  void LateUpdate(){Safe(ObserveSource);Safe(FootPlants);}
  void ObserveSource(){
   if(!Owner||dead||!actor||!actor.Ready||!human||human.IsDead()||Time.time<quietUntil)return;
   int serial=actor.Serial,cmd=actor.CommandId;double current=actor.ClipTime;float dt=Time.time-sampledAt;sampledAt=Time.time;
   if(serial!=observedSerial){
    observedSerial=serial;sourceEvents.Clear();observedTime=current<=.15?-0.0001:current;
    // Only new locally observed beginnings can speak; restored clocks seed quietly.
    if(current<=.15&&KnightAudioMarkers.IsAttack(cmd)){
     int action=combat?.LastDecision?.SourceActionId??cmd;bool first=action!=lastAttackAction||Time.time-lastAttackAt>4;
     lastAttackAt=Time.time;lastAttackAction=action;if(first)Say("attack",.20f,12);
    }
   }
   if(dt<0||dt>.3||current<observedTime){observedTime=current;sourceEvents.Clear();return;}
   foreach(var marker in KnightAudioMarkers.For(cmd)){
    if(!(observedTime<marker.At&&current>=marker.At))continue;
    string key=marker.Role+":"+marker.At.ToString("R",System.Globalization.CultureInfo.InvariantCulture);
    if(!sourceEvents.Add(key))continue;
    var at=marker.Role=="shield_raise"||marker.Role=="shield_lower"||marker.Role=="shield_move"?shield.position:sword.position;
    if(marker.Role=="sword_air"){
     KnightContactPose a,b;if(actor.TryContactPose(cmd,Math.Max(0,marker.At-.06),0,out a)&&actor.TryContactPose(cmd,marker.At+.06,0,out b)&&(b.Center-a.Center).sqrMagnitude>.0001f){Group("sword_air",at);swings++;}
    }else if(marker.Role=="effort"){
     if(Time.time>=nextEffort&&random.NextDouble()<.45){nextEffort=Time.time+1.2f;Group(KnightAudioMarkers.Heavy(cmd)?"heavy_attack":"light_attack",head.position);}
    }else if(marker.Role=="shield_move")Group("armor_move",at);
    else if(marker.Role=="parried"||marker.Role=="stagger"){
     Group(marker.Role,human.GetCenterPoint());pendingRecovery=true;
     // Missing pain voices are intentionally absent; a successful recovery may speak later.
    }else Group(marker.Role,at);
   }
   observedTime=current;
  }
  void FootPlants(){
   if(!Owner||dead||!human||human.IsDead()||!human.IsOnGround()||!actor||!actor.Ready||Time.time<quietUntil){if(feet!=null)foreach(var f in feet)f.Seeded=f.Lifted=false;return;}
   if(feet==null)return;foreach(var f in feet){
    if(!f.Bone)continue;Vector3 at=f.Bone.position;if(f.Seeded&&(at-f.Observed).sqrMagnitude<.000001f)continue;f.Observed=at;
    if(!Finite(at)||!Physics.Raycast(at+Vector3.up*.12f,Vector3.down,out var floor,.85f,KnightCombat.SolidMask,QueryTriggerInteraction.Ignore)||floor.normal.y<.65f||floor.collider.transform.IsChildOf(transform)){f.Seeded=false;f.Lifted=false;continue;}
    float height=Math.Max(0,at.y-floor.point.y);
    if(!f.Seeded){f.Seeded=true;f.BaseHeight=Math.Min(height,.30f);f.LastPlant=at;f.LastRoot=transform.position;f.LastRotation=transform.rotation;continue;}
    f.BaseHeight=Math.Min(f.BaseHeight,height);if(height>f.BaseHeight+.105f)f.Lifted=true;
    float footTravel=Vector3.ProjectOnPlane(at-f.LastPlant,Vector3.up).magnitude;
    bool rootMoved=Vector3.ProjectOnPlane(transform.position-f.LastRoot,Vector3.up).sqrMagnitude>.0036f||Quaternion.Angle(f.LastRotation,transform.rotation)>8;
    if(!f.Lifted||height>f.BaseHeight+.065f||footTravel<.10f||!rootMoved||Time.time<nextStep)continue;
    f.Lifted=false;f.LastPlant=at;f.LastRoot=transform.position;f.LastRotation=transform.rotation;nextStep=Time.time+.14f;
    // The bank has stone boot plants. Unsupported/soft terrain stays quiet rather than claiming a false surface.
    if(!StoneSurface(Surface(floor.collider)))continue;
    Group("footstep",floor.point);steps++;
    if(Time.time>=nextGear){Group("armor_move",human.GetCenterPoint());nextGear=Time.time+1.6f;}
    if(Time.time>=nextCloth){Group("cloth",human.GetCenterPoint());nextCloth=Time.time+2.8f;}
   }
  }
  bool BusyVoice=>voice&&voice.isPlaying;
  bool NearbyVoice(bool effort){int count=0;foreach(var a in actors)if(a&&a!=this&&a.BusyVoice&&(a.transform.position-transform.position).sqrMagnitude<324){if(!effort)return true;if(++count>=2)return true;}return false;}
  void Say(string family,float chance,float cooldown){
   if(!Owner||dead||Time.time<nextSpeech||BusyVoice||NearbyVoice(false)||random.NextDouble()>=chance)return;
   var choices=KnightAudioBank.Find(family,"spoken").Where(c=>!lineTimes.TryGetValue(c.id,out var last)||Time.time-last>=30).ToArray();if(choices.Length==0)return;
   var cue=choices[random.Next(choices.Length)];lineTimes[cue.id]=Time.time;nextSpeech=Time.time+Math.Max(8,cooldown);Emit(cue.id,head?head.position:transform.position);
  }
  public void Emit(string id,Vector3 point){Safe(()=>{
   if(!Owner||!Finite(point)||!KnightAudioBank.Cues.TryGetValue(id,out var cue)||(dead&&cue.family!="death")||(point-transform.position).sqrMagnitude>144)return;
   if(cueTimes.TryGetValue(id,out var last)&&Time.time-last<.08f)return;cueTimes[id]=Time.time;
   var p=new ZPackage();p.Write(++outgoing);p.Write(id);p.Write(cue.family=="death"&&healthZeroTicks>0?healthZeroTicks:Now);p.Write(point);emitted++;view.InvokeRPC(ZNetView.Everybody,EventRpc,p);
  });}
  public void Group(string family,Vector3 point){Safe(()=>{
   if(!Owner||dead||random==null)return;var choices=KnightAudioBank.Find(family);if(choices.Length==0)return;
   var cue=choices[random.Next(choices.Length)];if(cue.role=="effort"&&(BusyVoice||NearbyVoice(true)))return;Emit(cue.id,point);
  });}
  void Receive(long sender,ZPackage p){Safe(()=>{
   if(!ready||!isActiveAndEnabled||!view||!view.IsValid()||sender==0||sender!=view.GetZDO().GetOwner()||sender!=ownerId)return;
   int sequence=p.ReadInt();string id=p.ReadString();long at=p.ReadLong();Vector3 point=p.ReadVector3();double age=(Now-at)/(double)TimeSpan.TicksPerSecond;
   if(id==null||id.Length>100||!KnightAudioBank.Cues.TryGetValue(id,out var cue)||sequence<=receivedSequence||at<enabledAt-TimeSpan.TicksPerSecond/4||age<-.5||age>1.5||!Finite(point)||(point-transform.position).sqrMagnitude>144||(dead&&cue.family!="death"))return;
   receivedSequence=sequence;received++;Play(cue,point,Math.Max(0,age));
  });}
  void Play(KnightAudioBank.Cue cue,Vector3 point,double age=0){
   if(cue.role=="spoken"&&cue.family=="death"){PlayDeath(point,age);return;}
   if(dead)return;
   if(cue.role=="spoken"||cue.role=="effort"){
    if(BusyVoice||NearbyVoice(cue.role=="effort"))return;voice.transform.position=head?head.position:point;voice.clip=cue.Clip;voice.volume=cue.volume*(cue.role=="spoken"?.72f:.78f);voice.time=(float)Math.Min(age,Math.Max(0,cue.Clip.length-.01f));voice.Play();if(cue.role=="spoken")spoken++;return;
   }
   PlayEquipment(cue,point,foley,ref foleySlot);
  }
  internal static void PlayEquipment(KnightAudioBank.Cue cue,Vector3 point,List<AudioSource> pool,ref int slot){
   if(cue==null||!cue.Clip||pool.Count==0||!Finite(point))return;var source=pool.FirstOrDefault(s=>s&&!s.isPlaying)??pool[(slot++&int.MaxValue)%pool.Count];source.transform.position=point;var anchor=source.GetComponent<KnightAudioFixedPoint>();if(!anchor)anchor=source.gameObject.AddComponent<KnightAudioFixedPoint>();anchor.Point=point;source.clip=cue.Clip;source.pitch=1;source.volume=cue.volume*(cue.family=="cloth"?.28f:cue.family=="armor_move"?.36f:cue.family=="footstep"?.7f:.85f);source.time=0;source.Play();
  }
  public void Damage(float before,HitData hit){Safe(()=>{if(!Owner||dead||hit==null||!human||before<=human.GetHealth()||Time.time<nextHurt)return;nextHurt=Time.time+.35f;Group("armor_hit",Finite(hit.m_point)?hit.m_point:human.GetCenterPoint());});}
  public void Blocked(HitData hit){Safe(()=>{if(!Owner||dead||hit==null)return;Group("shield_block",Finite(hit.m_point)?hit.m_point:shield.position);if(Time.time>=nextGuardSpeech){nextGuardSpeech=Time.time+15;Say("guard",.15f,12);}});}
  public static string Surface(Collider c)=>c?c.name+" "+(c.sharedMaterial?c.sharedMaterial.name:""):"";
  public static bool StoneSurface(string surface){
   string m=(surface??"").ToLowerInvariant();
   if(m.Contains("wood")||m.Contains("oak")||m.Contains("timber")||m.Contains("pew")||m.Contains("plank")||m.Contains("board"))return false;
   // These named Abbey collider families are verified stone architecture in
   // the shipped room manifests; generic piece/default/terrain is insufficient.
   return m.Contains("stone")||m.Contains("rock")||m.Contains("marble")||m.Contains("masonry")||m.Contains("architecture_floor")||m.Contains("architecture_wall")||m.Contains("floor_relief")||m.Contains("wall_and_piers")||m.Contains("floor_and_dais")||m.Contains("vault_and_upperwall");
  }
  public void SolidContact(Vector3 point,string material){Safe(()=>{if(!Owner||dead||Time.time<nextWorld)return;nextWorld=Time.time+.13f;string m=(material??"").ToLowerInvariant();if(m.Contains("metal")||m.Contains("iron")||m.Contains("steel"))Group("sword_metal",point);else if(StoneSurface(m))Group("sword_stone",point);});}
  KnightAudioBank.Cue DeathCue(){var choices=KnightAudioBank.Find("death","spoken");return choices.Length==0?null:choices[identity%choices.Length];}
  public void MarkHealthZero(float before){Safe(()=>{
   if(!Owner||!armedLife||!human||before<=0||human.GetHealth()>0||healthZeroTicks>0)return;
   healthZeroTicks=Now;view.GetZDO().Set("rk_hp_zero_v1",healthZeroTicks);
   // Native CheckDeath runs later. Schedule on the actual positive-to-zero
   // health transition, retaining native death and presentation ownership.
   NativeDeath();
  });}
  public void NativeDeath(){Safe(()=>{
   if(!Owner||!armedLife||deathPlayed)return;var cue=DeathCue();if(cue==null)return;
   if(healthZeroTicks<=0)healthZeroTicks=view.GetZDO().GetLong("rk_hp_zero_v1",Now);
   // Dispatch while native actor/view still exists, before combat creates its cosmetic corpse.
   Emit(cue.id,head?head.position:human.GetCenterPoint());PlayDeath(head?head.position:human.GetCenterPoint(),Math.Max(0,(Now-healthZeroTicks)/(double)TimeSpan.TicksPerSecond));
  });}
  void PlayDeath(Vector3 point,double age){
   if(!armedLife||deathPlayed)return;var cue=DeathCue();if(cue==null||KnightDeathVoiceClock.Expired(age,cue.Clip.length))return;deathPlayed=true;dead=true;StopAttached();
   tails.RemoveAll(t=>!t);while(tails.Count>=24){Object.Destroy(tails[0]);tails.RemoveAt(0);}
   deathTail=new GameObject("RK Detached Death Voice");deathTail.transform.position=point;var source=KnightAudioBank.Source(deathTail.transform,"RK Final Words");source.clip=cue.Clip;source.volume=.8f;var follow=deathTail.AddComponent<KnightAudioTail>();follow.Target=deathAnchor?deathAnchor:head;follow.Schedule(source,age);tails.Add(deathTail);
  }
  public void AttachDeathAnchor(Transform holder){Safe(()=>{
   if(!holder)return;var nodes=holder.GetComponentsInChildren<Transform>(true);deathAnchor=Array.Find(nodes,t=>t.name=="Head")??Array.Find(nodes,t=>t.name=="Spine2")??Array.Find(nodes,t=>t.name=="Pelvis")??holder;
   if(!deathPlayed&&armedLife){long ticks=view&&view.IsValid()?view.GetZDO().GetLong("rk_hp_zero_v1",0):0;if(ticks<=0){string text=view&&view.IsValid()?view.GetZDO().GetString("rk_death_v3",""):"";long.TryParse(text,out ticks);}if(ticks>0){double age=(Now-ticks)/(double)TimeSpan.TicksPerSecond;var cue=DeathCue();if(age>=0&&cue!=null&&!KnightDeathVoiceClock.Expired(age,cue.Clip.length))PlayDeath(deathAnchor.position,age);}}
   dead=true;StopAttached();if(deathTail){var follow=deathTail.GetComponent<KnightAudioTail>();if(follow)follow.Target=deathAnchor;}
   if(!holder.GetComponent<KnightCorpseAudio>())holder.gameObject.AddComponent<KnightCorpseAudio>();
  });}
  void StopAttached(){if(voice)voice.Stop();foreach(var s in foley)if(s)s.Stop();}
  void OnDisable(){StopAttached();sourceEvents.Clear();if(feet!=null)foreach(var f in feet)f.Seeded=f.Lifted=false;}
  void OnDestroy(){if(bound&&view)view.Unregister(EventRpc);actors.Remove(this);}
  public string Diagnostics()=>"audio59 ready="+ready+" sent="+emitted+" received="+received+" steps="+steps+" swings="+swings+" spoken="+spoken;
  public static void Shutdown(){foreach(var a in actors)if(a)a.StopAttached();actors.Clear();foreach(var t in tails)if(t)Object.Destroy(t);tails.Clear();KnightNativeAudio.Shutdown();KnightAudioBank.Shutdown();callbackFailed=false;}
 }
 public sealed class KnightAudioTail:MonoBehaviour {
  public Transform Target;AudioSource source;double observedAge,scheduledAt;bool started;
  public void Schedule(AudioSource finalVoice,double deathAge){source=finalVoice;observedAge=Math.Max(0,deathAge);scheduledAt=Time.realtimeSinceStartupAsDouble;Tick();}
  void Update(){Tick();}
  void Tick(){
   if(!source||!source.clip){Object.Destroy(gameObject);return;}
   double age=observedAge+Math.Max(0,Time.realtimeSinceStartupAsDouble-scheduledAt);
   if(KnightDeathVoiceClock.Expired(age,source.clip.length)){Object.Destroy(gameObject);return;}
   if(!started&&KnightDeathVoiceClock.CanStart(age,source.clip.length)){started=true;source.time=(float)KnightDeathVoiceClock.Offset(age);source.Play();}
  }
  void LateUpdate(){if(Target)transform.position=Target.position;}
 }
 [DefaultExecutionOrder(1300)]
 public sealed class KnightAudioFixedPoint:MonoBehaviour {public Vector3 Point;void LateUpdate(){transform.position=Point;}}
}
