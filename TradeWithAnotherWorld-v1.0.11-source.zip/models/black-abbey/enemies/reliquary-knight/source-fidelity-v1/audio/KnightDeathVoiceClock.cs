using System;
namespace BlackAbbey.ReliquaryKnight {
 // Age starts at authoritative native HP-zero/death dispatch, not corpse rest.
 public static class KnightDeathVoiceClock {
  public const double DelaySeconds=1.0;
  public static bool CanStart(double deathAge,double clipLength)=>Finite(deathAge)&&Finite(clipLength)&&clipLength>0&&deathAge>=DelaySeconds&&deathAge<DelaySeconds+clipLength;
  public static double Offset(double deathAge)=>Math.Max(0,deathAge-DelaySeconds);
  public static bool Expired(double deathAge,double clipLength)=>!Finite(deathAge)||!Finite(clipLength)||clipLength<=0||deathAge>=DelaySeconds+clipLength+.3;
  static bool Finite(double x)=>!double.IsNaN(x)&&!double.IsInfinity(x);
 }
}
