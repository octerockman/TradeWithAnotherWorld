using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Jotunn.Entities;
using Jotunn.Managers;
using Jotunn.Utils;
using UnityEngine;
using Object=UnityEngine.Object;
namespace BlackAbbey.ReliquaryKnight {
 // Copy effect containers on this module's clones. Never edit shared native FX.
 public static class KnightNativeAudio {
  static readonly Dictionary<GameObject,GameObject> forks=new Dictionary<GameObject,GameObject>();
  static readonly MethodInfo Clone=typeof(object).GetMethod("MemberwiseClone",BindingFlags.Instance|BindingFlags.NonPublic);
  static bool Sound(GameObject p)=>p&&(p.GetComponentInChildren<AudioSource>(true)||p.GetComponentInChildren<ZSFX>(true));
  static bool Visual(GameObject p)=>p&&(p.GetComponentInChildren<Renderer>(true)||p.GetComponentInChildren<ParticleSystem>(true)||p.GetComponentInChildren<Light>(true));
  static void Mixer(GameObject p){if(KnightAudioBank.Mixer||!p)return;KnightAudioBank.Mixer=p.GetComponentsInChildren<AudioSource>(true).Select(a=>a.outputAudioMixerGroup).FirstOrDefault(m=>m);}
  static void Mute(GameObject own){foreach(var s in own.GetComponentsInChildren<AudioSource>(true)){Mixer(s.gameObject);s.Stop();s.mute=true;s.playOnAwake=false;s.volume=0;s.enabled=false;}foreach(var z in own.GetComponentsInChildren<ZSFX>(true)){z.m_playOnAwake=false;z.m_minVol=z.m_maxVol=0;z.m_audioClips=Array.Empty<AudioClip>();z.m_useVibration=false;z.m_playThroughController=z.m_playThroughAllControllers=false;z.m_controllerAudioVolume=0;z.m_closedCaptionToken=z.m_secondaryCaptionToken="";z.enabled=false;}}
  static GameObject Silent(GameObject source){
   if(forks.TryGetValue(source,out var known)&&known)return known;
   if(source.GetComponentInChildren<Character>(true)||source.GetComponentInChildren<Ragdoll>(true)||source.GetComponentInChildren<Projectile>(true)||source.GetComponentInChildren<Aoe>(true)||source.GetComponentInChildren<EffectArea>(true)||source.GetComponentsInChildren<ZNetView>(true).Any(v=>v.gameObject!=source))throw new InvalidOperationException("Unexpected gameplay payload in Knight audio visual fork: "+source.name);
   string name="BA_RK_SilentFX_"+source.name;if(ModQuery.GetPrefab(name)!=null)throw new InvalidOperationException("Own Knight FX fork name conflict: "+name);
   var manager=PrefabManager.Instance;var fork=manager.CreateClonedPrefab(name,source);
   if(!fork||fork==source||!fork.transform.parent||fork.activeInHierarchy)throw new InvalidOperationException("Knight FX fork must be private inactive prefab");
   try{Mute(fork);manager.AddPrefab(new CustomPrefab(fork,false));var published=ModQuery.GetPrefab(name);if(published?.Prefab!=fork||published.SourceMod?.GUID!=KnightPlugin.Id)throw new InvalidOperationException("Knight FX registration ownership failed");forks.Add(source,fork);return fork;}catch{Object.Destroy(fork);throw;}
  }
  static void FilterLists(object own){if(own==null)return;foreach(var f in own.GetType().GetFields(BindingFlags.Instance|BindingFlags.Public).Where(f=>f.FieldType==typeof(EffectList))){
   var effects=(f.GetValue(own)as EffectList)?.m_effectPrefabs??Array.Empty<EffectList.EffectData>();var copy=new List<EffectList.EffectData>();
   foreach(var e in effects){if(e?.m_prefab==null)continue;Mixer(e.m_prefab);var next=(EffectList.EffectData)Clone.Invoke(e,null);if(Sound(e.m_prefab)){if(!Visual(e.m_prefab))continue;next.m_prefab=Silent(e.m_prefab);}copy.Add(next);}
   f.SetValue(own,new EffectList{m_effectPrefabs=copy.ToArray()});
  }}
  public static void FilterPrefab(GameObject own){
   if(!own||own.name=="Draugr_Elite"||own.name=="SwordIron"||own.name=="ShieldBanded")throw new InvalidOperationException("Knight audio requires distinct own prefab");
   foreach(var component in own.GetComponentsInChildren<MonoBehaviour>(true))if(component)FilterLists(component);
   var drop=own.GetComponent<ItemDrop>();if(drop){var data=drop.m_itemData?.m_shared;FilterLists(data);if(data!=null){FilterLists(data.m_attack);FilterLists(data.m_secondaryAttack);}}
   // Direct own-instance native voice/animation sound components are private.
   Mute(own);foreach(var step in own.GetComponentsInChildren<FootStep>(true))step.enabled=false;
  }
  public static void Shutdown(){foreach(var f in forks.Values)if(f){PrefabManager.Instance.RemovePrefab(f.name);Object.Destroy(f);}forks.Clear();}
 }
}
