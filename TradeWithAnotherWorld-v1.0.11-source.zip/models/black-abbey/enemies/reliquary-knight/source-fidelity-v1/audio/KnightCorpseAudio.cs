using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace BlackAbbey.ReliquaryKnight {
 // Pure cosmetic observer. It never adds an impulse, collider or bone constraint.
 [DefaultExecutionOrder(1250)]
 public sealed class KnightCorpseAudio:MonoBehaviour {
  sealed class Probe {public Transform Bone;public Vector3 Last;public bool Seeded,Contact;}
  readonly List<AudioSource> sources=new List<AudioSource>();readonly HashSet<int> bound=new HashSet<int>();
  readonly Dictionary<int,float> bodyTimes=new Dictionary<int,float>();Probe[] probes;
  System.Random random;int slot,landings,settles;float nextImpact,nextProbe,started,lastAt;KnightDeathPlayback playback;
  void Start(){KnightAudio.Safe(()=>{
   started=lastAt=Time.realtimeSinceStartup;random=new System.Random(gameObject.GetInstanceID());playback=GetComponent<KnightDeathPlayback>();
   var nodes=GetComponentsInChildren<Transform>(true);probes=new[]{"Pelvis","Spine2","Head","L_Hand","R_Hand"}.Select(n=>new Probe{Bone=Array.Find(nodes,t=>t.name==n)}).ToArray();
   for(int i=0;i<2;i++)sources.Add(KnightAudioBank.Source(transform,"RK Corpse Contact "+i));
  });}
  void Update(){KnightAudio.Safe(()=>{
   if(random==null||bound.Count>=13||Time.realtimeSinceStartup<nextProbe)return;nextProbe=Time.realtimeSinceStartup+.2f;
   foreach(var body in GetComponentsInChildren<Rigidbody>(true))if(body&&bound.Add(body.GetInstanceID())){var receiver=body.gameObject.AddComponent<KnightCorpseAudioContact>();receiver.Owner=this;receiver.BodyId=body.GetInstanceID();}
  });}
  void LateUpdate(){KnightAudio.Safe(()=>{
   if(random==null||probes==null)return;float now=Time.realtimeSinceStartup,dt=now-lastAt;lastAt=now;
   // Once physical proxies exist, actual collision callbacks own contact audio.
   if(bound.Count>0||dt<=.0001f||dt>.15f)return;
   foreach(var p in probes){if(!p.Bone)continue;Vector3 at=p.Bone.position;
    if(!p.Seeded){p.Last=at;p.Seeded=true;continue;}
    float down=(p.Last.y-at.y)/dt;p.Last=at;
    bool near=Physics.Raycast(at+Vector3.up*.08f,Vector3.down,out var floor,.22f,KnightCombat.SolidMask,QueryTriggerInteraction.Ignore)&&floor.normal.y>.55f&&!floor.collider.transform.IsChildOf(transform);
    if(!near){p.Contact=false;continue;}
    if(!p.Contact&&down>.8f&&now-started>.25f)Impact(p.Bone.GetInstanceID(),floor.point,down,false);p.Contact=true;
   }
  });}
  internal void Collision(int body,Collision collision){KnightAudio.Safe(()=>{
   if(collision==null||collision.contactCount==0||!collision.collider||collision.collider.transform.IsChildOf(transform))return;
   if((KnightCombat.SolidMask&(1<<collision.collider.gameObject.layer))==0)return;
   float speed=collision.relativeVelocity.magnitude;var at=collision.GetContact(0).point;
   if(speed>=.85f)Impact(body,at,speed,true);
   else if(speed>=.18f&&landings>0&&settles<2&&Time.realtimeSinceStartup>=nextImpact+.3f){Play("settle",at);settles++;nextImpact=Time.realtimeSinceStartup+.6f;}
  });}
  void Impact(int body,Vector3 point,float speed,bool physical){
   float now=Time.realtimeSinceStartup;if(now<nextImpact||landings>=3||bodyTimes.TryGetValue(body,out var last)&&now-last<.3f)return;
   // The lying-pose physical handoff does not itself count as a fall.
   if(physical&&playback&&playback.PhysicsAge<.20&&speed<1.8f)return;
   bodyTimes[body]=now;nextImpact=now+.30f;landings++;Play("death_contact",point);
  }
  void Play(string family,Vector3 point){var cues=KnightAudioBank.Find(family,"equipment");if(cues.Length>0)KnightAudio.PlayEquipment(cues[random.Next(cues.Length)],point,sources,ref slot);}
 }
 public sealed class KnightCorpseAudioContact:MonoBehaviour {
  public KnightCorpseAudio Owner;public int BodyId;
  void OnCollisionEnter(Collision collision){if(Owner)Owner.Collision(BodyId,collision);}
 }
}
