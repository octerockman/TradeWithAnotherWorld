using System;
using System.Collections.Generic;
namespace BlackAbbey.ReliquaryKnight {
 // Timing hints from the retained source event audit; they never generate a hit.
 public static class KnightAudioMarkers {
  public readonly struct Marker {public readonly string Role;public readonly double At;public Marker(string role,double at){Role=role;At=at;}}
  public static bool Heavy(int c)=>c==3004||c==3005||c==3006||c==3007||c==3008||c==3010||c==3022||c==3030||c==3034;
  public static bool IsAttack(int c)=>For(c).Length>0&&(c>=3000&&c<4000);
  static readonly Dictionary<int,Marker[]> cache=new Dictionary<int,Marker[]>();
  public static Marker[] For(int command){if(cache.TryGetValue(command,out var markers))return markers;markers=Build(command);if(cache.Count<256)cache.Add(command,markers);return markers;}
  static Marker[] Build(int command){switch(command){
   case 3000:return new[]{new Marker("effort",0.400000024),new Marker("sword_air",0.600000024)};
   case 3001:return new[]{new Marker("effort",0.533333349),new Marker("sword_air",0.733333349)};
   case 3002:return new[]{new Marker("effort",0.666666675),new Marker("sword_air",0.866666675)};
   case 3003:return new[]{new Marker("effort",0.666666675),new Marker("shield_move",0.866666675)};
   case 3004:return new[]{new Marker("effort",0.766666639),new Marker("sword_air",0.966666639)};
   case 3005:return new[]{new Marker("effort",1.699999976),new Marker("sword_air",1.899999976)};
   case 3006:return new[]{new Marker("effort",1.266666698),new Marker("sword_air",1.466666698)};
   case 3007:return new[]{new Marker("effort",1.133333373),new Marker("sword_air",1.333333373)};
   case 3008:return new[]{new Marker("effort",1.133333373),new Marker("sword_air",1.333333373)};
   case 3009:return new[]{new Marker("effort",0.766666639),new Marker("sword_air",0.966666639)};
   case 3010:return new[]{new Marker("effort",1.300000000),new Marker("sword_air",1.500000000)};
   case 3011:return new[]{new Marker("effort",0.833333302),new Marker("sword_air",1.033333302)};
   case 3030:return new[]{new Marker("effort",1.200000048),new Marker("shield_move",1.333333373)};
   case 3034:return new[]{new Marker("effort",1.166666627),new Marker("sword_air",1.299999952)};
   case 3022:return new[]{new Marker("effort",1.366666722),new Marker("sword_air",1.566666722)};
   case 3023:return new[]{new Marker("effort",0.533333349),new Marker("sword_air",0.733333349)};
   case 1100:return new[]{new Marker("shield_raise",0.100000000)};
   case 1101:return new[]{new Marker("shield_lower",0.000000000)};
   case 8140:return new[]{new Marker("stagger",0.000000000)};
   case 8500:return new[]{new Marker("parried",0.000000000)};
   case 8220:case 8221:return new[]{new Marker("armor_move",0.000000000)};
   case 8300:return new[]{new Marker("stagger",0.000000000)};
   default:return Array.Empty<Marker>();
  }}
 }
}
