using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Audio;
using Object=UnityEngine.Object;

namespace BlackAbbey.ReliquaryKnight {
 public static class KnightAudioBank {
  public sealed class Cue {public string id,file,family,role,sha256;public float volume=1;public double seconds;[JsonIgnore]public AudioClip Clip;}
  sealed class Manifest {public string schema;public Cue[] cues;}
  public static readonly Dictionary<string,Cue> Cues=new Dictionary<string,Cue>(StringComparer.Ordinal);
  public static AudioMixerGroup Mixer;
  public static void Prepare(string folder){
   if(Cues.Count>0)return;
   try {
    var manifest=JsonConvert.DeserializeObject<Manifest>(File.ReadAllText(Path.Combine(folder,"bank.json")));
    if(manifest?.cues==null||manifest.cues.Length!=59)throw new InvalidDataException("Expected exact59-cue approved Knight audio bank");
    foreach(var c in manifest.cues){
     if(c==null||string.IsNullOrEmpty(c.id)||string.IsNullOrEmpty(c.file)||Path.GetFileName(c.file)!=c.file||!c.file.EndsWith(".wav",StringComparison.OrdinalIgnoreCase)||string.IsNullOrEmpty(c.family)||Cues.ContainsKey(c.id)||c.seconds<=0||c.seconds>12||c.volume<0||c.volume>1||c.sha256?.Length!=64||!new[]{"spoken","effort","equipment"}.Contains(c.role))throw new InvalidDataException("Invalid bounded Knight cue entry");
     c.Clip=Read(Path.Combine(folder,c.file),c.sha256);
     if(Math.Abs(c.Clip.length-c.seconds)>.002){Object.Destroy(c.Clip);throw new InvalidDataException("Knight cue length differs: "+c.id);}
     Cues.Add(c.id,c);
    }
   }catch{Shutdown();throw;}
  }
  static AudioClip Read(string path,string expected){
   var bytes=File.ReadAllBytes(path);if(bytes.Length<44||bytes.Length>1200000)throw new InvalidDataException("Knight WAV size");
   using(var sha=SHA256.Create())if(BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-","").ToLowerInvariant()!=expected)throw new InvalidDataException("Knight audio checksum differs: "+Path.GetFileName(path));
   using(var r=new BinaryReader(new MemoryStream(bytes))){
    if(new string(r.ReadChars(4))!="RIFF"||r.ReadInt32()!=bytes.Length-8||new string(r.ReadChars(4))!="WAVE")throw new InvalidDataException("Knight WAV extent");
    int format=0,channels=0,rate=0,bits=0,block=0;byte[] data=null;
    while(r.BaseStream.Position+8<=bytes.Length){var id=new string(r.ReadChars(4));int size=r.ReadInt32();long end=r.BaseStream.Position+size;if(size<0||end>bytes.Length)throw new InvalidDataException("Knight WAV chunk extent");
     if(id=="fmt "){if(size<16)throw new InvalidDataException("Knight WAV fmt");format=r.ReadInt16();channels=r.ReadInt16();rate=r.ReadInt32();r.ReadInt32();block=r.ReadInt16();bits=r.ReadInt16();}
     else if(id=="data"){if(data!=null)throw new InvalidDataException("Duplicate Knight WAV data");data=r.ReadBytes(size);}r.BaseStream.Position=end+(size&1);
    }
    if(format!=1||channels!=1||rate!=48000||bits!=16||block!=2||data==null||data.Length==0||data.Length%2!=0)throw new InvalidDataException("Knight cue must be48k monoPCM16");
    var samples=new float[data.Length/2];for(int i=0;i<samples.Length;i++)samples[i]=BitConverter.ToInt16(data,i*2)/32768f;
    var clip=AudioClip.Create("RK_"+Path.GetFileNameWithoutExtension(path),samples.Length,1,rate,false);if(!clip.SetData(samples,0)){Object.Destroy(clip);throw new InvalidDataException("Knight PCM upload failed");}return clip;
   }
  }
  public static AudioSource Source(Transform parent,string name){var go=new GameObject(name);go.transform.SetParent(parent,false);var s=go.AddComponent<AudioSource>();s.playOnAwake=false;s.loop=false;s.spatialBlend=1;s.dopplerLevel=0;s.pitch=1;s.rolloffMode=AudioRolloffMode.Logarithmic;s.minDistance=1.5f;s.maxDistance=18;s.outputAudioMixerGroup=Mixer;s.priority=100;return s;}
  public static Cue[] Find(string family,string role=null)=>Cues.Values.Where(c=>c.family==family&&(role==null||c.role==role)).OrderBy(c=>c.id,StringComparer.Ordinal).ToArray();
  public static void Shutdown(){foreach(var c in Cues.Values)if(c.Clip)Object.Destroy(c.Clip);Cues.Clear();Mixer=null;}
 }
}
