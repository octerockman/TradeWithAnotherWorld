using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbey.ReliquaryKnight
{
    // Presentation receipts only: no attack, HitData, damage or network ownership
    // field is changed. The victim's native block/HP result admits an impact.
    public sealed class KnightAudioContact : MonoBehaviour
    {
        const string ReceiptRpc = "RK_AudioContactV1";
        const double ReceiptLifetime = 1.5;
        sealed class Submission
        {
            public ZDOID Victim;
            public Vector3 Point;
            public long At;
            public int Serial, Command;
            public bool Delivered;
        }
        readonly List<Submission> pending = new List<Submission>();
        readonly Dictionary<string, long> receipts = new Dictionary<string, long>();
        ZNetView view;
        Humanoid human;
        KnightAudio audio;
        KnightActor actor;
        bool bound, wasOwner;
        long owner, enabledAt;
        int accepted, rejected;
        static long confirmation;
        static bool reportedFailure;
        static long Now => ZNet.instance ? ZNet.instance.GetTime().Ticks : DateTime.UtcNow.Ticks;
        bool Owner => bound && isActiveAndEnabled && view && view.IsValid() && view.IsOwner()
            && wasOwner && view.GetZDO().GetOwner() == owner && human && !human.IsDead() && human.GetHealth() > 0;
        static bool Finite(Vector3 v) => !float.IsNaN(v.x) && !float.IsInfinity(v.x)
            && !float.IsNaN(v.y) && !float.IsInfinity(v.y) && !float.IsNaN(v.z) && !float.IsInfinity(v.z);

        internal static void Safe(Action callback)
        {
            try { callback(); }
            catch (Exception e)
            {
                if (reportedFailure) return;
                reportedFailure = true;
                KnightActor.Log?.Invoke("RK_AUDIO_CONTACT_CALLBACK_FAILED " + e.GetBaseException().Message);
            }
        }
        void Awake()
        {
            view = GetComponent<ZNetView>(); human = GetComponent<Humanoid>();
            audio = GetComponent<KnightAudio>(); actor = GetComponent<KnightActor>();
        }
        void Start() { Safe(Bind); }
        void Bind()
        {
            if (bound || !view || !view.IsValid() || !human || !audio || !actor) return;
            view.Register<ZPackage>(ReceiptRpc, Receive);
            bound = true; ResetOwner();
        }
        void ResetOwner()
        {
            pending.Clear(); receipts.Clear(); enabledAt = Now;
            owner = view && view.IsValid() ? view.GetZDO().GetOwner() : 0;
            wasOwner = view && view.IsValid() && view.IsOwner();
        }
        void Update()
        {
            Safe(() =>
            {
                if (!bound) { Bind(); return; }
                if (!view || !view.IsValid()) { pending.Clear(); receipts.Clear(); return; }
                if (owner != view.GetZDO().GetOwner() || wasOwner != view.IsOwner()) ResetOwner();
            });
        }
        void Prune(long now)
        {
            pending.RemoveAll(p => now < p.At || (now - p.At) / (double)TimeSpan.TicksPerSecond > ReceiptLifetime);
            var expired = new List<string>();
            foreach (var p in receipts)
                if (now < p.Value || (now - p.Value) / (double)TimeSpan.TicksPerSecond > 8) expired.Add(p.Key);
            foreach (string id in expired) receipts.Remove(id);
        }

        // Called immediately before the existing native Damage submission.
        public static void RecordSubmission(Character attacker, Character victim, Vector3 point)
        {
            Safe(() =>
            {
                var contact = attacker ? attacker.GetComponent<KnightAudioContact>() : null;
                if (!contact || !contact.Owner || !victim || !Finite(point)) return;
                var targetView = victim.GetComponent<ZNetView>();
                if (!targetView || !targetView.IsValid()) return;
                long now = Now; contact.Prune(now);
                if (contact.pending.Count >= 128) contact.pending.RemoveAt(0);
                contact.pending.Add(new Submission
                {
                    Victim = targetView.GetZDO().m_uid, Point = point, At = now,
                    Serial = contact.actor.Serial, Command = contact.actor.CommandId
                });
            });
        }

        // 0 = real physical HP loss, 1 = native successful block, 2 = player
        // perfect block already carrying its own native success sound.
        internal static void Confirm(Character victim, HitData hit, Character attacker, int kind)
        {
            if (!victim || hit == null || !attacker || !Finite(hit.m_point) || kind < 0 || kind > 2) return;
            var victimView = victim.GetComponent<ZNetView>();
            if (!victimView || !victimView.IsValid() || !victimView.IsOwner()) return;
            var contact = attacker.GetComponent<KnightAudioContact>();
            if (!contact || !contact.bound || !contact.view || !contact.view.IsValid()) return;
            long now = Now;
            string receipt = victimView.GetZDO().m_uid + ":" + now + ":" + (++confirmation);
            if (contact.Owner)
            {
                contact.Accept(victimView.GetZDO().m_uid, hit.m_point, now, receipt, kind);
                return;
            }
            var p = new ZPackage();
            p.Write(victimView.GetZDO().m_uid); p.Write(hit.m_point); p.Write(now); p.Write(receipt); p.Write(kind);
            // Default target is the actor's current authoritative owner.
            contact.view.InvokeRPC(ReceiptRpc, p);
        }
        void Receive(long sender, ZPackage p)
        {
            Safe(() =>
            {
                if (!Owner || sender == 0 || p == null) return;
                ZDOID target = p.ReadZDOID(); Vector3 point = p.ReadVector3();
                long at = p.ReadLong(); string receipt = p.ReadString(); int kind = p.ReadInt();
                if (receipt == null || receipt.Length > 160 || !Finite(point) || kind < 0 || kind > 2) return;
                var targetObject = ZNetScene.instance ? ZNetScene.instance.FindInstance(target) : null;
                var targetView = targetObject ? targetObject.GetComponent<ZNetView>() : null;
                if (!targetView || !targetView.IsValid() || targetView.GetZDO().GetOwner() != sender
                    || !targetObject.GetComponent<Character>()) { rejected++; return; }
                Accept(target, point, at, sender + ":" + receipt, kind);
            });
        }
        void Accept(ZDOID target, Vector3 point, long at, string receipt, int kind)
        {
            if (!Owner || !Finite(point) || string.IsNullOrEmpty(receipt) || kind < 0 || kind > 2) return;
            long now = Now; Prune(now);
            if (at < enabledAt || at > now + TimeSpan.TicksPerSecond / 4
                || (now - at) / (double)TimeSpan.TicksPerSecond > ReceiptLifetime
                || (point - transform.position).sqrMagnitude > 144 || receipts.ContainsKey(receipt)) { rejected++; return; }
            Submission closest = null; long distance = long.MaxValue;
            foreach (var entry in pending)
            {
                if (entry.Victim != target || (entry.Point - point).sqrMagnitude > .0004f
                    || entry.At > at + TimeSpan.TicksPerSecond / 4
                    || (at - entry.At) / (double)TimeSpan.TicksPerSecond > ReceiptLifetime) continue;
                long d = Math.Abs(at - entry.At);
                if (d < distance) { closest = entry; distance = d; }
            }
            if (closest == null || closest.Delivered || receipts.Count >= 256) { rejected++; return; }
            receipts.Add(receipt, now); closest.Delivered = true; accepted++;
            // Consume a parried contact without a second success jingle. The
            // source reaction observer still supplies the Knight's armor recoil.
            if (kind == 2) return;
            audio.Group(KnightAttackRepertoire.UsesShield(closest.Command) ? "shield_bash" : kind == 1 ? "sword_metal" : "sword_body", point);
        }
        void OnDisable() { pending.Clear(); receipts.Clear(); enabledAt = Now; }
        void OnEnable() { if (bound) ResetOwner(); }
        void OnDestroy() { if (bound && view) view.Unregister(ReceiptRpc); bound = false; }
        public string Diagnostics() => "contactsAccepted=" + accepted + " contactsRejected=" + rejected + " pending=" + pending.Count;
    }

    public static class KnightAudioContactHooks
    {
        sealed class BlockScope
        {
            public Character Attacker;
            public Humanoid Defender;
            public HitData Hit;
            public bool Physical, Parried;
            public BlockScope Previous;
        }
        [ThreadStatic] static BlockScope currentBlock;

        [HarmonyPatch]
        static class OwnNativeFootsteps
        {
            static IEnumerable<MethodBase> TargetMethods() => AccessTools.GetDeclaredMethods(typeof(FootStep)).Where(m => m.Name == "OnFoot");
            static bool Prefix(FootStep __instance) => !__instance || !__instance.GetComponentInParent<KnightAudio>();
        }
        [HarmonyPatch(typeof(Character), nameof(Character.ApplyDamage))]
        static class Damage
        {
            static void Prefix(Character __instance, out float __state)
            {
                __state = 0; try { if (__instance) __state = __instance.GetHealth(); } catch { }
            }
            static void Postfix(Character __instance, HitData __0, float __state)
            {
                KnightAudioContact.Safe(() =>
                {
                    if (!__instance || __0 == null || __state <= 0 || __instance.GetHealth() >= __state) return;
                    __instance.GetComponent<KnightAudio>()?.Damage(__state, __0);
                    if (!__0.m_ranged && __0.GetTotalPhysicalDamage() > 0)
                        KnightAudioContact.Confirm(__instance, __0, __0.GetAttacker(), 0);
                });
            }
        }
        [HarmonyPatch(typeof(Humanoid), "BlockAttack")]
        static class Block
        {
            static void Prefix(Humanoid __instance, HitData __0, Character __1, out BlockScope __state)
            {
                __state = new BlockScope { Defender = __instance, Attacker = __1, Hit = __0,
                    Physical = __0 != null && __0.GetTotalPhysicalDamage() > 0, Previous = currentBlock };
                currentBlock = __state;
            }
            static void Postfix(Humanoid __instance, bool __result, BlockScope __state)
            {
                if (__state != null) currentBlock = __state.Previous;
                KnightAudioContact.Safe(() =>
                {
                    if (!__result || __state == null || !__state.Physical || !__instance) return;
                    __instance.GetComponent<KnightAudio>()?.Blocked(__state.Hit);
                    // Arrows can produce a genuine shield block as well; the
                    // attacker weapon receipt remains source-melee-only.
                    if (__state.Hit.m_ranged) return;
                    KnightAudioContact.Confirm(__instance, __state.Hit, __state.Attacker,
                        __state.Parried && __instance is Player ? 2 : 1);
                });
            }
            static Exception Finalizer(Exception __exception, BlockScope __state)
            {
                if (__state != null) currentBlock = __state.Previous;
                return __exception;
            }
        }
        [HarmonyPatch(typeof(Character), nameof(Character.Stagger))]
        static class TimedBlockCause
        {
            static void Prefix(Character __instance)
            {
                // In installed BlockAttack this call targets the attacker only
                // after the native perfect-block branch survives its checks.
                if (currentBlock != null && currentBlock.Attacker == __instance) currentBlock.Parried = true;
            }
        }
        [HarmonyPatch(typeof(Character), nameof(Character.OnDeath))]
        static class Death
        {
            [HarmonyPriority(Priority.First)]
            static void Prefix(Character __instance)
            {
                KnightAudioContact.Safe(() => { if (__instance) __instance.GetComponent<KnightAudio>()?.NativeDeath(); });
            }
        }
    }
}
