namespace BlackAbbey.ReliquaryKnight {
 public enum KnightContextMode { None=0,GuardRaise=1,GuardLower=2,Parried=4 }
 public static class KnightContextPolicy {
  public static bool GuardTransition(bool desired,bool displayed,bool committed,bool active)=>desired!=displayed&&!committed&&!active;
  public static bool CounterCanExit(KnightContextMode mode)=>mode==KnightContextMode.GuardRaise||mode==KnightContextMode.GuardLower;
  public static bool IsGuard(KnightContextMode mode)=>mode==KnightContextMode.GuardRaise||mode==KnightContextMode.GuardLower;
  public static int Command(KnightContextMode mode)=>mode==KnightContextMode.GuardRaise?1100:mode==KnightContextMode.GuardLower?1101:mode==KnightContextMode.Parried?8500:-1;
  public static bool Complete(KnightContextMode mode,double elapsed,double duration)=>mode!=KnightContextMode.None&&elapsed>=duration;
  public static bool CompleteWithMove(KnightContextMode mode,double elapsed,double duration,bool pendingMove)=>Complete(mode,elapsed,duration)
   ||pendingMove&&IsGuard(mode)&&KnightTransitionPolicy.Open(Command(mode),elapsed,duration,KnightTransitionChannel.Move);
  public static bool Valid(int mode)=>mode>=0&&mode<=2||mode==(int)KnightContextMode.Parried;
 }
}
