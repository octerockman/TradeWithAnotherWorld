using System;
using System.Collections.Generic;
namespace BlackAbbey.ReliquaryKnight {
 public enum KnightTransitionChannel { Move=78,SafetyStep=79,QueuedAttack=86 }
 public static class KnightTransitionPolicy {
  public static bool Open(int command,double elapsed,double duration,KnightTransitionChannel channel){
   if(!Finite(elapsed)||!Finite(duration)||elapsed<0||duration<=0)return false;
   if(elapsed>=duration)return true;
   Dictionary<int,EventWindow[]> table=channel==KnightTransitionChannel.Move?KnightTransitionData.Move:channel==KnightTransitionChannel.SafetyStep?KnightTransitionData.SafetyStep:channel==KnightTransitionChannel.QueuedAttack?KnightTransitionData.QueuedAttack:null;
   EventWindow[] windows;if(table==null||!table.TryGetValue(command,out windows))return false;
   foreach(var w in windows)if(elapsed>=w.Start&&elapsed<Math.Min(w.End,duration))return true;
   return false;
  }
  // A request to move never cuts through an active physical hit window. The
  // movement channel is independent of the earlier combo-attack channel23.
  public static bool RecoveryMove(ClipSpec clip,double elapsed){
   if(clip==null||!Open(clip.CommandId,elapsed,clip.Duration,KnightTransitionChannel.Move))return false;
   if(elapsed>=clip.Duration)return true;
   foreach(var w in clip.AttackWindows)if(elapsed>=w.Start&&elapsed<w.End)return false;
   return true;
  }
  static bool Finite(double n)=>!double.IsNaN(n)&&!double.IsInfinity(n);
 }
}
