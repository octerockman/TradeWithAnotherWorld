using UnityEngine;
namespace BlackAbbey.ReliquaryKnight {
 // Runtime-only size revision. The accepted native, rest rig, bindposes, gear
 // and exact source motion samples remain frozen at their original scale.
 public static class KnightScaleProfile {
  public const float BodyMultiplier=1.5f;
  public const float NativeBodyHeight=1.8f, NativeBodyRadius=.35f;
  public static float SourceToWorld(float sourceScale)=>sourceScale*BodyMultiplier;
  public static void Apply(GameObject actor,ZNetView view){
   Vector3 size=Vector3.one*BodyMultiplier;
   view.m_syncInitialScale=true;
   var sync=actor.GetComponent<ZSyncTransform>();if(sync)sync.m_syncScale=true;
   // Exact assignment after native/ZDO Awake also migrates pre-update actors.
   // Multiplication here would compound at ownership changes or reloads.
   view.SetLocalScale(size);
   if(view.IsValid()&&view.IsOwner())view.GetZDO().Set(ZDOVars.s_scaleHash,size);
  }
 }
}
