using System;
using UnityEngine;
namespace BlackAbbey.ReliquaryKnight {
 public sealed partial class KnightActor {
  KnightContextMode contextMode;bool guardDisplayed,deathPresented,guardPendingMove;
  const string DeathRpc="RK_DeathPresentationV3";
  public bool ContextActive=>contextMode!=KnightContextMode.None;
  public bool GuardPoseRequested=>KnightContextPolicy.IsGuard(contextMode)||contextMode==KnightContextMode.None&&guardDisplayed;
  bool BeginGuardContext(Decision next){
   if(next==null||!KnightContextPolicy.GuardTransition(next.GuardRequested,guardDisplayed,next.Committed,ContextActive))return false;
   guardPendingMove=next.Kind==DecisionKind.Move;
   BeginContext(next.GuardRequested?KnightContextMode.GuardRaise:KnightContextMode.GuardLower);return true;
  }
  public void ReleaseGuardTransitionForCounter(){
   if(!Owner||!ready||!KnightContextPolicy.CounterCanExit(contextMode))return;
   contextMode=KnightContextMode.None;guardDisplayed=true;guardPendingMove=false;sourceControl=false;decision=null;serial++;command=-1;restored=true;motorAt=Elapsed;Publish();
  }
  internal void BeginParriedPresentation(){
   if(!Owner||!ready||deathPresented||!human||human.IsDead()||!human.IsStaggering()||contextMode==KnightContextMode.Parried)return;
   guardDisplayed=false;BeginContext(KnightContextMode.Parried);
  }
  void BeginContext(KnightContextMode mode){
   int cmd=KnightContextPolicy.Command(mode);ClipSpec spec;if(!KnightSourceData.ByCommand.TryGetValue(cmd,out spec)||!Bank.Has(spec.ClipId))throw new InvalidOperationException("Unavailable source context "+cmd);
   contextMode=mode;decision=null;sourceControl=KnightContextPolicy.IsGuard(mode);guardPendingMove=sourceControl&&guardPendingMove;restored=false;
   StopMovement();StartClip(spec.ClipId,cmd,false,false);Publish();
   Log?.Invoke("RK_CONTEXT_START "+mode+" command="+cmd+" clip="+spec.ClipId+" duration="+spec.Duration);
  }
  void TickContext(){
   if(!Owner||!ContextActive||clip==null||!human||human.IsDead())return;
   // The native stagger tag may end before the complete source recovery pose.
   // Keep native AI move intent from walking through that remaining recovery.
   if(contextMode==KnightContextMode.Parried)StopMovement();
   if(!KnightContextPolicy.CompleteWithMove(contextMode,Elapsed,clip.duration,guardPendingMove))return;
   if(contextMode==KnightContextMode.GuardRaise)guardDisplayed=true;
   else if(contextMode==KnightContextMode.GuardLower)guardDisplayed=false;
   contextMode=KnightContextMode.None;guardPendingMove=false;sourceControl=false;decision=null;serial++;command=-1;restored=true;motorAt=Elapsed;Publish();
  }
  void InitializeDeathRpc(){view.Register<string>(DeathRpc,ReceiveDeathPresentation);}
  public void BeginDeathPresentation(){
   if(deathPresented||!ready||!rig)return;
   if(Owner&&ZNet.instance){string selected=KnightDeathPresentation.SelectSpaceCompatibleClip(rig,Bank,SelectDeathClip());string follow=KnightDeathFollowOn.Choose(selected,view.GetZDO().m_uid.ToString().GetStableHashCode(),view.GetZDO().GetLong("rk_hp_zero_v1",ZNet.instance.GetTime().Ticks))?KnightDeathFollowOn.ClipId:"";string message=ZNet.instance.GetTime().Ticks.ToString(System.Globalization.CultureInfo.InvariantCulture)+"|"+selected+"|"+follow;view.GetZDO().Set("rk_death_v3",message);PresentDeath(selected,follow);view.InvokeRPC(ZNetView.Everybody,DeathRpc,message);}
   else if(view&&view.IsValid()){string message=view.GetZDO().GetString("rk_death_v3","");if(!string.IsNullOrEmpty(message))ReceiveDeathPresentation(view.GetZDO().GetOwner(),message);}
  }
  void ReceiveDeathPresentation(long sender,string message){
   if(deathPresented||!view||!view.IsValid()||sender==0||sender!=view.GetZDO().GetOwner())return;
   if(string.IsNullOrEmpty(message)||message.Length>80)return;
   string[] parts=message.Split('|');if(parts.Length>3)return;string stamp=parts[0],selected=parts.Length<2?KnightDeathClock.DefaultClip:parts[1],follow=parts.Length<3?"":parts[2];
   long ticks;if(!long.TryParse(stamp,out ticks)||!KnightDeathVariantPolicy.IsSupported(selected)||follow.Length>0&&!KnightDeathFollowOn.ValidPair(selected,follow)||!ZNet.instance||Math.Abs((ZNet.instance.GetTime().Ticks-ticks)/(double)TimeSpan.TicksPerSecond)>15)return;
   PresentDeath(selected,follow);
  }
  void PresentDeath(string selected,string follow){
   if(deathPresented||!rig)return;deathPresented=true;contextMode=KnightContextMode.None;sourceControl=false;serial++;decision=null;
   // Clone the complete displayed source pose before hiding the network actor.
   var corpse=KnightDeathPresentation.Create(rig,Bank,selected,follow);
   if(corpse)GetComponent<KnightAudio>()?.AttachDeathAnchor(corpse.transform);
   foreach(var renderer in rig.GetComponentsInChildren<Renderer>(true))renderer.enabled=false;
  }
  void OnDestroy(){if(view)view.Unregister(DeathRpc);}
 }
}
