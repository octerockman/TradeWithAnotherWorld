using System;
namespace BlackAbbey.ReliquaryKnight {
 public readonly struct KnightMovementChoice {
  public readonly string ClipId;public readonly int Command;public readonly bool Loop,IsTurn;public readonly double NominalDegrees;
  public KnightMovementChoice(int command,bool loop,bool turn=false,double nominal=0){Command=command;ClipId="a000_"+command.ToString("D6",System.Globalization.CultureInfo.InvariantCulture);Loop=loop;IsTurn=turn;NominalDegrees=nominal;}
 }
 // Resolves the actual source move/turn tables. This owns no AI weights,
 // guard odds, pose clock, yaw, physical travel or damage admission.
 public static class KnightMovementRepertoire {
  public const double ActualTravelThreshold=.05;
  static readonly int[] GuardTurns={2,0,1},BattleTurns={0,1,2},DefaultTurns={1,0,2};
  static bool Finite(double n)=>!double.IsNaN(n)&&!double.IsInfinity(n);
  static bool Pick(int command,bool loop,bool turn,double nominal,Func<string,bool> has,out KnightMovementChoice choice){
   choice=new KnightMovementChoice(command,loop,turn,nominal);return has!=null&&has(choice.ClipId);
  }
  static bool Idle(bool guard,bool combat,Func<string,bool> has,out KnightMovementChoice choice){
   if(guard&&Pick(30,true,false,0,has,out choice))return true;
   if(Pick(combat?20:0,true,false,0,has,out choice))return true;
   return Pick(combat?0:20,true,false,0,has,out choice);
  }
  public static bool TryResolve(MovementKind movement,bool run,bool guardRequested,bool inCombat,double facingDegrees,Func<string,bool> has,out KnightMovementChoice choice){
   choice=default;if(has==null||!Finite(facingDegrees))return false;
   if(movement==MovementKind.None)return Idle(guardRequested,inCombat,has,out choice);
   if(movement==MovementKind.Turn){
    double angle=facingDegrees%360;if(angle>180)angle-=360;if(angle< -180)angle+=360;double size=Math.Abs(angle);
    if(size<45)return Idle(guardRequested,inCombat,has,out choice);
    // This supplied bank has90/180degree pivots only. CommonHKS falls
    // back from absent45degree variants to the corresponding90degree pivot.
    int direction=size<135?(angle<0?0:1):(angle<0?2:3);double nominal=direction>=2?180:90;
    var styles=guardRequested?GuardTurns:inCombat?BattleTurns:DefaultTurns;
    foreach(int style in styles)if(Pick(5000+style*10+direction,false,true,nominal,has,out choice))return true;
    return false;
   }
   if(movement==MovementKind.Approach){
    if(guardRequested){
     if(run&&Pick(2130,true,false,0,has,out choice))return true;
     if(Pick(2030,true,false,0,has,out choice))return true;
     if(run&&Pick(2100,true,false,0,has,out choice))return true;
     return Pick(2000,true,false,0,has,out choice);
    }
    // The default run2310 is absent in this bank; source fallback uses
    // battle run before default walk, without inventing a replacement clip.
    if(run&&Pick(2100,true,false,0,has,out choice))return true;
    if(!inCombat&&Pick(2300,true,false,0,has,out choice))return true;
    return Pick(2000,true,false,0,has,out choice);
   }
   int offset=movement==MovementKind.Retreat?1:movement==MovementKind.CircleLeft?2:movement==MovementKind.CircleRight?3:-1;
   if(offset<0)return false;
   if(guardRequested&&Pick(2030+offset,true,false,0,has,out choice))return true;
   return Pick(2000+offset,true,false,0,has,out choice);
  }
  public static bool TryResolveActualTravel(double localRight,double localForward,bool running,bool guardRequested,bool inCombat,Func<string,bool> has,out KnightMovementChoice choice){
   choice=default;if(!Finite(localRight)||!Finite(localForward))return false;
   double side=Math.Abs(localRight),forward=Math.Abs(localForward);
   MovementKind move=side*side+forward*forward<ActualTravelThreshold*ActualTravelThreshold?MovementKind.None:
    forward>=side?(localForward>=0?MovementKind.Approach:MovementKind.Retreat):(localRight<0?MovementKind.CircleLeft:MovementKind.CircleRight);
   return TryResolve(move,running&&move==MovementKind.Approach,guardRequested,inCombat,0,has,out choice);
  }
 }
}
