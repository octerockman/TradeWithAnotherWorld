using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using Newtonsoft.Json;
using UnityEngine;
namespace BlackAbbey.ReliquaryKnight {
 public sealed class MotionDescriptor {public string id,file,sha256;public int bytes,uncompressedBytes,frameCount;public double duration;}
 public sealed class MotionManifest {public string schema,sourceManifestSha256,ownSkinSha256;public string[] boneNames;public int[] parentIndices;public float scale;public MotionDescriptor[] clips;}
 public sealed class MotionFrame {public float[] positions,rotations,scales;}
 public sealed class MotionReference {public double duration;public float[][] samples;}
 public sealed class KnightClip {
  public string id;public double duration;public double[] times;public MotionFrame[] frames;public MotionReference referenceFrame;
  public void Indices(double time,out int lo,out int hi,out float blend){time=Math.Max(0,Math.Min(duration,time));int a=Array.BinarySearch(times,time);lo=a>=0?a:Math.Max(0,~a-1);hi=Math.Min(lo+1,times.Length-1);blend=hi==lo?0:(float)((time-times[lo])/(times[hi]-times[lo]));}
  public void Pose(int bone,double time,out Vector3 p,out Quaternion q,out Vector3 s){Indices(time,out int l,out int h,out float f);var a=frames[l];var b=frames[h];int k=bone*3,j=bone*4;p=Vector3.Lerp(V(a.positions,k),V(b.positions,k),f);q=Quaternion.Slerp(Q(a.rotations,j),Q(b.rotations,j),f);s=Vector3.Lerp(V(a.scales,k),V(b.scales,k),f);}
  public Matrix4x4 BoneMatrix(int bone,double time,int[] parents){var chain=new List<int>();for(int i=bone;i>=0;i=parents[i])chain.Add(i);var m=Matrix4x4.identity;for(int i=chain.Count-1;i>=0;i--){Pose(chain[i],time,out var p,out var q,out var s);m=m*Matrix4x4.TRS(p,q,s);}return m;}
  public Vector4 Reference(double at){var r=referenceFrame;if(r?.samples==null||r.samples.Length==0)return Vector4.zero;float t=r.duration<=0?0:(float)(Math.Max(0,Math.Min(r.duration,at))/r.duration*(r.samples.Length-1));int a=(int)t,b=Math.Min(a+1,r.samples.Length-1);var x=r.samples[a];var y=r.samples[b];float f=t-a;return new Vector4(-Mathf.Lerp(x[0],y[0],f),Mathf.Lerp(x[1],y[1],f),-Mathf.Lerp(x[2],y[2],f),Mathf.Lerp(x[3],y[3],f));}
  static Vector3 V(float[] a,int k)=>new Vector3(a[k],a[k+1],a[k+2]);
  static Quaternion Q(float[] a,int k)=>new Quaternion(a[k],a[k+1],a[k+2],a[k+3]).normalized;
 }
 public sealed class KnightMotionBank {
  public MotionManifest Manifest;public readonly Dictionary<string,MotionDescriptor> Descriptors=new Dictionary<string,MotionDescriptor>();
  readonly Dictionary<string,KnightClip> cache=new Dictionary<string,KnightClip>();readonly LinkedList<string> lru=new LinkedList<string>();string folder;long cacheBytes;
  public static string Hash(string path){using(var h=SHA256.Create())using(var f=File.OpenRead(path))return string.Concat(h.ComputeHash(f).Select(b=>b.ToString("x2")));}
  public static KnightMotionBank Read(string folder){var b=new KnightMotionBank{folder=folder};b.Manifest=JsonConvert.DeserializeObject<MotionManifest>(File.ReadAllText(Path.Combine(folder,"motion.json")));if(b.Manifest.schema!="black-abbey.knight-runtime-motion.v1"||b.Manifest.boneNames?.Length!=138||b.Manifest.clips?.Length!=225)throw new InvalidDataException("Unexpected source motion contract");foreach(var d in b.Manifest.clips){if(d.frameCount<2||d.duration<=0||d.uncompressedBytes>12*1024*1024||d.bytes<1||Path.GetFileName(d.file)!=d.file)throw new InvalidDataException("Motion bounds invalid");b.Descriptors.Add(d.id,d);}return b;}
  public bool Has(string id)=>id!=null&&Descriptors.ContainsKey(id);
  public KnightClip Get(string id){if(cache.TryGetValue(id,out var c)){lru.Remove(id);lru.AddLast(id);return c;}var d=Descriptors[id];string path=Path.Combine(folder,d.file);if(new FileInfo(path).Length!=d.bytes||Hash(path)!=d.sha256)throw new InvalidDataException("Motion integrity: "+id);using(var f=File.OpenRead(path))using(var gz=new GZipStream(f,CompressionMode.Decompress))using(var sr=new StreamReader(gz))using(var jr=new JsonTextReader(sr){MaxDepth=20})c=new JsonSerializer().Deserialize<KnightClip>(jr);if(c.id!=id||c.frames.Length!=d.frameCount||c.times.Length!=d.frameCount||Math.Abs(c.duration-d.duration)>.00001)throw new InvalidDataException("Motion mismatch");foreach(var frame in c.frames)if(frame.positions.Length!=414||frame.rotations.Length!=552||frame.scales.Length!=414)throw new InvalidDataException("Motion bone count");while(cache.Count>=4||cacheBytes+d.uncompressedBytes>32*1024*1024){if(lru.First==null)break;string old=lru.First.Value;cacheBytes-=Descriptors[old].uncompressedBytes;cache.Remove(old);lru.RemoveFirst();}cache[id]=c;lru.AddLast(id);cacheBytes+=d.uncompressedBytes;return c;}
 }
}
