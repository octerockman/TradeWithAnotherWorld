using System;
namespace BlackAbbey.ReliquaryKnight {
 // Valheim adaptation of the six supplied source death roles. The imported
 // HKS receives GetDeathType from its original engine; that classifier is not
 // present in the supplied scripts and is not claimed to run here. Jesse's
 // later review also admits10010/10030 as ordinary collapse variations, not
 // exclusively their historical FIRE/WEAK role labels.
 public static class KnightDeathCausePolicy {
  public const string Normal="a000_010000",Fire="a000_010010",Weak="a000_010030",Blast="a000_010040",Fling="a000_010050",Upper="a000_010060";
  public const double DominantShare=.5,WeakMaximumDamage=8,WeakMaximumPush=5;
  public const double BlastMinimumDamage=50,BlastMinimumPush=20,FlingMinimumPush=40;
  public const double UpperMinimumPush=5,UpperDirection=.5,LaunchVelocity=2,LaunchMinimumPush=20;
  public struct Evidence {
   public double Total,FireDamage,PoisonDamage,SpiritDamage,BluntDamage,Push,DirectionY,HorizontalDirection,VelocityY;
   public bool FireCause,DebilitatingCause,CrushingImpact;
  }
  public static bool ValidClip(string id)=>id==Normal||id==Fire||id==Weak||id==Blast||id==Fling||id==Upper;
  public static bool ShouldRecord(bool authority,bool recorded,double before,double after,bool scopedHit)=>authority&&!recorded&&scopedHit&&Finite(before)&&Finite(after)&&before>0&&after<=0;
  public static string OrdinaryClip(int variant){switch((uint)variant%3){case 1:return Fire;case 2:return Weak;default:return Normal;}}
  public static int StableOrdinaryVariant(string networkIdentity,long fatalTicks){
   // Owner-only bounded entropy. No Random call or read-time reroll; the chosen
   // clip is then persisted and transmitted with the death presentation.
   unchecked {
    uint hash=2166136261;int length=Math.Min(96,networkIdentity?.Length??0);
    for(int i=0;i<length;i++)hash=(hash^networkIdentity[i])*16777619;
    ulong time=(ulong)fatalTicks;for(int i=0;i<8;i++)hash=(hash^(byte)(time>>(i*8)))*16777619;
    hash^=hash>>16;hash*=0x7feb352d;hash^=hash>>15;return (int)(hash%3);
   }
  }
  public static string Select(Evidence e,int ordinaryVariant){string cause=Select(e);return cause==Normal?OrdinaryClip(ordinaryVariant):cause;}
  public static string Select(Evidence e){
   if(!Finite(e.Total)||e.Total<=0||!Nonnegative(e.FireDamage)||!Nonnegative(e.PoisonDamage)||!Nonnegative(e.SpiritDamage)||!Nonnegative(e.BluntDamage)||!Nonnegative(e.Push)||!Finite(e.DirectionY)||!Finite(e.HorizontalDirection)||!Finite(e.VelocityY))return Normal;
   // A demonstrated launch wins over damage material. No added force is used.
   if(e.Push>=UpperMinimumPush&&e.DirectionY>=UpperDirection||e.Push>=LaunchMinimumPush&&e.VelocityY>=LaunchVelocity)return Upper;
   if(e.FireCause||e.FireDamage>=e.Total*DominantShare)return Fire;
   if(e.DebilitatingCause||e.PoisonDamage+e.SpiritDamage>=e.Total*DominantShare)return Weak;
   // Blast denotes a heavy crushing shock; Valheim has no universal explosion
   // bit on the native HitData accepted by Character.ApplyDamage.
   if(e.Total>=BlastMinimumDamage&&(e.CrushingImpact||e.BluntDamage>=e.Total*DominantShare&&e.Push>=BlastMinimumPush))return Blast;
   if(e.Push>=FlingMinimumPush&&e.HorizontalDirection>=.5)return Fling;
   if(e.Total<=WeakMaximumDamage&&e.Push<=WeakMaximumPush)return Weak;
   return Normal;
  }
  static bool Nonnegative(double x)=>Finite(x)&&x>=0;
  static bool Finite(double x)=>!double.IsNaN(x)&&!double.IsInfinity(x);
 }
}
