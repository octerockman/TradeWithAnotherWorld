using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using Newtonsoft.Json;
using UnityEngine;
namespace BlackAbbey.ReliquaryKnight {
 [DefaultExecutionOrder(1000)]
 public sealed partial class KnightActor:MonoBehaviour,IKnightCombatHost {
  public static KnightMotionBank Bank;public static KnightVisual Template;public static ItemDrop.ItemData SwordItem,ShieldItem;
  public static Action<string> Log;
  Humanoid human;MonsterAI awareness;ZNetView view;Rigidbody body;CapsuleCollider capsule;KnightNavigation nav;Transform rig;Transform[] bones;Func<string,bool> movementAvailable;
  KnightClip clip;bool loop,ready,sourceControl,restored;double start,previous,motorAt;int command=-1,serial;Character target;Decision decision;
  Quaternion travelHeading;float turnYawScale=1;string netPacket;float lastPoll;bool previousOwner;
  readonly RaycastHit[] obstacles=new RaycastHit[64];readonly RaycastHit[] floors=new RaycastHit[16];
  static readonly AccessTools.FieldRef<Character,float> NativeSlippage=AccessTools.FieldRefAccess<Character,float>("m_slippage");
  float travelRequested,travelAdmitted;int travelTicks,discardedTicks,floorStops,solidStops;string travelGate="not started";
  Vector3[] blendP;Quaternion[] blendQ;Vector3[] blendS;float blendStart;
  readonly KnightMovementProgress movementProgress=new KnightMovementProgress();
  Vector3 goalPreviousPosition,goalPreviousDirection;float goalPreviousYaw,goalRadius;Character goalTarget;
  public bool Ready=>ready;public int CommandId=>command;public int Serial=>serial;public string ClipId=>clip?.id??"";
  bool Owner=>view&&view.IsValid()&&view.IsOwner();
  double Elapsed=>Math.Max(0,Time.time-start);
  public double ClipTime=>clip==null?0:loop?Elapsed%clip.duration:Math.Min(clip.duration,Elapsed);
  public double PreviousClipTime=>previous;
  public bool PathReady=>nav&&nav.Ready;
  public bool CanMoveForward=>ready&&human&&human.IsOnGround()&&(PathReady||LocalGoalClear(transform.forward));
  public bool CanMoveBackward=>GoalClear(-transform.forward);
  public bool CanMoveLeft=>LocalGoalClear(-transform.right);
  public bool CanMoveRight=>LocalGoalClear(transform.right);
  public int MovementGoalId=>movementProgress.GoalId;
  public bool MovementBlocked=>movementProgress.Blocked;
  public bool MovementCompleted=>movementProgress.Complete;
  public double MovementProgress=>movementProgress.Progress;
  float EffectiveScale=>KnightScaleProfile.SourceToWorld(Bank.Manifest.scale);
  bool PhysicalPivot=>clip!=null&&!loop&&command>=5000&&command<=5025;
  public bool Controlled=>ready&&sourceControl&&Owner&&human&&!human.IsDead()&&!human.IsStaggering()&&!human.InDodge()&&human.CanMove();
  void Awake(){try{
   human=GetComponent<Humanoid>();awareness=GetComponent<MonsterAI>();view=GetComponent<ZNetView>();body=GetComponent<Rigidbody>();capsule=GetComponent<CapsuleCollider>();rig=transform.Find("RK_VisualRig");
   if(!human||!view||!body||!capsule||!rig||Bank==null||Template==null)throw new InvalidOperationException("Own Knight source/lifecycle missing");
   var named=rig.GetComponentsInChildren<Transform>(true).ToDictionary(t=>t.name,t=>t);bones=Bank.Manifest.boneNames.Select(n=>named[n]).ToArray();blendP=new Vector3[138];blendQ=new Quaternion[138];blendS=new Vector3[138];
   foreach(var a in GetComponentsInChildren<Animator>(true)){a.applyRootMotion=false;a.cullingMode=AnimatorCullingMode.AlwaysAnimate;}
   KnightScaleProfile.Apply(gameObject,view);
   movementAvailable=Bank.Has;nav=KnightNavigation.Attach(gameObject);ready=true;GetComponent<KnightCombat>().Configure(this,EffectiveScale);
   InitializeDeathRpc();StartClip("a000_000020",20,true,false);previousOwner=Owner;
   if(Owner)Publish();else ReadNetwork();
  }catch(Exception e){ready=false;Log?.Invoke("RK_ACTOR_FAILED "+e);enabled=false;}}
  public bool CanStart(ClipSpec spec){TickContext();if(!Ready||ContextActive||spec==null||spec.IsAdditive||!Bank.Has(spec.ClipId)||!human||human.IsDead()||human.IsStaggering()||!human.CanMove()||!human.IsOnGround())return false;
   if(PhysicalPivot&&!KnightTransitionPolicy.Open(command,Elapsed,clip.duration,spec.CommandId>=6000&&spec.CommandId<=6003?KnightTransitionChannel.SafetyStep:KnightTransitionChannel.QueuedAttack))return false;
   // Exact source commands without a recovered damaging socket never invent a hit.
   if(spec.AttackWindows.Length>0&&(KnightAttackRepertoire.UsesShield(spec.CommandId)?Template.Shield==null:Template.Sword==null))return false;
   // Route discovery is for approach travel, not a prerequisite to strike an
   // adjacent opponent. Every root-motion step still passes capsule/floor
   // admission. Evasive steps need the full source clearance before starting.
   return spec.CommandId==6000?GoalClear(transform.forward):spec.CommandId==6001?GoalClear(-transform.forward):spec.CommandId==6002?GoalClear(-transform.right):spec.CommandId==6003?GoalClear(transform.right):true;
  }
  public bool TryPlay(ClipSpec spec,bool repeat){if(!Owner||!CanStart(spec))return false;ResetMovementGoal();sourceControl=true;StartClip(spec.ClipId,spec.CommandId,repeat,true);restored=false;return true;}
  void StartClip(string id,int cmd,bool repeat,bool publish){if(!Bank.Has(id))throw new InvalidOperationException("Missing source motion "+id);Capture();clip=Bank.Get(id);command=cmd;loop=repeat;start=Time.time;previous=motorAt=0;turnYawScale=1;travelHeading=transform.rotation;serial++;blendStart=Time.time;if(publish)Publish();}
  void Capture(){if(bones==null)return;for(int i=0;i<bones.Length;i++){blendP[i]=bones[i].localPosition;blendQ[i]=bones[i].localRotation;blendS[i]=bones[i].localScale;}}
  public void ApplyDecision(Decision d,Character who,float dt){if(!Owner||!ready)return;TickContext();if(ContextActive)return;target=who;if(BeginGuardContext(d))return;decision=d;sourceControl=true;
   if(d.Kind==DecisionKind.StartClip||d.Kind==DecisionKind.HoldClip){ResetMovementGoal();human.SetMoveDir(Vector3.zero);human.SetRun(false);return;}
   bool turning=d.Movement==MovementKind.Turn;
   string id=Bank.Has(d.MovementClipId)?d.MovementClipId:"a000_000030";
   KnightMovementChoice resolved;if(KnightMovementRepertoire.TryResolve(d.Movement,d.RunRequested,d.GuardRequested,target!=null,d.TargetTurnDegrees,movementAvailable,out resolved)){id=resolved.ClipId;turning=resolved.IsTurn;}
   int cmd=ParseCommand(id);
   bool repeat=!turning;
   bool finishingPivot=PhysicalPivot&&!KnightTransitionPolicy.Open(command,Elapsed,clip.duration,KnightTransitionChannel.Move);
   if(!finishingPivot&&(clip==null||clip.id!=id||loop!=repeat||(!repeat&&Elapsed>=clip.duration))){StartClip(id,cmd,repeat,true);if(turning){float nativeDegrees=(clip.Reference(clip.duration).w-clip.Reference(0).w)*Mathf.Rad2Deg;if(Mathf.Abs(nativeDegrees)>1)turnYawScale=Mathf.Clamp((float)d.TargetTurnDegrees/nativeDegrees,-1.5f,1.5f);}}
   if(d.Kind==DecisionKind.Move){if(goalTarget!=target){ResetMovementGoal();goalTarget=target;}if(movementProgress.Begin(d.GoalId,PhysicalPivot?MovementKind.Turn:d.Movement,Time.time)){goalPreviousPosition=transform.position;goalPreviousYaw=transform.eulerAngles.y;goalPreviousDirection=Vector3.zero;goalRadius=target?Vector3.ProjectOnPlane(transform.position-target.transform.position,Vector3.up).magnitude:0;}}
   else ResetMovementGoal();
   human.SetMoveDir(Vector3.zero);human.SetRun(false);
  }
  static int ParseCommand(string id){int.TryParse(id.Substring(id.IndexOf('_')+1),out int c);return c;}
  void ResetMovementGoal(){movementProgress.Reset();goalTarget=null;goalPreviousDirection=Vector3.zero;}
  public void StopMovement(){ResetMovementGoal();if(human){human.SetMoveDir(Vector3.zero);human.SetRun(false);}}
  public void YieldToNativeSearch(){
   if(!Owner||!ready||deathPresented||ContextActive)return;
   bool changed=sourceControl||guardDisplayed||decision!=null||target!=null;
   sourceControl=false;guardDisplayed=false;decision=null;target=null;restored=true;motorAt=Elapsed;
   ResetMovementGoal();
   // Keep the base clip/clock and do not overwrite the native move/turn intent.
   // Subsequent idle AI ticks leave a fresh cosmetic flinch alone.
   if(changed)Publish();
  }
  public void InterruptForNativeReaction(){if(!ready)return;ResetMovementGoal();if(sourceControl||ContextActive){contextMode=KnightContextMode.None;guardDisplayed=false;sourceControl=false;serial++;command=-1;decision=null;restored=true;motorAt=Elapsed;Publish();}}
  public ItemDrop.ItemData GetDamageItem(int c)=>KnightAttackRepertoire.UsesShield(c)?ShieldItem:SwordItem;
  public bool TryContactPose(int cmd,double at,int index,out KnightContactPose pose){pose=default;if(!ready||clip==null||cmd!=command||index!=0)return false;var fit=KnightAttackRepertoire.UsesShield(cmd)?Template.Shield:Template.Sword;if(fit==null)return false;
   var m=rig.localToWorldMatrix*clip.BoneMatrix(fit.boneIndex,at,Bank.Manifest.parentIndices);var q=new Quaternion(fit.rotation[0],fit.rotation[1],fit.rotation[2],fit.rotation[3]);var local=Matrix4x4.TRS(new Vector3(fit.center[0],fit.center[1],fit.center[2]),q,Vector3.one);var frame=m*local;
   pose.Center=frame.MultiplyPoint3x4(Vector3.zero);pose.Rotation=frame.rotation;var scale=frame.lossyScale;pose.HalfExtents=Vector3.Scale(new Vector3(fit.halfExtents[0],fit.halfExtents[1],fit.halfExtents[2]),new Vector3(Mathf.Abs(scale.x),Mathf.Abs(scale.y),Mathf.Abs(scale.z)));return true;
  }
  public void ApplySourceVelocity(ref Vector3 velocity){if(!Controlled||clip==null){travelGate="native reaction or inactive source";return;}float dt=Time.fixedDeltaTime;double now=Elapsed;double before=motorAt;motorAt=now;travelTicks++;
   // One physical consumption per clock interval. Never bank blocked/catch-up travel.
   if(!KnightMotorPolicy.Consume(before,now,restored)){restored=false;discardedTicks++;travelGate="restored or stalled clock";velocity.x=velocity.z=0;return;}
   previous=loop?before%clip.duration:Math.Min(before,clip.duration);
   var a=ReferenceUnwrapped(before);var b=ReferenceUnwrapped(now);var local=new Vector3(b.x-a.x,0,b.z-a.z)*EffectiveScale;
   bool requestedTravel=local.sqrMagnitude>.0000000001f;
   bool moving=decision!=null&&decision.Kind==DecisionKind.Move&&decision.Movement!=MovementKind.Turn&&!PhysicalPivot;
   if(moving&&decision.Movement==MovementKind.Approach&&target){if(nav.PathTo(target.transform.position,out var direction)){
     var look=Quaternion.LookRotation(direction);transform.rotation=Quaternion.RotateTowards(transform.rotation,look,KnightSourceData.TurnRate(command,ClipTime,0)*dt);travelHeading=transform.rotation;
     if(Vector3.Distance(transform.position,target.transform.position)<=decision.StopDistanceWorld)local=Vector3.zero;
    }else local=Vector3.zero;}
   else if(target&&decision!=null&&!(command>=5000&&command<=5025)){var to=Vector3.ProjectOnPlane(target.transform.position-transform.position,Vector3.up);float rate=KnightSourceData.TurnRate(command,ClipTime,0);if(to.sqrMagnitude>.001f&&rate>0)transform.rotation=Quaternion.RotateTowards(transform.rotation,Quaternion.LookRotation(to),rate*dt);travelHeading=transform.rotation;
    if(moving){var wanted=LocalGoalDirection(to);float advance=local.magnitude;if(Vector3.Dot(local,decision.Movement==MovementKind.Retreat?Vector3.back:decision.Movement==MovementKind.CircleLeft?Vector3.left:Vector3.right)<0)advance=-advance;
     float lookAhead=(float)KnightMovementGoalPolicy.LocalHorizon(EffectiveScale,to.magnitude);
     // Ask the local route first, then test its actual first leg. A wall on
     // the unsteered chord must not reject a valid route around that wall.
     Vector3 steered;bool supported=LocalSupport(wanted,lookAhead,out steered);
     local=supported?Quaternion.Inverse(travelHeading)*steered*advance:Vector3.zero;
    }
   }
   float yaw=(b.w-a.w)*Mathf.Rad2Deg*turnYawScale;if(Mathf.Abs(yaw)>.0001f)transform.rotation=transform.rotation*Quaternion.Euler(0,yaw,0);
   Vector3 delta=travelHeading*local;travelRequested+=delta.magnitude;float allowed=Allowed(delta,true);delta=delta.normalized*allowed;travelAdmitted+=allowed;
   ObserveMovementGoal(requestedTravel||Mathf.Abs(yaw)>.0001f,travelHeading*local);
   if(allowed>.00001f){
    // Native standing friction was selected earlier in UpdateMotion because
    // source actions intentionally keep m_moveDir zero. Restore only this
    // admitted step's native moving friction, on this collider's own instance.
    // Native UpdateBodyFriction resets it normally at the next fixed tick.
    var material=capsule.material;float friction=(float)KnightMotorPolicy.MovingFriction(NativeSlippage(human));material.staticFriction=material.dynamicFriction=friction;material.frictionCombine=PhysicsMaterialCombine.Multiply;travelGate="source travel admitted";
   }else if(local.sqrMagnitude<.0000000001f)travelGate="source stationary phase";
   velocity.x=delta.x/dt;velocity.z=delta.z/dt;
  }
  Vector3 LocalGoalDirection(Vector3 toward){
   if(toward.sqrMagnitude<.0001f)return Vector3.zero;
   var inward=toward.normalized;if(decision.Movement==MovementKind.Retreat)return -inward;
   var tangent=Vector3.Cross(Vector3.up,inward)*(decision.Movement==MovementKind.CircleLeft?-1:1);
   // Preserve chosen spacing while circling a moving target. This bounded
   // radial correction is adapter steering, not an invented meaning for the
   // source SidewayMove's opaque30..45 parameter.
   float correction=(float)KnightMovementGoalPolicy.CircleCorrection(goalRadius,toward.magnitude,EffectiveScale);
   return (tangent-inward*correction).normalized;
  }
  void ObserveMovementGoal(bool requested,Vector3 desired){
   if(decision==null||decision.Kind!=DecisionKind.Move||movementProgress.GoalId<0)return;
   var moved=Vector3.ProjectOnPlane(transform.position-goalPreviousPosition,Vector3.up);
   double distance=goalPreviousDirection.sqrMagnitude>.5f?Mathf.Max(0,Vector3.Dot(moved,goalPreviousDirection)):0;
   if(PhysicalPivot)distance=Mathf.Abs(Mathf.DeltaAngle(goalPreviousYaw,transform.eulerAngles.y))*Mathf.Deg2Rad*.3f*KnightScaleProfile.BodyMultiplier;
   double targetDistance=target?Vector3.ProjectOnPlane(target.transform.position-transform.position,Vector3.up).magnitude:0;
   bool complete=target&&KnightMovementGoalPolicy.Completed(decision.GoalMovement,targetDistance,decision.StopDistanceWorld,!loop&&Elapsed>=clip.duration-.01);
   movementProgress.Observe(Time.time,distance,requested,complete,.035*KnightScaleProfile.BodyMultiplier);
   goalPreviousPosition=transform.position;goalPreviousYaw=transform.eulerAngles.y;goalPreviousDirection=desired.normalized;
  }
  Vector4 ReferenceUnwrapped(double at){if(!loop)return clip.Reference(Math.Min(at,clip.duration));long cycles=(long)(at/clip.duration);var end=clip.Reference(clip.duration)-clip.Reference(0);return clip.Reference(at%clip.duration)+end*cycles;}
  bool LocalGoalClear(Vector3 direction){
   if(!ready||!human||!human.IsOnGround())return false;
   var enemy=awareness?awareness.GetTargetCreature():target;
   float distance=enemy?Vector3.ProjectOnPlane(enemy.transform.position-transform.position,Vector3.up).magnitude:0;
   Vector3 steered;return LocalSupport(direction,(float)KnightMovementGoalPolicy.LocalHorizon(EffectiveScale,distance),out steered);
  }
  bool LocalSupport(Vector3 desired,float horizon,out Vector3 steered){
   steered=desired.normalized;if(horizon<=0||steered.sqrMagnitude<.5f)return false;
   float firstLeg=horizon;
   if(PathReady&&!nav.LocalDirection(transform.position+steered*horizon,steered,out steered,out firstLeg))return false;
   float probe=(float)KnightMovementGoalPolicy.RouteProbeDistance(horizon,firstLeg);if(probe<.025f)return false;
   return Allowed(steered*probe,false,true)>=probe-.015f;
  }
  bool GoalClear(Vector3 direction){float distance=(float)KnightMovementGoalPolicy.ProbeDistance(EffectiveScale);return ready&&distance>0&&Allowed(direction.normalized*distance,false,true)>=distance-.015f;}
  float Allowed(Vector3 delta,bool track=false,bool geometryOnly=false){float distance=delta.magnitude;if(distance<.00001f)return 0;if(!capsule||!human||!human.IsOnGround()){if(track)travelGate="not grounded";return 0;}var bounds=capsule.bounds;float originalRadius=Math.Max(bounds.extents.x,bounds.extents.z),r=(float)KnightMotorPolicy.CastRadius(originalRadius,KnightScaleProfile.BodyMultiplier);float half=(float)KnightMotorPolicy.HemisphereOffset(bounds.extents.y,originalRadius);int count=Physics.CapsuleCastNonAlloc(bounds.center+Vector3.up*half,bounds.center-Vector3.up*half,r,delta/distance,obstacles,distance+.035f,geometryOnly?KnightCombat.SolidMask:KnightCombat.HitMask,QueryTriggerInteraction.Ignore);if(count>=obstacles.Length){if(track)travelGate="saturated obstacle query";return 0;}float allow=distance;
   for(int i=0;i<count;i++){var h=obstacles[i];if(!h.collider||h.collider.transform.IsChildOf(transform)||h.normal.y>.65f)continue;allow=Math.Min(allow,Math.Max(0,h.distance-.035f));}
   if(track&&allow<distance-.00001f){solidStops++;travelGate="solid obstruction";}
   Vector3 foot=bounds.center;foot.y=bounds.min.y;float step=.32f*KnightScaleProfile.BodyMultiplier,drop=.48f*KnightScaleProfile.BodyMultiplier;int samples=Mathf.Clamp(Mathf.CeilToInt(allow/(.35f*KnightScaleProfile.BodyMultiplier)),1,16);
   for(int sample=1;sample<=samples;sample++){var end=foot+delta.normalized*(allow*sample/samples);int nf=Physics.RaycastNonAlloc(end+Vector3.up*step,Vector3.down,floors,step+drop,KnightCombat.SolidMask,QueryTriggerInteraction.Ignore);if(nf>=floors.Length){if(track)travelGate="saturated floor query";return 0;}bool floor=false;for(int i=0;i<nf;i++)if(floors[i].collider&&!floors[i].collider.transform.IsChildOf(transform)&&floors[i].normal.y>=.65f)floor=true;if(!floor){if(track){floorStops++;travelGate="no supported floor ahead";}return 0;}}return allow;
  }
  void Update(){if(!ready||!view||!view.IsValid())return;bool own=Owner;if(own!=previousOwner){previousOwner=own;restored=true;serial++;command=-1;contextMode=KnightContextMode.None;sourceControl=false;decision=null;motorAt=Elapsed;ResetMovementGoal();if(own)Publish();}if(own)TickContext();if(!own&&Time.time-lastPoll>.1f){lastPoll=Time.time;ReadNetwork();string death=view.GetZDO().GetString("rk_death_v3","");if(!string.IsNullOrEmpty(death))ReceiveDeathPresentation(view.GetZDO().GetOwner(),death);}}
  void LateUpdate(){if(!ready||clip==null||!rig||deathPresented)return;try{
   TickContext();
   if(Owner&&!sourceControl&&!ContextActive&&human&&!human.IsDead()){
    var localTravel=transform.InverseTransformDirection(human.GetVelocity());KnightMovementChoice travelChoice;
    string reaction=guardDisplayed?"a000_000030":"a000_000020";
    if(KnightMovementRepertoire.TryResolveActualTravel(localTravel.x,localTravel.z,human.IsRunning(),guardDisplayed||human.IsBlocking(),GetComponent<MonsterAI>()?.IsAlerted()??false,movementAvailable,out travelChoice))reaction=travelChoice.ClipId;
    if(Bank.Has(reaction)&&clip.id!=reaction)StartClip(reaction,ParseCommand(reaction),true,true);
   }
   ApplyBasePose();
  }catch(Exception e){ready=false;StopMovement();Log?.Invoke("RK_POSE_FAILED "+e);}}
  void ApplyBasePose(){
   float f=Mathf.Clamp01((Time.time-blendStart)/.12f);double at=ClipTime;
   for(int i=0;i<bones.Length;i++){clip.Pose(i,at,out var p,out var q,out var s);bones[i].localPosition=Vector3.Lerp(blendP[i],p,f);bones[i].localRotation=Quaternion.Slerp(blendQ[i],q,f);bones[i].localScale=Vector3.Lerp(blendS[i],s,f);}
  }
  sealed class Packet{public string id;public int command,serial,context;public bool loop,controlled,guardDisplayed;public long ticks;}
  void Publish(){if(!Owner||clip==null)return;var packet=new Packet{id=clip.id,command=command,serial=serial,loop=loop,controlled=sourceControl,context=(int)contextMode,guardDisplayed=guardDisplayed,ticks=ZNet.instance.GetTime().Ticks-(long)(Elapsed*TimeSpan.TicksPerSecond)};view.GetZDO().Set("rk_motion_v1",JsonConvert.SerializeObject(packet));}
  void ReadNetwork(){string value=view.GetZDO().GetString("rk_motion_v1","");if(value==netPacket||string.IsNullOrEmpty(value))return;var p=JsonConvert.DeserializeObject<Packet>(value);if(p==null||!Bank.Has(p.id)||!KnightContextPolicy.Valid(p.context))return;Capture();clip=Bank.Get(p.id);command=p.command;serial=p.serial;loop=p.loop;sourceControl=p.controlled;contextMode=(KnightContextMode)p.context;guardDisplayed=p.guardDisplayed;double elapsed=Math.Max(0,(ZNet.instance.GetTime().Ticks-p.ticks)/(double)TimeSpan.TicksPerSecond);start=Time.time-elapsed;motorAt=elapsed;previous=ClipTime;restored=true;blendStart=Time.time;netPacket=value;}
  public string Status(){var ai=GetComponent<MonsterAI>();var seen=ai?ai.GetTargetCreature():null;return "Knight ready="+ready+" owner="+Owner+" size="+KnightScaleProfile.BodyMultiplier+" clip="+ClipId+" command="+command+" time="+ClipTime.ToString("F2")+" nav="+PathReady+" sourceControl="+sourceControl+" context="+contextMode+" nativeStagger="+(human&&human.IsStaggering())+" canMove="+(human&&human.CanMove())+" grounded="+(human&&human.IsOnGround())+" target="+(seen?seen.GetInstanceID():0)+" alerted="+(ai&&ai.IsAlerted())+" visible="+(ai&&seen&&ai.CanSeeTarget(seen))+" goal="+MovementGoalId+":"+movementProgress.Phase+" blocked="+MovementBlocked+" completed="+MovementCompleted+" progress="+MovementProgress.ToString("F2")+" travel="+travelAdmitted.ToString("F2")+"/"+travelRequested.ToString("F2")+"m ticks="+travelTicks+" discarded="+discardedTicks+" floorStops="+floorStops+" solidStops="+solidStops+" gate="+travelGate+" "+GetComponent<KnightCombat>().Diagnostics();}
 }
 public static class KnightMotionHooks {
  [HarmonyPatch(typeof(CharacterAnimEvent),"OnAnimatorMove")]
  static class NativeRoot{static bool Prefix(CharacterAnimEvent __instance)=>!__instance.GetComponentInParent<KnightActor>();}
  [HarmonyPatch(typeof(Character),"ApplyRootMotion")]
  static class Travel{static void Postfix(Character __instance,ref Vector3 __0){__instance.GetComponent<KnightActor>()?.ApplySourceVelocity(ref __0);}}
  [HarmonyPatch(typeof(Character),"UpdateRotation")]
  static class Facing{static bool Prefix(Character __instance,ref float __result){var a=__instance.GetComponent<KnightActor>();if(!a||!a.Controlled)return true;__result=0;return false;}}
 }
}
