using System;
namespace BlackAbbey.ReliquaryKnight {
 // Engine-independent geometry/clock rules used by the actual physical adapter.
 public static class KnightMotorPolicy {
  public const double MaximumInterval=.15;
  public static bool Consume(double previous,double now,bool restored)=>!restored&&Finite(previous)&&Finite(now)&&now>=previous&&now-previous<=MaximumInterval;
  public static double CastRadius(double originalRadius,double multiplier)=>Math.Max(.05,originalRadius-.04*multiplier);
  // Insets shrink the sphere only. Re-spacing endpoints with the smaller
  // radius cancels the inset at the sole and creates a false floor overlap.
  public static double HemisphereOffset(double halfHeight,double originalRadius)=>Math.Max(0,halfHeight-originalRadius);
  public static double BottomClearance(double halfHeight,double originalRadius,double multiplier)=>halfHeight-HemisphereOffset(halfHeight,originalRadius)-CastRadius(originalRadius,multiplier);
  public static double MovingFriction(double slippage)=>.4*(1-slippage);
  static bool Finite(double x)=>!double.IsNaN(x)&&!double.IsInfinity(x);
 }
}
