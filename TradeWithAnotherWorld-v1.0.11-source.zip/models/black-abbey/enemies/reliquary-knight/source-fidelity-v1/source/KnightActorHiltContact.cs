using UnityEngine;
namespace BlackAbbey.ReliquaryKnight {
 public sealed partial class KnightActor {
  // AABBs in the actual R_Sword bone frame, fitted from the accepted own
  // sword's grip/ferrule, straight quillons and pommel/peen vertices. The
  // original blade contact and displayed source pose are unchanged.
  static readonly Vector3[] HiltCenters={
   new Vector3(.052105371f,.000319946f,-.003046364f),
   new Vector3(-.212028967f,.000319930f,-.003046333f),
   new Vector3(.363239582f,.000319942f,-.003046309f)
  };
  static readonly Vector3[] HiltHalf={
   new Vector3(.257134350f,.019907480f,.029718920f),
   new Vector3(.015999999f,.013500052f,.224372198f),
   new Vector3(.063999951f,.018000018f,.059000074f)
  };
  KnightClip hiltCachedClip;bool hiltFirstValid,hiltSecondValid;
  double hiltFirstAt,hiltSecondAt;Matrix4x4 hiltFirstFrame,hiltSecondFrame;
  Matrix4x4 HiltBoneFrame(double at){
   if(hiltCachedClip!=clip){hiltCachedClip=clip;hiltFirstValid=hiltSecondValid=false;}
   if(hiltFirstValid&&hiltFirstAt==at)return hiltFirstFrame;
   if(hiltSecondValid&&hiltSecondAt==at)return hiltSecondFrame;
   hiltSecondValid=hiltFirstValid;hiltSecondAt=hiltFirstAt;hiltSecondFrame=hiltFirstFrame;
   hiltFirstFrame=clip.BoneMatrix(Template.Sword.boneIndex,at,Bank.Manifest.parentIndices);hiltFirstAt=at;hiltFirstValid=true;
   return hiltFirstFrame;
  }
  public bool TryHiltContactPose(int cmd,double at,int index,out KnightContactPose pose){
   pose=default;
   if(!ready||clip==null||cmd!=command||KnightAttackRepertoire.UsesShield(cmd)||index<0||index>=HiltCenters.Length||Template.Sword==null)return false;
   // Parts share the two sampled bone frames. World placement is read fresh,
   // so the cache never retains an old actor transform or blocked root step.
   var frame=rig.localToWorldMatrix*HiltBoneFrame(at);
   var scale=frame.lossyScale;
   pose.Center=frame.MultiplyPoint3x4(HiltCenters[index]);pose.Rotation=frame.rotation;
   pose.HalfExtents=Vector3.Scale(HiltHalf[index],new Vector3(Mathf.Abs(scale.x),Mathf.Abs(scale.y),Mathf.Abs(scale.z)));
   return true;
  }
 }
}
