using System;
using HarmonyLib;
using UnityEngine;
namespace BlackAbbey.ReliquaryKnight {
 public sealed partial class KnightActor {
  string deathCauseClip;
  bool deathCauseRecorded;
  const string DeathCauseKey="rk_death_cause_v1";
  internal bool CanCaptureDeathCause=>ready&&isActiveAndEnabled&&Owner&&human&&human.GetHealth()>0;
  internal void RecordFatalCause(float before,HitData hit){
   try {
    if(!KnightDeathCausePolicy.ShouldRecord(ready&&isActiveAndEnabled&&Owner&&human,deathCauseRecorded,before,human?human.GetHealth():double.NaN,hit!=null))return;
    Vector3 direction=hit.m_dir;float length=direction.magnitude;
    if(length>.00001f)direction/=length;else direction=Vector3.zero;
    var evidence=new KnightDeathCausePolicy.Evidence {
     Total=hit.GetTotalDamage(),FireDamage=hit.m_damage.m_fire,
     PoisonDamage=hit.m_damage.m_poison,SpiritDamage=hit.m_damage.m_spirit,
     BluntDamage=hit.m_damage.m_blunt,Push=hit.m_pushForce,DirectionY=direction.y,
     HorizontalDirection=Math.Sqrt(direction.x*direction.x+direction.z*direction.z),
     VelocityY=body?body.linearVelocity.y:0,
     FireCause=hit.m_hitType==HitData.HitType.Burning||hit.m_hitType==HitData.HitType.CinderFire||hit.m_hitType==HitData.HitType.AshlandsOcean||hit.m_hitType==HitData.HitType.AshlandsLava||hit.m_hitType==HitData.HitType.Incinerator,
     DebilitatingCause=hit.m_hitType==HitData.HitType.Poisoned||hit.m_hitType==HitData.HitType.Freezing||hit.m_hitType==HitData.HitType.Drowning||hit.m_hitType==HitData.HitType.Smoke,
     CrushingImpact=hit.m_hitType==HitData.HitType.Impact||hit.m_hitType==HitData.HitType.Catapult||hit.m_hitType==HitData.HitType.Tree||hit.m_hitType==HitData.HitType.Cart||hit.m_hitType==HitData.HitType.Stalagtite||hit.m_hitType==HitData.HitType.Structural||hit.m_hitType==HitData.HitType.DrawBridge||hit.m_hitType==HitData.HitType.Boat||hit.m_hitType==HitData.HitType.Fall
    };
    deathCauseClip=KnightDeathCausePolicy.Select(evidence,OrdinaryDeathVariant());deathCauseRecorded=true;view.GetZDO().Set(DeathCauseKey,deathCauseClip);
    Log?.Invoke("RK_DEATH_CAUSE clip="+deathCauseClip+" total="+evidence.Total+" push="+evidence.Push+" directionY="+evidence.DirectionY);
   }catch(Exception e){Log?.Invoke("RK_DEATH_CAUSE_SKIPPED "+e.GetBaseException().Message);}
  }
  int OrdinaryDeathVariant(){
   long ticks=view.GetZDO().GetLong("rk_hp_zero_v1",0);
   if(ticks<=0)ticks=ZNet.instance?ZNet.instance.GetTime().Ticks:DateTime.UtcNow.Ticks;
   return KnightDeathCausePolicy.StableOrdinaryVariant(view.GetZDO().m_uid.ToString(),ticks);
  }
  public string SelectDeathClip(){
   // Only the authoritative owner classifies. The caller transmits this exact
   // clip to peers in its bounded death message, rather than rerolling there.
   if(deathCauseRecorded&&KnightDeathCausePolicy.ValidClip(deathCauseClip))return deathCauseClip;
   if(view&&view.IsValid()&&human&&human.GetHealth()<=0){string saved=view.GetZDO().GetString(DeathCauseKey,"");if(KnightDeathCausePolicy.ValidClip(saved)){deathCauseRecorded=true;deathCauseClip=saved;return saved;}}
   if(Owner&&human&&human.GetHealth()<=0){deathCauseRecorded=true;deathCauseClip=KnightDeathCausePolicy.OrdinaryClip(OrdinaryDeathVariant());view.GetZDO().Set(DeathCauseKey,deathCauseClip);return deathCauseClip;}
   return KnightDeathCausePolicy.Normal;
  }
 }
 public static class KnightDeathCauseHooks {
  internal sealed class Scope {internal KnightActor Actor;internal HitData Hit;internal Scope Previous;}
  [ThreadStatic] static Scope current;
  static void Restore(Scope scope){if(scope!=null&&current==scope)current=scope.Previous;}
  [HarmonyPatch(typeof(Character),nameof(Character.ApplyDamage))]
  static class DamageScope {
   [HarmonyPriority(Priority.First)]
   static void Prefix(Character __instance,HitData __0,out Scope __state){
    __state=null;
    try {
     var actor=__instance?__instance.GetComponent<KnightActor>():null;
     if(!actor||!actor.CanCaptureDeathCause||__0==null)return;
     __state=new Scope {Actor=actor,Hit=__0,Previous=current};current=__state;
    }catch(Exception e){KnightActor.Log?.Invoke("RK_DEATH_CAUSE_SCOPE_SKIPPED "+e.GetBaseException().Message);}
   }
   static void Postfix(Scope __state){Restore(__state);}
   static Exception Finalizer(Exception __exception,Scope __state){Restore(__state);return __exception;}
  }
  [HarmonyPatch(typeof(Character),nameof(Character.SetHealth))]
  static class FatalHealth {
   static void Prefix(Character __instance,out float __state){__state=__instance?__instance.GetHealth():0;}
   [HarmonyPriority(Priority.First)]
   static void Postfix(Character __instance,float __state){
    try {
     if(current?.Actor&&__instance&&current.Actor.gameObject==__instance.gameObject)
      current.Actor.RecordFatalCause(__state,current.Hit);
    }catch(Exception e){KnightActor.Log?.Invoke("RK_DEATH_CAUSE_HEALTH_SKIPPED "+e.GetBaseException().Message);}
   }
  }
 }
}
