using System;
namespace BlackAbbey.ReliquaryKnight {
 // Source SpaceCheck probes two source units plus the actor's source radius.
 // This policy handles admission/progress only; the native body owns physics.
 public static class KnightMovementGoalPolicy {
  public const double SourceProbeDistance=2,SourceHitRadius=.5;
  public const double BlockedGraceSeconds=.55,ProgressSampleSeconds=.12;
  public static double ProbeDistance(double scale)=>Finite(scale)&&scale>0?(SourceProbeDistance+SourceHitRadius)*scale:0;
  public static double LocalHorizon(double scale,double targetDistance){
   if(!Finite(scale)||scale<=0||!Finite(targetDistance)||targetDistance<0)return 0;
   return Math.Min(ProbeDistance(scale),Math.Max(.4,Math.Min(1.1*scale,targetDistance*.35)));
  }
  public static double RouteProbeDistance(double requestedHorizon,double firstLeg){
   if(!Finite(requestedHorizon)||!Finite(firstLeg)||requestedHorizon<=0||firstLeg<=0)return 0;
   return Math.Min(requestedHorizon,firstLeg);
  }
  public static bool RouteCompatible(double desiredDot)=>Finite(desiredDot)&&desiredDot>=.35;
  public static double CircleCorrection(double desiredRadius,double distance,double scale){
   if(!Finite(desiredRadius)||!Finite(distance)||!Finite(scale)||desiredRadius<0||distance<0||scale<=0)return 0;
   return Math.Max(-.35,Math.Min(.35,(desiredRadius-distance)/Math.Max(.5,scale)));
  }
  public static bool Completed(MovementKind goal,double distance,double stop,bool pivotFinished){
   if(!Finite(distance)||!Finite(stop)||distance<0||stop<0)return false;
   return goal==MovementKind.Approach?distance<=stop:goal==MovementKind.Retreat?distance>=stop:goal==MovementKind.Turn&&pivotFinished;
  }
  static bool Finite(double n)=>!double.IsNaN(n)&&!double.IsInfinity(n);
 }
 // Feedback is tied to a stable source goal AND its current locomotion phase.
 // A temporary pivot inside an approach cannot complete/latch the approach.
 public sealed class KnightMovementProgress {
  public int GoalId{get;private set;}=-1;
  public MovementKind Phase{get;private set;}
  public double Progress{get;private set;}
  public bool Blocked{get;private set;}
  public bool Complete{get;private set;}
  double requestedSince=double.NaN,lastProgressAt,lastTime=-1,uncredited;
  public void Reset(){GoalId=-1;Phase=MovementKind.None;Progress=0;Blocked=Complete=false;requestedSince=double.NaN;lastProgressAt=0;lastTime=-1;uncredited=0;}
  public bool Begin(int id,MovementKind phase,double now){
   if(id==GoalId&&phase==Phase)return false;
   Reset();GoalId=id;Phase=phase;lastTime=lastProgressAt=now;return true;
  }
  public void Observe(double now,double distanceMoved,bool movementRequested,bool completed,double minimumProgress){
   if(GoalId<0||double.IsNaN(now)||double.IsInfinity(now)||now<lastTime){Reset();return;}
   lastTime=now;
   if(double.IsNaN(distanceMoved)||double.IsInfinity(distanceMoved)||distanceMoved<0||distanceMoved>3)return;
   Progress+=distanceMoved;uncredited+=distanceMoved;
   if(uncredited>=minimumProgress){uncredited=0;lastProgressAt=now;Blocked=false;}
   if(completed){Complete=true;Blocked=false;return;}
   if(!movementRequested){requestedSince=double.NaN;lastProgressAt=now;return;}
   if(double.IsNaN(requestedSince)){requestedSince=now;lastProgressAt=now;}
   Blocked=now-Math.Max(requestedSince,lastProgressAt)>=KnightMovementGoalPolicy.BlockedGraceSeconds;
  }
 }
}
