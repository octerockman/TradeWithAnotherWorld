using System;
namespace BlackAbbey.ReliquaryKnight {
 public static class KnightDeathFollowOnPolicy {
  public const string PrimaryClipId="a000_010000",ClipId="a000_011001";
  public const double EntryBlendSeconds=.30;
  public static bool Choose(string primaryClip,int identity,long hpZeroTicks){
   if(primaryClip!=PrimaryClipId||hpZeroTicks<=0)return false;
   uint draw=unchecked((uint)identity^(uint)hpZeroTicks^(uint)(hpZeroTicks>>32));
   draw^=draw<<13;draw^=draw>>17;draw^=draw<<5;
   return (draw&3u)==0;
  }
  public static bool ValidPair(string primaryClip,string followClip)=>primaryClip==PrimaryClipId&&followClip==ClipId;
  public static float EntryBlend(double elapsed){if(double.IsNaN(elapsed))return 0;double t=Math.Max(0,Math.Min(1,elapsed/EntryBlendSeconds));return (float)(t*t*(3-2*t));}
 }
}
