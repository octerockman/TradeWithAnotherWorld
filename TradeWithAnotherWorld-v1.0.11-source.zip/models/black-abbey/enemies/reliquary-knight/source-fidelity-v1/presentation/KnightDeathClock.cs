using System;
namespace BlackAbbey.ReliquaryKnight
{
    public static class KnightDeathClock
    {
        public const string DefaultClip="a000_010000";
        public const double BlendSeconds=.12;
        public const double HandoffLiftSeconds=.15;
        public const double CorpseSeconds=10;
        public static double Sample(double elapsed,double duration)
        { return Math.Max(0,Math.Min(duration,elapsed)); }
        public static bool Transfer(double elapsed,double duration,bool finalPresented)
        { return finalPresented&&elapsed>=duration; }
        public static bool Expired(double corpseStarted,double now)
        { return corpseStarted>=0&&now>=corpseStarted+CorpseSeconds; }
        public static double LiftBlend(double elapsed)
        { double t=Math.Max(0,Math.Min(1,elapsed/HandoffLiftSeconds));return t*t*(3-2*t); }
    }
}
