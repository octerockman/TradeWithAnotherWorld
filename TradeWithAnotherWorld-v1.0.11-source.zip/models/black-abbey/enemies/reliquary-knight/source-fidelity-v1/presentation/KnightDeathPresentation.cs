using System;
using System.Collections.Generic;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbey.ReliquaryKnight
{
    // Cosmetic presentation only. Native death, loot and network destruction
    // still run immediately; only the own visual rig is copied and retained.
    public static class KnightDeathPresentation
    {
        internal static readonly HashSet<KnightDeathPlayback> Active=new HashSet<KnightDeathPlayback>();
        static KnightMotionBank preparedBank;
        static readonly Dictionary<string,KnightClip> preparedClips=new Dictionary<string,KnightClip>(StringComparer.Ordinal);
        static readonly Collider[] deathSpace=new Collider[32];
        public static void Prepare(KnightMotionBank bank)
        {
            if(bank==null)throw new InvalidOperationException("Source death motion bank unavailable");
            if(preparedBank==bank&&preparedClips.Count==KnightDeathVariantPolicy.ClipIds.Length)return;
            preparedBank=null;preparedClips.Clear();
            foreach(string id in KnightDeathVariantPolicy.ClipIds){
                if(!bank.Has(id))throw new InvalidOperationException("Source death motion unavailable: "+id);
                var clip=bank.Get(id);
                if(!KnightDeathVariantPolicy.ValidDuration(id,clip.duration)||clip.frames==null||clip.frames.Length<2)throw new InvalidOperationException("Invalid source death motion: "+id);
                preparedClips.Add(id,clip);
            }
            KnightDeathFollowOn.Prepare(bank);preparedBank=bank;
        }
        public static string SelectSpaceCompatibleClip(Transform sourceRig,KnightMotionBank bank,string requested)
        {
            requested=KnightDeathVariantPolicy.OrDefault(requested);
            if(requested!=KnightDeathSpaceProfile.ClipId)return requested;
            if(!sourceRig||!sourceRig.parent||bank==null)return KnightDeathCausePolicy.Blast;
            Transform head=null;foreach(var node in sourceRig.GetComponentsInChildren<Transform>(true))if(node.name=="Head"){head=node;break;}
            float scale=Mathf.Abs(sourceRig.lossyScale.x);
            if(!head||scale<.1f||scale>4)return KnightDeathCausePolicy.Blast;
            // The measured whole skin/equipment envelope includes flipped boots
            // and sword, not merely the head. Test only its region above the
            // current helmet, avoiding a broad sphere overlapping the floor.
            float margin=.08f/scale,low=sourceRig.InverseTransformPoint(head.position).y+.20f*KnightScaleProfile.BodyMultiplier/scale;
            float high=KnightDeathSpaceProfile.MaximumYUnscaled+(.2f*KnightScaleProfile.BodyMultiplier+.08f)/scale;
            if(high<=low)return requested;
            float x=(KnightDeathSpaceProfile.MinimumXUnscaled+KnightDeathSpaceProfile.MaximumXUnscaled)*.5f,z=(KnightDeathSpaceProfile.MinimumZUnscaled+KnightDeathSpaceProfile.MaximumZUnscaled)*.5f;
            var center=sourceRig.TransformPoint(new Vector3(x,(low+high)*.5f,z));
            var half=new Vector3((KnightDeathSpaceProfile.MaximumXUnscaled-KnightDeathSpaceProfile.MinimumXUnscaled)*.5f+margin,(high-low)*.5f,(KnightDeathSpaceProfile.MaximumZUnscaled-KnightDeathSpaceProfile.MinimumZUnscaled)*.5f+margin)*scale;
            int count=Physics.OverlapBoxNonAlloc(center,half,deathSpace,sourceRig.rotation,KnightCombat.SolidMask,QueryTriggerInteraction.Ignore);
            bool blocked=count>=deathSpace.Length;
            for(int i=0;i<count&&!blocked;i++)if(deathSpace[i]&&!deathSpace[i].transform.IsChildOf(sourceRig.parent))blocked=true;
            if(blocked){KnightCombat.Log?.Invoke("RK_DEATH_HEADROOM_FALLBACK requested="+requested+" selected="+KnightDeathCausePolicy.Blast);return KnightDeathCausePolicy.Blast;}
            return requested;
        }
        public static GameObject Create(Transform sourceRig,KnightMotionBank bank,string clipId,string followClipId)
        {
            if(!sourceRig||bank==null)return null;
            GameObject holder=null;
            try {
                Prepare(bank);
                if(!KnightDeathVariantPolicy.IsSupported(clipId)||!preparedClips.TryGetValue(clipId,out var selected))throw new InvalidOperationException("Unsupported selected source death");
                holder=new GameObject("RK_DeathPresentation");
                // Unit outer transform keeps all physical proxy bodies at unit
                // world scale. The visual alone retains its exact actor scale.
                var visual=Object.Instantiate(sourceRig.gameObject,sourceRig.position,sourceRig.rotation);
                visual.name="RK_DeathVisual";visual.transform.SetParent(holder.transform,true);
                visual.transform.localScale=sourceRig.lossyScale;
                foreach(var script in visual.GetComponentsInChildren<MonoBehaviour>(true)) { script.enabled=false;Object.Destroy(script); }
                foreach(var animator in visual.GetComponentsInChildren<Animator>(true)) { animator.enabled=false;Object.Destroy(animator); }
                foreach(var collider in visual.GetComponentsInChildren<Collider>(true)) { collider.enabled=false;Object.Destroy(collider); }
                foreach(var body in visual.GetComponentsInChildren<Rigidbody>(true)) { body.isKinematic=true;Object.Destroy(body); }
                var player=holder.AddComponent<KnightDeathPlayback>();
                player.Initialize(visual.transform,bank,selected);
                player.SetFollowOn(followClipId);
                Active.Add(player);
                return holder;
            }
            catch(Exception e) {
                if(holder)Object.Destroy(holder);
                KnightCombat.Log?.Invoke("RK_DEATH_PRESENTATION_DISABLED "+e.GetBaseException().Message);
                return null;
            }
        }
        public static void Shutdown()
        {
            foreach(var player in new List<KnightDeathPlayback>(Active))if(player)Object.Destroy(player.gameObject);
            Active.Clear();preparedBank=null;preparedClips.Clear();KnightDeathFollowOn.Shutdown();
        }
    }

    [DefaultExecutionOrder(1200)]
    public sealed class KnightDeathPlayback:MonoBehaviour
    {
        Transform visual;Transform[] bones;
        KnightMotionBank bank;KnightClip clip;
        Vector3[] entryP,entryS;Quaternion[] entryQ;
        double started,lastAnimationTime,corpseStarted=-1;
        Quaternion travelHeading;
        float sourceWorldScale,baseHeight;
        bool initialized,finalPresented,failed,settled,preparingPhysics,followRequested,playingFollowOn;
        double preparedAt;float handoffLift;Vector3 preLiftVisual;
        Vector3[] preLiftBodies;CapsuleCollider[] pendingShapes;
        Rigidbody[] bodies;
        int[] mapping;
        Vector3[] bindBoneP,bindLocalS,bindBodyP;
        Quaternion[] bindBoneQ,bindBodyQ;
        Vector3[] targetP;Quaternion[] targetQ;
        readonly RaycastHit[] casts=new RaycastHit[48],floors=new RaycastHit[32];
        float physicalAge,quiet;
        public double PhysicsAge=>corpseStarted>=0?Math.Max(0,Time.realtimeSinceStartupAsDouble-corpseStarted):0;
        public void SetFollowOn(string id){followRequested=KnightDeathFollowOn.ValidPair(clip?.id,id)&&KnightDeathFollowOn.Clip!=null;}
        static int Solid=>LayerMask.GetMask("Default","static_solid","Default_small","piece","terrain","vehicle");
        public void Initialize(Transform rig,KnightMotionBank motionBank,KnightClip death)
        {
            visual=rig;bank=motionBank;clip=death;
            var named=new Dictionary<string,Transform>(StringComparer.Ordinal);
            var expected=new HashSet<string>(bank.Manifest.boneNames,StringComparer.Ordinal);
            foreach(var node in rig.GetComponentsInChildren<Transform>(true))if(expected.Contains(node.name)) {
                if(named.ContainsKey(node.name))throw new InvalidOperationException("Duplicate copied source bone "+node.name);
                named.Add(node.name,node);
            }
            bones=new Transform[138];entryP=new Vector3[138];entryQ=new Quaternion[138];entryS=new Vector3[138];
            if(named.Count!=bones.Length)throw new InvalidOperationException("Incomplete own copied skeleton");
            for(int i=0;i<bones.Length;i++) {
                bones[i]=named[bank.Manifest.boneNames[i]];
                entryP[i]=bones[i].localPosition;entryQ[i]=bones[i].localRotation;entryS[i]=bones[i].localScale;
            }
            mapping=KnightRagdollLayout.Bind(bank.Manifest.boneNames,bank.Manifest.parentIndices);
            foreach(var skin in rig.GetComponentsInChildren<SkinnedMeshRenderer>(true)) {
                var own=new Transform[skin.bones.Length];
                for(int i=0;i<own.Length;i++) {
                    var old=skin.bones[i];if(!old||!named.TryGetValue(old.name,out own[i]))throw new InvalidOperationException("Copied skin has an external/missing bone");
                }
                skin.bones=own;
                if(!skin.rootBone||!named.TryGetValue(skin.rootBone.name,out var ownRoot))throw new InvalidOperationException("Copied skin root unavailable");
                skin.rootBone=ownRoot;skin.updateWhenOffscreen=true;
                skin.localBounds=new Bounds(Vector3.zero,Vector3.one*12);
            }
            if(rig.GetComponentsInChildren<SkinnedMeshRenderer>(true).Length!=9)throw new InvalidOperationException("Expected nine own material skins");
            sourceWorldScale=Mathf.Abs(rig.lossyScale.x);
            if(sourceWorldScale<.1f||sourceWorldScale>4)throw new InvalidOperationException("Invalid source death scale");
            baseHeight=rig.position.y;travelHeading=rig.rotation;started=Time.realtimeSinceStartupAsDouble;initialized=true;
            KnightCombat.Log?.Invoke("RK_SOURCE_DEATH clip="+clip.id+" duration="+clip.duration+" physicsAfterFinalPose=true cleanupAfterPhysicsSeconds="+KnightDeathClock.CorpseSeconds);
        }
        void Update()
        {
            if(initialized&&KnightDeathClock.Expired(corpseStarted,Time.realtimeSinceStartupAsDouble))Object.Destroy(gameObject);
        }
        void LateUpdate()
        {
            if(!initialized||failed||!visual)return;
            try {
                if(preparingPhysics) { ContinueHandoff();return; }
                if(corpseStarted>=0) { if(bodies!=null)DriveAllBones();return; }
                double elapsed=Time.realtimeSinceStartupAsDouble-started;
                if(KnightDeathClock.Transfer(elapsed,clip.duration,finalPresented)) { if(followRequested&&!playingFollowOn)BeginFollowOn();else BeginRagdoll();return; }
                double at=KnightDeathClock.Sample(elapsed,clip.duration);
                float blend=playingFollowOn?KnightDeathFollowOn.EntryBlend(elapsed):Mathf.Clamp01((float)(elapsed/KnightDeathClock.BlendSeconds));
                AdvanceCosmetic(at);
                for(int i=0;i<bones.Length;i++) {
                    clip.Pose(i,at,out var p,out var q,out var s);
                    bones[i].localPosition=Vector3.Lerp(entryP[i],p,blend);
                    bones[i].localRotation=Quaternion.Slerp(entryQ[i],q,blend);
                    bones[i].localScale=Vector3.Lerp(entryS[i],s,blend);
                }
                ApplyAnimatedFloor(at);
                // Do not start physics in this pass. The exact final source
                // pose is presented for a frame before the subsequent handoff.
                if(at>=clip.duration)finalPresented=true;
            }
            catch(Exception e) {
                failed=true;corpseStarted=Time.realtimeSinceStartupAsDouble;
                foreach(var body in GetComponentsInChildren<Rigidbody>(true))if(body)body.isKinematic=true;
                KnightCombat.Log?.Invoke("RK_DEATH_PRESENTATION_FROZEN "+e.GetBaseException().Message);
            }
        }
        void BeginFollowOn()
        {
            for(int i=0;i<bones.Length;i++){entryP[i]=bones[i].localPosition;entryQ[i]=bones[i].localRotation;entryS[i]=bones[i].localScale;}
            clip=KnightDeathFollowOn.Clip;playingFollowOn=true;followRequested=false;lastAnimationTime=0;finalPresented=false;started=Time.realtimeSinceStartupAsDouble;
            // Preserve the original floor datum; the prior visual floor lift is
            // presentation, and must not be added a second time to this source.
            KnightCombat.Log?.Invoke("RK_DEATH_FOLLOW_ON clip="+clip.id+" duration="+clip.duration);
        }
        void AdvanceCosmetic(double at)
        {
            var from=clip.Reference(lastAnimationTime);var to=clip.Reference(at);lastAnimationTime=at;
            Vector3 local=new Vector3(to.x-from.x,0,to.z-from.z)*sourceWorldScale;
            Vector3 delta=travelHeading*local;float distance=delta.magnitude;
            if(distance>.00001f) {
                float size=KnightScaleProfile.BodyMultiplier,radius=KnightScaleProfile.NativeBodyRadius*size,height=KnightScaleProfile.NativeBodyHeight*size;
                Vector3 center=visual.position+Vector3.up*(height*.5f);float offset=Mathf.Max(0,height*.5f-radius),castRadius=radius-.04f*size;
                int n=Physics.CapsuleCastNonAlloc(center+Vector3.up*offset,center-Vector3.up*offset,castRadius,delta/distance,casts,distance+.025f,Solid,QueryTriggerInteraction.Ignore);
                float allowed=n>=casts.Length?0:distance;
                for(int i=0;i<n;i++)if(casts[i].collider&&!casts[i].collider.transform.IsChildOf(transform)&&casts[i].normal.y<.65f)allowed=Mathf.Min(allowed,Mathf.Max(0,casts[i].distance-.025f));
                var end=visual.position+delta.normalized*allowed;
                int nf=Physics.RaycastNonAlloc(end+Vector3.up*(.32f*size),Vector3.down,floors,.8f*size,Solid,QueryTriggerInteraction.Ignore);
                bool supported=false;
                if(nf<floors.Length)for(int i=0;i<nf;i++)if(floors[i].collider&&!floors[i].collider.transform.IsChildOf(transform)&&floors[i].normal.y>.65f)supported=true;
                if(supported)visual.position+=delta.normalized*allowed;
            }
            float yaw=(to.w-from.w)*Mathf.Rad2Deg;
            if(Mathf.Abs(yaw)>.00001f)visual.rotation=visual.rotation*Quaternion.Euler(0,yaw,0);
        }
        void ApplyAnimatedFloor(double at)
        {
            float size=KnightScaleProfile.BodyMultiplier;
            var foot=new Vector3(visual.position.x,baseHeight,visual.position.z);
            int n=Physics.RaycastNonAlloc(foot+Vector3.up*(.4f*size),Vector3.down,floors,.9f*size,Solid,QueryTriggerInteraction.Ignore);
            if(n>=floors.Length)return;
            bool found=false;float floor=float.NegativeInfinity;
            for(int i=0;i<n;i++)if(floors[i].collider&&!floors[i].collider.transform.IsChildOf(transform)&&floors[i].normal.y>.65f) {
                floor=Mathf.Max(floor,floors[i].point.y);found=true;
            }
            if(!found)return;
            float minimum=(playingFollowOn?KnightDeathFollowOn.MinimumY(at):KnightDeathVariantFloorProfile.MinimumY(clip.id,at))*sourceWorldScale;
            float lift=Mathf.Clamp(floor+.005f-baseHeight-minimum,0,.2f*size);
            var position=visual.position;position.y=baseHeight+lift;visual.position=position;
        }
        void BeginRagdoll()
        {
            var named=new Dictionary<string,int>(StringComparer.Ordinal);
            for(int i=0;i<bones.Length;i++)named.Add(bank.Manifest.boneNames[i],i);
            var parts=KnightRagdollLayout.Parts;
            bodies=new Rigidbody[parts.Length];var colliders=new CapsuleCollider[parts.Length];
            var physical=new GameObject("RK_PhysicalProxies");physical.transform.SetParent(transform,false);
            try {
                for(int i=0;i<parts.Length;i++) {
                    var spec=parts[i];Vector3 begin=bones[named[spec.Bone]].position,end=bones[named[spec.End]].position,delta=end-begin;
                    var go=new GameObject("RK_Physics_"+spec.Bone);go.layer=0;go.transform.SetParent(physical.transform,false);
                    go.transform.position=(begin+end)*.5f;go.transform.rotation=delta.sqrMagnitude>.000001f?Quaternion.FromToRotation(Vector3.up,delta.normalized):Quaternion.identity;
                    var rb=go.AddComponent<Rigidbody>();rb.isKinematic=true;rb.mass=spec.Mass;rb.linearDamping=.4f;rb.angularDamping=.8f;
                    rb.interpolation=RigidbodyInterpolation.Interpolate;rb.collisionDetectionMode=CollisionDetectionMode.ContinuousSpeculative;rb.solverIterations=10;rb.solverVelocityIterations=4;rb.maxAngularVelocity=8;
                    var shape=go.AddComponent<CapsuleCollider>();shape.enabled=false;shape.direction=1;shape.radius=spec.Radius*KnightScaleProfile.BodyMultiplier;shape.height=Mathf.Max(shape.radius*2,delta.magnitude+shape.radius);
                    bodies[i]=rb;colliders[i]=shape;
                }
                handoffLift=SafeInitialLift(colliders);
                var bodyIndex=new Dictionary<string,int>(StringComparer.Ordinal);
                for(int i=0;i<parts.Length;i++)bodyIndex.Add(parts[i].Bone,i);
                for(int i=0;i<parts.Length;i++)if(parts[i].Parent!=null) {
                    var rb=bodies[i];var parent=bodies[bodyIndex[parts[i].Parent]];Vector3 anchor=bones[named[parts[i].JointAnchor]].position;
                    var joint=rb.gameObject.AddComponent<CharacterJoint>();joint.connectedBody=parent;joint.autoConfigureConnectedAnchor=false;
                    joint.anchor=rb.transform.InverseTransformPoint(anchor);joint.connectedAnchor=parent.transform.InverseTransformPoint(anchor);
                    joint.axis=Vector3.up;joint.swingAxis=Vector3.right;
                    joint.lowTwistLimit=new SoftJointLimit{limit=-25};joint.highTwistLimit=new SoftJointLimit{limit=25};joint.swing1Limit=new SoftJointLimit{limit=40};joint.swing2Limit=new SoftJointLimit{limit=40};
                    joint.enableProjection=true;joint.projectionDistance=.035f*KnightScaleProfile.BodyMultiplier;joint.projectionAngle=10;joint.enableCollision=false;
                }
                for(int i=0;i<colliders.Length;i++)for(int j=i+1;j<colliders.Length;j++)Physics.IgnoreCollision(colliders[i],colliders[j],true);
                preLiftVisual=visual.position;preLiftBodies=new Vector3[bodies.Length];for(int i=0;i<bodies.Length;i++)preLiftBodies[i]=bodies[i].position;
                pendingShapes=colliders;preparedAt=Time.realtimeSinceStartupAsDouble;preparingPhysics=true;
                // Preserve the exact final pose during a short whole-corpse
                // floor clearance transfer. Colliders remain disabled and all
                // proxies kinematic until this small safe lift has completed.
                if(handoffLift<=.00001f)ActivatePhysics();
            }
            catch(Exception e) {
                foreach(var body in bodies)if(body)body.isKinematic=true;
                Object.Destroy(physical);bodies=null;corpseStarted=Time.realtimeSinceStartupAsDouble;
                KnightCombat.Log?.Invoke("RK_RAGDOLL_FROZEN_FINAL_POSE "+e.GetBaseException().Message);
            }
        }
        void ContinueHandoff()
        {
            double elapsed=Time.realtimeSinceStartupAsDouble-preparedAt;
            float lift=handoffLift*(float)KnightDeathClock.LiftBlend(elapsed);
            visual.position=preLiftVisual+Vector3.up*lift;
            for(int i=0;i<bodies.Length;i++)bodies[i].position=preLiftBodies[i]+Vector3.up*lift;
            if(elapsed>=KnightDeathClock.HandoffLiftSeconds)ActivatePhysics();
        }
        void ActivatePhysics()
        {
            bindBoneP=new Vector3[bones.Length];bindBoneQ=new Quaternion[bones.Length];bindLocalS=new Vector3[bones.Length];targetP=new Vector3[bones.Length];targetQ=new Quaternion[bones.Length];
            bindBodyP=new Vector3[bodies.Length];bindBodyQ=new Quaternion[bodies.Length];
            for(int i=0;i<bones.Length;i++) { bindBoneP[i]=bones[i].position;bindBoneQ[i]=bones[i].rotation;bindLocalS[i]=bones[i].localScale; }
            for(int i=0;i<bodies.Length;i++) { bindBodyP[i]=bodies[i].position;bindBodyQ[i]=bodies[i].rotation; }
            foreach(var shape in pendingShapes)shape.enabled=true;
            foreach(var body in bodies)body.isKinematic=false;
            preparingPhysics=false;corpseStarted=Time.realtimeSinceStartupAsDouble;
            DriveAllBones();
            KnightCombat.Log?.Invoke("RK_RAGDOLL_BOUND proxies="+bodies.Length+" mappedBones="+mapping.Length+" spineProxy="+mapping[56]+" initialFloorLift="+handoffLift+" liftBlendSeconds="+KnightDeathClock.HandoffLiftSeconds);
        }
        float SafeInitialLift(CapsuleCollider[] shapes)
        {
            float lift=0,size=KnightScaleProfile.BodyMultiplier;
            foreach(var shape in shapes) {
                var axis=shape.transform.up;float half=Mathf.Max(0,shape.height*.5f-shape.radius);
                var center=shape.transform.position;var points=new[]{center,center+axis*half,center-axis*half};
                foreach(var point in points) {
                    int n=Physics.RaycastNonAlloc(point+Vector3.up*(.4f*size),Vector3.down,floors,.9f*size,Solid,QueryTriggerInteraction.Ignore);
                    if(n>=floors.Length)throw new InvalidOperationException("Saturated corpse-floor query");
                    for(int i=0;i<n;i++)if(floors[i].collider&&!floors[i].collider.transform.IsChildOf(transform)&&floors[i].normal.y>.65f)
                        lift=Mathf.Max(lift,floors[i].point.y+.015f-(point.y-shape.radius));
                }
            }
            // The source final pose also places some fingers/armour below its
            // nominal floor. Include the real skinned surface, particularly
            // the shield rim, rather than shrinking colliders to hide this.
            lift=Mathf.Max(lift,SkinFloorLift());
            if(lift>.2f*size)throw new InvalidOperationException("Final pose too embedded for a safe physical handoff");
            return Mathf.Max(0,lift);
        }
        float SkinFloorLift()
        {
            float lift=0,size=KnightScaleProfile.BodyMultiplier;
            var baked=new Mesh{name="RK_DeathFloorMeasure"};
            try {
                foreach(var skin in visual.GetComponentsInChildren<SkinnedMeshRenderer>(true)) {
                    skin.BakeMesh(baked,false);var vertices=baked.vertices;
                    Vector3 lowest=Vector3.zero,next=Vector3.zero;bool have=false,haveNext=false;
                    foreach(var local in vertices) {
                        var point=skin.transform.TransformPoint(local);
                        if(!have||point.y<lowest.y) { lowest=point;have=true; }
                    }
                    if(!have)continue;
                    foreach(var local in vertices) {
                        var point=skin.transform.TransformPoint(local);var horizontal=point-lowest;horizontal.y=0;
                        if(horizontal.sqrMagnitude<.0225f)continue;
                        if(!haveNext||point.y<next.y) { next=point;haveNext=true; }
                    }
                    foreach(var point in haveNext?new[]{lowest,next}:new[]{lowest}) {
                        int n=Physics.RaycastNonAlloc(point+Vector3.up*(.4f*size),Vector3.down,floors,.9f*size,Solid,QueryTriggerInteraction.Ignore);
                        if(n>=floors.Length)throw new InvalidOperationException("Saturated skin-floor query");
                        for(int i=0;i<n;i++)if(floors[i].collider&&!floors[i].collider.transform.IsChildOf(transform)&&floors[i].normal.y>.65f)
                            lift=Mathf.Max(lift,floors[i].point.y+.005f-point.y);
                    }
                }
            }
            finally { Object.Destroy(baked); }
            return lift;
        }
        void DriveAllBones()
        {
            // Compute every target before modifying any parent. Skin bones stay
            // free of physics components; proxies are independent siblings.
            for(int i=0;i<bones.Length;i++) {
                int part=mapping[i];var body=bodies[part];
                var delta=body.transform.rotation*Quaternion.Inverse(bindBodyQ[part]);
                targetP[i]=body.transform.position+delta*(bindBoneP[i]-bindBodyP[part]);targetQ[i]=delta*bindBoneQ[i];
                if(!Finite(targetP[i])||!Finite(targetQ[i]))throw new InvalidOperationException("Nonfinite source-rig corpse target");
            }
            for(int i=0;i<bones.Length;i++) { bones[i].SetPositionAndRotation(targetP[i],targetQ[i]);bones[i].localScale=bindLocalS[i]; }
        }
        void FixedUpdate()
        {
            if(settled||bodies==null||corpseStarted<0)return;
            physicalAge+=Time.fixedDeltaTime;if(physicalAge<2)return;
            bool moving=false;
            foreach(var body in bodies)if(body&&!body.isKinematic&&(body.linearVelocity.sqrMagnitude>.0064f||body.angularVelocity.sqrMagnitude>.04f)) { moving=true;break; }
            quiet=moving?0:quiet+Time.fixedDeltaTime;if(quiet<2)return;
            foreach(var body in bodies)if(body) { body.linearVelocity=Vector3.zero;body.angularVelocity=Vector3.zero;body.isKinematic=true; }
            settled=true;
        }
        static bool Finite(Vector3 p)=>!(float.IsNaN(p.x)||float.IsNaN(p.y)||float.IsNaN(p.z)||float.IsInfinity(p.x)||float.IsInfinity(p.y)||float.IsInfinity(p.z));
        static bool Finite(Quaternion q)=>!(float.IsNaN(q.x)||float.IsNaN(q.y)||float.IsNaN(q.z)||float.IsNaN(q.w)||float.IsInfinity(q.x)||float.IsInfinity(q.y)||float.IsInfinity(q.z)||float.IsInfinity(q.w));
        void OnDestroy() { KnightDeathPresentation.Active.Remove(this); }
    }
}
