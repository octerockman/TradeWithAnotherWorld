// Generated from the accepted complete skin/equipment at120Hz by checks/death-space-profile.py.
namespace BlackAbbey.ReliquaryKnight {
 public static class KnightDeathSpaceProfile {
  public const string ClipId="a000_010060";
  public const float MaximumYUnscaled=4.050628234f;
  public const float MinimumXUnscaled=-1.356772108f,MaximumXUnscaled=2.513695990f;
  public const float MinimumZUnscaled=-1.872112459f,MaximumZUnscaled=1.842769700f;
  public const float HorizontalRadiusUnscaled=2.854072052f;
 }
}
