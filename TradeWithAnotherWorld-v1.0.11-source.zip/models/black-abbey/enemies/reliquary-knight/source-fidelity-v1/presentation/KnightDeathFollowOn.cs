using System;
namespace BlackAbbey.ReliquaryKnight {
 // The supplied011001 already starts prone. Jesse explicitly selected its
 // complete performance as a possible post-forward-fall continuation.
 public static class KnightDeathFollowOn {
  public const string PrimaryClipId=KnightDeathFollowOnPolicy.PrimaryClipId,ClipId=KnightDeathFollowOnPolicy.ClipId;
  public const double EntryBlendSeconds=KnightDeathFollowOnPolicy.EntryBlendSeconds;
  public static KnightClip Clip {get;private set;}
  public static void Prepare(KnightMotionBank bank){
   if(Clip!=null)return;
   if(bank==null||!bank.Has(ClipId))throw new InvalidOperationException("Forward-fall follow-on source unavailable");
   var clip=bank.Get(ClipId);
   if(clip.id!=ClipId||clip.frames==null||clip.frames.Length!=168||Math.Abs(clip.duration-5.566667)>1e-5)throw new InvalidOperationException("Unexpected forward-fall follow-on source");
   Clip=clip;
  }
  public static bool Choose(string primaryClip,int identity,long hpZeroTicks)=>KnightDeathFollowOnPolicy.Choose(primaryClip,identity,hpZeroTicks);
  public static bool ValidPair(string primaryClip,string followClip)=>KnightDeathFollowOnPolicy.ValidPair(primaryClip,followClip);
  public static float EntryBlend(double elapsed)=>KnightDeathFollowOnPolicy.EntryBlend(elapsed);
  public static float MinimumY(double at)=>KnightDeathFollowOnFloorProfile.MinimumY(at);
  public static void Shutdown(){Clip=null;}
 }
}
