using System;
using System.Collections.Generic;
namespace BlackAbbey.ReliquaryKnight
{
    // This pure layout is also exercised by offline coverage checks. It maps
    // every source bone, including source roots and the separate Spine branch.
    public sealed class KnightRagdollPart
    {
        public string Bone, End, Parent, JointAnchor;
        public float Radius, Mass;
        public KnightRagdollPart(string bone,string end,string parent,float radius,float mass,string jointAnchor=null)
        { Bone=bone;End=end;Parent=parent;Radius=radius;Mass=mass;JointAnchor=jointAnchor??bone; }
    }
    public static class KnightRagdollLayout
    {
        public static readonly KnightRagdollPart[] Parts = {
            new KnightRagdollPart("Pelvis","Spine",null,.16f,13),
            new KnightRagdollPart("Spine1","Neck","Pelvis",.19f,22,"Spine"),
            new KnightRagdollPart("Head","Jaw","Spine1",.13f,5,"Neck"),
            new KnightRagdollPart("L_UpperArm","L_Forearm","Spine1",.07f,3),
            new KnightRagdollPart("L_Forearm","L_Hand","L_UpperArm",.06f,2),
            new KnightRagdollPart("R_UpperArm","R_Forearm","Spine1",.07f,3),
            new KnightRagdollPart("R_Forearm","R_Hand","R_UpperArm",.06f,2),
            new KnightRagdollPart("L_Thigh","L_Calf","Pelvis",.10f,7),
            new KnightRagdollPart("L_Calf","L_Foot","L_Thigh",.075f,4),
            new KnightRagdollPart("L_Foot","L_Toe0","L_Calf",.07f,1.5f),
            new KnightRagdollPart("R_Thigh","R_Calf","Pelvis",.10f,7),
            new KnightRagdollPart("R_Calf","R_Foot","R_Thigh",.075f,4),
            new KnightRagdollPart("R_Foot","R_Toe0","R_Calf",.07f,1.5f)
        };
        public static int[] Bind(string[] names,int[] parents)
        {
            if(names==null||parents==null||names.Length!=138||parents.Length!=names.Length)
                throw new ArgumentException("Expected the complete138-bone source hierarchy");
            var indices=new Dictionary<string,int>(StringComparer.Ordinal);
            for(int i=0;i<names.Length;i++) {
                if(string.IsNullOrEmpty(names[i])||parents[i]>=i||parents[i]<-1||indices.ContainsKey(names[i]))
                    throw new ArgumentException("Invalid source hierarchy");
                indices.Add(names[i],i);
            }
            var physical=new Dictionary<int,int>();
            for(int i=0;i<Parts.Length;i++) {
                if(!indices.ContainsKey(Parts[i].Bone)||!indices.ContainsKey(Parts[i].End)||!indices.ContainsKey(Parts[i].JointAnchor))
                    throw new ArgumentException("Missing source anatomy "+Parts[i].Bone);
                physical.Add(indices[Parts[i].Bone],i);
            }
            var result=new int[names.Length];
            for(int i=0;i<names.Length;i++) {
                string name=names[i];
                if(name=="Spine") { result[i]=1;continue; }
                if(name.StartsWith("L_Foot_Target",StringComparison.Ordinal)) { result[i]=9;continue; }
                if(name.StartsWith("R_Foot_Target",StringComparison.Ordinal)) { result[i]=12;continue; }
                int at=i,part=-1;
                while(at>=0) {
                    if(physical.TryGetValue(at,out part))break;
                    at=parents[at];
                }
                // Master and Root have no anatomical parent. They must move
                // with the pelvis, never remain on a fixed world-space root.
                result[i]=at<0?0:part;
            }
            return result;
        }
    }
}
