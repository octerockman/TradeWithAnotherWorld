using System;
namespace BlackAbbey.ReliquaryKnight {
 // Only full ordinary death sequences are admitted. Tiny terminal poses and
 // paired finishers cannot replace one of these cause-specific performances.
 public static class KnightDeathVariantPolicy {
  public static readonly string[] ClipIds={"a000_010000","a000_010010","a000_010030","a000_010040","a000_010050","a000_010060"};
  public static bool IsSupported(string id)=>id=="a000_010000"||id=="a000_010010"||id=="a000_010030"||id=="a000_010040"||id=="a000_010050"||id=="a000_010060";
  public static string OrDefault(string id)=>IsSupported(id)?id:KnightDeathClock.DefaultClip;
  public static bool ValidDuration(string id,double duration)=>IsSupported(id)&&!double.IsNaN(duration)&&!double.IsInfinity(duration)&&duration>0.1&&duration<=10;
 }
}
