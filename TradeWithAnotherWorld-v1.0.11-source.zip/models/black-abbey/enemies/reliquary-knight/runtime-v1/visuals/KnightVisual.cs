using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace BlackAbbey.ReliquaryKnight
{
    [Serializable] public sealed class KnightFileRecord {
        public string path, sha256, format; public long bytes; public int width, height, mipCount;
    }
    [Serializable] public sealed class KnightBoneRecord {
        public string name; public int parentIndex; public float[] position, rotation, scale, worldRest, inverseBind;
    }
    [Serializable] public sealed class KnightWeightRecord {
        public int boneIndex0, boneIndex1, boneIndex2, boneIndex3;
        public float weight0, weight1, weight2, weight3;
    }
    [Serializable] public sealed class KnightMeshRecord {
        public string name, materialId; public int vertexCount, triangleCount;
        public float[] positions, normals, tangents, uv, boundsCenter, boundsSize;
        public int[] triangles; public KnightWeightRecord[] weights; public string[] sourceMeshes;
    }
    [Serializable] public sealed class KnightMaterialRecord {
        public string id, nativeName; public KnightFileRecord diffuse, normal, metallicGloss;
    }
    [Serializable] public sealed class ContactRecord {
        public string kind, boneName, units; public int boneIndex, fitVertexCount;
        public float[] center, rotation, halfExtents, capsuleStart, capsuleEnd;
        public float capsuleRadius, fitMaxAbsError; public string[] sourceMeshes;
    }
    [Serializable] public sealed class KnightVisualPayload {
        public string schema; public KnightFileRecord sourceNative, sourceSkin;
        public float actorScale; public float[] nativeToUnity;
        public KnightBoneRecord[] bones; public KnightMeshRecord[] renderers; public KnightMaterialRecord[] materials;
        public ContactRecord sword, shield; public int totalTriangles;
        public bool containsGameOwnedMeshes, containsAnimationClips;
    }

    /// <summary>Own geometry, exact generic source rig and baked native materials; no Avatar or retargeting.</summary>
    public sealed class KnightVisual : IDisposable
    {
        public Transform RootRig { get; private set; }
        public Transform[] Bones { get; private set; }
        public Matrix4x4[] NativeRestWorldUnity { get; private set; }
        public readonly Dictionary<string, Transform> Named = new Dictionary<string, Transform>(StringComparer.Ordinal);
        public readonly List<SkinnedMeshRenderer> Skins = new List<SkinnedMeshRenderer>();
        public ContactRecord Sword { get { return Payload.sword; } }
        public ContactRecord Shield { get { return Payload.shield; } }
        public KnightVisualPayload Payload { get; private set; }
        readonly List<Object> owned = new List<Object>();
        readonly Dictionary<string, Material> materialById = new Dictionary<string, Material>(StringComparer.Ordinal);

        public static KnightVisual Create(GameObject actor, string folder, Material template)
        {
            if (!actor || !template) throw new ArgumentNullException("Knight actor/material template");
            var result = new KnightVisual();
            try { result.Construct(actor, folder, template); return result; }
            catch { result.Dispose(); throw; }
        }

        void Construct(GameObject actor, string folder, Material template)
        {
            foreach (string property in new[] { "_MainTex", "_BumpMap", "_MetallicGlossMap" })
                if (!template.HasProperty(property)) throw new InvalidDataException("Knight material template lacks " + property);
            string path = Safe(folder, "runtime-visual.json.gz");
            if (new FileInfo(path).Length > 20 * 1024 * 1024) throw new InvalidDataException("Oversized Knight visual payload");
            using (var stream = File.OpenRead(path))
            using (var gzip = new GZipStream(stream, CompressionMode.Decompress))
            using (var text = new StreamReader(gzip))
            using (var json = new JsonTextReader(text) { MaxDepth = 64 })
                Payload = new JsonSerializer().Deserialize<KnightVisualPayload>(json);
            if (Payload == null || Payload.schema != "black-abbey.reliquary-knight.runtime-visual.v1" ||
                Payload.bones == null || Payload.bones.Length != 138 || Payload.totalTriangles != 20628 ||
                Payload.containsGameOwnedMeshes || Payload.containsAnimationClips ||
                !Finite(Payload.actorScale) || Mathf.Abs(Payload.actorScale - .7846478819847107f) > 1e-6f)
                throw new InvalidDataException("Unexpected Knight source contract");
            RootRig = new GameObject("RK_VisualRig").transform;
            RootRig.SetParent(actor.transform, false); RootRig.localScale = Vector3.one * Payload.actorScale;
            RootRig.gameObject.layer = actor.layer;
            Bones = new Transform[Payload.bones.Length]; NativeRestWorldUnity = new Matrix4x4[Bones.Length];
            for (int i = 0; i < Bones.Length; i++) {
                var record = Payload.bones[i];
                if (string.IsNullOrEmpty(record.name) || Named.ContainsKey(record.name) || record.parentIndex >= i || record.parentIndex < -1)
                    throw new InvalidDataException("Invalid Knight generic hierarchy");
                var bone = new GameObject(record.name).transform;
                bone.SetParent(record.parentIndex < 0 ? RootRig : Bones[record.parentIndex], false);
                bone.localPosition = V(record.position); bone.localRotation = Q(record.rotation); bone.localScale = V(record.scale);
                if ((bone.localScale - Vector3.one).sqrMagnitude > 1e-8f) throw new InvalidDataException("Bone scale must be unit; actor carries the single scale");
                bone.gameObject.layer = actor.layer;
                Bones[i] = bone; Named.Add(record.name, bone); NativeRestWorldUnity[i] = M(record.worldRest);
            }
            foreach (var material in Payload.materials) materialById.Add(material.id, MakeMaterial(template, folder, material));
            var binds = Payload.bones.Select(b => M(b.inverseBind)).ToArray();
            int triangleCount = 0;
            foreach (var record in Payload.renderers) {
                var go = new GameObject(record.name); go.transform.SetParent(RootRig, false); go.layer = actor.layer;
                var mesh = MakeMesh(record); mesh.bindposes = binds; mesh.boneWeights = record.weights.Select(Weight).ToArray();
                var skin = go.AddComponent<SkinnedMeshRenderer>();
                skin.sharedMesh = mesh; skin.bones = Bones; skin.rootBone = Bones[0];
                skin.sharedMaterial = materialById[record.materialId]; skin.quality = SkinQuality.Bone4;
                // Covers the exact generic rig's extended sword, knees and ground falls without pose-time bounds churn.
                skin.localBounds = new Bounds(new Vector3(0, 1, 0), new Vector3(12, 12, 12));
                skin.updateWhenOffscreen = false; skin.shadowCastingMode = ShadowCastingMode.On; skin.receiveShadows = true;
                Skins.Add(skin); triangleCount += record.triangleCount;
            }
            if (triangleCount != Payload.totalTriangles) throw new InvalidDataException("Knight triangle count changed");
            ValidateContact(Sword, 133, "R_Sword"); ValidateContact(Shield, 96, "L_Shield");
        }

        static void ValidateContact(ContactRecord c, int index, string name)
        {
            if (c == null || c.boneIndex != index || c.boneName != name || c.fitVertexCount < 3 || c.fitMaxAbsError > 1e-5f)
                throw new InvalidDataException("Invalid Knight source-fitted contact");
            var ext = V(c.halfExtents); V(c.center); Q(c.rotation); V(c.capsuleStart); V(c.capsuleEnd);
            if (ext.x <= 0 || ext.y <= 0 || ext.z <= 0 || !Finite(c.capsuleRadius) || c.capsuleRadius <= 0)
                throw new InvalidDataException("Empty Knight contact volume");
        }
        static bool Finite(float v) { return !float.IsNaN(v) && !float.IsInfinity(v); }
        public static Vector3 V(float[] a) {
            if (a == null || a.Length != 3 || a.Any(n => !Finite(n))) throw new InvalidDataException("Invalid Knight vector");
            return new Vector3(a[0], a[1], a[2]);
        }
        public static Quaternion Q(float[] a) {
            if (a == null || a.Length != 4 || a.Any(n => !Finite(n))) throw new InvalidDataException("Invalid Knight quaternion");
            var q = new Quaternion(a[0], a[1], a[2], a[3]);
            if (Mathf.Abs(Quaternion.Dot(q, q) - 1) > .002f) throw new InvalidDataException("Nonunit Knight quaternion");
            return q;
        }
        public static Matrix4x4 M(float[] a) {
            if (a == null || a.Length != 16 || a.Any(n => !Finite(n))) throw new InvalidDataException("Invalid Knight matrix");
            var m = new Matrix4x4(); for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) m[i, j] = a[i * 4 + j]; return m;
        }
        static BoneWeight Weight(KnightWeightRecord w) {
            var indices = new[] { w.boneIndex0, w.boneIndex1, w.boneIndex2, w.boneIndex3 };
            var values = new[] { w.weight0, w.weight1, w.weight2, w.weight3 };
            if (indices.Any(i => i < 0 || i >= 138) || values.Any(v => !Finite(v) || v < 0 || v > 1) || Mathf.Abs(values.Sum() - 1) > .0001f)
                throw new InvalidDataException("Invalid Knight four-weight skin");
            return new BoneWeight { boneIndex0 = w.boneIndex0, boneIndex1 = w.boneIndex1, boneIndex2 = w.boneIndex2, boneIndex3 = w.boneIndex3,
                weight0 = w.weight0, weight1 = w.weight1, weight2 = w.weight2, weight3 = w.weight3 };
        }
        Mesh MakeMesh(KnightMeshRecord r) {
            int n = r.vertexCount;
            if (n < 3 || n > 100000 || r.positions == null || r.positions.Length != n * 3 || r.normals == null || r.normals.Length != n * 3 ||
                r.tangents == null || r.tangents.Length != n * 4 || r.uv == null || r.uv.Length != n * 2 || r.weights == null || r.weights.Length != n ||
                r.triangles == null || r.triangles.Length != r.triangleCount * 3 || r.triangles.Any(i => i < 0 || i >= n) ||
                r.positions.Concat(r.normals).Concat(r.tangents).Concat(r.uv).Any(v => !Finite(v))) throw new InvalidDataException("Invalid Knight mesh arrays");
            var positions = new Vector3[n]; var normals = new Vector3[n]; var tangents = new Vector4[n]; var uv = new Vector2[n];
            for (int i = 0; i < n; i++) {
                positions[i] = new Vector3(r.positions[i * 3], r.positions[i * 3 + 1], r.positions[i * 3 + 2]);
                normals[i] = new Vector3(r.normals[i * 3], r.normals[i * 3 + 1], r.normals[i * 3 + 2]);
                tangents[i] = new Vector4(r.tangents[i * 4], r.tangents[i * 4 + 1], r.tangents[i * 4 + 2], r.tangents[i * 4 + 3]);
                uv[i] = new Vector2(r.uv[i * 2], r.uv[i * 2 + 1]);
            }
            var mesh = new Mesh { name = r.name, indexFormat = n > 65535 ? IndexFormat.UInt32 : IndexFormat.UInt16 };
            owned.Add(mesh); mesh.vertices = positions; mesh.normals = normals; mesh.tangents = tangents; mesh.uv = uv;
            mesh.triangles = r.triangles; mesh.RecalculateBounds(); return mesh;
        }
        public static string Hash(string path) {
            using (var h = SHA256.Create()) using (var stream = File.OpenRead(path)) return string.Concat(h.ComputeHash(stream).Select(b => b.ToString("x2")));
        }
        public static string Safe(string folder, string relative) {
            if (string.IsNullOrWhiteSpace(relative) || Path.IsPathRooted(relative)) throw new InvalidDataException("Expected relative Knight data path");
            string root = Path.GetFullPath(folder).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string path = Path.GetFullPath(Path.Combine(root, relative));
            if (!path.StartsWith(root, StringComparison.OrdinalIgnoreCase) || !File.Exists(path)) throw new InvalidDataException("Outside/missing Knight data");
            return path;
        }
        Texture2D Texture(string folder, KnightFileRecord record, bool linear) {
            if (record == null) return null;
            string path = Safe(folder, record.path);
            if (new FileInfo(path).Length > 32 * 1024 * 1024 || Hash(path) != record.sha256) throw new InvalidDataException("Knight texture source mismatch: " + record.path);
            if (record.format != "BC3" || record.width < 1 || record.height < 1 || record.width > 4096 || record.height > 4096 ||
                (record.width & (record.width - 1)) != 0 || (record.height & (record.height - 1)) != 0 ||
                !SystemInfo.SupportsTextureFormat(TextureFormat.DXT5)) throw new InvalidDataException("Unsupported Knight BC3 texture");
            int expected = 0, levels = 0, w = record.width, h = record.height;
            while (true) {
                expected += Math.Max(1, (w + 3) / 4) * Math.Max(1, (h + 3) / 4) * 16; levels++;
                if (w == 1 && h == 1) break; w = Math.Max(1, w / 2); h = Math.Max(1, h / 2);
            }
            if (record.mipCount != levels || new FileInfo(path).Length != expected) throw new InvalidDataException("Invalid Knight BC3 mip chain");
            var texture = new Texture2D(record.width, record.height, TextureFormat.DXT5, true, linear); owned.Add(texture);
            texture.LoadRawTextureData(File.ReadAllBytes(path)); texture.Apply(false, true);
            texture.name = "RK_" + record.path; texture.wrapMode = TextureWrapMode.Clamp; texture.filterMode = FilterMode.Trilinear; texture.anisoLevel = 4; return texture;
        }
        Material MakeMaterial(Material template, string folder, KnightMaterialRecord record) {
            var material = new Material(template) { name = "RK_" + record.id }; owned.Add(material);
            foreach (string property in material.GetTexturePropertyNames()) {
                material.SetTexture(property, null); material.SetTextureScale(property, Vector2.one); material.SetTextureOffset(property, Vector2.zero);
            }
            material.SetColor("_Color", Color.white); material.SetTexture("_MainTex", Texture(folder, record.diffuse, false));
            material.DisableKeyword("_NORMALMAP"); material.DisableKeyword("_METALLICGLOSSMAP");
            if (record.normal != null) { material.SetTexture("_BumpMap", Texture(folder, record.normal, true)); material.SetFloat("_BumpScale", 1); material.EnableKeyword("_NORMALMAP"); }
            if (record.metallicGloss != null) { material.SetTexture("_MetallicGlossMap", Texture(folder, record.metallicGloss, true)); material.SetFloat("_UseGlossmap", 1); material.EnableKeyword("_METALLICGLOSSMAP"); }
            foreach (string property in new[] { "_Hue", "_Saturation", "_Value", "_UseStyles", "_Style", "_NoiseGlowEnabled", "_SnowCover", "_AddRain" })
                if (material.HasProperty(property)) material.SetFloat(property, 0);
            if (material.HasProperty("_MetalColor")) material.SetColor("_MetalColor", Color.white);
            if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", 1);
            if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", 1);
            if (material.HasProperty("_EmissionColor")) material.SetColor("_EmissionColor", Color.black);
            material.DisableKeyword("_ALPHATEST_ON"); material.DisableKeyword("_EMISSION"); return material;
        }
        public void Dispose() {
            if (RootRig) Object.Destroy(RootRig.gameObject);
            foreach (var resource in owned) if (resource) Object.Destroy(resource);
            owned.Clear(); Skins.Clear(); Named.Clear(); RootRig = null;
        }
    }
}
