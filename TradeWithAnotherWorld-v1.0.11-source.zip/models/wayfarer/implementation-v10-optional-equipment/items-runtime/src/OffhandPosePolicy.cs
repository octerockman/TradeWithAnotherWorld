using System;
namespace Wayfarer.Items
{
    // Source timeline only; no engine objects or generic animation substitution.
    public static class OffhandPosePolicy
    {
        public static bool EmitDue(float elapsed,float eventAt,bool alreadyFired)=>!alreadyFired&&!float.IsNaN(elapsed)&&!float.IsInfinity(elapsed)&&elapsed>=eventAt;
        public static void Sample(float elapsed,float duration,int count,out int a,out int b,out float alpha)
        {
            if(count<2||duration<=0||float.IsNaN(elapsed)||float.IsInfinity(elapsed))throw new ArgumentOutOfRangeException();float phase=Math.Max(0,Math.Min(1,elapsed/duration));float f=phase*(count-1);a=(int)f;b=Math.Min(a+1,count-1);alpha=f-a;
        }
    }
}
