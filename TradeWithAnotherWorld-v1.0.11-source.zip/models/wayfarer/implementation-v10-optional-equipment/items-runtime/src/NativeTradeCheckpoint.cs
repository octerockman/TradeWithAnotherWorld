using System;
using HarmonyLib;

namespace Wayfarer.Items
{
    // Persist the transaction receipt inside the same native character save as
    // its inventory. A disconnect cannot leave a paid receipt in an unrelated
    // local file while the character still has its earlier inventory snapshot.
    public static class NativeTradeCheckpoint
    {
        public static bool ApplyingInventory{get;internal set;}
        static PlayerProfile expected;
        static bool? saved;
        public static bool Save(Player player)
        {
            if(!Game.instance||player!=Player.m_localPlayer)return false;
            expected=Game.instance.GetPlayerProfile();saved=null;
            try{Game.instance.SavePlayerProfile(false,false);return saved==true;}
            catch{if(saved==true)return true;throw;}
            finally{expected=null;}
        }
        internal static void Observe(PlayerProfile profile,bool result)
        {if(ReferenceEquals(profile,expected))saved=result;}
    }
    [HarmonyPatch(typeof(Game),nameof(Game.SavePlayerProfile))]
    static class PreventPartialTradeSave
    {[HarmonyPriority(Priority.First)]static bool Prefix()=>!NativeTradeCheckpoint.ApplyingInventory;}
    [HarmonyPatch(typeof(PlayerProfile),nameof(PlayerProfile.Save))]
    static class NativeTradeSaveReceipt
    {
        [HarmonyPriority(Priority.First)]static bool Prefix(ref bool __result)
        {if(!NativeTradeCheckpoint.ApplyingInventory)return true;__result=false;return false;}
        static void Postfix(PlayerProfile __instance,bool __result)=>NativeTradeCheckpoint.Observe(__instance,__result);
    }
}
