using System;
using System.Linq;
using System.Reflection;
using HarmonyLib;

namespace Wayfarer.Items
{
    // Optional integration. The installed lantern module and its ordinary fuel
    // rates remain intact; only an actually consumed Wayfarer resin changes the
    // duration of that particular fuel charge.
    public static class RefinedResinCompatibility
    {
        static Type stateType,rulesType,variantsType,backpackType;
        static PropertyInfo remaining,needsRelight;
        public static void Initialize(Harmony harmony)
        {
            stateType=AccessTools.TypeByName("OctoPack_addon_Lantern.FuelState");if(stateType==null)return;
            rulesType=AccessTools.TypeByName("OctoPack_addon_Lantern.LanternFuelRules");variantsType=AccessTools.TypeByName("OctoPack_addon_Lantern.LanternVariants");backpackType=AccessTools.TypeByName("OctoPack_addon_Lantern.BackpackBridge");
            remaining=AccessTools.Property(stateType,"Remaining");needsRelight=AccessTools.Property(stateType,"NeedsRelight");
            var advance=AccessTools.Method(stateType,"Advance",new[]{typeof(double),typeof(bool),typeof(Func<bool>),typeof(double)});
            var relight=AccessTools.Method(stateType,"Relight",new[]{typeof(bool),typeof(Func<bool>),typeof(double)});
            var decode=AccessTools.Method(stateType,"Decode",new[]{typeof(string),typeof(double)});
            if(remaining?.GetSetMethod(true)==null||needsRelight?.GetSetMethod(true)==null||advance==null||relight==null||decode==null||rulesType==null||variantsType==null||backpackType==null)throw new InvalidOperationException("Installed lantern fuel contract changed; refined resin adapter not applied.");
            harmony.Patch(advance,new HarmonyMethod(typeof(RefinedResinCompatibility),nameof(Advance)));
            harmony.Patch(relight,new HarmonyMethod(typeof(RefinedResinCompatibility),nameof(Relight)));
            harmony.Patch(decode,new HarmonyMethod(typeof(RefinedResinCompatibility),nameof(Decode)));
            ItemsPlugin.Instance.Report("REFINED_RESIN_ADAPTER regular=3600s magic=1800s ordinary_fuel_unchanged=true");
        }
        static void Decode(ref double __1){__1=Math.Max(__1,3600);}
        static bool Context(Func<bool> consume,out Inventory inventory,out Player owner,out int kind)
        {
            inventory=null;owner=null;kind=0;var target=consume?.Target;string type=target?.GetType().FullName;
            if(type!="OctoPack_addon_Lantern.LanternPlugin"&&type!="OctoPack_addon_Lantern.PortableLanternRig")return false;
            var lamp=AccessTools.Field(target.GetType(),"lamp")?.GetValue(target) as ItemDrop.ItemData;if(lamp==null)return false;
            kind=(int)AccessTools.Method(variantsType,"Of").Invoke(null,new object[]{lamp});if(kind==6)return false;
            if(type.EndsWith(".PortableLanternRig",StringComparison.Ordinal))inventory=AccessTools.Field(target.GetType(),"contents")?.GetValue(target) as Inventory;
            else{owner=AccessTools.Field(target.GetType(),"owner")?.GetValue(target) as Player;if(owner)inventory=owner.GetInventory();}
            return inventory!=null;
        }
        static bool Charge(Func<bool> original,Inventory inventory,Player owner,int kind,double ordinary,out double duration)
        {
            duration=ordinary;
            var resin=inventory.GetAllItems().FirstOrDefault(i=>i.m_stack>0&&ItemsPlugin.Instance.Catalogue.TryItem(i,out var d)&&d.Id=="refined_resin"&&(!owner||(bool)AccessTools.Method(backpackType,"InBackpack").Invoke(null,new object[]{owner,i})));
            if(resin!=null&&inventory.RemoveItem(resin,1)){duration=kind==0?3600:1800;return true;}
            return original();
        }
        static bool Advance(object __instance,double __0,bool __1,Func<bool> __2,double __3,ref bool __result)
        {
            if(!Context(__2,out var inventory,out var owner,out int kind))return true;
            double seconds=__0,left=(double)remaining.GetValue(__instance);bool off=(bool)needsRelight.GetValue(__instance);__result=false;
            if(!__1||off||double.IsNaN(seconds)||double.IsInfinity(seconds)||seconds<0)return false;
            if(left<=0){if(!Charge(__2,inventory,owner,kind,__3,out left)){needsRelight.SetValue(__instance,true);__result=true;return false;}__result=true;}
            while(seconds>=left)
            {
                seconds-=left;left=0;__result=true;
                if(!Charge(__2,inventory,owner,kind,__3,out left)){remaining.SetValue(__instance,0d);needsRelight.SetValue(__instance,true);return false;}
            }
            remaining.SetValue(__instance,left-seconds);return false;
        }
        static bool Relight(object __instance,bool __0,Func<bool> __1,double __2,ref bool __result)
        {
            if(!Context(__1,out var inventory,out var owner,out int kind))return true;
            __result=false;if(!__0)return false;double left=(double)remaining.GetValue(__instance);
            if(left<=0&&!Charge(__1,inventory,owner,kind,__2,out left))return false;
            remaining.SetValue(__instance,left);needsRelight.SetValue(__instance,false);__result=true;return false;
        }
    }
}
