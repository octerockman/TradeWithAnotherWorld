using System;
namespace Wayfarer.Items
{
    public struct OffhandButtons
    {public bool attack,attackHold,block,blockHold,offhand,clearMainQueue;}
    public sealed class OffhandChordPolicy
    {
        public const double RecognitionSeconds=.080;
        double pendingAt=-1;
        bool chordLatched,leftCommitted;
        public void Reset(){pendingAt=-1;chordLatched=false;leftCommitted=false;}
        public OffhandButtons Step(double now,bool leftDown,bool leftHeld,bool rightDown,bool rightHeld,bool actionBusy,bool hasOffhand)
        {
            var result=new OffhandButtons{attack=leftDown,attackHold=leftHeld,block=rightDown,blockHold=rightHeld};
            if(!hasOffhand){Reset();return result;}
            if(!leftHeld){leftCommitted=false;if(!rightHeld)chordLatched=false;}
            if(actionBusy){pendingAt=-1;result.attack=result.attackHold=result.block=result.blockHold=false;result.clearMainQueue=true;return result;}
            if(chordLatched)
            {
                if(!leftHeld){chordLatched=false;}
                else{result.attack=result.attackHold=false;if(rightHeld){result.block=result.blockHold=false;}return result;}
            }
            if(leftDown&&!leftCommitted)pendingAt=now;
            if(pendingAt>=0&&leftHeld&&(rightHeld||rightDown))
            {
                pendingAt=-1;chordLatched=true;result.offhand=true;result.clearMainQueue=true;
                result.attack=result.attackHold=result.block=result.blockHold=false;return result;
            }
            if(pendingAt>=0)
            {
                result.attack=result.attackHold=false;
                if(now-pendingAt>=RecognitionSeconds){pendingAt=-1;result.attack=true;result.attackHold=leftHeld;leftCommitted=leftHeld;}
            }
            return result;
        }
    }
}
