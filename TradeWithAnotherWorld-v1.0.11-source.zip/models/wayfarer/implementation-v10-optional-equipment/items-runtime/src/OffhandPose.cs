using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using HarmonyLib;
using Newtonsoft.Json.Linq;
using UnityEngine;
using Object=UnityEngine.Object;
using Wayfarer.InGame;
namespace Wayfarer.Items
{
    public sealed class OffhandPoseEvent {public string name;public float time;}
    public sealed class OffhandPropPose {public float[] Gravity,Swing;}
    public sealed class OffhandPoseClip
    {
        public string actionId,family,actionName,sourceNPCReference;public float duration;public OilPoseFrame[] frames;public OffhandPoseEvent[] events;public OffhandPropPose[] propFrames;
        internal OilRuntimePose[][] samples;
    }
    public sealed class OffhandPosePayload
    {public string schema,stage;public string[] boneNames;public MatrixRecord[] nativeBodyBindposes;public Dictionary<string,OilBonePose[]> ready;public OffhandPoseClip[] clips;}
    public static class OffhandPose
    {
        internal const string StampKey="TWA_WF_OffhandPose_v1",ActionKey="TWA_WF_OffhandAction_v1";
        static OffhandPosePayload payload;static float warningAt;
        static readonly string[] Actions={"bell_ring","torch_swing","torch_wide_sweep","censer_low_sweep","censer_flick"};
        internal static OffhandPosePayload Load()
        {
            if(payload!=null)return payload;var plugin=ItemsPlugin.Instance;if(!plugin)throw new InvalidOperationException("Item module unavailable.");
            string folder=Path.Combine(plugin.DataDirectory,"assets","motions","offhand");var m=RuntimeCatalogue.ReadJson(Path.Combine(folder,"manifest.json"),1024*1024);var r=m["motion"]??throw new InvalidDataException("Offhand motion manifest missing.");string path=PayloadReader.Safe(folder,r.Value<string>("path"));if(PayloadReader.Hash(path)!=r.Value<string>("sha256"))throw new InvalidDataException("Offhand motion checksum changed.");var p=PayloadReader.Read<OffhandPosePayload>(path);
            if(p?.schema!="wayfarer.player-offhand-motion.v1"||p.stage!="OFFLINE_CHECKED_AWAITING_JESSE"||p.boneNames?.Length!=53||p.nativeBodyBindposes?.Length!=53||p.ready?.Count!=3||p.clips?.Length!=5||!p.clips.Select(c=>c.actionId).OrderBy(x=>x).SequenceEqual(Actions.OrderBy(x=>x)))throw new InvalidDataException("Offhand native53 action contract changed.");
            foreach(var b in p.nativeBodyBindposes)PayloadReader.M(b);
            foreach(var ready in p.ready.Values)CheckPoses(ready);
            foreach(var c in p.clips)
            {
                if(!PayloadReader.Finite(c.duration)||c.duration<.3f||c.duration>5||c.frames?.Length<2||c.frames.Length>180||c.events?.Length!=1||c.events[0].name!="emit"||!PayloadReader.Finite(c.events[0].time)||c.events[0].time<=.12f||c.events[0].time>=c.duration-.12f||c.propFrames?.Length!=c.frames.Length)throw new InvalidDataException("Offhand action events/budget changed.");
                for(int i=0;i<c.frames.Length;i++){if(Math.Abs(c.frames[i].time-c.duration*i/(c.frames.Length-1))>.0001f)throw new InvalidDataException("Offhand sample time changed.");CheckPoses(c.frames[i].bones);PayloadReader.Q(c.propFrames[i].Gravity);PayloadReader.Q(c.propFrames[i].Swing);}
                c.samples=c.frames.Select(f=>f.bones.Select(From).ToArray()).ToArray();
            }
            payload=p;return p;
        }
        static void CheckPoses(OilBonePose[] poses)
        {if(poses?.Length!=53)throw new InvalidDataException("Offhand pose needs53native bones.");foreach(var b in poses){PayloadReader.V(b.position);PayloadReader.Q(b.rotation);var s=PayloadReader.V(b.scale);if(s.x<=0||s.y<=0||s.z<=0)throw new InvalidDataException("Offhand native scale invalid.");}}
        internal static OilRuntimePose From(OilBonePose b)=>new OilRuntimePose{position=PayloadReader.V(b.position),rotation=PayloadReader.Q(b.rotation),scale=PayloadReader.V(b.scale)};
        internal static Transform[] Bind(Player p,OffhandPosePayload source)=>OilMotion.Bind(p,new OilMotionPayload{boneNames=source.boneNames,nativeBodyBindposes=source.nativeBodyBindposes});
        public static bool TryDescribe(string actionId,out float duration,out float emitAt)
        {duration=emitAt=0;try{var c=Load().clips.FirstOrDefault(x=>x.actionId==actionId);if(c==null)return false;duration=c.duration;emitAt=c.events[0].time;return true;}catch(Exception e){Warn("OFFHAND_SOURCE_NOT_READY "+e.Message);return false;}}
        public static bool IsBusy(Player p)=>p&&p.GetComponent<OffhandPoseDriver>()?.Active==true;
        public static bool CanCancel(Player p)=>!IsBusy(p);
        public static void Cancel(Player p){if(p)p.GetComponent<OffhandPoseDriver>()?.StopMotion();}
        public static bool TryBegin(Player p,string actionId,Action<string> atEvent,Action completed)
        {
            var view=p?p.GetComponent<ZNetView>():null;if(!p||p!=Player.m_localPlayer||p.IsDead()||!view||!view.IsValid()||!view.IsOwner()||!ZNet.instance||IsBusy(p)||OilMotion.IsBusy(p)||atEvent==null)return false;
            try{var bank=Load();var clip=bank.clips.FirstOrDefault(c=>c.actionId==actionId);if(clip==null||!OffhandPoseMount.GetSocket(p,"Grip"))return false;var bones=Bind(p,bank);var driver=p.GetComponent<OffhandPoseDriver>()??p.gameObject.AddComponent<OffhandPoseDriver>();driver.Begin(p,clip,bones,atEvent,completed);return true;}catch(Exception e){Warn("OFFHAND_POSE_REFUSED "+e.Message);return false;}
        }
        internal static void Observe(Player p)
        {
            if(!p||p.IsDead())return;var mount=p.GetComponent<OffhandPoseMountDriver>()??p.gameObject.AddComponent<OffhandPoseMountDriver>();mount.Player=p;
            if(p==Player.m_localPlayer)return;var view=p.GetComponent<ZNetView>();if(!view||!view.IsValid())return;long stamp=view.GetZDO().GetLong(StampKey,0);if(stamp<=0)return;string aid=view.GetZDO().GetString(ActionKey,"");var old=p.GetComponent<OffhandPoseDriver>();if(old&&old.Stamp==stamp)return;
            try{var bank=Load();var c=bank.clips.FirstOrDefault(x=>x.actionId==aid);if(c==null||OilMotion.NetworkNow-stamp/1000.0>c.duration+.15)return;var bones=Bind(p,bank);(old??p.gameObject.AddComponent<OffhandPoseDriver>()).BeginRemote(p,c,bones,stamp);}catch(Exception e){Warn("OFFHAND_REMOTE_REFUSED "+e.Message);}
        }
        internal static void Warn(string t){if(Time.unscaledTime<warningAt)return;warningAt=Time.unscaledTime+5;ItemsPlugin.Instance?.Warn(t);}
        internal static void Sample(OffhandPoseClip c,float seconds,out int a,out int b,out float t)=>OffhandPosePolicy.Sample(seconds,c.duration,c.frames.Length,out a,out b,out t);
        internal static void Dispose(){foreach(var d in Object.FindObjectsByType<OffhandPoseDriver>(FindObjectsInactive.Include,FindObjectsSortMode.None))d.StopMotion();foreach(var d in Object.FindObjectsByType<OffhandPoseMountDriver>(FindObjectsInactive.Include,FindObjectsSortMode.None))Object.Destroy(d);OffhandPoseMount.Dispose();payload=null;}
    }
    [DefaultExecutionOrder(8050)]
    public sealed class OffhandPoseDriver:MonoBehaviour
    {
        public bool Active{get;private set;}public float Elapsed{get;private set;}public long Stamp{get;private set;}internal OffhandPoseClip Clip{get;private set;}internal float EntryAge=>Mathf.Max(0,Time.time-observed);
        Player player;ZNetView view;Transform[] bones;OilRuntimePose[] entry,exit;readonly OilRuntimePose[] displayed=new OilRuntimePose[53];Action<string> emit;Action done;bool local,fired,pendingComplete,leaving;float started,observed,leaveAt;int damageRevision;
        internal static OilRuntimePose Capture(Transform t)=>new OilRuntimePose{position=t.localPosition,rotation=t.localRotation,scale=t.localScale};
        internal static OilRuntimePose Mix(OilRuntimePose a,OilRuntimePose b,float t)=>new OilRuntimePose{position=Vector3.LerpUnclamped(a.position,b.position,t),rotation=Quaternion.SlerpUnclamped(a.rotation,b.rotation,t),scale=Vector3.LerpUnclamped(a.scale,b.scale,t)};
        void Init(Player p,OffhandPoseClip c,Transform[] b){if(Active)StopMotion();player=p;view=p.GetComponent<ZNetView>();bones=b;Clip=c;entry=b.Select(Capture).ToArray();Array.Copy(entry,displayed,53);Active=true;leaving=false;fired=false;pendingComplete=false;observed=Time.time;damageRevision=SupplyUse.LocalDamageRevision;var mount=p.GetComponent<OffhandPoseMountDriver>()??p.gameObject.AddComponent<OffhandPoseMountDriver>();mount.Player=p;}
        public void Begin(Player p,OffhandPoseClip c,Transform[] b,Action<string> atEvent,Action completed){Init(p,c,b);local=true;emit=atEvent;done=completed;started=Time.time;Elapsed=0;Stamp=Math.Max(1,(long)Math.Round(OilMotion.NetworkNow*1000));view.GetZDO().Set(OffhandPose.ActionKey,c.actionId);view.GetZDO().Set(OffhandPose.StampKey,Stamp);p.SetMoveDir(Vector3.zero);}
        public void BeginRemote(Player p,OffhandPoseClip c,Transform[] b,long stamp){Init(p,c,b);local=false;emit=null;done=null;Stamp=stamp;Elapsed=Mathf.Max(0,(float)(OilMotion.NetworkNow-stamp/1000.0));}
        void Update()
        {
            if(!Active)return;if(!player||player.IsDead()||!view||!view.IsValid()||OilMotion.IsBusy(player)||local&&SupplyUse.LocalDamageRevision!=damageRevision){StopMotion();return;}if(!local&&view.GetZDO().GetLong(OffhandPose.StampKey,0)!=Stamp){StopMotion();return;}float now=local?Time.time-started:(float)(OilMotion.NetworkNow-Stamp/1000.0);Elapsed=Mathf.Clamp(now,0,Clip.duration);pendingComplete=now>=Clip.duration;
        }
        void LateUpdate()
        {
            if(!Active&&!leaving)return;if(bones==null||bones.Any(b=>!b)){StopMotion();return;}if(leaving&&Time.time-leaveAt>=.12f){leaving=false;return;}
            if(Active){OffhandPose.Sample(Clip,Elapsed,out int a,out int b,out float t);float blend=Mathf.SmoothStep(0,1,(Time.time-observed)/.12f);for(int i=0;i<53;i++)displayed[i]=Mix(entry[i],Mix(Clip.samples[a][i],Clip.samples[b][i],t),blend);}
            else{float t=Mathf.SmoothStep(0,1,(Time.time-leaveAt)/.12f);for(int i=0;i<53;i++)displayed[i]=Mix(exit[i],Capture(bones[i]),t);}
            for(int i=0;i<53;i++){bones[i].localPosition=displayed[i].position;bones[i].localRotation=displayed[i].rotation;bones[i].localScale=displayed[i].scale;}
        }
        // Called by the later mount pass, after the actual moving sockets have updated.
        internal void DispatchAfterSockets()
        {if(!Active)return;if(OffhandPosePolicy.EmitDue(Elapsed,Clip.events[0].time,fired)){fired=true;if(local)try{emit?.Invoke("emit");}catch(Exception e){OffhandPose.Warn("OFFHAND_EVENT_FAILED "+e.Message);StopMotion();return;}}if(pendingComplete)StopMotion();}
        public void StopMotion(){if(!Active)return;Active=false;leaving=true;leaveAt=Time.time;exit=displayed.ToArray();if(local&&view&&view.IsValid()&&view.IsOwner()&&view.GetZDO().GetLong(OffhandPose.StampKey,0)==Stamp)view.GetZDO().Set(OffhandPose.StampKey,0L);var callback=done;done=null;emit=null;if(local)try{callback?.Invoke();}catch(Exception e){OffhandPose.Warn("OFFHAND_COMPLETE_FAILED "+e.Message);}}
        void OnDisable()=>StopMotion();
    }
    [HarmonyPatch(typeof(Player),"Update")]static class OffhandPoseObserver{static void Postfix(Player __instance)=>OffhandPose.Observe(__instance);}
    [HarmonyPatch(typeof(ItemsPlugin),"OnDestroy")]static class OffhandPoseShutdown{static void Prefix()=>OffhandPose.Dispose();}
}
