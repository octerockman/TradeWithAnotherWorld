using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
namespace Wayfarer.Items
{
    public static class NativeAbbeyReading
    {
        static MethodInfo itemIdentity;
        static readonly Dictionary<string,string> carriedPages=new Dictionary<string,string>(StringComparer.Ordinal)
        {{"abbey_bellkeeper_deposition","read_deposition"},{"abbey_hidden_tithe_purse","read_tithe"},{"abbey_broken_chapter_seal","read_chapterseal"}};
        public static string ItemId(ItemDrop.ItemData item)=>itemIdentity!=null&&item!=null?itemIdentity.Invoke(null,new object[]{item}) as string:null;
        public static void Initialize(Harmony harmony)
        {
            var reader=AccessTools.TypeByName("BlackAbbeySixRooms.SharedParchmentReader");var open=AccessTools.Method(reader,"Open",new[]{typeof(Player),typeof(string),typeof(string),typeof(string)});
            if(open==null)throw new InvalidOperationException("The installed Abbey document reader contract changed.");harmony.Patch(open,postfix:new HarmonyMethod(typeof(NativeAbbeyReading),nameof(ReadPage)));
            itemIdentity=AccessTools.Method(AccessTools.TypeByName("BlackAbbeySixRooms.FalseVowsItems"),"Id",new[]{typeof(ItemDrop.ItemData)});
            var inventoryRead=AccessTools.Method(typeof(InventoryGui),"OnRightClickItem",new[]{typeof(InventoryGrid),typeof(ItemDrop.ItemData),typeof(Vector2i)});if(inventoryRead==null)throw new InvalidOperationException("Native inventory reader action changed.");harmony.Patch(inventoryRead,prefix:new HarmonyMethod(typeof(NativeAbbeyReading),nameof(InventoryRead)));
            var door=AccessTools.TypeByName("BlackAbbeySixRooms.AbbeyDoor");var hover=AccessTools.Method(door,"GetHoverText");if(hover==null)throw new InvalidOperationException("The installed Abbey entrance observation contract changed.");harmony.Patch(hover,postfix:new HarmonyMethod(typeof(NativeAbbeyReading),nameof(DoorObserved)));
        }
        static bool InventoryRead(InventoryGrid __0,ItemDrop.ItemData __1)
        {var p=Player.m_localPlayer;return !p||__0==null||__0.GetInventory()!=p.GetInventory()||!TryUse(p,__1);}
        static void ReadPage(Player __0,string __3,bool __result)
        {
            if(!__result||__0!=Player.m_localPlayer||__3==null)return;string flag=null;
            if(__3=="BlackAbbey.FalseVows.Letter.png")flag="read_matthien_letter";
            else if(__3.StartsWith("BlackAbbey.UnrecordedDead.02-oswin-final-",StringComparison.Ordinal))flag="read_oswin_later";
            else if(__3.StartsWith("BlackAbbey.UnrecordedDead.03-oswin-older-",StringComparison.Ordinal))flag="read_oswin_older";
            else if(__3.StartsWith("BlackAbbey.UnrecordedDead.04-",StringComparison.Ordinal))flag="read_shared_prayer";
            else if(__3=="BlackAbbey.UnrecordedDead.05-matthien-note.png")flag="read_matthien_pages";
            else if(__3=="BlackAbbey.UnrecordedDead.06-edrin-folded-pages.png")flag="read_edrin_pages";
            if(flag!=null)RuntimeFacts.Record(flag);
        }
        static void DoorObserved(Component __instance)
        {
            var p=Player.m_localPlayer;if(!p||p.IsDead()||Vector3.Distance(p.transform.position,__instance.transform.position)>5)return;
            if(AccessTools.Field(__instance.GetType(),"portalAction")?.GetValue(__instance)!=null)RuntimeFacts.Record("door_seen");
        }
        public static bool TryUse(Player player,ItemDrop.ItemData item)
        {
            if(!player||player!=Player.m_localPlayer||item==null||!player.GetInventory().ContainsItem(item)||!TextViewer.instance||itemIdentity==null)return false;
            string id=ItemId(item);if(id==null||!carriedPages.TryGetValue(id,out string flag))return false;
            // These existing evidence items already carry approved transcriptions
            // in their native descriptions. Reading does not consume or replace
            // them, and merely carrying them never grants the reading fact.
            TextViewer.instance.ShowText(TextViewer.Style.Rune,Localization.instance.Localize(item.m_shared.m_name),Localization.instance.Localize(item.m_shared.m_description),false);RuntimeFacts.Record(flag);return true;
        }
    }
}
