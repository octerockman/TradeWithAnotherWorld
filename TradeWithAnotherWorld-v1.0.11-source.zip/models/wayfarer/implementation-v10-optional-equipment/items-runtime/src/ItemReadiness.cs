namespace Wayfarer.Items
{
    public static class ItemReadiness
    {
        public static bool Purchasable(string id)
        {
            var plugin=ItemsPlugin.Instance;if(!plugin||!plugin.Catalogue.TryItem(id,out var d)||!plugin.Definitions.Prefab(id))return false;
            if(d.IsJewelry)return JewelleryRuntime.IsNativeReady(id);
            if(d.Kind=="oil")return WeaponOilUse.Ready;
            if(d.Kind=="handbell"||d.Kind=="torch"||d.Kind=="censer")return OffhandRuntime.Ready;
            return true;
        }
    }
}
