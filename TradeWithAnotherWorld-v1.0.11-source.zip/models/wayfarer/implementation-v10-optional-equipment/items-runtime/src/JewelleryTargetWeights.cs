using System;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    public static class JewelleryTargetWeights
    {
        public sealed class Selection{public BaseAI ai;public Character actor;public readonly List<Player> players=new List<Player>();}
        [ThreadStatic]static Selection selection;
        static readonly FieldInfo actorField=AccessTools.Field(typeof(BaseAI),"m_character");
        static readonly MethodInfo havePath=AccessTools.Method(typeof(BaseAI),"HavePath",new[]{typeof(Vector3)});
        public static bool Ordinary(BaseAI ai,out Character actor)
        {
            actor=actorField.GetValue(ai) as Character;if(!(ai is MonsterAI)||!actor||actor.IsBoss()||actor.IsTamed()||actor.IsDead()||actor.InAttack()||!ai.IsAlerted())return false;
            var view=actor.GetComponent<ZNetView>();if(!view||!view.IsOwner())return false;
            string name=actor.name;return !name.StartsWith("TWA_",StringComparison.Ordinal)&&!name.StartsWith("BA_",StringComparison.Ordinal)&&name.IndexOf("hildir",StringComparison.OrdinalIgnoreCase)<0&&name.IndexOf("knight",StringComparison.OrdinalIgnoreCase)<0&&name.IndexOf("abbot",StringComparison.OrdinalIgnoreCase)<0&&!actor.GetComponent<JewelleryDecoy>();
        }
        public static Selection Enter(BaseAI ai)
        {
            var previous=selection;selection=Ordinary(ai,out var actor)?new Selection{ai=ai,actor=actor}:null;return previous;
        }
        public static void Leave(Selection previous){selection=previous;}
        public static bool Capture(bool sensed,BaseAI ai,Character candidate)
        {
            if(sensed&&selection?.ai==ai&&candidate is Player p&&!selection.players.Contains(p))selection.players.Add(p);return sensed;
        }
        public static Character Choose(Character original)
        {
            var s=selection;if(s==null||!(original is Player))return original;
            // Every candidate passed the original native IsEnemy, dead, cinematic,
            // skip-target, sleeping and CanSenseTarget checks in this exact call.
            var candidates=s.players.Where(p=>p&&!p.IsDead()&&(bool)havePath.Invoke(s.ai,new object[]{p.transform.position})).ToArray();
            if(candidates.Length<2)return original;
            var weights=candidates.Select(p=>1/Math.Max(.5f,Vector3.Distance(p.transform.position,s.actor.transform.position))*(Vector3.Distance(p.transform.position,s.actor.transform.position)<=10&&JewelleryRuntime.For(p).Has("ds3_bellwether")?1.5f:1)).ToArray();
            bool wearer=candidates.Any(p=>Vector3.Distance(p.transform.position,s.actor.transform.position)<=10&&JewelleryRuntime.For(p).Has("ds3_bellwether"));if(!wearer)return original;
            float draw=UnityEngine.Random.value*weights.Sum();for(int i=0;i<weights.Length;i++){draw-=weights[i];if(draw<=0)return candidates[i];}return candidates[candidates.Length-1];
        }
    }
    [HarmonyPatch(typeof(BaseAI),"FindEnemy")]
    static class JewelleryNativeCandidateWeights
    {
        static void Prefix(BaseAI __instance,out JewelleryTargetWeights.Selection __state){__state=JewelleryTargetWeights.Enter(__instance);}
        static void Postfix(ref Character __result){__result=JewelleryTargetWeights.Choose(__result);}
        static Exception Finalizer(Exception __exception,JewelleryTargetWeights.Selection __state){JewelleryTargetWeights.Leave(__state);return __exception;}
        static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            var sense=AccessTools.Method(typeof(BaseAI),"CanSenseTarget",new[]{typeof(Character)});int matches=0;
            foreach(var code in instructions)
            {
                yield return code;if(!code.Calls(sense))continue;
                // Native FindEnemy local3 is the character from its own loop.
                yield return new CodeInstruction(OpCodes.Ldarg_0);yield return new CodeInstruction(OpCodes.Ldloc_3);
                yield return new CodeInstruction(OpCodes.Call,AccessTools.Method(typeof(JewelleryTargetWeights),"Capture"));matches++;
            }
            if(matches!=1)throw new InvalidOperationException("Native FindEnemy candidate consumer changed; refuse weighting.");
        }
    }
}
