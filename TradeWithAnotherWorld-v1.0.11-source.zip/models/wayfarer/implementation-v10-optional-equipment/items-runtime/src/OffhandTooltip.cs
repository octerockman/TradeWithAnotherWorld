using System;
using HarmonyLib;
namespace Wayfarer.Items
{
    [HarmonyPatch(typeof(ItemDrop.ItemData),nameof(ItemDrop.ItemData.GetTooltip),new[]{typeof(ItemDrop.ItemData),typeof(int),typeof(bool),typeof(float),typeof(int),typeof(bool)})]
    static class OffhandTooltip
    {
        static string N(float n)=>n.ToString("0.#",System.Globalization.CultureInfo.InvariantCulture);
        static void Postfix(ItemDrop.ItemData __0,int __1,ref string __result)
        {
            var plugin=ItemsPlugin.Instance;if(!plugin||__0==null||!plugin.Catalogue.TryItem(__0,out var d)||!(d.Kind=="handbell"||d.Kind=="torch"||d.Kind=="censer"))return;
            int q=Math.Max(1,Math.Min(4,__1));string text="\n\n<color=orange>Offhand: left + right mouse</color>\n";
            if(d.Id=="sundered_bell")text+="5 homing motes · "+d.Stats["damagePerMoteByQuality"][q-1]+" ember damage each before skill scaling.\n15 health · 22 stamina before modifiers.\nSolid impacts scatter harmless embers. Elemental Magic has doubled damage benefit.";
            else if(d.Id=="consecrated_handbell")text+=d.Stats["spiritByQuality"][q-1]+" spirit damage before skill scaling · 15m pulse.\nSlows enemies 15% for 6s. Walls stop the pulse.\n20 stamina · 30 eitr before modifiers. Elemental Magic has doubled damage benefit.";
            else if(d.Kind=="torch")text+="Blunt "+N(OffhandCombatPolicy.Quality(d.Stat("blunt"),d.Stat("bluntPerQuality"),q))+" · Fire "+N(OffhandCombatPolicy.Quality(d.Stat("fire"),d.Stat("firePerQuality"),q))+" · Spirit "+N(OffhandCombatPolicy.Quality(d.Stat("spirit"),d.Stat("spiritPerQuality"),q))+" before skill scaling.\n12 stamina. Shift + both buttons: heavy sweep, 18 stamina.\nIts flame does not burn out.";
            else text+="Blunt "+N(OffhandCombatPolicy.Quality(d.Stat("blunt"),d.Stat("physicalDamagePerQuality"),q))+" before skill scaling.\nIncense: "+N(OffhandCombatPolicy.Quality(d.Stat("smokeTotalDamage"),d.Stat("smokeTotalDamagePerQuality"),q))+" poison over 4s · 2.5m cloud · 8s recovery.\nShift + both buttons: ember, "+N(OffhandCombatPolicy.Quality(d.Stat("emberTotalDamage"),d.Stat("emberTotalDamagePerQuality"),q))+" damage · 6s recovery.\n20 stamina for incense; 18 for the ember, before modifiers.";
            __result+=text;
        }
    }
}
