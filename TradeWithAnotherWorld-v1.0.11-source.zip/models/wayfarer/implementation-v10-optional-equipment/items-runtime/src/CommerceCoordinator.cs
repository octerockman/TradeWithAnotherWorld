using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;
using Wayfarer.InGame;

namespace Wayfarer.Items
{
    public sealed class CommerceRequest
    {
        public string id,operation,item,job,flag,instance,inventoryHash,catalogueHash;
        public int quantity=1;
        public long world,player,traderUser;
        public uint traderId;
        public Dictionary<string,long> inventory;
        public Dictionary<string,int> delivery;
        public string[] dialogueFlags;
    }
    public sealed class CommerceReply
    {
        public string kind,requestId,error,inventoryHash;
        public string selectedItemId;
        public long world;
        public CommerceWorldState state;
        public CommerceTransaction plan;
    }
    public sealed class CommerceCoordinator:IDisposable
    {
        const string RequestRpc="TWA_WF_TradeRequest_v1",ReplyRpc="TWA_WF_TradeReply_v1",AckRpc="TWA_WF_TradeAck_v1";
        readonly ItemsPlugin plugin;
        readonly string folder,catalogueHash;
        ZRoutedRpc rpc;
        CommerceWorldStore store;
        CommerceSave saved;
        long world;
        float nextPoll;
        readonly Queue<string> pendingNative=new Queue<string>();
        CommerceRequest localRequest;
        public CommerceWorldState State{get;private set;}
        public bool Busy=>localRequest!=null;
        public event Action Changed;
        public string LastMessage{get;private set;}="";
        public CommerceCoordinator(ItemsPlugin owner,string root)
        {plugin=owner;folder=root;catalogueHash=RuntimeCatalogue.FileHash(Path.Combine(owner.DataDirectory,"trade-catalogue.json"));}
        long ServerPeer=>ZNet.instance.IsServer()?ZNet.GetUID():ZNet.instance.GetServerPeer()?.m_uid??0;
        public void Tick()
        {
            if(Time.unscaledTime<nextPoll)return;nextPoll=Time.unscaledTime+1;
            if(!ZNet.instance||ZRoutedRpc.instance==null){Reset();return;}
            if(rpc!=ZRoutedRpc.instance)
            {
                rpc=ZRoutedRpc.instance;
                rpc.Register<string>(RequestRpc,ReceiveRequest);rpc.Register<string>(ReplyRpc,ReceiveReply);rpc.Register<string>(AckRpc,ReceiveAck);
                rpc.Register<string>("TWA_WF_NativeFact_v1",ReceiveNativeFact);
            }
            long uid=ZNet.instance.GetWorldUID();if(uid==0)return;
            if(uid!=world)
            {
                Reset();world=uid;
                if(ZNet.instance.IsServer()){store=new CommerceWorldStore(folder,world);saved=store.Load();State=saved.state;UpdateWorldBoss();}
                if(Player.m_localPlayer)Request("sync");
            }
            if(ZNet.instance.IsServer()&&saved!=null)
            {
                if(saved.pending==null&&saved.queuedNativeFacts.Count>0)
                {foreach(string fact in saved.queuedNativeFacts.ToArray()){if(!saved.state.flags.Contains(fact))Commit(CommercePolicy.PlanFlag(saved.state,Guid.NewGuid().ToString("N"),fact));saved.queuedNativeFacts.Remove(fact);}store.Save(saved);}
                UpdateWorldBoss();
                if(saved.pending==null&&saved.queuedVictories.Count>0)
                {
                    var eventAtDeath=saved.queuedVictories[0];
                    if(!saved.state.appliedVictories.Contains(eventAtDeath.run))
                    {var eligible=new HashSet<string>(eventAtDeath.eligibleAtVictory,StringComparer.Ordinal);Commit(CommercePolicy.PlanAbbeyVictory(saved.state,Guid.NewGuid().ToString("N"),eventAtDeath.run,plugin.Definitions.Offers.Values.Where(o=>eligible.Contains(o.id))));}
                    saved.queuedVictories.RemoveAt(0);store.Save(saved);
                }
            }
            if(Player.m_localPlayer&&world!=0&&pendingNative.Count>0)
            {
                while(pendingNative.Count>0)
                {string fact=pendingNative.Dequeue();var p=Player.m_localPlayer;string raw=JsonConvert.SerializeObject(new{world,player=p.GetPlayerID(),fact});if(ZNet.instance.IsServer())ReceiveNativeFact(ZNet.GetUID(),raw);else rpc.InvokeRoutedRPC(ServerPeer,"TWA_WF_NativeFact_v1",new object[]{raw});}
            }
        }
        public void NativeFact(string fact)
        {if(NativeProgress.AllowedFacts.Contains(fact)&&pendingNative.Count<256)pendingNative.Enqueue(fact);}
        void ReceiveNativeFact(long sender,string raw)
        {
            if(!ZNet.instance||!ZNet.instance.IsServer()||saved==null||raw==null||raw.Length>1024)return;
            try
            {
                var eventData=Newtonsoft.Json.Linq.JObject.Parse(raw);string fact=eventData.Value<string>("fact");if(eventData.Value<long>("world")!=world||!NativeProgress.AllowedFacts.Contains(fact))return;
                var peer=sender==ZNet.GetUID()?null:ZNet.instance.GetPeer(sender);long playerId=eventData.Value<long>("player");if(peer!=null&&peer.m_playerID!=playerId||peer==null&&sender!=ZNet.GetUID())return;
                if(fact=="coated_trial_hit")
                {
                    if(!saved.state.accepted.ContainsKey("oil_field_trial")||saved.state.completed.Contains("oil_field_trial"))return;
                    int hits=saved.nativeCounters.TryGetValue("oil_trial_hits",out int n)?n:0;saved.nativeCounters["oil_trial_hits"]=Math.Min(3,hits+1);saved.queuedNativeFacts.Add("starting_oil_used_in_combat");if(hits+1>=3)saved.queuedNativeFacts.Add("three_coated_hits_landed");
                }
                else saved.queuedNativeFacts.Add(fact);
                store.Save(saved);
            }
            catch(JsonException e){plugin.Warn("NATIVE_FACT_REJECTED "+e.Message);}
        }
        void Reset(){world=0;State=null;saved=null;store=null;localRequest=null;pendingNative.Clear();}
        public void Request(string operation,string item=null,string job=null,int quantity=1,Dictionary<string,int> delivery=null,string instance=null,string flag=null)
        {
            if(Busy||!Player.m_localPlayer||world==0){LastMessage="Please wait for the current account to settle.";return;}
            var p=Player.m_localPlayer;var trader=WayfarerTradeUI.Trader;var view=trader?trader.GetComponent<ZNetView>():null;var id=view&&view.IsValid()?view.GetZDO().m_uid:ZDOID.None;
            var request=new CommerceRequest{id=Guid.NewGuid().ToString("N"),operation=operation,item=item,job=job,quantity=quantity,delivery=delivery,instance=instance,flag=flag,dialogueFlags=WayfarerTradeUI.DialogueKnowledge,world=world,player=p.GetPlayerID(),traderUser=id.UserID,traderId=id.ID,catalogueHash=catalogueHash,inventory=plugin.Definitions.Inventory(p.GetInventory()),inventoryHash=CommerceInventory.Fingerprint(p.GetInventory(),plugin.Definitions)};
            localRequest=request;LastMessage="";
            SendRequest(request);
        }
        void SendRequest(CommerceRequest request)
        {if(ZNet.instance.IsServer())ReceiveRequest(ZNet.GetUID(),JsonConvert.SerializeObject(request));else rpc.InvokeRoutedRPC(ServerPeer,RequestRpc,new object[]{JsonConvert.SerializeObject(request)});}
        void Reply(long peer,CommerceReply reply)
        {reply.world=world;string raw=JsonConvert.SerializeObject(reply);if(peer==ZNet.GetUID())ReceiveReply(peer,raw);else rpc.InvokeRoutedRPC(peer,ReplyRpc,new object[]{raw});}
        void ReceiveRequest(long peer,string raw)
        {
            if(!ZNet.instance||!ZNet.instance.IsServer()||saved==null)return;
            CommerceRequest q=null;
            try
            {
                if(raw==null||raw.Length>128*1024)throw new InvalidOperationException("Oversized trade request.");
                q=JsonConvert.DeserializeObject<CommerceRequest>(raw);
                if(q==null||q.world!=world||q.id?.Length!=32||q.catalogueHash!=catalogueHash)throw new InvalidOperationException("Your Wayfarer item data does not match this world host.");
                var remote=peer==ZNet.GetUID()?null:ZNet.instance.GetPeer(peer);
                if(peer!=ZNet.GetUID()&&(remote==null||remote.m_playerID!=q.player))throw new InvalidOperationException("Unknown trading player.");
                if(q.operation=="sync")
                {
                    Reply(peer,new CommerceReply{kind="state",requestId=q.id,state=saved.state});
                    if(saved.pending?.player==q.player){saved.pending.peer=peer;store.Save(saved);Reply(peer,new CommerceReply{kind="prepare",requestId=saved.pending.plan.requestId,plan=saved.pending.plan,inventoryHash=saved.pending.inventoryHash,selectedItemId=saved.pending.selectedItemId});}return;
                }
                var merchant=ZDOMan.instance.GetZDO(new ZDOID(q.traderUser,q.traderId));
                Vector3 position=remote!=null?remote.GetRefPos():Player.m_localPlayer?Player.m_localPlayer.transform.position:new Vector3(float.MaxValue,0,0);
                if(merchant==null||merchant.GetPrefab()!=WayfarerPlugin.NpcPrefab.GetStableHashCode()||Vector3.Distance(position,merchant.GetPosition())>10)throw new InvalidOperationException("Speak to the Wayfarer nearby to trade.");
                if(saved.pending!=null)throw new InvalidOperationException("A previous trade is still being reconciled. Please wait.");
                if(q.inventory==null||q.inventory.Count>1024||q.inventory.Any(k=>k.Value<0||k.Value>10000000)||q.inventoryHash?.Length!=64)throw new InvalidOperationException("Invalid carried inventory summary.");
                var plan=Plan(q);
                if(!plan.Success)throw new InvalidOperationException(plan.error);
                if(plan.inventory.Count==0&&plan.selectedInstanceQualityAfter==0&&!plan.fullyRepairSelectedInstance)
                {Commit(plan);Reply(peer,new CommerceReply{kind="state",requestId=q.id,state=saved.state});return;}
                saved.pending=new CommercePending{peer=peer,player=q.player,inventoryHash=q.inventoryHash,selectedItemId=q.operation=="version"?q.job:q.item,plan=plan};store.Save(saved);
                Reply(peer,new CommerceReply{kind="prepare",requestId=q.id,plan=plan,inventoryHash=q.inventoryHash,selectedItemId=saved.pending.selectedItemId});
            }
            catch(Exception e){plugin.Warn("TRADE_REJECTED "+e.Message);Reply(peer,new CommerceReply{kind="error",requestId=q?.id,error=e.Message,state=saved.state});}
        }
        CommerceTransaction Plan(CommerceRequest q)
        {
            var definitions=plugin.Definitions;var state=saved.state;
            switch(q.operation)
            {
                case "purchase":
                    if(!definitions.Offers.TryGetValue(q.item??"",out var offer)||!CommercePolicy.AvailableStock(state,definitions.Offers.Values).Any(o=>o.id==q.item)||!ItemReadiness.Purchasable(q.item))return new CommerceTransaction{error="This item is not currently for sale."};
                    return CommercePolicy.PlanPurchase(state,q.id,offer,q.inventory,q.quantity);
                case "exchange":return CommercePolicy.PlanExchangeOrdinaryCoins(state,q.id,q.inventory,q.quantity);
                case "version":
                    if(!ItemReadiness.Purchasable(q.item))return new CommerceTransaction{error="This version is not currently available."};
                    return CommercePolicy.PlanVersionExchange(state,q.id,definitions.Offers.TryGetValue(q.job??"",out var old)?old:null,definitions.Offers.TryGetValue(q.item??"",out var newer)?newer:null,q.instance,q.inventory);
                case "repair":
                    var repairable=new HashSet<string>(plugin.Catalogue.Items.Values.Where(d=>d.Stats.Value<bool?>("wayfarerRepairsFree")==true).Select(d=>d.Id),StringComparer.Ordinal);
                    return MerchantRepairPolicy.Plan(state,q.id,q.item,q.instance,q.inventory,repairable);
                case "accept":
                    if(!definitions.Commissions.TryGetValue(q.job??"",out var accept)||!ConversationGates.CanOffer(state,accept))return new CommerceTransaction{error="This commission is not currently available."};return CommercePolicy.PlanAcceptCommission(state,q.id,accept);
                case "deliver":return CommercePolicy.PlanDelivery(state,q.id,definitions.Commissions.TryGetValue(q.job??"",out var deliver)?deliver:null,q.inventory,q.delivery);
                case "appraise":return CommercePolicy.PlanAppraisal(state,q.id,definitions.Commissions.TryGetValue(q.job??"",out var appraise)?appraise:null,q.item,q.inventory);
                case "record-appraisal":return CommercePolicy.PlanRecordAppraisal(state,q.id,q.item,q.inventory,definitions.ApprovedAppraisals);
                case "talk":
                case "node-fact":
                    var action=q.operation=="talk"?definitions.Talks.FirstOrDefault(a=>a.Value<string>("id")==q.item):definitions.DialogueMap["nodeFacts"]?[q.item??""] as Newtonsoft.Json.Linq.JObject;
                    var knowledge=new HashSet<string>((q.dialogueFlags??Array.Empty<string>()).Take(256),StringComparer.Ordinal);
                    if(!definitions.ConversationAllowed(action,state,q.inventory,knowledge))return new CommerceTransaction{error="That conversation requires more of the agreed work first."};
                    string field=q.operation=="talk"?"setsWorldFacts":"setWorldFacts";var facts=(action[field] as Newtonsoft.Json.Linq.JArray??new Newtonsoft.Json.Linq.JArray()).Values<string>().ToArray();
                    var protectedFacts=new HashSet<string>((definitions.DialogueMap["protectedNativeFacts"] as Newtonsoft.Json.Linq.JArray??new Newtonsoft.Json.Linq.JArray()).Values<string>(),StringComparer.Ordinal);
                    if(facts.Length==0||facts.Any(protectedFacts.Contains))return new CommerceTransaction{error="A conversation cannot create an unproved world event."};
                    var conversation=CommercePolicy.PlanFlag(state,q.id,facts[0]);if(conversation.Success)foreach(string fact in facts.Skip(1))conversation.stateAfter.flags.Add(fact);return conversation;
                case "complete":return CommercePolicy.PlanCompleteStoryCommission(state,q.id,definitions.Commissions.TryGetValue(q.job??"",out var complete)?complete:null);
                case "sale":
                    if(!plugin.Catalogue.TryItem(q.item,out var d)||d.Data["buyPriceSC"]==null||d.Data["buyPriceSC"].Type==Newtonsoft.Json.Linq.JTokenType.Null)return new CommerceTransaction{error="The Wayfarer has no buying price for this item."};
                    return CommercePolicy.PlanSale(state,q.id,q.item,q.quantity,d.Int("sellLotSize",1),d.Int("buyPriceSC"),q.inventory,definitions.Offers.Values.Any(o=>o.fragmentId==d.Id));
                case "flag":
                    if(!DialogueSession.IsApprovedStoryFlag(q.flag)||(definitions.DialogueMap["protectedNativeFacts"] as Newtonsoft.Json.Linq.JArray??new Newtonsoft.Json.Linq.JArray()).Values<string>().Contains(q.flag))return new CommerceTransaction{error="Unknown or unproved conversation event."};
                    return CommercePolicy.PlanFlag(state,q.id,q.flag);
                default:return new CommerceTransaction{error="Unknown trading action."};
            }
        }
        void ReceiveReply(long peer,string raw)
        {
            if(!ZNet.instance||peer!=ServerPeer||raw==null||raw.Length>16*1024*1024)return;
            try
            {
                var reply=JsonConvert.DeserializeObject<CommerceReply>(raw);if(reply?.world!=world)return;
                if(reply.state!=null)State=reply.state;
                if(reply.kind=="prepare")
                {
                    var p=Player.m_localPlayer;if(!p)return;
                    // Receipt and inventory are committed to the same native
                    // character snapshot before the world host credits progress.
                    var receipts=PlayerReceipts(p.GetPlayerID());
                    bool applied=receipts.Contains(reply.requestId);string error=null;
                    if(!applied)
                    {
                        Action rollback=null;NativeTradeCheckpoint.ApplyingInventory=true;
                        try
                        {
                            if(!string.IsNullOrEmpty(reply.plan.selectedInstanceId)&&!p.GetInventory().GetAllItems().Any(i=>i.m_customData.TryGetValue(CommerceInventory.InstanceKey,out var selected)&&selected==reply.plan.selectedInstanceId&&plugin.Definitions.ItemId(i)==reply.selectedItemId))throw new InvalidOperationException("The selected equipment item changed.");
                            if(CommerceInventory.Apply(p,plugin.Definitions,reply.plan,reply.inventoryHash,out error,out rollback))
                            {
                                receipts.Add(reply.requestId);SaveReceipts(p.GetPlayerID(),receipts);NativeTradeCheckpoint.ApplyingInventory=false;
                                if(NativeTradeCheckpoint.Save(p))applied=true;
                                else{receipts.Remove(reply.requestId);SaveReceipts(p.GetPlayerID(),receipts);rollback();error="Your character could not be saved. The trade was returned.";}
                            }
                        }
                        catch(Exception e)
                        {if(!applied){receipts.Remove(reply.requestId);SaveReceipts(p.GetPlayerID(),receipts);rollback?.Invoke();}error=e.Message;}
                        finally{NativeTradeCheckpoint.ApplyingInventory=false;}
                    }
                    string ack=JsonConvert.SerializeObject(new{world,requestId=reply.requestId,player=p.GetPlayerID(),applied,error});
                    if(ZNet.instance.IsServer())ReceiveAck(ZNet.GetUID(),ack);else rpc.InvokeRoutedRPC(ServerPeer,AckRpc,new object[]{ack});
                    if(!applied)LastMessage=error;
                }
                else{if(localRequest?.id==reply.requestId)localRequest=null;LastMessage=reply.error??"";Changed?.Invoke();}
            }
            catch(Exception e){plugin.Warn("TRADE_REPLY_FAILED "+e);LastMessage="The trade could not be confirmed. Your account has been retained.";}
        }
        void ReceiveAck(long peer,string raw)
        {
            if(!ZNet.instance||!ZNet.instance.IsServer()||saved?.pending==null||raw?.Length>4096)return;
            try
            {
                var ack=Newtonsoft.Json.Linq.JObject.Parse(raw);var pending=saved.pending;
                if(ack.Value<long>("world")!=world||ack.Value<string>("requestId")!=pending.plan.requestId||ack.Value<long>("player")!=pending.player||peer!=pending.peer)return;
                bool applied=ack.Value<bool>("applied");string error=ack.Value<string>("error");
                if(applied&&!saved.state.appliedTransactions.Contains(pending.plan.requestId))Commit(pending.plan);
                saved.pending=null;store.Save(saved);
                Reply(peer,new CommerceReply{kind=applied?"state":"error",requestId=pending.plan.requestId,state=saved.state,error=applied?null:error});
            }
            catch(Exception e){plugin.Warn("TRADE_COMMIT_FAILED "+e);}
        }
        void Commit(CommerceTransaction plan)
        {if(!CommercePolicy.TryCommit(saved.state,plan,out var next))throw new InvalidOperationException("The shared account changed during this trade.");plugin.Definitions.ApplyImmediateUnlocks(next);saved.state=next;store.Save(saved);State=next;Changed?.Invoke();if(rpc!=null&&ZNet.instance&&ZNet.instance.IsServer())foreach(var peer in ZNet.instance.GetPeers())Reply(peer.m_uid,new CommerceReply{kind="state",state=next});}
        HashSet<string> PlayerReceipts(long player)
        {var p=Player.m_localPlayer;if(!p||p.GetPlayerID()!=player)throw new InvalidOperationException("Trading character changed.");return p.m_customData.TryGetValue("TWA_WF_TradeReceipts_"+world,out var raw)?JsonConvert.DeserializeObject<HashSet<string>>(raw)??new HashSet<string>(StringComparer.Ordinal):new HashSet<string>(StringComparer.Ordinal);}
        void SaveReceipts(long player,HashSet<string> receipts)
        {var p=Player.m_localPlayer;if(!p||p.GetPlayerID()!=player)throw new InvalidOperationException("Trading character changed.");p.m_customData["TWA_WF_TradeReceipts_"+world]=JsonConvert.SerializeObject(receipts);}
        void UpdateWorldBoss()
        {
            if(saved==null||saved.pending!=null||!ZoneSystem.instance)return;
            string[] keys={"defeated_eikthyr","defeated_gdking","defeated_bonemass","defeated_dragon","defeated_goblinking","defeated_queen","defeated_fader","defeated_frozenking_p3"};
            int highest=0;for(int i=0;i<keys.Length;i++)if(ZoneSystem.instance.GetGlobalKey(keys[i]))highest=i+1;
            if(highest>saved.state.highestBossLevel)Commit(CommercePolicy.PlanBossProgress(saved.state,Guid.NewGuid().ToString("N"),highest));
        }
        public void AbbeyVictory(string generatedRunIdentity)
        {
            if(saved==null||!ZNet.instance.IsServer()||saved.state.appliedVictories.Contains(generatedRunIdentity)||saved.queuedVictories.Any(v=>v.run==generatedRunIdentity))return;
            var eligible=plugin.Definitions.Offers.Values.Where(o=>CommercePolicy.RequirementsMet(saved.state,o)).Select(o=>o.id).ToArray();
            saved.queuedVictories.Add(new CommerceQueuedVictory{run=generatedRunIdentity,eligibleAtVictory=eligible});store.Save(saved);
        }
        public void Dispose(){Reset();}
    }
}
