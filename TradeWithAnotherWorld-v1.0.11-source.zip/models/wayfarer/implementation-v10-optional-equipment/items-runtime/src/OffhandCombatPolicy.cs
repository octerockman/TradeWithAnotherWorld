using System;
namespace Wayfarer.Items
{
    public static class OffhandCombatPolicy
    {
        public static float BellDamageFactor(float skill,float percentile)
        {
            skill=Clamp(skill);percentile=Clamp(percentile);
            float center=.4f+.6f*skill;
            float native=Clamp(center-.15f)+(Clamp(center+.15f)-Clamp(center-.15f))*percentile;
            return 2*native-(.25f+.30f*percentile);
        }
        public static float SkillCost(float normal,float skill)=>Math.Max(0,normal)*(1-.33f*Clamp(skill));
        public static bool CanPay(float health,float stamina,float eitr,float healthCost,float staminaCost,float eitrCost)
            =>health>=healthCost+1&&stamina+.001f>=staminaCost&&eitr+.001f>=eitrCost;
        public static float Quality(float basic,float step,int quality)=>basic+Math.Max(0,Math.Min(4,quality)-1)*step;
        static float Clamp(float n)=>Math.Max(0,Math.Min(1,n));
    }
}
