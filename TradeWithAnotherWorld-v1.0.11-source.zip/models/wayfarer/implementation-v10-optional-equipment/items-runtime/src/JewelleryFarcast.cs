using System;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    public static class JewelleryFarcast
    {
        const string TokenKey="TWA_WF_FarcastThrow_v1";
        sealed class Ticket{public Player player;public Projectile projectile;public ItemDrop drop;public string token;public double due;public bool impacted;}
        static Ticket pending;
        [ThreadStatic]static Ticket dropping;
        public static void Register(Projectile projectile,Player p,ItemDrop.ItemData item)
        {
            if(pending!=null||!p||p!=Player.m_localPlayer||!projectile.m_respawnItemOnHit||item==null||item.m_stack!=1||item.m_shared.m_skillType!=Skills.SkillType.Spears||!JewelleryRuntime.For(p).Has("md_farcast_knot"))return;
            string token=Guid.NewGuid().ToString("N");item.m_customData[TokenKey]=token;pending=new Ticket{player=p,projectile=projectile,token=token};
        }
        public static object EnterImpact(Projectile projectile)
        {
            var old=dropping;
            if(pending!=null&&pending.projectile==projectile&&!pending.impacted){pending.impacted=true;pending.due=JewelleryRuntime.Now+5;dropping=pending;}
            else dropping=null;
            return old;
        }
        public static void LeaveImpact(object old){dropping=old as Ticket;}
        public static void NativeDrop(ItemDrop.ItemData original,ItemDrop drop)
        {
            if(dropping==null||!drop||original==null||!original.m_customData.TryGetValue(TokenKey,out string token)||token!=dropping.token)return;
            // Capture the actual ItemDrop native SpawnOnHit just created. Do not
            // create, clone, move, respawn or independently reconstruct an item.
            dropping.drop=drop;
        }
        public static void Cancel(){pending=null;dropping=null;}
        public static void Tick(Player p)
        {
            var t=pending;if(t==null)return;
            if(!p||p!=t.player||p.IsDead()||!JewelleryRuntime.For(p).Has("md_farcast_knot")){Cancel();return;}
            if(!t.impacted){if(!t.projectile)Cancel();return;}
            var drop=t.drop;if(!drop){Cancel();return;}
            var view=drop.GetComponent<ZNetView>();
            if(!view||!view.IsValid()||!view.IsOwner()||!drop.m_itemData.m_customData.TryGetValue(TokenKey,out string token)||token!=t.token){Cancel();return;}
            if(JewelleryRuntime.Now<t.due)return;pending=null;
            // Failed/full inventory is final. The owned physical spear remains
            // at its impact. Native Pickup performs ownership and item transfer.
            if(!p.GetInventory().CanAddItem(drop.m_itemData,1)||!drop.CanPickup(false))return;
            p.Pickup(drop.gameObject,false,false);
        }
    }
    [HarmonyPatch(typeof(Projectile),"Setup")]
    static class JewelleryFarcastThrownSpear
    {static void Postfix(Projectile __instance,Character __0,ItemDrop.ItemData __4){JewelleryFarcast.Register(__instance,__0 as Player,__4);}}
    [HarmonyPatch(typeof(Projectile),"SpawnOnHit")]
    static class JewelleryFarcastActualImpact
    {static void Prefix(Projectile __instance,out object __state){__state=JewelleryFarcast.EnterImpact(__instance);}static Exception Finalizer(Exception __exception,object __state){JewelleryFarcast.LeaveImpact(__state);return __exception;}}
    [HarmonyPatch(typeof(ItemDrop),"DropItem",new[]{typeof(ItemDrop.ItemData),typeof(int),typeof(Vector3),typeof(Quaternion)})]
    static class JewelleryFarcastActualDroppedInstance
    {static void Postfix(ItemDrop.ItemData __0,ItemDrop __result){JewelleryFarcast.NativeDrop(__0,__result);}}
}
