using System;
using System.Collections.Generic;
namespace Wayfarer.Items
{
    public static class RegistryBellUpgradePolicy
    {
        public static bool CanAttempt(int quality)=>quality>=1&&quality<4;
        public static Dictionary<string,string> Snapshot(IDictionary<string,string> data)=>data==null?new Dictionary<string,string>():new Dictionary<string,string>(data);
        public static void Restore(IDictionary<string,string> snapshot,IDictionary<string,string> replacement)
        {if(snapshot==null||replacement==null)throw new ArgumentNullException();foreach(var pair in snapshot)replacement[pair.Key]=pair.Value;}
    }
}
