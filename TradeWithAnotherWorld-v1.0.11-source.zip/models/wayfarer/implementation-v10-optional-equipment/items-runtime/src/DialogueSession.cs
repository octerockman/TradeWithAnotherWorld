using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using HarmonyLib;

namespace Wayfarer.Items
{
    public sealed class DialogueMemory
    {
        public HashSet<string> flags=new HashSet<string>(StringComparer.Ordinal),visited=new HashSet<string>(StringComparer.Ordinal),pendingNodeFacts=new HashSet<string>(StringComparer.Ordinal);
    }
    public sealed class DialogueSession
    {
        const string MemoryKey="twa_wayfarer_dialogue_v1";
        readonly Dictionary<string,JObject> nodes;
        readonly Dictionary<JObject,string> mappedJobs=new Dictionary<JObject,string>();
        readonly ItemsPlugin plugin;
        readonly Player player;
        readonly DialogueMemory memory;
        static HashSet<string> storyFlags=new HashSet<string>(StringComparer.Ordinal);
        readonly JObject mapping;
        public string Current{get;private set;}
        // A completed reply keeps its text while its options come from root.
        public string MenuNode{get;private set;}
        public string Text=>nodes.TryGetValue(Current??"",out var node)?node.Value<string>("npc")??"":"";
        public readonly Queue<string> PendingStoryFlags=new Queue<string>();
        public DialogueSession(ItemsPlugin owner,Player speaker)
        {
            plugin=owner;player=speaker;
            mapping=owner.Definitions.DialogueMap;
            var tree=RuntimeCatalogue.ReadJson(Path.Combine(owner.DataDirectory,"dialogue-tree.json"),2*1024*1024);
            nodes=((JArray)tree["nodes"]).OfType<JObject>().Where(n=>n.Value<bool?>("retired")!=true).ToDictionary(n=>n.Value<string>("id"),StringComparer.Ordinal);
            foreach(var row in (mapping["choiceActions"] as JArray??new JArray()).OfType<JObject>())
            {string id=row.Value<string>("nodeId");if(nodes.TryGetValue(id,out var node)&&node["choices"] is JArray choices){int index=row.Value<int>("choiceIndex");if(index>=0&&index<choices.Count&&choices[index] is JObject choice)mappedJobs[choice]=row["action"]?.Value<string>("jobId");}}
            var custom=CustomData(player);
            memory=custom.TryGetValue(MemoryKey,out string raw)?JsonConvert.DeserializeObject<DialogueMemory>(raw)??new DialogueMemory():new DialogueMemory();
            storyFlags=new HashSet<string>(owner.Definitions.Commissions.Values.SelectMany(c=>c.completionFlags).Concat(nodes.Values.SelectMany(n=>Strings(n,"setFlags"))).Concat(nodes.Values.SelectMany(n=>((JArray)n["choices"]).OfType<JObject>().SelectMany(c=>Strings(c,"setFlags")))),StringComparer.Ordinal);
            foreach(var action in owner.Definitions.Talks)foreach(string flag in Strings(action,"setsWorldFacts"))storyFlags.Add(flag);
            foreach(string flag in memory.flags.Where(f=>IsApprovedStoryFlag(f)&&!Protected(f)&&owner.Definitions.Commissions.Values.Any(c=>c.requiresFlags.Contains(f))&&owner.Commerce.State?.flags.Contains(f)!=true))PendingStoryFlags.Enqueue(flag);
            foreach(string node in memory.pendingNodeFacts.ToArray())QueueNodeFacts(node);
            Enter(Flag("abbey_item_carried")&&!Flag("abbey_topic")&&!Flag("item_prompt_seen")?"item_entry":!Flag("met_wayfarer")&&!Flag("abbey_topic")?"first_meeting":"root");
        }
        static Dictionary<string,string> CustomData(Player p)=>(Dictionary<string,string>)AccessTools.Field(typeof(Player),"m_customData").GetValue(p);
        void Save()=>CustomData(player)[MemoryKey]=JsonConvert.SerializeObject(memory);
        static IEnumerable<string> Strings(JObject row,string key)=>row[key] is JArray a?a.Values<string>():Array.Empty<string>();
        public static bool IsApprovedStoryFlag(string flag)=>flag!=null&&storyFlags.Contains(flag)&&!flag.EndsWith("_done",StringComparison.Ordinal)&&!flag.EndsWith("_accepted",StringComparison.Ordinal);
        bool Protected(string flag)=>(mapping["protectedNativeFacts"] as JArray??new JArray()).Values<string>().Contains(flag);
        public string[] Knowledge()=>memory.flags.Concat(RuntimeFacts.Flags(player)).Concat(nodes.Values.SelectMany(n=>new[]{n}.Concat(((JArray)n["choices"]).OfType<JObject>())).SelectMany(n=>Strings(n,"requiresAll").Concat(Strings(n,"requiresAny"))).Where(Flag)).Distinct().ToArray();
        public readonly Queue<string> PendingNodeFacts=new Queue<string>();
        public bool Flag(string flag)
        {
            var state=plugin.Commerce.State;
            if(flag=="strange_coin_carried")return plugin.Definitions.Inventory(player.GetInventory()).TryGetValue(CommercePolicy.StrangeCoinId,out long coins)&&coins>0;
            if(flag=="abbey_item_carried")return plugin.Definitions.AbbeyItemCarried(plugin.Definitions.Inventory(player.GetInventory()));
            string job=mapping["doneAliases"]?.Value<string>(flag);if(job!=null)return state?.completed.Contains(job)==true;
            job=mapping["acceptAliases"]?.Value<string>(flag);if(job!=null)return state?.accepted.ContainsKey(job)==true&&state.completed.Contains(job)!=true;
            if(Protected(flag))return RuntimeFacts.Have(player,flag)||state?.flags.Contains(flag)==true;
            if(flag=="abbey_topic"||flag=="ledger_read"||flag=="met_wayfarer"||flag=="other_worlds_admitted")return memory.flags.Contains(flag)||RuntimeFacts.Have(player,flag);
            if(flag=="q_mark_found")return Carried("bronze_offcuts")>=4;
            if(flag=="q_records_found")return Carried("ordinary_books")>=1&&Carried("scrolls")>=1;
            if(flag=="q_casting_found")return Carried("bronze_offcuts")>=8;
            if(flag=="ember_plan_carried")return Carried("oswin_last_bell_plans")>0;
            if(flag=="holy_plan_carried")return Carried("consecrated_bell_pattern")>0;
            if(flag=="abbot_defeated")return state?.abbeyVictories>0;
            return memory.flags.Contains(flag)||RuntimeFacts.Have(player,flag)||state?.flags.Contains(flag)==true;
        }
        long Carried(string id)=>plugin.Definitions.Inventory(player.GetInventory()).TryGetValue(id,out long amount)?amount:0;
        bool Allowed(JObject row,Func<string,bool> known=null)
        {
            known=known??Flag;
            if(row.Value<bool?>("retired")==true)return false;
            if(!Strings(row,"requiresAll").All(known)||Strings(row,"requiresNone").Any(known))return false;
            var any=Strings(row,"requiresAny").ToArray();if(any.Length>0&&!any.Any(known))return false;
            if(row["commissionGate"] is JObject gate)
            {
                string id=gate.Value<string>("jobId");id=id=="repairs"?"first_repairs":id=="relic_appraisal"?"first_relic":id;
                var state=plugin.Commerce.State;bool accepted=state?.accepted.ContainsKey(id)==true,done=state?.completed.Contains(id)==true;
                if(done)return false;
                if(gate["accepted"]!=null&&gate.Value<bool>("accepted")!=accepted)return false;
                if(gate["pending"]!=null&&gate.Value<bool>("pending")!=plugin.Commerce.Busy)return false;
                if(plugin.Definitions.Commissions.TryGetValue(id,out var job))
                {CommerceProgress progress=null;if(state!=null)state.accepted.TryGetValue(id,out progress);var inventory=plugin.Definitions.Inventory(player.GetInventory());if(gate["hasNeeded"]!=null&&gate.Value<bool>("hasNeeded")!=ConversationGates.HasDelivery(job,progress,inventory))return false;if(gate["hasRelic"]!=null&&gate.Value<bool>("hasRelic")!=job.appraisalGroups.SelectMany(g=>g).Any(key=>inventory.TryGetValue(key,out long n)&&n>0))return false;}
            }
            return true;
        }
        static bool Navigation(JObject choice)=>choice.Value<string>("to")=="@leave"||choice.Value<string>("to")=="root"||choice.Value<string>("to")=="first_meeting"||ReturnChoice(choice);
        static bool ReturnChoice(JObject choice)=>choice.Value<string>("player")=="Something else."||choice.Value<string>("player")=="Let us talk about something else.";
        static bool ExternalMenu(string target)=>target=="@available_shop"||target=="@simple_shop"||target=="@equipment";
        bool ActionAvailable(JObject choice)
        {
            if(choice["exchange"]!=null)return !plugin.Commerce.Busy&&Carried(CommercePolicy.OrdinaryCoinId)>=1000;
            string id=JobForChoice(choice);if(id==null)return true;
            var state=plugin.Commerce.State;
            if(plugin.Commerce.Busy||state==null||!plugin.Definitions.Commissions.TryGetValue(id,out var job)||state.completed.Contains(id))return false;
            string kind=choice["commissionAction"]?.Value<string>("type")??choice["commerceAction"]?.Value<string>("kind");
            bool accept=kind=="accept"||kind=="accept_commission"||Strings(choice,"setFlags").Any(f=>mapping["acceptAliases"]?.Value<string>(f)==id);
            if(accept)return !state.accepted.ContainsKey(id)&&ConversationGates.CanOffer(state,job);
            if(!state.accepted.TryGetValue(id,out var progress))return false;
            var inventory=plugin.Definitions.Inventory(player.GetInventory());
            if(kind=="appraise")return job.appraisalGroups.SelectMany(g=>g).Any(key=>inventory.TryGetValue(key,out long n)&&n>0&&!progress.shown.Contains(key));
            return ConversationGates.HasDelivery(job,progress,inventory)||CommercePolicy.CompleteRequirements(state,job,progress);
        }
        bool ChoiceAvailable(JObject choice)
        {
            if(choice==null||!Allowed(choice)||!ActionAvailable(choice))return false;
            if(Strings(choice,"exhaustedByNodes").Any()&&Strings(choice,"exhaustedByNodes").All(memory.visited.Contains))return false;
            string target=choice.Value<string>("to");
            // A player's line can establish knowledge required by the reply
            // (for example reporting smoke). Evaluate that entrance after the
            // same safe personal flags ApplyFlags will actually apply.
            var gained=new HashSet<string>(Strings(choice,"setFlags").Where(f=>!f.EndsWith("_done",StringComparison.Ordinal)&&!f.EndsWith("_accepted",StringComparison.Ordinal)&&!Protected(f)),StringComparer.Ordinal);
            var removed=new HashSet<string>(Strings(choice,"unsetFlags"),StringComparer.Ordinal);
            return target=="@leave"||ExternalMenu(target)||(target!=null&&nodes.TryGetValue(target,out var node)&&Allowed(node,f=>!removed.Contains(f)&&(gained.Contains(f)||Flag(f))));
        }
        bool Fresh(string id,HashSet<string> path)
        {
            if(id==null)return false;if(id.StartsWith("@",StringComparison.Ordinal))return ExternalMenu(id);
            if(!path.Add(id)||!nodes.TryGetValue(id,out var node)||!Allowed(node))return false;
            if(!memory.visited.Contains(id))return true;
            return ((JArray)node["choices"]).OfType<JObject>().Any(c=>!Navigation(c)&&ChoiceAvailable(c)&&(c["commissionAction"]!=null||c["exchange"]!=null||JobForChoice(c)!=null||Strings(c,"setFlags").Any(f=>!Flag(f))||Fresh(c.Value<string>("to"),new HashSet<string>(path,StringComparer.Ordinal))));
        }
        List<JObject> ChoicesFor(string id)
        {
            if(!nodes.TryGetValue(id,out var node))return new List<JObject>();
            return ((JArray)node["choices"]).OfType<JObject>().Where(c=>ChoiceAvailable(c)&&(Navigation(c)||c["commissionAction"]!=null||c["exchange"]!=null||JobForChoice(c)!=null||Strings(c,"setFlags").Any(f=>!Flag(f))||Fresh(c.Value<string>("to"),new HashSet<string>(StringComparer.Ordinal){id}))).ToList();
        }
        public List<JObject> Menu()
        {
            var current=ChoicesFor(Current);
            MenuNode=Current;
            if(Current=="root"||Current=="first_meeting"||current.Any(c=>!Navigation(c)))return current;
            // Do not revisit a transaction or unfinished commission on the way
            // back. Its old trail may no longer be usable after inventory changes.
            MenuNode="root";
            return ChoicesFor("root");
        }
        public void GoRoot(){Enter("root");WayfarerTradeUI.ShowDialogue();}
        void ApplyFlags(JObject record)
        {
            foreach(var flag in Strings(record,"setFlags"))
            {
                if(flag.EndsWith("_done",StringComparison.Ordinal)||flag.EndsWith("_accepted",StringComparison.Ordinal)||Protected(flag))continue;
                bool added=memory.flags.Add(flag);if(added&&IsApprovedStoryFlag(flag)&&plugin.Definitions.Commissions.Values.Any(c=>c.completionFlags.Contains(flag)||c.requiresFlags.Contains(flag)))PendingStoryFlags.Enqueue(flag);
            }
            foreach(var flag in Strings(record,"unsetFlags"))memory.flags.Remove(flag);Save();
        }
        void Enter(string id)
        {
            if(!nodes.TryGetValue(id,out var node))id="root";node=nodes[id];
            Current=id;MenuNode=id;memory.visited.Add(id);ApplyFlags(node);
            QueueNodeFacts(id);
        }
        void QueueNodeFacts(string id)
        {
            var fact=mapping["nodeFacts"]?[id] as JObject;var state=plugin.Commerce.State;if(fact==null||state==null)return;
            if(Strings(fact,"setWorldFacts").All(state.flags.Contains)){if(memory.pendingNodeFacts.Remove(id))Save();return;}
            if(plugin.Definitions.ConversationAllowed(fact,state,plugin.Definitions.Inventory(player.GetInventory()),new HashSet<string>(Knowledge(),StringComparer.Ordinal))){memory.pendingNodeFacts.Add(id);Save();PendingNodeFacts.Enqueue(id);}
        }
        public IEnumerable<JObject> AvailableTalks(string job=null)
        {
            var state=plugin.Commerce.State;if(state==null)return Array.Empty<JObject>();var inventory=plugin.Definitions.Inventory(player.GetInventory());var knowledge=new HashSet<string>(Knowledge(),StringComparer.Ordinal);
            return plugin.Definitions.Talks.Where(a=>(job==null||a.Value<string>("jobId")==job)&&(!Strings(a,"hideWhenWorldFactsKnown").Any()||!Strings(a,"hideWhenWorldFactsKnown").All(state.flags.Contains))&&plugin.Definitions.ConversationAllowed(a,state,inventory,knowledge)).ToArray();
        }
        public void Talk(JObject action)
        {if(plugin.Commerce.Busy)return;WayfarerTradeUI.AwaitSpokenLine(action.Value<string>("npc"));plugin.Commerce.Request("talk",action.Value<string>("id"));}
        string JobForChoice(JObject choice)
        {
            string direct=choice["commissionAction"]?.Value<string>("jobId");if(direct!=null)return direct=="repairs"?"first_repairs":direct=="relic_appraisal"?"first_relic":direct;
            if(mappedJobs.TryGetValue(choice,out string mapped))return mapped;
            foreach(string flag in Strings(choice,"setFlags")){string job=mapping["acceptAliases"]?.Value<string>(flag)??mapping["doneAliases"]?.Value<string>(flag);if(job!=null)return job;}
            return null;
        }
        public void Choose(JObject choice)
        {
            // Recheck live inventory and world state; a displayed option may
            // have become stale while another player finishes the same job.
            if(!ChoiceAvailable(choice)){GoRoot();return;}
            string target=choice.Value<string>("to")??"root";
            if(target=="@leave"){WayfarerTradeUI.Close();return;}
            string jobForAction=JobForChoice(choice);if(jobForAction!=null){WayfarerTradeUI.ShowCommission(jobForAction);return;}
            if(choice["exchange"]!=null){plugin.Commerce.Request("exchange");return;}
            if(target=="@equipment"){WayfarerTradeUI.ShowCommissions();return;}
            if(ExternalMenu(target)){WayfarerTradeUI.ShowShop();return;}
            if(choice["commissionAction"]?.Value<string>("type")!="cancel"&&(choice["commissionAction"]!=null||Strings(choice,"setFlags").Any(f=>f.EndsWith("_accepted",StringComparison.Ordinal)||f.EndsWith("_done",StringComparison.Ordinal))))
            {WayfarerTradeUI.ShowCommissions();return;}
            ApplyFlags(choice);Enter(target);WayfarerTradeUI.ShowDialogue();
        }
        public void MarkLedgerRead(){memory.flags.Add("ledger_read");Save();}
    }
}
