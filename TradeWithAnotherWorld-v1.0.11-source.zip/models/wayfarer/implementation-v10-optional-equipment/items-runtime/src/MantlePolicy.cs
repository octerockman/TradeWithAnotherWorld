using System;
using System.Collections.Generic;
using System.Globalization;

namespace Wayfarer.Items
{
    public static class MantlePolicy
    {
        public const float Capacity=5f,EnvironmentalHeatReduction=.25f;
        public const string ReserveKey="TWA_WF_MantleReserve_v1";
        public static float Clamp(float value)=>float.IsNaN(value)||float.IsInfinity(value)?0:Math.Max(0,Math.Min(Capacity,value));
        public static float Read(IDictionary<string,string> data)
        {
            if(!data.TryGetValue(ReserveKey,out string text)){data[ReserveKey]=Capacity.ToString("R",CultureInfo.InvariantCulture);return Capacity;}
            return float.TryParse(text,NumberStyles.Float,CultureInfo.InvariantCulture,out float n)?Clamp(n):0;
        }
        public static float Step(float reserve,float seconds,bool worn,bool alive,bool smoke)
        {
            reserve=Clamp(reserve);
            if(!worn||!alive||float.IsNaN(seconds)||float.IsInfinity(seconds)||seconds<=0)return reserve;
            return Clamp(reserve+(smoke?-seconds:seconds));
        }
        public static void Write(IDictionary<string,string> data,float reserve)=>data[ReserveKey]=Clamp(reserve).ToString("R",CultureInfo.InvariantCulture);
    }
}
