using System;using System.Collections.Generic;using HarmonyLib;
namespace Wayfarer.Items
{
    // Vanilla uses upgrade multipliers 1,2,4. Our reviewed fragment schedules
    // are explicit per-quality amounts and affect only these exact requirements.
    [HarmonyPatch(typeof(Piece.Requirement),nameof(Piece.Requirement.GetAmount))]
    public static class RegistryQualityRules
    {
        static readonly Dictionary<Piece.Requirement,int[]> Costs=new Dictionary<Piece.Requirement,int[]>();
        public static void Bind(Piece.Requirement requirement,int[] costs)
        {if(requirement==null||costs==null||costs.Length!=3)throw new ArgumentException("Three quality costs required.");Costs[requirement]=(int[])costs.Clone();}
        static bool Prefix(Piece.Requirement __instance,int qualityLevel,ref int __result)
        {if(!Costs.TryGetValue(__instance,out var costs))return true;__result=qualityLevel>=2&&qualityLevel<=4?costs[qualityLevel-2]:0;return false;}
    }
}
