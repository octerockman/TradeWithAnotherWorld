using System;
using System.Linq;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    [HarmonyPatch(typeof(Attack),"FireProjectileBurst")]
    static class JewelleryCuratedSpellSpreadPatch
    {
        static void Prefix(Attack __instance,out float[] __state)
        {
            __state=null;var player=AccessTools.Field(typeof(Attack),"m_character").GetValue(__instance) as Player;var weapon=__instance.GetWeapon();
            if(!player||!weapon?.m_dropPrefab||weapon.m_dropPrefab.name!="StaffIceShards"||!__instance.m_attackProjectile||__instance.m_attackProjectile.name!="staff_iceshard_projectile"||__instance.m_circularProjectileLaunch||__instance.m_distributeProjectilesAroundCircle||!JewelleryRuntime.For(player).Has("ms_stillhand_signet"))return;
            __state=new[]{__instance.m_projectileAccuracy,__instance.m_projectileAccuracyMin};__instance.m_projectileAccuracy*=.8f;__instance.m_projectileAccuracyMin*=.8f;
        }
        static void Postfix(Attack __instance,float[] __state){if(__state!=null){__instance.m_projectileAccuracy=__state[0];__instance.m_projectileAccuracyMin=__state[1];}}
    }
    public static class JewelleryBoundWard
    {
        [ThreadStatic]public static Player SelfCastPlayer;
        static readonly Dictionary<SE_Shield,float> baseDurations=new Dictionary<SE_Shield,float>();
        static readonly System.Reflection.FieldInfo character=AccessTools.Field(typeof(StatusEffect),"m_character");
        public static void Applied(SE_Shield shield)
        {
            var p=character.GetValue(shield) as Player;if(!p||p!=SelfCastPlayer||p!=Player.m_localPlayer||shield.NameHash()!="Staff_shield".GetStableHashCode()||!JewelleryRuntime.For(p).Has("sd_bound_ward_ring"))return;
            float normal=shield.m_ttl;if(normal<=0)return;baseDurations[shield]=normal;shield.m_ttl=normal*1.15f;
        }
        public static void Tick(Player p)
        {
            if(!p||p!=Player.m_localPlayer)return;bool keep=JewelleryRuntime.For(p).Has("sd_bound_ward_ring");
            foreach(var pair in baseDurations.ToArray())
            {
                var shield=pair.Key;if(!shield||shield.IsDone()){baseDurations.Remove(shield);continue;}
                if(!keep){shield.m_ttl=Math.Min(shield.m_ttl,pair.Value);baseDurations.Remove(shield);}
            }
        }
    }
    [HarmonyPatch(typeof(Character),"RPC_Damage")]
    static class JewellerySelfShieldSourceScope
    {
        static void Prefix(Character __instance,HitData __1,out Player __state)
        {
            __state=JewelleryBoundWard.SelfCastPlayer;var p=__instance as Player;
            JewelleryBoundWard.SelfCastPlayer=p&&p==Player.m_localPlayer&&__1.m_statusEffectHash=="Staff_shield".GetStableHashCode()&&__1.GetAttacker()==p?p:null;
        }
        static Exception Finalizer(Exception __exception,Player __state){JewelleryBoundWard.SelfCastPlayer=__state;return __exception;}
    }
    [HarmonyPatch(typeof(SE_Shield),"SetLevel")]
    static class JewelleryBoundWardDurationPatch{static void Postfix(SE_Shield __instance){JewelleryBoundWard.Applied(__instance);}}
}
