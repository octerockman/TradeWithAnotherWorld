using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using UnityEngine;
using Jotunn.Managers;
using Wayfarer.InGame;
using Object=UnityEngine.Object;

namespace Wayfarer.Items
{
    // Reuse the installed source-bound visual builder. Item resources have
    // their own cache: opening one item never loads every shop texture.
    public sealed class ItemVisualCache:IDisposable
    {
        readonly string folder;
        readonly Action<string> log;
        readonly Dictionary<string,JObject> entries=new Dictionary<string,JObject>(StringComparer.Ordinal);
        readonly Dictionary<string,VisualBuilder> builders=new Dictionary<string,VisualBuilder>(StringComparer.Ordinal);
        readonly Dictionary<string,Sprite> sprites=new Dictionary<string,Sprite>(StringComparer.Ordinal);
        readonly List<Object> iconResources=new List<Object>();
        Material opaque,glass;
        public int LoadedModels=>builders.Count;
        public int LoadedIcons=>sprites.Count;
        public ItemVisualCache(string root,Action<string> logger)
        {
            folder=root;log=logger;
            var m=RuntimeCatalogue.ReadJson(Path.Combine(folder,"manifest.json"),8*1024*1024);
            var all=m["items"] as JArray??m["models"] as JArray??throw new InvalidDataException("Item asset manifest has no models.");
            foreach(var entry in all.OfType<JObject>())
            {
                string id=entry.Value<string>("itemId")??entry.Value<string>("id");
                if(!RuntimeCatalogue.SafeId(id)||entries.ContainsKey(id))throw new InvalidDataException("Duplicate/unsafe item asset ID.");
                entries.Add(id,entry);
            }
            foreach(string overlayName in new[]{"restored","fixtures","mantle"})
            {
                string restored=Path.Combine(folder,overlayName,"manifest.json");if(!File.Exists(restored))continue;
                var extra=RuntimeCatalogue.ReadJson(restored,8*1024*1024);
                foreach(var entry in ((JArray)extra["items"]).OfType<JObject>())
                {string id=entry.Value<string>("itemId")??entry.Value<string>("id");if(!RuntimeCatalogue.SafeId(id)||entries.ContainsKey(id))throw new InvalidDataException("Duplicate item overlay asset.");entries.Add(id,entry);}
            }
            if((m["jewelryIconBindings"]??m["jewelryIcons"]) is JArray icons)foreach(var entry in icons.OfType<JObject>())
            {
                string id=entry.Value<string>("itemId")??entry.Value<string>("id");
                if(!RuntimeCatalogue.SafeId(id)||entries.ContainsKey(id))throw new InvalidDataException("Duplicate jewellery asset ID.");
                entries.Add(id,new JObject{["itemId"]=id,["icon"]=entry["icon"]??entry["file"],["sharedModel"]="jewelry_pouch"});
            }
        }
        public bool Has(string assetId)=>entries.ContainsKey(assetId??"");
        string CheckedFile(JToken record)
        {
            string path=record?.Value<string>("path"),hash=record?.Value<string>("sha256");
            if(path==null||hash?.Length!=64)throw new InvalidDataException("Asset resource missing path/hash.");
            string resolved=PayloadReader.Safe(folder,path);
            if(PayloadReader.Hash(resolved)!=hash)throw new InvalidDataException("Changed item resource: "+path);
            return resolved;
        }
        public Sprite Icon(string id)
        {
            if(sprites.TryGetValue(id,out var icon))return icon;
            if(!entries.TryGetValue(id,out var record))throw new InvalidDataException("No icon source: "+id);
            string p=CheckedFile(record["icon"]);
            if(new FileInfo(p).Length>2*1024*1024)throw new InvalidDataException("Oversized inventory icon.");
            var tex=new Texture2D(2,2,TextureFormat.RGBA32,false,false);
            if(!ImageConversion.LoadImage(tex,File.ReadAllBytes(p),false)||tex.width!=256||tex.height!=256){Object.Destroy(tex);throw new InvalidDataException("Expected a256px item icon.");}
            tex.name="WF_Icon_"+id;tex.wrapMode=TextureWrapMode.Clamp;tex.Apply(false,true);iconResources.Add(tex);
            icon=Sprite.Create(tex,new Rect(0,0,tex.width,tex.height),new Vector2(.5f,.5f),100);icon.name="WF_Icon_"+id;iconResources.Add(icon);sprites.Add(id,icon);return icon;
        }
        void ResolveTemplates()
        {
            if(opaque)return;
            var source=PrefabManager.Instance.GetPrefab("Skeleton");
            opaque=source?source.GetComponentsInChildren<Renderer>(true).SelectMany(r=>r.sharedMaterials).FirstOrDefault(m=>m&&m.shader&&m.shader.name=="Custom/Creature"):null;
            var crystal=PrefabManager.Instance.GetPrefab("crystal_wall_1x1");
            glass=crystal?crystal.GetComponentsInChildren<Renderer>(true).SelectMany(r=>r.sharedMaterials).FirstOrDefault(m=>m&&m.shader&&m.shader.name=="Standard"&&m.name.StartsWith("crystal_window",StringComparison.OrdinalIgnoreCase)):null;
            if(!opaque||!glass)throw new InvalidOperationException("Native item material templates unavailable.");
        }
        VisualBuilder Builder(string id)
        {
            if(!entries.TryGetValue(id,out var record))throw new InvalidDataException("No item mesh source: "+id);
            string shared=record.Value<string>("sharedModel");if(!string.IsNullOrEmpty(shared))return Builder(shared);
            if(builders.TryGetValue(id,out var builder))return builder;
            ResolveTemplates();string payload=CheckedFile(record["payload"]);
            var p=PayloadReader.Read<VisualPayload>(payload);
            if(p?.schema!="wayfarer.item-visual.v1"||p.nodes==null||p.renderers==null||p.materials==null||p.nodes.Length>2048||p.renderers.Length>256)throw new InvalidDataException("Invalid item visual schema/budget.");
            builder=new VisualBuilder(p,folder,opaque,glass,log);builder.PrepareMaterials();builders.Add(id,builder);return builder;
        }
        public Dictionary<string,Transform> Attach(string id,Transform parent,int layer,bool held)
        {
            var builder=Builder(id);var root=new GameObject("WayfarerItemVisual_"+id).transform;root.SetParent(parent,false);
            var nodes=builder.Build(root,layer,false);
            // The installed camp builder clamps all crystal alpha. Restore the
            // separately authored liquid tint for these item-only materials.
            var materialRoles=builder.Payload.materials.ToDictionary(m=>"WF_"+m.name,m=>m,StringComparer.Ordinal);
            foreach(var r in root.GetComponentsInChildren<Renderer>(true))foreach(var material in r.sharedMaterials)
            {
                if(!material||!materialRoles.TryGetValue(material.name,out var source))continue;
                if(source.shaderHint=="liquid_volume"&&material.HasProperty("_Color"))
                {var c=material.GetColor("_Color");var color=source.color??source.baseColor;c.a=color?.Length==4?Mathf.Clamp(color[3],.3f,.85f):.65f;material.SetColor("_Color",c);}
                if(source.shaderHint=="glass_shell")material.SetShaderPassEnabled("ShadowCaster",false);
            }
            foreach(var renderer in root.GetComponentsInChildren<Renderer>(true))
                if(renderer.sharedMaterials.Length>0&&renderer.sharedMaterials.All(m=>m&&materialRoles.TryGetValue(m.name,out var role)&&role.shaderHint=="glass_shell"))renderer.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;
            if(held)
            {
                var grip=nodes.FirstOrDefault(n=>n.Key.EndsWith("Grip",StringComparison.OrdinalIgnoreCase)||n.Key=="Grip").Value;
                if(grip){var local=root.InverseTransformPoint(grip.position);root.localPosition-=local;}
            }
            return nodes;
        }
        public Bounds Bounds(string id)
        {
            var b=Builder(id);return new Bounds((PayloadReader.V(b.Payload.boundsMin)+PayloadReader.V(b.Payload.boundsMax))*.5f,PayloadReader.V(b.Payload.boundsMax)-PayloadReader.V(b.Payload.boundsMin));
        }
        public void Dispose(){foreach(var b in builders.Values)b.Dispose();foreach(var o in iconResources)if(o)Object.Destroy(o);builders.Clear();sprites.Clear();iconResources.Clear();}
    }

    public sealed class DeferredItemVisual:MonoBehaviour
    {
        public string AssetId;
        public bool Held;
        bool built;
        void Start()
        {
            if(built||string.IsNullOrEmpty(AssetId))return;
            var plugin=ItemsPlugin.Instance;if(!plugin||!plugin.AssetsReady)return;
            try
            {
                plugin.Visuals.Attach(AssetId,transform,gameObject.layer,Held);built=true;
                if(!Held)
                {
                    var box=GetComponent<BoxCollider>();if(box){var bounds=plugin.Visuals.Bounds(AssetId);box.center=bounds.center;box.size=new Vector3(Mathf.Max(bounds.size.x,.01f),Mathf.Max(bounds.size.y,.01f),Mathf.Max(bounds.size.z,.01f));}
                }
            }
            catch(Exception e){plugin.Warn("ITEM_VISUAL_FAILED "+AssetId+" "+e);}
        }
    }
}
