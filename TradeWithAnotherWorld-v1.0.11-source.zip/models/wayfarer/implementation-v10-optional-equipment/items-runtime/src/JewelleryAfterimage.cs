using System;
using System.Linq;
using System.Collections.Generic;
using HarmonyLib;
using Jotunn.Entities;
using Jotunn.Managers;
using UnityEngine;

namespace Wayfarer.Items
{
    public sealed class JewelleryDecoy:MonoBehaviour
    {
        public const string Prefab="TWA_WF_Afterimage_Decoy_v1";
        ZNetView view;Vector3 fixedPosition;Quaternion fixedRotation;bool visual;double created;Renderer[] scaffold;
        readonly List<Mesh> baked=new List<Mesh>();
        void Awake()
        {
            view=GetComponent<ZNetView>();fixedPosition=transform.position;fixedRotation=transform.rotation;created=JewelleryRuntime.Now;
            scaffold=GetComponentsInChildren<Renderer>(true);foreach(var renderer in scaffold)renderer.enabled=false;
            var body=GetComponent<Rigidbody>();if(body){body.constraints=RigidbodyConstraints.FreezeAll;body.useGravity=false;}
        }
        void Update()
        {
            if(!view||!view.IsValid())return;var zdo=view.GetZDO();
            long user=zdo.GetLong("TWA_WF_DecoyUser",0);uint id=unchecked((uint)zdo.GetInt("TWA_WF_DecoyId",0));
            var source=Player.GetAllPlayers().FirstOrDefault(p=>p&&p.GetZDOID().UserID==user&&p.GetZDOID().ID==id);
            if(view.IsOwner()&&user!=0&&(!source||source.IsDead())){if(ZNetScene.instance)ZNetScene.instance.Destroy(gameObject);return;}
            if(!visual)
            {
                if(source){Snapshot(source);visual=true;}
            }
            double expires=zdo.GetLong("TWA_WF_DecoyExpiresMs",(long)((created+2)*1000))/1000.0;
            if(view.IsOwner()&&(JewelleryRuntime.Now>=expires||JewelleryRuntime.Now-created>3)&&ZNetScene.instance)ZNetScene.instance.Destroy(gameObject);
        }
        void LateUpdate(){transform.SetPositionAndRotation(fixedPosition,fixedRotation);foreach(var renderer in scaffold)if(renderer)renderer.enabled=false;}
        void Snapshot(Player source)
        {
            foreach(var skin in source.GetComponentsInChildren<SkinnedMeshRenderer>())
            {
                if(!skin.enabled||!skin.sharedMesh)continue;var mesh=new Mesh();skin.BakeMesh(mesh);baked.Add(mesh);
                var go=new GameObject("Silent Afterimage Surface",typeof(MeshFilter),typeof(MeshRenderer));go.transform.SetParent(transform,false);
                go.transform.localPosition=source.transform.InverseTransformPoint(skin.transform.position);go.transform.localRotation=Quaternion.Inverse(source.transform.rotation)*skin.transform.rotation;go.transform.localScale=skin.transform.lossyScale;
                go.GetComponent<MeshFilter>().sharedMesh=mesh;var r=go.GetComponent<MeshRenderer>();r.sharedMaterials=skin.sharedMaterials;r.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;r.receiveShadows=false;
            }
            foreach(var sourceMesh in source.GetComponentsInChildren<MeshFilter>())
            {
                var sourceRenderer=sourceMesh.GetComponent<MeshRenderer>();if(!sourceRenderer||!sourceRenderer.enabled||!sourceMesh.sharedMesh)continue;
                var go=new GameObject("Silent Afterimage Equipment",typeof(MeshFilter),typeof(MeshRenderer));go.transform.SetParent(transform,false);go.transform.localPosition=source.transform.InverseTransformPoint(sourceMesh.transform.position);go.transform.localRotation=Quaternion.Inverse(source.transform.rotation)*sourceMesh.transform.rotation;go.transform.localScale=sourceMesh.transform.lossyScale;
                go.GetComponent<MeshFilter>().sharedMesh=sourceMesh.sharedMesh;var r=go.GetComponent<MeshRenderer>();r.sharedMaterials=sourceRenderer.sharedMaterials;r.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;r.receiveShadows=false;
            }
        }
        void OnDestroy(){foreach(var mesh in baked)if(mesh)Destroy(mesh);}
    }
    public static class JewelleryAfterimage
    {
        static GameObject prefab;static bool registered;
        public static void Init(){PrefabManager.OnVanillaPrefabsAvailable+=Register;}
        public static void Dispose(){PrefabManager.OnVanillaPrefabsAvailable-=Register;}
        static void Register()
        {
            if(registered)return;
            try
            {
                var manager=PrefabManager.Instance;var source=manager.GetPrefab("Greydwarf");if(!source)throw new InvalidOperationException("Native Greydwarf actor scaffold unavailable.");
                prefab=manager.CreateClonedPrefab(JewelleryDecoy.Prefab,source);prefab.SetActive(false);
                foreach(var component in prefab.GetComponentsInChildren<BaseAI>(true))UnityEngine.Object.DestroyImmediate(component);
                foreach(var component in prefab.GetComponentsInChildren<CharacterDrop>(true))UnityEngine.Object.DestroyImmediate(component);
                foreach(var component in prefab.GetComponentsInChildren<AudioSource>(true))UnityEngine.Object.DestroyImmediate(component);
                foreach(var component in prefab.GetComponentsInChildren<FootStep>(true))UnityEngine.Object.DestroyImmediate(component);
                foreach(var component in prefab.GetComponentsInChildren<ItemDrop>(true))UnityEngine.Object.DestroyImmediate(component);
                foreach(var collider in prefab.GetComponentsInChildren<Collider>(true))collider.isTrigger=true;
                var humanoid=prefab.GetComponent<Humanoid>();if(humanoid){humanoid.m_defaultItems=Array.Empty<GameObject>();humanoid.m_randomWeapon=Array.Empty<GameObject>();humanoid.m_randomArmor=Array.Empty<GameObject>();humanoid.m_randomShield=Array.Empty<GameObject>();humanoid.m_randomSets=Array.Empty<Humanoid.ItemSet>();humanoid.m_randomItems=Array.Empty<Humanoid.RandomItem>();}
                var actor=prefab.GetComponent<Character>();actor.m_name="";actor.m_faction=Character.Faction.Players;actor.m_boss=false;actor.m_bossEvent="";actor.m_hitEffects=new EffectList();actor.m_critHitEffects=new EffectList();actor.m_backstabHitEffects=new EffectList();actor.m_deathEffects=new EffectList();actor.m_deathAnimation=false;
                var view=prefab.GetComponent<ZNetView>();view.m_persistent=false;
                prefab.AddComponent<JewelleryDecoy>();manager.AddPrefab(new CustomPrefab(prefab,false));prefab.SetActive(true);registered=true;JewelleryRuntime.NativeHooksReady.Add("ms_afterimage_knot");
                PrefabManager.OnVanillaPrefabsAvailable-=Register;
            }
            catch(Exception e){ItemsPlugin.Instance?.Warn("AFTERIMAGE_NOT_ADMITTED "+e.Message);}
        }
        public static void FinishedDodge(Player p)
        {
            if(!registered||!p||p!=Player.m_localPlayer||p.IsDead()||p.IsStaggering()||p.GetHealthPercentage()>.4f||!JewelleryRuntime.For(p).Has("ms_afterimage_knot"))return;
            var state=JewelleryRuntime.State(p);if(!state.Ready("ms_afterimage_knot",JewelleryRuntime.Now))return;
            var go=UnityEngine.Object.Instantiate(prefab,p.transform.position,p.transform.rotation);var view=go.GetComponent<ZNetView>();if(!view||!view.IsOwner()){if(go)UnityEngine.Object.Destroy(go);return;}
            var id=p.GetZDOID();view.GetZDO().Set("TWA_WF_DecoyUser",id.UserID);view.GetZDO().Set("TWA_WF_DecoyId",unchecked((int)id.ID));view.GetZDO().Set("TWA_WF_DecoyExpiresMs",(long)((JewelleryRuntime.Now+2)*1000));
            state.Cooldown("ms_afterimage_knot",JewelleryRuntime.Now,30);JewelleryRuntime.Save();
        }
        public static bool MayConsider(BaseAI ai,JewelleryDecoy decoy,bool validatePath=true)
        {
            var actor=ai.GetComponent<Character>();if(!(ai is MonsterAI)||!actor||actor.IsBoss()||actor.IsTamed()||actor.IsDead()||actor.InAttack()||Vector3.Distance(actor.transform.position,decoy.transform.position)>8)return false;
            string name=actor.name;bool ordinary=!name.StartsWith("TWA_",StringComparison.Ordinal)&&!name.StartsWith("BA_",StringComparison.Ordinal)&&name.IndexOf("hildir",StringComparison.OrdinalIgnoreCase)<0&&name.IndexOf("knight",StringComparison.OrdinalIgnoreCase)<0;
            return ordinary&&(!validatePath||(bool)AccessTools.Method(typeof(BaseAI),"HavePath",new[]{typeof(Vector3)}).Invoke(ai,new object[]{decoy.transform.position}));
        }
    }
    [HarmonyPatch(typeof(BaseAI),"CanSenseTarget",new[]{typeof(Character)})]
    static class JewelleryDecoyNativePerception
    {static void Postfix(BaseAI __instance,Character __0,ref bool __result){if(__result&&__0){var decoy=__0.GetComponent<JewelleryDecoy>();if(decoy)__result=JewelleryAfterimage.MayConsider(__instance,decoy);}}}
    [HarmonyPatch(typeof(BaseAI),"IsEnemy",new[]{typeof(Character),typeof(Character)})]
    static class JewelleryDecoyNoScriptedAggro
    {static void Postfix(Character __0,Character __1,ref bool __result){if(__result&&__1){var decoy=__1.GetComponent<JewelleryDecoy>();if(decoy){var ai=__0?__0.GetComponent<BaseAI>():null;__result=ai&&JewelleryAfterimage.MayConsider(ai,decoy,false);}}}}
    [HarmonyPatch(typeof(Player),"UpdateDodge")]
    static class JewelleryAfterimageDodgeCompletion
    {
        static readonly System.Reflection.FieldInfo dodging=AccessTools.Field(typeof(Player),"m_inDodge"),hit=AccessTools.Field(typeof(Player),"m_beenHitWhileDodging");
        static void Prefix(Player __instance,out bool __state){__state=__instance==Player.m_localPlayer&&(bool)dodging.GetValue(__instance);}
        static void Postfix(Player __instance,bool __state){if(__state&&!(bool)dodging.GetValue(__instance)&&!(bool)hit.GetValue(__instance))JewelleryAfterimage.FinishedDodge(__instance);}
    }
    [HarmonyPatch(typeof(Character),"RPC_Damage")]
    static class JewelleryDecoyNoSkillDamage
    {static void Prefix(Character __instance,HitData __1){if(__instance.GetComponent<JewelleryDecoy>())__1.m_skillRaiseAmount=0;}}
}
