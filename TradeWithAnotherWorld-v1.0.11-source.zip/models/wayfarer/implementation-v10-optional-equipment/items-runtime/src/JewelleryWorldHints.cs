using System;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace Wayfarer.Items
{
    public sealed class JewelleryWorldHints:MonoBehaviour
    {
        static JewelleryWorldHints live;
        static readonly Dictionary<Attack,Tuple<Character,double>> windups=new Dictionary<Attack,Tuple<Character,double>>();
        static readonly ConditionalWeakTable<Attack,object> released=new ConditionalWeakTable<Attack,object>();
        sealed class ReleaseFrame{public int frame;}
        static readonly ConditionalWeakTable<Attack,ReleaseFrame> releaseFrames=new ConditionalWeakTable<Attack,ReleaseFrame>();
        static readonly HashSet<string> magicalWeapons=new HashSet<string>(new[]{"GoblinShaman_attack_fireball","GoblinShaman_attack_protect","GoblinShaman_attack_fireball_hildir","GoblinShaman_attack_protect_hildir","DvergerStaffFire_fireball","DvergerStaffFire_clusterbomb","DvergerStaffFire_fire_aoe","DvergerStaffIce_icebolt","DvergerStaffHeal_heal","DvergerStaffHeal_aoe","DvergerStaffSupport_buff","charred_magestaff_fire","charred_magestaff_summon","charred_magestaff_summoncharred"},StringComparer.Ordinal);
        readonly List<Vector3> resourcePoints=new List<Vector3>();readonly Collider[] overlaps=new Collider[512];
        float scanAt;Image wound;
        Canvas hintsCanvas;readonly List<Image> hintImages=new List<Image>();
        public static void Init(){if(!live&&ItemsPlugin.Instance)live=ItemsPlugin.Instance.gameObject.AddComponent<JewelleryWorldHints>();}
        public static void Dispose(){if(live)Destroy(live);windups.Clear();}
        public static void StartWindup(Attack attack,Humanoid actor)
        {
            released.Remove(attack);releaseFrames.Remove(attack);
            if(!actor||actor is Player)return;var weapon=attack.GetWeapon();if(weapon==null)return;
            bool magic=weapon.m_shared.m_skillType==Skills.SkillType.ElementalMagic||weapon.m_shared.m_skillType==Skills.SkillType.BloodMagic||weapon.m_dropPrefab&&magicalWeapons.Contains(weapon.m_dropPrefab.name);
            if(magic)windups[attack]=Tuple.Create((Character)actor,JewelleryRuntime.Now);
        }
        public static bool Unreleased(Attack attack)=>attack!=null&&!attack.IsDone()&&!released.TryGetValue(attack,out _);
        public static bool WindupOrRelease(Attack attack)=>attack!=null&&!attack.IsDone()&&(Unreleased(attack)||releaseFrames.TryGetValue(attack,out var f)&&f.frame==Time.frameCount);
        public static void EndWindup(Attack attack){windups.Remove(attack);if(!released.TryGetValue(attack,out _))released.Add(attack,new object());releaseFrames.Remove(attack);releaseFrames.Add(attack,new ReleaseFrame{frame=Time.frameCount});}
        void OnDestroy(){if(wound)Destroy(wound.gameObject);if(hintsCanvas)Destroy(hintsCanvas.gameObject);if(live==this)live=null;}
        static bool Visible(Player player,Vector3 point,Transform target)
        {
            Vector3 eye=player.GetEyePoint();var hits=Physics.RaycastAll(eye,point-eye,Vector3.Distance(eye,point),Physics.DefaultRaycastLayers,QueryTriggerInteraction.Ignore);
            foreach(var hit in hits)if(!hit.collider.transform.IsChildOf(player.transform)&&!(target&&(hit.collider.transform.IsChildOf(target)||target.IsChildOf(hit.collider.transform))))return false;return true;
        }
        static bool OrdinaryResource(ItemDrop drop)
        {
            if(!drop||drop.GetComponentInParent<Container>()||drop.name.StartsWith("TWA_",StringComparison.Ordinal))return false;var d=drop.m_itemData.m_shared;
            return !d.m_questItem&&d.m_value<=0&&(d.m_itemType==ItemDrop.ItemData.ItemType.Material||d.m_food>0)&&!ItemsPlugin.Instance.Catalogue.TryItem(drop.m_itemData,out _);
        }
        void Update()
        {
            var p=Player.m_localPlayer;if(!p)return;var s=JewelleryRuntime.For(p);double now=JewelleryRuntime.Now;
            foreach(var a in windups.Where(x=>!x.Value.Item1||now-x.Value.Item2>2||x.Key.IsDone()).Select(x=>x.Key).ToArray())windups.Remove(a);
            if(Time.unscaledTime>=scanAt)
            {
                scanAt=Time.unscaledTime+.4f;resourcePoints.Clear();
                if(s.Has("st_wayside_eye"))
                {
                    int count=Physics.OverlapSphereNonAlloc(p.transform.position,8,overlaps,Physics.AllLayers,QueryTriggerInteraction.Collide);var seen=new HashSet<int>();
                    for(int i=0;i<count;i++)
                    {
                        var col=overlaps[i];if(!col)continue;var drop=col.GetComponentInParent<ItemDrop>();var pick=col.GetComponentInParent<Pickable>();Transform target=null;bool eligible=OrdinaryResource(drop);
                        if(eligible)target=drop.transform;
                        else if(pick&&!JewelleryCropProvenance.Picked(pick))
                        {
                            var prefab=JewelleryCropProvenance.Output(pick);var item=prefab?prefab.GetComponent<ItemDrop>():null;
                            eligible=OrdinaryResource(item)&&!pick.GetComponentInParent<Container>();target=pick.transform;
                        }
                        if(eligible&&target&&seen.Add(target.GetInstanceID())){Vector3 point=col.bounds.center;if(Visible(p,point,target))resourcePoints.Add(point);}
                    }
                }
            }
            UpdateWound(p,s);
        }
        void UpdateWound(Player p,JewellerySnapshot s)
        {
            if(!wound&&Hud.instance)
            {
                var bar=AccessTools.Field(typeof(Hud),"m_healthBarFast")?.GetValue(Hud.instance) as Component;
                if(bar&&bar.GetComponent<RectTransform>()){var go=new GameObject("Wayfarer Recoverable Wound",typeof(RectTransform),typeof(CanvasRenderer),typeof(Image));go.transform.SetParent(bar.transform,false);wound=go.GetComponent<Image>();wound.raycastTarget=false;wound.color=new Color(1,.44f,.07f,.9f);}
            }
            if(!wound)return;float reserve=s.Has("md_witness_seal")?JewelleryRuntime.State(p).Wound(JewelleryRuntime.Now):0;
            wound.gameObject.SetActive(reserve>0&&!p.IsDead());var rect=wound.rectTransform;float max=Math.Max(1,p.GetMaxHealth());rect.anchorMin=new Vector2(Mathf.Clamp01(p.GetHealth()/max),0);rect.anchorMax=new Vector2(Mathf.Clamp01((p.GetHealth()+reserve)/max),1);rect.offsetMin=Vector2.zero;rect.offsetMax=Vector2.zero;
        }
        void LateUpdate()
        {
            foreach(var image in hintImages)image.gameObject.SetActive(false);
            var p=Player.m_localPlayer;var cam=Camera.main;if(!p||!cam||p.IsDead())return;var s=JewelleryRuntime.For(p);int index=0;
            if(s.Has("st_wayside_eye"))foreach(var point in resourcePoints){var pos=cam.WorldToScreenPoint(point);if(pos.z>0)Hint(index++,pos,new Vector2(4,4),new Color(1,.82f,.42f,.75f));}
            if(s.Has("ms_watchers_measure"))foreach(var windup in windups.Values)
            {
                var enemy=windup.Item1;Vector3 point=enemy.transform.position+Vector3.up*2;
                if(!JewelleryRuntime.Hostile(enemy,p)||Vector3.Distance(p.transform.position,enemy.transform.position)>18||!Visible(p,point,enemy.transform))continue;
                var pos=cam.WorldToScreenPoint(point);if(pos.z>0){Hint(index++,pos+Vector3.up*5,new Vector2(3,9),new Color(.88f,.69f,.99f,.9f));Hint(index++,pos-Vector3.up*3,new Vector2(3,3),new Color(.88f,.69f,.99f,.9f));}
            }
        }
        void Hint(int index,Vector3 screen,Vector2 size,Color color)
        {
            if(!hintsCanvas){var go=new GameObject("Wayfarer World Hints",typeof(RectTransform),typeof(Canvas));go.transform.SetParent(transform,false);hintsCanvas=go.GetComponent<Canvas>();hintsCanvas.renderMode=RenderMode.ScreenSpaceOverlay;hintsCanvas.sortingOrder=20;}
            while(hintImages.Count<=index){var go=new GameObject("Hint",typeof(RectTransform),typeof(CanvasRenderer),typeof(Image));go.transform.SetParent(hintsCanvas.transform,false);var image=go.GetComponent<Image>();image.raycastTarget=false;hintImages.Add(image);}
            var hint=hintImages[index];hint.gameObject.SetActive(true);hint.color=color;var rect=hint.rectTransform;rect.anchorMin=rect.anchorMax=Vector2.zero;rect.anchoredPosition=new Vector2(screen.x,screen.y);rect.sizeDelta=size;
        }
    }
    [HarmonyPatch(typeof(Attack),"Start")]
    static class JewelleryMagicWindupStartPatch{static void Postfix(Attack __instance,Humanoid __0,bool __result){if(__result)JewelleryWorldHints.StartWindup(__instance,__0);}}
    [HarmonyPatch]
    static class JewelleryMagicWindupEndPatch
    {static IEnumerable<MethodBase> TargetMethods(){foreach(string n in new[]{"OnAttackTrigger","Stop","Abort"})yield return AccessTools.Method(typeof(Attack),n);}static void Prefix(Attack __instance){JewelleryWorldHints.EndWindup(__instance);}}
    [HarmonyPatch(typeof(BaseAI),"CanSeeTarget",new[]{typeof(Transform),typeof(Vector3),typeof(float),typeof(float),typeof(bool),typeof(bool),typeof(Character)})]
    static class JewelleryInitialVisionPatch
    {
        static void Prefix(Transform __0,ref float __2,bool __4,Character __6)
        {
            var p=__6 as Player;var enemy=__0?__0.GetComponent<Character>():null;
            if(!p||!enemy||__4||enemy.IsBoss()||enemy.name.StartsWith("TWA_",StringComparison.Ordinal)||!p.IsCrouching()||Vector3.Distance(p.transform.position,enemy.transform.position)<15||!JewelleryRuntime.Hostile(enemy,p)||!JewelleryRuntime.For(p).Has("ds3_mistveil"))return;__2*=.8f;
        }
    }
}
