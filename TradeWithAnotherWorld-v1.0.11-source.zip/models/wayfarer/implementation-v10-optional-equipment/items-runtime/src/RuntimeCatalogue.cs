using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Security.Cryptography;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Wayfarer.Items
{
    public sealed class ItemDefinition
    {
        public readonly JObject Data;
        public ItemDefinition(JObject data){Data=data;}
        public string Id=>Text("id");
        public string Name=>Text("name");
        public string Kind=>Text("kind").ToLowerInvariant();
        public string Prefab=>Text("prefabName","TWA_WF_"+Id);
        public string AssetId=>Text("assetId",Id);
        public string Description=>Text("description",Text("effect","Goods carried by the Weathered Wayfarer."));
        public JObject Stats=>Data["stats"] as JObject??new JObject();
        public string Text(string key,string fallback="")=>Data.Value<string>(key)??fallback;
        public float Number(string key,float fallback=0)=>Data[key]?.Type==JTokenType.Null?fallback:Data.Value<float?>(key)??fallback;
        public float Stat(string key,float fallback=0)=>Stats.Value<float?>(key)??fallback;
        public int Int(string key,int fallback=0)=>(int)Number(key,fallback);
        public bool Flag(string key,bool fallback=false)=>Data.Value<bool?>(key)??fallback;
        public bool IsJewelry=>Kind=="ring"||Kind=="talisman";
    }

    public sealed class RuntimeCatalogue
    {
        public JObject Document{get;private set;}
        public IReadOnlyDictionary<string,ItemDefinition> Items=>items;
        readonly Dictionary<string,ItemDefinition> items=new Dictionary<string,ItemDefinition>(StringComparer.Ordinal);
        readonly Dictionary<string,ItemDefinition> byPrefab=new Dictionary<string,ItemDefinition>(StringComparer.Ordinal);
        public static RuntimeCatalogue Load(string path)
        {
            var c=new RuntimeCatalogue{Document=ReadJson(path,16*1024*1024)};
            var rows=c.Document["items"] as JArray??throw new InvalidDataException("Trade catalogue has no items.");
            if(rows.Count==0||rows.Count>2048)throw new InvalidDataException("Invalid trade item count.");
            foreach(var row in rows.OfType<JObject>())
            {
                var d=new ItemDefinition(row);
                // Retain rejected/unfinished design records without admitting them as stock/prefabs.
                if(row.Value<bool?>("enabled")==false||string.Equals(d.Text("effectiveDecision"),"rejected",StringComparison.OrdinalIgnoreCase)||d.Text("stage").IndexOf("PROPOSAL",StringComparison.OrdinalIgnoreCase)>=0)continue;
                if(!SafeId(d.Id)||!SafeId(d.Prefab)||string.IsNullOrWhiteSpace(d.Name))throw new InvalidDataException("Incomplete or unsafe item definition.");
                if(c.items.ContainsKey(d.Id)||c.byPrefab.ContainsKey(d.Prefab))throw new InvalidDataException("Duplicate logical item/prefab identity.");
                c.items.Add(d.Id,d);c.byPrefab.Add(d.Prefab,d);
            }
            return c;
        }
        public bool TryItem(string id,out ItemDefinition item)=>items.TryGetValue(id??"",out item)||byPrefab.TryGetValue(id??"",out item);
        public bool TryItem(ItemDrop.ItemData data,out ItemDefinition item)
        {item=null;return data!=null&&data.m_dropPrefab&&byPrefab.TryGetValue(data.m_dropPrefab.name,out item);}
        public static bool SafeId(string id)=>!string.IsNullOrEmpty(id)&&id.Length<=160&&id.All(c=>char.IsLetterOrDigit(c)||c=='_'||c=='-');
        public static JObject ReadJson(string path,int maximumBytes)
        {
            if(!File.Exists(path)||new FileInfo(path).Length>maximumBytes)throw new InvalidDataException("Missing/oversized Wayfarer resource: "+Path.GetFileName(path));
            using(var input=File.OpenText(path))using(var reader=new JsonTextReader(input){MaxDepth=64,DateParseHandling=DateParseHandling.None})
            {return JObject.Load(reader,new JsonLoadSettings{DuplicatePropertyNameHandling=DuplicatePropertyNameHandling.Error});}
        }
        public static string FileHash(string file){using(var h=SHA256.Create())using(var s=File.OpenRead(file))return string.Concat(h.ComputeHash(s).Select(x=>x.ToString("x2")));}
    }
}
