using System;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using UnityEngine;
using Wayfarer.InGame;

namespace Wayfarer.Items
{
    public sealed class CommerceDefinitions
    {
        public readonly RuntimeCatalogue Catalogue;
        public readonly Dictionary<string,CommerceOffer> Offers=new Dictionary<string,CommerceOffer>(StringComparer.Ordinal);
        public readonly Dictionary<string,CommerceCommission> Commissions=new Dictionary<string,CommerceCommission>(StringComparer.Ordinal);
        public readonly Dictionary<string,JObject> CommissionText=new Dictionary<string,JObject>(StringComparer.Ordinal);
        public JObject DialogueMap{get;private set;}=new JObject();
        public readonly HashSet<string> ApprovedAppraisals=new HashSet<string>(StringComparer.Ordinal);
        public void LoadDialogueMap(string path)
        {
            DialogueMap=RuntimeCatalogue.ReadJson(path,2*1024*1024);
            var appraisal=Catalogue.Document["rules"]?["explicitAppraisals"];
            var ids=appraisal as JArray??appraisal?["eligibleItemIds"] as JArray??appraisal?["allowedItemIds"] as JArray??appraisal?["itemIds"] as JArray;
            if(ids!=null)foreach(string id in ids.Values<string>())ApprovedAppraisals.Add(id);
        }
        public IEnumerable<JObject> Talks=>new[]{"talkActions","jobTalkActions"}.SelectMany(key=>(DialogueMap[key] as JArray??new JArray()).OfType<JObject>());
        static IEnumerable<string> Strings(JObject row,string key)=>row[key] is JArray a?a.Values<string>():Array.Empty<string>();
        public bool DialogueFlag(CommerceWorldState state,ISet<string> knowledge,string flag)
        {
            string done=DialogueMap["doneAliases"]?.Value<string>(flag),accepted=DialogueMap["acceptAliases"]?.Value<string>(flag);
            if(done!=null)return state.completed.Contains(done);
            if(accepted!=null)return state.accepted.ContainsKey(accepted)&&!state.completed.Contains(accepted);
            if((DialogueMap["protectedNativeFacts"] as JArray??new JArray()).Values<string>().Contains(flag))return state.flags.Contains(flag);
            if(flag=="abbey_topic"||flag=="ledger_read"||flag=="met_wayfarer"||flag=="other_worlds_admitted")return knowledge?.Contains(flag)==true;
            return state.flags.Contains(flag)||knowledge?.Contains(flag)==true;
        }
        public bool ConversationAllowed(JObject action,CommerceWorldState state,IDictionary<string,long> inventory,ISet<string> knowledge)
        {
            return ConversationGates.Allowed(action,state,inventory,f=>f=="abbey_item_carried"?AbbeyItemCarried(inventory):f=="ember_plan_carried"?inventory.TryGetValue("oswin_last_bell_plans",out long ember)&&ember>0:f=="holy_plan_carried"?inventory.TryGetValue("consecrated_bell_pattern",out long holy)&&holy>0:f=="abbot_defeated"?state.abbeyVictories>0:DialogueFlag(state,knowledge,f));
        }
        public bool AbbeyItemCarried(IDictionary<string,long> inventory)=>inventory.Any(p=>p.Value>0&&(p.Key.StartsWith("abbey_",StringComparison.Ordinal)||Catalogue.TryItem(p.Key,out var d)&&(d.Kind=="salvage"||d.Kind=="fragment"||d.Kind=="upgrade_material"||d.Kind=="commission_record"&&d.Id!="sealed_delivery_parcel")));
        public CommerceDefinitions(RuntimeCatalogue catalogue)
        {
            Catalogue=catalogue;
            foreach(var d in catalogue.Items.Values)
            {
                var copy=(JObject)d.Data.DeepClone();if(copy["priceSC"]?.Type==JTokenType.Null)copy["priceSC"]=0;
                var o=copy.ToObject<CommerceOffer>();
                o.enabled=d.Flag("enabled",true);o.purchasable=d.Flag("purchasable",true)&&d.Data["priceSC"]?.Type==JTokenType.Integer&&d.Kind!="commission_record";
                o.fragmentId=d.Text("fragmentId",d.Text("restorationFragmentId"));o.fragmentTotal=d.Int("fragmentTotal",d.Int("cumulativeFragments"));
                Offers.Add(o.id,o);
            }
            foreach(var row in (catalogue.Document["commissions"] as JArray??new JArray()).OfType<JObject>())
            {if(row.Value<bool?>("enabled")==false)continue;var c=row.ToObject<CommerceCommission>();if(!RuntimeCatalogue.SafeId(c.id)||Commissions.ContainsKey(c.id))throw new InvalidOperationException("Duplicate commission identity.");Commissions.Add(c.id,c);CommissionText.Add(c.id,row);}
        }
        public string ItemId(ItemDrop.ItemData item)
        {
            if(item==null||!item.m_dropPrefab)return "";
            if(item.m_dropPrefab.name==StrangeCoinItem.PrefabName)return CommercePolicy.StrangeCoinId;
            string abbey=NativeAbbeyReading.ItemId(item);if(!string.IsNullOrEmpty(abbey))return abbey;
            return Catalogue.TryItem(item,out var d)?d.Id:item.m_dropPrefab.name;
        }
        public GameObject Prefab(string id)
        {
            string name=id==CommercePolicy.StrangeCoinId?StrangeCoinItem.PrefabName:Catalogue.TryItem(id,out var d)?d.Prefab:id;
            return ZNetScene.instance?ZNetScene.instance.GetPrefab(name):Jotunn.Managers.PrefabManager.Instance.GetPrefab(name);
        }
        public string Name(string id)=>Catalogue.TryItem(id,out var d)?d.Name:id==CommercePolicy.StrangeCoinId?"Strange Coin":id;
        public void ApplyImmediateUnlocks(CommerceWorldState state)
        {
            if(DialogueMap["runtimeFactDefinitions"] is JObject facts)foreach(var fact in facts.Properties())
            {string job=fact.Value.Value<string>("completedCommission");if(job!=null&&state.completed.Contains(job))state.flags.Add(fact.Name);}
            if(state.unlocked.Any(id=>Catalogue.TryItem(id,out var d)&&(d.Kind=="weapon"||d.Kind=="censer")))state.flags.Add("first_weapon_restoration");
            if(state.unlocked.Any(id=>Catalogue.TryItem(id,out var d)&&d.Kind=="shield"))state.flags.Add("first_shield_restoration");
            foreach(var d in Catalogue.Items.Values)
                if(!d.Flag("nextAbbeyVictoryRequired")&&Offers.TryGetValue(d.Id,out var offer)&&CommercePolicy.RequirementsMet(state,offer))state.unlocked.Add(d.Id);
        }
        public void ResolveNativeCategories()
        {
            var groups=Catalogue.Document["nativeDeliveryCategories"]?["groups"] as JObject;
            foreach(var pair in Commissions)
            {
                var rows=CommissionText[pair.Key]["deliveryGroups"] as JArray;
                if(rows==null)continue;
                for(int i=0;i<rows.Count;i++)
                {
                    string key=rows[i].Value<string>("nativeWhitelist");var definition=groups?[key];
                    if(definition==null)throw new InvalidOperationException("Unrecognized delivery category: "+key);
                    pair.Value.deliveryGroups[i].allowedItemIds=((JArray)definition["allowedItemIds"]).Values<string>().Where(id=>{var p=Prefab(id);return p&&p.GetComponent<ItemDrop>();}).ToArray();
                    if(pair.Value.deliveryGroups[i].allowedItemIds.Length==0)throw new InvalidOperationException("No installed item sources for delivery category: "+key);
                }
            }
        }
        public Dictionary<string,long> Inventory(Inventory inventory)
        {
            var result=new Dictionary<string,long>(StringComparer.Ordinal);
            foreach(var item in inventory.GetAllItems()){string id=ItemId(item);result.TryGetValue(id,out long n);result[id]=checked(n+item.m_stack);}
            return result;
        }
    }
}
