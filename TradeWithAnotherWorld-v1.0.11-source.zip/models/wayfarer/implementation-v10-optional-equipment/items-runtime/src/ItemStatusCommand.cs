using System.Linq;
using Jotunn.Entities;
namespace Wayfarer.Items
{
    public sealed class ItemStatusCommand:ConsoleCommand
    {
        public override string Name=>"twa_wayfarer_items_status";
        public override string Help=>"Report Wayfarer items, trade and equipment readiness. Changes nothing.";
        public override void Run(string[] args)
        {
            var p=ItemsPlugin.Instance;if(!p)return;var state=p.Commerce.State;
            string text="Wayfarer items "+ItemsPlugin.Version+": "+(ItemRegistry.Current?.RegisteredIds.Count()??0)+" registered; jewellery "+JewelleryRuntime.NativeHooksReady.Count+" ready; oil motion "+WeaponOilUse.Ready+"; offhand motions "+OffhandRuntime.Ready+"; world boss stage "+(state?.highestBossLevel??0)+"; Abbey victories "+(state?.abbeyVictories??0)+". Natural camp spawning disabled. Gameplay review: Jesse.";
            p.Report(text);if(Console.instance)Console.instance.AddString(text);
        }
    }
}
