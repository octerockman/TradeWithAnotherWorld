using System.Collections.Generic;
using UnityEngine;
using Wayfarer.InGame;
namespace Wayfarer.Items
{
    public static class EquippedOffhandFx
    {
        static readonly Dictionary<Player,Transform> attached=new Dictionary<Player,Transform>();
        static readonly Dictionary<Player,string> identities=new Dictionary<Player,string>();
        public static void Tick()
        {
            foreach(var p in Player.GetAllPlayers())
            {
                if(!p)continue;
                bool supported=OffhandRuntime.Supported(p,out _,out var d)&&(d.Kind=="torch"||d.Kind=="censer");string id=supported?d.Id:null;
                if(identities.TryGetValue(p,out string old)&&old!=id){if(attached.TryGetValue(p,out var fx)&&fx)Object.Destroy(fx.gameObject);attached.Remove(p);identities.Remove(p);}
                if(!supported)continue;if(attached.TryGetValue(p,out var existing)&&existing)continue;
                // Retry during the genuine held-mesh build; never attach a flame
                // to a guessed grip or an uninitialized zero socket.
                var socket=OffhandPoseMount.GetSocket(p,d.Kind=="torch"?"Flame":"Smoke");if(!socket)continue;
                var host=new GameObject("Wayfarer equipped ambient effect").transform;host.SetParent(socket,false);attached[p]=host;identities[p]=id;
                if(d.Kind=="torch")NativeCampLighting.AttachCandle(host,.7f);
                else{OffhandParticles.AmbientCenser(host);var ember=OffhandPoseMount.GetSocket(p,"Ember");if(ember){var light=new GameObject("Censer coals");light.transform.SetParent(host,false);light.transform.position=ember.position;var point=light.AddComponent<Light>();point.color=new Color(1,.2f,.02f);point.intensity=.35f;point.range=.65f;point.shadows=LightShadows.None;}}
            }
        }
    }
}
