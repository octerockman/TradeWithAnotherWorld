using System;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Security.Cryptography;
using System.Collections.Generic;
using HarmonyLib;
using Newtonsoft.Json;
using UnityEngine;

namespace Wayfarer.Items
{
    public sealed class CombatHitMetadata
    {public string id,key,coating;public long action,attackerUser,victimUser;public uint attackerId,victimId;public bool directMelee;}
    public sealed class CombatHitReceipt
    {public string id,target;public float physicalDamage;public bool fatal,blocked,newStagger;}
    public sealed class OwnerHitScope
    {public string key,target;public Character victim;public HitData sourceHit,originalHit;public float healthBefore,physicalLost;public bool staggerBefore,blocked,fatal,newStagger;public double time;}
    public static class CombatReceipts
    {
        const string MetadataRpc="TWA_WF_HitMetadata_v1",ReceiptRpc="TWA_WF_HitReceipt_v1";
        static ZRoutedRpc rpc;
        static long currentAction;
        static Attack actionAttack;
        static Player actionPlayer;
        static bool actionEnded;
        [ThreadStatic]static Stack<long> sourceActions;
        public static long CurrentActionId=>sourceActions!=null&&sourceActions.Count>0?sourceActions.Peek():currentAction;
        public static IDisposable UseAction(long action)
        {if(sourceActions==null)sourceActions=new Stack<long>();sourceActions.Push(action);return new ActionScope();}
        sealed class ActionScope:IDisposable
        {bool disposed;public void Dispose(){if(disposed)return;disposed=true;if(sourceActions!=null&&sourceActions.Count>0)sourceActions.Pop();}}
        static readonly Dictionary<string,Tuple<CombatHitMetadata,long,double>> pending=new Dictionary<string,Tuple<CombatHitMetadata,long,double>>(StringComparer.Ordinal);
        static readonly Dictionary<string,Queue<Tuple<CombatHitMetadata,long,double>>> incoming=new Dictionary<string,Queue<Tuple<CombatHitMetadata,long,double>>>(StringComparer.Ordinal);
        static readonly Dictionary<string,Queue<OwnerHitScope>> completed=new Dictionary<string,Queue<OwnerHitScope>>(StringComparer.Ordinal);
        [ThreadStatic]static Stack<OwnerHitScope> scopes;
        public static OwnerHitScope CurrentOwnerHit=>scopes!=null&&scopes.Count>0?scopes.Peek():null;
        public static HitData CurrentOriginalHit=>CurrentOwnerHit?.originalHit;
        public static Character CurrentVictim=>CurrentOwnerHit?.victim;
        static double Now=>Time.realtimeSinceStartupAsDouble;
        public static void Tick()
        {
            if(ZRoutedRpc.instance==null||!ZNet.instance){currentAction=0;actionAttack=null;actionPlayer=null;pending.Clear();incoming.Clear();completed.Clear();return;}
            if(rpc!=ZRoutedRpc.instance){rpc=ZRoutedRpc.instance;rpc.Register<string>(MetadataRpc,ReceiveMetadata);rpc.Register<string>(ReceiptRpc,ReceiveReceipt);JewelleryRuntime.EnableConfirmedCombatAdapters();ItemsPlugin.Instance?.Report("CONFIRMED_COMBAT_ADAPTERS_BOUND nativeOwnerReceipts=true gameValidation=awaiting_Jesse");}
            foreach(var id in pending.Where(p=>Now-p.Value.Item3>5).Select(p=>p.Key).ToArray())pending.Remove(id);
            foreach(var key in incoming.Where(p=>p.Value.Count==0||Now-p.Value.Peek().Item3>5).Select(p=>p.Key).ToArray())incoming.Remove(key);
            foreach(var key in completed.Where(p=>p.Value.Count==0||Now-p.Value.Peek().time>5).Select(p=>p.Key).ToArray())completed.Remove(key);
            if(actionPlayer&&currentAction!=0&&!actionEnded&&JewelleryRuntime.CurrentAttack(actionPlayer)!=actionAttack&&!pending.Values.Any(p=>p.Item1.action==currentAction))
            {JewelleryRuntime.EndAction(actionPlayer,currentAction);actionEnded=true;}
        }
        public static void Started(Player player,bool success,bool secondary,float eitrBefore)
        {
            if(!success||player!=Player.m_localPlayer)return;
            if(currentAction!=0&&actionPlayer&&!pending.Values.Any(p=>p.Item1.action==currentAction))JewelleryRuntime.EndAction(actionPlayer,currentAction);
            actionPlayer=player;actionAttack=JewelleryRuntime.CurrentAttack(player);actionEnded=false;currentAction=JewelleryRuntime.BeginAction(player,actionAttack,secondary,eitrBefore);
            if(actionAttack!=null&&actionAttack.GetWeapon()?.m_shared.m_skillType==Skills.SkillType.ElementalMagic)RuntimeFacts.Record("used_elemental_magic");
        }
        static string Key(Character victim,HitData hit)
        {
            // HitData has no extension field. Metadata travels beside the native
            // hit; reserved native fields are never overwritten with our IDs.
            var text=new StringBuilder();text.Append(victim.GetZDOID()).Append('|').Append(hit.m_attacker).Append('|').Append((int)hit.m_skill).Append('|').Append(hit.m_ranged).Append('|');
            foreach(float f in new[]{hit.m_point.x,hit.m_point.y,hit.m_point.z,hit.m_damage.m_blunt,hit.m_damage.m_slash,hit.m_damage.m_pierce,hit.m_damage.m_fire,hit.m_damage.m_frost,hit.m_damage.m_lightning,hit.m_damage.m_poison,hit.m_damage.m_spirit,hit.m_damage.m_damage})text.Append(Math.Round(f,2).ToString("R",CultureInfo.InvariantCulture)).Append('|');
            using(var sha=SHA256.Create())
            {byte[] bytes=Encoding.UTF8.GetBytes(text.ToString());return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-","");}
        }
        internal static void Outgoing(Character victim,HitData hit)
        {
            var attacker=hit?.GetAttacker() as Player;
            long action=CurrentActionId;
            if(!attacker||attacker!=Player.m_localPlayer||!JewelleryRuntime.Hostile(victim,attacker)||action==0||rpc==null)return;
            JewelleryRuntime.ModifyOutgoingHit(attacker,action,victim,hit);
            bool mainHandCoating=action==currentAction&&actionPlayer==attacker&&actionAttack!=null&&!hit.m_ranged&&JewelleryRuntime.IsPhysicalMelee(actionAttack);
            if(mainHandCoating)WeaponOilUse.ModifyHit(attacker,hit);
            var view=victim.GetComponent<ZNetView>();if(!view||!view.IsValid())return;
            var attackerId=attacker.GetZDOID();var victimId=victim.GetZDOID();long owner=view.GetZDO().GetOwner();
            var metadata=new CombatHitMetadata{id=Guid.NewGuid().ToString("N"),key=Key(victim,hit),coating=mainHandCoating?WeaponOilUse.ActiveOil(attacker):null,directMelee=!hit.m_ranged,action=action,attackerUser=attackerId.UserID,attackerId=attackerId.ID,victimUser=victimId.UserID,victimId=victimId.ID};
            pending[metadata.id]=Tuple.Create(metadata,owner,Now);string raw=JsonConvert.SerializeObject(metadata);
            if(owner==ZNet.GetUID())ReceiveMetadata(owner,raw);else rpc.InvokeRoutedRPC(owner,MetadataRpc,new object[]{raw});
        }
        static void ReceiveMetadata(long sender,string raw)
        {
            if(raw==null||raw.Length>2048||ZDOMan.instance==null||!ZNetScene.instance)return;
            var meta=JsonConvert.DeserializeObject<CombatHitMetadata>(raw);if(meta?.id?.Length!=32||meta.key?.Length!=64)return;
            var attacker=ZDOMan.instance.GetZDO(new ZDOID(meta.attackerUser,meta.attackerId));var victim=ZDOMan.instance.GetZDO(new ZDOID(meta.victimUser,meta.victimId));
            if(attacker==null||victim==null||attacker.GetOwner()!=sender||victim.GetOwner()!=ZNet.GetUID())return;
            if(completed.TryGetValue(meta.key,out var ready)&&ready.Count>0){Reply(meta,sender,ready.Dequeue());return;}
            if(!incoming.TryGetValue(meta.key,out var queue))incoming[meta.key]=queue=new Queue<Tuple<CombatHitMetadata,long,double>>();if(queue.Count<32)queue.Enqueue(Tuple.Create(meta,sender,Now));
        }
        internal static OwnerHitScope BeginOwner(Character victim,HitData hit)
        {
            var view=victim.GetComponent<ZNetView>();if(!view||!view.IsValid()||!view.IsOwner()||!hit.HaveAttacker())return null;
            var scope=new OwnerHitScope{key=Key(victim,hit),target=victim.GetZDOID().ToString(),victim=victim,sourceHit=hit,originalHit=hit.Clone(),healthBefore=victim.GetHealth(),staggerBefore=victim.IsStaggering(),time=Now};
            if(scopes==null)scopes=new Stack<OwnerHitScope>();scopes.Push(scope);
            if(victim==Player.m_localPlayer&&hit.GetAttacker())JewelleryRuntime.NotifyEnemyAttackAttempt(Player.m_localPlayer,hit.m_attacker.ToString());return scope;
        }
        internal static void FinalDamage(Character victim,HitData hit,float before)
        {
            if(scopes==null||scopes.Count==0||scopes.Peek().victim!=victim)return;
            float lost=Math.Max(0,before-victim.GetHealth()),total=hit.GetTotalDamage();
            if(lost>0&&total>0)scopes.Peek().physicalLost+=lost*Mathf.Clamp01(hit.GetTotalPhysicalDamage()/total);
            scopes.Peek().fatal=victim.GetHealth()<=0;scopes.Peek().newStagger=!scopes.Peek().staggerBefore&&victim.IsStaggering();
        }
        internal static void EndOwner(OwnerHitScope scope,bool failed=false)
        {
            if(scope==null)return;if(scopes!=null&&scopes.Count>0&&ReferenceEquals(scopes.Peek(),scope))scopes.Pop();
            if(failed)return;
            // Seal the result at completion. The companion message may arrive
            // later, after another hit, regeneration or network destruction.
            if(scope.victim){scope.fatal=scope.victim.GetHealth()<=0;scope.newStagger=!scope.staggerBefore&&scope.victim.IsStaggering();}
            if(incoming.TryGetValue(scope.key,out var metadata)&&metadata.Count>0){var meta=metadata.Dequeue();Reply(meta.Item1,meta.Item2,scope);return;}
            if(!completed.TryGetValue(scope.key,out var queue))completed[scope.key]=queue=new Queue<OwnerHitScope>();if(queue.Count<32)queue.Enqueue(scope);
        }
        static void Reply(CombatHitMetadata meta,long peer,OwnerHitScope scope)
        {
            WeaponOilHitEffects.Confirmed(scope.victim,meta,scope);
            var receipt=new CombatHitReceipt{id=meta.id,target=scope.target,physicalDamage=scope.physicalLost,fatal=scope.fatal,blocked=scope.blocked,newStagger=scope.newStagger};
            string raw=JsonConvert.SerializeObject(receipt);if(peer==ZNet.GetUID())ReceiveReceipt(peer,raw);else rpc.InvokeRoutedRPC(peer,ReceiptRpc,new object[]{raw});
        }
        static void ReceiveReceipt(long sender,string raw)
        {
            if(raw==null||raw.Length>2048)return;var receipt=JsonConvert.DeserializeObject<CombatHitReceipt>(raw);
            if(receipt==null||!pending.TryGetValue(receipt.id??"",out var issued)||issued.Item2!=sender||!Player.m_localPlayer||receipt.physicalDamage<0||float.IsNaN(receipt.physicalDamage)||float.IsInfinity(receipt.physicalDamage))return;
            var id=new ZDOID(issued.Item1.victimUser,issued.Item1.victimId);if(receipt.target!=id.ToString())return;pending.Remove(receipt.id);
            OffhandRuntime.ConfirmHit(issued.Item1.action,receipt.physicalDamage);
            if(issued.Item1.directMelee){JewelleryRuntime.ConfirmPhysicalHit(Player.m_localPlayer,issued.Item1.action,receipt.target,receipt.physicalDamage,receipt.fatal,receipt.blocked,receipt.newStagger);if(receipt.physicalDamage>0)NativeProgress.CoatedHit(issued.Item1.coating);}
        }
        internal static void Blocked(Humanoid victim,HitData hit,Character attacker,bool success,bool parried)
        {
            if(scopes!=null&&scopes.Count>0&&scopes.Peek().victim==victim)scopes.Peek().blocked|=success;
            if(victim!=Player.m_localPlayer||!attacker||!success||!JewelleryRuntime.Hostile(attacker,(Player)victim))return;
            bool magic=hit.m_ranged&&(hit.m_skill==Skills.SkillType.ElementalMagic||hit.m_skill==Skills.SkillType.BloodMagic);
            JewelleryRuntime.ConfirmBlock((Player)victim,attacker.GetZDOID().ToString(),true,parried,magic,hit.m_ranged);
        }
    }
    public sealed class ProjectileActionSource:MonoBehaviour
    {public long ActionId;public Player Owner;}
    [HarmonyPatch(typeof(Projectile),nameof(Projectile.Setup))]
    static class JewelleryProjectileSource
    {
        static void Postfix(Projectile __instance,Character __0)
        {if(__0!=Player.m_localPlayer||!Player.m_localPlayer)return;var marker=__instance.GetComponent<ProjectileActionSource>()??__instance.gameObject.AddComponent<ProjectileActionSource>();marker.Owner=Player.m_localPlayer;marker.ActionId=CombatReceipts.CurrentActionId;}
    }
    [HarmonyPatch(typeof(Projectile),"OnHit")]
    static class JewelleryProjectileHitScope
    {
        static void Prefix(Projectile __instance,out IDisposable __state)
        {var marker=__instance.GetComponent<ProjectileActionSource>();__state=marker&&marker.Owner==Player.m_localPlayer?CombatReceipts.UseAction(marker.ActionId):null;}
        static Exception Finalizer(Exception __exception,IDisposable __state){__state?.Dispose();return __exception;}
    }
    [HarmonyPatch(typeof(Aoe),nameof(Aoe.Setup))]
    static class JewelleryAreaSource
    {
        static void Postfix(Aoe __instance,Character __0)
        {if(__0!=Player.m_localPlayer||!Player.m_localPlayer)return;var marker=__instance.GetComponent<ProjectileActionSource>()??__instance.gameObject.AddComponent<ProjectileActionSource>();marker.Owner=Player.m_localPlayer;marker.ActionId=CombatReceipts.CurrentActionId;}
    }
    [HarmonyPatch(typeof(Aoe),"OnHit")]
    static class JewelleryAreaHitScope
    {
        static void Prefix(Aoe __instance,out IDisposable __state)
        {var marker=__instance.GetComponent<ProjectileActionSource>();__state=marker&&marker.Owner==Player.m_localPlayer?CombatReceipts.UseAction(marker.ActionId):null;}
        static Exception Finalizer(Exception __exception,IDisposable __state){__state?.Dispose();return __exception;}
    }
    [HarmonyPatch(typeof(Humanoid),nameof(Humanoid.StartAttack))]
    static class JewelleryActionReceiptStart
    {
        static void Prefix(Humanoid __instance,out float __state)=>__state=__instance==Player.m_localPlayer?((Player)__instance).GetEitr():-1;
        static void Postfix(Humanoid __instance,Character __0,bool __1,bool __result,float __state)
        {if(__instance is Player p)CombatReceipts.Started(p,__result,__1,__state);else if(__result&&__0==Player.m_localPlayer&&Player.m_localPlayer)JewelleryRuntime.NotifyEnemyAttackAttempt(Player.m_localPlayer,__instance.GetZDOID().ToString());}
    }
    [HarmonyPatch(typeof(Character),nameof(Character.Damage))]
    static class JewelleryOutgoingReceipt
    {static void Prefix(Character __instance,HitData __0){if(ItemsPlugin.Instance)CombatReceipts.Outgoing(__instance,__0);}}
    [HarmonyPatch(typeof(Character),"RPC_Damage")]
    static class JewelleryOwnerReceipt
    {
        static void Prefix(Character __instance,HitData __1,out OwnerHitScope __state)=>__state=CombatReceipts.BeginOwner(__instance,__1);
        static Exception Finalizer(Exception __exception,OwnerHitScope __state){CombatReceipts.EndOwner(__state,__exception!=null);return __exception;}
    }
    [HarmonyPatch(typeof(Character),nameof(Character.ApplyDamage))]
    static class JewelleryFinalReceipt
    {
        static void Prefix(Character __instance,out float __state)=>__state=__instance.GetHealth();
        static void Postfix(Character __instance,HitData __0,float __state)=>CombatReceipts.FinalDamage(__instance,__0,__state);
    }
    [HarmonyPatch(typeof(Humanoid),"BlockAttack")]
    static class JewelleryBlockReceipt
    {
        static void Prefix(Humanoid __instance,out bool __state)
        {
            float timer=(float)AccessTools.Field(typeof(Humanoid),"m_blockTimer").GetValue(__instance);
            var blocker=AccessTools.Method(typeof(Humanoid),"GetCurrentBlocker").Invoke(__instance,null) as ItemDrop.ItemData;
            __state=timer>=0&&timer<.25f&&blocker!=null&&blocker.m_shared.m_timedBlockBonus>1&&!JewelleryBackstay.ActiveRearBlock;
        }
        static void Postfix(Humanoid __instance,HitData __0,Character __1,bool __result,bool __state)=>CombatReceipts.Blocked(__instance,__0,__1,__result,__state);
    }
}
