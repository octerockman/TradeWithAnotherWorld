using System;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    [HarmonyPatch(typeof(Projectile),"Setup")]
    static class JewelleryBallisticSpellSpeedPatch
    {
        static void Postfix(Projectile __instance,Character __0,ItemDrop.ItemData __4)
        {
            var p=__0 as Player;if(!p||!__4?.m_dropPrefab||!JewelleryRuntime.For(p).Has("ms_cinderline_band"))return;
            string focus=__4.m_dropPrefab.name;
            bool linked=focus=="StaffIceShards"&&__instance.name.StartsWith("staff_iceshard_projectile",StringComparison.Ordinal)||focus=="StaffFireball"&&__instance.name.StartsWith("staff_fireball_projectile",StringComparison.Ordinal);
            if(!linked||__instance.m_drag!=0||__instance.m_bounce||__instance.m_bounceOnWater||__instance.m_projectileReturn||__instance.m_spawnOnTtl||__instance.m_ttl<=0)return;
            var view=__instance.GetComponent<ZNetView>();if(!view||!view.IsOwner())return;
            const float k=1.15f;
            var velocity=AccessTools.Field(typeof(Projectile),"m_vel");velocity.SetValue(__instance,(Vector3)velocity.GetValue(__instance)*k);
            __instance.m_gravity*=k*k;__instance.m_ttl/=k;
            // p'(t)=k*v*t + .5*k*k*a*t*t == p(k*t): same continuous
            // ballistic path and terminal point, reached sooner. No homing,
            // damage/count or reach increase. Sampled physics awaits Jesse.
        }
    }
}
