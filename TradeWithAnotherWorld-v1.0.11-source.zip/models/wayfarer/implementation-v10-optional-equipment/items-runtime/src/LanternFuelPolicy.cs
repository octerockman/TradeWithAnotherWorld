using System;
using System.Linq;
using System.Collections.Generic;

namespace Wayfarer.Items
{
    [Serializable] public sealed class LanternCharge
    {public int kind;public double remaining;public LanternCharge(){}public LanternCharge(int type,double seconds){kind=type;remaining=seconds;}}
    [Serializable] public sealed class LanternFuelReceipt
    {public string request;public int kind;public bool accepted;}
    [Serializable] public sealed class LanternFuelState
    {
        public int schema=1;
        public bool enabled=true;
        public double worldAt;
        public List<LanternCharge> charges=new List<LanternCharge>();
        public List<LanternFuelReceipt> receipts=new List<LanternFuelReceipt>();
        public bool Burning=>enabled&&charges.Count>0;
        public double RemainingSeconds=>charges.Sum(x=>x.remaining);
    }
    // One charge remains one inventory fuel item, even after partial use.
    // Each entry retains its own duration; mixed fuels never convert to a
    // misleading common "fuel count" whose time changes after a reload.
    public static class LanternFuelPolicy
    {
        public const int Capacity=30,OrdinaryResin=1,RefinedResin=2,ReceiptLimit=32;
        public static double Duration(int kind)=>kind==OrdinaryResin?1800:kind==RefinedResin?3600:0;
        public static bool Finite(double value)=>!double.IsNaN(value)&&!double.IsInfinity(value);
        public static bool Valid(LanternFuelState state)
        {
            return state!=null&&state.schema==1&&Finite(state.worldAt)&&state.worldAt>=0&&state.charges!=null&&state.charges.Count<=Capacity
                &&state.charges.All(c=>c!=null&&Duration(c.kind)>0&&Finite(c.remaining)&&c.remaining>0&&c.remaining<=Duration(c.kind)+.0001)
                &&state.receipts!=null&&state.receipts.Count<=ReceiptLimit&&state.receipts.All(r=>r!=null&&ValidRequest(r.request)&&r.kind>=0&&r.kind<=2)
                &&state.receipts.Select(r=>r.request).Distinct(StringComparer.Ordinal).Count()==state.receipts.Count;
        }
        public static bool ValidRequest(string request)=>request!=null&&request.Length==32&&request.All(c=>c>='0'&&c<='9'||c>='a'&&c<='f');
        public static void Advance(LanternFuelState state,double worldNow)
        {
            if(!Valid(state)||!Finite(worldNow)||worldNow<0)throw new ArgumentException("Invalid lantern fuel/time snapshot.");
            double elapsed=state.enabled?Math.Max(0,worldNow-state.worldAt):0;
            state.worldAt=worldNow;
            while(elapsed>0&&state.charges.Count>0)
            {
                var charge=state.charges[0];
                if(elapsed>=charge.remaining){elapsed-=charge.remaining;state.charges.RemoveAt(0);}
                else{charge.remaining-=elapsed;elapsed=0;}
            }
        }
        public static bool Add(LanternFuelState state,int kind,double worldNow)
        {
            Advance(state,worldNow);
            if(Duration(kind)<=0||state.charges.Count>=Capacity)return false;
            state.charges.Add(new LanternCharge(kind,Duration(kind)));return true;
        }
        public static void Toggle(LanternFuelState state,double worldNow)
        {Advance(state,worldNow);state.enabled=!state.enabled;}
        public static bool TryReceipt(LanternFuelState state,string request,int kind,out bool accepted)
        {
            var found=state.receipts.FirstOrDefault(r=>r.request==request);accepted=found!=null&&found.kind==kind&&found.accepted;return found!=null;
        }
        public static void Remember(LanternFuelState state,string request,int kind,bool accepted)
        {
            if(!ValidRequest(request)||kind<0||kind>2)throw new ArgumentException("Invalid lantern request identity.");
            if(TryReceipt(state,request,kind,out _))return;
            state.receipts.Add(new LanternFuelReceipt{request=request,kind=kind,accepted=accepted});
            while(state.receipts.Count>ReceiptLimit)state.receipts.RemoveAt(0);
        }
    }
}
