using System;
using System.Linq;
using System.Collections.Generic;

namespace Wayfarer.Items
{
    // Engine-independent effect rules. Event adapters must prove eligibility;
    // this layer never guesses a spell, enemy windup or attack from its name.
    public static class JewelleryMath
    {
        public static float Cap(float value,float limit)=>Math.Max(0,Math.Min(limit,value));
        public static float Cost(float normal,float reductions)=>normal<=0?normal:normal*(1-Cap(reductions,.30f));
        public static float Damage(float normal,float bonuses)=>normal*(1+Cap(bonuses,.40f));
        public static float AttackRate(float bonuses)=>1+Cap(bonuses,.20f);
        public static float GroundSpeed(float bonuses)=>1+Cap(bonuses,.15f);
        public static float Regen(float incomingBaseline,float otherResult,float bonus)=>otherResult+incomingBaseline*Cap(bonus,.30f);
        public static float HealthMitigation(params float[] reductions)=>Math.Max(.70f,reductions.Aggregate(1f,(a,b)=>a*(1-Cap(b,1))));
        public static float Durability(bool menders,bool keptVellum,bool casting)=>(menders?.8f:1)*(keptVellum&&casting?.75f:1);
        public static float JumpVelocity(float normal,float heightBonus)=>normal*(float)Math.Sqrt(1+Math.Max(0,heightBonus));
        public static float MixedDotHealthScale(float hostileFraction,float reduction,float enemyDrawback)
        {float h=Cap(hostileFraction,1);return (1-h)+h*(1-Cap(reduction,.3f))*(1+Math.Max(0,enemyDrawback));}
        public static float MixedDotHostileFireShare(float hostileFireFraction,float hostileFraction,float reduction,float enemyDrawback)
        {float scale=MixedDotHealthScale(hostileFraction,reduction,enemyDrawback);return scale>0?Cap(hostileFireFraction*(1-Cap(reduction,.3f))*(1+Math.Max(0,enemyDrawback))/scale,1):0;}
        public static bool BorrowedSpark(float eitrCost,float staminaCost,float healthCost,float eitr,float maximumEitr,float stamina,bool ready,out float extraStamina)
        {
            extraStamina=0;if(!ready||eitrCost<=0||healthCost>0||maximumEitr<=0||eitr<0||staminaCost<0)return false;
            float missing=eitrCost-eitr;if(missing<=0||missing>5)return false;extraStamina=missing*2;
            return extraStamina<=10&&stamina>=staminaCost+extraStamina;
        }
        public static bool DodgeRecovery(float normalizedTime,bool invulnerable,float equippedWeight)=>normalizedTime>.7f/1.5f&&normalizedTime<1&&!invulnerable&&equippedWeight<=25;
    }
    public sealed class JewelleryCombatState
    {
        public readonly Dictionary<string,double> cooldownDeadlines=new Dictionary<string,double>(StringComparer.Ordinal);
        public float woundOriginal,woundSpent,storedFire;
        public double woundStarted,fireExpires,pursuitExpires,lastMeleeHit,firstScarQualifiedSince=-1;
        public int momentum,thirdBeatCount,waterStepsRemaining=4;
        public string followupEnemy;
        public double followupUntil;
        public bool Ready(string id,double utc)=>!cooldownDeadlines.TryGetValue(id,out double deadline)||utc>=deadline;
        public void Cooldown(string id,double utc,double seconds){cooldownDeadlines[id]=utc+seconds;}
        public void NewWound(float actualHealthLost,double now){woundOriginal=Math.Max(0,actualHealthLost)*.5f;woundSpent=0;woundStarted=now;}
        public float Wound(double now)
        {
            double elapsed=Math.Max(0,now-woundStarted);float fade=elapsed<=2?1:elapsed>=5?0:(float)((5-elapsed)/3);
            return Math.Max(0,woundOriginal*fade-woundSpent);
        }
        public float Reclaim(float actualPhysicalDamage,float missingHealth,double now)
        {float amount=Math.Min(Math.Max(0,missingHealth),Math.Min(Wound(now),Math.Max(0,actualPhysicalDamage)*.1f));woundSpent+=amount;return amount;}
        public void OrdinaryHeal(float healthGained,double now){woundSpent+=Math.Min(Wound(now),Math.Max(0,healthGained));}
        public void ClearWound(){woundOriginal=0;woundSpent=0;}
        public void ReceiveFire(float actualFireHealthLost,double now){storedFire=Math.Min(30,storedFire+Math.Max(0,actualFireHealthLost)*.5f);fireExpires=now+20;}
        public float SpendFire(double now){float result=now<=fireExpires?storedFire:0;storedFire=0;return result;}
        public float MeleeMomentum(bool landed,double now)
        {
            if(!landed||now-lastMeleeHit>3)momentum=0;
            if(!landed)return 0;lastMeleeHit=now;float bonus=Math.Min(3,momentum)*.03f;momentum=Math.Min(3,momentum+1);return bonus;
        }
        public float ThirdBeat(bool landed,double now)
        {
            if(!landed||now-lastMeleeHit>6)thirdBeatCount=0;
            if(!landed)return 0;lastMeleeHit=now;thirdBeatCount++;
            if(thirdBeatCount<3)return 0;thirdBeatCount=0;
            if(!Ready("ds3_third_beat",now))return 0;Cooldown("ds3_third_beat",now,10);return .12f;
        }
        public bool QualifyFirstScar(float healthFraction,float maxHealth,bool maxChanged,double now)
        {
            if(healthFraction<.95f||maxChanged){firstScarQualifiedSince=-1;return false;}
            if(firstScarQualifiedSince<0)firstScarQualifiedSince=now;return now-firstScarQualifiedSince>=2;
        }
        public void ResetTransient()
        {
            ClearWound();storedFire=0;fireExpires=0;pursuitExpires=0;momentum=0;thirdBeatCount=0;lastMeleeHit=0;followupEnemy=null;followupUntil=0;firstScarQualifiedSince=-1;
            // Death/reload do not reset cooldown deadlines or water steps.
        }
    }
}
