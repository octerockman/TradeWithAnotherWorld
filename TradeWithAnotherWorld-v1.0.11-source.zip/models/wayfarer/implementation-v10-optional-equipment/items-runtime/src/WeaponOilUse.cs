using System;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using Newtonsoft.Json;
using UnityEngine;

namespace Wayfarer.Items
{
    public sealed class WeaponCoating
    {public string schema="wayfarer.weapon-coating.v1",oilId,weaponInstance;public float remaining;}
    public static class WeaponOilUse
    {
        const string SaveKey="TWA_WF_WeaponCoating_v1";
        static readonly FieldInfo hiddenRight=AccessTools.Field(typeof(Humanoid),"m_hiddenRightItem");
        static Player current;
        static ItemDrop.ItemData coatedWeapon;
        static WeaponCoating coating;
        static float resolveUntil,nextSave;
        static bool applying;
        static Func<Player,Func<bool>,Func<bool>,Action<bool>,bool> beginMotion;
        [ThreadStatic]internal static int StowDepth;
        public static bool Ready=>beginMotion!=null;
        public static bool IsBusy(Player player)=>applying&&player==current;
        public static void RegisterMotion(Func<Player,Func<bool>,Func<bool>,Action<bool>,bool> begin)=>beginMotion=begin;
        public static ItemDrop.ItemData RightOrStowed(Player player)=>JewelleryRuntime.HeldRight(player)??hiddenRight?.GetValue(player) as ItemDrop.ItemData;
        public static bool Eligible(ItemDrop.ItemData item)
        {
            if(item==null||!item.m_dropPrefab)return false;
            int type=(int)item.m_shared.m_itemType;if(!new[]{3,14,20,22}.Contains(type))return false;
            if(!new[]{"Swords","Knives","Clubs","Axes","Spears","Polearms"}.Contains(item.m_shared.m_skillType.ToString()))return false;
            if(ItemsPlugin.Instance.Catalogue.TryItem(item,out var d)&&new[]{"torch","handbell","censer"}.Contains(d.Kind))return false;
            var damage=item.GetDamage();return damage.m_fire<=0&&damage.m_frost<=0&&damage.m_lightning<=0&&damage.m_poison<=0&&damage.m_spirit<=0;
        }
        public static void Tick(Player player,float dt)
        {
            if(!player||player!=Player.m_localPlayer)return;
            if(current!=player)
            {
                Save(current);current=player;coatedWeapon=null;coating=null;applying=false;resolveUntil=Time.unscaledTime+2;
                if(player.m_customData.TryGetValue(SaveKey,out var raw))try{var value=JsonConvert.DeserializeObject<WeaponCoating>(raw);if(value?.schema=="wayfarer.weapon-coating.v1"&&value.remaining>0&&value.remaining<=100&&RuntimeCatalogue.SafeId(value.oilId)&&value.weaponInstance?.Length==32)coating=value;}catch(JsonException){player.m_customData.Remove(SaveKey);}
            }
            if(player.IsDead()){Clear();return;}
            if(coating==null)return;
            if(coatedWeapon==null)
            {
                coatedWeapon=player.GetInventory().GetAllItems().FirstOrDefault(i=>i.m_customData.TryGetValue(CommerceInventory.InstanceKey,out var id)&&id==coating.weaponInstance);
                if(coatedWeapon==null){if(Time.unscaledTime>=resolveUntil)Clear();return;}
            }
            if(!Eligible(coatedWeapon)||!player.GetInventory().ContainsItem(coatedWeapon)){Clear();return;}
            if(!ReferenceEquals(RightOrStowed(player),coatedWeapon))
            {if(Time.unscaledTime>=resolveUntil)Clear();return;}
            coating.remaining=Math.Max(0,coating.remaining-Mathf.Clamp(dt,0,1));if(coating.remaining<=0){Clear();return;}
            if(Time.unscaledTime>=nextSave){Save(player);WeaponOilVisuals.Publish(player,coatedWeapon,coating.oilId,coating.remaining);nextSave=Time.unscaledTime+1;}
        }
        public static bool Use(Player player,ItemDrop.ItemData oil,ItemDefinition definition)
        {
            if(!Ready){player.Message(MessageHud.MessageType.Center,"The oil-application animation is unavailable.");return false;}
            if(IsBusy(player)||OffhandPose.IsBusy(player)||player.InAttack()||player.IsDodgeInvincible()||player.IsDead())return false;
            var weapon=JewelleryRuntime.HeldRight(player);if(!Eligible(weapon)){player.Message(MessageHud.MessageType.Center,"Use oil on a physical melee weapon without built-in elemental damage.");return false;}
            if(current!=player)Tick(player,0);int damaged=SupplyUse.LocalDamageRevision;string instance=CommerceInventory.Instance(weapon);bool committed=false;
            bool StillValid()=>player&&player==Player.m_localPlayer&&!player.IsDead()&&SupplyUse.LocalDamageRevision==damaged&&ReferenceEquals(JewelleryRuntime.HeldRight(player),weapon)&&Eligible(weapon)&&player.GetInventory().ContainsItem(weapon)&&(committed||player.GetInventory().ContainsItem(oil));
            bool Consume()
            {
                if(!StillValid()||!player.GetInventory().RemoveItem(oil,1))return false;
                // Replacing or reusing consumes this oil and starts its own
                // duration. It never refunds or adds to the previous coating.
                coating=new WeaponCoating{oilId=definition.Id,weaponInstance=instance,remaining=definition.Stat("duration")};coatedWeapon=weapon;committed=true;resolveUntil=Time.unscaledTime;Save(player);WeaponOilVisuals.Publish(player,coatedWeapon,coating.oilId,coating.remaining);WeaponOilVisuals.Applied(definition,player.GetCenterPoint());return true;
            }
            applying=true;bool accepted=beginMotion(player,StillValid,Consume,finished=>{applying=false;Save(player);});if(!accepted)applying=false;return accepted;
        }
        public static string ActiveOil(Player player)
        {if(player!=current||coating==null||coating.remaining<=0||!ReferenceEquals(JewelleryRuntime.HeldRight(player),coatedWeapon))return null;return coating.oilId;}
        public static void ModifyHit(Player player,HitData hit)
        {
            string id=ActiveOil(player);if(id==null||hit.m_ranged||JewelleryCombat.NativeDotDepth>0||!ItemsPlugin.Instance.Catalogue.TryItem(id,out var d))return;
            hit.m_damage.m_fire+=d.Stat("fire");hit.m_damage.m_frost+=d.Stat("frost");hit.m_damage.m_lightning+=d.Stat("lightning");hit.m_damage.m_spirit+=d.Stat("spirit");hit.m_damage.m_poison+=d.Stat("poisonTotal");
        }
        public static void Save(Player player)
        {if(!player||player!=current)return;if(coating==null||coating.remaining<=0)player.m_customData.Remove(SaveKey);else player.m_customData[SaveKey]=JsonConvert.SerializeObject(coating);}
        public static void Unequipped(Player player,ItemDrop.ItemData item)
        {if(StowDepth==0&&player==current&&ReferenceEquals(item,coatedWeapon))Clear();}
        static void Clear(){WeaponOilVisuals.Publish(current,null,null,0);coating=null;coatedWeapon=null;if(current)current.m_customData.Remove(SaveKey);}
        public static void Dispose(){Save(current);WeaponOilVisuals.Publish(current,null,null,0);current=null;coating=null;coatedWeapon=null;applying=false;beginMotion=null;}
    }
    [HarmonyPatch(typeof(Player),nameof(Player.Save))]
    static class WeaponOilSave{static void Prefix(Player __instance)=>WeaponOilUse.Save(__instance);}
    [HarmonyPatch(typeof(Humanoid),nameof(Humanoid.UnequipItem))]
    static class WeaponOilUnequip{static void Postfix(Humanoid __instance,ItemDrop.ItemData __0){if(__instance is Player p)WeaponOilUse.Unequipped(p,__0);}}
    [HarmonyPatch(typeof(Humanoid),nameof(Humanoid.HideHandItems))]
    static class WeaponOilStow
    {static void Prefix(){WeaponOilUse.StowDepth++;}static Exception Finalizer(Exception __exception){WeaponOilUse.StowDepth=Math.Max(0,WeaponOilUse.StowDepth-1);return __exception;}}
}
