using System;
using System.Collections;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    public static class MantleSmokeContext
    {
        [ThreadStatic]static Character character;
        static readonly FieldInfo owner=AccessTools.Field(typeof(StatusEffect),"m_character");
        public static Character Enter(StatusEffect effect){var before=character;character=owner.GetValue(effect) as Character;return before;}
        public static void Restore(Character previous)=>character=previous;
        public static bool Block(Character target)=>ReferenceEquals(character,target)&&target is Player p&&MantleRuntime.Protects(p);
    }
    [HarmonyPatch(typeof(SE_Smoke),nameof(SE_Smoke.UpdateStatusEffect))]
    static class MantleNativeSmokeDamage
    {
        static void Prefix(SE_Smoke __instance,out Character __state)=>__state=MantleSmokeContext.Enter(__instance);
        static Exception Finalizer(Exception __exception,Character __state){MantleSmokeContext.Restore(__state);return __exception;}
    }
    [HarmonyPatch]
    static class MantleIncenseDamage
    {
        static MethodBase TargetMethod()=>AccessTools.Method("BlackAbbey.CenserBrother.SE_CenserChoking:UpdateStatusEffect");
        static bool Prepare()=>AccessTools.TypeByName("BlackAbbey.CenserBrother.SE_CenserChoking")!=null;
        static void Prefix(StatusEffect __instance,out Character __state)=>__state=MantleSmokeContext.Enter(__instance);
        static Exception Finalizer(Exception __exception,Character __state){MantleSmokeContext.Restore(__state);return __exception;}
    }
    [HarmonyPatch(typeof(Character),nameof(Character.ApplyDamage),new[]{typeof(HitData),typeof(bool),typeof(bool),typeof(HitData.DamageModifier)})]
    static class MantleSmokeOnlyDamage
    {
        // Never inspect damage type/name/attacker to guess that a hit is smoke.
        // Only the two exact smoke-status update call scopes may be suppressed.
        [HarmonyPriority(Priority.First)]static bool Prefix(Character __instance)=>!MantleSmokeContext.Block(__instance);
    }
    [HarmonyPatch]
    static class MantleIncenseExposure
    {
        static Type cloud,geometry,ai;
        static FieldInfo age,duration,centers,particles,stopped;
        static MethodInfo birth,contains,sight;
        static bool Prepare()
        {
            cloud=AccessTools.TypeByName("BlackAbbey.CenserBrother.CenserCloud");geometry=AccessTools.TypeByName("BlackAbbey.CenserBrother.CenserCloudGeometry");ai=AccessTools.TypeByName("BlackAbbey.CenserBrother.CenserAI");
            if(cloud==null||geometry==null||ai==null)return false;
            age=AccessTools.Field(cloud,"age");duration=AccessTools.Field(cloud,"duration");centers=AccessTools.Field(cloud,"centers");particles=AccessTools.Field(cloud,"particles");stopped=AccessTools.Field(cloud,"stopped");
            birth=AccessTools.Method(geometry,"BirthTime");contains=AccessTools.Method(geometry,"Contains");sight=AccessTools.Method(ai,"Sight",new[]{typeof(Vector3),typeof(Vector3)});
            return age!=null&&duration!=null&&centers!=null&&particles!=null&&stopped!=null&&birth!=null&&contains!=null&&sight!=null;
        }
        static MethodBase TargetMethod()=>AccessTools.Method(cloud,"Update");
        static void Postfix(object __instance)
        {
            var p=Player.m_localPlayer;if(!p||p.IsDead()||p.InGhostMode()||MantleRuntime.Worn(p)==null||(bool)stopped.GetValue(__instance))return;
            float elapsed=(float)age.GetValue(__instance);if(elapsed>=(float)duration.GetValue(__instance))return;
            var cs=centers.GetValue(__instance) as IList;var ps=particles.GetValue(__instance) as IList;if(cs==null||ps==null)return;
            var point=p.GetCenterPoint();
            for(int i=0;i<Math.Min(cs.Count,ps.Count);i++)
            {
                float born=(float)birth.Invoke(null,new object[]{i});var system=ps[i] as ParticleSystem;
                if(elapsed<born+.12f||!system||system.particleCount==0)continue;
                var center=(Vector3)cs[i];
                if((bool)contains.Invoke(null,new object[]{center,point,elapsed-born})&&(bool)sight.Invoke(null,new object[]{center,point})){MantleRuntime.ObserveCloud(p);return;}
            }
        }
    }
}
