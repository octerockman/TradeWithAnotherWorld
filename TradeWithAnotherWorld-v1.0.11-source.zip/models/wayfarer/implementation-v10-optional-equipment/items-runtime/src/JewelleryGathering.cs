using System;
using System.Linq;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    [HarmonyPatch(typeof(FishingFloat),"FixedUpdate")]
    static class JewelleryReelingCostPatch
    {
        static readonly System.Reflection.FieldInfo cost=AccessTools.Field(typeof(FishingFloat),"m_pullStaminaUse");
        static void Prefix(FishingFloat __instance,out float __state)
        {
            __state=float.NaN;var p=AccessTools.Method(typeof(FishingFloat),"GetOwner").Invoke(__instance,null) as Player;
            if(p&&__instance.GetCatch()&&JewelleryRuntime.For(p).Has("st_patient_angler_ring")){__state=(float)cost.GetValue(__instance);cost.SetValue(__instance,__state*.85f);}
        }
        static void Postfix(FishingFloat __instance,float __state){if(!float.IsNaN(__state))cost.SetValue(__instance,__state);}
    }
    static class JewelleryCropProvenance
    {
        public static readonly HashSet<string> Outputs=new HashSet<string>(new[]{"Carrot","Turnip","Onion","MushroomJotunPuffs","MushroomMagecap","Vineberry"},StringComparer.Ordinal);
        public static GameObject Output(Pickable p)=>AccessTools.Field(typeof(Pickable),"m_itemPrefab").GetValue(p) as GameObject;
        public static bool Picked(Pickable p)=>(bool)AccessTools.Method(typeof(Pickable),"GetPicked").Invoke(p,null);
    }
    [HarmonyPatch(typeof(Plant),"Grow")]
    static class JewelleryCultivatedMarkerPatch
    {
        static void Postfix(GameObject __result)
        {
            if(!__result)return;var pick=__result.GetComponent<Pickable>();var view=__result.GetComponent<ZNetView>();
            if(pick&&view&&view.IsOwner()&&JewelleryCropProvenance.Output(pick) is GameObject output&&JewelleryCropProvenance.Outputs.Contains(output.name))view.GetZDO()?.Set("TWA_WF_CultivatedFood_v1",true);
        }
    }
    [HarmonyPatch(typeof(Pickable),"RPC_Pick")]
    static class JewelleryCropYieldPatch
    {
        static void Prefix(Pickable __instance,long __0,out Player __state)
        {
            __state=null;var view=__instance.GetComponent<ZNetView>();if(!view||!view.IsOwner()||JewelleryCropProvenance.Picked(__instance)||view.GetZDO()?.GetBool("TWA_WF_CultivatedFood_v1",false)!=true)return;
            var output=JewelleryCropProvenance.Output(__instance);if(!output||!JewelleryCropProvenance.Outputs.Contains(output.name))return;
            __state=Player.GetAllPlayers().FirstOrDefault(p=>p&&p.GetComponent<ZNetView>()?.GetZDO()?.GetOwner()==__0);
        }
        static void Postfix(Pickable __instance,Player __state)
        {
            if(!__state||!JewelleryCropProvenance.Picked(__instance)||!JewelleryRuntime.For(__state).Has("st_fair_harvest_band")||UnityEngine.Random.value>=.20f)return;
            // Exactly one extra edible output, after a real cultivated harvest.
            AccessTools.Method(typeof(Pickable),"Drop").Invoke(__instance,new object[]{JewelleryCropProvenance.Output(__instance),1,1});
        }
    }
    [HarmonyPatch(typeof(CharacterDrop),"GenerateDropList")]
    static class JewelleryCommonMaterialBonusPatch
    {
        static readonly HashSet<string> rolled=new HashSet<string>(StringComparer.Ordinal);
        static void Postfix(CharacterDrop __instance,ref List<KeyValuePair<GameObject,int>> __result)
        {
            var c=__instance.GetComponent<Character>();var view=__instance.GetComponent<ZNetView>();
            if(!c||!view||!view.IsOwner()||!c.IsDead()||c.IsBoss()||c.IsTamed()||c.IsPlayer()||c.InInterior()||c.gameObject.name.StartsWith("TWA_",StringComparison.Ordinal))return;
            var hit=AccessTools.Field(typeof(Character),"m_lastHit").GetValue(c) as HitData;var p=hit?.GetAttacker() as Player;
            if(!p||!JewelleryRuntime.Hostile(c,p)||!JewelleryRuntime.For(p).Has("sd_gatherers_luck_band")||!rolled.Add(c.GetZDOID().ToString()))return;
            var eligible=__result.Where(pair=>pair.Value>0&&pair.Key&&!pair.Key.name.StartsWith("TWA_",StringComparison.Ordinal)&&pair.Key.GetComponent<ItemDrop>() is ItemDrop d&&d.m_itemData.m_shared.m_itemType==ItemDrop.ItemData.ItemType.Material&&!d.m_itemData.m_shared.m_questItem&&d.m_itemData.m_shared.m_value<=0&&!ItemsPlugin.Instance.Catalogue.TryItem(d.m_itemData,out _)).Select(pair=>pair.Key).Distinct().ToArray();
            if(eligible.Length>0&&UnityEngine.Random.value<.15f)__result.Add(new KeyValuePair<GameObject,int>(eligible[UnityEngine.Random.Range(0,eligible.Length)],1));
        }
    }
}
