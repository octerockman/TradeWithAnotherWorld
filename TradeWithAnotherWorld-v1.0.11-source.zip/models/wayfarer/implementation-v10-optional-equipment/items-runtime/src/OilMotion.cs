using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using HarmonyLib;
using Newtonsoft.Json.Linq;
using UnityEngine;
using Wayfarer.InGame;
using Object=UnityEngine.Object;

namespace Wayfarer.Items
{
    public sealed class OilBonePose {public float[] position,rotation,scale;}
    public sealed class OilPoseFrame {public float time;public OilBonePose[] bones;}
    public sealed class OilMotionPayload
    {
        public string schema,sourceClip,sourceHKXSHA256;public float duration,fps,consumeAt;
        public string[] boneNames;public OilPoseFrame[] frames;public MatrixRecord[] nativeBodyBindposes;
        internal OilRuntimePose[][] samples;
    }
    internal struct OilRuntimePose {public Vector3 position,scale;public Quaternion rotation;}
    public static class OilMotion
    {
        internal const string StampKey="TWA_WF_OilMotion_v1";
        static OilMotionPayload payload;static float nextWarning;
        internal static double NetworkNow=>ZNet.instance?ZNet.instance.GetTimeSeconds():0;
        internal static OilMotionPayload Load()
        {
            if(payload!=null)return payload;var plugin=ItemsPlugin.Instance;if(!plugin)throw new InvalidOperationException("Wayfarer item module is unavailable.");
            string folder=Path.Combine(plugin.DataDirectory,"assets","motions","oil-v2");var manifest=RuntimeCatalogue.ReadJson(Path.Combine(folder,"manifest.json"),1024*1024);
            var source=manifest["oilRegular"]??throw new InvalidDataException("Exact oil source motion is unavailable.");
            string path=PayloadReader.Safe(folder,source.Value<string>("path"));if(PayloadReader.Hash(path)!=source.Value<string>("sha256"))throw new InvalidDataException("Oil source motion hash changed.");
            var p=PayloadReader.Read<OilMotionPayload>(path);
            if(p?.schema!="wayfarer.player-oil-motion.v1"||p.sourceClip!="a000_050060"||p.sourceHKXSHA256!=OilMotionPolicy.SourceHash||!PayloadReader.Finite(p.duration)||!PayloadReader.Finite(p.consumeAt)||p.fps!=30||Math.Abs(p.duration-OilMotionPolicy.Duration)>.00001f||Math.Abs(p.consumeAt-OilMotionPolicy.ConsumeAt)>.00001f||p.frames?.Length!=116||p.boneNames?.Length!=53||p.boneNames.Distinct().Count()!=53||p.nativeBodyBindposes?.Length!=53)throw new InvalidDataException("Oil motion requires the checked116-frame source/native53-bone contract.");
            for(int f=0;f<p.frames.Length;f++)
            {
                var row=p.frames[f];if(row?.bones?.Length!=53||!PayloadReader.Finite(row.time)||Math.Abs(row.time-p.duration*f/115f)>.0001f)throw new InvalidDataException("Oil source sample time changed.");
                foreach(var b in row.bones){PayloadReader.V(b.position);PayloadReader.Q(b.rotation);var s=PayloadReader.V(b.scale);if(s.x<=0||s.y<=0||s.z<=0)throw new InvalidDataException("Oil motion has invalid native scale.");}
            }
            foreach(var m in p.nativeBodyBindposes)PayloadReader.M(m);
            p.samples=p.frames.Select(f=>f.bones.Select(b=>new OilRuntimePose{position=PayloadReader.V(b.position),rotation=PayloadReader.Q(b.rotation),scale=PayloadReader.V(b.scale)}).ToArray()).ToArray();payload=p;return p;
        }
        internal static Transform[] Bind(Player player,OilMotionPayload p)
        {
            var visual=player.GetComponent<VisEquipment>()??player.GetComponentInChildren<VisEquipment>(true);var body=visual?visual.m_bodyModel:null;
            if(!body||!body.sharedMesh)throw new InvalidDataException("Actual native player body is not ready.");
            var bones=body.bones;var bindposes=body.sharedMesh.bindposes;if(bones.Length!=53||bindposes.Length!=53)throw new InvalidDataException("Oil motion cannot retarget an unknown runtime skeleton.");
            for(int i=0;i<53;i++)
            {
                if(!bones[i]||bones[i].name!=p.boneNames[i])throw new InvalidDataException("Oil native bone order changed at "+i);
                var m=PayloadReader.M(p.nativeBodyBindposes[i]);for(int r=0;r<4;r++)for(int c=0;c<4;c++)if(Math.Abs(bindposes[i][r,c]-m[r,c])>.00001f)throw new InvalidDataException("Oil native bind changed at "+i);
            }
            return bones;
        }
        public static bool IsBusy(Player player)=>player&&player.GetComponent<OilMotionDriver>()?.Active==true;
        public static float Elapsed(Player player)=>player?player.GetComponent<OilMotionDriver>()?.Elapsed??0:0;
        public static bool CanCancel(Player player,OilMotionCancel kind)=>!IsBusy(player)||OilMotionPolicy.CanCancel(Elapsed(player),kind);
        public static bool CancelIfAllowed(Player player,OilMotionCancel kind)
        {if(!CanCancel(player,kind))return false;Cancel(player);return true;}
        public static void Cancel(Player player){if(player)player.GetComponent<OilMotionDriver>()?.StopMotion();}
        // finished receives whether the oil was actually consumed, including an
        // interruption after its event. An interruption never refunds that use.
        public static bool TryBegin(Player player,Func<bool> stillValid,Func<bool> consumeAtEvent,Action<bool> finished=null)
        {
            var view=player?player.GetComponent<ZNetView>():null;
            if(!player||player!=Player.m_localPlayer||player.IsDead()||!view||!view.IsValid()||!view.IsOwner()||!ZNet.instance||IsBusy(player)||consumeAtEvent==null)return false;
            try
            {
                var p=Load();var bones=Bind(player,p);if(stillValid!=null&&!stillValid())return false;
                var driver=player.GetComponent<OilMotionDriver>()??player.gameObject.AddComponent<OilMotionDriver>();driver.Begin(player,p,bones,stillValid,consumeAtEvent,finished);return true;
            }
            catch(Exception e){Warn("OIL_SOURCE_MOTION_REFUSED "+e.Message);return false;}
        }
        internal static void Observe(Player player)
        {
            if(!player||player==Player.m_localPlayer||player.IsDead())return;var view=player.GetComponent<ZNetView>();if(!view||!view.IsValid())return;long stamp=view.GetZDO().GetLong(StampKey,0);
            if(stamp<=0||NetworkNow-stamp/1000.0>OilMotionPolicy.Duration+.2)return;
            var existing=player.GetComponent<OilMotionDriver>();if(existing&&existing.Stamp==stamp)return;
            try{var p=Load();var bones=Bind(player,p);var driver=existing??player.gameObject.AddComponent<OilMotionDriver>();driver.BeginRemote(player,p,bones,stamp);}
            catch(Exception e){Warn("OIL_REMOTE_SOURCE_MOTION_REFUSED "+e.Message);}
        }
        internal static void Warn(string text){if(Time.unscaledTime<nextWarning)return;nextWarning=Time.unscaledTime+5;ItemsPlugin.Instance?.Warn(text);}
        internal static void Dispose(){payload=null;nextWarning=0;WeaponOilUse.RegisterMotion(null);foreach(var driver in Object.FindObjectsByType<OilMotionDriver>(FindObjectsInactive.Include,FindObjectsSortMode.None))driver.StopMotion();}
    }
    [DefaultExecutionOrder(8000)]
    public sealed class OilMotionDriver:MonoBehaviour
    {
        public bool Active{get;private set;}public float Elapsed{get;private set;}public long Stamp{get;private set;}
        Player player;ZNetView view;OilMotionPayload payload;Transform[] bones;OilRuntimePose[] entry,exit;
        VisEquipment visual;
        readonly Dictionary<GameObject,bool> leftVisualStates=new Dictionary<GameObject,bool>();
        static readonly System.Reflection.FieldInfo leftInstance=AccessTools.Field(typeof(VisEquipment),"m_leftItemInstance");
        readonly OilRuntimePose[] displayed=new OilRuntimePose[53];
        Func<bool> valid,consume;Action<bool> finished;bool local,attempted,consumed,leaving;float started,leaveAt,observed;int damageRevision;
        static OilRuntimePose Capture(Transform b)=>new OilRuntimePose{position=b.localPosition,rotation=b.localRotation,scale=b.localScale};
        void Init(Player p,OilMotionPayload source,Transform[] actualBones)
        {
            if(Active)StopMotion();
            player=p;view=p.GetComponent<ZNetView>();payload=source;bones=actualBones;entry=bones.Select(Capture).ToArray();Array.Copy(entry,displayed,53);exit=null;Active=true;leaving=false;attempted=false;consumed=false;observed=Time.time;damageRevision=SupplyUse.LocalDamageRevision;
            visual=p.GetComponent<VisEquipment>()??p.GetComponentInChildren<VisEquipment>(true);HideLeftVisual();
        }
        void HideLeftVisual()
        {var current=visual?leftInstance.GetValue(visual) as GameObject:null;if(!current||leftVisualStates.ContainsKey(current))return;leftVisualStates.Add(current,current.activeSelf);current.SetActive(false);}
        void RestoreLeftVisuals(){foreach(var row in leftVisualStates)if(row.Key)row.Key.SetActive(row.Value);leftVisualStates.Clear();}
        public void Begin(Player p,OilMotionPayload source,Transform[] actualBones,Func<bool> validator,Func<bool> use,Action<bool> done)
        {
            Init(p,source,actualBones);local=true;valid=validator;consume=use;finished=done;started=Time.time;Elapsed=0;Stamp=Math.Max(1,(long)Math.Round(OilMotion.NetworkNow*1000));view.GetZDO().Set(OilMotion.StampKey,Stamp);player.SetMoveDir(Vector3.zero);
        }
        public void BeginRemote(Player p,OilMotionPayload source,Transform[] actualBones,long stamp)
        {Init(p,source,actualBones);local=false;valid=null;consume=null;finished=null;Stamp=stamp;Elapsed=Mathf.Max(0,(float)(OilMotion.NetworkNow-stamp/1000.0));}
        void Update()
        {
            if(!Active)return;
            if(!player||player.IsDead()||!view||!view.IsValid()){StopMotion();return;}
            HideLeftVisual();
            float next=local?Mathf.Max(0,Time.time-started):Mathf.Max(0,(float)(OilMotion.NetworkNow-Stamp/1000.0));
            if(local)
            {
                if(SupplyUse.LocalDamageRevision!=damageRevision||valid!=null&&!valid()){StopMotion();return;}
                if(!attempted&&next>=OilMotionPolicy.ConsumeAt)
                {attempted=true;try{consumed=consume();}catch(Exception e){OilMotion.Warn("OIL_CONSUME_EVENT_FAILED "+e.Message);consumed=false;}if(!consumed){StopMotion();return;}}
            }
            else if(view.GetZDO().GetLong(OilMotion.StampKey,0)!=Stamp){StopMotion();return;}
            Elapsed=Mathf.Min(next,payload.duration);if(next>=payload.duration)StopMotion();
        }
        public void StopMotion()
        {
            if(!Active)return;Active=false;leaving=true;leaveAt=Time.time;exit=displayed.ToArray();RestoreLeftVisuals();
            if(local&&view&&view.IsValid()&&view.IsOwner()&&view.GetZDO().GetLong(OilMotion.StampKey,0)==Stamp)view.GetZDO().Set(OilMotion.StampKey,0L);
            var callback=finished;finished=null;valid=null;consume=null;if(local)try{callback?.Invoke(consumed);}catch(Exception e){OilMotion.Warn("OIL_COMPLETION_CALLBACK_FAILED "+e.Message);}
        }
        static OilRuntimePose Mix(OilRuntimePose a,OilRuntimePose b,float t)
        {
            return new OilRuntimePose{position=Vector3.LerpUnclamped(a.position,b.position,t),rotation=Quaternion.SlerpUnclamped(a.rotation,b.rotation,t),scale=Vector3.LerpUnclamped(a.scale,b.scale,t)};
        }
        void LateUpdate()
        {
            if(!Active&&!leaving)return;
            if(bones==null||bones.Any(b=>!b)){StopMotion();Destroy(this);return;}
            if(leaving&&Time.time-leaveAt>=.12f){leaving=false;return;}
            if(Active)HideLeftVisual();
            if(Active)
            {
                OilMotionPolicy.Sample(Elapsed,payload.frames.Length,out int a,out int b,out float t);float blend=Mathf.SmoothStep(0,1,(Time.time-observed)/.12f);
                for(int i=0;i<53;i++)displayed[i]=Mix(entry[i],Mix(payload.samples[a][i],payload.samples[b][i],t),blend);
            }
            else
            {
                float t=Mathf.SmoothStep(0,1,(Time.time-leaveAt)/.12f);
                for(int i=0;i<53;i++)displayed[i]=Mix(exit[i],Capture(bones[i]),t);
            }
            for(int i=0;i<53;i++){bones[i].localPosition=displayed[i].position;bones[i].localRotation=displayed[i].rotation;bones[i].localScale=displayed[i].scale;}
        }
        void OnDisable(){StopMotion();}
    }
    [HarmonyPatch(typeof(Player),"Update")]
    static class OilRemotePoseObserver{static void Postfix(Player __instance)=>OilMotion.Observe(__instance);}
    [HarmonyPatch(typeof(ItemsPlugin),"OnDestroy")]
    static class OilMotionShutdown{static void Prefix()=>OilMotion.Dispose();}
    [HarmonyPatch(typeof(ItemsPlugin),"Register")]
    static class OilMotionAdmission
    {
        static void Postfix()
        {try{OilMotion.Load();WeaponOilUse.RegisterMotion(OilMotion.TryBegin);ItemsPlugin.Instance?.Report("OIL_SOURCE_MOTION_READY source=a000_050060 frames=116 consumeAt=25/30 nativeBones=53 gameplay=awaiting_Jesse");}catch(Exception e){WeaponOilUse.RegisterMotion(null);OilMotion.Warn("OIL_SOURCE_MOTION_NOT_ADMITTED "+e.Message);}}
    }
    [HarmonyPatch(typeof(Player),nameof(Player.SetControls))]
    static class OilMotionControls
    {
        [HarmonyPriority(Priority.Last)]
        static void Prefix(Player __instance,ref Vector3 __0,ref bool __1,ref bool __2,ref bool __3,ref bool __4,ref bool __5,ref bool __6,ref bool __7,ref bool __8,ref bool __9,ref bool __10,ref bool __11)
        {
            if(!OilMotion.IsBusy(__instance))return;
            bool release=(__1||__2||__3||__4)&&OilMotion.CanCancel(__instance,OilMotionCancel.RightAttack)||(__5||__6)&&OilMotion.CanCancel(__instance,OilMotionCancel.Guard)||__11&&OilMotion.CanCancel(__instance,OilMotionCancel.Dodge)||(__7||__8)&&OilMotion.CanCancel(__instance,OilMotionCancel.JumpCrouchWeaponSwitch)||(__0.sqrMagnitude>.0001f||__10)&&OilMotion.CanCancel(__instance,OilMotionCancel.Movement);
            if(release){OilMotion.Cancel(__instance);return;}
            __0=Vector3.zero;__1=__2=__3=__4=__5=__6=__7=__8=__9=__10=__11=false;__instance.SetMoveDir(Vector3.zero);
        }
    }
    [HarmonyPatch(typeof(Humanoid),nameof(Humanoid.EquipItem))]
    static class OilMotionWeaponSwitch
    {
        static bool Prefix(Humanoid __instance,ItemDrop.ItemData __0,ref bool __result)
        {
            if(!(__instance is Player p)||!OilMotion.IsBusy(p)||__0==null||!(__0.IsWeapon()||__0.m_shared.m_itemType==ItemDrop.ItemData.ItemType.Shield||__0.m_shared.m_itemType==ItemDrop.ItemData.ItemType.Torch))return true;
            if(OilMotion.CancelIfAllowed(p,OilMotionCancel.JumpCrouchWeaponSwitch))return true;__result=false;return false;
        }
    }
    [HarmonyPatch(typeof(Humanoid),nameof(Humanoid.UnequipItem))]
    static class OilMotionStowWeapon
    {
        static bool Prefix(Humanoid __instance,ItemDrop.ItemData __0)
        {if(!(__instance is Player p)||!OilMotion.IsBusy(p)||!ReferenceEquals(__0,JewelleryRuntime.HeldRight(p))&&!ReferenceEquals(__0,JewelleryRuntime.HeldLeft(p)))return true;return OilMotion.CancelIfAllowed(p,OilMotionCancel.JumpCrouchWeaponSwitch);}
    }
}
