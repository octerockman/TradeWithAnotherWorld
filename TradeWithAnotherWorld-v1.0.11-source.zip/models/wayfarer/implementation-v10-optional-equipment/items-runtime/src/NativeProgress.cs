using System;
using System.Collections.Generic;
using System.Reflection;
using BepInEx.Bootstrap;
using HarmonyLib;
using UnityEngine;
namespace Wayfarer.Items
{
    public static class NativeProgress
    {
        public static readonly HashSet<string> AllowedFacts=new HashSet<string>(StringComparer.Ordinal){"abbey_visited","concealed_route_discovered","boat_journey_completed","used_elemental_magic","trapper_bundle_opened","coated_trial_hit","censer_ember_seen","survived_hostile_fire"};
        static object helper;static MethodInfo contains;static Type censerType;static PropertyInfo censerSeconds;static float next;static Player current;static Ship ship;static Vector3 journeyStart,lastPoint;static float distance;
        public static void Initialize(Harmony harmony)
        {
            JewelleryRuntime.HostileFireHealthLost+=(p,loss)=>{if(p==Player.m_localPlayer&&loss>0&&!p.IsDead())RuntimeFacts.Record("survived_hostile_fire");};
            if(Chainloader.PluginInfos.TryGetValue("studio.otherworld.blackabbeyroomtest",out var info))helper=info.Instance;
            contains=helper==null?null:AccessTools.Method(helper.GetType(),"RunContains",new[]{typeof(Vector3)});
            var r07=AccessTools.TypeByName("BlackAbbeySixRooms.R07InteractionRuntime");var open=AccessTools.Method(r07,"Open",new[]{typeof(string),typeof(Player)});
            if(contains==null||open==null)throw new InvalidOperationException("The Abbey discovery event contract changed.");
            harmony.Patch(open,prefix:new HarmonyMethod(typeof(NativeProgress),nameof(CacheBefore)),postfix:new HarmonyMethod(typeof(NativeProgress),nameof(CacheAfter)));
            censerType=AccessTools.TypeByName("BlackAbbey.CenserBrother.CenserInstance");censerSeconds=AccessTools.Property(censerType,"ActionSeconds");
        }
        public static void Tick()
        {
            if(Time.time<next)return;next=Time.time+.5f;var p=Player.m_localPlayer;if(!p||p.IsDead()){current=null;ship=null;distance=0;return;}
            if(current!=p){current=p;ship=null;distance=0;foreach(string fact in AllowedFacts)if(fact!="coated_trial_hit"&&RuntimeFacts.Have(p,fact))ItemsPlugin.Instance.Commerce.NativeFact(fact);}
            if(helper!=null&&!RuntimeFacts.Have(p,"abbey_visited")&&contains.Invoke(helper,new object[]{p.transform.position}) is bool inside&&inside)RuntimeFacts.Record("abbey_visited");
            if(censerType!=null&&censerSeconds!=null&&!RuntimeFacts.Have(p,"censer_ember_seen"))foreach(var c in Character.GetAllCharacters())
            {
                if(!c||c.IsDead()||c.name.Replace("(Clone)","").Trim()!="BA_CenserBrother"||Vector3.Distance(c.transform.position,p.transform.position)>20)continue;
                var view=c.GetComponent<ZNetView>();if(!view||!view.IsValid()||view.GetZDO().GetInt("cb_action",0)!=3)continue;
                var component=c.GetComponent(censerType);if(component&&censerSeconds.GetValue(component) is float elapsed&&elapsed>=0&&elapsed<.85f&&OffhandEffects.ClearPath(p.GetCenterPoint(),c.GetCenterPoint(),p,c)){RuntimeFacts.Record("censer_ember_seen");break;}
            }
            var controlled=p.GetControlledShip();
            if(controlled)
            {if(ship!=controlled){ship=controlled;journeyStart=lastPoint=p.transform.position;distance=0;}else{float step=Vector3.Distance(lastPoint,p.transform.position);if(step<30)distance+=step;lastPoint=p.transform.position;}return;}
            if(ship&&distance>=30&&Vector3.Distance(journeyStart,p.transform.position)>=15&&!p.IsAttachedToShip()&&Ship.GetLocalShip()==null)
            {var onGround=AccessTools.Method(typeof(Character),"IsOnGround");if(onGround?.Invoke(p,null) is bool landed&&landed){RuntimeFacts.Record("boat_journey_completed");ship=null;distance=0;}}
        }
        static void CacheBefore(object __instance,string __0,Player __1,out bool __state)
        {__state=__0=="secret-box"&&__1==Player.m_localPlayer&&AccessTools.Method(__instance.GetType(),"CanOpen").Invoke(__instance,new object[]{__0}) is bool can&&can;}
        static void CacheAfter(string __0,Player __1,bool __result,bool __state)
        {if(__result&&__state&&__1==Player.m_localPlayer&&__0=="secret-box")RuntimeFacts.Record("concealed_route_discovered");}
        public static void CoatedHit(string coating)
        {if(coating!=null&&(coating=="oil_fire_lesser"||coating=="oil_lightning_lesser"||coating=="oil_poison_lesser"))ItemsPlugin.Instance?.Commerce.NativeFact("coated_trial_hit");}
    }
}
