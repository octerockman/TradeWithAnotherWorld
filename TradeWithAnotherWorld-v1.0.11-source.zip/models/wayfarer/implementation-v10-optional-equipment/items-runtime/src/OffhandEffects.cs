using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
namespace Wayfarer.Items
{
    public static class OffhandEffects
    {
        public static void Emit(Player p,OffhandEmission m,long action,bool authoritative)
        {
            if(!ItemsPlugin.Instance.Catalogue.TryItem(m.item,out var d))return;
            if(d.Kind=="handbell")OffhandSounds.Play(d.Id,m.origin);
            if(d.Kind=="handbell"&&d.Id=="sundered_bell")
            {
                float total=(float)d.Stats["damagePerMoteByQuality"][m.quality-1]*m.damageFactor;
                for(int i=0;i<5;i++)
                {Vector3 dir=Quaternion.AngleAxis((i-2)*8,Vector3.up)*m.direction;OffhandMote.Create(p,m.origin+Vector3.up*.04f*i,dir,25,12,total,action,authoritative,true);}
            }
            else if(d.Kind=="handbell")
            {
                OffhandParticles.Pulse(m.origin,15,new Color(.8f,.79f,.58f,.5f));if(!authoritative)return;
                float amount=(float)d.Stats["spiritByQuality"][m.quality-1]*m.damageFactor;
                foreach(var target in Character.GetAllCharacters().Where(c=>c&&JewelleryRuntime.Hostile(c,p)&&!c.IsDead()&&Vector3.Distance(c.GetCenterPoint(),p.GetCenterPoint())<=15).ToArray())
                {
                    if(!ClearPath(p.GetCenterPoint(),target.GetCenterPoint(),p,target))continue;
                    bool susceptible=(HitData.DamageModifier)HarmonyLib.AccessTools.Method(typeof(Character),"GetDamageModifier").Invoke(target,new object[]{HitData.DamageType.Spirit})!=HitData.DamageModifier.Immune;
                    var hit=Hit(p,target.GetCenterPoint(),m.direction,Skills.SkillType.ElementalMagic,true,OwnedCombatEffects.Holy);
                    hit.m_damage.m_spirit=susceptible||OwnedCombatEffects.Abbey(target)?amount:0;
                    using(CombatReceipts.UseAction(action))target.Damage(hit);
                }
                p.RaiseSkill(Skills.SkillType.ElementalMagic,1);
            }
            else if(m.action=="censer_flick")
            {float total=OffhandCombatPolicy.Quality(d.Stat("emberTotalDamage"),d.Stat("emberTotalDamagePerQuality"),m.quality)*m.damageFactor;OffhandMote.Create(p,m.origin,m.direction,25,18,total,action,authoritative,false);}
            else
            {
                bool torch=d.Kind=="torch";float radius=torch?(m.action=="torch_wide_sweep"?2.5f:2f):2.8f;
                OffhandParticles.Burst(m.origin,torch?new Color(1,.45f,.08f,.7f):new Color(.28f,.27f,.25f,.2f),torch?18:26,torch?.15f:.6f);
                if(authoritative)
                {
                    foreach(var target in Character.GetAllCharacters().Where(c=>c&&!c.IsDead()&&JewelleryRuntime.Hostile(c,p)&&Vector3.Distance(c.GetCenterPoint(),p.GetCenterPoint())<=radius).ToArray())
                    {
                        Vector3 to=target.GetCenterPoint()-p.GetCenterPoint();if(Vector3.Dot(to.normalized,p.transform.forward)<(m.action=="torch_swing"?.35f:-.15f)||!ClearPath(p.GetCenterPoint(),target.GetCenterPoint(),p,target))continue;
                        var hit=Hit(p,target.GetCenterPoint(),to.normalized,Skills.SkillType.Clubs,false);
                        hit.m_damage.m_blunt=OffhandCombatPolicy.Quality(d.Stat("blunt"),d.Stat(torch?"bluntPerQuality":"physicalDamagePerQuality"),m.quality)*m.damageFactor;
                        if(torch){hit.m_damage.m_fire=OffhandCombatPolicy.Quality(d.Stat("fire"),d.Stat("firePerQuality"),m.quality)*m.damageFactor;hit.m_damage.m_spirit=OffhandCombatPolicy.Quality(d.Stat("spirit"),d.Stat("spiritPerQuality"),m.quality)*m.damageFactor;if(m.action=="torch_wide_sweep")hit.ApplyModifier(d.Stat("secondaryDamageMultiplier",1.5f));}
                        hit.m_pushForce=d.Stat("knockback",20);using(CombatReceipts.UseAction(action))target.Damage(hit);
                    }
                }
                if(!torch)
                {var cloud=new GameObject("Wayfarer censer sweep cloud").AddComponent<OffhandSmokeCloud>();cloud.transform.position=p.transform.position+p.transform.forward*1.8f+Vector3.up*.65f;cloud.Initialize(p,d,m.quality,m.damageFactor,action,authoritative);}
            }
        }
        public static HitData Hit(Player p,Vector3 point,Vector3 direction,Skills.SkillType skill,bool ranged,string effect=null)
        {var hit=new HitData{m_point=point,m_dir=direction,m_skill=skill,m_skillLevel=p.GetSkillLevel(skill),m_dodgeable=true,m_blockable=true,m_ranged=ranged,m_backstabBonus=1,m_staggerMultiplier=1,m_statusEffectHash=effect==null?0:effect.GetStableHashCode()};hit.SetAttacker(p);return hit;}
        public static bool ClearPath(Vector3 from,Vector3 to,Character owner,Character target)
        {
            var delta=to-from;foreach(var h in Physics.RaycastAll(from,delta.normalized,delta.magnitude,Physics.DefaultRaycastLayers,QueryTriggerInteraction.Ignore).OrderBy(h=>h.distance))
            {if(!h.collider)continue;var c=h.collider.GetComponentInParent<Character>();if(c==owner||c==target||c)continue;return false;}return true;
        }
    }
    public sealed class OffhandMote:MonoBehaviour
    {
        Player owner;Vector3 direction;float range,speed,total,traveled;long action;bool authoritative,sundered;Character target;bool xp;
        public static void Create(Player p,Vector3 origin,Vector3 direction,float range,float speed,float damage,long action,bool authoritative,bool sundered)
        {
            var go=new GameObject(sundered?"Sundered Bell mote":"Censer ember");go.transform.position=origin;var m=go.AddComponent<OffhandMote>();m.owner=p;m.direction=direction.normalized;m.range=range;m.speed=speed;m.total=damage;m.action=action;m.authoritative=authoritative;m.sundered=sundered;
            OffhandParticles.Trail(go.transform,sundered?.04f:.07f);m.target=Character.GetAllCharacters().Where(c=>c&&p&&JewelleryRuntime.Hostile(c,p)&&!c.IsDead()&&Vector3.Distance(c.GetCenterPoint(),origin)<=range&&Vector3.Dot((c.GetCenterPoint()-origin).normalized,direction)>.4f&&OffhandEffects.ClearPath(origin,c.GetCenterPoint(),p,c)).OrderBy(c=>Vector3.Angle(c.GetCenterPoint()-origin,direction)).ThenBy(c=>Vector3.Distance(c.GetCenterPoint(),origin)).FirstOrDefault();
        }
        void Update()
        {
            if(!owner){Destroy(gameObject);return;}if(sundered&&target&&!target.IsDead())direction=Vector3.RotateTowards(direction,(target.GetCenterPoint()-transform.position).normalized,2.8f*Time.deltaTime,0).normalized;
            float distance=Math.Min(speed*Time.deltaTime,range-traveled);Vector3 start=transform.position;
            foreach(var hit in Physics.SphereCastAll(start,.075f,direction,distance,Physics.DefaultRaycastLayers,QueryTriggerInteraction.Ignore).OrderBy(h=>h.distance))
            {
                if(!hit.collider)continue;var c=hit.collider.GetComponentInParent<Character>();if(c==owner)continue;if(c&&!JewelleryRuntime.Hostile(c,owner))continue;
                if(c&&authoritative&&!c.IsDead())
                {
                    var damage=OffhandEffects.Hit(owner,hit.point,direction,sundered?Skills.SkillType.ElementalMagic:Skills.SkillType.Clubs,true,sundered?OwnedCombatEffects.Ember:null);
                    if(sundered)damage.m_damage.m_fire=total;else{damage.m_damage.m_blunt=total*.4f;damage.m_damage.m_fire=total*.6f;}
                    using(CombatReceipts.UseAction(action))c.Damage(damage);
                    if(sundered&&!xp){owner.RaiseSkill(Skills.SkillType.ElementalMagic,.2f);xp=true;}
                }
                // Walls and closed doors terminate motes. This visual burst has
                // no area damage or explosion component.
                OffhandParticles.Burst(hit.point,new Color(1,.35f,.04f,.55f),9,.04f);Destroy(gameObject);return;
            }
            transform.position+=direction*distance;traveled+=distance;if(traveled>=range)Destroy(gameObject);
        }
    }
    public sealed class OffhandSmokeCloud:MonoBehaviour
    {
        Player owner;ItemDefinition definition;float life,next,total;long action;bool authoritative;readonly HashSet<ZDOID> affected=new HashSet<ZDOID>();
        public void Initialize(Player p,ItemDefinition d,int quality,float factor,long id,bool own)
        {owner=p;definition=d;life=d.Stat("smokeDuration",4);total=OffhandCombatPolicy.Quality(d.Stat("smokeTotalDamage"),d.Stat("smokeTotalDamagePerQuality"),quality)*factor;action=id;authoritative=own;OffhandParticles.Cloud(transform,d.Stat("smokeRadius",2.5f),life);}
        void Update()
        {
            life-=Time.deltaTime;if(life<=0||!owner){Destroy(gameObject);return;}if(!authoritative||Time.time<next)return;next=Time.time+.1f;
            foreach(var target in Character.GetAllCharacters().Where(c=>c&&!c.IsDead()&&JewelleryRuntime.Hostile(c,owner)&&Vector3.Distance(c.GetCenterPoint(),transform.position)<=definition.Stat("smokeRadius",2.5f)).ToArray())
            {if(affected.Contains(target.GetZDOID())||!OffhandEffects.ClearPath(transform.position,target.GetCenterPoint(),owner,target))continue;affected.Add(target.GetZDOID());var hit=OffhandEffects.Hit(owner,target.GetCenterPoint(),Vector3.zero,Skills.SkillType.Clubs,true,OwnedCombatEffects.Smoke);hit.m_damage.m_poison=total;hit.m_blockable=false;using(CombatReceipts.UseAction(action))target.Damage(hit);}
        }
    }
}
