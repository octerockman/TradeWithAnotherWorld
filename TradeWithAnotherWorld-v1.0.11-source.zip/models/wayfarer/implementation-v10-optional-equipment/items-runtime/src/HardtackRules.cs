using System;
using System.Linq;
using HarmonyLib;

namespace Wayfarer.Items
{
    // This exception belongs only to our hardtack family. Other native food
    // uniqueness, replacement and recovery rules remain unchanged.
    static class HardtackRules
    {
        internal static bool IsHardtack(ItemDrop.ItemData item)=>ItemsPlugin.Instance&&ItemsPlugin.Instance.Catalogue.TryItem(item,out var d)&&d.Text("family")=="hardtack";
        internal static bool CanEat(Player player)=>player.GetFoods().Count<3||player.GetFoods().Any(f=>f.CanEatAgain());
        internal static bool Eat(Player player,ItemDrop.ItemData item)
        {
            var foods=player.GetFoods();Player.Food target;
            if(foods.Count<3){target=new Player.Food();foods.Add(target);}
            else{target=foods.Where(f=>f.CanEatAgain()).OrderBy(f=>f.m_time/Math.Max(1,f.m_item.m_shared.m_foodBurnTime)).FirstOrDefault();if(target==null)return false;}
            target.m_name=item.m_dropPrefab.name;target.m_item=item;target.m_time=item.m_shared.m_foodBurnTime;
            target.m_health=item.m_shared.m_food;target.m_stamina=item.m_shared.m_foodStamina;target.m_eitr=item.m_shared.m_foodEitr;
            AccessTools.Method(typeof(Player),"UpdateFood").Invoke(player,new object[]{0f,true});
            if(Game.instance){Game.instance.IncrementPlayerStat((PlayerStatType)49,1,false);Game.instance.GetPlayerProfile().IncrementStatFoodEaten(item.m_shared.m_name,1,item.m_cheated);}
            return true;
        }
    }
    [HarmonyPatch(typeof(Player),nameof(Player.CanEat))]
    static class HardtackCanEat
    {
        static bool Prefix(Player __instance,ItemDrop.ItemData __0,bool __1,ref bool __result)
        {if(!HardtackRules.IsHardtack(__0))return true;__result=HardtackRules.CanEat(__instance);if(!__result&&__1)__instance.Message(MessageHud.MessageType.Center,"$msg_foodfull");return false;}
    }
    [HarmonyPatch(typeof(Player),nameof(Player.EatFood))]
    static class HardtackEat
    {
        static bool Prefix(Player __instance,ItemDrop.ItemData __0,ref bool __result)
        {if(!HardtackRules.IsHardtack(__0))return true;__result=HardtackRules.Eat(__instance,__0);return false;}
    }
}
