using System;
using System.Collections.Generic;
using HarmonyLib;
using Jotunn.Entities;
using Jotunn.Managers;
using UnityEngine;

namespace Wayfarer.Items
{
    public static class OwnedCombatEffects
    {
        public const string Ember="TWA_WF_SunderedEmber",Smoke="TWA_WF_CenserSmoke",Holy="TWA_WF_ConsecratedPulse";
        static bool registered;
        [ThreadStatic]static Stack<HitData> hits;
        public static HitData Current=>hits!=null&&hits.Count>0?hits.Peek():null;
        public static bool Is(string id)=>Current?.m_statusEffectHash==id.GetStableHashCode();
        public static void Register()
        {
            if(registered)return;
            foreach(string name in new[]{Ember,Smoke})
            {var se=ScriptableObject.CreateInstance<StatusEffect>();se.name=name;se.m_name=name;se.m_hidden=true;se.m_ttl=.05f;if(!ItemManager.Instance.AddStatusEffect(new CustomStatusEffect(se,false)))throw new InvalidOperationException("Combat marker registration failed: "+name);}
            var holy=ScriptableObject.CreateInstance<SE_Stats>();holy.name=Holy;holy.m_name="Consecrated";holy.m_hidden=true;holy.m_ttl=6;holy.m_speedModifier=-.15f;
            if(!ItemManager.Instance.AddStatusEffect(new CustomStatusEffect(holy,false)))throw new InvalidOperationException("Consecrated status registration failed.");
            registered=true;
        }
        internal static void Push(HitData hit){if(hits==null)hits=new Stack<HitData>();hits.Push(hit);}
        internal static void Pop(){if(hits!=null&&hits.Count>0)hits.Pop();}
        public static bool Abbey(Character c)=>c&&new HashSet<string>(StringComparer.Ordinal){"BA_BlindAbbot","BA_ReliquaryKnight","BA_ReliquaryGuard","BA_CenserBrother","BA_BellThrall","TWA_HushedMonk_Test"}.Contains(c.name.Replace("(Clone)","").Trim());
        public static void DirectAfterMitigation(Character victim,float damage,HitData source)
        {
            if(!victim||victim.IsDead()||damage<=0||!victim.IsOwner())return;
            // This budget already passed native block, resistance and armour.
            // ApplyDamage commits it once without entering RPC mitigation again.
            var tick=new HitData{m_damage=new HitData.DamageTypes{m_damage=damage},m_point=victim.GetCenterPoint(),m_dir=source.m_dir,m_attacker=source.m_attacker,m_skill=source.m_skill,m_dodgeable=false,m_blockable=false,m_ranged=true};
            victim.ApplyDamage(tick,true,false,HitData.DamageModifier.Normal);
        }
        public static void Budget(Character target,float total,float duration,HitData source,string kind,int maximum=64)
        {
            if(!target||!target.IsOwner()||total<=0)return;
            var state=target.GetComponent<OwnedDamageBudget>()??target.gameObject.AddComponent<OwnedDamageBudget>();state.Add(total,duration,source,kind,maximum);
        }
    }
    public sealed class OwnedDamageBudget:MonoBehaviour
    {
        sealed class Charge{public float total,elapsed,duration,paid;public string kind;public HitData source;}
        readonly List<Charge> charges=new List<Charge>();Character victim;
        void Awake()=>victim=GetComponent<Character>();
        public void Add(float total,float duration,HitData source,string kind,int max)
        {while(charges.FindAll(c=>c.kind==kind).Count>=max){int i=charges.FindIndex(c=>c.kind==kind);charges.RemoveAt(i);}charges.Add(new Charge{total=total,duration=Math.Max(.1f,duration),source=source.Clone(),kind=kind});}
        void Update()
        {
            if(!victim||victim.IsDead()){Destroy(this);return;}if(!victim.IsOwner())return;
            foreach(var c in charges.ToArray())
            {c.elapsed=Math.Min(c.duration,c.elapsed+Time.deltaTime);float owed=c.total*c.elapsed/c.duration-c.paid;if(owed>=.5f||c.elapsed>=c.duration){c.paid+=owed;OwnedCombatEffects.DirectAfterMitigation(victim,owed,c.source);}if(c.elapsed>=c.duration)charges.Remove(c);}
            if(charges.Count==0)Destroy(this);
        }
    }
    [HarmonyPatch(typeof(Character),"RPC_Damage")]
    static class OwnedCombatHitScope
    {
        [HarmonyPriority(Priority.First)]static void Prefix(HitData __1)=>OwnedCombatEffects.Push(__1);
        static Exception Finalizer(Exception __exception){OwnedCombatEffects.Pop();return __exception;}
    }
    [HarmonyPatch(typeof(Character),"GetDamageModifiers")]
    static class OwnedCombatResistance
    {
        static void Postfix(Character __instance,ref HitData.DamageModifiers __result)
        {if(OwnedCombatEffects.Is(OwnedCombatEffects.Ember))__result.m_fire=HitData.DamageModifier.Normal;if(OwnedCombatEffects.Is(OwnedCombatEffects.Holy)&&OwnedCombatEffects.Abbey(__instance)&&__result.m_spirit==HitData.DamageModifier.Immune)__result.m_spirit=HitData.DamageModifier.Normal;}
    }
    [HarmonyPatch(typeof(Character),"AddFireDamage")]
    static class SunderedEmberBudget
    {
        static bool Prefix(Character __instance,float __0)
        {if(!OwnedCombatEffects.Is(OwnedCombatEffects.Ember))return true;var source=OwnedCombatEffects.Current;OwnedCombatEffects.DirectAfterMitigation(__instance,__0*.6f,source);OwnedCombatEffects.Budget(__instance,__0*.4f,2,source,"sundered");return false;}
    }
    [HarmonyPatch(typeof(Character),"AddPoisonDamage")]
    static class CenserSmokeBudget
    {
        static bool Prefix(Character __instance,float __0)
        {if(!OwnedCombatEffects.Is(OwnedCombatEffects.Smoke))return true;OwnedCombatEffects.Budget(__instance,__0,4,OwnedCombatEffects.Current,"censer-smoke");return false;}
    }
}
