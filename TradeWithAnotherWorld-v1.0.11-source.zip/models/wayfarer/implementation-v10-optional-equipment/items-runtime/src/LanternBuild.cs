using System;
using System.Linq;
using System.Collections.Generic;
using Jotunn.Entities;
using Jotunn.Managers;
using UnityEngine;
using Wayfarer.InGame;
using Object=UnityEngine.Object;

namespace Wayfarer.Items
{
    public static class LanternBuild
    {
        public const string HangingPrefab="TWA_WF_HangingLantern",PostPrefab="TWA_WF_LanternPost";
        static readonly HashSet<string> registered=new HashSet<string>(StringComparer.Ordinal);
        public static void Register(ItemsPlugin plugin)
        {
            if(ItemRegistry.Current==null||!ItemRegistry.Current.TryPrefab("wayfarer_lantern",out var lantern))throw new InvalidOperationException("Lantern inventory item must register before build entries.");
            var wood=PrefabManager.Instance.GetPrefab("Wood");if(!wood||!wood.GetComponent<ItemDrop>())throw new InvalidOperationException("Native Wood material unavailable.");
            NativeCampLighting.Validate();
            Build(plugin,HangingPrefab,"Wayfarer's Hanging Lantern","wayfarer_hanging_lantern",lantern,null);
            Build(plugin,PostPrefab,"Wayfarer's Lamp Post","wayfarer_lantern_post",lantern,wood);
        }
        static void Build(ItemsPlugin plugin,string id,string title,string asset,GameObject lantern,GameObject wood)
        {
            if(registered.Contains(id))return;
            if(!plugin.Visuals.Has(asset))throw new InvalidOperationException("Missing actual lantern fixture visual: "+asset);
            var manager=PrefabManager.Instance;var source=manager.GetPrefab("wood_pole");
            if(!source||!source.GetComponent<Piece>()||!source.GetComponent<ZNetView>()||!source.GetComponent<WearNTear>())throw new InvalidOperationException("Native piece construction lifecycle unavailable.");
            if(manager.GetPrefab(id))throw new InvalidOperationException("Lantern build identity is already owned: "+id);
            var root=manager.CreateClonedPrefab(id,source);root.SetActive(false);root.transform.localPosition=Vector3.zero;root.transform.localRotation=Quaternion.identity;root.transform.localScale=Vector3.one;
            try
            {
                foreach(var lod in root.GetComponentsInChildren<LODGroup>(true))Object.DestroyImmediate(lod);
                foreach(var child in root.transform.Cast<Transform>().ToArray())Object.DestroyImmediate(child.gameObject);
                foreach(var renderer in root.GetComponents<Renderer>())Object.DestroyImmediate(renderer);
                foreach(var mesh in root.GetComponents<MeshFilter>())Object.DestroyImmediate(mesh);
                foreach(var collider in root.GetComponents<Collider>())Object.DestroyImmediate(collider);
                var piece=root.GetComponent<Piece>();piece.m_name=title;piece.m_description=wood?"A wooden post carrying the Wayfarer's lantern.":"The Wayfarer's lantern suspended from a short, connected chain.";
                piece.m_icon=plugin.Visuals.Icon(asset);piece.m_category=Piece.PieceCategory.Furniture;piece.m_enabled=true;piece.m_craftingStation=null;piece.m_canBeRemoved=true;piece.m_canRotate=true;piece.m_comfort=0;
                piece.m_groundPiece=false;piece.m_groundOnly=false;piece.m_inCeilingOnly=!wood;piece.m_notOnFloor=!wood;piece.m_notOnWood=false;piece.m_noClipping=false;piece.m_spaceRequirement=0;piece.m_noInWater=true;
                var costs=new List<Piece.Requirement>{new Piece.Requirement{m_resItem=lantern.GetComponent<ItemDrop>(),m_amount=1,m_recover=true}};
                if(wood)costs.Add(new Piece.Requirement{m_resItem=wood.GetComponent<ItemDrop>(),m_amount=4,m_recover=true});piece.m_resources=costs.ToArray();
                var nodes=plugin.Visuals.Attach(asset,root.transform,root.layer,false);
                if(!nodes.TryGetValue("FlameSocket",out var socket))throw new InvalidOperationException("Source lantern flame socket missing.");
                // AttachCandle cancels the socket's inherited1.25 scale before
                // applying this requested global factor. Geometry is not scaled again.
                NativeCampLighting.AttachCandle(socket,1.25f);var flame=socket.Find("WF_Native_Resin_Flame");if(!flame)throw new InvalidOperationException("Native candle source did not attach.");flame.gameObject.SetActive(false);
                foreach(var filter in root.GetComponentsInChildren<MeshFilter>(true))
                {if(!filter.sharedMesh)continue;var collider=filter.gameObject.AddComponent<MeshCollider>();collider.sharedMesh=filter.sharedMesh;collider.convex=false;}
                var wear=root.GetComponent<WearNTear>();wear.m_new=null;wear.m_worn=null;wear.m_broken=null;wear.m_wet=null;wear.m_snow=null;wear.m_snowWorn=null;wear.m_snowBroken=null;wear.m_fragmentRoots=Array.Empty<GameObject>();wear.m_nonSolidRenderers=new List<Renderer>();wear.m_supports=false;wear.m_noSupportWear=true;
                var view=root.GetComponent<ZNetView>();view.m_persistent=true;view.m_syncInitialScale=false;
                var light=root.AddComponent<LanternWorldLight>();light.LightHost=flame;light.HoverOffset=root.transform.InverseTransformPoint(socket.position).y-.15f;
                if(!PieceManager.Instance.AddPiece(new CustomPiece(root,"Hammer",false)))throw new InvalidOperationException("Lantern Hammer entry registration failed.");
                root.SetActive(true);registered.Add(id);plugin.Report("LANTERN_BUILD_REGISTERED "+id+" source="+asset+" lanternCost=1 woodCost="+(wood?4:0)+" purchasedFuel=0");
            }
            catch{manager.DestroyPrefab(id);throw;}
        }
    }
}
