using System;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Collections.Generic;
using Newtonsoft.Json;
using HarmonyLib;

namespace Wayfarer.Items
{
    public static class CommerceInventory
    {
        public const string InstanceKey="twa_wf_instance";
        public static string Instance(ItemDrop.ItemData item)
        {if(!item.m_customData.TryGetValue(InstanceKey,out string id)){id=Guid.NewGuid().ToString("N");item.m_customData[InstanceKey]=id;}return id;}
        public static string Fingerprint(Inventory inventory,CommerceDefinitions definitions)
        {
            var rows=inventory.GetAllItems().Select(i=>new{item=definitions.ItemId(i),count=i.m_stack,quality=i.m_quality,durability=i.m_durability,x=i.m_gridPos.x,y=i.m_gridPos.y,instance=i.m_customData.TryGetValue(InstanceKey,out var id)?id:""}).OrderBy(i=>i.y).ThenBy(i=>i.x).ToArray();
            using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(rows)))).Replace("-","").ToLowerInvariant();
        }
        public static bool Apply(Player player,CommerceDefinitions definitions,CommerceTransaction plan,string expectedHash,out string error)
        {return Apply(player,definitions,plan,expectedHash,out error,out var rollback);}
        public static bool Apply(Player player,CommerceDefinitions definitions,CommerceTransaction plan,string expectedHash,out string error,out Action rollback)
        {
            error=null;rollback=null;var inventory=player.GetInventory();
            if(Fingerprint(inventory,definitions)!=expectedHash){error="Your inventory changed. Please try again.";return false;}
            if(!plan.Success||plan.inventory.Count>128){error="Invalid trade plan.";return false;}
            var original=inventory.GetAllItems().ToList();
            var stacks=original.ToDictionary(i=>i,i=>i.m_stack);
            var durability=original.ToDictionary(i=>i,i=>i.m_durability);
            var quality=original.ToDictionary(i=>i,i=>i.m_quality);
            var removedEquipped=new List<ItemDrop.ItemData>();
            void Restore()
            {
                var items=inventory.GetAllItems();items.Clear();items.AddRange(original);
                foreach(var i in original){i.m_stack=stacks[i];i.m_durability=durability[i];i.m_quality=quality[i];}
                Changed(inventory);foreach(var i in removedEquipped)player.EquipItem(i,false);
            }
            try
            {
                // Preflight on cloned objects: failed room/stack checks cannot
                // remove native items or invalidate another mod's equipment refs.
                var trial=new Inventory("Wayfarer trade preflight",null,inventory.GetWidth(),inventory.GetHeight());
                foreach(var item in original)if(!trial.AddItem(item.Clone(),item.m_gridPos))throw new InvalidOperationException("Unable to copy the current inventory for trade.");
                ApplyDeltas(trial,definitions,plan,false,null);
                foreach(var i in original.Where(i=>i.m_equipped))if(plan.inventory.Any(d=>d.quantity<0&&d.itemId==definitions.ItemId(i))&&(plan.operation!="version-exchange"||i.m_customData.TryGetValue(InstanceKey,out var selected)&&selected==plan.selectedInstanceId)){player.UnequipItem(i,false);removedEquipped.Add(i);}
                ApplyDeltas(inventory,definitions,plan,true,player);
                Changed(inventory);rollback=Restore;return true;
            }
            catch(Exception exception)
            {
                Restore();
                error=exception.Message;return false;
            }
        }
        static void ApplyDeltas(Inventory inventory,CommerceDefinitions definitions,CommerceTransaction plan,bool live,Player player)
        {
            foreach(var delta in plan.inventory.Where(d=>d.quantity<0))
            {
                long left=checked(-delta.quantity);
                var candidates=inventory.GetAllItems().Where(i=>definitions.ItemId(i)==delta.itemId).OrderBy(i=>i.m_customData.TryGetValue(InstanceKey,out var id)&&id==plan.selectedInstanceId?0:1).ToArray();
                if(plan.operation=="version-exchange"&&delta.itemId!=CommercePolicy.StrangeCoinId)candidates=candidates.Where(i=>i.m_customData.TryGetValue(InstanceKey,out var id)&&id==plan.selectedInstanceId).ToArray();
                foreach(var item in candidates){int take=(int)Math.Min(left,item.m_stack);if(take>0&&!inventory.RemoveItem(item,take))throw new InvalidOperationException("The selected items could not be removed.");left-=take;if(left==0)break;}
                if(left!=0)throw new InvalidOperationException("You no longer carry the requested items.");
            }
            foreach(var delta in plan.inventory.Where(d=>d.quantity>0))
            {
                var prefab=definitions.Prefab(delta.itemId);var drop=prefab?prefab.GetComponent<ItemDrop>():null;
                if(!drop||delta.quantity>1000000)throw new InvalidOperationException("The requested item is not ready.");
                long left=delta.quantity;
                while(left>0)
                {
                    var item=drop.m_itemData.Clone();item.m_dropPrefab=prefab;item.m_quality=delta.quality;item.m_stack=(int)Math.Min(left,item.m_shared.m_maxStackSize);item.m_durability=item.GetMaxDurability();
                    if(item.m_shared.m_maxStackSize==1)Instance(item);
                    int amount=item.m_stack;if(!inventory.AddItem(item))throw new InvalidOperationException("Make room in your inventory first.");left-=amount;
                }
            }
            if(plan.selectedInstanceQualityAfter>0)
            {
                var selected=inventory.GetAllItems().SingleOrDefault(i=>i.m_customData.TryGetValue(InstanceKey,out var id)&&id==plan.selectedInstanceId);
                if(selected==null)throw new InvalidOperationException("The selected equipment item is missing.");
                selected.m_quality=plan.selectedInstanceQualityAfter;if(plan.fullyRepairSelectedInstance)selected.m_durability=selected.GetMaxDurability();
            }
            if((plan.operation=="repair-kit"||plan.operation=="merchant-repair")&&plan.fullyRepairSelectedInstance)
            {
                var selected=inventory.GetAllItems().SingleOrDefault(i=>i.m_customData.TryGetValue(InstanceKey,out var id)&&id==plan.selectedInstanceId);
                if(selected==null)throw new InvalidOperationException("The selected equipment item is missing.");selected.m_durability=selected.GetMaxDurability();
            }
        }
        static void Changed(Inventory inventory)=>AccessTools.Method(typeof(Inventory),"Changed",new[]{typeof(bool),typeof(bool)}).Invoke(inventory,new object[]{true,false});
    }
}
