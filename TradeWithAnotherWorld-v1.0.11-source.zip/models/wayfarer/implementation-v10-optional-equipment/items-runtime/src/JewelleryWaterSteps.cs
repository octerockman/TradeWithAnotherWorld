using System;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    public sealed class JewelleryWaterSteps:MonoBehaviour
    {
        static readonly FieldInfo water=AccessTools.Field(typeof(Character),"m_waterLevel"),feetField=AccessTools.Field(typeof(FootStep),"m_feet");
        Player player;BoxCollider support;Transform[] feet;Transform lastFoot;int lastFrame=-1;float surface;
        public static void Ensure(Player p){if(p&&!p.GetComponent<JewelleryWaterSteps>())p.gameObject.AddComponent<JewelleryWaterSteps>();}
        void Awake()
        {
            player=GetComponent<Player>();var steps=GetComponentInChildren<FootStep>();feet=steps?feetField.GetValue(steps) as Transform[]:null;
            var go=new GameObject("Siltwalker Local Foot Support");go.layer=LayerMask.NameToLayer("piece");support=go.AddComponent<BoxCollider>();support.size=new Vector3(.7f,.06f,.7f);support.enabled=false;
        }
        void OnDestroy(){if(support)Destroy(support.gameObject);}
        void OnDisable(){if(support)support.enabled=false;}
        bool SolidUnder(Transform foot)
        {
            if(!foot)return false;
            foreach(var hit in Physics.RaycastAll(foot.position+Vector3.up*.08f,Vector3.down,.28f,Physics.DefaultRaycastLayers,QueryTriggerInteraction.Ignore))
                if(hit.collider&&hit.collider!=support&&!hit.collider.transform.IsChildOf(player.transform)&&!hit.collider.GetComponentInParent<Character>()&&hit.normal.y>.5f)return true;
            return false;
        }
        void FixedUpdate()
        {
            if(!support)return;support.enabled=false;if(!JewelleryRuntime.Active||player!=Player.m_localPlayer||player.IsDead())return;
            var state=JewelleryRuntime.State(player);if(state==null)return;
            // Both actual foot bones must independently touch a non-water,
            // non-character solid. Our temporary support is explicitly excluded.
            if(feet?.Length>=2&&SolidUnder(feet[0])&&SolidUnder(feet[1]))
            {
                if(state.waterStepsRemaining!=4){state.waterStepsRemaining=4;JewelleryRuntime.Save();}lastFoot=null;return;
            }
            if(state.waterStepsRemaining<=0||!JewelleryRuntime.For(player).Has("sd_siltwalker_loop"))return;
            surface=(float)water.GetValue(player);var body=player.GetComponent<Collider>();
            if(surface< -1000||!body||body.bounds.min.y<surface-.12f||player.IsSwimming())return;
            // The platform is local to the authoritative player and has no mesh,
            // item, ZDO, saved terrain edit or shared world persistence.
            support.transform.position=new Vector3(player.transform.position.x,surface-.03f,player.transform.position.z);support.enabled=true;
            foreach(var actor in Character.GetAllCharacters())if(actor&&actor!=player)
                foreach(var collider in actor.GetComponentsInChildren<Collider>())if(collider)Physics.IgnoreCollision(support,collider,true);
        }
        public void Footfall(Transform foot)
        {
            if(player!=Player.m_localPlayer||!support||!support.enabled||!foot||foot==lastFoot||lastFrame==Time.frameCount||player.InDodge()||player.InAttack()||player.IsSwimming()||!player.IsOnGround())return;
            var velocity=player.GetVelocity();velocity.y=0;if(velocity.sqrMagnitude<.0025f||Math.Abs(foot.position.y-surface)>.22f)return;
            var state=JewelleryRuntime.State(player);if(state==null||state.waterStepsRemaining<=0)return;
            lastFrame=Time.frameCount;lastFoot=foot;state.waterStepsRemaining--;JewelleryRuntime.Save();
            if(state.waterStepsRemaining==0)support.enabled=false;
        }
    }
    [HarmonyPatch(typeof(FootStep),"OnFoot",new[]{typeof(Transform)})]
    static class JewelleryActualWaterFootfalls
    {static void Postfix(FootStep __instance,Transform __0){var p=__instance.GetComponentInParent<Player>();if(p==Player.m_localPlayer)p?.GetComponent<JewelleryWaterSteps>()?.Footfall(__0);}}
}
