using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using HarmonyLib;
using Newtonsoft.Json.Linq;
using UnityEngine;
using UnityEngine.Rendering;
using Object=UnityEngine.Object;
using Wayfarer.InGame;
namespace Wayfarer.Items
{
    public sealed class OffhandPropNode{public int id,parentId;public string name;public float[] position,rotation,scale;}
    public sealed class OffhandPropWeight{public int[] indices;public float[] weights;}
    public sealed class OffhandPropRenderer{public float[] vertices,normals,uv;public int[] triangles,boneNodeIds;public MatrixRecord[] bindposes;public OffhandPropWeight[] weights;}
    public sealed class OffhandPropPayload{public string schema;public OffhandPropNode[] nodes;public OffhandPropRenderer[] renderers;}
    public static class OffhandPoseMount
    {
        internal static readonly System.Reflection.FieldInfo LeftInstance=AccessTools.Field(typeof(VisEquipment),"m_leftItemInstance");
        static OffhandPropPayload prop;static Mesh mesh;
        internal static Quaternion Rotation(string family)=>Quaternion.AngleAxis(family=="censer"?-90:90,Vector3.right);
        internal static string Family(string id)=>id=="sundered_bell"||id=="consecrated_handbell"?"bell":id=="unsundered_flame"?"torch":id=="restored_censer"?"censer":null;
        public static Transform GetSocket(Player p,string name)
        {
            if(!p||p.IsDead())return null;var d=p.GetComponent<OffhandPoseMountDriver>()??p.gameObject.AddComponent<OffhandPoseMountDriver>();d.Player=p;
            try{d.EnsureMount();return d.Socket(name);}catch(Exception e){OffhandPose.Warn("OFFHAND_MOUNT_NOT_READY "+e.Message);return null;}
        }
        internal static OffhandPropPayload LoadProp()
        {
            if(prop!=null)return prop;var plugin=ItemsPlugin.Instance;if(!plugin)throw new InvalidOperationException("Item module unavailable.");string folder=Path.Combine(plugin.DataDirectory,"assets","motions","offhand");var m=RuntimeCatalogue.ReadJson(Path.Combine(folder,"manifest.json"),1024*1024);var rec=m["censerProp"]??throw new InvalidDataException("Original censer prop manifest missing.");string path=PayloadReader.Safe(folder,rec.Value<string>("path"));if(PayloadReader.Hash(path)!=rec.Value<string>("sha256"))throw new InvalidDataException("Original censer prop checksum changed.");var p=PayloadReader.Read<OffhandPropPayload>(path);var r=p?.renderers?.SingleOrDefault();
            if(p?.schema!="wayfarer.item-visual.v1"||p.nodes?.Length!=7||p.nodes.Select(n=>n.id).Distinct().Count()!=7||r==null||r.vertices?.Length!=26991||r.normals?.Length!=r.vertices.Length||r.uv?.Length!=17994||r.triangles?.Length!=8997||r.weights?.Length!=8997||r.bindposes?.Length!=3||!r.boneNodeIds.SequenceEqual(new[]{1,2,3}))throw new InvalidDataException("Original three-bone censer source contract changed.");
            foreach(var n in p.nodes){if(n.id<0||n.id>=7||n.parentId>=n.id||n.parentId<-1)throw new InvalidDataException("Censer hierarchy changed.");PayloadReader.V(n.position);PayloadReader.Q(n.rotation);PayloadReader.V(n.scale);}
            if(!p.nodes.Select(n=>n.name).SequenceEqual(new[]{"OffhandCenserRoot","Grip","Gravity","Swing","Smoke","Ember","Impact"}))throw new InvalidDataException("Censer source sockets changed.");
            if(r.vertices.Concat(r.normals).Concat(r.uv).Any(x=>!PayloadReader.Finite(x))||r.triangles.Any(i=>i<0||i>=8997))throw new InvalidDataException("Invalid censer source geometry.");
            foreach(var w in r.weights)if(w.indices?.Length!=4||w.weights?.Length!=4||w.indices.Any(i=>i<0||i>2)||w.weights.Any(x=>!PayloadReader.Finite(x)||x<0)||Math.Abs(w.weights.Sum()-1)>.0001f)throw new InvalidDataException("Invalid original censer weights.");
            foreach(var b in r.bindposes)PayloadReader.M(b);prop=p;return p;
        }
        internal static Mesh CenserMesh()
        {
            if(mesh)return mesh;var r=LoadProp().renderers[0];var v=new Vector3[8997];var n=new Vector3[v.Length];var uv=new Vector2[v.Length];var colors=new Color32[v.Length];for(int i=0;i<v.Length;i++){v[i]=new Vector3(r.vertices[i*3],r.vertices[i*3+1],r.vertices[i*3+2]);n[i]=new Vector3(r.normals[i*3],r.normals[i*3+1],r.normals[i*3+2]);uv[i]=new Vector2(r.uv[i*2],r.uv[i*2+1]);colors[i]=new Color32(255,255,255,255);}
            mesh=new Mesh{name="WF_OffhandCenser_SourceSkin",indexFormat=IndexFormat.UInt16,vertices=v,normals=n,uv=uv,colors32=colors,triangles=r.triangles,bindposes=r.bindposes.Select(PayloadReader.M).ToArray(),boneWeights=r.weights.Select(w=>new BoneWeight{boneIndex0=w.indices[0],boneIndex1=w.indices[1],boneIndex2=w.indices[2],boneIndex3=w.indices[3],weight0=w.weights[0],weight1=w.weights[1],weight2=w.weights[2],weight3=w.weights[3]}).ToArray()};mesh.RecalculateBounds();mesh.RecalculateTangents();return mesh;
        }
        internal static void Dispose(){if(mesh)Object.Destroy(mesh);mesh=null;prop=null;}
    }
    // Left-only ready layer: the native animator retains locomotion, torso and mainhand.
    [DefaultExecutionOrder(7900)]
    public sealed class OffhandReadyPose:MonoBehaviour
    {
        public Player Player;Transform[] bones;OilRuntimePose[] ready;string family;float blend;
        void LateUpdate()
        {
            var mount=GetComponent<OffhandPoseMountDriver>();if(!Player||Player.IsDead()||!mount||mount.Family==null||!mount.Visible||OilMotion.IsBusy(Player)||OffhandPose.IsBusy(Player)||Player.InDodge()||Player.InAttack()){blend=0;return;}
            try
            {
                if(bones==null||family!=mount.Family){var p=OffhandPose.Load();bones=OffhandPose.Bind(Player,p);family=mount.Family;ready=p.ready[family].Select(OffhandPose.From).ToArray();blend=0;}
                blend=Mathf.MoveTowards(blend,1,Time.deltaTime/.15f);for(int i=0;i<bones.Length;i++)if(bones[i]&&bones[i].name.StartsWith("Left",StringComparison.Ordinal)&&!bones[i].name.Contains("Leg")&&!bones[i].name.Contains("Foot")&&!bones[i].name.Contains("Toe")){var value=OffhandPoseDriver.Mix(OffhandPoseDriver.Capture(bones[i]),ready[i],Mathf.SmoothStep(0,1,blend));bones[i].localPosition=value.position;bones[i].localRotation=value.rotation;bones[i].localScale=value.scale;}
            }
            catch(Exception e){OffhandPose.Warn("OFFHAND_READY_REFUSED "+e.Message);}
        }
    }
    [DefaultExecutionOrder(8200)]
    public sealed class OffhandPoseMountDriver:MonoBehaviour
    {
        public Player Player;public string Family{get;private set;}public bool Visible=>current&&current.activeInHierarchy;
        VisEquipment visual;GameObject current,hiddenVisual;bool priorActive;Transform calibrated,propRoot;Vector3 oldPosition;Quaternion oldRotation;string asset;
        readonly Dictionary<string,Transform> sockets=new Dictionary<string,Transform>(StringComparer.Ordinal);
        Transform gravity,swing,clapper;Quaternion clapperRest;Vector3 direction=Vector3.down,velocity,lastPosition,lastMotionVelocity;bool initialized;long propStamp;Quaternion propEntryGravity,propEntrySwing;
        internal void EnsureMount()
        {
            if(!Player)Player=GetComponent<Player>();if(!Player)return;visual=Player.GetComponent<VisEquipment>()??Player.GetComponentInChildren<VisEquipment>(true);var next=visual?OffhandPoseMount.LeftInstance.GetValue(visual) as GameObject:null;
            if(current==next&&sockets.Count>0)return;if(next!=current)Clear();if(!next)return;
            var marker=next.GetComponentInChildren<RegistryVisualMount>(true);string id=marker?marker.AssetId:null;string family=OffhandPoseMount.Family(id);if(family==null)return;
            var root=next.GetComponentsInChildren<Transform>(true).FirstOrDefault(t=>t.name=="WayfarerItemVisual_"+id);if(!root)return;
            current=next;asset=id;Family=family;var ready=GetComponent<OffhandReadyPose>()??gameObject.AddComponent<OffhandReadyPose>();ready.Player=Player;
            if(family=="censer")BuildCenser(root);
            else
            {
                calibrated=root;oldPosition=root.localPosition;oldRotation=root.localRotation;var q=OffhandPoseMount.Rotation(family);root.localPosition=q*oldPosition;root.localRotation=q*oldRotation;
                foreach(var t in root.GetComponentsInChildren<Transform>(true))
                {
                    if(t.name.EndsWith("Grip",StringComparison.Ordinal))sockets["Grip"]=t;
                    if(t.name.EndsWith("FlameSocket",StringComparison.Ordinal)){sockets["Flame"]=t;sockets["FlameSocket"]=t;sockets["Impact"]=t;}
                    if(t.name.EndsWith("MouthContact",StringComparison.Ordinal)){sockets["Impact"]=t;sockets["Mouth"]=t;}
                    if(t.name.EndsWith("__Clapper",StringComparison.Ordinal)){clapper=t;clapperRest=t.localRotation;}
                }
            }
            if(!sockets.ContainsKey("Grip")){Clear();throw new InvalidDataException("Authored held grip not found.");}
        }
        void BuildCenser(Transform original)
        {
            var p=OffhandPoseMount.LoadProp();var renderer=original.GetComponentInChildren<MeshRenderer>(true);if(!renderer||renderer.sharedMaterials.Length!=1)throw new InvalidDataException("Admitted censer mapped material missing.");var root=new GameObject("WF_EquippedCenser_OriginalThreeBone").transform;root.SetParent(original.parent,false);root.localRotation=OffhandPoseMount.Rotation("censer");root.gameObject.layer=current.layer;var nodes=new Transform[7];nodes[0]=root;
            try
            {
                for(int i=1;i<7;i++){var n=p.nodes[i];var t=new GameObject(n.name).transform;t.SetParent(nodes[n.parentId],false);t.localPosition=PayloadReader.V(n.position);t.localRotation=PayloadReader.Q(n.rotation);t.localScale=PayloadReader.V(n.scale);t.gameObject.layer=current.layer;nodes[i]=t;}
                var skin=root.gameObject.AddComponent<SkinnedMeshRenderer>();skin.sharedMesh=OffhandPoseMount.CenserMesh();skin.sharedMaterials=renderer.sharedMaterials;skin.bones=new[]{nodes[1],nodes[2],nodes[3]};skin.rootBone=nodes[1];skin.updateWhenOffscreen=true;skin.quality=SkinQuality.Bone4;skin.localBounds=new Bounds(new Vector3(0,.22f,0),Vector3.one*1.2f);skin.shadowCastingMode=ShadowCastingMode.On;skin.receiveShadows=true;
                propRoot=root;gravity=nodes[2];swing=nodes[3];foreach(int i in new[]{1,4,5,6})sockets[p.nodes[i].name]=nodes[i];hiddenVisual=original.gameObject;priorActive=hiddenVisual.activeSelf;hiddenVisual.SetActive(false);direction=Vector3.down;velocity=Vector3.zero;lastPosition=gravity.position;lastMotionVelocity=Vector3.zero;initialized=false;
            }
            catch{Object.Destroy(root.gameObject);throw;}
        }
        internal Transform Socket(string name)=>Visible&&name!=null&&sockets.TryGetValue(name,out var t)?t:null;
        void LateUpdate()
        {
            try
            {
                EnsureMount();if(!current||!Visible)return;var pose=GetComponent<OffhandPoseDriver>();
                if(gravity&&swing)
                {
                    if(pose&&pose.Active&&pose.Clip.propFrames!=null){OffhandPose.Sample(pose.Clip,pose.Elapsed,out int a,out int b,out float t);if(propStamp!=pose.Stamp){propStamp=pose.Stamp;propEntryGravity=gravity.localRotation;propEntrySwing=swing.localRotation;}float entryBlend=Mathf.SmoothStep(0,1,pose.EntryAge/.12f);gravity.localRotation=Quaternion.Slerp(propEntryGravity,Quaternion.Slerp(PayloadReader.Q(pose.Clip.propFrames[a].Gravity),PayloadReader.Q(pose.Clip.propFrames[b].Gravity),t),entryBlend);swing.localRotation=Quaternion.Slerp(propEntrySwing,Quaternion.Slerp(PayloadReader.Q(pose.Clip.propFrames[a].Swing),PayloadReader.Q(pose.Clip.propFrames[b].Swing),t),entryBlend);direction=(swing.rotation*Vector3.up).normalized;velocity=Vector3.zero;initialized=false;}
                    else{propStamp=0;StepPendulum();}
                }
                if(clapper){float phase=pose&&pose.Active&&pose.Clip.family=="bell"?Mathf.Sin(pose.Elapsed*2*Mathf.PI/pose.Clip.duration*2)*18:0;clapper.localRotation=clapperRest*Quaternion.AngleAxis(phase,Vector3.right);}
                pose?.DispatchAfterSockets();
            }
            catch(Exception e){OffhandPose.Warn("OFFHAND_MOUNT_FAILED "+e.Message);GetComponent<OffhandPoseDriver>()?.StopMotion();Clear();}
        }
        void StepPendulum()
        {
            float dt=Mathf.Min(Time.deltaTime,.05f);if(dt<=0)return;Vector3 pos=gravity.position;if(!initialized){lastPosition=pos;lastMotionVelocity=Vector3.zero;initialized=true;}Vector3 moveVelocity=(pos-lastPosition)/dt;Vector3 acceleration=(moveVelocity-lastMotionVelocity)/dt;lastPosition=pos;lastMotionVelocity=moveVelocity;acceleration=Vector3.ClampMagnitude(acceleration,18);velocity+=Vector3.ProjectOnPlane(Vector3.down*18-acceleration*1.1f,direction)*dt;velocity*=Mathf.Exp(-2.2f*dt);direction=(direction+velocity*dt).normalized;if(Vector3.Angle(Vector3.down,direction)>65)direction=Vector3.RotateTowards(Vector3.down,direction,65*Mathf.Deg2Rad,0);gravity.rotation=Quaternion.FromToRotation(Vector3.up,Vector3.down);swing.rotation=Quaternion.FromToRotation(Vector3.up,direction);
        }
        void Clear(){if(hiddenVisual)hiddenVisual.SetActive(priorActive);if(calibrated){calibrated.localPosition=oldPosition;calibrated.localRotation=oldRotation;}if(propRoot)Object.Destroy(propRoot.gameObject);sockets.Clear();current=null;hiddenVisual=null;calibrated=null;propRoot=null;gravity=null;swing=null;clapper=null;Family=null;asset=null;}
        void OnDisable(){Clear();}
        void OnDestroy(){Clear();var ready=GetComponent<OffhandReadyPose>();if(ready)Object.Destroy(ready);}
    }
}
