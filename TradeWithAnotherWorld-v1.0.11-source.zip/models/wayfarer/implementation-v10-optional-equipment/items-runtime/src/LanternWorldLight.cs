using System;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using UnityEngine;

namespace Wayfarer.Items
{
    // Only the two new player-built prefabs carry this component. Camp lamps,
    // camp fire and OctoPack lanterns never enter this fuel/interaction route.
    public sealed class LanternWorldLight:MonoBehaviour,Hoverable,Interactable
    {
        const string FuelKey="wf_built_lantern_fuel_v1",AddRPC="WF_LanternAddFuel",ToggleRPC="WF_LanternToggle",AckRPC="WF_LanternAck";
        public Transform LightHost;
        public float HoverOffset;
        ZNetView view;
        LanternFuelState state;
        string lastRaw;
        bool wasOwner;
        float nextTick,nextSave,nextWarning;
        Pending pending;
        sealed class Pending {public string Request;public int Kind;public Player User;public ItemDrop.ItemData Reserved;public float LastSend;}
        static double WorldNow=>ZNet.instance?Math.Max(0,ZNet.instance.GetTimeSeconds()):0;
        void Awake()
        {
            view=GetComponent<ZNetView>();SetLight(false);
            if(!view||!view.IsValid())return;
            view.Register<string,int>(AddRPC,RPC_AddFuel);view.Register<string>(ToggleRPC,RPC_Toggle);view.Register<string,int,bool>(AckRPC,RPC_Ack);
            var wear=GetComponent<WearNTear>();if(wear)wear.m_onDestroyed+=OnPieceDestroyed;
        }
        LanternFuelState ReadState(bool force=false)
        {
            if(!view||!view.IsValid())throw new InvalidOperationException("Lantern network state unavailable.");
            string raw=view.GetZDO().GetString(FuelKey,"");
            if(force||state==null||lastRaw!=raw)
            {
                if(raw.Length>16384)throw new InvalidDataException("Lantern fuel record exceeds its bound.");
                state=string.IsNullOrEmpty(raw)?new LanternFuelState{worldAt=WorldNow}:JsonConvert.DeserializeObject<LanternFuelState>(raw,new JsonSerializerSettings{MaxDepth=8,DateParseHandling=DateParseHandling.None,MissingMemberHandling=MissingMemberHandling.Error});
                if(!LanternFuelPolicy.Valid(state))throw new InvalidDataException("Invalid lantern fuel record.");
                lastRaw=raw;
            }
            LanternFuelPolicy.Advance(state,WorldNow);return state;
        }
        void Save()
        {
            if(!view||!view.IsValid()||!view.IsOwner()||!ZNet.instance||!LanternFuelPolicy.Valid(state))return;
            LanternFuelPolicy.Advance(state,WorldNow);lastRaw=JsonConvert.SerializeObject(state);view.GetZDO().Set(FuelKey,lastRaw);nextSave=Time.unscaledTime+30;
        }
        void Update()
        {
            if(Time.unscaledTime<nextTick)return;nextTick=Time.unscaledTime+.25f;
            if(!view||!view.IsValid()||!ZNet.instance){SetLight(false);return;}
            try
            {
                bool owner=view.IsOwner();var current=ReadState(owner!=wasOwner);wasOwner=owner;
                if(owner&&Time.unscaledTime>=nextSave)Save();SetLight(current.Burning);
                if(pending!=null&&LanternFuelPolicy.TryReceipt(current,pending.Request,pending.Kind,out bool committed))
                {var resolved=pending;pending=null;if(!committed)Refund(resolved);}
                if(pending!=null&&Time.unscaledTime-pending.LastSend>=2)
                {pending.LastSend=Time.unscaledTime;view.InvokeRPC(AddRPC,pending.Request,pending.Kind);}
            }
            catch(Exception e){SetLight(false);if(Time.unscaledTime>=nextWarning){nextWarning=Time.unscaledTime+10;ItemsPlugin.Instance?.Warn("BUILT_LANTERN_STATE_FAILED "+e.Message);}}
        }
        void SetLight(bool burning)
        {
            if(!LightHost||LightHost.gameObject.activeSelf==burning)return;
            LightHost.gameObject.SetActive(burning);
            if(burning)foreach(var particles in LightHost.GetComponentsInChildren<ParticleSystem>(true))particles.Play(true);
        }
        bool SenderNear(long sender)
        {
            foreach(var player in Player.GetAllPlayers())
            {
                if(!player)continue;var network=player.GetComponent<ZNetView>();
                if(network&&network.IsValid()&&network.GetZDO().GetOwner()==sender&&Vector3.Distance(player.transform.position,transform.position)<=6)return true;
            }
            // A dedicated owner can authenticate the peer even when it has no
            // local rendered player object. Clients use the nearby player ZDO.
            if(ZNet.instance&&ZNet.instance.IsServer())
            {var peer=ZNet.instance.GetPeer(sender);if(peer!=null&&!peer.m_characterID.IsNone()&&Vector3.Distance(peer.GetRefPos(),transform.position)<=8)return true;}
            return false;
        }
        void Reply(long target,string request,int kind,bool accepted)=>view.InvokeRPC(target,AckRPC,request,kind,accepted);
        void RPC_AddFuel(long sender,string request,int kind)
        {
            if(!view||!view.IsValid()||!view.IsOwner()||!LanternFuelPolicy.ValidRequest(request)||LanternFuelPolicy.Duration(kind)<=0)return;
            try
            {
                var current=ReadState(!wasOwner);wasOwner=true;
                if(LanternFuelPolicy.TryReceipt(current,request,kind,out bool prior)){Reply(sender,request,kind,prior);return;}
                bool accepted=SenderNear(sender)&&LanternFuelPolicy.Add(current,kind,WorldNow);
                LanternFuelPolicy.Remember(current,request,kind,accepted);Save();SetLight(current.Burning);Reply(sender,request,kind,accepted);
            }
            catch(Exception e){ItemsPlugin.Instance?.Warn("BUILT_LANTERN_FUEL_FAILED "+e.Message);Reply(sender,request,kind,false);}
        }
        void RPC_Toggle(long sender,string request)
        {
            if(!view||!view.IsValid()||!view.IsOwner()||!LanternFuelPolicy.ValidRequest(request))return;
            try
            {
                var current=ReadState(!wasOwner);wasOwner=true;
                if(LanternFuelPolicy.TryReceipt(current,request,0,out _))return;
                bool accepted=SenderNear(sender)&&current.charges.Count>0;
                if(accepted)LanternFuelPolicy.Toggle(current,WorldNow);
                LanternFuelPolicy.Remember(current,request,0,accepted);Save();SetLight(current.Burning);
            }
            catch(Exception e){ItemsPlugin.Instance?.Warn("BUILT_LANTERN_TOGGLE_FAILED "+e.Message);}
        }
        void RPC_Ack(long sender,string request,int kind,bool accepted)
        {
            if(pending==null||pending.Request!=request||pending.Kind!=kind||!view||!view.IsValid()||sender!=view.GetZDO().GetOwner())return;
            var done=pending;pending=null;if(!accepted)Refund(done);
        }
        static void Refund(Pending reservation)
        {
            if(!reservation.User||reservation.Reserved==null)return;
            var inventory=reservation.User.GetInventory();
            if(!inventory.AddItem(reservation.Reserved))ItemDrop.DropItem(reservation.Reserved,1,reservation.User.transform.position+Vector3.up,Quaternion.identity);
        }
        void OnPieceDestroyed()
        {
            // An actually dismantled/destroyed piece cannot retain a committed
            // fuel charge. An unresolved local reservation can be returned.
            var reserved=pending;pending=null;if(reserved!=null)Refund(reserved);
        }
        public bool UseItem(Humanoid user,ItemDrop.ItemData item)
        {
            if(!user||user!=Player.m_localPlayer||item==null||!view||!view.IsValid())return false;
            string prefab=item.m_dropPrefab?item.m_dropPrefab.name:"";
            int kind=prefab=="Resin"?LanternFuelPolicy.OrdinaryResin:prefab=="TWA_WF_refined_resin"?LanternFuelPolicy.RefinedResin:0;
            if(kind==0)return false;
            if(pending!=null){user.Message(MessageHud.MessageType.Center,"Adding fuel…");return true;}
            try
            {
                if(ReadState().charges.Count>=LanternFuelPolicy.Capacity){user.Message(MessageHud.MessageType.Center,"The lantern is full.");return true;}
                var inventory=user.GetInventory();var reserve=item.Clone();reserve.m_stack=1;reserve.m_equipped=false;
                if(!inventory.RemoveItem(item,1))return true;
                pending=new Pending{Request=Guid.NewGuid().ToString("N"),Kind=kind,User=(Player)user,Reserved=reserve,LastSend=Time.unscaledTime};
                view.InvokeRPC(AddRPC,pending.Request,kind);return true;
            }
            // A send exception does not prove the owner failed to commit.
            // Keep that reservation and retry its same request ID; an owner
            // receipt/ack either commits it or explicitly refunds it once.
            catch(Exception e){ItemsPlugin.Instance?.Warn("BUILT_LANTERN_USE_FAILED "+e.Message);return true;}
        }
        public bool Interact(Humanoid user,bool hold,bool alt)
        {
            if(hold||!user||user!=Player.m_localPlayer||!view||!view.IsValid())return false;
            try
            {if(ReadState().charges.Count==0){user.Message(MessageHud.MessageType.Center,"Add resin to light the lantern.");return true;}view.InvokeRPC(ToggleRPC,Guid.NewGuid().ToString("N"));return true;}
            catch(Exception e){ItemsPlugin.Instance?.Warn("BUILT_LANTERN_INTERACT_FAILED "+e.Message);return false;}
        }
        public string GetHoverName()=>"Wayfarer's Lantern";
        public float GetHoverOffset()=>HoverOffset;
        public string GetHoverText()
        {
            try
            {
                var current=ReadState();var time=TimeSpan.FromSeconds(current.RemainingSeconds);
                string status=current.charges.Count==0?"Empty":(current.enabled?"Lit":"Off")+" · "+(int)time.TotalHours+"h "+time.Minutes+"m remaining";
                string toggle=current.charges.Count==0?"":"\n[<color=yellow><b>$KEY_Use</b></color>] "+(current.enabled?"Turn off":"Light");
                return Localization.instance.Localize(GetHoverName()+"\n"+status+" · Fuel "+current.charges.Count+"/30"+toggle+"\nUse Resin or Refined Lantern Resin to add fuel.");
            }
            catch{return GetHoverName();}
        }
        void OnDestroy(){if(view&&view.IsValid()&&view.IsOwner())Save();}
    }
}
