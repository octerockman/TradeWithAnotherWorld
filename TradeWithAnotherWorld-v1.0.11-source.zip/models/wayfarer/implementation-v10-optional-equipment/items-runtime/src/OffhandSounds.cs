using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Linq;
using UnityEngine;
namespace Wayfarer.Items
{
    public static class OffhandSounds
    {
        static readonly Dictionary<string,AudioClip> clips=new Dictionary<string,AudioClip>(StringComparer.Ordinal);
        static AudioClip Load(string id)
        {
            if(clips.TryGetValue(id,out var clip))return clip;
            string folder=Path.Combine(ItemsPlugin.Instance.DataDirectory,"assets","sounds");var manifest=RuntimeCatalogue.ReadJson(Path.Combine(folder,"manifest.json"),65536);
            JObject record=null;foreach(var r in (JArray)manifest["clips"])if(r.Value<string>("id")==id){record=(JObject)r;break;}if(record==null)throw new InvalidDataException("Missing handbell sound.");
            string path=Wayfarer.InGame.PayloadReader.Safe(folder,record.Value<string>("path"));if(RuntimeCatalogue.FileHash(path)!=record.Value<string>("sha256"))throw new InvalidDataException("Handbell audio checksum changed.");
            byte[] data=File.ReadAllBytes(path);if(data.Length<44||data.Length>256000||BitConverter.ToInt16(data,20)!=1||BitConverter.ToInt16(data,22)!=1||BitConverter.ToInt16(data,34)!=16||BitConverter.ToInt32(data,24)!=22050)throw new InvalidDataException("Handbell PCM contract changed.");int frames=(data.Length-44)/2;if(frames!=record.Value<int>("frames"))throw new InvalidDataException("Handbell sample count changed.");var values=new float[frames];for(int i=0;i<frames;i++)values[i]=BitConverter.ToInt16(data,44+i*2)/32768f;clip=AudioClip.Create("Wayfarer original "+id,frames,1,22050,false);clip.SetData(values,0);clips[id]=clip;return clip;
        }
        public static void Play(string id,Vector3 position)
        {
            try{var clip=Load(id);var go=new GameObject("Wayfarer handbell sound");go.transform.position=position;var audio=go.AddComponent<AudioSource>();audio.clip=clip;audio.outputAudioMixerGroup=Resources.FindObjectsOfTypeAll<UnityEngine.Audio.AudioMixerGroup>().FirstOrDefault(g=>g&&g.name.Equals("SFX",StringComparison.OrdinalIgnoreCase));audio.spatialBlend=1;audio.rolloffMode=AudioRolloffMode.Linear;audio.minDistance=2;audio.maxDistance=25;audio.volume=.45f;audio.dopplerLevel=0;audio.Play();UnityEngine.Object.Destroy(go,clip.length+.2f);}catch(Exception e){ItemsPlugin.Instance?.Warn("HANDBELL_AUDIO_UNAVAILABLE "+e.Message);}
        }
    }
}
