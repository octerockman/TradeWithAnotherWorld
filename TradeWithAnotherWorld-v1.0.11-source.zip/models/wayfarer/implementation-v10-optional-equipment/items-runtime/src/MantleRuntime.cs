using System;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using Object=UnityEngine.Object;

namespace Wayfarer.Items
{
    public static class MantleRuntime
    {
        static readonly FieldInfo utility=AccessTools.Field(typeof(Humanoid),"m_utilityItem");
        static readonly FieldInfo smokeMask=AccessTools.Field(typeof(Character),"s_smokeRayMask");
        static Player exposurePlayer;static float cloudObservedAt=float.NegativeInfinity;
        public static ItemDrop.ItemData Worn(Player player)
        {
            var item=player?utility?.GetValue(player) as ItemDrop.ItemData:null;
            return item?.m_customData!=null&&item.m_customData.TryGetValue("wayfarer:item",out string id)&&id==MantleSkin.ItemId?item:null;
        }
        static bool OwnedAlive(Player p)
        {var view=p?p.GetComponent<ZNetView>():null;return p&&p==Player.m_localPlayer&&!p.IsDead()&&view&&view.IsValid()&&view.IsOwner();}
        public static void ObserveCloud(Player player)
        {if(!OwnedAlive(player))return;if(exposurePlayer!=player){exposurePlayer=player;cloudObservedAt=float.NegativeInfinity;}cloudObservedAt=Time.time;}
        static bool NativeSmoke(Player player)
        {
            if(player.m_tolerateSmoke||smokeMask==null)return false;
            int mask=(int)smokeMask.GetValue(null);
            // Exact installed Character.UpdateSmoke query, checked every active
            // frame so lingering status duration does not delay clean-air recovery.
            return Physics.CheckSphere(player.GetTopPoint()+Vector3.up*.1f,.5f,mask);
        }
        public static bool InSmoke(Player player)=>NativeSmoke(player)||(exposurePlayer==player&&Time.time-cloudObservedAt<=Mathf.Max(.001f,Time.deltaTime*1.5f));
        public static bool Protects(Player player)
        {var item=Worn(player);return OwnedAlive(player)&&item!=null&&MantlePolicy.Read(item.m_customData)>0;}
        public static void Tick(Player player,float dt)
        {
            if(!OwnedAlive(player))return;var item=Worn(player);if(item==null)return;
            float before=MantlePolicy.Read(item.m_customData),after=MantlePolicy.Step(before,dt,true,true,InSmoke(player));
            MantlePolicy.Write(item.m_customData,after);
        }
        public static void ApplyRegisteredStats(ItemRegistry registry)
        {
            if(!registry.TryPrefab(MantleSkin.ItemId,out var prefab)||!prefab)return;
            var s=prefab.GetComponent<ItemDrop>().m_itemData.m_shared;
            s.m_itemType=ItemDrop.ItemData.ItemType.Utility;
            // Native GetEquipmentHeatResistanceModifier is consumed by the
            // lava/ocean environmental heat path, not fire damage resistance.
            s.m_heatResistanceModifier=MantlePolicy.EnvironmentalHeatReduction;
        }
        public static void ResetSession(){exposurePlayer=null;cloudObservedAt=float.NegativeInfinity;MantleSkin.Dispose();}
    }
    [HarmonyPatch(typeof(ItemRegistry),nameof(ItemRegistry.RegisterAll))]
    static class MantleRegisteredStats
    {static void Postfix(ItemRegistry __instance)=>MantleRuntime.ApplyRegisteredStats(__instance);}
    [HarmonyPatch(typeof(Player),"Update")]
    static class MantlePlayerTick
    {static void Postfix(Player __instance)=>MantleRuntime.Tick(__instance,Time.deltaTime);}
    [HarmonyPatch(typeof(ItemsPlugin),"OnDestroy")]
    static class MantleShutdown
    {static void Prefix()=>MantleRuntime.ResetSession();}

    [HarmonyPatch(typeof(VisEquipment),"SetUtilityEquipped")]
    static class MantleUtilityVisual
    {
        static readonly FieldInfo instances=AccessTools.Field(typeof(VisEquipment),"m_utilityItemInstances"),lodField=AccessTools.Field(typeof(VisEquipment),"m_lodGroup");
        static void Postfix(VisEquipment __instance,int hash,bool __result)
        {
            if(!__result||hash!=MantleSkin.PrefabName.GetStableHashCode())return;
            var plugin=ItemsPlugin.Instance;if(!plugin||!plugin.AssetsReady)return;
            GameObject own=null;
            try
            {
                // Only the utility instance list is owned here. Shoulder/cape,
                // native body renderer/masks and OctoPack settings are untouched.
                own=MantleSkin.Attach(plugin,__instance.m_bodyModel);
                var prior=instances.GetValue(__instance) as List<GameObject>;
                if(prior!=null)foreach(var p in prior)if(p)Object.Destroy(p);
                instances.SetValue(__instance,new List<GameObject>{own});
                var lod=lodField.GetValue(__instance) as LODGroup;
                if(lod)
                {
                    var levels=lod.GetLODs();var skin=own.GetComponent<SkinnedMeshRenderer>();
                    for(int i=0;i<levels.Length;i++)levels[i].renderers=(levels[i].renderers??Array.Empty<Renderer>()).Concat(new Renderer[]{skin}).ToArray();
                    lod.SetLODs(levels);lod.RecalculateBounds();
                }
            }
            catch(Exception e){if(own)Object.Destroy(own);plugin.Warn("MANTLE_NATIVE_BIND_REFUSED "+e.Message);}
        }
    }
}
