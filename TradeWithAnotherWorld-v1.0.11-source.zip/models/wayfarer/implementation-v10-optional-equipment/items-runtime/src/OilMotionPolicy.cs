using System;

namespace Wayfarer.Items
{
    public enum OilMotionCancel {RightAttack,LeftAttack,Dodge,Guard,Goods,Magic,JumpCrouchWeaponSwitch,Movement}
    public static class OilMotionPolicy
    {
        public const string SourceHash="2db699c1e14ec53549e6e6c8c1c1b9e50fe0c25fc0e2c6e666559e85a99241e2";
        public const float Duration=3.8333330154418945f,ConsumeAt=25f/30f;
        public static float CancelAt(OilMotionCancel kind)
        {
            switch(kind)
            {
                case OilMotionCancel.RightAttack:return 72f/30f;
                case OilMotionCancel.LeftAttack:return 76f/30f;
                case OilMotionCancel.Dodge:return 74f/30f;
                case OilMotionCancel.Movement:return 87f/30f;
                default:return 85f/30f;
            }
        }
        public static bool CanCancel(float elapsed,OilMotionCancel kind)=>elapsed>=CancelAt(kind);
        public static bool ConsumeCrossed(float before,float after)=>before<ConsumeAt&&after>=ConsumeAt;
        public static void Sample(float elapsed,int count,out int first,out int second,out float alpha)
        {
            float f=Math.Max(0,Math.Min(1,elapsed/Duration))*(count-1);first=Math.Min(count-1,(int)f);second=Math.Min(count-1,first+1);alpha=f-first;
        }
    }
}
