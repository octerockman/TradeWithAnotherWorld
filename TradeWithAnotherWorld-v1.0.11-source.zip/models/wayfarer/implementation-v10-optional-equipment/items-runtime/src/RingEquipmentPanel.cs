using System;
using System.Reflection;
using Jotunn.Managers;
using HarmonyLib;
using UnityEngine;
using Object=UnityEngine.Object;
namespace Wayfarer.Items
{
    // Inventory-owned presentation; never changes inventory dimensions or capacity.
    public static class RingEquipmentPanel
    {
        static GameObject panel;
        static readonly UnityEngine.UI.Image[] icons=new UnityEngine.UI.Image[4];
        static readonly UnityEngine.UI.Text[] names=new UnityEngine.UI.Text[4];
        static readonly UnityEngine.UI.Button[] buttons=new UnityEngine.UI.Button[4];
        static readonly FieldInfo playerPanel=AccessTools.Field(typeof(InventoryGui),"m_player");
        static float nextRefresh;
        static UnityEngine.UI.Text Label(Transform parent,string text,int size,Vector2 pos,float w,float h)
        {
            var go=new GameObject("RingLabel",typeof(RectTransform),typeof(UnityEngine.UI.Text));go.transform.SetParent(parent,false);var r=(RectTransform)go.transform;r.anchorMin=r.anchorMax=new Vector2(0,1);r.pivot=new Vector2(0,1);r.anchoredPosition=pos;r.sizeDelta=new Vector2(w,h);
            var t=go.GetComponent<UnityEngine.UI.Text>();t.font=GUIManager.Instance.AveriaSerif;t.text=text;t.fontSize=size;t.color=new Color(.94f,.87f,.70f);t.alignment=TextAnchor.MiddleCenter;t.raycastTarget=false;t.horizontalOverflow=HorizontalWrapMode.Wrap;t.verticalOverflow=VerticalWrapMode.Truncate;return t;
        }
        static void Build(Transform parent)
        {
            panel=GUIManager.Instance.CreateWoodpanel(parent,new Vector2(.5f,0),new Vector2(.5f,0),new Vector2(0,-8),338,174,true);panel.name="WayfarerRingSlots";var rect=(RectTransform)panel.transform;rect.pivot=new Vector2(.5f,1);rect.anchoredPosition=new Vector2(0,-8);
            Label(panel.transform,"Rings",21,new Vector2(12,-7),314,26);
            for(int i=0;i<4;i++)
            {
                int slot=i;float x=14+i*80;
                var go=GUIManager.Instance.CreateButton("",panel.transform,new Vector2(0,1),new Vector2(0,1),new Vector2(x,-38),70,66);var r=(RectTransform)go.transform;r.pivot=new Vector2(0,1);r.anchoredPosition=new Vector2(x,-38);buttons[i]=go.GetComponent<UnityEngine.UI.Button>();buttons[i].onClick.AddListener(()=>{var item=RingEquipmentBackend.SlotItem(slot);if(item!=null&&!JewelleryRuntime.UnequipRing(Player.m_localPlayer,item))Player.m_localPlayer.Message(MessageHud.MessageType.Center,"Make room in your bag to unequip this ring.");nextRefresh=0;});
                var image=new GameObject("RingIcon",typeof(RectTransform),typeof(UnityEngine.UI.Image));image.transform.SetParent(go.transform,false);var ir=(RectTransform)image.transform;ir.anchorMin=Vector2.zero;ir.anchorMax=Vector2.one;ir.offsetMin=new Vector2(8,8);ir.offsetMax=new Vector2(-8,-8);icons[i]=image.GetComponent<UnityEngine.UI.Image>();icons[i].preserveAspect=true;icons[i].raycastTarget=false;
                names[i]=Label(panel.transform,"Ring "+(i+1),13,new Vector2(x,-106),70,36);
            }
            Label(panel.transform,"Right-click a ring to equip. Click a slot to unequip.",13,new Vector2(12,-145),314,23);
        }
        public static void Tick()
        {
            bool show=Player.m_localPlayer&&!Player.m_localPlayer.IsDead()&&InventoryGui.instance&&InventoryGui.IsVisible()&&!RingEquipmentBackend.UsingEqs;
            if(!show){if(panel)panel.SetActive(false);return;}
            var parent=playerPanel?.GetValue(InventoryGui.instance) as RectTransform;if(!parent||GUIManager.Instance==null)return;
            if(panel&&panel.transform.parent!=parent)Dispose();if(!panel)Build(parent);panel.SetActive(true);
            if(Time.unscaledTime<nextRefresh)return;nextRefresh=Time.unscaledTime+.1f;
            for(int i=0;i<4;i++)
            {
                var item=RingEquipmentBackend.SlotItem(i);var icon=item?.m_shared?.m_icons;icons[i].sprite=icon!=null&&icon.Length>0?icon[0]:null;icons[i].enabled=icons[i].sprite;buttons[i].interactable=item!=null;names[i].text=item==null?"Ring "+(i+1):Localization.instance.Localize(item.m_shared.m_name);
            }
        }
        public static void Dispose(){if(panel)Object.Destroy(panel);panel=null;nextRefresh=0;}
    }
}
