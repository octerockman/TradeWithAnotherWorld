using System;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    static class JewelleryWear
    {
        [ThreadStatic]static int depth;
        static Player owner;static bool casting;
        public static bool Begin(Player p,bool isCasting)
        {
            if(!p||p!=Player.m_localPlayer)return false;depth++;if(depth>1)return true;
            owner=p;casting=isCasting;return true;
        }
        public static void End(bool active)
        {
            if(!active)return;depth--;if(depth>0)return;
            owner=null;
        }
        public static void Store(ItemDrop.ItemData item,float proposed)
        {
            float loss=item.m_durability-proposed;
            item.m_durability=owner&&loss>0&&owner.GetInventory().ContainsItem(item)?item.m_durability-loss*JewelleryRuntime.DurabilityFactor(owner,casting):proposed;
        }
    }
    [HarmonyPatch]
    static class JewelleryWearScopes
    {
        static IEnumerable<MethodBase> TargetMethods()
        {
            foreach(string name in new[]{"DoMeleeAttack","DoAreaAttack","ProjectileAttackTriggered"}){var m=AccessTools.Method(typeof(Attack),name);if(m!=null)yield return m;}
            yield return AccessTools.Method(typeof(Humanoid),"BlockAttack");yield return AccessTools.Method(typeof(Humanoid),"DrainEquipedItemDurability");
        }
        static void Prefix(object __instance,out bool __state)
        {var a=__instance as Attack;var p=a!=null?AccessTools.Field(typeof(Attack),"m_character").GetValue(a) as Player:__instance as Player;__state=JewelleryWear.Begin(p,a!=null&&JewelleryRuntime.IsSpell(a));}
        static Exception Finalizer(Exception __exception,bool __state){JewelleryWear.End(__state);return __exception;}
        static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            var field=AccessTools.Field(typeof(ItemDrop.ItemData),"m_durability");var store=AccessTools.Method(typeof(JewelleryWear),"Store");
            foreach(var code in instructions){if(code.opcode==OpCodes.Stfld&&Equals(code.operand,field)){code.opcode=OpCodes.Call;code.operand=store;}yield return code;}
        }
    }
    [HarmonyPatch(typeof(Player),"DamageArmorDurability")]
    static class JewelleryArmorWearPatch
    {static void Prefix(Player __instance,ref HitData __0){float factor=JewelleryRuntime.DurabilityFactor(__instance,false);if(factor<1){__0=__0.Clone();__0.ApplyModifier(factor);}}}
    [HarmonyPatch(typeof(Player),"GetPlaceDurability")]
    static class JewelleryBuildWearPatch{static void Postfix(Player __instance,ref float __result){__result*=JewelleryRuntime.DurabilityFactor(__instance,false);}}

    [HarmonyPatch(typeof(Humanoid),"BlockAttack")]
    static class JewelleryParryTimingPatch
    {
        static readonly FieldInfo timer=AccessTools.Field(typeof(Humanoid),"m_blockTimer");
        [HarmonyPriority(Priority.First)]
        static void Prefix(Humanoid __instance,out float __state)
        {
            __state=float.NaN;var p=__instance as Player;if(!p||!JewelleryRuntime.For(p).Has("md_last_inch"))return;
            var blocker=AccessTools.Method(typeof(Humanoid),"GetCurrentBlocker").Invoke(p,null) as ItemDrop.ItemData;
            if(blocker==null||blocker.m_shared.m_timedBlockBonus<=1||timer==null)return;
            __state=(float)timer.GetValue(p);timer.SetValue(p,Math.Max(0,__state-.03f));
        }
        static void Postfix(Humanoid __instance,float __state){if(!float.IsNaN(__state))timer.SetValue(__instance,__state);}
    }
    [HarmonyPatch(typeof(Player),"OnDodgeMortal")]
    static class JewelleryDodgeTrailingStart
    {public static double Until;static void Prefix(Player __instance){Until=__instance==Player.m_localPlayer&&JewelleryRuntime.For(__instance).Has("md_cairn_thimble")?JewelleryRuntime.Now+.02:0;}}
    [HarmonyPatch(typeof(Player),"IsDodgeInvincible")]
    static class JewelleryDodgeTrailingWindow
    {static void Postfix(Player __instance,ref bool __result){if(__instance==Player.m_localPlayer&&__instance.InDodge()&&JewelleryRuntime.Now<JewelleryDodgeTrailingStart.Until&&JewelleryRuntime.For(__instance).Has("md_cairn_thimble"))__result=true;}}

    static class JewelleryNoise
    {
        [ThreadStatic]public static float Factor;
        public static float Enter(Player p,string source)
        {
            float old=Factor;var s=JewelleryRuntime.For(p);Factor=source=="footstep"?1-s.Value("footstepHearingReduction"):source=="spell"?1-s.Value("initialCastHearingReduction"):source=="bow"?1-s.Value("bowReleaseHearingReduction"):1;return old;
        }
    }
    [HarmonyPatch(typeof(CharacterAnimEvent),"FootStep")]
    static class JewelleryFootstepNoiseScope
    {
        static void Prefix(CharacterAnimEvent __instance,out float __state){__state=JewelleryNoise.Enter(__instance.GetComponentInParent<Player>(),"footstep");}
        static Exception Finalizer(Exception __exception,float __state){JewelleryNoise.Factor=__state;return __exception;}
    }
    [HarmonyPatch(typeof(Attack),"Start")]
    static class JewelleryInitialCastNoiseScope
    {
        static void Prefix(Attack __instance,Humanoid __0,ItemDrop.ItemData __5,out float __state){var skill=__5?.m_shared.m_skillType;__state=JewelleryNoise.Enter(__0 as Player,skill==Skills.SkillType.ElementalMagic||skill==Skills.SkillType.BloodMagic?"spell":"other");}
        static Exception Finalizer(Exception __exception,float __state){JewelleryNoise.Factor=__state;return __exception;}
    }
    [HarmonyPatch(typeof(Attack),"ProjectileAttackTriggered")]
    static class JewelleryBowReleaseNoiseScope
    {
        static void Prefix(Attack __instance,out float __state){var p=AccessTools.Field(typeof(Attack),"m_character").GetValue(__instance) as Player;__state=JewelleryNoise.Enter(p,__instance.GetWeapon()?.m_shared.m_skillType==Skills.SkillType.Bows?"bow":"other");}
        static Exception Finalizer(Exception __exception,float __state){JewelleryNoise.Factor=__state;return __exception;}
    }
    [HarmonyPatch(typeof(Character),"AddNoise")]
    static class JewelleryScopedNoisePatch{static void Prefix(Character __instance,ref float __0){if(__instance is Player&&JewelleryNoise.Factor>0)__0*=JewelleryNoise.Factor;}}
    [HarmonyPatch(typeof(ItemDrop.ItemData),"GetDrawStaminaDrain")]
    static class JewelleryBowHoldingCostPatch
    {static void Postfix(ItemDrop.ItemData __instance,ref float __result){var p=Player.m_localPlayer;if(p&&ReferenceEquals(__instance,JewelleryRuntime.HeldRight(p))&&__instance.m_shared.m_skillType==Skills.SkillType.Bows)__result=JewelleryMath.Cost(__result,JewelleryRuntime.For(p).Value("bowDrawHoldStaminaReduction"));}}
    [HarmonyPatch(typeof(ItemDrop.ItemData),"GetWeaponLoadingTime")]
    static class JewelleryReloadTimePatch
    {static void Postfix(ItemDrop.ItemData __instance,ref float __result){var p=Player.m_localPlayer;if(p&&ReferenceEquals(__instance,JewelleryRuntime.HeldRight(p))&&__instance.m_shared.m_skillType==Skills.SkillType.Crossbows&&JewelleryRuntime.For(p).Has("md_patient_windlass"))__result*=.85f;}}
    [HarmonyPatch(typeof(Attack),"FireProjectileBurst")]
    static class JewelleryBowSpreadPatch
    {
        static void Prefix(Attack __instance,out float[] __state)
        {
            __state=null;var p=AccessTools.Field(typeof(Attack),"m_character").GetValue(__instance) as Player;
            if(!p||__instance.GetWeapon()?.m_shared.m_skillType!=Skills.SkillType.Bows||!JewelleryRuntime.For(p).Has("sd_fletchkeeper_loop"))return;
            float draw=(float)AccessTools.Field(typeof(Attack),"m_attackDrawPercentage").GetValue(__instance);if(draw<.999f)return;
            __state=new[]{__instance.m_projectileAccuracy,__instance.m_projectileAccuracyMin};__instance.m_projectileAccuracy*=.8f;__instance.m_projectileAccuracyMin*=.8f;
        }
        static void Postfix(Attack __instance,float[] __state){if(__state!=null){__instance.m_projectileAccuracy=__state[0];__instance.m_projectileAccuracyMin=__state[1];}}
    }
    [HarmonyPatch(typeof(SEMan),"ApplyStatusEffectSpeedMods")]
    static class JewelleryPursuitMovePatch
    {static void Postfix(SEMan __instance,ref float __0){var p=JewelleryRuntime.PlayerFor(__instance);if(p&&p==Player.m_localPlayer&&p.IsOnGround()&&!p.IsAttached()&&JewelleryRuntime.For(p).Has("md_pursuit_thread")&&JewelleryRuntime.Now<JewelleryRuntime.State(p).pursuitExpires)__0*=JewelleryMath.GroundSpeed(.05f);}}
    [HarmonyPatch(typeof(CharacterAnimEvent),"Speed")]
    static class JewelleryPursuitAttackRatePatch
    {static void Prefix(CharacterAnimEvent __instance,ref float __0){var p=__instance.GetComponentInParent<Player>();if(p&&p==Player.m_localPlayer&&JewelleryRuntime.IsPhysicalMelee(JewelleryRuntime.CurrentAttack(p))&&JewelleryRuntime.For(p).Has("md_pursuit_thread")&&JewelleryRuntime.Now<JewelleryRuntime.State(p).pursuitExpires)__0*=JewelleryMath.AttackRate(.05f);}}
    [HarmonyPatch(typeof(Ship),"UpdateControlls")]
    static class JewelleryRudderResponsePatch
    {
        static readonly FieldInfo speed=AccessTools.Field(typeof(Ship),"m_rudderSpeed");
        static void Prefix(Ship __instance,out float __state){__state=float.NaN;var p=Player.m_localPlayer;if(speed!=null&&p&&p.GetControlledShip()==__instance&&JewelleryRuntime.For(p).Has("st_steady_helm_ring")){__state=(float)speed.GetValue(__instance);speed.SetValue(__instance,__state*1.15f);}}
        static void Postfix(Ship __instance,float __state){if(!float.IsNaN(__state))speed.SetValue(__instance,__state);}
    }
}
