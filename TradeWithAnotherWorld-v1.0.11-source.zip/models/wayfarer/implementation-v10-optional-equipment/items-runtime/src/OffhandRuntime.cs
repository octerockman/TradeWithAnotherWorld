using System;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using HarmonyLib;
using Newtonsoft.Json;
using UnityEngine;
namespace Wayfarer.Items
{
    public sealed class OffhandEmission
    {public string item,action;public int quality;public long user;public uint id;public float damageFactor;public Vector3 origin,direction;}
    public static class OffhandRuntime
    {
        const string Rpc="TWA_WF_OffhandEmission_v1";
        static ZRoutedRpc rpc;
        static readonly Dictionary<string,float> cooldowns=new Dictionary<string,float>(StringComparer.Ordinal);
        static ItemDrop.ItemData activeItem;static Player activePlayer;static long activeAction;static int damageRevision;static bool emitted;
        static readonly Dictionary<long,double> lastRemote=new Dictionary<long,double>();
        static readonly Dictionary<long,Tuple<Player,double,bool>> training=new Dictionary<long,Tuple<Player,double,bool>>();
        public static bool Ready=>OffhandPose.TryDescribe("bell_ring",out _,out _)&&OffhandPose.TryDescribe("torch_swing",out _,out _)&&OffhandPose.TryDescribe("censer_low_sweep",out _,out _);
        public static bool Supported(Player p,out ItemDrop.ItemData item,out ItemDefinition d)
        {item=JewelleryRuntime.HeldLeft(p);d=null;return p&&item!=null&&ItemsPlugin.Instance&&ItemsPlugin.Instance.Catalogue.TryItem(item,out d)&&new[]{"handbell","torch","censer"}.Contains(d.Kind);}
        public static bool Busy(Player p)=>OffhandPose.IsBusy(p);
        public static void Tick()
        {
            if(ZRoutedRpc.instance!=null&&rpc!=ZRoutedRpc.instance){rpc=ZRoutedRpc.instance;rpc.Register<string>(Rpc,Receive);}
            if(activePlayer&&Busy(activePlayer)&&(!ReferenceEquals(JewelleryRuntime.HeldLeft(activePlayer),activeItem)||activePlayer.IsDead()||SupplyUse.LocalDamageRevision!=damageRevision))OffhandPose.Cancel(activePlayer);
            EquippedOffhandFx.Tick();
            foreach(long key in training.Where(t=>Time.realtimeSinceStartupAsDouble-t.Value.Item2>12).Select(t=>t.Key).ToArray())training.Remove(key);
        }
        public static void ConfirmHit(long action,float physicalDamage)
        {if(physicalDamage>0&&training.TryGetValue(action,out var record)&&record.Item1==Player.m_localPlayer&&!record.Item3){record.Item1.RaiseSkill(Skills.SkillType.Clubs,1);training[action]=Tuple.Create(record.Item1,record.Item2,true);}}
        public static bool TryStart(Player player,bool secondary)
        {
            if(!Supported(player,out var item,out var d)||player!=Player.m_localPlayer||player.IsDead()||player.InAttack()||player.InDodge()||Busy(player)||WayfarerTradeUI.IsOpen||Wayfarer.InGame.ApprovedLedgerPanel.IsOpen)return false;
            if(item.m_shared.m_useDurability&&item.m_durability<=0)return false;
            string action=d.Kind=="handbell"?"bell_ring":d.Kind=="torch"?(secondary?"torch_wide_sweep":"torch_swing"):(secondary?"censer_flick":"censer_low_sweep");
            string cooldown=d.Kind+":"+(secondary?"alternate":"primary");if(cooldowns.TryGetValue(cooldown,out float until)&&until>Time.time)return false;
            if(!OffhandPose.TryDescribe(action,out _,out _))return false;
            bool spell=d.Kind=="handbell";float skill=player.GetSkillFactor(spell?Skills.SkillType.ElementalMagic:item.m_shared.m_skillType);
            float stamina=d.Kind=="censer"&&secondary?d.Stat("emberStamina"):secondary?d.Stat("secondaryStamina",d.Stat("stamina")):d.Stat("stamina");
            stamina*=1+player.GetEquipmentAttackStaminaModifier();player.GetSEMan().ModifyAttackStaminaUsage(stamina,ref stamina,true);stamina=OffhandCombatPolicy.SkillCost(stamina,skill);float eitr=OffhandCombatPolicy.SkillCost(d.Stat("eitr"),skill);
            if(spell){stamina=JewelleryRuntime.CastingStamina(player,stamina);eitr=JewelleryRuntime.CastingEitr(player,eitr);}
            else if(!secondary&&JewelleryRuntime.For(player).Has("ds3_afterturn")&&JewelleryRuntime.State(player)?.cooldownDeadlines.TryGetValue("afterturn_opportunity_expires",out double opportunity)==true&&opportunity>JewelleryRuntime.Now)stamina=JewelleryMath.Cost(stamina,.2f);
            float health=d.Stat("healthCost");bool borrowed=!player.HaveEitr(eitr)&&JewelleryBorrowedSpark.CanPayCustomCast(player,eitr,stamina,health);
            if(!borrowed&&!OffhandCombatPolicy.CanPay(player.GetHealth(),player.GetStamina(),player.GetEitr(),health,stamina,eitr)){player.Message(MessageHud.MessageType.Center,"You lack the strength to use it.");return false;}
            float eitrBefore=player.GetEitr();long actionId=0;
            bool started=OffhandPose.TryBegin(player,action,eventName=>{if(eventName=="emit"&&activePlayer==player&&ReferenceEquals(activeItem,item)&&!emitted){emitted=true;Emit(player,item,d,action,actionId,skill);}},()=>{if(activePlayer==player){JewelleryRuntime.EndAction(player,actionId);activePlayer=null;activeItem=null;activeAction=0;}});
            if(!started)return false;
            actionId=JewelleryRuntime.BeginCustomAction(player,!spell&&action!="censer_flick",spell,eitr>0,eitrBefore,secondary);activeAction=actionId;activeItem=item;activePlayer=player;damageRevision=SupplyUse.LocalDamageRevision;emitted=false;
            if(!spell)training[actionId]=Tuple.Create(player,Time.realtimeSinceStartupAsDouble,false);
            if(borrowed){if(!JewelleryBorrowedSpark.TryPayCustomCast(player,eitr,stamina,health)){OffhandPose.Cancel(player);return false;}}
            else{player.UseStamina(stamina);if(eitr>0)player.UseEitr(eitr);}if(health>0)player.UseHealth(health);
            if(d.Kind=="censer")cooldowns[cooldown]=Time.time+d.Stat(secondary?"emberCooldown":"smokeCooldown");
            if(item.m_shared.m_useDurability)item.m_durability=Math.Max(0,item.m_durability-item.m_shared.m_useDurabilityDrain*Game.m_durabilityRate*JewelleryRuntime.DurabilityFactor(player,spell));
            if(spell)RuntimeFacts.Record("used_elemental_magic");return true;
        }
        static void Emit(Player p,ItemDrop.ItemData item,ItemDefinition d,string action,long actionId,float skill)
        {
            JewelleryRuntime.ReleaseCustomAction(p,actionId);
            var socket=OffhandPoseMount.GetSocket(p,d.Kind=="torch"?"Flame":d.Kind=="censer"?(action=="censer_low_sweep"?"Smoke":"Ember"):"Grip");
            if(!socket)socket=OffhandPoseMount.GetSocket(p,"Grip");if(!socket)return;
            Vector3 direction=p.GetAimDir(p.GetCenterPoint()).normalized;
            float factor=d.Kind=="handbell"?OffhandCombatPolicy.BellDamageFactor(skill,UnityEngine.Random.value):p.GetRandomSkillFactor(item.m_shared.m_skillType);
            var id=p.GetZDOID();var message=new OffhandEmission{item=d.Id,action=action,quality=item.m_quality,user=id.UserID,id=id.ID,origin=socket.position,direction=direction,damageFactor=factor};
            OffhandEffects.Emit(p,message,actionId,true);
            if(rpc!=null)rpc.InvokeRoutedRPC(ZRoutedRpc.Everybody,Rpc,new object[]{JsonConvert.SerializeObject(message)});
        }
        static void Receive(long sender,string raw)
        {
            if(raw==null||raw.Length>2048||ZDOMan.instance==null||!ZNetScene.instance)return;
            OffhandEmission m;try{m=JsonConvert.DeserializeObject<OffhandEmission>(raw);}catch(JsonException){return;}
            if(m==null||!RuntimeCatalogue.SafeId(m.item)||m.quality<1||m.quality>4||!Finite(m.origin)||!Finite(m.direction)||float.IsNaN(m.damageFactor)||m.damageFactor<0||m.damageFactor>2)return;
            var id=new ZDOID(m.user,m.id);var zdo=ZDOMan.instance.GetZDO(id);if(zdo==null||zdo.GetOwner()!=sender)return;
            var go=ZNetScene.instance.FindInstance(id);var player=go?go.GetComponent<Player>():null;if(!player||player==Player.m_localPlayer||Vector3.Distance(player.transform.position,m.origin)>4)return;
            if(!Supported(player,out _,out var held)||held.Id!=m.item)return;
            double now=Time.realtimeSinceStartupAsDouble;if(lastRemote.TryGetValue(sender,out double at)&&now-at<.08)return;lastRemote[sender]=now;
            OffhandEffects.Emit(player,m,0,false);
        }
        static bool Finite(Vector3 v)=>!(float.IsNaN(v.x)||float.IsNaN(v.y)||float.IsNaN(v.z)||float.IsInfinity(v.x)||float.IsInfinity(v.y)||float.IsInfinity(v.z));
    }
    [HarmonyPatch(typeof(Player),nameof(Player.SetControls))]
    static class OffhandControls
    {
        static readonly OffhandChordPolicy policy=new OffhandChordPolicy();
        static readonly string[] QueueFields={"m_attack","m_attackHold","m_secondaryAttack","m_secondaryAttackHold"};
        [HarmonyPriority(Priority.First)]
        static void Prefix(Player __instance,ref Vector3 __0,ref bool __1,ref bool __2,ref bool __3,ref bool __4,ref bool __5,ref bool __6,ref bool __7,ref bool __8,ref bool __9,ref bool __10,ref bool __11)
        {
            if(__instance!=Player.m_localPlayer)return;
            if(InventoryGui.IsVisible()||StoreGui.IsVisible()||WayfarerTradeUI.IsOpen||Wayfarer.InGame.ApprovedLedgerPanel.IsOpen||global::Console.IsVisible()||Menu.IsVisible()||TextInput.IsVisible()||Chat.instance&&Chat.instance.HasFocus()||TextViewer.instance&&TextViewer.instance.IsVisible()){policy.Reset();return;}
            bool supported=OffhandRuntime.Supported(__instance,out _,out _);
            if(supported&&__2&&(__5||__6)&&OilMotion.IsBusy(__instance))
            {if(OilMotion.CanCancel(__instance,OilMotionCancel.LeftAttack))OilMotion.Cancel(__instance);else{__1=__2=__5=__6=false;return;}}
            var result=policy.Step(Time.unscaledTimeAsDouble,__1,__2,__5,__6,OffhandRuntime.Busy(__instance),supported);
            __1=result.attack;__2=result.attackHold;__5=result.block;__6=result.blockHold;
            if(result.clearMainQueue)foreach(string field in QueueFields)AccessTools.Field(typeof(Character),field)?.SetValue(__instance,false);
            if(result.offhand)OffhandRuntime.TryStart(__instance,Input.GetKey(KeyCode.LeftShift)||Input.GetKey(KeyCode.RightShift));
            if(OffhandRuntime.Busy(__instance)){__0=Vector3.zero;__1=__2=__3=__4=__5=__6=__7=__8=__9=__10=__11=false;}
        }
    }
}
