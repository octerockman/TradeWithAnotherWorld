using System;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    public static class JewelleryCuratedCombat
    {
        static readonly ConditionalWeakTable<Attack,object> intercepted=new ConditionalWeakTable<Attack,object>();
        static readonly System.Reflection.FieldInfo activeAttack=AccessTools.Field(typeof(Humanoid),"m_currentAttack");
        public static bool IsCuratedThrust(JewelleryAction action)=>action.physical&&!action.secondary&&action.attack!=null&&action.attack.m_attackAnimation=="spear_poke";
        public static bool IsCuratedSlowSecondary(JewelleryAction action)=>action.physical&&action.secondary&&action.attack!=null&&action.attack.m_attackAnimation=="greatsword_secondary";
        public static bool InterceptWindup(JewelleryAction action,Character target)
        {
            if(!IsCuratedThrust(action)||!(target is Humanoid actor))return false;var ai=actor.GetComponent<BaseAI>();
            if(!ai||ai.GetTargetCreature()!=action.player)return false;
            var attack=activeAttack.GetValue(actor) as Attack;if(!JewelleryWorldHints.Unreleased(attack)||intercepted.TryGetValue(attack,out _))return false;
            intercepted.Add(attack,new object());return true;
        }
        static double pendingJumpAt=-10,jumpedAt=-10;static bool jumpUsed;
        [ThreadStatic]public static Player IntentionalJump;
        public static void Input(Player p,bool jump){if(jump&&p==Player.m_localPlayer)pendingJumpAt=JewelleryRuntime.Now;}
        public static bool HasRecentJumpInput=>JewelleryRuntime.Now-pendingJumpAt<=.15;
        public static void Jumped(Player p){if(p==IntentionalJump&&p==Player.m_localPlayer){jumpedAt=JewelleryRuntime.Now;jumpUsed=false;pendingJumpAt=-10;}}
        public static bool SampleAirborneRelease(Player p)
        {
            if(!p||p!=Player.m_localPlayer||jumpUsed||p.IsOnGround()||JewelleryRuntime.Now-jumpedAt>.75)return false;jumpUsed=true;return JewelleryRuntime.For(p).Has("er_t_rooftop_spur");
        }
    }
    [HarmonyPatch(typeof(Player),"SetControls")]
    static class JewelleryRealJumpInputPatch{static void Prefix(Player __instance,bool __7){JewelleryCuratedCombat.Input(__instance,__7);}}
    [HarmonyPatch(typeof(Character),"Jump")]
    static class JewelleryIntentionalJumpScope
    {
        static void Prefix(Character __instance,bool __0,out Player __state){__state=JewelleryCuratedCombat.IntentionalJump;JewelleryCuratedCombat.IntentionalJump=__instance==Player.m_localPlayer&&!__0&&JewelleryCuratedCombat.HasRecentJumpInput?Player.m_localPlayer:null;}
        static Exception Finalizer(Exception __exception,Player __state){JewelleryCuratedCombat.IntentionalJump=__state;return __exception;}
    }
    [HarmonyPatch(typeof(Player),"OnJump")]
    static class JewellerySuccessfulJumpPatch{static void Postfix(Player __instance){JewelleryCuratedCombat.Jumped(__instance);}}
    [HarmonyPatch(typeof(Attack),"OnAttackTrigger")]
    static class JewelleryActualMeleeReleasePatch
    {static void Prefix(Attack __instance){JewelleryCombat.Released(__instance);}}
}
