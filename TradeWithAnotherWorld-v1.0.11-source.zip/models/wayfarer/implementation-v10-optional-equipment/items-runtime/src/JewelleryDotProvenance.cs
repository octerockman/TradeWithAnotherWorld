using System;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    public sealed class JewelleryDotBudget
    {public float fire,spirit,poison;}
    public sealed class JewelleryDotContext
    {
        public StatusEffect effect;public Player player;
        public float fireBefore,spiritBefore,poisonBefore,fireFraction,spiritFraction,poisonFraction,addedFire,addedSpirit,addedPoison;
        public float HostileFraction(HitData hit)
        {float total=hit.GetTotalDamage();return total>0?Mathf.Clamp01((hit.m_damage.m_fire*fireFraction+hit.m_damage.m_spirit*spiritFraction+hit.m_damage.m_poison*poisonFraction)/total):0;}
        public float HostileFireFraction(HitData hit)
        {float total=hit.GetTotalDamage();return total>0?Mathf.Clamp01(hit.m_damage.m_fire*fireFraction/total):0;}
    }
    public static class JewelleryDotProvenance
    {
        static readonly ConditionalWeakTable<StatusEffect,JewelleryDotBudget> budgets=new ConditionalWeakTable<StatusEffect,JewelleryDotBudget>();
        [ThreadStatic]static Stack<JewelleryDotContext> contexts;
        static Func<HitData> originalHit;static Func<Character> originalVictim;
        static readonly FieldInfo character=AccessTools.Field(typeof(StatusEffect),"m_character"),fireLeft=AccessTools.Field(typeof(SE_Burning),"m_fireDamageLeft"),spiritLeft=AccessTools.Field(typeof(SE_Burning),"m_spiritDamageLeft"),poisonLeft=AccessTools.Field(typeof(SE_Poison),"m_damageLeft");
        public static JewelleryDotContext Current=>contexts!=null&&contexts.Count>0?contexts.Peek():null;
        public static void BindSource(Func<HitData> hit,Func<Character> victim){originalHit=hit;originalVictim=victim;}
        static Player PlayerFor(StatusEffect effect)=>character.GetValue(effect) as Player;
        static bool HostileSource(StatusEffect effect)
        {var p=PlayerFor(effect);var h=originalHit?.Invoke();return p&&originalVictim?.Invoke()==p&&h!=null&&JewelleryRuntime.Hostile(h.GetAttacker(),p);}
        static float Read(FieldInfo field,object instance)=>Math.Max(0,(float)field.GetValue(instance));
        public static float Pool(StatusEffect effect,string channel)=>channel=="fire"?Read(fireLeft,effect):channel=="spirit"?Read(spiritLeft,effect):Read(poisonLeft,effect);
        public static void Added(StatusEffect effect,string channel,float before,float supplied)
        {
            var p=PlayerFor(effect);if(!p||p!=Player.m_localPlayer)return;float after=Pool(effect,channel);var budget=budgets.GetOrCreateValue(effect);bool hostile=HostileSource(effect);
            if(channel=="poison")
            {
                // Actual native code replaces, rather than adds, only when the
                // newly supplied poison is at least the previous remaining pool.
                if(supplied>=before)budget.poison=hostile?after:0;
                return;
            }
            float added=Math.Max(0,after-before);
            if(channel=="fire")budget.fire=Math.Min(after,budget.fire+(hostile?added:0));else budget.spirit=Math.Min(after,budget.spirit+(hostile?added:0));
        }
        public static JewelleryDotContext Begin(StatusEffect effect)
        {
            var p=PlayerFor(effect);var ctx=new JewelleryDotContext{effect=effect,player=p};
            if(effect is SE_Burning){ctx.fireBefore=Pool(effect,"fire");ctx.spiritBefore=Pool(effect,"spirit");}else ctx.poisonBefore=Pool(effect,"poison");
            if(budgets.TryGetValue(effect,out var budget))
            {
                ctx.fireFraction=ctx.fireBefore>0?Mathf.Clamp01(budget.fire/ctx.fireBefore):0;ctx.spiritFraction=ctx.spiritBefore>0?Mathf.Clamp01(budget.spirit/ctx.spiritBefore):0;ctx.poisonFraction=ctx.poisonBefore>0?Mathf.Clamp01(budget.poison/ctx.poisonBefore):0;
            }
            if(contexts==null)contexts=new Stack<JewelleryDotContext>();contexts.Push(ctx);return ctx;
        }
        public static void End(JewelleryDotContext ctx)
        {
            if(ctx==null)return;
            if(contexts!=null&&contexts.Count>0&&ReferenceEquals(contexts.Peek(),ctx))contexts.Pop();
        }
        public static void StoreFire(SE_Burning effect,float remaining)=>Store(effect,remaining,"fire",fireLeft);
        public static void StoreSpirit(SE_Burning effect,float remaining)=>Store(effect,remaining,"spirit",spiritLeft);
        public static void StorePoison(SE_Poison effect,float remaining)=>Store(effect,remaining,"poison",poisonLeft);
        static void Store(StatusEffect effect,float remaining,string channel,FieldInfo field)
        {
            float old=Pool(effect,channel);float fraction=0;
            if(budgets.TryGetValue(effect,out var b))
            {
                float hostile=channel=="fire"?b.fire:channel=="spirit"?b.spirit:b.poison;fraction=old>0?Mathf.Clamp01(hostile/old):0;
                float after=Mathf.Clamp(hostile-Math.Max(0,old-remaining)*fraction,0,Math.Max(0,remaining));
                if(channel=="fire")b.fire=after;else if(channel=="spirit")b.spirit=after;else b.poison=after;
            }
            var ctx=Current;if(ctx!=null&&ctx.effect==effect){if(channel=="fire")ctx.fireFraction=fraction;else if(channel=="spirit")ctx.spiritFraction=fraction;else ctx.poisonFraction=fraction;}
            field.SetValue(effect,remaining);
        }
    }
    [HarmonyPatch(typeof(SE_Burning),"AddFireDamage")]
    static class JewelleryAddFireProvenancePatch
    {static void Prefix(SE_Burning __instance,out float __state){__state=JewelleryDotProvenance.Pool(__instance,"fire");}static void Postfix(SE_Burning __instance,float __0,float __state){JewelleryDotProvenance.Added(__instance,"fire",__state,__0);}}
    [HarmonyPatch(typeof(SE_Burning),"AddSpiritDamage")]
    static class JewelleryAddSpiritProvenancePatch
    {static void Prefix(SE_Burning __instance,out float __state){__state=JewelleryDotProvenance.Pool(__instance,"spirit");}static void Postfix(SE_Burning __instance,float __0,float __state){JewelleryDotProvenance.Added(__instance,"spirit",__state,__0);}}
    [HarmonyPatch(typeof(SE_Poison),"AddDamage")]
    static class JewelleryAddPoisonProvenancePatch
    {static void Prefix(SE_Poison __instance,out float __state){__state=JewelleryDotProvenance.Pool(__instance,"poison");}static void Postfix(SE_Poison __instance,float __0,float __state){JewelleryDotProvenance.Added(__instance,"poison",__state,__0);}}
    [HarmonyPatch]
    static class JewelleryNativeDotProvenanceScope
    {
        static IEnumerable<MethodBase> TargetMethods(){yield return AccessTools.Method(typeof(SE_Burning),"UpdateStatusEffect");yield return AccessTools.Method(typeof(SE_Poison),"UpdateStatusEffect");}
        static void Prefix(StatusEffect __instance,out JewelleryDotContext __state){__state=JewelleryDotProvenance.Begin(__instance);}
        static Exception Finalizer(Exception __exception,JewelleryDotContext __state){JewelleryDotProvenance.End(__state);return __exception;}
        static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            var fire=AccessTools.Field(typeof(SE_Burning),"m_fireDamageLeft");var spirit=AccessTools.Field(typeof(SE_Burning),"m_spiritDamageLeft");var poison=AccessTools.Field(typeof(SE_Poison),"m_damageLeft");
            foreach(var code in instructions)
            {
                if(code.opcode==OpCodes.Stfld)
                {
                    string method=Equals(code.operand,fire)?"StoreFire":Equals(code.operand,spirit)?"StoreSpirit":Equals(code.operand,poison)?"StorePoison":null;
                    if(method!=null){code.opcode=OpCodes.Call;code.operand=AccessTools.Method(typeof(JewelleryDotProvenance),method);}
                }
                yield return code;
            }
        }
    }
}
