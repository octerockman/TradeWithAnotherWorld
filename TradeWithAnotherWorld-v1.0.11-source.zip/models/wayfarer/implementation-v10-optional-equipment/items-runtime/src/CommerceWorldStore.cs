using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Wayfarer.Items
{
    public sealed class CommercePending
    {
        public long peer,player;
        public string inventoryHash;
        public string selectedItemId;
        public CommerceTransaction plan;
    }
    public sealed class CommerceSave
    {
        public string schema="twa.wayfarer.commerce-world.v1";
        public long worldUid;
        public CommerceWorldState state=new CommerceWorldState();
        public CommercePending pending;
        public List<CommerceQueuedVictory> queuedVictories=new List<CommerceQueuedVictory>();
        public HashSet<string> queuedNativeFacts=new HashSet<string>(StringComparer.Ordinal);
        public Dictionary<string,int> nativeCounters=new Dictionary<string,int>(StringComparer.Ordinal);
        public Dictionary<long,HashSet<string>> playerFlags=new Dictionary<long,HashSet<string>>();
    }
    public sealed class CommerceQueuedVictory
    {public string run;public string[] eligibleAtVictory;}
    public sealed class CommerceWorldStore
    {
        readonly string path;
        readonly long world;
        public CommerceWorldStore(string folder,long uid){Directory.CreateDirectory(folder);world=uid;path=Path.Combine(folder,uid+".json");}
        public CommerceSave Load()
        {
            if(!File.Exists(path))return new CommerceSave{worldUid=world};
            // Never silently reset a damaged world economy or replay purchases.
            var json=RuntimeCatalogue.ReadJson(path,64*1024*1024);
            var saved=json.ToObject<CommerceSave>();
            if(saved?.schema!="twa.wayfarer.commerce-world.v1"||saved.worldUid!=world||saved.state?.schemaVersion!=1||saved.state.revision<0)throw new InvalidDataException("Invalid Wayfarer world account; original retained.");
            return saved;
        }
        public void Save(CommerceSave saved)
        {
            if(saved.worldUid!=world)throw new InvalidOperationException("World identity changed during trade.");
            string temporary=path+".new",backup=path+".previous";
            byte[] bytes=Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(saved,Formatting.Indented));
            using(var output=new FileStream(temporary,FileMode.Create,FileAccess.Write,FileShare.None)){output.Write(bytes,0,bytes.Length);output.Flush(true);}
            if(File.Exists(path))File.Replace(temporary,path,backup);else File.Move(temporary,path);
        }
    }
}
