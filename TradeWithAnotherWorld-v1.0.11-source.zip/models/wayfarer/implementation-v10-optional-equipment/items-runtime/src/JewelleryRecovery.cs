using System;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    [DefaultExecutionOrder(10000)]
    public sealed class JewelleryRecovery:MonoBehaviour
    {
        // Exact controller/clip receipts: native-animation-phases-v2.json.
        const int Dodge=unchecked((int)3588401672u),FireballToIdle=unchecked((int)3349479214u),Fireball0=525728579,Fireball1=1750256597;
        static readonly FieldInfo animatorField=AccessTools.Field(typeof(Character),"m_animator");
        static readonly FieldInfo[] armour=new[]{"m_chestItem","m_legItem","m_helmetItem","m_shoulderItem"}.Select(n=>AccessTools.Field(typeof(Humanoid),n)).ToArray();
        Player player;Animator animator;float baseSpeed,lastWritten;bool changed;
        public static void Ensure(Player p){if(p&&!p.GetComponent<JewelleryRecovery>())p.gameObject.AddComponent<JewelleryRecovery>();}
        void Awake(){player=GetComponent<Player>();animator=animatorField.GetValue(player) as Animator;}
        public static float EquippedLoad(Player p)
        {
            return armour.Select(f=>f.GetValue(p) as ItemDrop.ItemData).Concat(new[]{JewelleryRuntime.HeldRight(p),JewelleryRuntime.HeldLeft(p)})
                .Where(x=>x!=null).Distinct().Sum(x=>x.GetWeight());
        }
        void Restore()
        {
            if(changed&&animator&&Math.Abs(animator.speed-lastWritten)<.00001f)animator.speed=baseSpeed;
            changed=false;
        }
        void OnDisable(){Restore();}
        void Update()
        {
            Restore();if(!JewelleryRuntime.Active||player!=Player.m_localPlayer||!animator||player.IsDead())return;
            if(animator.IsInTransition(0))return;
            var state=animator.GetCurrentAnimatorStateInfo(0);var s=JewelleryRuntime.For(player);bool eligible=false;
            if(state.fullPathHash==Dodge&&s.Has("sd_reedstep_band")&&player.InDodge())
                eligible=JewelleryMath.DodgeRecovery(state.normalizedTime,player.IsDodgeInvincible(),EquippedLoad(player));
            bool fireballTail=state.fullPathHash==FireballToIdle||state.fullPathHash==Fireball0&&state.normalizedTime>.50706905f/.83333337f||state.fullPathHash==Fireball1&&state.normalizedTime>.4991844f;
            if(fireballTail&&s.Has("sd_quick_release_band"))
            {
                var focus=JewelleryRuntime.HeldRight(player);
                eligible=focus?.m_dropPrefab&&focus.m_dropPrefab.name=="StaffFireball"&&focus.m_shared.m_skillType==Skills.SkillType.ElementalMagic;
            }
            // No clip seeking or replacement: original event order/root curve
            // remains intact. Only verified, event-free recovery time is scaled.
            if(!eligible)return;baseSpeed=animator.speed;if(baseSpeed<=0)return;
            lastWritten=baseSpeed/.94f;animator.speed=lastWritten;changed=true;
        }
    }
}
