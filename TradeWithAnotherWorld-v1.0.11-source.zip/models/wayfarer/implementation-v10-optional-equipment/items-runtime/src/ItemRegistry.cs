using System;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using Jotunn.Entities;
using Jotunn.Managers;
using UnityEngine;
using Wayfarer.InGame;
using Object=UnityEngine.Object;

namespace Wayfarer.Items
{
    // Item identities never change with world progress. Commerce selects stock;
    // an already purchased item keeps its own prefab and its own native stats.
    public sealed class ItemRegistry
    {
        public static ItemRegistry Current { get; private set; }
        readonly RuntimeCatalogue catalogue;
        readonly ItemVisualCache visuals;
        readonly Action<string> log;
        readonly Dictionary<string,GameObject> registered=new Dictionary<string,GameObject>(StringComparer.Ordinal);
        readonly Dictionary<string,string> deferred=new Dictionary<string,string>(StringComparer.Ordinal);
        readonly Dictionary<string,EquipmentSource> equipment=new Dictionary<string,EquipmentSource>(StringComparer.Ordinal);
        readonly Dictionary<string,float> bellPatternChances=new Dictionary<string,float>(StringComparer.Ordinal);
        readonly HashSet<string> recipes=new HashSet<string>(StringComparer.Ordinal);
        static readonly MethodInfo Memberwise=typeof(object).GetMethod("MemberwiseClone",BindingFlags.Instance|BindingFlags.NonPublic);
        public IReadOnlyDictionary<string,string> Deferred=>deferred;
        public IEnumerable<string> RegisteredIds=>registered.Keys;
        public ItemRegistry(RuntimeCatalogue definitions,ItemVisualCache assets,Action<string> logger)
        {
            catalogue=definitions??throw new ArgumentNullException(nameof(definitions));visuals=assets??throw new ArgumentNullException(nameof(assets));log=logger;
            foreach(var d in catalogue.Items.Values.Where(IsRestored))
            {
                string native=EquipmentBehavior(d.Text("family"));
                if(native!=null&&visuals.Has(d.AssetId))equipment[d.Id]=new EquipmentSource{Prefab=native,AssetId=d.AssetId};
            }
            foreach(var bell in catalogue.Items.Values.Where(x=>x.Kind=="handbell"))
            {
                string pattern=bell.Stats.Value<string>("matchingPatternId");
                if(!string.IsNullOrEmpty(pattern))bellPatternChances[pattern]=bell.Stat("qualityUpgradeSuccessChance",.65f);
            }
        }
        static string EquipmentBehavior(string family)
        {
            switch(family)
            {
                case "monk":return "MaceBronze";
                case "guard":case "knight":return "SwordIron";
                case "thrall":return "SledgeIron";
                case "abbot":return "AtgeirIron";
                case "guard_shield":case "knight_shield":case "censer":return "ShieldBanded";
                default:return null;
            }
        }
        public static void Register(ItemsPlugin plugin)
        {
            if(Current==null)Current=new ItemRegistry(plugin.Catalogue,plugin.Visuals,plugin.Report);
            Current.RegisterAll();
        }
        public bool IsRegistered(string id)=>registered.ContainsKey(id??"");
        public bool TryPrefab(string id,out GameObject prefab)=>registered.TryGetValue(id??"",out prefab);
        // Supply a real full weapon visual. A fragment is never an equipment substitute.
        // assetId selects an admitted visual; sourcePrefab supplies native attack behavior.
        public void BindEquipmentSource(string id,string sourcePrefab,string assetId)
        {
            if(!catalogue.TryItem(id,out var d)||!IsRestored(d))throw new ArgumentException("Not a restored equipment identity.");
            if(IsRegistered(d.Id))throw new InvalidOperationException("Equipment identity already registered.");
            if(string.IsNullOrEmpty(sourcePrefab)||!visuals.Has(assetId)||assetId.EndsWith("-fragment",StringComparison.Ordinal))throw new ArgumentException("A complete admitted equipment source is required.");
            equipment[d.Id]=new EquipmentSource{Prefab=sourcePrefab,AssetId=assetId};
        }
        public void RegisterAll()
        {
            foreach(var d in catalogue.Items.Values.OrderBy(x=>x.Id,StringComparer.Ordinal))
            {
                if(IsRegistered(d.Id))continue;
                try{RegisterOne(d);deferred.Remove(d.Id);}
                catch(Exception e){deferred[d.Id]=e.Message;log?.Invoke("ITEM_DEFERRED "+d.Id+" "+e.Message);}
            }
            RegisterQualityRecipes();
            log?.Invoke("ITEM_REGISTRATION registered="+registered.Count+" deferred="+deferred.Count+" naturalSpawns=false");
        }
        static bool IsRestored(ItemDefinition d)=>d.Kind=="weapon"||d.Kind=="shield"||d.Kind=="censer";
        static bool HasForgeRecipe(ItemDefinition d)=>IsRestored(d)||d.Kind=="torch";
        static string BasePrefab(ItemDefinition d)
        {
            if(d.Kind=="food")return "Raspberry";
            if(d.Kind=="arrow")return "ArrowWood";
            if(d.Kind=="healing_potion")return "MeadHealthMinor";
            if(d.Kind=="handbell")return "ShieldWood";
            if(d.Kind=="torch")return "Torch";
            if(d.Kind=="ring"||d.Kind=="talisman"||d.Kind=="mantle")return "BeltStrength";
            return "Amber";
        }
        static string AssetId(ItemDefinition d)
        {
            // These are documentary copies, not new visual designs. Their exact
            // plan/page identity remains separate from the reusable presentation.
            if(d.Kind=="commission_record")return d.Id=="consecrated_bell_pattern"?"bell_patterns":"scrolls";
            return d.AssetId;
        }
        void RegisterOne(ItemDefinition d)
        {
            if(d.Kind=="currency")
            {
                if(d.Prefab!=StrangeCoinItem.PrefabName)throw new InvalidOperationException("Unexpected Strange Coin identity.");
                var existing=StrangeCoinItem.Prefab?StrangeCoinItem.Prefab:PrefabManager.Instance.GetPrefab(d.Prefab);
                if(!existing||!existing.GetComponent<ItemDrop>())throw new InvalidOperationException("Existing Wayfarer coin has not registered yet.");
                // Preserve the camp's own model, icon, issue/link markers and prefab.
                var coin=existing.GetComponent<ItemDrop>().m_itemData.m_shared;
                coin.m_maxStackSize=d.Int("maxStack",9999);coin.m_weight=d.Number("weight");coin.m_value=0;
                registered.Add(d.Id,existing);return;
            }
            string sourceName=BasePrefab(d),asset=AssetId(d);
            if(IsRestored(d))
            {
                if(!equipment.TryGetValue(d.Id,out var binding))throw new InvalidOperationException("Full restored equipment visual/held source not admitted.");
                sourceName=binding.Prefab;asset=binding.AssetId;
            }
            if(!visuals.Has(asset))throw new InvalidOperationException("No admitted visual/icon source: "+asset);
            var source=PrefabManager.Instance.GetPrefab(sourceName);
            if(!source||!source.GetComponent<ItemDrop>())throw new InvalidOperationException("Native behavior template missing: "+sourceName);
            if(PrefabManager.Instance.GetPrefab(d.Prefab))throw new InvalidOperationException("Prefab identity owned outside this registry: "+d.Prefab);
            // Validate icon, stats and computed bundle weight before admitting a clone.
            var icon=visuals.Icon(asset);
            float weight=Weight(d);
            var item=new CustomItem(d.Prefab,sourceName);
            var root=item.ItemPrefab;root.SetActive(false);
            try
            {
                var original=source.GetComponent<ItemDrop>().m_itemData;
                var data=original.Clone();data.m_shared=(ItemDrop.ItemData.SharedData)Memberwise.Invoke(original.m_shared,null);
                data.m_dropPrefab=root;data.m_stack=1;data.m_quality=1;data.m_variant=0;
                data.m_customData=new Dictionary<string,string>(StringComparer.Ordinal){{"wayfarer:item",d.Id},{"wayfarer:version",d.Int("version").ToString(System.Globalization.CultureInfo.InvariantCulture)}};
                var shared=data.m_shared;
                shared.m_name=d.Name;shared.m_description=Description(d);shared.m_icons=new[]{icon};
                shared.m_maxStackSize=Math.Max(1,d.Int("maxStack",1));shared.m_weight=weight;shared.m_value=0;
                shared.m_maxQuality=Math.Max(1,(int)d.Stat("maxQuality",1));shared.m_variants=1;shared.m_scaleByQuality=0;shared.m_scaleWeightByQuality=0;
                shared.m_upgradeChance=bellPatternChances.TryGetValue(d.Id,out var patternChance)?patternChance:1;
                shared.m_breakChance=0;shared.m_successUpgradeSteps=1;
                shared.m_teleportable=true;shared.m_questItem=d.Stats.Value<bool?>("questRecord")??false;
                shared.m_equipStatusEffect=null;shared.m_setStatusEffect=null;shared.m_setName="";shared.m_setSize=0;shared.m_buildPieces=null;
                shared.m_armor=0;shared.m_armorPerLevel=0;shared.m_eitrRegenModifier=0;shared.m_movementModifier=0;shared.m_heatResistanceModifier=0;
                shared.m_attack=original.m_shared.m_attack?.Clone();shared.m_secondaryAttack=original.m_shared.m_secondaryAttack?.Clone();
                ApplyStats(d,shared,original.m_shared);
                data.m_durability=data.GetMaxDurability();item.ItemDrop.m_itemData=data;
                item.ItemDrop.m_autoPickup=true;item.ItemDrop.m_autoDestroy=false;
                root.transform.localScale=Vector3.one;root.transform.localRotation=Quaternion.identity;
                ReplaceVisual(root,d,asset);
                if(d.Kind=="arrow")RegistryProjectiles.Configure(data,d);
                var marker=root.AddComponent<RegistryItemMarker>();marker.ItemId=d.Id;marker.Kind=d.Kind;marker.AssetId=asset;marker.Version=d.Int("version");
                var view=root.GetComponent<ZNetView>();if(!view)throw new InvalidOperationException("Native item network lifecycle missing.");view.m_persistent=true;
                if(!ItemManager.Instance.AddItem(item))throw new InvalidOperationException("Jotunn rejected item identity.");
                root.SetActive(true);registered.Add(d.Id,root);
            }
            catch{PrefabManager.Instance.DestroyPrefab(d.Prefab);throw;}
        }
        float Weight(ItemDefinition d)
        {
            if(d.Kind!="trapper_bundle")return Math.Max(0,d.Number("weight"));
            if(!(d.Stats["contents"] is JObject contents))throw new InvalidOperationException("Bundle has no fixed contents.");
            float total=0;
            foreach(var pair in contents)
            {
                var native=PrefabManager.Instance.GetPrefab(pair.Key);var drop=native?native.GetComponent<ItemDrop>():null;
                if(!drop||pair.Value.Type!=JTokenType.Integer||pair.Value.Value<int>()<1)throw new InvalidOperationException("Bundle native content missing: "+pair.Key);
                total+=drop.m_itemData.m_shared.m_weight*pair.Value.Value<int>();
            }
            if(float.IsNaN(total)||float.IsInfinity(total)||total<=0)throw new InvalidOperationException("Invalid native bundle weight.");
            return total;
        }
        static string Description(ItemDefinition d)
        {
            return RegistryDescriptions.Build(d,id=>
            {
                var native=PrefabManager.Instance.GetPrefab(id);var drop=native?native.GetComponent<ItemDrop>():null;
                return drop&&Localization.instance!=null?Localization.instance.Localize(drop.m_itemData.m_shared.m_name):id;
            });
        }
        void ApplyStats(ItemDefinition d,ItemDrop.ItemData.SharedData s,ItemDrop.ItemData.SharedData native)
        {
            s.m_food=0;s.m_foodStamina=0;s.m_foodEitr=0;s.m_foodBurnTime=0;s.m_foodRegen=0;s.m_consumeStatusEffect=null;
            s.m_useDurability=false;s.m_destroyBroken=false;s.m_canBeReparied=false;s.m_maxDurability=0;s.m_durabilityPerLevel=0;
            s.m_damages=new HitData.DamageTypes();s.m_damagesPerLevel=new HitData.DamageTypes();s.m_attackStatusEffect=null;
            s.m_blockPower=0;s.m_blockPowerPerLevel=0;s.m_deflectionForce=0;s.m_deflectionForcePerLevel=0;
            s.m_timedBlockBonus=1;s.m_itemType=ItemDrop.ItemData.ItemType.Material;
            if(d.Kind=="food")
            {
                s.m_itemType=ItemDrop.ItemData.ItemType.Consumable;s.m_isDrink=false;
                s.m_food=d.Stat("health");s.m_foodStamina=d.Stat("stamina");s.m_foodEitr=d.Stat("eitr");s.m_foodBurnTime=d.Stat("duration");s.m_foodRegen=d.Stat("foodRegen",1);
            }
            else if(d.Kind=="arrow")
            {
                s.m_itemType=ItemDrop.ItemData.ItemType.Ammo;s.m_ammoType=native.m_ammoType;
                s.m_damages.m_pierce=d.Stat("pierce");s.m_attackForce=d.Stat("knockback");
                // Native ArrowWood projectile behavior and flight remain intact.
            }
            else if(d.Kind=="healing_potion")
            {
                if(!(native.m_consumeStatusEffect is SE_Stats original))throw new InvalidOperationException("Native healing mead effect unavailable.");
                var effect=Object.Instantiate(original);effect.name="WF_Healing_"+d.Id;effect.m_name=d.Name;effect.m_icon=s.m_icons[0];
                effect.m_healthUpFront=d.Stat("instantHealth");effect.m_healthOverTime=0;effect.m_healthPerTick=0;effect.m_healthOverTimeDuration=0;
                effect.m_ttl=d.Stat("cooldown",120);effect.m_cooldown=effect.m_ttl;
                // Preserve the native category so all healing meads and all nine
                // Wayfarer potion identities exclude each other during recovery.
                if(string.IsNullOrEmpty(effect.m_category))throw new InvalidOperationException("Native healing cooldown category is empty.");
                if(!ItemManager.Instance.AddStatusEffect(new CustomStatusEffect(effect,false)))throw new InvalidOperationException("Healing effect registration failed.");
                s.m_itemType=ItemDrop.ItemData.ItemType.Consumable;s.m_isDrink=true;s.m_consumeStatusEffect=effect;
            }
            else if(d.Kind=="ring")s.m_itemType=(ItemDrop.ItemData.ItemType)200;
            else if(d.Kind=="talisman")s.m_itemType=ItemDrop.ItemData.ItemType.Trinket;
            else if(d.Kind=="mantle")s.m_itemType=ItemDrop.ItemData.ItemType.Utility;
            else if(d.Kind=="handbell")
            {
                s.m_itemType=ItemDrop.ItemData.ItemType.Shield;s.m_attack=null;s.m_secondaryAttack=null;
                s.m_skillType=Skills.SkillType.ElementalMagic;s.m_equipDuration=.2f;
            }
            else if(d.Kind=="torch")
            {
                // This weapon always occupies the left hand, even without a
                // main-hand weapon. Its attacks are the own offhand actions.
                s.m_itemType=ItemDrop.ItemData.ItemType.Shield;s.m_skillType=Skills.SkillType.Clubs;
                s.m_attack=null;s.m_secondaryAttack=null;s.m_useDurability=true;s.m_canBeReparied=true;
                s.m_maxDurability=d.Stat("durability",200);s.m_durabilityPerLevel=d.Stat("durabilityPerQuality",50);
                s.m_durabilityDrain=0;s.m_useDurabilityDrain=native.m_useDurabilityDrain; // Infinite burn time; ordinary combat wear/repair remains.
                s.m_damages.m_blunt=d.Stat("blunt");s.m_damages.m_fire=d.Stat("fire");s.m_damages.m_spirit=d.Stat("spirit");
                s.m_damagesPerLevel.m_blunt=d.Stat("bluntPerQuality");s.m_damagesPerLevel.m_fire=d.Stat("firePerQuality");s.m_damagesPerLevel.m_spirit=d.Stat("spiritPerQuality");
                s.m_movementModifier=d.Stat("movementModifier");s.m_attackForce=d.Stat("knockback");
            }
            if(IsRestored(d))ApplyEquipmentStats(d,s);
        }
        static void ApplyEquipmentStats(ItemDefinition d,ItemDrop.ItemData.SharedData s)
        {
            string hand=d.Stats.Value<string>("handedness");
            // ShieldBanded supplies the offhand lifecycle only. Its Blocking
            // skill must not drive the censer's Clubs damage/cost calculations.
            if(d.Kind=="censer")s.m_skillType=Skills.SkillType.Clubs;
            s.m_itemType=d.Kind=="shield"||hand=="offhand"?ItemDrop.ItemData.ItemType.Shield:hand=="two_hand"?ItemDrop.ItemData.ItemType.TwoHandedWeapon:ItemDrop.ItemData.ItemType.OneHandedWeapon;
            s.m_useDurability=true;s.m_canBeReparied=true;s.m_maxDurability=d.Stat("durability",200);s.m_durabilityPerLevel=d.Stat("durabilityPerQuality",50);
            s.m_blockPower=d.Stat("blockPower");s.m_blockPowerPerLevel=d.Stat("blockPowerPerQuality");s.m_timedBlockBonus=d.Stat("parryMultiplier",1);
            s.m_deflectionForce=d.Stat("blockKnockback");s.m_movementModifier=d.Stat("movementModifier");s.m_attackForce=d.Stat("knockback");
            s.m_damages.m_blunt=d.Stat("blunt");s.m_damages.m_slash=d.Stat("slash");s.m_damages.m_pierce=d.Stat("pierce");s.m_damages.m_spirit=d.Stat("spirit");
            if(s.m_damages.m_blunt>0)s.m_damagesPerLevel.m_blunt=d.Stat("physicalDamagePerQuality");
            else if(s.m_damages.m_slash>0)s.m_damagesPerLevel.m_slash=d.Stat("physicalDamagePerQuality");
            else if(s.m_damages.m_pierce>0)s.m_damagesPerLevel.m_pierce=d.Stat("physicalDamagePerQuality");
            s.m_damagesPerLevel.m_spirit=d.Stat("spiritPerQuality");
            if(s.m_attack!=null){s.m_attack.m_attackStamina=d.Stat("stamina");s.m_attack.m_staggerMultiplier=d.Stat("staggerMultiplier",1);}
            if(s.m_secondaryAttack!=null&&d.Stats["secondary"] is JObject secondary)
            {
                s.m_secondaryAttack.m_attackStamina=d.Stat("stamina")*(secondary.Value<float?>("staminaMultiplier")??1);
                s.m_secondaryAttack.m_damageMultiplier=secondary.Value<float?>("damageMultiplier")??secondary.Value<float?>("bluntMultiplier")??1;
            }
        }
        static void ReplaceVisual(GameObject root,ItemDefinition d,string asset)
        {
            foreach(var lod in root.GetComponentsInChildren<LODGroup>(true))Object.DestroyImmediate(lod);
            foreach(var child in root.transform.Cast<Transform>().ToArray())Object.DestroyImmediate(child.gameObject);
            foreach(var r in root.GetComponents<Renderer>())Object.DestroyImmediate(r);
            foreach(var mesh in root.GetComponents<MeshFilter>())Object.DestroyImmediate(mesh);
            foreach(var collider in root.GetComponents<Collider>())Object.DestroyImmediate(collider);
            var box=root.AddComponent<BoxCollider>();box.size=new Vector3(.08f,.08f,.08f);
            var body=root.GetComponent<Rigidbody>()??root.AddComponent<Rigidbody>();body.isKinematic=false;body.useGravity=true;
            var attach=new GameObject("attach");attach.layer=root.layer;attach.transform.SetParent(root.transform,false);
            var mount=attach.AddComponent<RegistryVisualMount>();mount.AssetId=asset;mount.MayBeHeld=IsRestored(d)||d.Kind=="handbell"||d.Kind=="torch";
            mount.GroundOnly=d.IsJewelry||d.Kind=="mantle";
            var hover=new GameObject("WF_ItemHover");hover.layer=root.layer;hover.transform.SetParent(root.transform,false);var trigger=hover.AddComponent<SphereCollider>();trigger.isTrigger=true;trigger.radius=.15f;
        }
        public void RegisterQualityRecipes()
        {
            var stationObject=PrefabManager.Instance.GetPrefab("forge");var station=stationObject?stationObject.GetComponent<CraftingStation>():null;
            if(!station)return;
            foreach(var d in catalogue.Items.Values.Where(HasForgeRecipe))
            {
                if(!IsRegistered(d.Id)||recipes.Contains(d.Id))continue;
                string fragment=d.Stats.Value<string>("forgeFragmentId");
                if(!TryPrefab(fragment,out var material))continue;
                var costs=(d.Stats["forgeQualityFragmentCosts"] as JArray)?.Values<int>().ToArray();
                if(costs==null||costs.Length!=3||costs.Any(x=>x<1))throw new InvalidOperationException("Missing approved Q2–Q4 fragment costs: "+d.Id);
                var recipe=ScriptableObject.CreateInstance<Recipe>();recipe.name="Recipe_"+d.Prefab;recipe.m_item=registered[d.Id].GetComponent<ItemDrop>();recipe.m_amount=1;
                recipe.m_enabled=true;recipe.m_noCraftOnlyUpgrade=true;recipe.m_craftingStation=station;recipe.m_repairStation=station;recipe.m_minStationLevel=(int)d.Stat("minimumRepairStationLevel",1);
                var requirement=new Piece.Requirement{m_resItem=material.GetComponent<ItemDrop>(),m_amount=0,m_amountPerLevel=1,m_recover=false};
                recipe.m_resources=new[]{requirement};RegistryQualityRules.Bind(requirement,costs);
                if(!ItemManager.Instance.AddRecipe(new CustomRecipe(recipe,false,false)))throw new InvalidOperationException("Quality recipe rejected: "+d.Id);
                recipes.Add(d.Id);
            }
            RegisterBellRecipes();
        }
        void RegisterBellRecipes()
        {
            var obj=PrefabManager.Instance.GetPrefab("UpgradeStation");var station=obj?obj.GetComponent<CraftingStation>():null;
            if(!station||!station.m_upgrader||station.m_name!=RegistryBellUpgradeRules.StationName)throw new InvalidOperationException("Actual native Forge of Potential unavailable.");
            foreach(var d in catalogue.Items.Values.Where(x=>x.Kind=="handbell"))
            {
                if(!IsRegistered(d.Id)||recipes.Contains(d.Id))continue;
                string pattern=d.Stats.Value<string>("matchingPatternId");
                if(!TryPrefab(pattern,out var material))throw new InvalidOperationException("Matching bell pattern not registered: "+pattern);
                var recipe=ScriptableObject.CreateInstance<Recipe>();recipe.name="Recipe_"+d.Prefab;recipe.m_item=registered[d.Id].GetComponent<ItemDrop>();recipe.m_amount=1;
                recipe.m_enabled=true;recipe.m_noCraftOnlyUpgrade=true;recipe.m_craftingStation=station;recipe.m_minStationLevel=1;
                var requirement=new Piece.Requirement{m_resItem=material.GetComponent<ItemDrop>(),m_amount=0,m_amountPerLevel=1,m_upgraderResource=true,m_recover=false};
                recipe.m_resources=new[]{requirement};RegistryQualityRules.Bind(requirement,new[]{1,1,1});
                if(!ItemManager.Instance.AddRecipe(new CustomRecipe(recipe,false,false)))throw new InvalidOperationException("Bell upgrade recipe rejected: "+d.Id);
                recipes.Add(d.Id);log?.Invoke("BELL_UPGRADE_REGISTERED "+d.Id+" station=UpgradeStation chance="+material.GetComponent<ItemDrop>().m_itemData.m_shared.m_upgradeChance+" breakChance=0 maxQuality=4");
            }
        }
        sealed class EquipmentSource {public string Prefab,AssetId;}
    }

    public sealed class RegistryItemMarker:MonoBehaviour
    {public string ItemId,Kind,AssetId;public int Version;}

    // Native dropped prefabs contain attach; native equipped visuals clone just
    // that child. Choose the mounting rule at instance time, not on the template.
    public sealed class RegistryVisualMount:MonoBehaviour
    {
        public string AssetId;public bool MayBeHeld,GroundOnly;
        void Start()
        {
            var drop=GetComponentInParent<ItemDrop>();if(GroundOnly&&!drop)return;
            var deferred=gameObject.AddComponent<DeferredItemVisual>();
            deferred.AssetId=AssetId;deferred.Held=MayBeHeld&&!drop;
            if(drop&&ItemsPlugin.Instance&&ItemsPlugin.Instance.AssetsReady)
            {
                try{var bounds=ItemsPlugin.Instance.Visuals.Bounds(AssetId);var box=drop.GetComponent<BoxCollider>();if(box){box.center=bounds.center;box.size=new Vector3(Mathf.Max(.01f,bounds.size.x),Mathf.Max(.01f,bounds.size.y),Mathf.Max(.01f,bounds.size.z));}}
                catch(Exception e){ItemsPlugin.Instance.Warn("ITEM_COLLIDER_FAILED "+AssetId+" "+e.Message);}
            }
        }
    }
}
