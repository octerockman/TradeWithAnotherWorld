using System;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    public sealed class JewelleryAction
    {
        public long id; public Player player; public Attack attack;
        public bool physical,spell,secondary,positivePaidEitr,lowEitr,confirmed,hitAttempted;
        public float momentumBonus;public bool thirdBeatReady;
        public string returnedBlowEnemy;public bool rooftopSampled,rooftopBonus;
        public Vector3 castOrigin;public double started;public int customReleaseFrame=-1;public bool ended;
        public readonly HashSet<string> confirmedTargets=new HashSet<string>(StringComparer.Ordinal);
    }
    public static class JewelleryCombat
    {
        static long counter=DateTime.UtcNow.Ticks;
        static readonly Dictionary<long,JewelleryAction> actions=new Dictionary<long,JewelleryAction>();
        static readonly Dictionary<string,double> enemyAttackAttempts=new Dictionary<string,double>(StringComparer.Ordinal);
        static readonly HashSet<string> killHealed=new HashSet<string>(StringComparer.Ordinal);
        [ThreadStatic]public static int NativeDotDepth;
        [ThreadStatic]public static bool ReprieveHealing;
        public static bool FirstScarReady;
        static float previousMax;
        public static void ResetSession(){actions.Clear();enemyAttackAttempts.Clear();killHealed.Clear();FirstScarReady=false;previousMax=0;JewelleryBorrowedSpark.Reset();}
        public static void ReleaseCustomAction(Player p,long id){if(actions.TryGetValue(id,out var a)&&a.player==p&&a.attack==null){a.customReleaseFrame=Time.frameCount;if(a.physical&&!a.rooftopSampled){a.rooftopSampled=true;a.rooftopBonus=JewelleryCuratedCombat.SampleAirborneRelease(p);}}}
        public static bool CustomSpellWindupOrRelease(Player p)=>actions.Values.Any(a=>a.player==p&&a.attack==null&&a.spell&&!a.ended&&(a.customReleaseFrame<0||a.customReleaseFrame==Time.frameCount)&&JewelleryRuntime.Now-a.started<10);
        public static long BeginAction(Player player,Attack attack,bool secondary=false,float eitrBeforePayment=-1)
        {
            if(!player||player!=Player.m_localPlayer||attack==null)return 0;
            var state=JewelleryRuntime.State(player);double now=JewelleryRuntime.Now;
            foreach(var id in actions.Where(p=>now-p.Value.started>20).Select(p=>p.Key).ToArray())actions.Remove(id);
            bool spell=JewelleryRuntime.IsSpell(attack);var a=new JewelleryAction{id=++counter,player=player,attack=attack,physical=JewelleryRuntime.IsPhysicalMelee(attack),spell=spell,secondary=secondary,castOrigin=player.transform.position,started=now};
            a.positivePaidEitr=spell&&attack.GetAttackEitr(player,attack.GetWeapon())>0;a.lowEitr=a.positivePaidEitr&&eitrBeforePayment>0&&eitrBeforePayment<=player.GetMaxEitr()*.25f;
            a.momentumBonus=now-state.lastMeleeHit<=3?Math.Min(3,state.momentum)*.03f:0;a.thirdBeatReady=state.thirdBeatCount>=2&&now-state.lastMeleeHit<=6&&state.Ready("ds3_third_beat",now);
            if(a.physical){if(now<=state.followupUntil)a.returnedBlowEnemy=state.followupEnemy;state.followupEnemy=null;state.followupUntil=0;if(!secondary)state.cooldownDeadlines.Remove("afterturn_opportunity_expires");}
            actions[a.id]=a;return a.id;
        }
        public static long BeginCustomAction(Player player,bool physicalMelee,bool spell,bool positivePaidEitr,float eitrBeforePayment,bool secondary=false)
        {
            if(!player||player!=Player.m_localPlayer)return 0;var state=JewelleryRuntime.State(player);double now=JewelleryRuntime.Now;
            foreach(var id in actions.Where(p=>now-p.Value.started>20).Select(p=>p.Key).ToArray())actions.Remove(id);
            var a=new JewelleryAction{id=++counter,player=player,physical=physicalMelee,spell=spell,secondary=secondary,positivePaidEitr=positivePaidEitr,lowEitr=positivePaidEitr&&eitrBeforePayment>0&&eitrBeforePayment<=player.GetMaxEitr()*.25f,castOrigin=player.transform.position,started=now,momentumBonus=now-state.lastMeleeHit<=3?Math.Min(3,state.momentum)*.03f:0,thirdBeatReady=state.thirdBeatCount>=2&&now-state.lastMeleeHit<=6&&state.Ready("ds3_third_beat",now)};
            if(physicalMelee){if(now<=state.followupUntil)a.returnedBlowEnemy=state.followupEnemy;state.followupEnemy=null;state.followupUntil=0;if(!secondary)state.cooldownDeadlines.Remove("afterturn_opportunity_expires");}
            actions[a.id]=a;return a.id;
        }
        public static void ModifyOutgoingHit(Player player,long actionId,Character target,HitData hit)
        {
            if(!actions.TryGetValue(actionId,out var action)||action.player!=player||hit==null||!JewelleryRuntime.Hostile(target,player)||target.IsDead())return;
            var s=JewelleryRuntime.For(player);var state=JewelleryRuntime.State(player);float physical=0,directSpell=0,spirit=0,pierceOnly=0;
            if(action.physical&&!hit.m_ranged)
            {
                physical+=s.Value("physicalDamageBonus");var ai=target.GetComponent<BaseAI>();if(ai&&!ai.IsAlerted())physical+=s.Value("unawareOpeningPhysicalBonus");
                if(s.Has("er_t_unbroken_thread"))physical+=action.momentumBonus;
                if(s.Has("er_t_slow_iron")&&JewelleryCuratedCombat.IsCuratedSlowSecondary(action)&&!action.hitAttempted)physical+=.12f;
                if(action.rooftopBonus)physical+=.10f;
                if(s.Has("ds3_briar_point")&&hit.m_damage.m_pierce>0&&JewelleryCuratedCombat.InterceptWindup(action,target))pierceOnly+=.12f;
                if(s.Has("ds3_third_beat")&&action.thirdBeatReady&&!action.hitAttempted)physical+=.12f;
                if(s.Has("er_t_returned_blow")&&action.returnedBlowEnemy==target.GetZDOID().ToString())physical+=.12f;
                float modifier=1+JewelleryMath.Cap(physical,.4f);hit.m_damage.m_blunt*=modifier;hit.m_damage.m_slash*=modifier;hit.m_damage.m_pierce*=1+JewelleryMath.Cap(physical+pierceOnly,.4f);
                if(s.Has("sd_ashsealed_ring"))hit.m_damage.m_fire+=state.SpendFire(JewelleryRuntime.Now);
                if(s.Has("md_hollow_knuckle")&&hit.m_skill.ToString()=="Unarmed")hit.m_staggerMultiplier*=1.2f;
                action.hitAttempted=true;
            }
            else if(action.spell)
            {
                if(s.Has("ms_last_syllable")&&action.lowEitr)directSpell+=.12f;
                if(s.Has("ms_distant_witness")&&Vector3.Distance(action.castOrigin,target.transform.position)>=15)directSpell+=.1f;
                if(s.Has("ms_pale_refrain")&&enemyAttackAttempts.TryGetValue(target.GetZDOID().ToString(),out double attempt)&&JewelleryRuntime.Now-attempt<=5)spirit+=.1f;
                float main=1+JewelleryMath.Cap(directSpell,.4f),holy=1+JewelleryMath.Cap(directSpell+spirit,.4f);
                hit.m_damage.m_blunt*=main;hit.m_damage.m_slash*=main;hit.m_damage.m_pierce*=main;hit.m_damage.m_fire*=main;hit.m_damage.m_frost*=main;hit.m_damage.m_lightning*=main;hit.m_damage.m_spirit*=holy;
                if(s.Has("ms_closewritten_sigil")&&Vector3.Distance(action.castOrigin,target.transform.position)<=6)hit.m_staggerMultiplier*=1.15f;
                // Poison and deferred native burning pools are never multiplied
                // again here. Native cast metadata must identify direct impacts.
            }
        }
        public static void ConfirmPhysicalHit(Player player,long actionId,string targetId,float actualPhysicalDamage,bool fatal,bool blocked,bool causedNewStagger)
        {
            if(!actions.TryGetValue(actionId,out var a)||a.player!=player||!a.physical||!player||player!=Player.m_localPlayer||actualPhysicalDamage<=0)return;
            var s=JewelleryRuntime.For(player);var state=JewelleryRuntime.State(player);double now=JewelleryRuntime.Now;
            if(!a.confirmed&&!blocked)
            {
                if(now-state.lastMeleeHit>3)state.momentum=0;
                state.momentum=s.Has("er_t_unbroken_thread")?Math.Min(3,state.momentum+1):0;
                if(now-state.lastMeleeHit>6)state.thirdBeatCount=0;state.thirdBeatCount=s.Has("ds3_third_beat")?state.thirdBeatCount+1:0;
                if(state.thirdBeatCount>=3){state.thirdBeatCount=0;if(s.Has("ds3_third_beat")&&a.thirdBeatReady)state.Cooldown("ds3_third_beat",now,10);}
                state.lastMeleeHit=now;a.confirmed=true;
            }
            if(s.Has("md_pursuit_thread")&&causedNewStagger&&state.Ready("md_pursuit_thread",now)){state.Cooldown("md_pursuit_thread",now,12);state.pursuitExpires=now+4;}
            if(s.Has("md_witness_seal")){float heal=state.Reclaim(actualPhysicalDamage,player.GetMaxHealth()-player.GetHealth(),now);if(heal>0){ReprieveHealing=true;try{player.Heal(heal,true);}finally{ReprieveHealing=false;}}}
            if(fatal&&s.Has("er_t_hearthcut_cameo")&&killHealed.Add(targetId))player.Heal(5,true);
            if(player.GetHealth()>=player.GetMaxHealth())state.ClearWound();
        }
        public static void EndAction(Player player,long actionId)
        {if(actions.TryGetValue(actionId,out var a)&&a.player==player){a.ended=true;if(!a.confirmed&&a.physical){var s=JewelleryRuntime.State(player);if(s!=null){s.momentum=0;s.thirdBeatCount=0;}}}}
        public static void Released(Attack attack)
        {
            foreach(var a in actions.Values)if(ReferenceEquals(a.attack,attack)&&a.physical&&!a.rooftopSampled){a.rooftopSampled=true;a.rooftopBonus=JewelleryCuratedCombat.SampleAirborneRelease(a.player);}
        }
        public static void ConfirmBlock(Player player,string enemyId,bool successful,bool parried,bool magicalProjectile,bool ranged=false)
        {
            if(!successful||player!=Player.m_localPlayer)return;var s=JewelleryRuntime.For(player);var state=JewelleryRuntime.State(player);double now=JewelleryRuntime.Now;
            if(!ranged&&!magicalProjectile&&s.Has("er_t_returned_blow")){state.followupEnemy=enemyId;state.followupUntil=now+1.2;}
            if(parried&&s.Has("ds3_afterturn")&&state.Ready("ds3_afterturn",now)){state.Cooldown("ds3_afterturn",now,8);state.Cooldown("afterturn_opportunity_expires",now,3);}
            if(parried&&magicalProjectile&&s.Has("ms_empty_chalice"))player.AddEitr(4);
        }
        public static void NotifyEnemyAttackAttempt(Player player,string enemyId){if(player==Player.m_localPlayer)enemyAttackAttempts[enemyId]=JewelleryRuntime.Now;}
        public static void Tick(Player player)
        {
            if(!player||player!=Player.m_localPlayer)return;var s=JewelleryRuntime.For(player);var state=JewelleryRuntime.State(player);float max=player.GetMaxHealth();
            FirstScarReady=s.Has("er_t_first_scar")&&state.QualifyFirstScar(player.GetHealthPercentage(),max,Math.Abs(max-previousMax)>.001f,JewelleryRuntime.Now);previousMax=max;
        }
        public static float FinalHealthDamage(float normal,Character victim,HitData hit)
        {
            var p=victim as Player;if(!p||p!=Player.m_localPlayer||hit==null)return normal;
            var s=JewelleryRuntime.For(p);bool dot=NativeDotDepth>0;var context=JewelleryDotProvenance.Current;
            if(dot)
            {
                float hostile=context!=null&&context.player==p?context.HostileFraction(hit):0;
                return normal*JewelleryMath.MixedDotHealthScale(hostile,s.Value("hostileDotDamageReduction"),s.Value("enemyDamageTakenBonus"));
            }
            if(!JewelleryRuntime.Hostile(hit.GetAttacker(),p))return normal;
            float physical=hit.m_damage.GetTotalPhysicalDamage(),all=hit.GetTotalDamage();float projectileReduction=!dot&&hit.m_ranged&&all>0?s.Value("hostileProjectilePhysicalReduction")*physical/all:0;
            float scar=!dot&&FirstScarReady&&p.GetHealthPercentage()>=.95f&&Math.Abs(p.GetMaxHealth()-previousMax)<.001f?.15f:0;
            return normal*JewelleryMath.HealthMitigation(projectileReduction,scar)*(1+s.Value("enemyDamageTakenBonus"));
        }
    }
    [HarmonyPatch(typeof(Character),"ApplyDamage")]
    static class JewelleryDamageConsumerPatch
    {
        static void Prefix(Character __instance,out float __state){__state=__instance.GetHealth();}
        static void Postfix(Character __instance,HitData __0,float __state)
        {
            var p=__instance as Player;if(!p||p!=Player.m_localPlayer)return;bool dot=JewelleryCombat.NativeDotDepth>0;var ctx=JewelleryDotProvenance.Current;
            bool directHostile=JewelleryRuntime.Hostile(__0.GetAttacker(),p);float hostileFraction=dot&&ctx!=null&&ctx.player==p?ctx.HostileFraction(__0):0;
            if(!directHostile&&hostileFraction<=0)return;
            float lost=Math.Max(0,__state-p.GetHealth());var s=JewelleryRuntime.For(p);var state=JewelleryRuntime.State(p);
            if(p.IsDead()){state.ResetTransient();return;}
            if(lost>0&&!dot&&directHostile&&s.Has("md_witness_seal"))state.NewWound(lost,JewelleryRuntime.Now);
            if(lost>0)
            {
                float total=__0.GetTotalDamage();float fireShare=dot&&ctx!=null?JewelleryMath.MixedDotHostileFireShare(ctx.HostileFireFraction(__0),hostileFraction,s.Value("hostileDotDamageReduction"),s.Value("enemyDamageTakenBonus")):total>0?__0.m_damage.m_fire/total:0;
                float fireLost=lost*fireShare;if(fireLost>0){if(s.Has("sd_ashsealed_ring"))state.ReceiveFire(fireLost,JewelleryRuntime.Now);JewelleryRuntime.HostileFireHealthLost?.Invoke(p,fireLost);}
            }
        }
        static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            var get=AccessTools.Method(typeof(HitData),"GetTotalDamage");var modify=AccessTools.Method(typeof(JewelleryCombat),"FinalHealthDamage");
            foreach(var code in instructions){yield return code;if(code.Calls(get)){yield return new CodeInstruction(OpCodes.Ldarg_0);yield return new CodeInstruction(OpCodes.Ldarg_1);yield return new CodeInstruction(OpCodes.Call,modify);}}
        }
    }
    [HarmonyPatch(typeof(Character),"Heal")]
    static class JewelleryOrdinaryHealingPatch
    {static void Prefix(Character __instance,out float __state){__state=__instance.GetHealth();}static void Postfix(Character __instance,float __state){var p=__instance as Player;if(p&&p==Player.m_localPlayer&&!JewelleryCombat.ReprieveHealing){var s=JewelleryRuntime.State(p);s.OrdinaryHeal(Math.Max(0,p.GetHealth()-__state),JewelleryRuntime.Now);if(p.GetHealth()>=p.GetMaxHealth())s.ClearWound();}}}
    [HarmonyPatch(typeof(SE_Burning),"UpdateStatusEffect")]
    static class JewelleryBurningSourcePatch{static void Prefix(){JewelleryCombat.NativeDotDepth++;}static void Finalizer(){JewelleryCombat.NativeDotDepth=Math.Max(0,JewelleryCombat.NativeDotDepth-1);}}
    [HarmonyPatch(typeof(SE_Poison),"UpdateStatusEffect")]
    static class JewelleryPoisonSourcePatch{static void Prefix(){JewelleryCombat.NativeDotDepth++;}static void Finalizer(){JewelleryCombat.NativeDotDepth=Math.Max(0,JewelleryCombat.NativeDotDepth-1);}}
}
