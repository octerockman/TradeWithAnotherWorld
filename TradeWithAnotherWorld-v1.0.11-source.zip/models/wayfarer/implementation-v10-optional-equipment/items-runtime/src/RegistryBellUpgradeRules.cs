using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;

namespace Wayfarer.Items
{
    // The native upgrader has its own success/failure route. It removes and
    // recreates ItemData, and bypasses ordinary max-Q filtering. Preserve our
    // state markers on that replacement and enforce the ceiling before costs.
    [HarmonyPatch(typeof(InventoryGui),"DoCrafting")]
    public static class RegistryBellUpgradeRules
    {
        public const string StationName="$piece_upgradestation";
        static readonly FieldInfo UpgradeItem=AccessTools.Field(typeof(InventoryGui),"m_craftUpgradeItem");
        static readonly MethodInfo InventoryChanged=AccessTools.Method(typeof(Inventory),"Changed",new[]{typeof(bool),typeof(bool)});
        public sealed class UpgradeSnapshot
        {public ItemDrop.ItemData Original;public string Prefab;public int X,Y;public Dictionary<string,string> CustomData;}
        static bool Prefix(InventoryGui __instance,Player player,out UpgradeSnapshot __state)
        {
            __state=null;
            var plugin=ItemsPlugin.Instance;
            var item=UpgradeItem?.GetValue(__instance) as ItemDrop.ItemData;
            if(!plugin||item==null||!plugin.Catalogue.TryItem(item,out var d)||d.Kind!="handbell")return true;
            if(!RegistryBellUpgradePolicy.CanAttempt(item.m_quality))
            {player?.Message(MessageHud.MessageType.Center,"This handbell is already at its highest quality.");return false;}
            var station=player?player.GetCurrentCraftingStation():null;
            if(!station||!station.m_upgrader||station.m_name!=StationName)
            {player?.Message(MessageHud.MessageType.Center,"Upgrade this handbell at the Forge of Potential.");return false;}
            __state=new UpgradeSnapshot{Original=item,Prefab=d.Prefab,X=item.m_gridPos.x,Y=item.m_gridPos.y,CustomData=RegistryBellUpgradePolicy.Snapshot(item.m_customData)};
            return true;
        }
        static void Postfix(Player player,UpgradeSnapshot __state)
        {
            if(__state==null||!player)return;var inventory=player.GetInventory();
            if(inventory.ContainsItem(__state.Original))return;
            var replacement=inventory.GetAllItems().FirstOrDefault(i=>i.m_dropPrefab&&i.m_dropPrefab.name==__state.Prefab&&i.m_gridPos.x==__state.X&&i.m_gridPos.y==__state.Y);
            if(replacement==null){ItemsPlugin.Instance?.Warn("BELL_UPGRADE_STATE_RESTORE_MISSING "+__state.Prefab);return;}
            if(replacement.m_customData==null)replacement.m_customData=new Dictionary<string,string>();
            RegistryBellUpgradePolicy.Restore(__state.CustomData,replacement.m_customData);
            InventoryChanged?.Invoke(inventory,new object[]{true,false}); // success, no cheated-state change
        }
    }
}
