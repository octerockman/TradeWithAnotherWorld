using System;
using System.Reflection;
using System.Reflection.Emit;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using HarmonyLib;

namespace Wayfarer.Items
{
    public static class JewelleryBorrowedSpark
    {
        [ThreadStatic]static Attack starting;
        [ThreadStatic]static Player owner;
        [ThreadStatic]static float pendingExtra,pendingEitr;
        sealed class Reservation{public Player player;}
        static ConditionalWeakTable<Attack,Reservation> reservations=new ConditionalWeakTable<Attack,Reservation>();
        public static void Reset(){reservations=new ConditionalWeakTable<Attack,Reservation>();pendingExtra=0;pendingEitr=0;}
        static readonly MethodInfo health=AccessTools.Method(typeof(Attack),"GetAttackHealth"),staminaCost=AccessTools.Method(typeof(Attack),"GetAttackStamina");
        public sealed class Scope { public Attack attack;public Player player;public float extra,eitr; }
        public static Scope Enter(Attack a,Humanoid actor)
        {
            var old=new Scope{attack=starting,player=owner,extra=pendingExtra,eitr=pendingEitr};
            starting=a;owner=actor as Player;pendingExtra=0;pendingEitr=0;return old;
        }
        public static void Leave(Scope old){starting=old.attack;owner=old.player;pendingExtra=old.extra;pendingEitr=old.eitr;}
        static bool Eligible(Player p,float eitrCost,float staminaCost,float healthCost,out float additional)
        {
            additional=0;var s=JewelleryRuntime.State(p);
            return p&&p==Player.m_localPlayer&&!p.IsDead()&&JewelleryRuntime.For(p).Has("sd_borrowed_spark_band")&&s!=null&&JewelleryMath.BorrowedSpark(eitrCost,staminaCost,healthCost,p.GetEitr(),p.GetMaxEitr(),p.GetStamina(),s.Ready("sd_borrowed_spark_band",JewelleryRuntime.Now),out additional);
        }
        public static bool TryReplaceNativePayment(Character actor,float cost)
        {
            if(actor!=owner||!owner||starting==null||!JewelleryRuntime.IsSpell(starting))return false;
            float stamina=(float)staminaCost.Invoke(starting,null),hp=(float)health.Invoke(starting,null);
            if(!Eligible(owner,cost,stamina,hp,out float extra))return false;
            // Native Attack.Start checks ammunition after TryUseEitr. Reserve this
            // conversion but debit only when that exact native start succeeds.
            pendingExtra=extra;pendingEitr=owner.GetEitr();return true;
        }
        public static void CommitNative(bool started)
        {
            if(!started||!owner||pendingExtra<=0)return;
            // Despite its name, native TryUseEitr only checks affordability.
            // The actual debit occurs later in Update/FireProjectileBurst.
            reservations.Remove(starting);reservations.Add(starting,new Reservation{player=owner});pendingExtra=0;
        }
        public static bool HaveBurstEitr(Character actor,float cost,Attack attack)
        {
            if(actor.HaveEitr(cost))return true;var p=actor as Player;
            if(!JewelleryRuntime.IsSpell(attack)||!Eligible(p,cost,0,(float)health.Invoke(attack,null),out _))return false;
            reservations.Remove(attack);reservations.Add(attack,new Reservation{player=p});return true;
        }
        public static bool PayNativeEitr(Character actor,float cost,Attack attack)
        {
            if(!reservations.TryGetValue(attack,out var r)||actor!=r.player){actor.UseEitr(cost);return true;}
            reservations.Remove(attack);var p=r.player;
            if(p.GetEitr()>=cost){p.UseEitr(cost);return true;}
            // Native normal stamina has already been paid immediately before
            // this call; only the additional conversion must remain affordable.
            if(!Eligible(p,cost,0,(float)health.Invoke(attack,null),out float extra)){attack.Stop();return false;}
            p.UseEitr(p.GetEitr());p.UseStamina(extra);JewelleryRuntime.State(p).Cooldown("sd_borrowed_spark_band",JewelleryRuntime.Now,12);JewelleryRuntime.Save();return true;
        }
        // Custom spell adapters call only when the ordinary eitr check failed.
        // This pays ALL normal stamina plus conversion cost, and all remaining
        // eitr, exactly once. A false result has no side effects.
        public static bool CanPayCustomCast(Player p,float eitrCost,float staminaCost,float healthCost)=>Eligible(p,eitrCost,staminaCost,healthCost,out _);
        public static bool TryPayCustomCast(Player p,float eitrCost,float staminaCost,float healthCost)
        {
            if(!Eligible(p,eitrCost,staminaCost,healthCost,out float extra))return false;
            p.UseEitr(p.GetEitr());p.UseStamina(staminaCost+extra);
            JewelleryRuntime.State(p).Cooldown("sd_borrowed_spark_band",JewelleryRuntime.Now,12);JewelleryRuntime.Save();return true;
        }
    }
    [HarmonyPatch(typeof(Attack),"Start")]
    static class JewelleryBorrowedSparkStartScope
    {
        static void Prefix(Attack __instance,Humanoid __0,out JewelleryBorrowedSpark.Scope __state){__state=JewelleryBorrowedSpark.Enter(__instance,__0);}
        static void Postfix(bool __result){JewelleryBorrowedSpark.CommitNative(__result);}
        static Exception Finalizer(Exception __exception,JewelleryBorrowedSpark.Scope __state){JewelleryBorrowedSpark.Leave(__state);return __exception;}
    }
    [HarmonyPatch(typeof(Character),"TryUseEitr")]
    static class JewelleryBorrowedSparkEitrPayment
    {static bool Prefix(Character __instance,float __0,ref bool __result){if(!JewelleryBorrowedSpark.TryReplaceNativePayment(__instance,__0))return true;__result=true;return false;}}
    [HarmonyPatch]
    static class JewelleryBorrowedSparkActualNativePayment
    {
        static IEnumerable<MethodBase> TargetMethods(){yield return AccessTools.Method(typeof(Attack),"Update");yield return AccessTools.Method(typeof(Attack),"FireProjectileBurst");}
        static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions,ILGenerator generator,MethodBase __originalMethod)
        {
            var use=AccessTools.Method(typeof(Character),"UseEitr",new[]{typeof(float)});var have=AccessTools.Method(typeof(Character),"HaveEitr",new[]{typeof(float)});
            foreach(var code in instructions)
            {
                if(code.Calls(have)){var load=new CodeInstruction(OpCodes.Ldarg_0);load.labels.AddRange(code.labels);yield return load;yield return new CodeInstruction(OpCodes.Call,AccessTools.Method(typeof(JewelleryBorrowedSpark),"HaveBurstEitr"));continue;}
                if(code.Calls(use))
                {
                    var load=new CodeInstruction(OpCodes.Ldarg_0);load.labels.AddRange(code.labels);yield return load;yield return new CodeInstruction(OpCodes.Call,AccessTools.Method(typeof(JewelleryBorrowedSpark),"PayNativeEitr"));
                    var success=generator.DefineLabel();yield return new CodeInstruction(OpCodes.Brtrue,success);
                    // Update retains native InAttack() beneath the resource call.
                    // Its normal tail stores that bool; an early return must discard it.
                    if(__originalMethod.Name=="Update")yield return new CodeInstruction(OpCodes.Pop);
                    yield return new CodeInstruction(OpCodes.Ret);var next=new CodeInstruction(OpCodes.Nop);next.labels.Add(success);yield return next;continue;
                }
                yield return code;
            }
        }
    }
}
