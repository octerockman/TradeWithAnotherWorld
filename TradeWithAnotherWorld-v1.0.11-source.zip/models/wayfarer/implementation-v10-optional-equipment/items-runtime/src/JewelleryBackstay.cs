using System;
using System.Reflection;
using System.Reflection.Emit;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    public static class JewelleryBackstay
    {
        [ThreadStatic]static ItemDrop.ItemData shield;
        [ThreadStatic]public static bool ActiveRearBlock;
        public static bool Eligible(Humanoid actor,HitData hit,Character attacker)
        {
            var p=actor as Player;if(!p||p!=Player.m_localPlayer||hit==null||hit.m_ranged||!p.IsBlocking()||!JewelleryRuntime.Hostile(attacker,p)||!JewelleryRuntime.For(p).Has("sd_backstay_signet")||Vector3.Dot(hit.m_dir,p.transform.forward)<=0)return false;
            var held=JewelleryRuntime.HeldLeft(p);return held!=null&&held.m_shared.m_itemType==ItemDrop.ItemData.ItemType.Shield&&(!held.m_shared.m_useDurability||held.m_durability>0)&&p.GetStamina()>0&&hit.m_damage.GetTotalPhysicalDamage()>0&&hit.m_damage.GetTotalDamage()-hit.m_damage.GetTotalPhysicalDamage()<.0001f;
        }
        public sealed class Scope{public ItemDrop.ItemData shield;public bool rear;}
        public static Scope Enter(Humanoid actor,HitData hit,Character attacker)
        {var old=new Scope{shield=shield,rear=ActiveRearBlock};ActiveRearBlock=Eligible(actor,hit,attacker);shield=ActiveRearBlock?JewelleryRuntime.HeldLeft((Player)actor):null;return old;}
        public static void Leave(Scope old){shield=old.shield;ActiveRearBlock=old.rear;}
        public static float Direction(float dot)=>ActiveRearBlock?-Math.Abs(dot):dot;
        public static float ParryTimer(float timer)=>ActiveRearBlock?-1:timer;
        public static float Power(ItemDrop.ItemData item,float value)=>ActiveRearBlock&&ReferenceEquals(item,shield)?value*.25f:value;
    }
    [HarmonyPatch(typeof(Humanoid),"BlockAttack")]
    static class JewelleryRearBlockConsumer
    {
        [HarmonyPriority(Priority.First)]
        static void Prefix(Humanoid __instance,HitData __0,Character __1,out JewelleryBackstay.Scope __state){__state=JewelleryBackstay.Enter(__instance,__0,__1);}
        static Exception Finalizer(Exception __exception,JewelleryBackstay.Scope __state){JewelleryBackstay.Leave(__state);return __exception;}
        static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            var dot=AccessTools.Method(typeof(Vector3),"Dot",new[]{typeof(Vector3),typeof(Vector3)});var timer=AccessTools.Field(typeof(Humanoid),"m_blockTimer");bool directionDone=false;
            foreach(var code in instructions)
            {
                yield return code;
                if(!directionDone&&code.Calls(dot)){yield return new CodeInstruction(OpCodes.Call,AccessTools.Method(typeof(JewelleryBackstay),"Direction"));directionDone=true;}
                if(code.opcode==OpCodes.Ldfld&&Equals(code.operand,timer))yield return new CodeInstruction(OpCodes.Call,AccessTools.Method(typeof(JewelleryBackstay),"ParryTimer"));
            }
            if(!directionDone)throw new InvalidOperationException("Native BlockAttack angle consumer changed; Backstay cannot be admitted.");
        }
    }
    [HarmonyPatch(typeof(ItemDrop.ItemData),"GetBlockPower",new[]{typeof(float)})]
    static class JewelleryRearBlockPower
    {static void Postfix(ItemDrop.ItemData __instance,ref float __result){__result=JewelleryBackstay.Power(__instance,__result);}}
}
