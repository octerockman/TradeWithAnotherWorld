using System;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
using Newtonsoft.Json.Linq;
using Wayfarer.InGame;
using Object=UnityEngine.Object;

namespace Wayfarer.Items
{
    public sealed class MantleSkinPayload
    {
        public string schema,itemId;public string[] boneNames,bonePaths;
        public float[] rendererLocalPosition,rendererLocalRotation,rendererLocalScale;
        public RendererRecord renderer;
    }
    public static class MantleSkin
    {
        public const string ItemId="cinderveil_mantle",AssetId="mantle-model-v10",PrefabName="TWA_WF_cinderveil_mantle";
        static MantleSkinPayload payload;static Mesh mesh;static Material[] materials;
        static string sourceHash;
        static bool Near(float a,float b)=>Math.Abs(a-b)<.00001f;
        static void CheckBody(SkinnedMeshRenderer body)
        {
            if(!body||!body.sharedMesh||!body.rootBone)throw new InvalidDataException("Native player body skin is missing.");
            var bones=body.bones;var poses=body.sharedMesh.bindposes;
            if(bones.Length!=payload.boneNames.Length||poses.Length!=bones.Length)throw new InvalidDataException("Mantle requires the exact native53-bone body order.");
            for(int i=0;i<bones.Length;i++)
            {
                if(!bones[i]||bones[i].name!=payload.boneNames[i])throw new InvalidDataException("Native mantle bone order changed at "+i);
                var recorded=PayloadReader.M(payload.renderer.bindposes[i]);
                for(int r=0;r<4;r++)for(int c=0;c<4;c++)if(!Near(poses[i][r,c],recorded[r,c]))throw new InvalidDataException("Native mantle bind matrix changed at "+i);
            }
            // This asset is authored in this body's renderer-local space.
            if((body.transform.localPosition-PayloadReader.V(payload.rendererLocalPosition)).sqrMagnitude>1e-8f||Quaternion.Angle(body.transform.localRotation,PayloadReader.Q(payload.rendererLocalRotation))>.001f||(body.transform.localScale-PayloadReader.V(payload.rendererLocalScale)).sqrMagnitude>1e-6f)throw new InvalidDataException("Native mantle renderer-local transform changed.");
        }
        static void Load(ItemsPlugin plugin)
        {
            if(payload!=null)return;
            string folder=Path.Combine(plugin.DataDirectory,"assets","mantle");
            var manifest=RuntimeCatalogue.ReadJson(Path.Combine(folder,"manifest.json"),1024*1024);
            var rec=manifest["payload"]??throw new InvalidDataException("Mantle manifest has no skin payload.");
            string path=PayloadReader.Safe(folder,rec.Value<string>("path"));sourceHash=rec.Value<string>("sha256");
            if(sourceHash?.Length!=64||PayloadReader.Hash(path)!=sourceHash)throw new InvalidDataException("Mantle skin hash changed.");
            var p=PayloadReader.Read<MantleSkinPayload>(path);var r=p?.renderer;
            if(p?.schema!="wayfarer.mantle-native-player-skin.v1"||p.itemId!=ItemId||p.boneNames?.Length!=53||p.boneNames.Distinct().Count()!=53||r==null||r.vertices?.Length%3!=0||r.vertices.Length<9||r.vertices.Length>30000||r.normals?.Length!=r.vertices.Length||r.uv?.Length!=r.vertices.Length/3*2||r.weights?.Length!=r.vertices.Length/3||r.bindposes?.Length!=53||r.triangles?.Length%3!=0||r.triangles.Length<3||r.triangles.Length>30000||r.triangles.Any(x=>x<0||x>=r.vertices.Length/3)||r.vertices.Concat(r.normals).Concat(r.uv).Any(x=>!PayloadReader.Finite(x)))throw new InvalidDataException("Invalid mantle mesh/bone budget.");
            foreach(var w in r.weights)if(w?.indices?.Length!=4||w.weights?.Length!=4||w.indices.Any(x=>x<0||x>=53)||w.weights.Any(x=>!PayloadReader.Finite(x)||x<0||x>1)||Math.Abs(w.weights.Sum()-1)>.0001f)throw new InvalidDataException("Invalid mantle skin weights.");
            foreach(var b in r.bindposes)PayloadReader.M(b);
            payload=p;
        }
        static void Prepare(ItemsPlugin plugin,SkinnedMeshRenderer body)
        {
            Load(plugin);CheckBody(body);if(mesh)return;
            var r=payload.renderer;int n=r.vertices.Length/3;var positions=new Vector3[n];var normals=new Vector3[n];var uv=new Vector2[n];var colors=new Color32[n];
            for(int i=0;i<n;i++){positions[i]=new Vector3(r.vertices[i*3],r.vertices[i*3+1],r.vertices[i*3+2]);normals[i]=new Vector3(r.normals[i*3],r.normals[i*3+1],r.normals[i*3+2]);uv[i]=new Vector2(r.uv[i*2],r.uv[i*2+1]);colors[i]=new Color32(255,255,255,255);}
            var candidate=new Mesh{name="WF_Cinderveil_Native53",indexFormat=IndexFormat.UInt16,vertices=positions,normals=normals,uv=uv,colors32=colors,triangles=r.triangles};
            candidate.bindposes=body.sharedMesh.bindposes;
            candidate.boneWeights=r.weights.Select(w=>new BoneWeight{boneIndex0=w.indices[0],boneIndex1=w.indices[1],boneIndex2=w.indices[2],boneIndex3=w.indices[3],weight0=w.weights[0],weight1=w.weights[1],weight2=w.weights[2],weight3=w.weights[3]}).ToArray();
            candidate.RecalculateBounds();candidate.RecalculateTangents();
            var staging=new GameObject("WF_Mantle_MaterialAdmission");staging.SetActive(false);
            try
            {
                plugin.Visuals.Attach(AssetId,staging.transform,body.gameObject.layer,false);
                var render=staging.GetComponentInChildren<MeshRenderer>(true);
                if(!render||render.sharedMaterials.Length!=1||!render.sharedMaterials[0])throw new InvalidDataException("Admitted mantle material is unavailable.");
                materials=render.sharedMaterials;mesh=candidate;
            }
            catch{Object.Destroy(candidate);throw;}
            finally{Object.Destroy(staging);}
        }
        public static GameObject Attach(ItemsPlugin plugin,SkinnedMeshRenderer nativeBody)
        {
            Prepare(plugin,nativeBody);
            var root=new GameObject("WF_Cinderveil_UtilitySkin");root.SetActive(false);root.layer=nativeBody.gameObject.layer;
            root.transform.SetParent(nativeBody.transform.parent,false);
            root.transform.localPosition=nativeBody.transform.localPosition;root.transform.localRotation=nativeBody.transform.localRotation;root.transform.localScale=nativeBody.transform.localScale;
            var skin=root.AddComponent<SkinnedMeshRenderer>();skin.sharedMesh=mesh;skin.sharedMaterials=materials;skin.bones=nativeBody.bones;skin.rootBone=nativeBody.rootBone;
            var bounds=mesh.bounds;bounds.Expand(.0015f);skin.localBounds=bounds;skin.quality=SkinQuality.Bone4;skin.updateWhenOffscreen=true;skin.shadowCastingMode=ShadowCastingMode.On;skin.receiveShadows=true;
            root.SetActive(true);return root;
        }
        public static void Dispose(){if(mesh)Object.Destroy(mesh);mesh=null;materials=null;payload=null;sourceHash=null;}
    }
}
