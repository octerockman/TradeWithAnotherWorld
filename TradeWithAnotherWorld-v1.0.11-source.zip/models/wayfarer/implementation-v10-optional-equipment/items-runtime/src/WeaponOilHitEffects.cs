using System;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
namespace Wayfarer.Items
{
    public static class WeaponOilHitEffects
    {
        public static void Confirmed(Character victim,CombatHitMetadata metadata,OwnerHitScope proof)
        {
            if(!victim||!victim.IsOwner()||!metadata.directMelee||proof.physicalLost<=0||string.IsNullOrEmpty(metadata.coating)||!ItemsPlugin.Instance.Catalogue.TryItem(metadata.coating,out var oil))return;
            var attacker=proof.originalHit.GetAttacker() as Player;if(!attacker||!JewelleryRuntime.Hostile(victim,attacker))return;
            WeaponOilVisuals.Hit(oil,proof.originalHit.m_point);if(victim.IsDead())return;
            string family=oil.Stats.Value<string>("oilFamily");
            if(family=="bloodletting"&&Bleedable(victim))OwnedCombatEffects.Budget(victim,oil.Stat("woundDamage"),oil.Stat("woundDuration",4),proof.originalHit,"bloodletting",3);
            if(family=="ether_rot")
            {var effect=victim.GetComponent<WeaponOilSuppression>()??victim.gameObject.AddComponent<WeaponOilSuppression>();effect.Hit(oil);}
        }
        public static bool Bleedable(Character target)
        {
            // Use the creature's actual blood response rather than treating
            // skeletons, constructs and elemental creatures as flesh.
            var field=AccessTools.Field(typeof(Character),"m_hitEffects");var effects=field?.GetValue(target) as EffectList;
            return effects?.m_effectPrefabs?.Any(e=>e.m_prefab&&e.m_prefab.name.IndexOf("blood",StringComparison.OrdinalIgnoreCase)>=0)==true;
        }
        public static bool Suppressed(Character target)
        {var view=target?target.GetComponent<ZNetView>():null;return view&&view.IsValid()&&view.GetZDO().GetLong("twa_wf_silenced_until",0)>DateTime.UtcNow.Ticks;}
        public static bool Magical(ItemDrop.ItemData item)
        {
            if(item==null)return false;
            if(item.m_shared.m_skillType==Skills.SkillType.ElementalMagic||item.m_shared.m_skillType==Skills.SkillType.BloodMagic)return true;
            var damage=item.GetDamage();return item.m_shared.m_attack?.m_attackProjectile&&damage.GetTotalPhysicalDamage()<=0&&(damage.m_fire>0||damage.m_frost>0||damage.m_lightning>0||damage.m_poison>0||damage.m_spirit>0);
        }
        public static void Initialize(Harmony harmony)
        {
            var ai=AccessTools.TypeByName("BlackAbbey.CenserBrother.CenserAI");var instance=AccessTools.TypeByName("BlackAbbey.CenserBrother.CenserInstance");
            var begin=AccessTools.Method(ai,"Begin");var ember=AccessTools.Method(ai,"Ember");var sweep=AccessTools.Method(instance,"PublishSweep");
            if(begin!=null)harmony.Patch(begin,prefix:new HarmonyMethod(typeof(WeaponOilHitEffects),nameof(CenserBegin)));
            if(ember!=null)harmony.Patch(ember,prefix:new HarmonyMethod(typeof(WeaponOilHitEffects),nameof(CenserRelease)));
            if(sweep!=null)harmony.Patch(sweep,prefix:new HarmonyMethod(typeof(WeaponOilHitEffects),nameof(CenserRelease)));
            var abbot=AccessTools.TypeByName("BlackAbbey.Abbot.AbbotEncounterController")??AccessTools.TypeByName("BlackAbbey.BlindAbbot.AbbotEncounterController");
            if(abbot==null)foreach(var assembly in AppDomain.CurrentDomain.GetAssemblies())try{abbot=Array.Find(assembly.GetTypes(),t=>t.Name=="AbbotEncounterController");if(abbot!=null)break;}catch(ReflectionTypeLoadException){}
            if(abbot!=null)
            {foreach(string name in new[]{"AddPulse","ScheduleRuptures"}){var method=AccessTools.Method(abbot,name);if(method!=null)harmony.Patch(method,prefix:new HarmonyMethod(typeof(WeaponOilHitEffects),nameof(CenserRelease)));}var pattern=AccessTools.Method(abbot,"AddBellPattern");if(pattern!=null)harmony.Patch(pattern,prefix:new HarmonyMethod(typeof(WeaponOilHitEffects),nameof(AbbotPattern)));}
        }
        static bool AbbotPattern(Component __instance,object __0)
        {string kind=AccessTools.Field(__0.GetType(),"kind")?.GetValue(__0) as string;return kind!="cast"&&kind!="bellPulse"||!Suppressed(__instance.GetComponent<Character>());}
        static bool CenserBegin(Component __instance,object __0)=>Convert.ToInt32(__0)==1||!Suppressed(__instance.GetComponent<Character>());
        static bool CenserRelease(Component __instance)=>!Suppressed(__instance.GetComponent<Character>());
    }
    public sealed class WeaponOilSuppression:MonoBehaviour
    {
        readonly Queue<double> hits=new Queue<double>();Character target;ZNetView view;
        void Awake(){target=GetComponent<Character>();view=GetComponent<ZNetView>();}
        public void Hit(ItemDefinition oil)
        {
            if(!view||!view.IsValid()||!view.IsOwner()||!target||target.IsDead())return;
            long now=DateTime.UtcNow.Ticks;var z=view.GetZDO();if(z.GetLong("twa_wf_silence_recovery",0)>now)return;
            double time=Time.realtimeSinceStartupAsDouble;while(hits.Count>0&&time-hits.Peek()>oil.Stat("hitWindow",5))hits.Dequeue();hits.Enqueue(time);
            if(hits.Count<(int)oil.Stat("requiredHits",3))return;hits.Clear();
            z.Set("twa_wf_silenced_until",now+(long)(oil.Stat("suppressionDuration",2)*TimeSpan.TicksPerSecond));z.Set("twa_wf_silence_recovery",now+(long)(oil.Stat("targetRecovery",10)*TimeSpan.TicksPerSecond));
        }
        void Update(){if(!target||target.IsDead())Destroy(this);}
    }
    [HarmonyPatch(typeof(Humanoid),nameof(Humanoid.StartAttack))]
    static class WeaponOilNativeMagicSuppression
    {
        static bool Prefix(Humanoid __instance,ref bool __result)
        {if(__instance is Player||!WeaponOilHitEffects.Suppressed(__instance)||!WeaponOilHitEffects.Magical(__instance.GetCurrentWeapon()))return true;__result=false;return false;}
    }
}
