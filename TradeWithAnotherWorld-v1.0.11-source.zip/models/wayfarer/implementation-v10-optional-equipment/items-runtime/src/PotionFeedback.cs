using System;
using HarmonyLib;
using UnityEngine;
namespace Wayfarer.Items
{
    // Only the instances created for our instant-heal potions are accelerated.
    // The shared vanilla prefab, its audio, healing and cooldown are untouched.
    [HarmonyPatch(typeof(StatusEffect),"TriggerStartEffects")]
    public static class PotionFeedback
    {
        static void Postfix(StatusEffect __instance,GameObject[] ___m_startEffectInstances)
        {
            if(!__instance||!__instance.name.StartsWith("WF_Healing_",StringComparison.Ordinal)||___m_startEffectInstances==null)return;
            foreach(var root in ___m_startEffectInstances)if(root)foreach(var system in root.GetComponentsInChildren<ParticleSystem>(true))
            {var main=system.main;main.simulationSpeed*=2;}
        }
    }
}
