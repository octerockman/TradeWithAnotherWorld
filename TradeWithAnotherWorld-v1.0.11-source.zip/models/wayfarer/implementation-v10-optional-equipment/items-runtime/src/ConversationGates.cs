using System;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
namespace Wayfarer.Items
{
    public static class ConversationGates
    {
        static IEnumerable<string> Strings(JObject row,string key)=>row[key] is JArray a?a.Values<string>():Array.Empty<string>();
        public static bool CanOffer(CommerceWorldState state,CommerceCommission job)
            =>state!=null&&job!=null&&job.enabled&&!state.completed.Contains(job.id)&&state.highestBossLevel>=job.worldBossOfferMinimum&&job.requiresFlags.All(state.flags.Contains)&&job.requiresCommissions.All(state.completed.Contains)&&!job.forbidsFlags.Any(state.flags.Contains);
        public static bool HasDelivery(CommerceCommission job,CommerceProgress progress,IDictionary<string,long> inventory)
        {
            if(job==null||progress==null)return false;
            if(job.required.Any(p=>inventory.TryGetValue(p.Key,out long n)&&n>0&&(!progress.delivered.TryGetValue(p.Key,out int count)||count<p.Value)))return true;
            return job.deliveryGroups.Any(g=>g.allowedItemIds.Sum(k=>progress.delivered.TryGetValue(k,out int n)?n:0)<g.quantity&&g.allowedItemIds.Any(k=>inventory.TryGetValue(k,out long n)&&n>0&&(!progress.delivered.TryGetValue(k,out int delivered)||delivered<g.maximumPerType)));
        }
        public static bool Allowed(JObject action,CommerceWorldState state,IDictionary<string,long> inventory,Func<string,bool> knowledge)
        {
            if(action==null||state==null||inventory==null)return false;
            foreach(string key in new[]{"requiresCompletedCommissions","requiresCommissions"})if(!Strings(action,key).All(state.completed.Contains))return false;
            foreach(string key in new[]{"requiresAnyCompletedCommissions","requiresAnyCommissions"})if(action[key] is JArray groups)foreach(var group in groups.OfType<JArray>())if(!group.Values<string>().Any(state.completed.Contains))return false;
            if(!Strings(action,"requiresWorldFacts").All(state.flags.Contains))return false;
            foreach(string key in new[]{"requiresDialogueFlags","requiresDialogueKnowledge"})if(!Strings(action,key).All(knowledge))return false;
            if(action["requiresCarriedItems"] is JObject items)foreach(var p in items.Properties())if(!inventory.TryGetValue(p.Name,out long amount)||amount<p.Value.Value<int>())return false;
            string accepted=action.Value<string>("requiresAcceptedCommission");if(accepted!=null&&(!state.accepted.ContainsKey(accepted)||state.completed.Contains(accepted)))return false;
            if(action["requiresDeliveredItems"] is JObject delivered)
            {string job=action.Value<string>("jobId");if(job==null||!state.accepted.TryGetValue(job,out var progress))return false;foreach(var item in delivered.Properties())if(!progress.delivered.TryGetValue(item.Name,out int count)||count<item.Value.Value<int>())return false;}
            return true;
        }
    }
}
