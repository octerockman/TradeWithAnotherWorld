using System;
using System.Linq;
using System.Collections;
using HarmonyLib;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace Wayfarer.Items
{
    public static class SupplyUse
    {
        public static bool Repairing{get;private set;}
        public static int LocalDamageRevision{get;internal set;}
        public static bool OpenBundle(Player player,ItemDrop.ItemData item,ItemDefinition definition)
        {
            var plugin=ItemsPlugin.Instance;var inventory=player.GetInventory();
            var plan=new CommerceTransaction{requestId=Guid.NewGuid().ToString("N"),operation="open-bundle",stateAfter=new CommerceWorldState()};
            plan.inventory.Add(new CommerceDelta(definition.Id,-1));
            foreach(var property in definition.Stats["contents"].Children<JProperty>())plan.inventory.Add(new CommerceDelta(property.Name,property.Value.Value<int>()));
            string hash=CommerceInventory.Fingerprint(inventory,plugin.Definitions);
            bool applied=CommerceInventory.Apply(player,plugin.Definitions,plan,hash,out string error);
            player.Message(MessageHud.MessageType.Center,applied?"Trapper's Bundle opened.":error);
            if(applied)RuntimeFacts.Record("trapper_bundle_opened");return applied;
        }
        public static void Repair(Player player,ItemDrop.ItemData kit,ItemDrop.ItemData target)
        {
            if(Repairing||!Eligible(target)||!player.GetInventory().ContainsItem(kit)||!player.GetInventory().ContainsItem(target))return;
            ItemsPlugin.Instance.StartCoroutine(RepairRoutine(player,kit,target));
        }
        public static bool Eligible(ItemDrop.ItemData item)=>item!=null&&item.m_shared.m_useDurability&&item.m_shared.m_canBeReparied&&item.m_durability<item.GetMaxDurability();
        static IEnumerator RepairRoutine(Player player,ItemDrop.ItemData kit,ItemDrop.ItemData target)
        {
            Repairing=true;Vector3 position=player.transform.position;int damaged=LocalDamageRevision;float end=Time.time+6;
            player.Message(MessageHud.MessageType.Center,"Repairing "+Localization.instance.Localize(target.m_shared.m_name)+"… Stay still.");
            bool interrupted=false;
            while(Time.time<end)
            {
                if(!player||player.IsDead()||Vector3.Distance(position,player.transform.position)>.1f||player.InAttack()||player.IsDodgeInvincible()||LocalDamageRevision!=damaged){interrupted=true;break;}
                yield return null;
            }
            try
            {
                if(interrupted||!player||!player.GetInventory().ContainsItem(kit)||!player.GetInventory().ContainsItem(target))
                {if(player)player.Message(MessageHud.MessageType.Center,"Repair interrupted. Your kit was kept.");yield break;}
                if(!ItemsPlugin.Instance.Catalogue.TryItem(kit,out var definition))yield break;
                var plan=new CommerceTransaction{requestId=Guid.NewGuid().ToString("N"),operation="repair-kit",stateAfter=new CommerceWorldState(),selectedInstanceId=CommerceInventory.Instance(target),fullyRepairSelectedInstance=true};
                plan.inventory.Add(new CommerceDelta(definition.Id,-1));var inv=player.GetInventory();
                bool applied=CommerceInventory.Apply(player,ItemsPlugin.Instance.Definitions,plan,CommerceInventory.Fingerprint(inv,ItemsPlugin.Instance.Definitions),out string error);
                player.Message(MessageHud.MessageType.Center,applied?"Fully repaired.":error);
            }
            finally{Repairing=false;}
        }
    }
    public static class RuntimeFacts
    {
        static string Key=>"twa_wayfarer_facts_v1_"+(ZNet.instance?ZNet.instance.GetWorldUID():0);
        static System.Collections.Generic.HashSet<string> Read(Player p)=>p.m_customData.TryGetValue(Key,out string raw)?Newtonsoft.Json.JsonConvert.DeserializeObject<System.Collections.Generic.HashSet<string>>(raw)??new System.Collections.Generic.HashSet<string>():new System.Collections.Generic.HashSet<string>();
        public static System.Collections.Generic.IEnumerable<string> Flags(Player p)=>p?Read(p):System.Array.Empty<string>();
        public static void Record(string flag)
        {var p=Player.m_localPlayer;if(!p)return;var facts=Read(p);if(facts.Add(flag))p.m_customData[Key]=Newtonsoft.Json.JsonConvert.SerializeObject(facts);if(NativeProgress.AllowedFacts.Contains(flag))ItemsPlugin.Instance?.Commerce.NativeFact(flag);}
        public static bool Have(Player p,string flag)=>p&&Read(p).Contains(flag);
    }
    [HarmonyPatch(typeof(Humanoid),nameof(Humanoid.UseItem))]
    static class CustomSupplyUse
    {
        static bool Prefix(Humanoid __instance,Inventory __0,ItemDrop.ItemData __1)
        {
            var plugin=ItemsPlugin.Instance;if(!plugin||__instance!=Player.m_localPlayer||__1==null)return true;
            if(!plugin.Catalogue.TryItem(__1,out var d))return true;
            var p=(Player)__instance;
            if(d.Kind=="trapper_bundle"){SupplyUse.OpenBundle(p,__1,d);return false;}
            if(d.Kind=="repair_kit"){WayfarerTradeUI.OpenRepairPicker(__1);return false;}
            if(d.Kind=="ring"){if(JewelleryRuntime.InRingSlot(__1)){if(!JewelleryRuntime.UnequipRing(p,__1))p.Message(MessageHud.MessageType.Center,"Make room in your bag to unequip this ring.");}else if(!JewelleryRuntime.EquipRing(p,__1))p.Message(MessageHud.MessageType.Center,"You can equip up to four different rings.");return false;}
            if(d.Kind=="oil"){WeaponOilUse.Use(p,__1,d);return false;}
            return true;
        }
    }
    [HarmonyPatch(typeof(Character),"ApplyDamage")]
    static class SupplyDamageInterrupt
    {
        static void Prefix(Character __instance,out float __state)=>__state=__instance.GetHealth();
        static void Postfix(Character __instance,float __state){if(__instance==Player.m_localPlayer&&__instance.GetHealth()<__state)SupplyUse.LocalDamageRevision++;}
    }
    [HarmonyPatch(typeof(Wayfarer.InGame.ApprovedLedgerReader),nameof(Wayfarer.InGame.ApprovedLedgerReader.Interact))]
    static class LedgerDiscovery
    {static void Postfix(Humanoid user,bool __result){if(__result&&user==Player.m_localPlayer)RuntimeFacts.Record("ledger_read");}}
}
