using System;
using System.Collections.Generic;
using Jotunn.Entities;
using Jotunn.Managers;
using UnityEngine;

namespace Wayfarer.Items
{
    public static class RegistryProjectiles
    {
        static readonly Dictionary<string,GameObject> owned=new Dictionary<string,GameObject>(StringComparer.Ordinal);
        static readonly Dictionary<string,Vector3> preparedTips=new Dictionary<string,Vector3>(StringComparer.Ordinal){
            {"grayflight_stage_0",new Vector3(.00166570081f,.375f,-.000832853548f)},
            {"grayflight_stage_1",new Vector3(.00332937529f,.375f,-.000831927871f)},
            {"grayflight_stage_2",new Vector3(.00330699561f,.375f,-.00165264623f)},
            {"grayflight_stage_3",new Vector3(.00206548395f,.37500003f,-.000825516123f)},
            {"grayflight_stage_4",new Vector3(0,.37499997f,-.000821893802f)},
            {"grayflight_stage_5",new Vector3(-.00577563606f,.375f,-.000824608433f)},
            {"grayflight_stage_6",new Vector3(.000826290518f,.37500003f,-.000824606628f)},
            {"grayflight_stage_7",new Vector3(-.000826445932f,.375f,-.000826423871f)},
            {"grayflight_stage_8",new Vector3(0,.375f,-.000828251010f)}};
        // Actual installed bow_projectile mesh point in its native+Z flight frame.
        // Source/contact measurement lives in checks/registration/native-projectile-station.json.
        public static readonly Vector3 NativeVisualTip=new Vector3(-.0055008002f,.0038556002f,.0324283157f);
        public static void Configure(ItemDrop.ItemData ammo,ItemDefinition definition)
        {
            if(definition.Kind!="arrow")return;
            if(!preparedTips.TryGetValue(definition.AssetId,out var ownTip))throw new InvalidOperationException("Prepared arrow point calibration missing.");
            var attack=ammo.m_shared.m_attack;var source=attack?.m_attackProjectile;
            if(!source||!source.GetComponent<Projectile>())throw new InvalidOperationException("Native ArrowWood projectile behavior missing.");
            if(owned.TryGetValue(definition.Id,out var prior)){attack.m_attackProjectile=prior;return;}
            var sourceProjectile=source.GetComponent<Projectile>();
            // The measured native source has neither override. Leave all native
            // Projectile fields intact; the root already faces its flight vector.
            if(sourceProjectile.m_visual||sourceProjectile.m_hideOnHit)throw new InvalidOperationException("Native arrow visual/contact contract changed; calibration needs review.");
            string id="TWA_WF_Flight_"+definition.Id;var manager=PrefabManager.Instance;
            if(manager.GetPrefab(id))throw new InvalidOperationException("Owned arrow flight identity already exists outside registry.");
            var clone=manager.CreateClonedPrefab(id,source);clone.SetActive(false);
            try
            {
                foreach(var renderer in clone.GetComponentsInChildren<Renderer>(true))renderer.enabled=false;
                var visual=new GameObject("WF_Grayflight_Visual");visual.layer=clone.layer;visual.transform.SetParent(clone.transform,false);
                var binding=visual.AddComponent<RegistryArrowFlightVisual>();binding.AssetId=definition.AssetId;binding.NativeTip=NativeVisualTip;binding.OwnTip=ownTip;
                manager.AddPrefab(new CustomPrefab(clone,false));clone.SetActive(true);owned.Add(definition.Id,clone);
                // Only the cloned ammo attack changes. Native ArrowWood and its
                // projectile, collision/raycast/gravity/hitcode and HitData stay untouched.
                attack.m_attackProjectile=clone;
            }
            catch{manager.DestroyPrefab(id);throw;}
        }
    }
    public sealed class RegistryArrowFlightVisual:MonoBehaviour
    {
        public string AssetId;public Vector3 NativeTip,OwnTip;
        void Start()
        {
            var plugin=ItemsPlugin.Instance;if(!plugin||!plugin.AssetsReady)return;
            try
            {
                var bounds=plugin.Visuals.Bounds(AssetId);
                if(bounds.size.y<.7f||bounds.size.y>1||bounds.size.y<=bounds.size.x*3)throw new InvalidOperationException("Prepared Grayflight point+Y contract changed.");
                var rotation=Quaternion.FromToRotation(Vector3.up,Vector3.forward);
                if(Mathf.Abs(bounds.max.y-OwnTip.y)>.00001f)throw new InvalidOperationException("Prepared Grayflight point calibration changed.");
                transform.localRotation=rotation;transform.localPosition=NativeTip-rotation*OwnTip;
                plugin.Visuals.Attach(AssetId,transform,gameObject.layer,false);
            }
            catch(Exception e){plugin.Warn("GRAYFLIGHT_FLIGHT_VISUAL_FAILED "+AssetId+" "+e.Message);}
        }
    }
}
