using System;
using System.Linq;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace Wayfarer.Items
{
    [HarmonyPatch(typeof(Humanoid),"GetAttackSpeedFactorMovement")]
    static class JewelleryCastingMovementPatch
    {
        static void Postfix(Humanoid __instance,ref float __result)
        {var p=__instance as Player;if(p&&JewelleryRuntime.IsSpell(JewelleryRuntime.CurrentAttack(p)))__result=JewelleryRuntime.CastingMovementFactor(p,__result);}
    }
    static class JewelleryGuardPressure
    {
        [ThreadStatic]public static Humanoid defender;
        [ThreadStatic]public static bool eligible;
    }
    [HarmonyPatch(typeof(Humanoid),"BlockAttack")]
    static class JewelleryGuardPressureScope
    {
        static void Prefix(Humanoid __instance,HitData __0,Character __1,out Tuple<Humanoid,bool> __state)
        {
            __state=Tuple.Create(JewelleryGuardPressure.defender,JewelleryGuardPressure.eligible);JewelleryGuardPressure.defender=__instance;JewelleryGuardPressure.eligible=false;
            var p=__1 as Player;if(!p||__0.m_ranged||__0.GetTotalPhysicalDamage()<=0||!JewelleryRuntime.Hostile(__instance,p)||!JewelleryRuntime.For(p).Has("sd_guardbreak_signet"))return;
            var shield=AccessTools.Method(typeof(Humanoid),"GetCurrentBlocker").Invoke(__instance,null) as ItemDrop.ItemData;
            JewelleryGuardPressure.eligible=shield!=null&&shield.m_shared.m_itemType==ItemDrop.ItemData.ItemType.Shield;
        }
        static Exception Finalizer(Exception __exception,Tuple<Humanoid,bool> __state){JewelleryGuardPressure.defender=__state.Item1;JewelleryGuardPressure.eligible=__state.Item2;return __exception;}
    }
    [HarmonyPatch(typeof(Character),"AddStaggerDamage")]
    static class JewelleryActualBlockPressurePatch
    {static void Prefix(Character __instance,ref float __0,HitData __2){if(__2==null&&__instance==JewelleryGuardPressure.defender&&JewelleryGuardPressure.eligible)__0*=1.15f;}}

    public static class JewellerySealedSip
    {
        public static readonly HashSet<string> EligiblePotionPrefabs=new HashSet<string>(new[]{"MeadFrostResist","MeadPoisonResist","BarleyWine","MeadStrength"},StringComparer.Ordinal);
        static readonly Dictionary<StatusEffect,float> normalDurations=new Dictionary<StatusEffect,float>();
        public static void AfterConsumed(Player p,ItemDrop.ItemData item,bool wornAtConsumption)
        {
            if(!p||p!=Player.m_localPlayer||!wornAtConsumption||!item?.m_dropPrefab||!EligiblePotionPrefabs.Contains(item.m_dropPrefab.name)||!item.m_shared.m_consumeStatusEffect)return;
            var effect=p.GetSEMan().GetStatusEffect(item.m_shared.m_consumeStatusEffect.NameHash());if(!effect||effect.m_ttl<=0)return;
            float normal=effect.m_ttl;if(normalDurations.TryGetValue(effect,out float previous)&&Math.Abs(normal-previous*1.15f)<.001f)normal=previous;
            normalDurations[effect]=normal;effect.m_ttl=normal*1.15f;
        }
        public static void Tick(Player p)
        {
            if(!p||p!=Player.m_localPlayer)return;bool keep=JewelleryRuntime.For(p).Has("ds3_sealed_sip");
            foreach(var pair in normalDurations.ToArray())
            {if(!pair.Key||pair.Key.IsDone()){normalDurations.Remove(pair.Key);continue;}if(!keep){pair.Key.m_ttl=Math.Min(pair.Key.m_ttl,pair.Value);normalDurations.Remove(pair.Key);}}
        }
    }
    [HarmonyPatch(typeof(Player),"ConsumeItem")]
    static class JewelleryPotionDurationPatch
    {
        static void Prefix(Player __instance,out bool __state){__state=JewelleryRuntime.For(__instance).Has("ds3_sealed_sip");}
        static void Postfix(Player __instance,ItemDrop.ItemData __1,bool __result,bool __state){if(__result)JewellerySealedSip.AfterConsumed(__instance,__1,__state);}
    }
}
