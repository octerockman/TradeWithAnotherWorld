using System;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;
using HarmonyLib;

namespace Wayfarer.Items
{
    public sealed class JewellerySnapshot
    {
        public readonly HashSet<string> ids=new HashSet<string>(StringComparer.Ordinal);
        public readonly Dictionary<string,float> values=new Dictionary<string,float>(StringComparer.Ordinal);
        public float Value(string key)=>values.TryGetValue(key,out float n)?n:0;
        public bool Has(string id)=>ids.Contains(id);
    }
    public static class JewelleryRuntime
    {
        public const int RingItemType=200;
        public static Action<Player,float> HostileFireHealthLost;
        public static readonly string[] RingSlots=Enumerable.Range(1,4).Select(i=>"TWA_WF_Ring"+i).ToArray();
        static bool initialized;
        public static bool Active=>initialized;
        static Player current;
        static float nextRefresh;
        static JewellerySnapshot equipped=new JewellerySnapshot();
        static JewelleryCombatState combat=new JewelleryCombatState();
        static readonly FieldInfo trinket=AccessTools.Field(typeof(Humanoid),"m_trinketItem");
        static readonly FieldInfo attack=AccessTools.Field(typeof(Humanoid),"m_currentAttack");
        static readonly FieldInfo rightItem=AccessTools.Field(typeof(Humanoid),"m_rightItem"),leftItem=AccessTools.Field(typeof(Humanoid),"m_leftItem");
        static readonly FieldInfo seCharacter=AccessTools.Field(typeof(SEMan),"m_character");
        public static readonly HashSet<string> NativeHooksReady=new HashSet<string>(new[]{
            "core_heartwood_band","core_long_road","core_peddlers_loop","core_steady_breath","core_lightstep","core_iron_resolve","core_stillwater","core_clear_thought","core_quiet_channel","core_patient_study",
            "st_highstep_band","md_bent_nail","md_anchor_debt","md_trembling_oak","md_menders_iron","md_low_lintel","md_unburdened_spur","ms_kept_vellum","ms_measured_breath","ms_anchored_letter",
            "st_softsole_ring","st_steady_helm_ring","st_wayside_eye","st_fair_harvest_band","st_patient_angler_ring","md_last_inch","md_cairn_thimble","md_hushed_bowstring","md_patient_windlass","ms_hushed_wick","sd_fletchkeeper_loop","sd_gatherers_luck_band","ds3_mistveil","ms_watchers_measure","ms_stillhand_signet","sd_bound_ward_ring","md_ashcatcher","md_saltglass_ward","sd_ashsealed_ring","core_red_edge","ms_wandering_verse","sd_guardbreak_signet","ds3_sealed_sip","sd_reedstep_band","sd_quick_release_band","sd_borrowed_spark_band","sd_backstay_signet","md_farcast_knot","ms_cinderline_band","ds3_bellwether","sd_siltwalker_loop"
        },StringComparer.Ordinal);
        public static void Init()
        {
            if(initialized)return;
            RingEquipmentBackend.Init(IsRing,item=>Definition(item,out var d)?d.Id:null);
            JewelleryDotProvenance.BindSource(()=>CombatReceipts.CurrentOriginalHit,()=>CombatReceipts.CurrentVictim);
            initialized=true;JewelleryWorldHints.Init();JewelleryAfterimage.Init();
        }
        public static void Dispose()
        {
            Save();JewelleryCombat.ResetSession();JewelleryFarcast.Cancel();JewelleryAfterimage.Dispose();JewelleryWorldHints.Dispose();RingEquipmentBackend.Dispose();
            initialized=false;current=null;equipped=new JewellerySnapshot();combat=new JewelleryCombatState();
        }
        static ItemDrop.ItemData SlotItem(string id)=>RingEquipmentBackend.SlotItem(Array.IndexOf(RingSlots,id));
        static bool Definition(ItemDrop.ItemData item,out ItemDefinition d){d=null;return item!=null&&ItemsPlugin.Instance?.Catalogue!=null&&ItemsPlugin.Instance.Catalogue.TryItem(item,out d);}
        public static bool IsRing(ItemDrop.ItemData item)=>Definition(item,out var d)&&d.Kind=="ring";
        public static bool InRingSlot(ItemDrop.ItemData item)=>RingEquipmentBackend.IsEquipped(Player.m_localPlayer,item);
        public static bool EquipRing(Player p,ItemDrop.ItemData item)
        {if(!initialized)Init();bool result=RingEquipmentBackend.Equip(p,item);if(result){nextRefresh=0;Tick(p);}return result;}
        public static bool UnequipRing(Player p,ItemDrop.ItemData item)
        {bool result=RingEquipmentBackend.Unequip(p,item);if(result){nextRefresh=0;Tick(p);}return result;}
        public static bool IsNativeReady(string id)=>NativeHooksReady.Contains(id);
        public static void EnableConfirmedCombatAdapters()
        {
            NativeHooksReady.UnionWith(new[]{"core_ambush","md_hollow_knuckle","md_pursuit_thread","md_witness_seal","ms_last_syllable","ms_distant_witness","ms_closewritten_sigil","ms_pale_refrain","ms_empty_chalice","ds3_third_beat","ds3_afterturn","er_t_returned_blow","er_t_unbroken_thread","er_t_hearthcut_cameo","er_t_first_scar","ds3_briar_point","er_t_slow_iron","er_t_rooftop_spur"});
        }
        public static Player PlayerFor(SEMan manager)=>seCharacter?.GetValue(manager) as Player;
        public static Attack CurrentAttack(Player player)=>attack?.GetValue(player) as Attack;
        public static ItemDrop.ItemData HeldRight(Player player)=>rightItem?.GetValue(player) as ItemDrop.ItemData;
        public static ItemDrop.ItemData HeldLeft(Player player)=>leftItem?.GetValue(player) as ItemDrop.ItemData;
        public static JewellerySnapshot For(Player player)
        {
            if(!player||player.IsDead())return new JewellerySnapshot();
            if(player!=Player.m_localPlayer)
            {
                var remote=new JewellerySnapshot();var view=player.GetComponent<ZNetView>();string value=view?.GetZDO()?.GetString("TWA_WF_EquippedJewellery_v1","")??"";
                foreach(string id in value.Split('|').Take(5))if(ItemsPlugin.Instance.Catalogue.TryItem(id,out var d)&&d.IsJewelry&&remote.ids.Add(id))foreach(var prop in d.Stats.Properties())if(prop.Value.Type==Newtonsoft.Json.Linq.JTokenType.Float||prop.Value.Type==Newtonsoft.Json.Linq.JTokenType.Integer){remote.values.TryGetValue(prop.Name,out float n);remote.values[prop.Name]=n+(float)prop.Value;}
                return remote;
            }
            if(current!=player||Time.unscaledTime>=nextRefresh)Tick(player);return equipped;
        }
        public static JewelleryCombatState State(Player player){For(player);return player==current?combat:null;}
        public static double Now=>DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()/1000.0;
        public static void Tick(Player player)
        {
            if(!initialized)Init();if(!player||player!=Player.m_localPlayer)return;
            if(current!=player){Save();JewelleryCombat.ResetSession();JewelleryFarcast.Cancel();current=player;combat=new JewelleryCombatState();Load();JewelleryRecovery.Ensure(player);JewelleryWaterSteps.Ensure(player);}
            if(Time.unscaledTime<nextRefresh)return;nextRefresh=Time.unscaledTime+.1f;
            RingEquipmentBackend.Normalize(player);
            var snapshot=new JewellerySnapshot();
            if(!player.IsDead())
            {
                foreach(var item in RingSlots.Select(SlotItem).Concat(new[]{trinket?.GetValue(player) as ItemDrop.ItemData}))
                {
                    if(!Definition(item,out var def)||!def.IsJewelry||!snapshot.ids.Add(def.Id))continue;
                    foreach(var prop in def.Stats.Properties())if(prop.Value.Type==Newtonsoft.Json.Linq.JTokenType.Float||prop.Value.Type==Newtonsoft.Json.Linq.JTokenType.Integer){snapshot.values.TryGetValue(prop.Name,out float before);snapshot.values[prop.Name]=before+(float)prop.Value;}
                }
            }
            if(equipped.Has("md_witness_seal")&&!snapshot.Has("md_witness_seal"))combat.ClearWound();
            if(equipped.Has("sd_ashsealed_ring")&&!snapshot.Has("sd_ashsealed_ring"))combat.storedFire=0;
            if(equipped.Has("er_t_unbroken_thread")&&!snapshot.Has("er_t_unbroken_thread"))combat.momentum=0;
            if(equipped.Has("ds3_third_beat")&&!snapshot.Has("ds3_third_beat"))combat.thirdBeatCount=0;
            if(equipped.Has("md_pursuit_thread")&&!snapshot.Has("md_pursuit_thread"))combat.pursuitExpires=0;
            if(equipped.Has("er_t_returned_blow")&&!snapshot.Has("er_t_returned_blow")){combat.followupEnemy=null;combat.followupUntil=0;}
            if(equipped.Has("ds3_afterturn")&&!snapshot.Has("ds3_afterturn"))combat.cooldownDeadlines.Remove("afterturn_opportunity_expires");
            if(player.IsDead())combat.ResetTransient();equipped=snapshot;
            var view=player.GetComponent<ZNetView>();if(view&&view.IsOwner())view.GetZDO()?.Set("TWA_WF_EquippedJewellery_v1",string.Join("|",snapshot.ids.OrderBy(x=>x,StringComparer.Ordinal)));
            JewelleryFarcast.Tick(player);JewelleryCombat.Tick(player);JewelleryBoundWard.Tick(player);JewellerySealedSip.Tick(player);
        }
        public static void Save()
        {
            if(!current)return;
            current.m_customData["TWA_WF_JewelleryCooldowns_v1"]=JsonConvert.SerializeObject(combat.cooldownDeadlines);
            current.m_customData["TWA_WF_WaterSteps_v1"]=combat.waterStepsRemaining.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }
        static void Load()
        {
            if(current.m_customData.TryGetValue("TWA_WF_JewelleryCooldowns_v1",out string json))try{foreach(var p in JsonConvert.DeserializeObject<Dictionary<string,double>>(json)??new Dictionary<string,double>())if(p.Value>Now&&p.Value<Now+86400)combat.cooldownDeadlines[p.Key]=p.Value;}catch(JsonException){ItemsPlugin.Instance?.Warn("Ignored malformed jewellery cooldown state.");}
            if(current.m_customData.TryGetValue("TWA_WF_WaterSteps_v1",out string steps)&&int.TryParse(steps,out int n))combat.waterStepsRemaining=Math.Max(0,Math.Min(4,n));combat.ResetTransient();
        }
        public static float CastingStamina(Player player,float normal)=>JewelleryMath.Cost(normal,For(player).Value("castStaminaReduction"));
        public static float CastingEitr(Player player,float normal)=>JewelleryMath.Cost(normal,For(player).Value("castEitrReduction"));
        public static float CastingMovementFactor(Player player,float normal)=>normal>0&&normal<1?1-(1-normal)*(For(player).Has("ms_wandering_verse")?.75f:1):normal;
        public static float DurabilityFactor(Player player,bool casting)=>JewelleryMath.Durability(For(player).Has("md_menders_iron"),For(player).Has("ms_kept_vellum"),casting);
        public static bool IsPhysicalMelee(Attack a)
        {if(a==null)return false;var weapon=a.GetWeapon();if(weapon==null)return false;string skill=weapon.m_shared.m_skillType.ToString();return new[]{"Swords","Knives","Clubs","Polearms","Spears","Axes","Unarmed"}.Contains(skill)&&!a.m_bowDraw&&!a.m_attackProjectile;}
        public static bool IsSpell(Attack a)
        {var w=a?.GetWeapon();return w!=null&&(w.m_shared.m_skillType==Skills.SkillType.ElementalMagic||w.m_shared.m_skillType==Skills.SkillType.BloodMagic);}
        public static bool Hostile(Character other,Player player)=>other&&player&&other!=player&&!other.IsPlayer()&&!other.IsTamed()&&BaseAI.IsEnemy(other,player);
        // Root's confirmed-native-hit adapter calls this only with actual damage
        // and one proven action identity. Event-only effects are not stock-ready
        // merely because their formulas exist here.
        public static float ReclaimConfirmedMelee(Player player,float actualPhysicalDamage,float missingHealth)
        {var s=State(player);return s!=null&&For(player).Has("md_witness_seal")?s.Reclaim(actualPhysicalDamage,missingHealth,Now):0;}
        public static float ConfirmedMeleeKillHealing(Player player)=>For(player).Has("er_t_hearthcut_cameo")?5:0;
        public static long BeginAction(Player player,Attack attack,bool secondary=false,float eitrBeforePayment=-1)=>JewelleryCombat.BeginAction(player,attack,secondary,eitrBeforePayment);
        public static long BeginCustomAction(Player player,bool physicalMelee,bool spell,bool positivePaidEitr,float eitrBeforePayment,bool secondary=false)=>JewelleryCombat.BeginCustomAction(player,physicalMelee,spell,positivePaidEitr,eitrBeforePayment,secondary);
        public static void ModifyOutgoingHit(Player player,long actionId,Character target,HitData hit)=>JewelleryCombat.ModifyOutgoingHit(player,actionId,target,hit);
        public static void ConfirmPhysicalHit(Player player,long actionId,string targetId,float actualPhysicalDamage,bool fatal,bool blocked,bool causedNewStagger)=>JewelleryCombat.ConfirmPhysicalHit(player,actionId,targetId,actualPhysicalDamage,fatal,blocked,causedNewStagger);
        public static void ConfirmBlock(Player player,string enemyId,bool successful,bool parried,bool magicalProjectile,bool ranged=false)=>JewelleryCombat.ConfirmBlock(player,enemyId,successful,parried,magicalProjectile,ranged);
        public static void NotifyEnemyAttackAttempt(Player player,string enemyId)=>JewelleryCombat.NotifyEnemyAttackAttempt(player,enemyId);
        public static void EndAction(Player player,long actionId)=>JewelleryCombat.EndAction(player,actionId);
        public static void ReleaseCustomAction(Player player,long actionId)=>JewelleryCombat.ReleaseCustomAction(player,actionId);
    }

    [HarmonyPatch(typeof(Player),"GetTotalFoodValue")]
    static class JewelleryMaximumsPatch
    {static void Postfix(Player __instance,ref float __0,ref float __1,ref float __2){var s=JewelleryRuntime.For(__instance);__0+=s.Value("maxHealth");__1+=s.Value("maxStamina");__2+=s.Value("maxEitr");}}
    [HarmonyPatch(typeof(Player),"GetMaxCarryWeight")]
    static class JewelleryCarryPatch{static void Postfix(Player __instance,ref float __result){__result+=JewelleryRuntime.For(__instance).Value("carryWeight");}}
    [HarmonyPatch(typeof(SEMan),"ModifyStaminaRegen")]
    static class JewelleryStaminaRegenPatch
    {static void Prefix(float __0,out float __state){__state=__0;}static void Postfix(SEMan __instance,ref float __0,float __state){__0=JewelleryMath.Regen(__state,__0,JewelleryRuntime.For(JewelleryRuntime.PlayerFor(__instance)).Value("staminaRegen"));}}
    [HarmonyPatch(typeof(SEMan),"ModifyEitrRegen")]
    static class JewelleryEitrRegenPatch
    {static void Prefix(float __0,out float __state){__state=__0;}static void Postfix(SEMan __instance,ref float __0,float __state){__0=JewelleryMath.Regen(__state,__0,JewelleryRuntime.For(JewelleryRuntime.PlayerFor(__instance)).Value("eitrRegen"));}}
    [HarmonyPatch(typeof(SEMan),"ModifyRunStaminaDrain")]
    static class JewelleryRunCostPatch{static void Postfix(SEMan __instance,ref float __1){__1=JewelleryMath.Cost(__1,JewelleryRuntime.For(JewelleryRuntime.PlayerFor(__instance)).Value("runStaminaReduction"));}}
    [HarmonyPatch(typeof(SEMan),"ModifyJumpStaminaUsage")]
    static class JewelleryJumpCostPatch{static void Postfix(SEMan __instance,ref float __1){__1=JewelleryMath.Cost(__1,JewelleryRuntime.For(JewelleryRuntime.PlayerFor(__instance)).Value("jumpStaminaReduction"));}}
    [HarmonyPatch(typeof(SEMan),"ModifyBlockStaminaUsage")]
    static class JewelleryBlockCostPatch{static void Postfix(SEMan __instance,ref float __1){__1=JewelleryMath.Cost(__1,JewelleryRuntime.For(JewelleryRuntime.PlayerFor(__instance)).Value("blockStaminaReduction"));}}
    [HarmonyPatch(typeof(SEMan),"ModifyDodgeStaminaUsage")]
    static class JewelleryDodgeCostPatch{static void Postfix(SEMan __instance,ref float __1){__1=JewelleryMath.Cost(__1,JewelleryRuntime.For(JewelleryRuntime.PlayerFor(__instance)).Value("dodgeStaminaReduction"));}}
    [HarmonyPatch(typeof(SEMan),"ApplyStatusEffectJumpMods")]
    static class JewelleryJumpHeightPatch{static void Postfix(SEMan __instance,ref Vector3 __0){__0.y=JewelleryMath.JumpVelocity(__0.y,JewelleryRuntime.For(JewelleryRuntime.PlayerFor(__instance)).Value("jumpHeightBonus"));}}
    [HarmonyPatch(typeof(Player),"GetBodyArmor")]
    static class JewelleryLowHealthArmorPatch{static void Postfix(Player __instance,ref float __result){var s=JewelleryRuntime.For(__instance);if(__instance.GetHealthPercentage()<s.Value("healthFractionBelow"))__result+=s.Value("conditionalArmor");}}
    [HarmonyPatch(typeof(SEMan),"ModifyFallDamage")]
    static class JewelleryFallPatch{static void Postfix(SEMan __instance,ref float __1){__1*=1-JewelleryRuntime.For(JewelleryRuntime.PlayerFor(__instance)).Value("fallDamageReduction");}}
    [HarmonyPatch(typeof(SEMan),"ModifyRaiseSkill")]
    static class JewellerySkillXpPatch
    {static void Postfix(SEMan __instance,Skills.SkillType __0,ref float __1){if(new[]{"Swords","Knives","Clubs","Polearms","Spears","Axes","Unarmed","Bows","Crossbows","ElementalMagic","BloodMagic","Blocking"}.Contains(__0.ToString()))__1*=1+JewelleryRuntime.For(JewelleryRuntime.PlayerFor(__instance)).Value("combatSkillXpBonus");}}
    [HarmonyPatch(typeof(Character),"AddStaggerDamage")]
    static class JewelleryIncomingStaggerPatch{static void Prefix(Character __instance,ref float __0,HitData __2){var p=__instance as Player;if(p&&JewelleryRuntime.Hostile(__2?.GetAttacker(),p))__0*=1-JewelleryRuntime.For(p).Value("incomingStaggerReduction");}}
    [HarmonyPatch(typeof(Character),"ApplyPushback",new[]{typeof(HitData)})]
    static class JewelleryPushbackPatch
    {static void Prefix(Character __instance,HitData __0,out float __state){__state=__0.m_pushForce;var p=__instance as Player;if(!p||!JewelleryRuntime.Hostile(__0.GetAttacker(),p))return;var s=JewelleryRuntime.For(p);float reduction=s.Value("enemyKnockbackReduction");var cast=JewelleryRuntime.CurrentAttack(p);if((JewelleryRuntime.IsSpell(cast)&&JewelleryWorldHints.WindupOrRelease(cast)||JewelleryCombat.CustomSpellWindupOrRelease(p))&&__0.m_damage.GetTotalPhysicalDamage()>0)reduction=1-(1-reduction)*(1-s.Value("castWindupReleasePhysicalPushbackReduction"));__0.m_pushForce*=1-reduction;}static void Postfix(HitData __0,float __state){__0.m_pushForce=__state;}}
    [HarmonyPatch(typeof(Player),"GetEquipmentMovementModifier")]
    static class JewelleryHeldPenaltyPatch
    {static void Postfix(Player __instance,ref float __result){var s=JewelleryRuntime.For(__instance);if(s.Has("md_unburdened_spur")){var right=JewelleryRuntime.HeldRight(__instance);var left=JewelleryRuntime.HeldLeft(__instance);float held=Math.Min(0,right?.m_shared.m_movementModifier??0)+Math.Min(0,left?.m_shared.m_movementModifier??0);__result-=held*.5f;}__result-=s.Value("groundMovementPenalty");}}
    [HarmonyPatch(typeof(Attack),"GetAttackEitr",new Type[0])]
    static class JewelleryCastEitrPatch{static void Postfix(Attack __instance,ref float __result){if(JewelleryRuntime.IsSpell(__instance)){var p=AccessTools.Field(typeof(Attack),"m_character").GetValue(__instance) as Player;__result=JewelleryRuntime.CastingEitr(p,__result);}}}
    [HarmonyPatch(typeof(Attack),"GetAttackStamina")]
    static class JewelleryCastStaminaPatch
    {static void Postfix(Attack __instance,ref float __result){var p=AccessTools.Field(typeof(Attack),"m_character").GetValue(__instance) as Player;if(JewelleryRuntime.IsSpell(__instance))__result=JewelleryRuntime.CastingStamina(p,__result);else if(p&&JewelleryAttackStartScope.PrimaryStart&&JewelleryRuntime.IsPhysicalMelee(__instance)&&JewelleryRuntime.For(p).Has("ds3_afterturn")&&JewelleryRuntime.State(p)?.cooldownDeadlines.TryGetValue("afterturn_opportunity_expires",out double until)==true&&until>JewelleryRuntime.Now)__result=JewelleryMath.Cost(__result,.2f);}}
    [HarmonyPatch(typeof(Humanoid),"StartAttack")]
    static class JewelleryAttackStartScope
    {[ThreadStatic]public static bool PrimaryStart;static void Prefix(bool __1,out bool __state){__state=PrimaryStart;PrimaryStart=!__1;}static Exception Finalizer(Exception __exception,bool __state){PrimaryStart=__state;return __exception;}}
    [HarmonyPatch(typeof(Player),"Save")]
    static class JewellerySavePatch{static void Prefix(Player __instance){if(__instance==Player.m_localPlayer)JewelleryRuntime.Save();}}
    [HarmonyPatch(typeof(Player),"OnDeath")]
    static class JewelleryDeathPatch{static void Prefix(Player __instance){if(__instance==Player.m_localPlayer){JewelleryCombat.ResetSession();JewelleryFarcast.Cancel();}JewelleryRuntime.State(__instance)?.ResetTransient();RingEquipmentBackend.ClearOnDeath(__instance);JewelleryRuntime.Save();}}
    [HarmonyPatch(typeof(Humanoid),"EquipItem")]
    static class JewelleryRingEquipPatch
    {static bool Prefix(Humanoid __instance,ItemDrop.ItemData __0,ref bool __result){if(!(__instance is Player p)||p!=Player.m_localPlayer||!JewelleryRuntime.IsRing(__0))return true;__result=JewelleryRuntime.EquipRing(p,__0);return false;}}
    [HarmonyPatch(typeof(Humanoid),"UnequipItem")]
    static class JewelleryRingUnequipPatch
    {static bool Prefix(Humanoid __instance,ItemDrop.ItemData __0){if(!(__instance is Player p)||p!=Player.m_localPlayer||!JewelleryRuntime.IsRing(__0))return true;if(p.IsDead()){RingEquipmentBackend.ClearOnDeath(p);__0.m_equipped=false;return false;}JewelleryRuntime.UnequipRing(p,__0);return false;}}
    [HarmonyPatch(typeof(Humanoid),"IsItemEquiped")]
    static class JewelleryRingEquippedPatch
    {static bool Prefix(Humanoid __instance,ItemDrop.ItemData __0,ref bool __result){if(!(__instance is Player p)||p!=Player.m_localPlayer||!JewelleryRuntime.IsRing(__0))return true;__result=JewelleryRuntime.InRingSlot(__0);return false;}}
}
