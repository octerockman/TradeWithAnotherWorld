using System;
namespace Wayfarer.Items
{
    // Display-only rules. CommercePolicy remains the authority for every trade.
    public static class TradePresentation
    {
        public const float Width=1000,Height=760;
        public static float Fit(float canvasWidth,float canvasHeight)
            =>Math.Min(1,Math.Min(Math.Max(1,canvasWidth-32)/Width,Math.Max(1,canvasHeight-32)/Height));
        public static bool CanClick(bool enabled,bool localNavigation,bool busy)=>enabled&&(localNavigation||!busy);
        public static string Category(string kind)
        {
            switch(kind)
            {
                case "food":case "arrow":case "healing_potion":case "oil":case "trapper_bundle":case "bundle":case "supply":case "fuel":case "repair_kit":case "lantern":return "Supplies";
                case "ring":return "Rings";
                case "talisman":return "Talismans";
                default:return "Equipment";
            }
        }
        public static bool Affordable(long balance,long price)=>price>=0&&balance>=price;
    }
}
