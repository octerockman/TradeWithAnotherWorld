using System;
using System.Globalization;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace Wayfarer.Items
{
    // Text comes from the approved catalogue. Native material names are resolved
    // by the registration boundary; this formatter has no game-state side effects.
    public static class RegistryDescriptions
    {
        static string Number(float value)=>value.ToString("0.##",CultureInfo.InvariantCulture);
        public static string Build(ItemDefinition d,Func<string,string> materialName=null)
        {
            string approved=d.Stats.Value<string>("approvedEffect");
            if(d.IsJewelry&&!string.IsNullOrWhiteSpace(approved))return approved;
            if(d.Stats.Value<string>("description") is string text&&!string.IsNullOrWhiteSpace(text))return text;
            if(d.Kind=="trapper_bundle"&&d.Stats["contents"] is JObject contents)
            {
                string list=string.Join(", ",contents.Properties().Select(p=>p.Value.Value<int>()+" × "+(materialName?.Invoke(p.Name)??p.Name)));
                return "Right-click to unpack: "+list+".\nMake room for all contents. This purchased bundle keeps these contents.";
            }
            if(d.Kind=="oil")return Oil(d);
            if(d.Kind=="food")return d.Text("family")=="hardtack"?"A dry, enduring travel ration. May fill more than one food slot.":"A substantial traveller's meal, packed for the road.";
            if(d.Kind=="healing_potion")return "Restores "+Number(d.Stat("instantHealth"))+" health immediately. Shares the healing mead recovery time.";
            return d.Description;
        }
        static string Oil(ItemDefinition d)
        {
            string effect;
            switch(d.Stats.Value<string>("oilFamily"))
            {
                case "fire":effect="Adds "+Number(d.Stat("fire"))+" Fire damage to each hit.";break;
                case "lightning":effect="Adds "+Number(d.Stat("lightning"))+" Lightning damage to each hit.";break;
                case "frost":effect="Adds "+Number(d.Stat("frost"))+" Frost damage to each hit, with normal frost slowing.";break;
                case "poison":effect="Adds "+Number(d.Stat("poisonTotal"))+" total Poison damage per hit, using normal poison rules.";break;
                case "hallowed":effect="Adds "+Number(d.Stat("spirit"))+" Spirit damage to each hit against susceptible creatures.";break;
                case "bloodletting":effect="Hits against creatures that can bleed open a wound dealing "+Number(d.Stat("woundDamage"))+" damage over "+Number(d.Stat("woundDuration"))+" seconds. Up to "+Number(d.Stat("maxWounds"))+" wounds; further wounds replace the oldest.";break;
                case "ether_rot":effect=Number(d.Stat("requiredHits"))+" hits within "+Number(d.Stat("hitWindow"))+" seconds suppress eligible magical attacks for "+Number(d.Stat("suppressionDuration"))+" seconds. Can trigger on the same target at most once every "+Number(d.Stat("targetRecovery"))+" seconds. Physical attacks are unchanged.";break;
                default:return d.Description;
            }
            return effect+"\nLasts "+Number(d.Stat("duration"))+" seconds. Takes "+Number(d.Stat("applicationDuration"))+" seconds to apply to a main-hand physical melee weapon without built-in elemental damage.\nSwitching or unequipping the weapon ends the coating. Stowing does not pause it. Another application consumes the oil and replaces the coating; its timer restarts instead of stacking.";
        }
    }
}
