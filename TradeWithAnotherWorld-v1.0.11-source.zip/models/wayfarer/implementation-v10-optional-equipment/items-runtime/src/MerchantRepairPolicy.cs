using System;
using System.Collections.Generic;
namespace Wayfarer.Items
{
    public static class MerchantRepairPolicy
    {
        public static CommerceTransaction Plan(CommerceWorldState state,string request,string item,string selectedInstance,IDictionary<string,long> inventory,ISet<string> approvedItems)
        {
            if(state==null||request?.Length!=32||state.appliedTransactions.Contains(request)||selectedInstance?.Length!=32||!approvedItems.Contains(item??"")||!inventory.TryGetValue(item,out long quantity)||quantity<1)return new CommerceTransaction{error="Select one carried restored item for repair."};
            var next=state.Copy();next.revision=checked(next.revision+1);next.appliedTransactions.Add(request);
            return new CommerceTransaction{requestId=request,operation="merchant-repair",expectedRevision=state.revision,stateAfter=next,selectedInstanceId=selectedInstance,fullyRepairSelectedInstance=true};
        }
    }
}
