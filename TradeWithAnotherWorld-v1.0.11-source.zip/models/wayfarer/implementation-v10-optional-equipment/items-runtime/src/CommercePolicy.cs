using System;
using System.Linq;
using System.Collections.Generic;

namespace Wayfarer.Items
{
    // Pure server-side policy. The runtime adapter owns durable world saves,
    // authentication and the atomic application of the exact inventory deltas.
    public sealed class CommerceOffer
    {
        public string id, family, kind;
        public int version, bossLevel, priceSC, purchaseQuantity = 1, maxStack = 1;
        public bool startingStock, replaceEarlierStock, enabled = true, purchasable = true, nextAbbeyVictoryRequired = true;
        public string[] requiresFlags = Array.Empty<string>(), requiresCommissions = Array.Empty<string>();
        public string[][] requiresAnyFlags = Array.Empty<string[]>(), requiresAnyCommissions = Array.Empty<string[]>();
        public string fragmentId;
        public int fragmentTotal;
    }
    public sealed class CommerceCommission
    {
        public string id, kind;
        public Dictionary<string,int> required = new Dictionary<string,int>(StringComparer.Ordinal);
        public Dictionary<string,int> unitPaymentSC = new Dictionary<string,int>(StringComparer.Ordinal);
        public string[] requiresFlags = Array.Empty<string>(), requiresCommissions = Array.Empty<string>();
        public string[] forbidsFlags = Array.Empty<string>();
        public bool enabled = true;
        public int worldBossOfferMinimum;
        public int acceptancePaymentSC;
        public Dictionary<string,int> acceptanceGrants = new Dictionary<string,int>(StringComparer.Ordinal);
        public string[] onCompleteFlags = Array.Empty<string>();
        public string[] completionFlags = Array.Empty<string>();
        public string[][] completionAnyFlags = Array.Empty<string[]>(), appraisalGroups = Array.Empty<string[]>();
        public CommerceDeliveryGroup[] deliveryGroups = Array.Empty<CommerceDeliveryGroup>();
        public bool paymentReady = true;
        public int completionPaymentSC;
        public int alternativePaymentAfterEarlierDeclineSC = -1;
        public string declinedPaymentFlag;
    }
    public sealed class CommerceDeliveryGroup
    {
        public string id;
        // Filled by the trusted native-data adapter; never supplied by a player request.
        public string[] allowedItemIds = Array.Empty<string>();
        public int quantity, minimumDistinctTypes = 1, maximumPerType = int.MaxValue, unitPaymentSC;
    }
    public sealed class CommerceProgress
    {
        public long acceptedAtRevision;
        public Dictionary<string,int> delivered = new Dictionary<string,int>(StringComparer.Ordinal);
        public bool paymentClaimed;
        public HashSet<string> shown = new HashSet<string>(StringComparer.Ordinal);
        public CommerceProgress Copy() => new CommerceProgress { acceptedAtRevision=acceptedAtRevision, delivered=new Dictionary<string,int>(delivered,StringComparer.Ordinal), paymentClaimed=paymentClaimed, shown=new HashSet<string>(shown,StringComparer.Ordinal) };
    }
    public sealed class CommerceWorldState
    {
        public int schemaVersion = 1, highestBossLevel;
        public long revision, abbeyVictories;
        public HashSet<string> unlocked = new HashSet<string>(StringComparer.Ordinal), flags = new HashSet<string>(StringComparer.Ordinal), completed = new HashSet<string>(StringComparer.Ordinal), appliedTransactions = new HashSet<string>(StringComparer.Ordinal), appliedVictories = new HashSet<string>(StringComparer.Ordinal);
        public Dictionary<string,long> fragments = new Dictionary<string,long>(StringComparer.Ordinal);
        public Dictionary<string,CommerceProgress> accepted = new Dictionary<string,CommerceProgress>(StringComparer.Ordinal);
        public CommerceWorldState Copy() => new CommerceWorldState {
            schemaVersion=schemaVersion, highestBossLevel=highestBossLevel, revision=revision, abbeyVictories=abbeyVictories,
            unlocked=new HashSet<string>(unlocked,StringComparer.Ordinal),flags=new HashSet<string>(flags,StringComparer.Ordinal),completed=new HashSet<string>(completed,StringComparer.Ordinal),appliedTransactions=new HashSet<string>(appliedTransactions,StringComparer.Ordinal),appliedVictories=new HashSet<string>(appliedVictories,StringComparer.Ordinal),
            fragments=new Dictionary<string,long>(fragments,StringComparer.Ordinal),accepted=accepted.ToDictionary(x=>x.Key,x=>x.Value.Copy(),StringComparer.Ordinal)
        };
    }
    public sealed class CommerceDelta
    {
        public string itemId;
        public long quantity;
        public int quality = 1;
        public CommerceDelta(string item,long count,int q=1){itemId=item;quantity=count;quality=q;}
    }
    public sealed class CommerceTransaction
    {
        public string requestId, operation, error;
        public long expectedRevision;
        public CommerceWorldState stateAfter;
        public List<CommerceDelta> inventory = new List<CommerceDelta>();
        public string selectedInstanceId;
        public int selectedInstanceQualityAfter;
        public bool fullyRepairSelectedInstance, upgradeSucceeded;
        public bool Success => error == null && stateAfter != null;
    }
    public sealed class CommerceQualityRecipe
    {
        public string itemId, materialId;
        public int maximumQuality = 4;
        public int[] stepMaterialCosts = Array.Empty<int>();
        public double successChance = 1;
    }
    public static class CommercePolicy
    {
        public const string StrangeCoinId="strange_coin", OrdinaryCoinId="Coins";
        public static bool RequirementsMet(CommerceWorldState s,CommerceOffer o) => o.enabled && s.highestBossLevel>=o.bossLevel && o.requiresFlags.All(s.flags.Contains) && o.requiresCommissions.All(s.completed.Contains) && o.requiresAnyFlags.All(g=>g.Any(s.flags.Contains)) && o.requiresAnyCommissions.All(g=>g.Any(s.completed.Contains)) && (o.fragmentTotal<=0 || (o.fragmentId!=null && s.fragments.TryGetValue(o.fragmentId,out var n) && n>=o.fragmentTotal));
        public static bool IsUnlocked(CommerceWorldState s,CommerceOffer o) => o.enabled && (o.startingStock || s.unlocked.Contains(o.id) || (!o.nextAbbeyVictoryRequired && RequirementsMet(s,o)));
        public static IEnumerable<CommerceOffer> AvailableStock(CommerceWorldState s,IEnumerable<CommerceOffer> offers)
        {
            var eligible=offers.Where(o=>o.purchasable&&IsUnlocked(s,o)).ToArray();
            return eligible.Where(o=>!o.replaceEarlierStock || !eligible.Any(n=>n.replaceEarlierStock && n.family==o.family && n.version>o.version)).OrderBy(o=>o.id,StringComparer.Ordinal);
        }
        static long Have(IDictionary<string,long> inventory,string id)=>inventory.TryGetValue(id,out var n)?n:0;
        static CommerceTransaction Begin(CommerceWorldState state,string request,string operation)
        {
            if(state==null)return new CommerceTransaction{error="Missing world state."};
            if(string.IsNullOrWhiteSpace(request)||request.Length>128)return new CommerceTransaction{error="Invalid request identity."};
            if(state.appliedTransactions.Contains(request))return new CommerceTransaction{error="Request already applied."};
            var copy=state.Copy();copy.revision=checked(state.revision+1);copy.appliedTransactions.Add(request);
            return new CommerceTransaction{requestId=request,operation=operation,expectedRevision=state.revision,stateAfter=copy};
        }
        static CommerceTransaction Fail(CommerceTransaction t,string reason){t.error=reason;t.stateAfter=null;t.inventory.Clear();return t;}
        public static bool CompleteRequirements(CommerceWorldState s, CommerceCommission job, CommerceProgress progress)
        {
            if(s==null||job==null||progress==null)return false;
            return job.required.All(p=>progress.delivered.TryGetValue(p.Key,out int n)&&n>=p.Value)
                && job.deliveryGroups.All(g=>g.allowedItemIds.Sum(id=>progress.delivered.TryGetValue(id,out int n)?n:0)>=g.quantity && g.allowedItemIds.Count(id=>progress.delivered.TryGetValue(id,out int n)&&n>0)>=g.minimumDistinctTypes)
                && job.completionFlags.All(s.flags.Contains)
                && job.completionAnyFlags.All(group=>group.Any(s.flags.Contains))
                && job.appraisalGroups.All(group=>group.Any(id=>progress.shown.Contains(id)||s.flags.Contains("appraised:"+id)));
        }
        static void FinishCommission(CommerceTransaction t,CommerceCommission job)
        {
            var p=t.stateAfter.accepted[job.id];t.stateAfter.completed.Add(job.id);
            foreach(string flag in job.onCompleteFlags)t.stateAfter.flags.Add(flag);
            if(!p.paymentClaimed)
            {
                int payment=job.alternativePaymentAfterEarlierDeclineSC>=0&&!string.IsNullOrEmpty(job.declinedPaymentFlag)&&t.stateAfter.flags.Contains(job.declinedPaymentFlag)?job.alternativePaymentAfterEarlierDeclineSC:job.completionPaymentSC;
                if(payment>0)t.inventory.Add(new CommerceDelta(StrangeCoinId,payment));p.paymentClaimed=true;
            }
        }
        public static bool TryCommit(CommerceWorldState live,CommerceTransaction transaction,out CommerceWorldState next)
        {
            next=live;
            if(live==null||transaction==null||!transaction.Success||transaction.expectedRevision!=live.revision||live.appliedTransactions.Contains(transaction.requestId)||transaction.stateAfter.revision!=checked(live.revision+1))return false;
            // Return a defensive copy; callers cannot mutate the reusable plan after commit.
            next=transaction.stateAfter.Copy();return true;
        }
        public static CommerceTransaction PlanBossProgress(CommerceWorldState state,string request,int highestBoss)
        {
            var t=Begin(state,request,"boss-progress");if(!t.Success)return t;if(highestBoss<0||highestBoss>8)return Fail(t,"Invalid world boss stage.");
            t.stateAfter.highestBossLevel=Math.Max(state.highestBossLevel,highestBoss);return t;
        }
        public static CommerceTransaction PlanFlag(CommerceWorldState state,string request,string flag)
        {
            var t=Begin(state,request,"world-flag");if(!t.Success)return t;if(string.IsNullOrWhiteSpace(flag)||flag.Length>120)return Fail(t,"Invalid world flag.");t.stateAfter.flags.Add(flag);return t;
        }
        public static CommerceTransaction PlanAbbeyVictory(CommerceWorldState state,string request,string generatedRunIdentity,IEnumerable<CommerceOffer> catalogue)
        {
            var t=Begin(state,request,"abbey-victory");if(!t.Success)return t;
            if(string.IsNullOrWhiteSpace(generatedRunIdentity)||generatedRunIdentity.Length>160)return Fail(t,"Missing generated-run identity.");
            if(state.appliedVictories.Contains(generatedRunIdentity))return Fail(t,"This Abbey victory is already credited.");
            t.stateAfter.appliedVictories.Add(generatedRunIdentity);t.stateAfter.abbeyVictories=checked(state.abbeyVictories+1);
            // Requirement snapshot is the state BEFORE this victory. Victory loot
            // delivered afterwards therefore waits for a later qualifying victory.
            foreach(var o in catalogue)if(RequirementsMet(state,o))t.stateAfter.unlocked.Add(o.id);
            return t;
        }
        public static CommerceTransaction PlanAcceptCommission(CommerceWorldState state,string request,CommerceCommission job)
        {
            var t=Begin(state,request,"accept-commission");if(!t.Success)return t;
            if(job==null||!job.enabled||string.IsNullOrWhiteSpace(job.id))return Fail(t,"Unknown or unavailable commission.");
            if(state.completed.Contains(job.id))return Fail(t,"Commission already completed.");
            if(state.accepted.ContainsKey(job.id))return Fail(t,"Commission already accepted.");
            if(state.highestBossLevel<job.worldBossOfferMinimum||!job.requiresFlags.All(state.flags.Contains)||!job.requiresCommissions.All(state.completed.Contains)||job.forbidsFlags.Any(state.flags.Contains))return Fail(t,"Commission prerequisites are not known.");
            if(job.acceptancePaymentSC<0||job.acceptanceGrants.Any(p=>p.Value<1||string.IsNullOrWhiteSpace(p.Key)))return Fail(t,"Invalid acceptance payment or parcel.");
            t.stateAfter.accepted.Add(job.id,new CommerceProgress{acceptedAtRevision=t.stateAfter.revision});
            if(job.acceptancePaymentSC>0)t.inventory.Add(new CommerceDelta(StrangeCoinId,job.acceptancePaymentSC));
            foreach(var grant in job.acceptanceGrants)t.inventory.Add(new CommerceDelta(grant.Key,grant.Value));return t;
        }
        public static CommerceTransaction PlanDelivery(CommerceWorldState state,string request,CommerceCommission job,IDictionary<string,long> inventory,IDictionary<string,int> requested)
        {
            var t=Begin(state,request,"commission-delivery");if(!t.Success)return t;
            if(job==null||job.kind!="delivery"||!state.accepted.ContainsKey(job.id)||state.completed.Contains(job.id))return Fail(t,"Accept this delivery commission first.");
            if(!job.paymentReady)return Fail(t,"Commission payment is not settled.");
            if(requested==null||requested.Count==0)return Fail(t,"No delivery selected.");
            var allowed=job.deliveryGroups.SelectMany(g=>g.allowedItemIds).ToArray();
            if(allowed.Distinct(StringComparer.Ordinal).Count()!=allowed.Length||allowed.Any(job.required.ContainsKey)||job.deliveryGroups.Any(g=>g.quantity<1||g.minimumDistinctTypes<1||g.maximumPerType<1||g.unitPaymentSC<0||g.allowedItemIds.Length==0))return Fail(t,"Invalid delivery category definition.");
            var progress=t.stateAfter.accepted[job.id];long payment=0,delivered=0;
            foreach(var pair in requested)
            {
                if(pair.Value<=0)return Fail(t,"Invalid delivery selection.");
                progress.delivered.TryGetValue(pair.Key,out int existing);int amount,rate=0;
                if(job.required.TryGetValue(pair.Key,out int required))
                {
                    amount=Math.Min(pair.Value,Math.Max(0,required-existing));job.unitPaymentSC.TryGetValue(pair.Key,out rate);
                }
                else
                {
                    var group=job.deliveryGroups.SingleOrDefault(g=>g.allowedItemIds.Contains(pair.Key));if(group==null)return Fail(t,"This item is not in an approved delivery category.");
                    int groupDelivered=group.allowedItemIds.Sum(id=>progress.delivered.TryGetValue(id,out int n)?n:0);
                    amount=Math.Min(pair.Value,Math.Min(Math.Max(0,group.quantity-groupDelivered),Math.Max(0,group.maximumPerType-existing)));rate=group.unitPaymentSC;
                }
                if(amount==0)continue;if(Have(inventory,pair.Key)<amount)return Fail(t,"Not enough carried items.");
                progress.delivered[pair.Key]=checked(existing+amount);t.inventory.Add(new CommerceDelta(pair.Key,-amount));delivered+=amount;
                if(rate<0)return Fail(t,"Invalid payment rate.");payment=checked(payment+(long)rate*amount);
            }
            if(delivered==0)return Fail(t,"No requested quantity remains.");
            if(CompleteRequirements(t.stateAfter,job,progress))FinishCommission(t,job);
            if(payment>0)t.inventory.Add(new CommerceDelta(StrangeCoinId,payment));return t;
        }
        public static CommerceTransaction PlanAppraisal(CommerceWorldState state,string request,CommerceCommission job,string shownItem,IDictionary<string,long> inventory)
        {
            var t=Begin(state,request,"commission-appraisal");if(!t.Success)return t;
            if(job==null||!state.accepted.ContainsKey(job.id)||state.completed.Contains(job.id))return Fail(t,"Accept this appraisal first.");
            var groups=job.appraisalGroups.Length>0?job.appraisalGroups:new[]{job.required.Keys.ToArray()};
            if(!groups.Any(g=>g.Contains(shownItem))||Have(inventory,shownItem)<1)return Fail(t,"Carry the requested object to show it.");
            t.stateAfter.accepted[job.id].shown.Add(shownItem);t.stateAfter.flags.Add("appraised:"+shownItem);
            // Appraisal may be one step of a mixed delivery/conversation job.
            if(job.appraisalGroups.Length>0&&CompleteRequirements(t.stateAfter,job,t.stateAfter.accepted[job.id]))FinishCommission(t,job);
            else if(job.kind=="appraisal"&&job.appraisalGroups.Length==0&&job.completionFlags.All(state.flags.Contains))FinishCommission(t,job);
            return t;
        }
        public static CommerceTransaction PlanRecordAppraisal(CommerceWorldState state,string request,string shownItem,IDictionary<string,long> inventory,ISet<string> approvedAppraisalIds)
        {
            var t=Begin(state,request,"explicit-appraisal");if(!t.Success)return t;
            if(string.IsNullOrWhiteSpace(shownItem)||approvedAppraisalIds==null||!approvedAppraisalIds.Contains(shownItem)||Have(inventory,shownItem)<1)return Fail(t,"Carry an approved appraisal object and explicitly show it.");
            // A remembered appraisal is reusable, even if an earlier OR-group
            // job was completed with its other object. No sale or free payment.
            t.stateAfter.flags.Add("appraised:"+shownItem);return t;
        }
        public static CommerceTransaction PlanCompleteStoryCommission(CommerceWorldState state,string request,CommerceCommission job)
        {
            var t=Begin(state,request,"complete-story-commission");if(!t.Success)return t;
            if(job==null||!state.accepted.ContainsKey(job.id)||state.completed.Contains(job.id))return Fail(t,"No active commission.");
            if(!job.requiresFlags.All(state.flags.Contains)||!job.requiresCommissions.All(state.completed.Contains))return Fail(t,"Story requirements remain unmet.");
            if(!CompleteRequirements(state,job,state.accepted[job.id]))return Fail(t,"Delivery, appraisal or conversation requirements remain unmet.");
            FinishCommission(t,job);return t;
        }
        public static CommerceTransaction PlanPurchase(CommerceWorldState state,string request,CommerceOffer offer,IDictionary<string,long> inventory,int lots=1)
        {
            var t=Begin(state,request,"purchase");if(!t.Success)return t;
            if(offer==null||!offer.purchasable||!IsUnlocked(state,offer))return Fail(t,"Stock is not unlocked or purchasable.");
            if(lots<1||lots>10000||offer.purchaseQuantity<1||offer.priceSC<0)return Fail(t,"Invalid purchase quantity or price.");
            long cost=checked((long)offer.priceSC*lots),quantity=checked((long)offer.purchaseQuantity*lots);
            if(Have(inventory,StrangeCoinId)<cost)return Fail(t,"Not enough Strange Coins.");
            if(cost>0)t.inventory.Add(new CommerceDelta(StrangeCoinId,-cost));t.inventory.Add(new CommerceDelta(offer.id,quantity));
            if(offer.kind=="oil"&&new[]{"oil_fire_lesser","oil_lightning_lesser","oil_poison_lesser"}.Contains(offer.id))t.stateAfter.flags.Add("starting_oil_purchased");return t;
        }
        public static CommerceTransaction PlanExchangeOrdinaryCoins(CommerceWorldState state,string request,IDictionary<string,long> inventory,int strangeCoins=1)
        {
            var t=Begin(state,request,"ordinary-to-strange-coins");if(!t.Success)return t;
            if(strangeCoins<1||strangeCoins>10000)return Fail(t,"Invalid exchange quantity.");long ordinary=checked(1000L*strangeCoins);
            if(Have(inventory,OrdinaryCoinId)<ordinary)return Fail(t,"Not enough ordinary coins.");
            t.inventory.Add(new CommerceDelta(OrdinaryCoinId,-ordinary));t.inventory.Add(new CommerceDelta(StrangeCoinId,strangeCoins));return t;
        }
        public static CommerceTransaction PlanSale(CommerceWorldState state,string request,string itemId,int quantity,int lotSize,int lotPaymentSC,IDictionary<string,long> inventory,bool restorationFragment=false)
        {
            var t=Begin(state,request,"sale");if(!t.Success)return t;
            if(itemId==StrangeCoinId||itemId=="TWA_StrangeCoin_v1"||itemId==OrdinaryCoinId)return Fail(t,"Coins cannot be sold through salvage trading.");
            if(string.IsNullOrWhiteSpace(itemId)||quantity<1||lotSize<1||lotPaymentSC<0||quantity%lotSize!=0)return Fail(t,"Sell complete approved lots only.");
            if(Have(inventory,itemId)<quantity)return Fail(t,"Not enough carried items.");
            t.inventory.Add(new CommerceDelta(itemId,-quantity));long pay=checked((long)(quantity/lotSize)*lotPaymentSC);if(pay>0)t.inventory.Add(new CommerceDelta(StrangeCoinId,pay));
            if(restorationFragment){t.stateAfter.fragments.TryGetValue(itemId,out long n);t.stateAfter.fragments[itemId]=checked(n+quantity);}
            // Ordinary sales never credit a commission, accepted or otherwise.
            return t;
        }
        public static CommerceTransaction PlanVersionExchange(CommerceWorldState state,string request,CommerceOffer oldItem,CommerceOffer nextItem,string selectedInstance,IDictionary<string,long> inventory)
        {
            var t=Begin(state,request,"version-exchange");if(!t.Success)return t;
            string[] kinds={"weapon","shield","censer","torch"};
            if(oldItem==null||nextItem==null||!kinds.Contains(oldItem.kind)||nextItem.kind!=oldItem.kind||oldItem.family!=nextItem.family||nextItem.version<=oldItem.version||!IsUnlocked(state,nextItem)||string.IsNullOrWhiteSpace(selectedInstance))return Fail(t,"Select a matching older equipment item and an unlocked later version.");
            if(Have(inventory,oldItem.id)<1)return Fail(t,"Selected older item is no longer carried.");
            long difference=(long)nextItem.priceSC-oldItem.priceSC;if(difference<0)return Fail(t,"Invalid version price order.");
            if(Have(inventory,StrangeCoinId)<difference)return Fail(t,"Not enough Strange Coins for the price difference.");
            t.selectedInstanceId=selectedInstance;t.fullyRepairSelectedInstance=true;t.inventory.Add(new CommerceDelta(oldItem.id,-1));if(difference>0)t.inventory.Add(new CommerceDelta(StrangeCoinId,-difference));t.inventory.Add(new CommerceDelta(nextItem.id,1,1));return t;
        }
        public static CommerceTransaction PlanQualityUpgrade(CommerceWorldState state,string request,CommerceQualityRecipe recipe,string selectedInstance,int currentQuality,IDictionary<string,long> inventory,double serverRandom)
        {
            var t=Begin(state,request,"forge-quality-upgrade");if(!t.Success)return t;
            if(recipe==null||string.IsNullOrWhiteSpace(selectedInstance)||string.IsNullOrWhiteSpace(recipe.itemId)||string.IsNullOrWhiteSpace(recipe.materialId)||currentQuality<1||currentQuality>=recipe.maximumQuality||recipe.maximumQuality>4||currentQuality>recipe.stepMaterialCosts.Length||recipe.successChance<=0||recipe.successChance>1||double.IsNaN(serverRandom)||serverRandom<0||serverRandom>=1)return Fail(t,"Invalid quality upgrade.");
            int cost=recipe.stepMaterialCosts[currentQuality-1];if(cost<1||Have(inventory,recipe.itemId)<1||Have(inventory,recipe.materialId)<cost)return Fail(t,"Carry the selected item and required upgrade materials.");
            t.selectedInstanceId=selectedInstance;t.inventory.Add(new CommerceDelta(recipe.materialId,-cost));
            t.upgradeSucceeded=serverRandom<recipe.successChance;t.selectedInstanceQualityAfter=t.upgradeSucceeded?currentQuality+1:currentQuality;
            // A failed pattern attempt never destroys or downgrades the bell.
            // Neither forge nor bell consumption adds merchant restoration credit.
            return t;
        }
    }
}
