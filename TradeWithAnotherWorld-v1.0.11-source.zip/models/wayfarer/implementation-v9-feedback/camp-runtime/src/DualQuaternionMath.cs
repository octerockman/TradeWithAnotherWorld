using System;

namespace Wayfarer.InGame
{
    // Pure managed rigid dual-quaternion math. This same source is run by the
    // offline fixture checker; it does not need a running Unity engine.
    public static class DualQuaternionMath
    {
        public struct V { public float x,y,z; public V(float a,float b,float c){x=a;y=b;z=c;} }
        public struct Q { public float x,y,z,w; public Q(float a,float b,float c,float d){x=a;y=b;z=c;w=d;} }
        public struct DQ { public Q real,dual; public DQ(Q a,Q b){real=a;dual=b;} }
        public static Q Add(Q a,Q b)=>new Q(a.x+b.x,a.y+b.y,a.z+b.z,a.w+b.w);
        public static Q Scale(Q a,float s)=>new Q(a.x*s,a.y*s,a.z*s,a.w*s);
        public static float Dot(Q a,Q b)=>a.x*b.x+a.y*b.y+a.z*b.z+a.w*b.w;
        public static Q Conjugate(Q q)=>new Q(-q.x,-q.y,-q.z,q.w);
        public static Q Multiply(Q a,Q b)=>new Q(a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z);
        static Q Normalize(Q q){float n=(float)Math.Sqrt(Dot(q,q));if(n<1e-8f||float.IsNaN(n))throw new InvalidOperationException("Degenerate quaternion.");return Scale(q,1/n);}
        public static DQ FromMatrix(float[] m)
        {
            if(m==null||m.Length!=16)throw new ArgumentException("Row-major matrix required.");
            // Rigidity is deliberate: source exporter proves all admitted bone
            // matrices are unit rigid. No lossy scale/shear approximation.
            for(int k=0;k<3;k++){float len=0;for(int i=0;i<3;i++)len+=m[i*4+k]*m[i*4+k];if(Math.Abs(len-1)>.005f)throw new InvalidOperationException("DQS matrix is not unit rigid.");}
            Q q;float trace=m[0]+m[5]+m[10];
            if(trace>0){float s=(float)Math.Sqrt(trace+1)*2;q=new Q((m[9]-m[6])/s,(m[2]-m[8])/s,(m[4]-m[1])/s,s*.25f);}
            else if(m[0]>m[5]&&m[0]>m[10]){float s=(float)Math.Sqrt(1+m[0]-m[5]-m[10])*2;q=new Q(s*.25f,(m[1]+m[4])/s,(m[2]+m[8])/s,(m[9]-m[6])/s);}
            else if(m[5]>m[10]){float s=(float)Math.Sqrt(1+m[5]-m[0]-m[10])*2;q=new Q((m[1]+m[4])/s,s*.25f,(m[6]+m[9])/s,(m[2]-m[8])/s);}
            else{float s=(float)Math.Sqrt(1+m[10]-m[0]-m[5])*2;q=new Q((m[2]+m[8])/s,(m[6]+m[9])/s,s*.25f,(m[4]-m[1])/s);}
            q=Normalize(q);return new DQ(q,Scale(Multiply(new Q(m[3],m[7],m[11],0),q),.5f));
        }
        public static DQ Blend(DQ[] bones,int[] indices,float[] weights)
        {
            if(indices==null||weights==null||indices.Length!=4||weights.Length!=4)throw new ArgumentException("Four influences required.");
            Q reference=bones[indices[0]].real,real=new Q(),dual=new Q();
            for(int i=0;i<4;i++){float w=weights[i];if(w<=0)continue;var q=bones[indices[i]];float sign=Dot(reference,q.real)<0?-1:1;real=Add(real,Scale(q.real,w*sign));dual=Add(dual,Scale(q.dual,w*sign));}
            float norm=(float)Math.Sqrt(Dot(real,real));if(norm<1e-8f)throw new InvalidOperationException("Degenerate DQS blend.");real=Scale(real,1/norm);dual=Scale(dual,1/norm);dual=Add(dual,Scale(real,-Dot(real,dual)));return new DQ(real,dual);
        }
        public static V Rotate(Q q,V p){Q v=Multiply(Multiply(q,new Q(p.x,p.y,p.z,0)),Conjugate(q));return new V(v.x,v.y,v.z);}
        public static V Transform(DQ q,V p){V v=Rotate(q.real,p);Q t=Multiply(q.dual,Conjugate(q.real));return new V(v.x+2*t.x,v.y+2*t.y,v.z+2*t.z);}
    }
}
