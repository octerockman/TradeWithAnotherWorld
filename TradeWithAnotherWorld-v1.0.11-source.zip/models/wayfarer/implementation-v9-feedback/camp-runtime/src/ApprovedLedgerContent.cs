using System;
using System.IO;

namespace Wayfarer.InGame
{
    public sealed class ApprovedLedgerDocument
    {
        public string schema,approvedSourceSha256;public LedgerContent ledger;
    }
    public static class ApprovedLedgerContent
    {
        public const string ResourceSha256="6bdaa7b9a3c85ba27809189d9b54b9d6b3832d3c8c11e0d79d658b0ccc35b47d";
        public const string ApprovedSourceSha256="08882b5b461f6e8db489e92cb974033ef9bf5b41fbc19af8b7d3d951268749a4";
        public static LedgerContent Load(string dataFolder)
        {
            // Additive resource: the original 82 camp/actor/interaction files
            // stay exact. Absence remains compatible with an older data folder.
            string file=PayloadReader.Safe(dataFolder,"interactions/approved-ledger.json");
            if(!File.Exists(file)){WayfarerPlugin.Report("WF_LEDGER_UNAVAILABLE approved-ledger.json is missing.");return null;}
            if(new FileInfo(file).Length>20000||PayloadReader.Hash(file)!=ResourceSha256)throw new InvalidDataException("Approved ledger resource hash/size mismatch.");
            var document=PayloadReader.Read<ApprovedLedgerDocument>(file);
            if(document?.schema!="wayfarer.approved-ledger.v1"||document.approvedSourceSha256!=ApprovedSourceSha256||document.ledger==null||string.IsNullOrWhiteSpace(document.ledger.title)||string.IsNullOrWhiteSpace(document.ledger.text))throw new InvalidDataException("Approved ledger content contract mismatch.");
            WayfarerPlugin.Report("WF_LEDGER_READY exactApprovedAccounts=true reader=scrollable");
            return document.ledger;
        }
    }
}
