using System;
using UnityEngine;
using HarmonyLib;

namespace Wayfarer.InGame
{
    public static class OwnedPlotClutter
    {
        static ClutterSystem measured;static int count;static float bound=1.5f;
        public static float OverhangPad()
        {
            var system=ClutterSystem.instance;if(!system)return 1.5f;
            if(measured==system&&count==system.m_clutter.Count)return bound;
            measured=system;count=system.m_clutter.Count;bound=1.5f;
            foreach(var d in system.m_clutter)
            {
                if(d==null||!d.m_enabled||!d.m_prefab)continue;float radius=0;
                foreach(var mf in d.m_prefab.GetComponentsInChildren<MeshFilter>(true))if(mf&&mf.sharedMesh)
                {
                    var b=mf.sharedMesh.bounds;var matrix=d.m_prefab.transform.worldToLocalMatrix*mf.transform.localToWorldMatrix;
                    var rs=d.m_prefab.transform.localScale;var rootScale=new Vector3(Mathf.Max(1,Mathf.Abs(rs.x)),Mathf.Max(1,Mathf.Abs(rs.y)),Mathf.Max(1,Mathf.Abs(rs.z)));
                    for(int i=0;i<8;i++)
                    {
                        var p=matrix.MultiplyPoint3x4(b.center+Vector3.Scale(b.extents,new Vector3((i&1)==0?-1:1,(i&2)==0?-1:1,(i&4)==0?-1:1)));
                        p=Vector3.Scale(p,rootScale);float r=d.m_terrainTilt?p.magnitude:new Vector2(p.x,p.z).magnitude;radius=Mathf.Max(radius,r);
                    }
                }
                foreach(var ir in d.m_prefab.GetComponentsInChildren<InstanceRenderer>(true))if(ir&&ir.m_mesh)
                {
                    // Native AddInstance builds world TRS with m_scale * the
                    // randomized row scale; no MeshFilter/prefab-TRS required.
                    var b=ir.m_mesh.bounds;
                    for(int i=0;i<8;i++)
                    {
                        var p=Vector3.Scale(b.center+Vector3.Scale(b.extents,new Vector3((i&1)==0?-1:1,(i&2)==0?-1:1,(i&4)==0?-1:1)),ir.m_scale);
                        radius=Mathf.Max(radius,d.m_terrainTilt?p.magnitude:new Vector2(p.x,p.z).magnitude);
                    }
                }
                radius*=Mathf.Max(Mathf.Abs(d.m_scaleMin),Mathf.Abs(d.m_scaleMax));
                if(!PayloadReader.Finite(radius)||radius>64)throw new InvalidOperationException("Native clutter bounds exceed the owned-plot suppression contract.");
                bound=Mathf.Max(bound,radius+.15f);WayfarerPlugin.Report("WF_CLUTTER_SOURCE family="+d.m_name+" prefab="+d.m_prefab.name+" maxOverhangM="+radius);
            }
            WayfarerPlugin.Report("WF_CLUTTER_BOUND families="+count+" padM="+bound+" allFamilies=true");return bound;
        }
        public static bool Blocks(Vector3 point)
        {
            foreach(var marker in OwnedCampTerrainMarker.Live)
            {
                if(!marker||!marker.Owner||!marker.Owner.Settings.ClearGrass)continue;var s=marker.Owner.Settings;
                if(Mathf.Abs(point.y-s.Target)>8)continue;var local=marker.Owner.transform.InverseTransformPoint(point);float pad=Mathf.Max(s.Pad,OverhangPad());
                if(local.x>=s.Low.x-pad&&local.x<=s.High.x+pad&&local.z>=s.Low.z-pad&&local.z<=s.High.z+pad)return true;
            }
            return false;
        }
        public static void Invalidate(OwnedCampTerrainMarker marker)
        {
            if(!marker||!marker.Owner||!ClutterSystem.instance)return;var s=marker.Owner.Settings;
            float pad=Mathf.Max(s.Pad,OverhangPad())+s.Feather;
            float radius=new Vector2((s.High.x-s.Low.x)*.5f+pad,(s.High.z-s.Low.z)*.5f+pad).magnitude;
            ClutterSystem.instance.ResetGrass(marker.Owner.transform.TransformPoint(s.LocalCenter),radius);
        }
    }
    [HarmonyPatch(typeof(ClutterSystem),"GetGroundInfo")]
    static class OwnedPlotClutterGroundFilter
    {
        static void Postfix(ref Vector3 point,ref bool __result)
        {if(__result&&OwnedPlotClutter.Blocks(point))__result=false;}
    }
}
