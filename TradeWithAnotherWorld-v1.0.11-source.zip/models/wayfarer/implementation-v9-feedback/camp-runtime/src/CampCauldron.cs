using System;
using System.Linq;
using System.Collections;
using UnityEngine;
using Jotunn.Entities;
using Jotunn.Managers;
using Object=UnityEngine.Object;

namespace Wayfarer.InGame
{
    public static class CampCauldron
    {
        public const string PrefabName="TWA_WayfarerCauldron_v1",LinkKey="twa_wf_cauldron_v5";
        public const float SourceFit=.311261772f;
        public static readonly Vector3 SourcePosition=new Vector3(-3.25f,.284666286f,2.35f);
        public static GameObject Prefab{get;private set;}static Material water;
        public static void Register()
        {
            if(Prefab)return;var native=PrefabManager.Instance.GetPrefab("piece_cauldron");var original=native?native.GetComponent<CraftingStation>():null;
            if(!original||original.m_name!="$piece_cauldron"||!original.m_haveFireObject)throw new InvalidOperationException("Actual native level1 cauldron station is unavailable.");
            var copy=PrefabManager.Instance.CreateClonedPrefab(PrefabName,native);copy.SetActive(false);var station=copy.GetComponent<CraftingStation>();var have=station.m_haveFireObject;
            var plane=have.transform.Find("Waterplane");var steam=have.transform.Find("steam");var bubbles=have.transform.Find("bubbles");
            if(!plane||!plane.GetComponent<MeshRenderer>()||!steam||!steam.GetComponent<ParticleSystem>()||!bubbles||!bubbles.GetComponent<ParticleSystem>())throw new InvalidOperationException("Verified native cauldron steam/water hierarchy changed.");
            var sourceWater=plane.GetComponent<MeshRenderer>().sharedMaterial;
            if(!sourceWater||!sourceWater.name.StartsWith("cauldron_water",StringComparison.Ordinal))throw new InvalidOperationException("Native cauldron liquid material changed.");
            water=new Material(sourceWater){name="WF_Native_Cauldron_Transparent_Liquid"};
            plane.GetComponent<MeshRenderer>().sharedMaterial=water;
            foreach(var r in copy.GetComponentsInChildren<Renderer>(true))if(!r.transform.IsChildOf(have.transform))r.enabled=false;
            var nativeBody=copy.transform.Find("new");if(!nativeBody||have.transform.IsChildOf(nativeBody))throw new InvalidOperationException("Verified native cauldron body/effects separation changed.");nativeBody.gameObject.SetActive(false);
            foreach(var c in copy.GetComponentsInChildren<Collider>(true))c.enabled=false;
            foreach(var piece in copy.GetComponents<Piece>())Object.DestroyImmediate(piece);
            foreach(var wear in copy.GetComponents<WearNTear>())Object.DestroyImmediate(wear);
            foreach(var snap in copy.GetComponents<SnapToGround>())Object.DestroyImmediate(snap);
            station.m_craftRequireFire=true;station.m_craftRequireRoof=false;station.m_useDistance=1.9f;
            var view=copy.GetComponent<ZNetView>();if(!view)throw new InvalidOperationException("Native station needs its own persistent network view.");view.m_persistent=true;view.m_syncInitialScale=true;
            copy.AddComponent<OwnedCampCauldron>();PrefabManager.Instance.AddPrefab(new CustomPrefab(copy,false));copy.SetActive(true);Prefab=copy;
            WayfarerPlugin.Report("WF_CAULDRON_REGISTERED native=piece_cauldron station=$piece_cauldron baseLevel=1 nativeExtensions=true");
        }
        public static void Dispose(){if(water)Object.Destroy(water);water=null;Prefab=null;}
    }
    public sealed class OwnedCampCauldron:MonoBehaviour
    {
        public bool Ready{get;private set;}public string Failure{get;private set;}public CraftingStation Station{get;private set;}
        IEnumerator Start()
        {
            yield return null;
            try
            {
                var view=GetComponent<ZNetView>();Station=GetComponent<CraftingStation>();
                if(!view||!view.IsValid()||!WayfarerPlugin.Owned(view.GetZDO())||view.GetZDO().GetString(WayfarerPlugin.RoleKey,"")!="cauldron"||!Station)throw new InvalidOperationException("Own native cauldron identity is invalid.");
                Ready=true;WayfarerPlugin.Report("WF_CAULDRON_READY uid="+view.GetZDO().m_uid+" source=piece_cauldron ownPotArt=true baseLevel=1");
            }
            catch(Exception e){Failure=e.Message;WayfarerPlugin.Report("WF_CAULDRON_FAILED "+e);}
        }
    }
    public sealed class AuthoredPotInteract:MonoBehaviour,Hoverable,Interactable
    {
        internal ZNetView Camp;
        CraftingStation Station()
        {
            if(!Camp||!Camp.IsValid()||!ZNetScene.instance)return null;var z=Camp.GetZDO();var id=z.GetZDOID(CampCauldron.LinkKey);if(id.IsNone())return null;var obj=ZNetScene.instance.FindInstance(id);var view=obj?obj.GetComponent<ZNetView>():null;
            if(!view||!view.IsValid()||!WayfarerPlugin.Owned(view.GetZDO())||view.GetZDO().GetString(WayfarerPlugin.RoleKey,"")!="cauldron"||view.GetZDO().GetString(WayfarerPlugin.GroupKey,"")!=z.GetString(WayfarerPlugin.GroupKey,"")||view.GetZDO().GetZDOID(WayfarerPlugin.CampKey)!=z.m_uid)return null;return obj.GetComponent<CraftingStation>();
        }
        public string GetHoverName(){var s=Station();return s?s.GetHoverName():"";}
        public string GetHoverText(){var s=Station();return s?s.GetHoverText():"";}
        public float GetHoverOffset()=>.15f;
        public bool Interact(Humanoid user,bool hold,bool alt){var s=Station();return s&&s.Interact(user,hold,alt);}
        public bool UseItem(Humanoid user,ItemDrop.ItemData item){var s=Station();return s&&s.UseItem(user,item);}
    }
    public sealed class CampInteractionBindings:MonoBehaviour
    {
        ZNetView camp;GameObject selectedCoin;bool hidden;
        public void Configure(ZNetView view,System.Collections.Generic.Dictionary<string,Transform> named)
        {
            camp=view;if(!named.TryGetValue("WF_A05_kettle",out var pot)||!named.TryGetValue(CoinPresentation.Selected,out var coin))throw new InvalidOperationException("Authored pot/coin nodes unavailable.");
            selectedCoin=coin.gameObject;pot.gameObject.AddComponent<AuthoredPotInteract>().Camp=view;Update();
            if(StrangeCoinItem.Ledger!=null&&named.TryGetValue("WF_A04_ledger",out var ledger))ledger.gameObject.AddComponent<ApprovedLedgerReader>();
        }
        void Update()
        {if(!hidden&&camp&&camp.IsValid()&&camp.GetZDO().GetBool(StrangeCoinItem.IssuedKey,false)){hidden=true;if(selectedCoin)selectedCoin.SetActive(false);}}
        public void HideCoinNow(){Update();}
    }
    public sealed class ApprovedLedgerReader:MonoBehaviour,Hoverable,Interactable
    {
        public string GetHoverName()=>StrangeCoinItem.Ledger?.title??"";
        public string GetHoverText()=>StrangeCoinItem.Ledger==null?"":Localization.instance.Localize(GetHoverName()+"\n[<color=yellow><b>$KEY_Use</b></color>] Read");
        public float GetHoverOffset()=>.1f;
        public bool Interact(Humanoid user,bool hold,bool alt)
        {
            if(hold||user!=Player.m_localPlayer||StrangeCoinItem.Ledger==null)return false;
            try{if(ApprovedLedgerPanel.Open(StrangeCoinItem.Ledger,transform))return true;}
            catch(Exception e){WayfarerPlugin.Report("WF_LEDGER_PANEL_FAILED "+e.Message);}
            if(!TextViewer.instance)return false;
            TextViewer.instance.ShowText(TextViewer.Style.Rune,StrangeCoinItem.Ledger.title,StrangeCoinItem.Ledger.text,false);return true;
        }
        public bool UseItem(Humanoid user,ItemDrop.ItemData item)=>false;
    }
}
