using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using System.Security.Cryptography;
using Newtonsoft.Json;
using UnityEngine;

namespace Wayfarer.InGame
{
    public sealed class SourceRecord { public string path, sha256; }
    public sealed class MapRecord { public string path, sha256; }
    public sealed class MaterialRecord
    {
        public string id, name, normalEncoding, wrap, shaderHint;
        public MapRecord diffuse, normal, metallicGloss, emission;
        public float[] color, baseColor;
        public float metallic, roughness=.7f, emissionStrength=1, normalScale=1;
        public bool alphaCutout, transparent, doubleSided;
    }
    public sealed class NodeRecord { public int id, parentId; public string name; public float[] position, rotation, scale; }
    public sealed class MatrixRecord { public float[] values; }
    public sealed class WeightRecord { public int[] indices; public float[] weights; }
    public sealed class RendererRecord
    {
        public string name,type,collider,deformationMode; public int nodeId, rootBoneNodeId;
        public float[] vertices,normals,uv,boundsCenter,boundsSize; public int[] triangles,boneNodeIds;
        public int[][] submeshes; public int[] sourceVertexIds; public string[] materialIds; public MatrixRecord[] bindposes; public WeightRecord[] weights;
    }
    public sealed class PlacementRecord { public float[] position,rotation,scale; }
    public sealed class NativeInstanceRecord { public string name,prefab; public bool visualOnly; public float[] position,rotation,scale; }
    public sealed class FixtureRecord { public string name,role; public int nodeId; public float[] color; public float intensity,range; }
    public sealed class BagRecord { public string rig,fixedAnchor,swingBone,sourceMesh,physicsComponent; public bool keepAllMarkers; }
    public sealed class VisualPayload
    {
        public string schema; public SourceRecord sourceNative; public NodeRecord[] nodes;
        public RendererRecord[] renderers; public MaterialRecord[] materials;
        public NativeInstanceRecord[] nativeInstances; public PlacementRecord actorPlacement;
        public FixtureRecord[] fixtures; public BagRecord bag;
        public float[] boundsMin,boundsMax; public Dictionary<string,string> semanticNodes;
    }
    public sealed class MotionFrame { public float time; public float[] positions,rotations,scales; }
    public sealed class MotionClip { public string name; public float duration; public MotionFrame[] frames; }
    public sealed class MotionPayload { public string schema; public SourceRecord sourceNative; public string[] boneNames; public float fps; public MotionClip[] clips; public Dictionary<string,string> aliases; }
    public sealed class DataManifest { public string schema,sourceNativeSha256; public MapRecord camp,actor,motion; }

    public static class PayloadReader
    {
        public const string NativeSha="819716daf5ddfb873eda7a6f7cb562e030a3d7282481ab4810d7cca39365a911";
        const int MaxBytes=160*1024*1024;
        public static bool Finite(float n)=>!float.IsNaN(n)&&!float.IsInfinity(n);
        public static string Hash(string path){using(var h=SHA256.Create())using(var s=File.OpenRead(path))return string.Concat(h.ComputeHash(s).Select(v=>v.ToString("x2")));}
        public static string Safe(string folder,string relative)
        {
            if(string.IsNullOrWhiteSpace(relative)||Path.IsPathRooted(relative))throw new InvalidDataException("Expected package-relative path.");
            string root=Path.GetFullPath(folder).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;
            string p=Path.GetFullPath(Path.Combine(root,relative));
            if(!p.StartsWith(root,StringComparison.OrdinalIgnoreCase)||!File.Exists(p))throw new InvalidDataException("Missing/outside package file: "+relative);
            return p;
        }
        public static void CheckMap(MapRecord m){if(m==null||string.IsNullOrWhiteSpace(m.path)||m.sha256==null||m.sha256.Length!=64||!m.sha256.All(Uri.IsHexDigit))throw new InvalidDataException("Incomplete source hash/path.");}
        public static T Read<T>(string path)
        {
            if(!File.Exists(path)||new FileInfo(path).Length>MaxBytes)throw new InvalidDataException("Missing/oversized own payload.");
            string text;
            using(var input=File.OpenRead(path))using(var memory=new MemoryStream())
            {
                Stream src=path.EndsWith(".gz",StringComparison.OrdinalIgnoreCase)?(Stream)new GZipStream(input,CompressionMode.Decompress):input;
                using(src){var buffer=new byte[65536];int n;while((n=src.Read(buffer,0,buffer.Length))>0){if(memory.Length+n>MaxBytes)throw new InvalidDataException("Payload decompression limit.");memory.Write(buffer,0,n);}}
                text=System.Text.Encoding.UTF8.GetString(memory.ToArray());
            }
            var settings=new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MetadataPropertyHandling=MetadataPropertyHandling.Ignore,MaxDepth=64,Culture=CultureInfo.InvariantCulture,CheckAdditionalContent=true};
            try{return JsonConvert.DeserializeObject<T>(text,settings);}catch(JsonException e){throw new InvalidDataException("Malformed own payload.",e);}
        }
        public static Vector3 V(float[] a){if(a==null||a.Length!=3||a.Any(x=>!Finite(x)))throw new InvalidDataException("Invalid vector.");return new Vector3(a[0],a[1],a[2]);}
        public static Quaternion Q(float[] a){if(a==null||a.Length!=4||a.Any(x=>!Finite(x)))throw new InvalidDataException("Invalid quaternion.");var q=new Quaternion(a[0],a[1],a[2],a[3]);if(Math.Abs(Quaternion.Dot(q,q)-1)>.003f)throw new InvalidDataException("Non-unit quaternion.");return q;}
        public static Matrix4x4 M(MatrixRecord a){if(a?.values==null||a.values.Length!=16||a.values.Any(x=>!Finite(x)))throw new InvalidDataException("Invalid bind matrix.");var m=new Matrix4x4();for(int i=0;i<4;i++)for(int j=0;j<4;j++)m[i,j]=a.values[i*4+j];return m;}
        public static void Validate(VisualPayload p,bool camp)
        {
            if(p==null||p.schema!=(camp?"wayfarer.camp-visual.v1":"wayfarer.actor-visual.v1")||p.sourceNative?.sha256!=NativeSha||p.nodes==null||p.nodes.Length<1||p.nodes.Length>1024||p.renderers==null||p.renderers.Length<1||p.renderers.Length>256||p.materials==null||p.materials.Length<1||p.materials.Length>256)throw new InvalidDataException("Wrong authored visual source/schema/inventory.");
            var seen=new HashSet<int>();var names=new HashSet<string>(StringComparer.Ordinal);
            foreach(var n in p.nodes){if(n==null||!seen.Add(n.id)||string.IsNullOrWhiteSpace(n.name)||!names.Add(n.name)||n.parentId>=0&&!seen.Contains(n.parentId)||n.parentId==n.id)throw new InvalidDataException("Invalid parent-first own hierarchy.");V(n.position);Q(n.rotation);var s=V(n.scale);if(Math.Abs(s.x)<1e-8||Math.Abs(s.y)<1e-8||Math.Abs(s.z)<1e-8)throw new InvalidDataException("Zero node scale.");}
            if(p.nodes.Count(n=>n.parentId<0)!=1)throw new InvalidDataException("Exactly one visual root required.");
            if(p.materials.Any(m=>m==null||string.IsNullOrWhiteSpace(m.id))||p.materials.Select(m=>m.id).Distinct().Count()!=p.materials.Length)throw new InvalidDataException("Missing/duplicate material.");
            var ids=new HashSet<string>(p.materials.Select(m=>m.id));
            foreach(var m in p.materials){foreach(var map in new[]{m.diffuse,m.normal,m.metallicGloss,m.emission})if(map!=null)CheckMap(map);if(m.normal!=null&&m.normalEncoding!="dxt5nm-ag")throw new InvalidDataException("Normals must have declared AG packing.");if(!Finite(m.metallic)||!Finite(m.roughness)||m.metallic<0||m.metallic>1||m.roughness<0||m.roughness>1)throw new InvalidDataException("Invalid PBR scalar.");}
            long tris=0;
            foreach(var r in p.renderers)
            {
                if(r==null||!seen.Contains(r.nodeId)||r.vertices==null||r.vertices.Length%3!=0)throw new InvalidDataException("Missing renderer/node.");int n=r.vertices.Length/3;
                if(n<3||n>1000000||r.normals?.Length!=n*3||r.uv?.Length!=n*2||r.vertices.Concat(r.normals).Concat(r.uv).Any(x=>!Finite(x))||r.submeshes==null||r.submeshes.Length<1||r.submeshes.Length>64||r.materialIds?.Length!=r.submeshes.Length||r.materialIds.Any(m=>!ids.Contains(m)))throw new InvalidDataException("Invalid finite mesh/material arrays.");
                foreach(var sub in r.submeshes){if(sub==null||sub.Length%3!=0||sub.Any(i=>i<0||i>=n))throw new InvalidDataException("Invalid indices.");tris+=sub.Length/3;}
                V(r.boundsCenter);if(V(r.boundsSize).x<0||V(r.boundsSize).y<0||V(r.boundsSize).z<0)throw new InvalidDataException("Invalid renderer bounds.");
                if(r.type=="skin")
                {
                    if(r.boneNodeIds==null||r.boneNodeIds.Length<1||r.boneNodeIds.Length>256||r.boneNodeIds.Any(i=>!seen.Contains(i))||r.bindposes?.Length!=r.boneNodeIds.Length||r.weights?.Length!=n||!seen.Contains(r.rootBoneNodeId))throw new InvalidDataException("Invalid skin references.");
                    foreach(var b in r.bindposes)M(b);
                    if(r.deformationMode!=null&&r.deformationMode!="linear"&&r.deformationMode!="dual-quaternion-rigid")throw new InvalidDataException("Unknown deformation mode.");
                    if(r.deformationMode=="dual-quaternion-rigid"&&(r.sourceVertexIds?.Length!=n||r.sourceVertexIds.Any(i=>i<0)))throw new InvalidDataException("DQS deduplication map missing.");
                    foreach(var w in r.weights)if(w?.indices?.Length!=4||w.weights?.Length!=4||w.indices.Any(i=>i<0||i>=r.boneNodeIds.Length)||w.weights.Any(v=>!Finite(v)||v<0||v>1)||Math.Abs(w.weights.Sum()-1)>.001f)throw new InvalidDataException("Invalid four-influence weights.");
                    if(camp&&r.collider!="none")throw new InvalidDataException("Dynamic bag cannot also have static collider.");
                }
                else if(r.type!="rigid")throw new InvalidDataException("Unknown renderer type.");
                if(r.collider!=null&&!new[]{"none","mesh","canvas-double"}.Contains(r.collider))throw new InvalidDataException("Unknown collider policy.");
            }
            if(tris<1||tris>300000)throw new InvalidDataException("Runtime triangle budget.");
            if(camp){if(!p.renderers.Any(r=>r.collider=="canvas-double"))throw new InvalidDataException("Actual canvas collision is required.");if(p.actorPlacement==null||p.nativeInstances==null||p.nativeInstances.Length!=8)throw new InvalidDataException("Camp placement/native instance contract missing.");V(p.actorPlacement.position);Q(p.actorPlacement.rotation);V(p.actorPlacement.scale);V(p.boundsMin);V(p.boundsMax);foreach(var x in p.nativeInstances){if(x.prefab!="Wood"&&x.prefab!="fire_pit")throw new InvalidDataException("Unexpected native binding.");V(x.position);Q(x.rotation);V(x.scale);}}
        }
        public static void Validate(MotionPayload b,VisualPayload p)
        {
            if(b?.schema!="wayfarer.actor-motion.v1"||b.sourceNative?.sha256!=NativeSha||b.boneNames==null||b.boneNames.Length<161||b.boneNames.Length>256||b.boneNames.Distinct().Count()!=b.boneNames.Length||b.boneNames.Any(n=>!p.nodes.Any(x=>x.name==n))||b.clips==null||b.clips.Length<1||b.clips.Length>40||!Finite(b.fps)||Math.Abs(b.fps-30)>.001f||b.aliases==null||!b.aliases.ContainsKey("idle"))throw new InvalidDataException("Source motion bank mismatch.");
            foreach(var c in b.clips){if(c==null||string.IsNullOrWhiteSpace(c.name)||!Finite(c.duration)||c.duration<=0||c.duration>120||c.frames==null||c.frames.Length<2||c.frames.Length>3601)throw new InvalidDataException("Invalid source clip.");float last=-1;foreach(var f in c.frames){if(f==null||!Finite(f.time)||f.time<last||f.positions?.Length!=b.boneNames.Length*3||f.rotations?.Length!=b.boneNames.Length*4||f.scales?.Length!=b.boneNames.Length*3||f.positions.Concat(f.rotations).Concat(f.scales).Any(v=>!Finite(v))||f.scales.Any(v=>v<=0||v>100))throw new InvalidDataException("Invalid source pose arrays.");last=f.time;for(int i=0;i<b.boneNames.Length;i++){int q=i*4;float n=0;for(int j=0;j<4;j++)n+=f.rotations[q+j]*f.rotations[q+j];if(Math.Abs(n-1)>.003)throw new InvalidDataException("Nonunit source pose rotation.");}}}
            if(b.clips.Select(c=>c.name).Distinct().Count()!=b.clips.Length||b.aliases.Values.Any(n=>!b.clips.Any(c=>c.name==n)))throw new InvalidDataException("Ambiguous motion alias.");
        }
    }
}
