using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Jotunn.Managers;
using Wayfarer.CampPhysics;
using Object=UnityEngine.Object;

namespace Wayfarer.InGame
{
    public sealed class CampInstance:MonoBehaviour
    {
        public static readonly HashSet<CampInstance> Live=new HashSet<CampInstance>();
        public bool Ready{get;private set;}public string Failure{get;private set;} public TentBagPendulum Bag{get;private set;}
        public ZNetView View{get;private set;}
        IEnumerator Start()
        {
            View=GetComponent<ZNetView>();if(!View||!View.IsValid())yield break;
            Live.Add(this);var plugin=WayfarerPlugin.Instance;if(!plugin){Failure="Plugin missing";yield break;}
            var ground=GetComponent<CampTerrainSupport>();
            // Native sector reload is independent for camp, NPC and fire. The
            // camp's visuals must not be gated by its outer terrain feather or
            // unrelated neighbor-sector objects. New placement still explicitly
            // awaits ground.Ensure before its destructive site commit.
            if(ground)StartCoroutine(ground.Ensure());
            yield return plugin.Assets.Ensure();if(!this)yield break;
            try
            {
                if(!plugin.Assets.Ready)throw new InvalidOperationException(plugin.Assets.Failure);
                var root=new GameObject("CampVisual");root.transform.SetParent(transform,false);
                var named=plugin.Assets.Camp.Build(root.transform,plugin.Assets.Layer,true);
                float scale=CampInstanceScale.Read(View.GetZDO(),CampInstanceScale.CampKey);root.transform.localScale=Vector3.one*scale;
                NativeWood(root.transform,plugin.Assets.Camp.Payload.nativeInstances);
                plugin.Assets.Camp.AddFixtures(named,scale);
                if(ground)ground.ConfigureLegacyGrass(PayloadReader.V(plugin.Assets.Camp.Payload.boundsMin)*scale,PayloadReader.V(plugin.Assets.Camp.Payload.boundsMax)*scale);
                gameObject.AddComponent<CampInteractionBindings>().Configure(View,named);
                // Last: all fixed markers and actual static canvas colliders
                // already exist before binding the one physical hanging bag.
                Bag=TentBagPendulum.ConfigureFromImportedRig(root,plugin.Assets.Layer);
                Ready=true;WayfarerPlugin.Report("WF_CAMP_INSTANCE_READY uid="+View.GetZDO().m_uid+" layer=static_solid bag="+Bag.Initialized);
            }
            catch(Exception e){Failure=e.Message;WayfarerPlugin.Report("WF_CAMP_INSTANCE_FAILED "+e);}
        }
        static void NativeWood(Transform root,NativeInstanceRecord[] placements)
        {
            var source=PrefabManager.Instance.GetPrefab("Wood");if(!source)throw new InvalidOperationException("Installed Wood prefab missing.");
            var staging=new GameObject("WF_Wood_Visuals");staging.SetActive(false);staging.transform.SetParent(root,false);
            foreach(var p in placements)if(p.visualOnly)
            {
                if(p.prefab!="Wood")throw new InvalidOperationException("Only installed Wood may be cosmetic.");
                var copy=Object.Instantiate(source,staging.transform,false);copy.name=p.name;copy.SetActive(false);
                // Parent is inactive before Instantiate: native Awake has not
                // run and no item/network object has been created. Strip all
                // behaviors and collision before ever activating the visuals.
                foreach(var b in copy.GetComponentsInChildren<MonoBehaviour>(true))Object.DestroyImmediate(b);
                foreach(var c in copy.GetComponentsInChildren<Collider>(true))Object.DestroyImmediate(c);
                foreach(var b in copy.GetComponentsInChildren<Rigidbody>(true))Object.DestroyImmediate(b);
                foreach(var a in copy.GetComponentsInChildren<AudioSource>(true))Object.DestroyImmediate(a);
                foreach(var a in copy.GetComponentsInChildren<ParticleSystem>(true))Object.DestroyImmediate(a);
                foreach(var a in copy.GetComponentsInChildren<Light>(true))Object.DestroyImmediate(a);
                copy.transform.localPosition=PayloadReader.V(p.position);copy.transform.localRotation=PayloadReader.Q(p.rotation);copy.transform.localScale=PayloadReader.V(p.scale);copy.SetActive(true);
            }
            staging.SetActive(true);
        }
        void OnDestroy(){Live.Remove(this);}
    }
    public sealed class NpcInstance:MonoBehaviour
    {
        public static readonly HashSet<NpcInstance> Live=new HashSet<NpcInstance>();
        public bool Ready{get;private set;}public string Failure{get;private set;}public SourcePosePlayer Pose{get;private set;}public ZNetView View{get;private set;}
        public CapsuleCollider BodyCollider;
        Renderer[] nativeRenderers;
        IEnumerator Start()
        {
            View=GetComponent<ZNetView>();if(!View||!View.IsValid())yield break;
            Live.Add(this);nativeRenderers=GetComponentsInChildren<Renderer>(true);foreach(var r in nativeRenderers)r.enabled=false;
            var plugin=WayfarerPlugin.Instance;if(!plugin){Failure="Plugin missing";yield break;}
            yield return plugin.Assets.Ensure();if(!this)yield break;
            try
            {
                if(!plugin.Assets.Ready)throw new InvalidOperationException(plugin.Assets.Failure);
                var root=new GameObject("WayfarerVisual");root.transform.SetParent(transform,false);
                var named=plugin.Assets.Actor.Build(root.transform,plugin.Assets.Layer,false);
                float scale=CampInstanceScale.Read(View.GetZDO(),CampInstanceScale.ActorKey);root.transform.localScale=Vector3.one*scale;
                var capsule=BodyCollider;if(!capsule)throw new InvalidOperationException("Own Wayfarer body capsule binding unavailable.");capsule.center=new Vector3(0,.91f*scale,0);capsule.height=1.82f*scale;capsule.radius=.27f*scale;capsule.enabled=true;
                var trader=GetComponent<Trader>();if(trader){trader.m_dialogHeight=1.85f*scale;trader.m_hoverOffset=1.65f*scale;}
                Pose=root.AddComponent<SourcePosePlayer>();Pose.Initialize(plugin.Assets.Motion,named);Ready=true;
                WayfarerPlugin.Report("WF_NPC_INSTANCE_READY uid="+View.GetZDO().m_uid+" clips=4 source=c0000 stock=empty");
            }
            catch(Exception e){Failure=e.Message;WayfarerPlugin.Report("WF_NPC_INSTANCE_FAILED "+e);}
        }
        void LateUpdate(){if(nativeRenderers!=null)foreach(var r in nativeRenderers)if(r)r.enabled=false;}
        public void Gesture(string alias){if(Ready&&Pose)Pose.Play(alias,false);}
        void OnDestroy(){Live.Remove(this);}
    }
}
