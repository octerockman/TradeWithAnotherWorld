using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Reflection;
using UnityEngine;
using Jotunn.Entities;
using Jotunn.Managers;
using Object=UnityEngine.Object;

namespace Wayfarer.InGame
{
    public sealed class LedgerContent {public string title,text;}
    public sealed class InteractionManifest {public string schema,sourceNativeSha256;public MapRecord icon;public LedgerContent ledger;}
    public static class StrangeCoinItem
    {
        public const string PrefabName="TWA_StrangeCoin_v1",IssuedKey="twa_wf_coin_issued_v5",LinkKey="twa_wf_coin_v5";
        public static GameObject Prefab{get;private set;}static Texture2D iconTexture;static Sprite icon;
        public static LedgerContent Ledger{get;private set;}
        public static void Register(string dataFolder)
        {
            if(Prefab)return;string folder=Path.Combine(dataFolder,"interactions");
            var descriptor=PayloadReader.Read<InteractionManifest>(PayloadReader.Safe(folder,"manifest.json"));
            if(descriptor?.schema!="wayfarer.camp-interactions.v1"||descriptor.sourceNativeSha256!=PayloadReader.NativeSha)throw new InvalidDataException("Wrong camp-interaction resource source.");
            if(descriptor.ledger!=null){if(string.IsNullOrWhiteSpace(descriptor.ledger.title)||string.IsNullOrWhiteSpace(descriptor.ledger.text)||descriptor.ledger.title.Length>120||descriptor.ledger.text.Length>16000)throw new InvalidDataException("Optional ledger needs bounded nonempty approved content.");Ledger=descriptor.ledger;}
            var approved=ApprovedLedgerContent.Load(dataFolder);if(approved!=null)Ledger=approved;
            PayloadReader.CheckMap(descriptor.icon);string file=PayloadReader.Safe(folder,descriptor.icon.path);
            if(new FileInfo(file).Length>1024*1024||PayloadReader.Hash(file)!=descriptor.icon.sha256)throw new InvalidDataException("Strange Coin icon hash/size mismatch.");
            iconTexture=new Texture2D(2,2,TextureFormat.RGBA32,false,false);if(!ImageConversion.LoadImage(iconTexture,File.ReadAllBytes(file),false)||iconTexture.width!=256||iconTexture.height!=256)throw new InvalidDataException("Own Strange Coin icon must be256px.");iconTexture.name="WF_StrangeCoin_OwnIcon";iconTexture.Apply(false,true);
            icon=Sprite.Create(iconTexture,new Rect(0,0,256,256),new Vector2(.5f,.5f),100);icon.name="Strange Coin - own crescent bridge art";
            var source=PrefabManager.Instance.GetPrefab("Amber");if(!source||!source.GetComponent<ItemDrop>())throw new InvalidOperationException("Native material-item behavior template unavailable.");
            var item=new CustomItem(PrefabName,"Amber");var root=item.ItemPrefab;root.SetActive(false);root.transform.localScale=Vector3.one;root.transform.localRotation=Quaternion.identity;
            foreach(var child in root.transform.Cast<Transform>().ToArray())Object.DestroyImmediate(child.gameObject);
            foreach(var r in root.GetComponents<Renderer>())Object.DestroyImmediate(r);
            foreach(var mf in root.GetComponents<MeshFilter>())Object.DestroyImmediate(mf);
            foreach(var lod in root.GetComponents<LODGroup>())Object.DestroyImmediate(lod);
            foreach(var c in root.GetComponentsInChildren<Collider>(true))Object.DestroyImmediate(c);
            var original=source.GetComponent<ItemDrop>().m_itemData;var data=original.Clone();data.m_dropPrefab=root;data.m_stack=1;data.m_quality=1;data.m_variant=0;
            data.m_shared=(ItemDrop.ItemData.SharedData)typeof(object).GetMethod("MemberwiseClone",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(original.m_shared,null);
            var shared=data.m_shared;shared.m_name="Strange Coin";shared.m_description="A worn coin stamped with a crescent moon above an arched bridge. You have never seen its like in this world, nor in the one before.";shared.m_icons=new[]{icon};shared.m_itemType=ItemDrop.ItemData.ItemType.Material;shared.m_value=0;shared.m_weight=.01f;shared.m_maxStackSize=1;shared.m_questItem=false;shared.m_teleportable=true;shared.m_useDurability=false;
            item.ItemDrop.m_itemData=data;item.ItemDrop.m_autoPickup=false;item.ItemDrop.m_autoDestroy=false;
            var body=root.GetComponent<Rigidbody>()??root.AddComponent<Rigidbody>();body.isKinematic=false;body.useGravity=true;body.constraints=RigidbodyConstraints.None;
            var physical=root.AddComponent<BoxCollider>();physical.size=new Vector3(.05f,.008f,.05f);physical.center=new Vector3(0,.004f,0);
            var hover=new GameObject("WF_StrangeCoin_Hover");hover.layer=root.layer;hover.transform.SetParent(root.transform,false);hover.AddComponent<SphereCollider>().radius=.075f;hover.GetComponent<SphereCollider>().isTrigger=true;
            var view=root.GetComponent<ZNetView>();if(!view)throw new InvalidOperationException("Native item template needs its network view.");view.m_persistent=true;root.AddComponent<StrangeCoinVisual>();
            if(!ItemManager.Instance.AddItem(item))throw new InvalidOperationException("Own Strange Coin item registration failed.");root.SetActive(true);Prefab=root;
            WayfarerPlugin.Report("WF_STRANGE_COIN_REGISTERED ownArt=true nativeCurrency=false value=0 stack=1");
        }
        public static Vector3 Contact(VisualPayload payload)=>CoinPresentation.Contact(payload.renderers.Single(r=>r.name==CoinPresentation.Selected).vertices);
        public static void Dispose(){if(icon)Object.Destroy(icon);if(iconTexture)Object.Destroy(iconTexture);icon=null;iconTexture=null;Prefab=null;Ledger=null;}
    }
    public sealed class StrangeCoinVisual:MonoBehaviour
    {
        public static Func<Transform,Bounds> DroppedVisual;
        public bool Ready{get;private set;}public string Failure{get;private set;}
        IEnumerator Start()
        {
            var view=GetComponent<ZNetView>();if(!view||!view.IsValid())yield break;var plugin=WayfarerPlugin.Instance;if(!plugin)yield break;
            if(!(WayfarerPlugin.Owned(view.GetZDO())&&view.GetZDO().GetString(WayfarerPlugin.RoleKey,"")=="coin")&&DroppedVisual!=null)
            {
                try{var bounds=DroppedVisual(transform);var collider=GetComponent<BoxCollider>();collider.center=bounds.center;collider.size=bounds.size;Ready=true;}
                catch(Exception e){Failure=e.Message;WayfarerPlugin.Report("WF_DROPPED_COIN_POUCH_FAILED "+e);}
                yield break;
            }
            yield return plugin.Assets.Ensure();if(!this)yield break;
            try
            {
                if(!plugin.Assets.Ready)throw new InvalidOperationException(plugin.Assets.Failure);
                float factor=view.GetZDO().GetFloat(CampInstanceScale.CampKey,CampInstanceScale.NewCamp);
                var b=plugin.Assets.Camp.AddLooseCoin(transform,factor);var box=GetComponent<BoxCollider>();box.center=b.center;box.size=new Vector3(Mathf.Max(b.size.x,.003f),Mathf.Max(b.size.y,.003f),Mathf.Max(b.size.z,.003f));
                if(WayfarerPlugin.Owned(view.GetZDO())&&view.GetZDO().GetString(WayfarerPlugin.RoleKey,"")=="coin")
                {var rb=GetComponent<Rigidbody>();rb.useGravity=false;rb.isKinematic=true;rb.constraints=RigidbodyConstraints.FreezeAll;}
                Ready=true;
            }
            catch(Exception e){Failure=e.Message;WayfarerPlugin.Report("WF_STRANGE_COIN_VISUAL_FAILED "+e);}
        }
    }
}
