using System;
namespace Wayfarer.InGame
{
    public static class CampLightingPolicy
    {
        public static float LanternRange(float nativeRange,float factor)
        {
            if(float.IsNaN(nativeRange)||float.IsInfinity(nativeRange)||nativeRange<=0
                ||float.IsNaN(factor)||float.IsInfinity(factor)||factor<=0||factor>4)
                throw new ArgumentException("Invalid lantern-light profile.");
            return Math.Max(nativeRange,4f)*factor;
        }
    }
}
