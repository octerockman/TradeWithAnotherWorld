using System;
namespace Wayfarer.InGame
{
    public static class NatureSitePolicy
    {
        public static bool ProtectPiece(bool registeredNature,bool playerPlaced)
        {return !registeredNature||playerPlaced;}
        public static bool Intersects(float boxMinX,float boxMaxX,float boxMinZ,float boxMaxZ,float minX,float maxX,float minZ,float maxZ,float pad,float feather)
        {
            float x=Math.Max(Math.Max(minX-pad-boxMaxX,boxMinX-maxX-pad),0);
            float z=Math.Max(Math.Max(minZ-pad-boxMaxZ,boxMinZ-maxZ-pad),0);
            return x*x+z*z<=feather*feather;
        }
        public static bool Eligible(bool registeredNatureProvenance,bool matchingNatureRoot,bool protectedContents,bool oneValidNetworkRoot)
        {return registeredNatureProvenance&&matchingNatureRoot&&!protectedContents&&oneValidNetworkRoot;}
    }
}
