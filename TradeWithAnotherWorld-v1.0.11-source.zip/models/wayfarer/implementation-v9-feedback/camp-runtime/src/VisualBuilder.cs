using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using Jotunn.Managers;
using Object=UnityEngine.Object;

namespace Wayfarer.InGame
{
    // This builder consumes only the source-bound own-art payload. Native game
    // prefabs are resolved from the running installation, never shipped here.
    public sealed class VisualBuilder:IDisposable
    {
        public readonly VisualPayload Payload;
        public readonly string Folder;
        readonly Dictionary<string,Texture2D> textures=new Dictionary<string,Texture2D>();
        readonly Dictionary<string,Material> materials=new Dictionary<string,Material>();
        readonly Dictionary<RendererRecord,Mesh> meshes=new Dictionary<RendererRecord,Mesh>();
        readonly Dictionary<Mesh,Mesh> collisionMeshes=new Dictionary<Mesh,Mesh>();
        readonly Dictionary<RendererRecord,Mesh> interactionMeshes=new Dictionary<RendererRecord,Mesh>();
        readonly List<Object> resources=new List<Object>();
        readonly Material opaqueTemplate,glassTemplate;
        readonly Action<string> log;
        public string GlassShader=>glassTemplate.shader.name;
        public int TextureCount=>textures.Count;
        public long TextureEstimatedBytes{get;private set;}

        public VisualBuilder(VisualPayload p,string folder,Material opaque,Material glass,Action<string> logger)
        {Payload=p;Folder=folder;opaqueTemplate=opaque;glassTemplate=glass;log=logger;}

        public void PrepareMaterials()
        {
            foreach(var record in Payload.materials)if(!materials.ContainsKey(record.id))materials.Add(record.id,MakeMaterial(record));
        }
        public void PrepareMaterial(MaterialRecord record){if(!materials.ContainsKey(record.id))materials.Add(record.id,MakeMaterial(record));}

        public Dictionary<string,Transform> Build(Transform root,int layer,bool colliders)
        {
            var nodes=new Dictionary<int,Transform>();var named=new Dictionary<string,Transform>(StringComparer.Ordinal);
            foreach(var n in Payload.nodes)
            {
                Transform t;
                if(n.parentId<0)t=root;
                else{t=new GameObject(n.name).transform;t.SetParent(nodes[n.parentId],false);}
                t.localPosition=PayloadReader.V(n.position);t.localRotation=PayloadReader.Q(n.rotation);t.localScale=PayloadReader.V(n.scale);t.gameObject.layer=layer;
                nodes.Add(n.id,t);named.Add(n.name,t);
            }
            foreach(var r in Payload.renderers)
            {
                var node=nodes[r.nodeId];var mesh=Mesh(r);
                if(Payload.schema=="wayfarer.camp-visual.v1"&&(r.name=="WF_A05_kettle"||r.name=="WF_A04_ledger"))
                {
                    // Exported static vertices are world-baked. Give interactive
                    // authored props a useful local origin while preserving
                    // every world vertex, collider, UV and source appearance.
                    var pivot=mesh.bounds.center;node.localPosition+=pivot;
                    if(!interactionMeshes.TryGetValue(r,out var anchored)){anchored=Object.Instantiate(mesh);anchored.name=mesh.name+"_InteractionOrigin";var v=anchored.vertices;for(int i=0;i<v.Length;i++)v[i]-=pivot;anchored.vertices=v;anchored.RecalculateBounds();interactionMeshes.Add(r,anchored);resources.Add(anchored);}mesh=anchored;
                }
                var assigned=r.materialIds.Select(m=>materials[m]).ToArray();Renderer renderer;
                if(r.type=="skin"&&(r.deformationMode=="dual-quaternion"||r.deformationMode=="dual-quaternion-rigid"))
                {
                    var copy=Object.Instantiate(mesh);copy.name=mesh.name+"_DQS_Instance";
                    node.gameObject.AddComponent<MeshFilter>().sharedMesh=copy;
                    renderer=node.gameObject.AddComponent<MeshRenderer>();
                    var dq=node.gameObject.AddComponent<DualQuaternionSkin>();dq.Initialize(copy,r,r.boneNodeIds.Select(i=>nodes[i]).ToArray());
                }
                else if(r.type=="skin")
                {
                    var skin=node.gameObject.AddComponent<SkinnedMeshRenderer>();skin.sharedMesh=mesh;skin.bones=r.boneNodeIds.Select(i=>nodes[i]).ToArray();skin.rootBone=nodes[r.rootBoneNodeId];skin.localBounds=new Bounds(PayloadReader.V(r.boundsCenter),PayloadReader.V(r.boundsSize));skin.updateWhenOffscreen=true;skin.quality=SkinQuality.Bone4;renderer=skin;
                }
                else{node.gameObject.AddComponent<MeshFilter>().sharedMesh=mesh;renderer=node.gameObject.AddComponent<MeshRenderer>();}
                renderer.sharedMaterials=assigned;renderer.shadowCastingMode=ShadowCastingMode.On;renderer.receiveShadows=true;
                if(colliders&&r.type=="rigid"&&r.collider!="none"&&!string.IsNullOrEmpty(r.collider))
                {
                    var c=node.gameObject.AddComponent<MeshCollider>();c.sharedMesh=r.collider=="canvas-double"?DoubleCollision(mesh):mesh;c.convex=false;c.contactOffset=.003f;
                }
            }
            return named;
        }
        Mesh DoubleCollision(Mesh input)
        {
            if(collisionMeshes.TryGetValue(input,out var found))return found;
            var m=new Mesh{name=input.name+"_DoubleSidedCollision",indexFormat=input.indexFormat};m.vertices=input.vertices;var indices=input.triangles;var both=new int[indices.Length*2];Array.Copy(indices,both,indices.Length);
            for(int i=0;i<indices.Length;i+=3){both[indices.Length+i]=indices[i+2];both[indices.Length+i+1]=indices[i+1];both[indices.Length+i+2]=indices[i];}
            m.triangles=both;m.RecalculateBounds();resources.Add(m);collisionMeshes.Add(input,m);return m;
        }
        Mesh Mesh(RendererRecord r)
        {
            if(meshes.TryGetValue(r,out var found))return found;
            int n=r.vertices.Length/3;var vs=new Vector3[n];var ns=new Vector3[n];var uv=new Vector2[n];var colors=new Color32[n];
            for(int i=0;i<n;i++){vs[i]=new Vector3(r.vertices[i*3],r.vertices[i*3+1],r.vertices[i*3+2]);ns[i]=new Vector3(r.normals[i*3],r.normals[i*3+1],r.normals[i*3+2]);uv[i]=new Vector2(r.uv[i*2],r.uv[i*2+1]);colors[i]=new Color32(255,255,255,255);}
            if(Payload.schema=="wayfarer.camp-visual.v1"&&CoinPresentation.IsCoin(r.name)){var contact=CoinPresentation.Contact(r.vertices);for(int i=0;i<n;i++)vs[i]=CoinPresentation.Enlarge(vs[i],contact);}
            var m=new Mesh{name=r.name,indexFormat=n>65535?IndexFormat.UInt32:IndexFormat.UInt16,vertices=vs,normals=ns,uv=uv,colors32=colors,subMeshCount=r.submeshes.Length};
            for(int i=0;i<r.submeshes.Length;i++)
            {
                var indices=r.submeshes[i];
                // Two crossed alpha cards have no physical back surface. Keep
                // them visible even when a native material culls backfaces.
                if(n<=32&&Payload.materials.Any(x=>x.id==r.materialIds[i]&&x.alphaCutout))
                {var both=new int[indices.Length*2];Array.Copy(indices,both,indices.Length);for(int j=0;j<indices.Length;j+=3){both[indices.Length+j]=indices[j+2];both[indices.Length+j+1]=indices[j+1];both[indices.Length+j+2]=indices[j];}indices=both;}
                m.SetTriangles(indices,i,false);
            }
            if(r.type=="skin")
            {
                m.bindposes=r.bindposes.Select(PayloadReader.M).ToArray();m.boneWeights=r.weights.Select(w=>new BoneWeight{boneIndex0=w.indices[0],boneIndex1=w.indices[1],boneIndex2=w.indices[2],boneIndex3=w.indices[3],weight0=w.weights[0],weight1=w.weights[1],weight2=w.weights[2],weight3=w.weights[3]}).ToArray();
            }
            m.RecalculateBounds();m.RecalculateTangents();resources.Add(m);meshes.Add(r,m);return m;
        }
        Texture2D Texture(MapRecord map,bool linear,string wrap)
        {
            string key=map.sha256+":"+linear+":"+wrap;
            if(textures.TryGetValue(key,out var cached))return cached;
            string path=PayloadReader.Safe(Folder,map.path);
            if(new FileInfo(path).Length>64*1024*1024||PayloadReader.Hash(path)!=map.sha256)throw new InvalidDataException("Texture hash/size mismatch:"+map.path);
            var t=new Texture2D(2,2,TextureFormat.RGBA32,true,linear);resources.Add(t);
            if(!ImageConversion.LoadImage(t,File.ReadAllBytes(path),false)||t.width>4096||t.height>4096||t.width<1||t.height<1)throw new InvalidDataException("Invalid source texture.");
            t.name="WF_"+Path.GetFileName(map.path);t.wrapMode=wrap=="repeat"?TextureWrapMode.Repeat:TextureWrapMode.Clamp;t.filterMode=FilterMode.Trilinear;t.anisoLevel=4;
            // Actual Unity-supported compression once at lazy admission, never
            // per frame. AG normals and smoothness keep their alpha in DXT5.
            try{t.Compress(true);}catch(Exception e){log?.Invoke("WF_TEXTURE_COMPRESSION_FALLBACK "+map.path+" "+e.Message);}
            t.Apply(true,true);TextureEstimatedBytes+=(long)t.width*t.height*(t.format==TextureFormat.DXT1?1: t.format==TextureFormat.DXT5?2:8)/2*4/3;
            textures.Add(key,t);return t;
        }
        static void Float(Material m,string name,float value){if(m.HasProperty(name))m.SetFloat(name,value);}
        static void ColorValue(Material m,string name,Color value){if(m.HasProperty(name))m.SetColor(name,value);}
        Material MakeMaterial(MaterialRecord r)
        {
            if(r.transparent&&!glassTemplate)throw new InvalidOperationException("Native transparent crystal_window template unavailable; refuse opaque substitute.");
            var m=new Material(r.transparent?glassTemplate:opaqueTemplate){name="WF_"+r.name};resources.Add(m);
            foreach(var prop in m.GetTexturePropertyNames()){m.SetTexture(prop,null);m.SetTextureScale(prop,Vector2.one);m.SetTextureOffset(prop,Vector2.zero);}
            var c=r.color??r.baseColor;var color=c!=null&&c.Length==4?new Color(c[0],c[1],c[2],c[3]):Color.white;
            if(r.transparent)color.a=Mathf.Clamp(color.a,.04f,.20f);
            ColorValue(m,"_Color",color);ColorValue(m,"_MetalColor",Color.white);Float(m,"_Metallic",r.metallic);Float(m,"_Glossiness",1-r.roughness);
            foreach(var prop in new[]{"_Hue","_Saturation","_Value","_UseStyles","_Style","_NoiseGlowEnabled","_SnowCover","_AddRain","_AddSnow","_ValueNoise","_TriplanarMap"})Float(m,prop,0);
            if(r.diffuse!=null)m.SetTexture("_MainTex",Texture(r.diffuse,false,r.wrap));
            if(r.normal!=null){m.SetTexture("_BumpMap",Texture(r.normal,true,r.wrap));Float(m,"_BumpScale",r.normalScale);m.EnableKeyword("_NORMALMAP");}else m.DisableKeyword("_NORMALMAP");
            if(r.metallicGloss!=null){var tex=Texture(r.metallicGloss,true,r.wrap);if(m.HasProperty("_MetallicGlossMap"))m.SetTexture("_MetallicGlossMap",tex);if(m.HasProperty("_MetallicTex"))m.SetTexture("_MetallicTex",tex);Float(m,"_UseGlossmap",1);Float(m,"_MetallicAlphaGloss",1);m.EnableKeyword("_METALLICGLOSSMAP");}
            else{Float(m,"_UseGlossmap",0);m.DisableKeyword("_METALLICGLOSSMAP");}
            if(r.emission!=null){m.SetTexture("_EmissionMap",Texture(r.emission,false,r.wrap));ColorValue(m,"_EmissionColor",Color.white*r.emissionStrength);m.EnableKeyword("_EMISSION");}else{ColorValue(m,"_EmissionColor",Color.black);m.DisableKeyword("_EMISSION");}
            if(r.doubleSided){Float(m,"_Cull",0);Float(m,"_TwoSidedNormals",1);}else Float(m,"_Cull",2);
            Float(m,"_Cutoff",r.alphaCutout?.45f:0f);
            if(r.alphaCutout){m.EnableKeyword("_ALPHATEST_ON");m.renderQueue=2450;m.SetOverrideTag("RenderType","TransparentCutout");}else m.DisableKeyword("_ALPHATEST_ON");
            if(r.transparent)
            {Float(m,"_Mode",2);Float(m,"_SrcBlend",(float)BlendMode.SrcAlpha);Float(m,"_DstBlend",(float)BlendMode.OneMinusSrcAlpha);Float(m,"_ZWrite",0);m.SetShaderPassEnabled("ShadowCaster",false);m.EnableKeyword("_ALPHABLEND_ON");m.DisableKeyword("_ALPHAPREMULTIPLY_ON");m.renderQueue=3000;m.SetOverrideTag("RenderType","Transparent");}
            else{Float(m,"_Mode",r.alphaCutout?1:0);Float(m,"_SrcBlend",(float)BlendMode.One);Float(m,"_DstBlend",(float)BlendMode.Zero);Float(m,"_ZWrite",1);m.DisableKeyword("_ALPHABLEND_ON");m.DisableKeyword("_ALPHAPREMULTIPLY_ON");}
            return m;
        }
        public void Dispose(){foreach(var x in resources)if(x)Object.Destroy(x);resources.Clear();textures.Clear();materials.Clear();meshes.Clear();collisionMeshes.Clear();interactionMeshes.Clear();looseCoin=null;}
        Mesh looseCoin;
        public Bounds AddLooseCoin(Transform parent,float campScale)
        {
            var record=Payload.renderers.Single(r=>r.name==CoinPresentation.Selected);var contact=CoinPresentation.Contact(record.vertices);
            if(!looseCoin){looseCoin=Object.Instantiate(Mesh(record));looseCoin.name="WF_StrangeCoin_OwnArt";var v=looseCoin.vertices;for(int i=0;i<v.Length;i++)v[i]-=contact;looseCoin.vertices=v;looseCoin.RecalculateBounds();resources.Add(looseCoin);}
            var model=new GameObject("Strange Coin - authored moon and bridge");model.transform.SetParent(parent,false);model.transform.localScale=Vector3.one*campScale;model.AddComponent<MeshFilter>().sharedMesh=looseCoin;model.AddComponent<MeshRenderer>().sharedMaterials=record.materialIds.Select(id=>materials[id]).ToArray();
            return new Bounds(looseCoin.bounds.center*campScale,looseCoin.bounds.size*campScale);
        }
        public void AddFixtures(Dictionary<string,Transform> nodes,float factor)
        {
            if(Payload.fixtures==null)return;
            foreach(var f in Payload.fixtures)
            {
                if(f.role!="candle"||!nodes.TryGetValue(f.name,out var socket))throw new InvalidOperationException("Missing candle fixture socket.");
                NativeCampLighting.AttachCandle(socket,factor);
            }
        }
    }
}
