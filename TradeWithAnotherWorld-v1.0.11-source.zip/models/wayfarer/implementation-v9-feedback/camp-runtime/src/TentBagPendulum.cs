using System;
using UnityEngine;
using UnityEngine.SceneManagement;
#if UNITY_6000_0_OR_NEWER || WF_UNITY6
using ContactMaterial = UnityEngine.PhysicsMaterial;
using ContactCombine = UnityEngine.PhysicsMaterialCombine;
#else
using ContactMaterial = UnityEngine.PhysicMaterial;
using ContactCombine = UnityEngine.PhysicMaterialCombine;
#endif

namespace Wayfarer.CampPhysics
{
    /// <summary>
    /// Instantiate-time, client-local camp dressing physics. Not a BepInEx plugin.
    /// A physical body carries the bag COM below its pinned crown; the imported
    /// Swing bone drives both bag and lower strap. No animation loop fakes motion.
    /// </summary>
    public sealed class TentBagPendulum : MonoBehaviour
    {
        [Serializable]
        public sealed class Settings
        {
            // Positions/sizes are measured in imported Swing local coordinates,
            // in metres. Bake model scale before binding; never guess axis swaps.
            public Vector3 centerOfMassLocal;
            public Vector3 boxCenterLocal, boxSizeLocal;
            public float massKg = .75f, angularDrag = 1.6f, linearDrag = .2f;
            public float maxSwingDegrees = 28f, maxTwistDegrees = 20f;
            public float teleportDistanceM = .75f;
            public int physicsLayer;
        }

        [SerializeField] Transform fixedAnchor, swing;
        [SerializeField] Vector3 com, boxCenter, boxSize, savedLocalPosition;
        [SerializeField] Quaternion savedLocalRotation, supportRotationOffset;
        [SerializeField] float massKg, angularDrag, linearDrag, maxSwing, maxTwist, teleportDistance;
        [SerializeField] int physicsLayer;
        [SerializeField] bool configured;
        Rigidbody body, support;
        ConfigurableJoint joint;
        ContactMaterial material;
        Vector3 lastAnchor;
        Quaternion savedWorldRotation;
        bool initialized;

        public bool Initialized => initialized;
        public Rigidbody DynamicBody => body;
        public Rigidbody AnchorBody => support;
        public ConfigurableJoint Joint => joint;
        public float AnchorGapM => initialized ? Vector3.Distance(body.position, fixedAnchor.position) : 0f;
        public float PendulumCOMLengthM => com.magnitude;

        public static TentBagPendulum Configure(GameObject owner, Transform fixedAnchor,
            Transform swing, Settings settings)
        {
            if (!owner || !fixedAnchor || !swing || settings == null)
                throw new ArgumentException("A camp instance, fixed crown, imported Swing bone and measured settings are required.");
            if (!swing.IsChildOf(owner.transform) || !fixedAnchor.IsChildOf(owner.transform) || swing == fixedAnchor)
                throw new ArgumentException("Both rig bindings must belong to this camp instance; the fixed socket must not be the moving Swing.");
            if (fixedAnchor.IsChildOf(swing))
                throw new ArgumentException("The fixed socket must remain outside the moving Swing hierarchy.");
            Validate(settings);
            var component = owner.GetComponent<TentBagPendulum>() ?? owner.AddComponent<TentBagPendulum>();
            if (component.configured) throw new InvalidOperationException("This camp already has bag physics.");
            component.fixedAnchor = fixedAnchor; component.swing = swing;
            component.com = settings.centerOfMassLocal;
            component.boxCenter = settings.boxCenterLocal; component.boxSize = settings.boxSizeLocal;
            component.massKg = settings.massKg; component.angularDrag = settings.angularDrag;
            component.linearDrag = settings.linearDrag; component.maxSwing = settings.maxSwingDegrees;
            component.maxTwist = settings.maxTwistDegrees; component.teleportDistance = settings.teleportDistanceM;
            component.physicsLayer = settings.physicsLayer;
            component.savedLocalPosition = swing.localPosition; component.savedLocalRotation = swing.localRotation;
            component.supportRotationOffset = Quaternion.Inverse(fixedAnchor.rotation) * swing.rotation;
            component.configured = true;
            if (component.isActiveAndEnabled) component.Initialize();
            return component;
        }

        // The optional automatic binding reads the saved markers AFTER import.
        // Run only on the spawned scene instance, not on an unloaded prefab asset.
        public static TentBagPendulum ConfigureFromImportedRig(GameObject camp, int layer = 0)
        {
            var anchor = Find(camp.transform, "WF_TentBag_FixedAnchor");
            var swing = Find(camp.transform, "WF_TentBag_Swing");
            var centre = Find(camp.transform, "WF_TentBag_COM");
            Bounds localBox = new Bounds();
            for (int i = 0; i < 8; i++)
            {
                Vector3 q = swing.InverseTransformPoint(Find(camp.transform, "WF_TentBag_BoxCorner_" + i).position);
                if (i == 0) localBox = new Bounds(q, Vector3.zero); else localBox.Encapsulate(q);
            }
            // V4 private runtime derivative: visual geometry may have positive
            // uniform scale. Independent physical bodies remain unit-scale, so
            // convert marker-local measurements into their metre coordinates.
            float scale = UniformScale(swing.lossyScale);
            return Configure(camp, anchor, swing, new Settings {
                centerOfMassLocal = swing.InverseTransformPoint(centre.position) * scale,
                boxCenterLocal = localBox.center * scale, boxSizeLocal = localBox.size * (.92f * scale),
                massKg = .75f * scale * scale * scale,
                physicsLayer = layer
            });
        }

        static Transform Find(Transform root, string name)
        {
            Transform found = null;
            foreach (var candidate in root.GetComponentsInChildren<Transform>(true))
                if (candidate.name == name)
                {
                    if (found) throw new InvalidOperationException("Duplicate camp rig binding: " + name);
                    found = candidate;
                }
            if (!found) throw new InvalidOperationException("Missing imported camp rig binding: " + name + ". Preserve bones and markers on export.");
            return found;
        }

        static void Validate(Settings x)
        {
            if (!Finite(x.centerOfMassLocal) || !Finite(x.boxCenterLocal) || !Finite(x.boxSizeLocal)
                || x.centerOfMassLocal.magnitude < .05f || x.centerOfMassLocal.magnitude > 1.2f
                || x.boxSizeLocal.x < .01f || x.boxSizeLocal.y < .01f || x.boxSizeLocal.z < .01f
                || !(x.massKg > .01f) || !Finite(x.massKg) || x.massKg > 20f
                || !Finite(x.angularDrag) || x.angularDrag < 0 || !Finite(x.linearDrag) || x.linearDrag < 0
                || !Finite(x.maxSwingDegrees) || x.maxSwingDegrees < 5 || x.maxSwingDegrees > 60
                || !Finite(x.maxTwistDegrees) || x.maxTwistDegrees < 0 || x.maxTwistDegrees > 90
                || !Finite(x.teleportDistanceM) || x.teleportDistanceM < .2f || x.physicsLayer < 0 || x.physicsLayer > 31)
                throw new ArgumentOutOfRangeException(nameof(x), "Invalid metre-scale bag mass, COM, collider, joint or layer settings.");
        }
        static bool Finite(float x) => !float.IsNaN(x) && !float.IsInfinity(x);
        static bool Finite(Vector3 x) => Finite(x.x) && Finite(x.y) && Finite(x.z);
        static float UniformScale(Vector3 s)
        {if (!Finite(s) || s.x < .5f || s.x > 3f || Mathf.Abs(s.x-s.y)>.0001f || Mathf.Abs(s.x-s.z)>.0001f) throw new InvalidOperationException("Bag visual transforms require positive uniform scale.");return s.x;}

        void OnEnable() { if (configured) Initialize(); }
        void Initialize()
        {
            if (initialized) return;
            if (!fixedAnchor || !swing) throw new InvalidOperationException("Camp bag rig was destroyed before physics initialization.");
            UniformScale(swing.lossyScale);
            if (Vector3.Distance(fixedAnchor.position, swing.position) > .002f)
                throw new InvalidOperationException("Moving and fixed crown pivots do not coincide after import.");
            if (Physics.gravity.sqrMagnitude < .01f) throw new InvalidOperationException("Bag gravity requires a nonzero world gravity vector.");
            Vector3 down = swing.TransformDirection(com.normalized);
            if (Vector3.Angle(down, Physics.gravity) > 2f)
                throw new InvalidOperationException("Bag body COM is not below its crown in the imported neutral. Check import axes and rig fit.");

            savedWorldRotation = swing.rotation;
            support = NewBody("WF_TentBag_PhysicsAnchor", true);
            body = NewBody("WF_TentBag_PhysicsBody", false);
            body.mass = massKg;
#if UNITY_6000_0_OR_NEWER || WF_UNITY6
            body.linearDamping = linearDrag; body.angularDamping = angularDrag;
#else
            body.drag = linearDrag; body.angularDrag = angularDrag;
#endif
            body.useGravity = true; body.interpolation = RigidbodyInterpolation.Interpolate;
            body.collisionDetectionMode = CollisionDetectionMode.ContinuousSpeculative;
            body.maxAngularVelocity = 6f; body.solverIterations = 12; body.solverVelocityIterations = 8;
            material = new ContactMaterial("WF_TentBag_LeatherContact") {
                dynamicFriction = .35f, staticFriction = .45f, bounciness = 0,
                frictionCombine = ContactCombine.Minimum, bounceCombine = ContactCombine.Minimum };
            // Two primitive pieces form a conservative soft-bag silhouette. They
            // are one compound body: overlapping owned pieces do not self-collide.
            int longAxis = boxSize.x > boxSize.y ? (boxSize.x > boxSize.z ? 0 : 2) : (boxSize.y > boxSize.z ? 1 : 2);
            Vector3 sizeA = boxSize, sizeB = boxSize * .86f;
            sizeA[longAxis] *= .58f; sizeB[longAxis] = boxSize[longAxis] * .44f;
            Vector3 offset = Vector3.zero; offset[longAxis] = boxSize[longAxis] * .21f;
            AddBox(boxCenter - offset, sizeA); AddBox(boxCenter + offset, sizeB);
            body.centerOfMass = com; body.ResetInertiaTensor();

            joint = body.gameObject.AddComponent<ConfigurableJoint>(); joint.connectedBody = support;
            joint.autoConfigureConnectedAnchor = false; joint.anchor = Vector3.zero; joint.connectedAnchor = Vector3.zero;
            joint.axis = com.normalized; joint.secondaryAxis = Mathf.Abs(Vector3.Dot(com.normalized, Vector3.right)) < .8f ? Vector3.right : Vector3.forward;
            joint.xMotion = joint.yMotion = joint.zMotion = ConfigurableJointMotion.Locked;
            joint.angularXMotion = joint.angularYMotion = joint.angularZMotion = ConfigurableJointMotion.Limited;
            joint.lowAngularXLimit = new SoftJointLimit { limit = -maxTwist };
            joint.highAngularXLimit = new SoftJointLimit { limit = maxTwist };
            joint.angularYLimit = new SoftJointLimit { limit = maxSwing };
            joint.angularZLimit = new SoftJointLimit { limit = maxSwing };
            joint.rotationDriveMode = RotationDriveMode.XYAndZ;
            // Weak twist relaxation only; swing has no spring holding a pose.
            joint.angularXDrive = new JointDrive { positionSpring = .025f, positionDamper = .08f, maximumForce = .15f };
            joint.angularYZDrive = new JointDrive { positionSpring = 0f, positionDamper = .015f, maximumForce = .1f };
            joint.enableCollision = false; joint.enablePreprocessing = true;
            joint.projectionMode = JointProjectionMode.PositionAndRotation; joint.projectionDistance = .008f; joint.projectionAngle = 4f;
            lastAnchor = fixedAnchor.position; initialized = true;
        }

        Rigidbody NewBody(string label, bool kinematic)
        {
            var go = new GameObject(label); go.layer = physicsLayer;
            SceneManager.MoveGameObjectToScene(go, gameObject.scene);
            go.transform.SetPositionAndRotation(fixedAnchor.position, swing.rotation);
            var rb = go.AddComponent<Rigidbody>(); rb.isKinematic = kinematic; rb.useGravity = !kinematic;
            return rb;
        }
        void AddBox(Vector3 centre, Vector3 size)
        {
            var collider = body.gameObject.AddComponent<BoxCollider>(); collider.center = centre; collider.size = size;
            collider.isTrigger = false; collider.contactOffset = .003f; collider.sharedMaterial = material;
        }
        void FixedUpdate()
        {
            if (!initialized || !body || !support || !fixedAnchor || !swing) return;
            Vector3 point = fixedAnchor.position; Quaternion orientation = fixedAnchor.rotation * supportRotationOffset;
            if (Vector3.Distance(point, lastAnchor) > teleportDistance || Vector3.Distance(point, body.position) > .20f)
            {
                body.position = point; body.rotation = orientation;
#if UNITY_6000_0_OR_NEWER || WF_UNITY6
                body.linearVelocity = Vector3.zero;
#else
                body.velocity = Vector3.zero;
#endif
                body.angularVelocity = Vector3.zero;
                support.position = point; support.rotation = orientation; body.WakeUp();
            }
            else { support.MovePosition(point); support.MoveRotation(orientation); }
            lastAnchor = point;
        }
        void LateUpdate()
        {
            if (!initialized || !body || !swing || !fixedAnchor) return;
            // Pin rendered crown exactly; PhysX solver gap is not shown as a
            // disconnected strap. The rotation remains the real physical result.
            swing.SetPositionAndRotation(fixedAnchor.position, body.rotation);
        }

        /// <summary>
        /// Use only for controller/kinematic contacts that bypass native dynamic
        /// collision response. Normal Rigidbody contacts already push the bag.
        /// Caller passes the actual contact velocity in world metres/second.
        /// </summary>
        public void NotifyControllerBump(Vector3 worldPoint, Vector3 worldVelocity)
        {
            if (!initialized || !Finite(worldPoint) || !Finite(worldVelocity)) return;
            var push = worldVelocity - body.GetPointVelocity(worldPoint);
            if (push.sqrMagnitude < .0025f) return;
            body.WakeUp(); body.AddForceAtPosition(Vector3.ClampMagnitude(push * massKg * .35f, .8f), worldPoint, ForceMode.Impulse);
        }

        void OnDisable() { Cleanup(); }
        void OnDestroy() { Cleanup(); }
        void Cleanup()
        {
            initialized = false;
            if (body) Destroy(body.gameObject); if (support) Destroy(support.gameObject); if (material) Destroy(material);
            body = null; support = null; joint = null; material = null;
            if (swing && configured) { swing.localPosition = savedLocalPosition; swing.localRotation = savedLocalRotation; }
        }
    }
}
