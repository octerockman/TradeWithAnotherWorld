using System;
using System.Collections.Generic;
using UnityEngine;
namespace Wayfarer.InGame
{
    public static class CoinPresentation
    {
        public const float ExtraSize=1.25f;
        public const string Selected="Mesh_0.001";
        static readonly HashSet<string> Names=new HashSet<string>(StringComparer.Ordinal){"Mesh_0","Mesh_0.001","Mesh_0.002","Mesh_0.003","Mesh_0.004","Mesh_0.005","Mesh_0.006","Mesh_0.007","Mesh_0.008","geometry_0","geometry_0.001","geometry_0.002","geometry_0.003","geometry_0.004","geometry_0.005","geometry_0.006","geometry_0.007","output_unwrapped","output_unwrapped.001","output_unwrapped.002","output_unwrapped.003"};
        public static bool IsCoin(string name)=>Names.Contains(name);
        public static Vector3 Contact(float[] vertices)
        {
            float min=float.PositiveInfinity;for(int i=1;i<vertices.Length;i+=3)min=Mathf.Min(min,vertices[i]);
            Vector3 sum=Vector3.zero;int count=0;
            for(int i=0;i<vertices.Length;i+=3)if(vertices[i+1]<=min+.000001f){sum+=new Vector3(vertices[i],vertices[i+1],vertices[i+2]);count++;}
            if(count==0)throw new InvalidOperationException("Coin contact points unavailable.");var pivot=sum/count;pivot.y=min;return pivot;
        }
        public static Vector3 Enlarge(Vector3 p,Vector3 contact)=>contact+(p-contact)*ExtraSize;
    }
}
