using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;

namespace Wayfarer.InGame
{
    [DefaultExecutionOrder(-100)]
    public sealed class SourcePosePlayer:MonoBehaviour
    {
        MotionPayload bank;Transform[] nodes;MotionClip current;float start;bool loop;
        public string Current=>current?.name;
        public void Initialize(MotionPayload payload,Dictionary<string,Transform> named)
        {bank=payload;nodes=bank.boneNames.Select(n=>named[n]).ToArray();Play("idle",true);Apply(0);}
        public void Play(string alias,bool repeat=false)
        {
            if(bank==null)return;string id=bank.aliases.TryGetValue(alias,out string actual)?actual:alias;
            var clip=bank.clips.FirstOrDefault(c=>c.name==id);if(clip==null)throw new InvalidOperationException("Missing own motion:"+alias);
            current=clip;start=Time.time;loop=repeat;
        }
        void Update()
        {
            if(current==null)return;float t=Time.time-start;
            if(loop)t=Mathf.Repeat(t,current.duration);else if(t>=current.duration){Play("idle",true);t=0;}
            Apply(t);
        }
        void Apply(float time)
        {
            var f=current.frames;int a=Mathf.Clamp((int)(time*bank.fps),0,f.Length-1);
            while(a>0&&f[a].time>time)a--;while(a+1<f.Length&&f[a+1].time<time)a++;
            int b=Math.Min(a+1,f.Length-1);float blend=f[b].time>f[a].time?Mathf.Clamp01((time-f[a].time)/(f[b].time-f[a].time)):0;
            for(int i=0;i<nodes.Length;i++)
            {
                int p=i*3,q=i*4;var x=f[a];var y=f[b];nodes[i].localPosition=Vector3.LerpUnclamped(new Vector3(x.positions[p],x.positions[p+1],x.positions[p+2]),new Vector3(y.positions[p],y.positions[p+1],y.positions[p+2]),blend);
                nodes[i].localRotation=Quaternion.SlerpUnclamped(new Quaternion(x.rotations[q],x.rotations[q+1],x.rotations[q+2],x.rotations[q+3]),new Quaternion(y.rotations[q],y.rotations[q+1],y.rotations[q+2],y.rotations[q+3]),blend);
                nodes[i].localScale=Vector3.LerpUnclamped(new Vector3(x.scales[p],x.scales[p+1],x.scales[p+2]),new Vector3(y.scales[p],y.scales[p+1],y.scales[p+2]),blend);
            }
        }
    }
}
