using System;
using Jotunn.Managers;
using UnityEngine;
using UnityEngine.UI;
using Object=UnityEngine.Object;

namespace Wayfarer.InGame
{
    // Scoped to the player's reading interaction. No global TextViewer font,
    // layout, cursor, time scale or native input settings are permanently edited.
    public static class ApprovedLedgerPanel
    {
        static GameObject panel;static Player reader;static Transform ledger;static bool inputBlocked;
        public static bool IsOpen=>panel;
        public static bool Open(LedgerContent content,Transform source)
        {
            if(content==null||!Player.m_localPlayer||GUIManager.Instance==null||!GUIManager.CustomGUIFront)return false;
            Close();
            try
            {
                reader=Player.m_localPlayer;ledger=source;
                panel=GUIManager.Instance.CreateWoodpanel(GUIManager.CustomGUIFront.transform,new Vector2(.5f,.5f),new Vector2(.5f,.5f),Vector2.zero,900,760,true);
                panel.name="WayfarerLedgerReader";
                var bounds=panel.GetComponent<RectTransform>();bounds.anchorMin=new Vector2(.13f,.10f);bounds.anchorMax=new Vector2(.87f,.90f);bounds.offsetMin=bounds.offsetMax=Vector2.zero;
                var title=Label(panel.transform,"LedgerTitle",content.title,28);
                var titleRect=title.rectTransform;titleRect.anchorMin=new Vector2(0,1);titleRect.anchorMax=Vector2.one;titleRect.pivot=new Vector2(0,1);titleRect.offsetMin=new Vector2(30,-76);titleRect.offsetMax=new Vector2(-170,-22);
                var button=GUIManager.Instance.CreateButton("Close",panel.transform,new Vector2(1,1),new Vector2(1,1),new Vector2(-30,-25),120,44);
                var br=button.GetComponent<RectTransform>();br.pivot=new Vector2(1,1);br.anchoredPosition=new Vector2(-30,-25);
                button.GetComponent<Button>().onClick.AddListener(Close);
                var hint=Label(panel.transform,"ReadingHelp","Scroll to read  ·  Esc to close",18);hint.rectTransform.anchorMin=Vector2.zero;hint.rectTransform.anchorMax=new Vector2(1,0);hint.rectTransform.pivot=Vector2.zero;hint.rectTransform.offsetMin=new Vector2(30,20);hint.rectTransform.offsetMax=new Vector2(-30,48);
                var scrollGo=new GameObject("LedgerScroll",typeof(RectTransform),typeof(Image),typeof(ScrollRect));var sr=(RectTransform)scrollGo.transform;sr.SetParent(panel.transform,false);Stretch(sr);sr.offsetMin=new Vector2(30,65);sr.offsetMax=new Vector2(-30,-85);scrollGo.GetComponent<Image>().color=new Color(.045f,.036f,.027f,.92f);
                var viewportGo=new GameObject("Viewport",typeof(RectTransform),typeof(Image),typeof(Mask));var viewport=(RectTransform)viewportGo.transform;viewport.SetParent(sr,false);Stretch(viewport);viewport.offsetMin=new Vector2(20,16);viewport.offsetMax=new Vector2(-34,-16);viewportGo.GetComponent<Image>().color=Color.white;viewportGo.GetComponent<Mask>().showMaskGraphic=false;
                var body=Label(viewport,"ApprovedAccounts",content.text,24);body.lineSpacing=1.12f;var text=body.rectTransform;text.anchorMin=new Vector2(0,1);text.anchorMax=Vector2.one;text.pivot=new Vector2(0,1);text.anchoredPosition=Vector2.zero;text.sizeDelta=Vector2.zero;
                var fitter=body.gameObject.AddComponent<ContentSizeFitter>();fitter.horizontalFit=ContentSizeFitter.FitMode.Unconstrained;fitter.verticalFit=ContentSizeFitter.FitMode.PreferredSize;
                var scroll=scrollGo.GetComponent<ScrollRect>();scroll.viewport=viewport;scroll.content=text;scroll.horizontal=false;scroll.vertical=true;scroll.movementType=ScrollRect.MovementType.Clamped;scroll.inertia=true;scroll.decelerationRate=.12f;scroll.scrollSensitivity=34;
                scroll.verticalScrollbar=Scrollbar(sr);scroll.verticalScrollbarVisibility=ScrollRect.ScrollbarVisibility.Permanent;
                GUIManager.BlockInput(true);inputBlocked=true;Canvas.ForceUpdateCanvases();scroll.verticalNormalizedPosition=1;
                return true;
            }
            catch{Close();throw;}
        }
        static Text Label(Transform parent,string name,string value,int size)
        {
            var go=new GameObject(name,typeof(RectTransform),typeof(Text));go.transform.SetParent(parent,false);var label=go.GetComponent<Text>();label.font=GUIManager.Instance.AveriaSerif;label.text=value;label.fontSize=size;label.resizeTextForBestFit=false;label.supportRichText=false;label.color=new Color(.96f,.91f,.80f);label.alignment=TextAnchor.UpperLeft;label.horizontalOverflow=HorizontalWrapMode.Wrap;label.verticalOverflow=VerticalWrapMode.Overflow;label.raycastTarget=false;return label;
        }
        static Scrollbar Scrollbar(Transform parent)
        {
            var go=new GameObject("ScrollBar",typeof(RectTransform),typeof(Image),typeof(Scrollbar));var rect=(RectTransform)go.transform;rect.SetParent(parent,false);rect.anchorMin=new Vector2(1,0);rect.anchorMax=Vector2.one;rect.pivot=new Vector2(1,.5f);rect.offsetMin=new Vector2(-20,12);rect.offsetMax=new Vector2(-7,-12);go.GetComponent<Image>().color=new Color(.30f,.25f,.18f,.8f);
            var handleGo=new GameObject("Handle",typeof(RectTransform),typeof(Image));var h=(RectTransform)handleGo.transform;h.SetParent(rect,false);Stretch(h);var image=handleGo.GetComponent<Image>();image.color=new Color(.77f,.65f,.42f);var bar=go.GetComponent<Scrollbar>();bar.direction=UnityEngine.UI.Scrollbar.Direction.BottomToTop;bar.handleRect=h;bar.targetGraphic=image;bar.numberOfSteps=0;return bar;
        }
        static void Stretch(RectTransform r){r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.offsetMin=r.offsetMax=Vector2.zero;}
        public static void Tick()
        {
            if(!panel){if(inputBlocked)Close();return;}
            if(!reader||reader!=Player.m_localPlayer||reader.IsDead()||!ledger||Vector3.Distance(reader.transform.position,ledger.position)>8||Input.GetKeyDown(KeyCode.Escape))Close();
        }
        public static void Close()
        {
            var old=panel;panel=null;reader=null;ledger=null;
            if(inputBlocked){inputBlocked=false;GUIManager.BlockInput(false);}
            if(old)Object.Destroy(old);
        }
    }
}
