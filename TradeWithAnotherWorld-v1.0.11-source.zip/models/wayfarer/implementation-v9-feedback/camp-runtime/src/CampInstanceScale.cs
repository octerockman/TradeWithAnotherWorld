using System;
using UnityEngine;
using Jotunn.Managers;
namespace Wayfarer.InGame
{
    public static class CampInstanceScale
    {
        public const float NewCamp=1.25f,IdleSourceHeight=1.711445593f,StandingRatio=1.09f;
        public const string CampKey="twa_wf_camp_scale_v4",ActorKey="twa_wf_actor_scale_v4";
        public static float Read(ZDO z,string key)
        {float s=z.GetFloat(key,1);if(!PayloadReader.Finite(s)||s<.5f||s>3)throw new InvalidOperationException("Invalid saved Wayfarer instance scale.");return s;}
        public static float ActorFor(Player player,out float standingHeight)
        {
            var prefab=PrefabManager.Instance.GetPrefab("Player");var rest=prefab?prefab.GetComponent<CapsuleCollider>():null;
            if(!rest||!player)throw new InvalidOperationException("Native standing-player capsule unavailable.");
            float local=Mathf.Max(player.GetHeight(),Mathf.Max(rest.height,rest.radius*2));
            standingHeight=local*Mathf.Abs(player.transform.lossyScale.y);
            float s=standingHeight*StandingRatio/IdleSourceHeight;
            if(!PayloadReader.Finite(s)||s<.5f||s>3)throw new InvalidOperationException("Player standing size is outside the supported Wayfarer fit.");return s;
        }
    }
}
