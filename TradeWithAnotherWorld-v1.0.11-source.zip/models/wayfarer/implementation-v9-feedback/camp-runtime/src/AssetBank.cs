using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Threading.Tasks;
using UnityEngine;
using Jotunn.Managers;

namespace Wayfarer.InGame
{
    public sealed class AssetBank:IDisposable
    {
        public VisualBuilder Camp,Actor; public MotionPayload Motion;
        public bool Ready{get;private set;} public bool Loading{get;private set;} public string Failure{get;private set;}
        public int Layer{get;private set;}=-1;
        readonly string folder; readonly Action<string> log;
        public AssetBank(string folder,Action<string> log){this.folder=folder;this.log=log;}
        sealed class Loaded { public VisualPayload camp,actor; public MotionPayload motion; public string campFolder,actorFolder; }
        public IEnumerator Ensure()
        {
            if(Ready||Failure!=null)yield break;
            if(!Loading)
            {
                var host=WayfarerPlugin.Instance;
                if(!host){Failure="Plugin missing during asset admission.";yield break;}
                // A camp/NPC/coin caller is allowed to unload while waiting.
                // Keep one bounded shared admission on the plugin, not on that
                // streamed instance, so Loading cannot be stranded forever.
                Loading=true;host.StartCoroutine(Load());
            }
            while(Loading)yield return null;
        }
        IEnumerator Load()
        {
            Task<Loaded> task=null;
            try{task=Task.Run(()=>Read());}catch(Exception e){Failure=e.Message;}
            if(task!=null)
            {
                while(!task.IsCompleted)yield return null;
                if(task.IsFaulted)Failure=task.Exception.GetBaseException().Message;
                else if(task.IsCanceled)Failure="Payload loading canceled.";
                else
                {
                    var d=task.Result;
                    try
                    {
                        // Pure parsing/hash work ran off the game thread. Unity
                        // object admission stays here, bounded one material/frame.
                        PayloadReader.Validate(d.camp,true);PayloadReader.Validate(d.actor,false);PayloadReader.Validate(d.motion,d.actor);
                        Layer=LayerMask.NameToLayer("static_solid");if(Layer<0)throw new InvalidOperationException("Native static_solid collision layer unavailable.");
                        var skeleton=PrefabManager.Instance.GetPrefab("Skeleton");
                        var opaque=skeleton?skeleton.GetComponentsInChildren<Renderer>(true).SelectMany(r=>r.sharedMaterials).FirstOrDefault(m=>m&&m.shader&&m.shader.name=="Custom/Creature"):null;
                        if(!opaque)throw new InvalidOperationException("Native Custom/Creature material template unavailable.");
                        foreach(var property in new[]{"_Cull","_TwoSidedNormals","_BumpMap","_BumpScale","_MetallicGlossMap","_UseGlossmap","_Cutoff"})if(!opaque.HasProperty(property))throw new InvalidOperationException("Native Creature material contract missing "+property);
                        var glassPrefab=PrefabManager.Instance.GetPrefab("crystal_wall_1x1");
                        var glass=glassPrefab?glassPrefab.GetComponentsInChildren<Renderer>(true).SelectMany(r=>r.sharedMaterials).FirstOrDefault(m=>m&&m.shader&&m.shader.name=="Standard"&&m.name.StartsWith("crystal_window",StringComparison.OrdinalIgnoreCase)):null;
                        if(!glass)throw new InvalidOperationException("Native crystal_window transparent template unavailable.");
                        Camp=new VisualBuilder(d.camp,d.campFolder,opaque,glass,log);Actor=new VisualBuilder(d.actor,d.actorFolder,opaque,glass,log);Motion=d.motion;
                    }
                    catch(Exception e){Failure=e.Message;}
                    if(Failure==null)
                    {
                        foreach(var builder in new[]{Camp,Actor})foreach(var material in builder.Payload.materials)
                        {
                            try{builder.PrepareMaterial(material);}catch(Exception e){Failure=e.Message;}
                            if(Failure!=null)break;
                            yield return null;
                        }
                    }
                }
            }
            Loading=false;Ready=Failure==null;
            if(!Ready){Dispose();log("WF_DATA_FAILED "+Failure);}
            else log("WF_DATA_READY source="+PayloadReader.NativeSha+" layer=static_solid glass="+Camp.GlassShader+" clips="+Motion.clips.Length+" textures="+(Camp.TextureCount+Actor.TextureCount));
        }
        Loaded Read()
        {
            var m=PayloadReader.Read<DataManifest>(PayloadReader.Safe(folder,"manifest.json"));
            if(m?.schema!="wayfarer.runtime-data.v1"||m.sourceNativeSha256!=PayloadReader.NativeSha)throw new InvalidDataException("Wrong runtime manifest/source.");
            foreach(var r in new[]{m.camp,m.actor,m.motion}){PayloadReader.CheckMap(r);if(PayloadReader.Hash(PayloadReader.Safe(folder,r.path))!=r.sha256)throw new InvalidDataException("Payload hash mismatch: "+r.path);}
            string cp=PayloadReader.Safe(folder,m.camp.path),ap=PayloadReader.Safe(folder,m.actor.path);
            return new Loaded{camp=PayloadReader.Read<VisualPayload>(cp),actor=PayloadReader.Read<VisualPayload>(ap),motion=PayloadReader.Read<MotionPayload>(PayloadReader.Safe(folder,m.motion.path)),campFolder=Path.GetDirectoryName(cp),actorFolder=Path.GetDirectoryName(ap)};
        }
        public void Dispose(){Camp?.Dispose();Actor?.Dispose();Camp=null;Actor=null;Motion=null;Ready=false;}
    }
}
