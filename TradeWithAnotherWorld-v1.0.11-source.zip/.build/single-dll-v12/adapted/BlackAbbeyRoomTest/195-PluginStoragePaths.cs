using System;
using System.IO;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // ModGate can load this DLL from a hashed plugin folder. Data belongs to
    // that actual assembly, rather than an assumed direct child of PluginPath.
    internal static class PluginStoragePaths
    {
        private static string AssemblyDirectory(string assemblyPath)
        {
            if (string.IsNullOrWhiteSpace(assemblyPath) || !Path.IsPathRooted(assemblyPath)) return null;
            return Path.GetDirectoryName(Path.GetFullPath(assemblyPath));
        }
        private static string LegacyDirectory(string pluginsRoot) => Path.Combine(Path.GetFullPath(pluginsRoot), "BlackAbbeyRoomTest");
        // Stable across ModGate's per-profile assembly paths. These host world
        // records are not a player's return checkpoint or a room-data resource.
        internal static string WorldDoorDirectory(string assemblyPath, string pluginsRoot) => Path.Combine(LegacyDirectory(pluginsRoot),"world-doors");
        internal static string DataDirectory(string assemblyPath, string pluginsRoot)
        {
            string adjacent = AssemblyDirectory(assemblyPath), legacy = Path.Combine(LegacyDirectory(pluginsRoot), "data");
            if (adjacent != null && Directory.Exists(Path.Combine(adjacent, "data"))) return Path.Combine(adjacent, "data");
            if (Directory.Exists(legacy) || adjacent == null) return legacy;
            return Path.Combine(adjacent, "data"); // A missing package fails normally before travel.
        }
        private static bool HasRecoveryRecords(string directory)
        {
            if (File.Exists(Path.Combine(directory, "return-state.json"))) return true;
            string root = Path.Combine(directory, "return-checkpoints");
            return Directory.Exists(root) && Directory.EnumerateFiles(root, "*.json", SearchOption.AllDirectories).Any();
        }
        internal static string ReturnFile(string assemblyPath, string pluginsRoot)
        {
            string legacy = LegacyDirectory(pluginsRoot), adjacent = AssemblyDirectory(assemblyPath);
            // Preserve an existing global recovery store; otherwise adopt the
            // existing profile-adjacent records copied alongside this plugin.
            // This resolver never moves, merges, deletes or authorizes records.
            if (HasRecoveryRecords(legacy)) return Path.Combine(legacy, "return-state.json");
            if (adjacent != null && HasRecoveryRecords(adjacent)) return Path.Combine(adjacent, "return-state.json");
            return Path.Combine(legacy, "return-state.json");
        }
    }
}
