using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using HarmonyLib;
using Jotunn.Entities;
using Jotunn.Managers;
using Newtonsoft.Json;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    // Replaces the earlier R05 helper at the same ID/folder; never install both.
    [BepInPlugin(Id, "Black Abbey Connected Dungeon Test", Version)]
    [BepInDependency(Jotunn.Main.ModGuid, "2.30.2")]
    public sealed partial class RuntimeTestPlugin : BaseUnityPlugin
    {
        public const string Id = "studio.otherworld.blackabbeyroomtest", Version = "0.4.80";
        private R07RoomStates<Inventory> r07Run;
        private PewRunState pewRun;
        private DungeonRenderBudget renderBudget;
        private readonly List<string> missingRoomKeys = new List<string>();
        private static readonly Predicate<LoadedRoom> RoomAlive = room => room.Root;
        private sealed class ShaftBinding
        {
            internal string Key;
            internal LoadedRoom Room;
            internal GameObject Root;
            internal R08ShaftRuntime Shaft;
        }
        private readonly List<ShaftBinding> shaftRooms = new List<ShaftBinding>();
        private void RefreshRenderBudget()
        {
            if (renderRefreshDeferral > 0) return;
            renderBudget?.Configure(rooms.Values, dungeonPlan, CanSeeThroughDoor, s => Logger.LogInfo(s),dungeonArt,DoorForLink);
            ambienceRooms = rooms.Values.Where(r => r.Root).ToArray();
            shaftRooms.Clear();
            foreach (var pair in rooms)
            {
                var room = pair.Value;
                // R08ShaftRuntime.Attach admits this exact source ID only.
                // Rebuild the index after the room/fixture batch commits.
                if (room.Root && room.Manifest.roomId == "R08")
                    shaftRooms.Add(new ShaftBinding { Key = pair.Key, Room = room, Root = room.Root,
                        Shaft = room.Root.GetComponent<R08ShaftRuntime>() });
            }
        }
        private bool CanSeeThroughDoor(DungeonLink link)
        {
            if(R09SplitPlanning.IsThreshold(link))
                return rooms.TryGetValue("R09-B",out var chamber)&&chamber.Root&&chamber.Root.GetComponent<R09RoomRuntime>()?.DoorVisibleThrough==true;
            return !dungeonDoors.TryGetValue(link,out var door)||!door||door.VisibleThrough;
        }
        private AbbeyDoor DoorForLink(DungeonLink link)=>dungeonDoors.TryGetValue(link,out var door)?door:null;
        private const float PreviewAltitude = 8000f, HighAltitudeGuard = 7000f, RoomSpacing = 256f;
        private readonly Dictionary<string, LoadedRoom> rooms = new Dictionary<string, LoadedRoom>(StringComparer.Ordinal);
        private RoomCatalog catalog; private LoadedRoom activeRoom;
        private ReturnCheckpoint checkpoint; private Vector3? gridOrigin;
        private ReturnCheckpointStore checkpointStore;
        private string selectedCheckpointIdentity, selectedPlayerId, selectedWorldKey;
        private bool checkpointReadFailed;
        private Player returnPlayer, observedPlayer; private bool busy, recoveryAttempted; private int lastStatusFrame = -1;
        private static string AssemblyPath => typeof(RuntimeTestPlugin).Assembly.Location;
        private string DataPath => architectureRoot ?? Path.Combine(SharedDataPath,KitArchitectureProfile.RelativeRoot);
        private string ReturnPath => PluginStoragePaths.ReturnFile(AssemblyPath, Paths.PluginPath);
        [Serializable] private sealed class ReturnCheckpoint
        {
            public int schemaVersion = 2;
            public string sourceSha256, playerId, worldKey;
            public float[] position, rotation, roomOrigin;
            public bool pending;
            public int? dungeonSeed;
            public string dungeonMode;
            public string persistentRunId;
        }
        private sealed class TestCommand : ConsoleCommand
        {
            private readonly string name, help; private readonly bool host; private readonly Action action;
            internal TestCommand(string name, string help, bool host, Action action) { this.name = name; this.help = help; this.host = host; this.action = action; }
            public override string Name => name; public override string Help => help;
            public override bool IsCheat => host; public override bool OnlyServer => host;
            public override void Run(string[] args) => action();
        }
        private void Add(string name, string help, bool cheat, Action action) => CommandManager.Instance.AddConsoleCommand(new TestCommand(name, help, cheat, action));
        private void Awake()
        {
            global::Otherworld.Distribution.BundleRuntime.Initialize(this);

            try { IsolatedSaveProfile.Configure(s => Logger.LogInfo(s)); }
            catch (Exception ex) { Logger.LogError("Isolated test profile failed; helper startup stopped: " + ex); enabled = false; return; }
            AbbeyLoadDiagnostics.Initialize(gameObject,Path.Combine(Path.GetDirectoryName(PluginStoragePaths.WorldDoorDirectory(AssemblyPath,Paths.PluginPath)),"diagnostics"),s=>Logger.LogInfo(s),Version);
            NativeCandleFixture.FixtureDiagnostics = Config.Bind("Diagnostics", "FixtureDetails", false, "Log per-candle setup details; normal operation uses room summaries.").Value;
            checkpointStore = new ReturnCheckpointStore(ReturnPath, s => Logger.LogInfo(s));
            InitializePersistentRunHooks();
            AbbeyBalanceRuntime.Initialize();
            DungeonActorResidency.Initialize();
            renderBudget = gameObject.AddComponent<DungeonRenderBudget>();
            InitializeDoorwayFaceDiagnostics();
            InitializeAbbeyAmbience();
            InitializeBossMusic();
            InitializeWardingCommands();
            InitializeBalanceStatus();
            InitializeFalseVows();
            foreach (string id in CatalogReader.RoomIds)
            {
                string selected = id;
                Add("twa_test_" + id.ToLowerInvariant(), "Load/enter the local " + id + " authored-room preview (devcommands; local host).", true, () => Enter(selected, false));
            }
            Add("twa_test_rooms", "Generate/re-enter a seeded Black Abbey with every room type and Hushed Monks; twa_test_regenerate starts a fresh run.", true, () => StartDungeon(null));
            AddDungeonCommands();
            AddWorldPortalCommands();
            Add("twa_test_next", "Enter the next authored-room preview, including both R03 statue variants.", true, Next);
            Add("twa_test_list", "List the installed room catalog and preview commands.", false, ListRooms);
            Add("twa_test_return", "Return to the character/world-bound surface checkpoint; retain loaded test rooms.", true, Return);
            Add("twa_test_remove", "Return safely, unload this helper's rooms and delete this world's saved Mysterious Door.", true, Remove);
            Add("twa_test_status", "Report selected room, resources, floor contact, actual flames/lights and material state.", false, Status);
            Add("twa_test_diagnostics_arm","Capture the next load into bounded timing/cache/memory diagnostics; no game/render settings change.",false,()=>{AbbeyLoadDiagnostics.ArmNext();Print("The next room/dungeon load will save a diagnostic report.");});
            Add("twa_test_diagnostics_snapshot","Save a read-only memory/resource snapshot; no collection, unloading or camera capture.",false,()=>AbbeyLoadDiagnostics.Snapshot("manual",rooms.Values));
            Add("twa_test_diagnostics_void","Sample eight seconds of application frame intervals while you hold an outward/void view still. No screenshot or GPU timing.",false,()=>{AbbeyLoadDiagnostics.StartViewSample("outward-void");Print("Close the console and hold the view still for eight seconds.");});
            Add("twa_test_diagnostics_inward","Sample eight seconds of application frame intervals looking inward from the same position/settings. No screenshot or GPU timing.",false,()=>{AbbeyLoadDiagnostics.StartViewSample("inward");Print("Close the console and hold the view still for eight seconds.");});
            Add("twa_test_recover_grave", "Restore this character's existing native dungeon grave to its original supported spot. Rebuild the original seed first; no items are created.", true, RecoverDungeonGrave);
            Add("twa_boss_dead", "Mark the current local R09 test encounter complete and unlock its doors; no boss is implemented.", true, () => BossEncounterCommand(false));
            Add("twa_boss_reset", "Reset the local R09 candle/door test; retreat before the first-pillar plane to rearm.", true, () => BossEncounterCommand(true));
            Add("twa_test_water_hide", "Hide water only in the selected room for diagnosis.", true, () => WaterControl(WaterPresentation.Hide));
            Add("twa_test_water_show", "Show the selected room's current water material.", true, () => WaterControl(WaterPresentation.Show));
            Add("twa_test_water_fade", "Restore the accepted Fade water presentation in the selected room.", true, () => WaterControl(WaterPresentation.Fade));
            Logger.LogInfo("Black Abbey helper loaded; Mysterious Door registered through world locations. Dungeon generation starts on entry. Data: " + DataPath);
        }
        private void BossEncounterCommand(bool reset)
        {
            if (busy || !LocalPlayer(out var player)) return;
            if (!Matches(player) || player.transform.position.y < HighAltitudeGuard || !rooms.TryGetValue("R09-B", out var loaded) || !loaded.Root)
            { Print("Enter this character/world's loaded Black Abbey test first. No encounter changed."); return; }
            var encounter = loaded.Root.GetComponent<R09RoomRuntime>();
            bool changed = encounter && (reset ? encounter.ResetEncounter() : encounter.CompleteEncounter());
            if(changed&&persistentRunBound){persistentRun.bossCompleted=!reset;persistentRun.bossEncounterStarted=!reset;ObserveRunPlayers();SavePersistentRun(true);}
            Print(changed ? (reset ? "R09 test reset: chamber candles off, doors opening; retreat past the trigger before re-entering." : "R09 test boss marked dead: candles lit and great doors unlocked for E.") : "No matching active V25 R09 encounter changed.");
        }
        private bool LocalPlayer(out Player player)
        {
            player = Player.m_localPlayer;
            if (!player || !ZNet.instance || !ZNet.instance.IsServer()) { Print("Use this test as the local host or in singleplayer; a local player is required."); return false; }
            if (!SelectCheckpoint(player)) { Print("This character's test return record could not be loaded; see the test log. No travel occurred."); return false; }
            return true;
        }
        private bool ReadCatalog()
        {
            try
            {
                SelectArchitectureForSavedRun();
                if (catalog != null) return true;
                string path = Path.Combine(DataPath, "catalog.json");
                if (!File.Exists(path) || new FileInfo(path).Length > 4 * 1024 * 1024) throw new InvalidDataException("Missing/oversized data/catalog.json.");
                catalog = CatalogReader.Read(File.ReadAllText(path)); return true;
            }
            catch (Exception ex) { Logger.LogError("Room catalog unavailable: " + ex); Print("The room catalog is not ready. Safe return remains available; see the test log."); return false; }
        }
        private static float[] Array(Vector3 p) => new[] { p.x, p.y, p.z };
        private static float[] Array(Quaternion p) => new[] { p.x, p.y, p.z, p.w };
        private static Quaternion Rotation(float[] a)
        {
            if (a == null || a.Length != 4 || a.Any(v => !RoomPackage.Finite(v))) throw new InvalidDataException("Invalid return rotation.");
            var q = new Quaternion(a[0], a[1], a[2], a[3]); if (Quaternion.Dot(q, q) < .1f) throw new InvalidDataException("Zero return rotation."); return q.normalized;
        }
        private static readonly RuntimeWorldIdentity WorldIdentity = new RuntimeWorldIdentity(typeof(ZNet),
            (type, name) => AccessTools.Method(type, name, Type.EmptyTypes), AccessTools.Field);
        private static string WorldKey()
        {
            var owner = ZNet.instance;
            return owner ? WorldIdentity.Read(owner) : null;
        }
        private bool Matches(Player player)
        {
            if (checkpoint == null || !checkpoint.pending || !player) return false;
            try { return checkpoint.playerId == player.GetPlayerID().ToString() && checkpoint.worldKey == WorldKey(); }
            catch (Exception ex) { Logger.LogWarning("Return identity unavailable: " + ex.Message); return false; }
        }
        private bool SelectCheckpoint(Player player)
        {
            if (!player || !ZNet.instance || !ZNet.instance.IsServer()) return false;
            string world = WorldKey(), id = player.GetPlayerID().ToString();
            if (string.IsNullOrEmpty(world)) return false;
            string identity = world + "\0" + id;
            if (identity == selectedCheckpointIdentity) return !checkpointReadFailed;
            if (busy) return false;
            if (selectedCheckpointIdentity != null) { DisposeRooms(); DisposeWorldPortal(); }
            checkpoint = null; returnPlayer = null; gridOrigin = null; recoveryAttempted = false;
            selectedCheckpointIdentity = identity; selectedPlayerId = id; selectedWorldKey = world; checkpointReadFailed = true;
            try
            {
                string json = checkpointStore.Load(id, world);
                if (json != null)
                {
                    var saved = JsonConvert.DeserializeObject<ReturnCheckpoint>(json, ManifestReader.Settings());
                    if (saved == null || saved.schemaVersion < 1 || saved.schemaVersion > 2 || !saved.pending || saved.playerId != id || saved.worldKey != world)
                        throw new InvalidDataException("Unrecognized or wrong-owner return checkpoint.");
                    var position = RoomPackage.Vector(saved.position, "return position");
                    RoomPackage.Vector(saved.roomOrigin, "test origin"); Rotation(saved.rotation);
                    if (position.y >= HighAltitudeGuard) throw new InvalidDataException("A surface return point cannot be inside a test area.");
                    checkpoint = saved; gridOrigin = RoomPackage.Vector(saved.roomOrigin, "test origin");
                    Logger.LogInfo("Matching character/world test recovery loaded. Other identities' return records remain preserved.");
                }
                checkpointReadFailed = false; return true;
            }
            catch (Exception ex) { Logger.LogWarning("Return checkpoint was not accepted; file preserved: " + ex.Message); return false; }
        }
        private bool PrepareReturn(Player player, out bool captured)
        {
            captured = false;
            try
            {
                if (checkpoint != null && checkpoint.pending)
                {
                    if (!Matches(player)) throw new InvalidOperationException("A different character/world owns the pending test return checkpoint.");
                    if (player.transform.position.y > HighAltitudeGuard) { if (!gridOrigin.HasValue) gridOrigin = RoomPackage.Vector(checkpoint.roomOrigin, "test origin"); returnPlayer = player; return true; }
                }
                if (player.transform.position.y > HighAltitudeGuard) throw new InvalidOperationException("No matching surface return checkpoint; the current floor must be preserved.");
                string world = WorldKey(); if (string.IsNullOrEmpty(world)) throw new InvalidOperationException("Cannot identify this world for safe return.");
                if (!gridOrigin.HasValue) gridOrigin = new Vector3(player.transform.position.x, PreviewAltitude, player.transform.position.z);
                var saved = new ReturnCheckpoint { sourceSha256 = CatalogReader.HashFile(Path.Combine(DataPath, "catalog.json")), playerId = player.GetPlayerID().ToString(), worldKey = world,
                    position = Array(player.transform.position), rotation = Array(player.transform.rotation), roomOrigin = Array(gridOrigin.Value), pending = true,
                    dungeonSeed = dungeonPlan?.Seed ?? checkpoint?.dungeonSeed, dungeonMode = dungeonPlan?.Mode ?? checkpoint?.dungeonMode };
                checkpointStore.Save(saved.playerId, saved.worldKey, JsonConvert.SerializeObject(saved, Formatting.Indented));
                checkpoint = saved; returnPlayer = player; captured = true; return true;
            }
            catch (Exception ex) { Logger.LogError("Test entry refused before travel: " + ex); Print(ex.Message); return false; }
        }
        private void ClearReturn()
        {
            checkpoint = null; returnPlayer = null;
            try { checkpointStore.Clear(selectedPlayerId, selectedWorldKey); }
            catch (Exception ex) { Logger.LogWarning("Returned safely; the owned checkpoint could not be removed: " + ex.Message); }
        }
        private void Enter(string id, bool all)
        {
            if (busy) { Print("A test-room transition is in progress."); return; }
            if (!LocalPlayer(out var player) || !ReadCatalog()) return;
            if (!catalog.rooms.Any(record => record.roomId == id)) { Print(id + " is not present in the installed room catalog."); return; }
            if (!PrefabManager.Instance.GetPrefab("Candle_resin")) { Print("Vanilla candle/material prefabs are not ready yet; wait a moment."); return; }
            StartCoroutine(EnterRoutine(player, id, all));
        }
        private IEnumerator EnterRoutine(Player player, string id, bool all)
        {
            AbbeyLoadDiagnostics.BeginAttempt("authored-room-preview",false,null,AbbeyLoadDiagnostics.CatalogIdentity(Path.Combine(DataPath,"catalog.json")),rooms.Values);
            try { yield return EnterRoutineCore(player,id,all); }
            finally { AbbeyLoadDiagnostics.Finish("authored-preview-routine-ended (inspect travel log)",rooms.Values); }
        }
        private IEnumerator EnterRoutineCore(Player player, string id, bool all)
        {
            if (dungeonPlan != null)
            {
                // Never move the connected floors out from under their player.
                if (player && player.transform.position.y > HighAltitudeGuard)
                {
                    if (!Matches(player)) { Print("Return with the matching test character before switching rooms."); yield break; }
                    yield return ReturnRoutine(player, false);
                    if (!player || player.transform.position.y > HighAltitudeGuard) yield break;
                }
                if(!SavePersistentRun(true)){Print("The active dungeon could not be saved; it was left intact.");yield break;}
                ReleaseProgressCheckpointHooks();persistentRunBound=false;
                ClearDungeonArt();
                DisposeMonkRun();
                foreach (var room in rooms.Values) room.Dispose();
                rooms.Clear(); activeRoom = null; r07Run = null; pewRun = null; naturalRunId = null;
                Physics.SyncTransforms();
            }
            busy = true;
            if (!PrepareReturn(player, out bool captured)) { busy = false; yield break; }
            foreach (var record in catalog.rooms.Where(r => all || r.roomId == id).OrderBy(r => r.Slot))
            {
                bool loaded = false; yield return LoadRoomRoutine(record, null, value => loaded = value);
                if (!loaded) { if (captured && player && player.transform.position.y < HighAltitudeGuard) ClearReturn(); busy = false; yield break; }
                yield return null;
            }
            if (!rooms.TryGetValue(id, out var destination) || !destination.Root) { busy = false; yield break; }
            yield return new WaitForFixedUpdate();
            if (!player || Player.m_localPlayer != player || !ZNet.instance || !ZNet.instance.IsServer() || !Matches(player)) { busy = false; yield break; }
            activeRoom = destination;
            Vector3 target = destination.Root.transform.TransformPoint(RoomPackage.Vector(destination.Manifest.entryPosition, "entry position"));
            Vector3 forward = Vector3.ProjectOnPlane(destination.Root.transform.TransformDirection(RoomPackage.Vector(destination.Manifest.entryForward, "entry forward")), Vector3.up).normalized;
            player.TeleportTo(target, Quaternion.LookRotation(forward, Vector3.up), true);
            float until = Time.unscaledTime + 20f;
            while (player && Vector3.Distance(player.transform.position, target) > 5f && Time.unscaledTime < until) yield return null;
            busy = false;
            Print(player && Vector3.Distance(player.transform.position, target) <= 5f ? "Entered " + id + ". Use twa_test_next or an installed room command; twa_test_return leaves safely." : "Travel is pending; floors and the surface checkpoint are retained. Use twa_test_return if needed.");
            if (all) Print("Installed authored rooms are loaded in separate test areas. Open doorways have no connecting corridors.");
        }
        private void Next()
        {
            if (!ReadCatalog()) return;
            var installed = catalog.rooms.OrderBy(record => record.Slot).ToArray();
            int index = activeRoom?.Record == null ? -1 : System.Array.FindIndex(installed, record => record.roomId == activeRoom.Record.roomId);
            Enter(installed[(index + 1) % installed.Length].roomId, false);
        }
        private void ListRooms()
        {
            if (!ReadCatalog()) return;
            foreach (var record in catalog.rooms.OrderBy(r => r.Slot)) Print(record.roomId + " — " + record.displayName + ": twa_test_" + record.roomId.ToLowerInvariant() + (rooms.ContainsKey(record.roomId) ? " (loaded)" : ""));
            Print("twa_test_dungeon [seed] generates the natural room mix with Hushed Monks; twa_test_showcase [seed] shows every source once without enemies. twa_test_return leaves; twa_test_regenerate starts a fresh run.");
        }
        private void Return()
        {
            if (busy) { Print("A test-room transition is in progress."); return; }
            if (!LocalPlayer(out var player)) return;
            if (!Matches(player)) { Print("No surface return point is recorded for this character/world."); return; }
            StartCoroutine(ReturnRoutine(player, false));
        }
        private void Remove()
        {
            RequestPersistentReset(null,true);
        }
        private IEnumerator ReturnRoutine(Player player, bool remove, bool preserveLayoutRecovery = false, bool properExit = false)
        {
            string leavingRun=persistentRunBound?persistentRun?.runId:null;
            AbbeyDoorAudio.StopAll();
            nativeBackground?.Restore();
            ambience?.Suspend(false);
            busy = true; returnPlayer = player;
            Vector3 target = RoomPackage.Vector(checkpoint.position, "return position"); Quaternion rotation = Rotation(checkpoint.rotation);
            player.TeleportTo(target, rotation, true); float until = Time.unscaledTime + 25f, next = Time.unscaledTime + 1f;
            while (player && Vector3.Distance(player.transform.position, target) > 5f && Time.unscaledTime < until)
            { if (Time.unscaledTime >= next) { player.TeleportTo(target, rotation, true); next = Time.unscaledTime + 1f; } yield return null; }
            if (player && Player.m_localPlayer == player && Vector3.Distance(player.transform.position, target) <= 5f)
            {
                if(properExit&&leavingRun!=null)RecordProperDungeonExit(player,leavingRun);
                preserveLayoutRecovery |= !remove && dungeonPlan != null && checkpoint?.dungeonSeed.HasValue == true;
                if (preserveLayoutRecovery) returnPlayer = null; else ClearReturn();
                if (remove) { DisposeRooms(); RemoveWorldPortal(); }
                Print(remove ? "Returned safely and unloaded the temporary rooms; saved world-door removal was requested." : preserveLayoutRecovery
                    ? "Returned safely; saved dungeon layout and grave recovery record remain available through the door."
                    : "Returned to the surface checkpoint; test rooms remain loaded.");
            }
            else Print("Return travel is pending. Floors and recovery checkpoint remain intact; retry twa_test_return.");
            busy = false;
        }
        private bool Inside(LoadedRoom loaded, Vector3 world)
        {
            if (!loaded.Root) return false;
            Vector3 p = loaded.Root.transform.InverseTransformPoint(world);
            return RuntimeRoomBounds.Contains(loaded.Manifest.boundsMin, loaded.Manifest.boundsMax, p.x, p.y, p.z);
        }
        private LoadedRoom RecoverShaft(Player player)
        {
            foreach (var binding in shaftRooms)
            {
                // A retained index cannot grant recovery to a removed/replaced
                // root or room. A replaced component on our live R08 is resolved.
                if (!binding.Root || !ReferenceEquals(binding.Room.Root, binding.Root) ||
                    !rooms.TryGetValue(binding.Key, out var current) || !ReferenceEquals(current, binding.Room)) continue;
                if (!binding.Shaft) binding.Shaft = binding.Root.GetComponent<R08ShaftRuntime>();
                if (binding.Shaft && binding.Shaft.gameObject == binding.Root && binding.Shaft.TryRecover(player)) return binding.Room;
            }
            return null;
        }
        private LoadedRoom FindContainingRoom(Vector3 world)
        {
            foreach (var room in rooms.Values) if (Inside(room, world)) return room;
            return null;
        }
        private void Update()
        {
            var player = Player.m_localPlayer;
            TickDoorLoading(player);
            bool retainedSession = UpdateSessionLifetime(player);
            if (player && !busy) SelectCheckpoint(player);
            if (!retainedSession && RoomLoadCancellationPolicy.Orphaned(player, busy, rooms.Count, inFlightRoom != null, extraAssets != null))
            { CancelRoomLoading(); DisposeRooms(); DisposeWorldPortal(); }
            UpdateWorldPortalPersistence(player);
            TickGraveEjectionReplay(player);
            TickWardingSpawners();
            TickPersistentRun(player);
            TickFalseVows(player);
            TickUnrecordedDead(player);
            RuntimeRoomMaintenance.CollectMissing(rooms, missingRoomKeys, RoomAlive);
            foreach (var missing in missingRoomKeys)
            { var removed = rooms[missing]; removed.Dispose(); rooms.Remove(missing); if (activeRoom == removed) activeRoom = null; }
            missingRoomKeys.Clear();
            UpdateAbbeyAmbience(player);
            RetireCompletedDungeonWhenEmpty();
            if (!busy && player && Matches(player) && player == returnPlayer && player.transform.position.y > HighAltitudeGuard && rooms.Count > 0)
            {
                var shaft = RecoverShaft(player);
                if (shaft != null) { activeRoom = shaft; return; }
                var containing = FindContainingRoom(player.transform.position);
                if (containing != null) activeRoom = containing;
                else if (!InsideDungeonPassage(player.transform.position)) { Logger.LogWarning("Automatic test return after leaving the authored rooms and connected passages."); StartCoroutine(ReturnRoutine(player, false)); return; }
            }
            if (!busy && rooms.Count == 0 && player && ZNet.instance && ZNet.instance.IsServer() && !recoveryAttempted && player.transform.position.y > HighAltitudeGuard && Matches(player))
            { recoveryAttempted = true; Logger.LogWarning("Recovering matching character/world from earlier test altitude."); StartCoroutine(ReturnRoutine(player, false, checkpoint?.dungeonSeed.HasValue == true)); }
        }
        private void WaterControl(Action<LoadedRoom, Action<string>> action)
        {
            if (busy) { Print("A test-room transition is in progress."); return; }
            if (!LocalPlayer(out var player) || activeRoom == null || !activeRoom.Root) { Print("Enter a room before changing its water presentation."); return; }
            try { action(activeRoom, Print); } catch (Exception ex) { Print("Water control unavailable: " + ex.Message); }
        }
        private void Status()
        {
            LogWardingStatus(Print);
            bossMusic?.LogStatus(Print);
            nativeBackground?.LogStatus(Print);
            ambience?.LogStatus(Print);
            if(persistentRun!=null)Print("Saved dungeon run="+persistentRun.runId+"; seed="+persistentRun.seed+"; revision="+persistentRun.revision+
                "; bossCompleted="+persistentRun.bossCompleted+"; entered="+persistentRun.participants.Count+"; awaiting proper exit="+persistentRun.participants.Count(p=>!p.exitedProperly)+
                "; pending saved-run write="+(runWriteFailure??"none")+"; local-host test, remote-client support pending.");
            Print($"Black Abbey {Version}: loadedInstances={rooms.Count}; selected={activeRoom?.InstanceId ?? "none"}; sharedMeshTextureResources={SharedRoomResources.ResidentCount}; transition={busy}; pendingReturn={checkpoint?.pending == true}; isolatedSaveProfile={IsolatedSaveProfile.ActivePath ?? "inactive"}; generated layouts use saved room encounters.");
            var player = Player.m_localPlayer; string advancing = lastStatusFrame < 0 ? "not sampled twice" : (Time.frameCount > lastStatusFrame).ToString(); lastStatusFrame = Time.frameCount;
            if (player)
            {
                bool hit = Physics.Raycast(player.transform.position + Vector3.up * .2f, Vector3.down, out var ground, 2f, LayerMask.GetMask("static_solid", "terrain", "piece"));
                Print($"Player world={player.transform.position}; selected-local={(activeRoom?.Root ? activeRoom.Root.transform.InverseTransformPoint(player.transform.position) : player.transform.position)}; grounded={player.IsOnGround()}; groundRay={(hit ? ground.collider.name + " @" + ground.distance.ToString("F3") + "m" : "none within2m")}; frame={Time.frameCount}; advancing={advancing}.");
            }
            if (activeRoom?.Root)
            {
                var loaded = activeRoom; var colliders = loaded.Root.GetComponentsInChildren<MeshCollider>(true); var particles = loaded.Root.GetComponentsInChildren<ParticleSystem>(true);
                Print($"{loaded.Record.roomId}: source={loaded.Manifest.sourceSha256}; visuals={loaded.Manifest.meshes.Length}/{loaded.VisualTriangles} triangles; colliders={colliders.Count(c => c.enabled)}/{colliders.Length}/{loaded.ColliderTriangles} triangles; nativeFlames={loaded.FlameCount}; particlePlaying={particles.Count(p => p.isPlaying)}/{particles.Length}.");
                foreach (var light in loaded.Root.GetComponentsInChildren<Light>(true)) Print($"{light.name}: active={light.enabled && light.gameObject.activeInHierarchy}; intensity={light.intensity:F3}; range={light.range:F2}; shadows={light.shadows}; resolution={light.shadowCustomResolution}; strength={light.shadowStrength:F2}; bias={light.shadowBias:F4}; normalBias={light.shadowNormalBias:F4}.");
                WaterPresentation.LogState(loaded, Print);
                loaded.Root.GetComponent<R07InteractionRuntime>()?.LogStatus(Print);
                loaded.Root.GetComponent<PewRoomBinding>()?.LogStatus(Print);
                foreach (var material in loaded.Resources.OfType<Material>()) Print($"{material.name}: shader={material.shader.name}; supported={material.shader.isSupported}; queue={material.renderQueue}; keywords={string.Join(",", material.shaderKeywords)}.");
            }
            foreach (var camera in Camera.allCameras.Where(c => c && c.isActiveAndEnabled)) Print($"Camera {camera.name}: requested={camera.renderingPath}; actual={camera.actualRenderingPath}.");
            Print("Offline/source checks and these runtime diagnostics do not grant appearance, performance, multiplayer or release approval.");
        }
        private void DisposeRooms()
        {
            SavePersistentRun(true);ParkDungeonActors();ReleaseProgressCheckpointHooks();
            bossMusic?.Release();
            AbbeyDoorAudio.StopAll();
            nativeBackground?.Restore();
            ambience?.Suspend(true);
            inFlightRoom?.Dispose(); inFlightRoom = null;
            r07Run = null; pewRun = null;
            DisposeMonkRun(); naturalRunId = null;
            graveGuard = new DungeonGraveGuard();
            ClearDungeonArt();
            foreach (var loaded in rooms.Values) loaded.Dispose(); rooms.Clear(); activeRoom = null; gridOrigin = null; RefreshRenderBudget();
            persistentRunBound=false;retirementEnvelope=null;
            ReleaseFalseVowsRun();
        }
        private void RestoreBeforeShutdown()
        {
            var player = Player.m_localPlayer; if (!player || !Matches(player) || player.transform.position.y < HighAltitudeGuard) return;
            try
            {
                Vector3 target = RoomPackage.Vector(checkpoint.position, "return position"); Quaternion rotation = Rotation(checkpoint.rotation); player.transform.SetPositionAndRotation(target, rotation);
                var body = player.GetComponent<Rigidbody>(); if (body) { body.position = target; body.rotation = rotation; body.linearVelocity = Vector3.zero; }
                Logger.LogInfo("Best-effort same-character/world return before shutdown; no save forced, recovery checkpoint retained.");
            }
            catch (Exception ex) { Logger.LogWarning("Shutdown restoration pending recovery: " + ex.Message); }
        }
        private void Print(string message) { if (Console.instance) Console.instance.AddString(message); Logger.LogInfo(message); }
        private void OnDisable() { ShutdownDoorLoading();bossMusic?.Release(); AbbeyDoorAudio.StopAll(); nativeBackground?.Restore(); ambience?.Suspend(true); }
        private void OnApplicationQuit() { ShutdownDoorLoading();SavePersistentRun(true);bossMusic?.Release(); AbbeyDoorAudio.StopAll(); nativeBackground?.Restore(); ambience?.Suspend(true); RestoreBeforeShutdown(); }
        private void OnDestroy() { StopNaturalEntrance();ShutdownDoorwayFaceDiagnostics();ShutdownDoorLoading();bossMusic?.Release(); AbbeyDoorAudio.Dispose(); nativeBackground?.DisposeScope(); ambience?.DisposeAudio(); RestoreBeforeShutdown(); DisposeRooms(); DisposeWorldPortal();ShutdownFalseVows();AbbeyBalanceRuntime.Shutdown();persistenceHooks?.UnpatchSelf();if(persistentOwner==this)persistentOwner=null; }
    }
}

