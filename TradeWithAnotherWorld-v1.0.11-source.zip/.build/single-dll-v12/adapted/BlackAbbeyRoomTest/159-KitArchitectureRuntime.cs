using System;
using System.IO;
using System.Linq;
namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        private string architectureRoot;
        private string SharedDataPath => global::Otherworld.Distribution.BundleRuntime.Data("BlackAbbeyRoomTest");
        private int ArchitectureRevision(bool fresh)
        {
            EnsurePersistentRunWorld();
            if(fresh||persistentRun!=null)return KitArchitectureSelectionPolicy.Revision(fresh,persistentRun?.generationRevision,false,null,null,null);
            // Older helpers sometimes had only the saved entrance seed.
            // That legacy catalog also requires explicit surface regeneration.
            var door=DoorStore.Load(WorldKey());
            if(door?.dungeonSeed.HasValue==true)
            {
                string root=KitArchitectureProfile.SelectRoot(SharedDataPath,KitArchitectureProfile.Revision);
                return KitArchitectureSelectionPolicy.Revision(false,null,true,door.catalogSha256,null,CatalogReader.HashFile(Path.Combine(root,"catalog.json")));
            }
            return KitArchitectureProfile.Revision;
        }
        private string PlanningDataPath(bool fresh)=>KitArchitectureProfile.SelectRoot(SharedDataPath,ArchitectureRevision(fresh));
        private void SelectArchitectureForSavedRun()
        {
            string desired=PlanningDataPath(false);
            if(string.Equals(architectureRoot,desired,StringComparison.OrdinalIgnoreCase))return;
            // A fresh-run preflight never calls this method. Actual switching
            // occurs only after safe retirement or when binding a saved world.
            if(rooms.Values.Any(r=>r?.Root))throw new InvalidOperationException("Unload the current Abbey before switching its architecture; saved rooms were retained.");
            architectureRoot=desired;catalog=null;unrecordedDeadIndex=null;
            falseVowsAssets?.Dispose();falseVowsAssets=null;
            foreach(var resource in unrecordedDeadAssets.Values)resource.Dispose();unrecordedDeadAssets.Clear();
        }
    }
}
