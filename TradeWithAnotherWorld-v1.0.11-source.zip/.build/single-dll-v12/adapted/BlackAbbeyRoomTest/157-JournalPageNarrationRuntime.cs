using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using BepInEx;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.Networking;
using Object=UnityEngine.Object;

namespace BlackAbbeySixRooms
{
    // One local reader voice; this never owns a world actor, global mixer,
    // listener, input guard or document. All Unity calls stay on the main thread.
    internal sealed class JournalPageNarrationRuntime:MonoBehaviour
    {
        sealed class Cached:IDisposable
        {
            internal AudioClip Clip;internal JournalPageNarrationLease Lease;internal long Used;
            public void Dispose(){if(Clip)Object.Destroy(Clip);Clip=null;Lease?.Dispose();Lease=null;}
        }
        readonly JournalPageNarrationPolicy policy=new JournalPageNarrationPolicy();
        readonly Dictionary<string,Cached> cache=new Dictionary<string,Cached>(StringComparer.Ordinal);
        Func<bool> readerOpen;
        string directory,manifestSha,lastFailure,currentPage;
        bool configured,disposed,requested,paused,started,failed;
        long used;
        AudioSource source;
        AudioMixerGroup mixer;
        float nextMixer;
        Coroutine loading;
        UnityWebRequest request;
        Task<JournalPageNarrationAssets> preparing;
        Task<JournalPageNarrationLease> verifying;
        JournalPageNarrationAssets assets;
        JournalPageNarrationLease loadingLease;

        // Optional overrides are for inert managed/offline fixture tests only;
        // the live reader supplies only its own visibility predicate.
        internal void Configure(Func<bool> isOpen,string dataDirectory=null,string expectedManifest=null)
        {
            if(configured)throw new InvalidOperationException("Journal reader narration cannot be rebound.");
            configured=true;readerOpen=isOpen??throw new ArgumentNullException(nameof(isOpen));
            directory=dataDirectory??Path.Combine(global::Otherworld.Distribution.BundleRuntime.Data("BlackAbbeyRoomTest"),"journal-narration");
            manifestSha=expectedManifest??JournalPageNarrationSource.ManifestSha256;
        }
        bool ReaderOpen(){try{return !disposed&&readerOpen!=null&&readerOpen();}catch{return false;}}
        bool Current(long ticket,string page)=>policy.MayPlay(ticket,page,ReaderOpen());
        bool Ended=>started&&!paused&&source&&source.clip&&!source.isPlaying&&loading==null;
        internal bool CanControl=>requested&&!failed&&ReaderOpen();
        internal bool IsPaused=>CanControl&&paused;
        internal bool ShouldOfferPlay=>CanControl&&(paused||Ended);
        internal void TogglePause()
        {
            if(!CanControl)return;
            if(Ended){Restart();return;}
            paused=!paused;
            if(!source||!started||!source.clip)return;
            if(paused)source.Pause();else source.UnPause();
        }
        internal void Restart()
        {
            if(!CanControl)return;
            paused=false;
            // A pending page has not played a sample: resume its one existing
            // verification/decode/mixer job rather than starting another one.
            if(!started&&loading!=null)return;
            string page=currentPage;Play(page);
        }
        internal void Play(string pageId)
        {
            Stop();if(disposed||!configured)return;
            long ticket=policy.Begin(pageId);if(!Current(ticket,pageId))return;
            requested=true;currentPage=pageId;loading=StartCoroutine(Load(ticket,pageId));
        }
        IEnumerator Load(long ticket,string pageId)
        {
            // Ensure the coroutine handle is published before a cached page can
            // finish synchronously; no page/task work runs in Open's call stack.
            yield return null;
            if(!Current(ticket,pageId))yield break;
            if(!cache.TryGetValue(pageId,out var entry))
            {
                if(assets==null)
                {
                    preparing=Task.Run(()=>JournalPageNarrationAssets.Prepare(directory,manifestSha));
                    var task=preparing;while(!task.IsCompleted)yield return null;
                    if(!Current(ticket,pageId))yield break;
                    preparing=null;
                    if(task.IsFaulted||task.IsCanceled){Failure(task.Exception?.GetBaseException().Message??"Narration verification was cancelled.");yield break;}
                    assets=task.Result;
                }
                var bank=assets;verifying=Task.Run(()=>bank.VerifyPage(pageId));
                var verify=verifying;while(!verify.IsCompleted)yield return null;
                if(!Current(ticket,pageId))yield break;
                verifying=null;
                if(verify.IsFaulted||verify.IsCanceled){Failure(verify.Exception?.GetBaseException().Message??"Narration page verification was cancelled.");yield break;}
                loadingLease=verify.Result;
                try
                {
                    request=UnityWebRequestMultimedia.GetAudioClip(new Uri(loadingLease.Path).AbsoluteUri,AudioType.OGGVORBIS);
                    ((DownloadHandlerAudioClip)request.downloadHandler).streamAudio=true;
                    request.timeout=45;request.SendWebRequest();
                }
                catch(Exception error){Failure(error.Message);CancelRequest();DisposeLoadingLease();yield break;}
                while(!request.isDone)yield return null;
                if(!Current(ticket,pageId))yield break;
                AudioClip clip=null;string failure=null;
                try
                {
                    if(request.result!=UnityWebRequest.Result.Success)throw new IOException(request.error??"Native narration decoding failed.");
                    clip=DownloadHandlerAudioClip.GetContent(request);
                    if(!clip||clip.channels!=1||clip.frequency!=48000||clip.samples<1||Math.Abs(clip.length-loadingLease.Page.DurationSeconds)>.2)
                        throw new InvalidDataException("Native narration format or duration differs: "+pageId);
                    clip.name="Abbey journal | "+pageId;
                }
                catch(Exception error){if(clip)Object.Destroy(clip);failure=error.Message;}
                finally{request.Dispose();request=null;}
                if(failure!=null){Failure(failure);DisposeLoadingLease();yield break;}
                entry=new Cached{Clip=clip,Lease=loadingLease,Used=++used};loadingLease=null;cache.Add(pageId,entry);
                while(cache.Count>JournalPageNarrationContract.MaximumCachedPages)
                {
                    var expired=cache.Where(x=>x.Key!=pageId).OrderBy(x=>x.Value.Used).First();cache.Remove(expired.Key);expired.Value.Dispose();
                }
            }
            entry.Used=++used;
            while(Current(ticket,pageId)&&(paused||!ResolveMixer()))yield return null;
            if(!Current(ticket,pageId))yield break;
            if(!source)
            {
                var node=new GameObject("Abbey | local journal narration");node.transform.SetParent(transform,false);source=node.AddComponent<AudioSource>();
                source.playOnAwake=false;source.loop=false;source.spatialBlend=0;source.pitch=1;source.dopplerLevel=0;source.reverbZoneMix=0;source.priority=64;
            }
            source.Stop();source.outputAudioMixerGroup=mixer;source.clip=entry.Clip;source.volume=1;source.timeSamples=0;source.Play();started=true;loading=null;
        }
        AudioMixerGroup ResolveMixer()
        {
            if(mixer)return mixer;if(Time.realtimeSinceStartup<nextMixer)return null;nextMixer=Time.realtimeSinceStartup+1;
            try
            {
                var native=AudioMan.instance?AudioMan.instance.m_ambientMixer:null;
                if(native&&native.audioMixer)mixer=native.audioMixer.FindMatchingGroups("SFX").FirstOrDefault(x=>x&&string.Equals(x.name,"SFX",StringComparison.Ordinal));
            }
            catch(Exception error){Failure("Native SFX mixer pending: "+error.GetType().Name,false);}
            return mixer;
        }
        internal void Stop()
        {
            policy.Stop();requested=false;paused=false;started=false;failed=false;currentPage=null;
            if(source){source.Stop();source.clip=null;}
            CancelRequest();
            if(loading!=null){StopCoroutine(loading);loading=null;}
            var page=verifying;verifying=null;Discard(page);
            var manifest=preparing;preparing=null;Discard(manifest);
            DisposeLoadingLease();
        }
        static void Discard<T>(Task<T> pending)where T:class,IDisposable
        {
            if(pending==null)return;
            pending.ContinueWith(task=>{if(task.Status==TaskStatus.RanToCompletion)task.Result?.Dispose();else{var ignored=task.Exception;}},TaskScheduler.Default);
        }
        void CancelRequest(){var value=request;request=null;if(value==null)return;try{value.Abort();}finally{value.Dispose();}}
        void DisposeLoadingLease(){loadingLease?.Dispose();loadingLease=null;}
        void Failure(string reason,bool terminal=true)
        {
            if(terminal){failed=true;paused=false;started=false;}
            if(reason==lastFailure)return;lastFailure=reason;
            Debug.LogWarning("ABB_JOURNAL_NARRATION_UNAVAILABLE: "+reason+"; the existing reader remains available.");
        }
        void Update(){if(requested&&!ReaderOpen())Stop();}
        internal void Dispose()
        {
            if(disposed)return;disposed=true;Stop();
            foreach(var entry in cache.Values)entry.Dispose();cache.Clear();assets?.Dispose();assets=null;
            if(source)Object.Destroy(source.gameObject);source=null;mixer=null;readerOpen=null;
        }
        void OnDisable()=>Stop();
        void OnDestroy()=>Dispose();
    }
}
