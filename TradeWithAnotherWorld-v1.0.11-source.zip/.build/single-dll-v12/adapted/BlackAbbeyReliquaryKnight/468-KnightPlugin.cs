using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx;
using HarmonyLib;
using Jotunn.Entities;
using Jotunn.Managers;
using UnityEngine;
using Object=UnityEngine.Object;
namespace BlackAbbey.ReliquaryKnight {
 [BepInPlugin(Id,"Black Abbey Reliquary Knight",Version)]
 [BepInDependency(Jotunn.Main.ModGuid,"2.30.2")]
 public sealed class KnightPlugin:BaseUnityPlugin {
  public const string Id="studio.otherworld.reliquaryknight",Version="0.1.9",PrefabName="BA_ReliquaryKnight";
  Harmony harmony;GameObject prefab;KnightVisual visual;bool attempted;string error;
  string Folder=>global::Otherworld.Distribution.BundleRuntime.Data("BlackAbbeyReliquaryKnight");
  void Print(string message){Logger.LogInfo(message);if(Console.instance)Console.instance.AddString(message);}
  void Awake(){
            global::Otherworld.Distribution.BundleRuntime.Initialize(this);
KnightActor.Log=KnightCombat.Log=KnightNavigation.Log=Print;CommandManager.Instance.AddConsoleCommand(new Cmd("twa_knight_spawn",true,Spawn));CommandManager.Instance.AddConsoleCommand(new Cmd("twa_knight_remove",true,Remove));CommandManager.Instance.AddConsoleCommand(new Cmd("twa_knight_status",false,Status));harmony=new Harmony(Id);try{global::Otherworld.Distribution.BundleRuntime.PatchModule(harmony,typeof(KnightPlugin));PrefabManager.OnVanillaPrefabsAvailable+=Register;}catch(Exception e){error=e.ToString();harmony.UnpatchSelf();Logger.LogError("RK_STARTUP_FAILED "+e);}}
  sealed class Cmd:ConsoleCommand {readonly string name;readonly bool cheat;readonly Action action;public Cmd(string n,bool c,Action a){name=n;cheat=c;action=a;}public override string Name=>name;public override string Help=>"Reliquary Knight manual test. Spawn/remove require local host and devcommands; no natural spawns.";public override bool IsCheat=>cheat;public override bool OnlyServer=>cheat;public override void Run(string[] args)=>action();}
  static GameObject Required(string name){var p=PrefabManager.Instance.GetPrefab(name);if(!p)throw new InvalidOperationException("Missing native prefab "+name);return p;}
  void Register(){if(attempted)return;attempted=true;GameObject enemy=null;try{
   KnightActor.Bank=KnightMotionBank.Read(Path.Combine(Folder,"motion"));KnightDeathPresentation.Prepare(KnightActor.Bank);KnightAudio.Prepare(Path.Combine(Folder,"audio"));
   var source=Required("Draugr_Elite");var material=source.GetComponentsInChildren<SkinnedMeshRenderer>(true).SelectMany(s=>s.sharedMaterials).FirstOrDefault(m=>m&&m.HasProperty("_MainTex")&&m.HasProperty("_BumpMap")&&m.HasProperty("_MetallicGlossMap"));
   if(!material)material=Required("Player").GetComponentsInChildren<SkinnedMeshRenderer>(true).SelectMany(s=>s.sharedMaterials).FirstOrDefault(m=>m&&m.HasProperty("_MainTex")&&m.HasProperty("_BumpMap")&&m.HasProperty("_MetallicGlossMap"));
   if(!material)throw new InvalidOperationException("Native character PBR shader unavailable");
   enemy=PrefabManager.Instance.CreateClonedPrefab(PrefabName,source);enemy.SetActive(false);enemy.transform.localScale=Vector3.one*KnightScaleProfile.BodyMultiplier;
   // Native root LevelEffects assigns an absolute level scale. Remove that
   // root-only writer before Awake; hidden native child visuals stay intact.
   foreach(var level in enemy.GetComponents<LevelEffects>())Object.DestroyImmediate(level);
   var h=enemy.GetComponent<Humanoid>();var ai=enemy.GetComponent<MonsterAI>();var cap=enemy.GetComponent<CapsuleCollider>();if(!h||!ai||!cap||!enemy.GetComponent<ZNetView>()||!enemy.GetComponent<Rigidbody>())throw new InvalidOperationException("Native enemy lifecycle incomplete");
   foreach(var r in enemy.GetComponentsInChildren<Renderer>(true))r.enabled=false;
   foreach(var lod in enemy.GetComponentsInChildren<LODGroup>(true))Object.DestroyImmediate(lod);
   enemy.GetComponent<ZNetView>().m_syncInitialScale=true;var networkTransform=enemy.GetComponent<ZSyncTransform>();if(networkTransform)networkTransform.m_syncScale=true;
   visual=KnightVisual.Create(enemy,Path.Combine(Folder,"visual"),material);KnightActor.Template=visual;
   var sword=MakeItem("BA_ReliquaryKnight_SwordProfile","SwordIron",false);var shield=MakeItem("BA_ReliquaryKnight_ShieldProfile","ShieldBanded",true);
   KnightActor.SwordItem=sword.ItemDrop.m_itemData;KnightActor.ShieldItem=shield.ItemDrop.m_itemData;
   h.m_name="Reliquary Knight";h.m_health=650;KnightPoiseProfile.Configure(h);h.m_staggerWhenBlocked=true;h.m_group="BlackAbbeyReliquaryKnight";h.m_boss=false;h.m_bossEvent="";h.m_defeatSetGlobalKey="";
   h.m_defaultItems=new[]{sword.ItemPrefab,shield.ItemPrefab};h.m_unarmedWeapon=sword.ItemDrop;h.m_randomWeapon=Array.Empty<GameObject>();h.m_randomShield=Array.Empty<GameObject>();h.m_randomArmor=Array.Empty<GameObject>();h.m_randomItems=Array.Empty<Humanoid.RandomItem>();h.m_randomSets=Array.Empty<Humanoid.ItemSet>();
   h.m_eye=visual.Named["Head"];h.m_weakSpots=Array.Empty<WeakSpot>();
   ai.m_sleeping=false;ai.m_fallAsleepDistance=0;AccessTools.Field(typeof(MonsterAI),"m_despawnInDay").SetValue(ai,false);AccessTools.Field(typeof(MonsterAI),"m_eventCreature").SetValue(ai,false);
   // Imported attacks do not refresh the native DoAttack age. Disable native
   // flight triggers as well as the identity gate on Flee itself.
   ai.m_fleeIfHurtWhenTargetCantBeReached=false;ai.m_fleeIfLowHealth=0;ai.m_fleeIfNotAlerted=false;ai.m_crownFearRange=0;ai.m_fleeInLava=false;ai.m_afraidOfFire=false;ai.m_avoidLavaFlee=false;
   // Fixed physical envelope derives from the body; weapon silhouettes are contact geometry only.
   cap.center=new Vector3(0,.9f,0);cap.height=1.8f;cap.radius=.35f;
   var player=Required("Player").GetComponent<Humanoid>();h.m_hitEffects=player.m_hitEffects;
   h.m_deathEffects=new EffectList{m_effectPrefabs=(player.m_deathEffects?.m_effectPrefabs??Array.Empty<EffectList.EffectData>()).Where(e=>e?.m_prefab&&!e.m_prefab.GetComponentInChildren<Ragdoll>(true)).ToArray()};
   var drops=enemy.GetComponent<CharacterDrop>();if(drops)drops.m_drops=new List<CharacterDrop.Drop>();
   // Keep native Animator/controller for native stagger/movement/death state. Own source rig is independent.
   foreach(var a in enemy.GetComponentsInChildren<Animator>(true)){a.applyRootMotion=false;a.cullingMode=AnimatorCullingMode.AlwaysAnimate;}
   KnightNativeAudio.FilterPrefab(enemy);
   enemy.AddComponent<KnightActor>();enemy.AddComponent<KnightCombat>();enemy.AddComponent<KnightAudio>();enemy.AddComponent<KnightAudioContact>();enemy.AddComponent<KnightParryPresentation>();enemy.AddComponent<KnightDefense>();
   PrefabManager.Instance.AddPrefab(new CustomPrefab(enemy,false));if(!enemy.transform.parent||enemy.transform.parent.gameObject.activeInHierarchy)throw new InvalidOperationException("Knight prefab must remain in inactive manager container");prefab=enemy;prefab.SetActive(true);PrefabManager.OnVanillaPrefabsAvailable-=Register;Print("Reliquary Knight ready. Use twa_knight_spawn (local host/devcommands). Manual test only; no dungeon spawn changes.");
  }catch(Exception e){error=e.ToString();if(enemy)Object.Destroy(enemy);prefab=null;visual?.Dispose();visual=null;Logger.LogError("RK_REGISTRATION_FAILED; no substitute actor: "+e);}}
  CustomItem MakeItem(string name,string source,bool shield){var original=Required(source).GetComponent<ItemDrop>().m_itemData;var item=new CustomItem(name,source);var data=original.Clone();data.m_shared=(ItemDrop.ItemData.SharedData)typeof(object).GetMethod("MemberwiseClone",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(original.m_shared,null);data.m_dropPrefab=item.ItemPrefab;data.m_shared.m_name=shield?"Reliquary Knight Shield":"Reliquary Knight Sword";data.m_shared.m_useDurability=false;data.m_shared.m_attack=original.m_shared.m_attack.Clone();data.m_shared.m_secondaryAttack=original.m_shared.m_secondaryAttack?.Clone();data.m_shared.m_damages=new HitData.DamageTypes();if(shield)data.m_shared.m_damages.m_blunt=20;else data.m_shared.m_damages.m_slash=35;data.m_shared.m_timedBlockBonus=1f;data.m_shared.m_blockPower=shield?65:15;data.m_shared.m_blockPowerPerLevel=0;item.ItemDrop.m_itemData=data;
   KnightNativeAudio.FilterPrefab(item.ItemPrefab);foreach(var r in item.ItemPrefab.GetComponentsInChildren<Renderer>(true))r.enabled=false;if(!ItemManager.Instance.AddItem(item))throw new InvalidOperationException("Cannot register internal profile "+name);return item;}
  bool Host(out Player p){p=Player.m_localPlayer;if(!p||!ZNet.instance||!ZNet.instance.IsServer()||!ZNetScene.instance||!prefab){Print("Use in a loaded local-host world; twa_knight_status shows registration errors.");return false;}return true;}
  void Spawn(){if(!Host(out var p))return;if(Object.FindObjectsByType<KnightActor>(FindObjectsSortMode.None).Count(a=>a&&a.gameObject.activeInHierarchy)>=3){Print("Remove existing test knights first: twa_knight_remove");return;}var f=Vector3.ProjectOnPlane(p.transform.forward,Vector3.up).normalized;var at=p.transform.position+f*8;int mask=LayerMask.GetMask("terrain","static_solid","piece");if(!Physics.Raycast(at+Vector3.up*2,Vector3.down,out var floor,5,mask,QueryTriggerInteraction.Ignore)||floor.normal.y<.7f){Print("Stand with flat floor eight metres ahead.");return;}at.y=floor.point.y+.06f;float radius=KnightScaleProfile.NativeBodyRadius*KnightScaleProfile.BodyMultiplier,height=KnightScaleProfile.NativeBodyHeight*KnightScaleProfile.BodyMultiplier;if(Physics.CheckCapsule(at+Vector3.up*(radius+.035f),at+Vector3.up*(height-radius-.035f),radius-.015f,mask,QueryTriggerInteraction.Ignore)){Print("The spawn location is obstructed; face an open space.");return;}Object.Instantiate(prefab,at,Quaternion.LookRotation(-f)).SetActive(true);Print("Spawned hostile Reliquary Knight. Remove nearby owned test knights: twa_knight_remove");}
  void Remove(){if(!Host(out var p))return;int n=0;foreach(var a in Object.FindObjectsByType<KnightActor>(FindObjectsSortMode.None)){if(!a||!a.gameObject.activeInHierarchy||(a.transform.position-p.transform.position).sqrMagnitude>10000)continue;var v=a.GetComponent<ZNetView>();if(v&&v.IsValid()&&v.IsOwner()){ZNetScene.instance.Destroy(a.gameObject);n++;}}Print("Removed "+n+" nearby owned Reliquary Knights.");}
  void Status(){Print("Reliquary Knight "+Version+" ready="+(prefab!=null)+" clips="+(KnightActor.Bank?.Descriptors.Count??0)+" naturalSpawns=false");if(error!=null)Print(error);foreach(var a in Object.FindObjectsByType<KnightActor>(FindObjectsSortMode.None))if(a&&a.gameObject.activeInHierarchy)Print(a.Status());}
  void OnDestroy(){PrefabManager.OnVanillaPrefabsAvailable-=Register;harmony?.UnpatchSelf();KnightNavigation.Shutdown();KnightDeathPresentation.Shutdown();KnightAudio.Shutdown();visual?.Dispose();}
 }
}
