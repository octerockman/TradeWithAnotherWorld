using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using BepInEx;
using HarmonyLib;
using Jotunn.Entities;
using Jotunn.Managers;
using UnityEngine;
using Object=UnityEngine.Object;

namespace Wayfarer.InGame
{
    [BepInPlugin(Id,"Weathered Wayfarer",Version)]
    [BepInDependency(Jotunn.Main.ModGuid,"2.30.2")]
    public sealed class WayfarerPlugin:BaseUnityPlugin
    {
        public const string Id="studio.otherworld.wayfarer",Version="0.1.7";
        public const string CampPrefab="TWA_WayfarerCamp_v1",NpcPrefab="TWA_WeatheredWayfarer_v1";
        internal const string OwnerKey="twa_wf_owner",GroupKey="twa_wf_group",RoleKey="twa_wf_role",CampKey="twa_wf_camp",NpcKey="twa_wf_npc",FireKey="twa_wf_fire";
        public static WayfarerPlugin Instance{get;private set;} public AssetBank Assets{get;private set;}
        GameObject campPrefab,npcPrefab;Harmony patches;bool busy,registered;string lastClearing="none";
        public static void Report(string text){if(Instance)Instance.Logger.LogInfo(text);}
        public void Print(string text){Logger.LogInfo(text);if(Console.instance)Console.instance.AddString(text);}
        void Awake()
        {
            global::Otherworld.Distribution.BundleRuntime.Initialize(this);

            Instance=this;Assets=new AssetBank(global::Otherworld.Distribution.BundleRuntime.Data("WayfarerInGame"),Report);
            patches=new Harmony(Id);global::Otherworld.Distribution.BundleRuntime.PatchModule(patches,typeof(WayfarerPlugin));
            PrefabManager.OnVanillaPrefabsAvailable+=Register;
            ZoneManager.OnVanillaLocationsAvailable+=RegisterNaturalCamp;
            Add("twa_wayfarer_spawn","Prepare a camp and clear natural trees/rocks from its footprint. Host/devcommands only.",true,()=>Spawn(false));
            Add("twa_wayfarer_spawn_npc","Place only the saved Wayfarer NPC ahead. Host/devcommands only.",true,()=>Spawn(true));
            Add("twa_wayfarer_remove","Remove the nearest owned Wayfarer camp/NPC and only its linked fire within30m. Host/devcommands only.",true,RemoveNearest);
            Add("twa_wayfarer_status","Report Wayfarer module, saved instances, physics and source motion. Creates nothing.",false,Status);
            Report("WF_MODULE_READY version="+Version+" worldLocation=enabled payloadLoading=lazy");
        }
        void RegisterNaturalCamp()
        {
            try { global::Otherworld.Distribution.NaturalLocations.RegisterCamp(); }
            catch (Exception ex) { Logger.LogError("WF_LOCATION_REGISTRATION_FAILED "+ex); }
        }

        internal IEnumerator MaterializeNaturalCamp(ZNetView site)
        {
            if (!registered) yield break;
            yield return Assets.Ensure();
            if (!this || !site || !site.IsValid() || !site.IsOwner() || !Assets.Ready ||
                site.GetZDO().GetBool(NaturalCampSite.Complete,false) || !ZNetScene.instance) yield break;

            var created = new List<GameObject>();
            try
            {
                NativeCampLighting.Validate();
                var player = PrefabManager.Instance.GetPrefab("Player");
                var capsule = player ? player.GetComponent<CapsuleCollider>() : null;
                if (!capsule) throw new InvalidOperationException("Native standing-player capsule unavailable.");
                float actorScale = Mathf.Max(capsule.height,capsule.radius*2) *
                    CampInstanceScale.StandingRatio / CampInstanceScale.IdleSourceHeight;
                float scale = CampInstanceScale.NewCamp;
                Vector3 origin = site.transform.position;
                Quaternion rotation = site.transform.rotation;
                string group = Guid.NewGuid().ToString("N");
                var camp = SpawnNetwork(campPrefab,origin,rotation,group,"camp",created);
                var record = camp.GetZDO();
                record.Set(CampInstanceScale.CampKey,scale);
                record.Set("twa_wf_features_v5",1);
                SpawnCampContents(camp, origin, rotation, group, scale, actorScale, created);
                IssueCampCoin(camp, origin, rotation, group, scale, created);
                site.GetZDO().Set(NaturalCampSite.Complete,true);
                Report("WF_NATURAL_CAMP_PLACED position="+origin);
            }
            catch (Exception ex)
            {
                foreach (var obj in created) if (obj) CleanupNewObject(obj);
                Logger.LogError("WF_NATURAL_CAMP_FAILED "+ex);
            }
        }
        sealed class Command:ConsoleCommand
        {
            readonly string name,help;readonly bool host;readonly Action action;
            public Command(string n,string h,bool s,Action a){name=n;help=h;host=s;action=a;}
            public override string Name=>name;public override string Help=>help;public override bool IsCheat=>host;public override bool OnlyServer=>host;
            public override void Run(string[] args){if(args.Length!=0){Instance.Print("This command takes no arguments.");return;}action();}
        }
        void Add(string name,string help,bool host,Action action)=>CommandManager.Instance.AddConsoleCommand(new Command(name,help,host,action));
        bool CanChange(out Player player)
        {
            player=Player.m_localPlayer;
            if(!player||!ZNet.instance||!ZNet.instance.IsServer()||!ZNetScene.instance||!Console.instance||!Console.instance.IsCheatsEnabled())
            {Print("Use this command as the world host with devcommands enabled.");return false;}
            return true;
        }
        void Register()
        {
            if(registered)return;
            try
            {
                var manager=PrefabManager.Instance;var haldor=manager.GetPrefab("Haldor");
                if(!haldor||!haldor.GetComponent<Trader>()||!haldor.GetComponent<ZNetView>())throw new InvalidOperationException("Installed native Trader prefab Haldor unavailable.");
                StrangeCoinItem.Register(global::Otherworld.Distribution.BundleRuntime.Data("WayfarerInGame"));CampCauldron.Register();
                campPrefab=manager.CreateEmptyPrefab(CampPrefab,true);campPrefab.SetActive(false);
                // Jotunn's 'empty' factory actually creates PrimitiveType.Cube.
                // Remove only its generated root presentation/collision, never
                // any authored camp geometry or the required network view.
                foreach(var c in campPrefab.GetComponents<Renderer>())Object.DestroyImmediate(c);
                foreach(var c in campPrefab.GetComponents<MeshFilter>())Object.DestroyImmediate(c);
                foreach(var c in campPrefab.GetComponents<Collider>())Object.DestroyImmediate(c);
                var cv=campPrefab.GetComponent<ZNetView>()??campPrefab.AddComponent<ZNetView>();cv.m_persistent=true;cv.m_syncInitialScale=true;campPrefab.AddComponent<CampTerrainSupport>();campPrefab.AddComponent<CampInstance>();
                npcPrefab=manager.CreateClonedPrefab(NpcPrefab,haldor);npcPrefab.SetActive(false);
                var nv=npcPrefab.GetComponent<ZNetView>();nv.m_persistent=true;nv.m_syncInitialScale=true;
                foreach(var r in npcPrefab.GetComponentsInChildren<Renderer>(true))r.enabled=false;
                foreach(var c in npcPrefab.GetComponentsInChildren<Collider>(true))c.enabled=false;
                foreach(var a in npcPrefab.GetComponentsInChildren<AudioSource>(true))a.enabled=false;
                foreach(var a in npcPrefab.GetComponentsInChildren<Light>(true))a.enabled=false;
                foreach(var a in npcPrefab.GetComponentsInChildren<ParticleSystem>(true))a.gameObject.SetActive(false);
                foreach(var snap in npcPrefab.GetComponents<SnapToGround>())Object.DestroyImmediate(snap);
                var capsule=npcPrefab.AddComponent<CapsuleCollider>();capsule.center=new Vector3(0,.91f,0);capsule.height=1.82f;capsule.radius=.27f;
                ConfigureTrader(npcPrefab.GetComponent<Trader>());npcPrefab.AddComponent<NpcInstance>().BodyCollider=capsule;
                if(!campPrefab.transform.parent||campPrefab.transform.parent.gameObject.activeInHierarchy||!npcPrefab.transform.parent||npcPrefab.transform.parent.gameObject.activeInHierarchy)throw new InvalidOperationException("Network prototypes must remain in the inactive prefab container.");
                manager.AddPrefab(new CustomPrefab(campPrefab,false));manager.AddPrefab(new CustomPrefab(npcPrefab,false));campPrefab.SetActive(true);npcPrefab.SetActive(true);registered=true;
                PrefabManager.OnVanillaPrefabsAvailable-=Register;Report("WF_PREFABS_REGISTERED camp="+CampPrefab+" npc="+NpcPrefab+" heavyDataLoaded=false");
            }
            catch(Exception e){Report("WF_REGISTRATION_FAILED "+e);}
        }
        static void ConfigureTrader(Trader trader)
        {
            trader.m_name="Weathered Wayfarer";trader.m_dialogHeight=1.85f;trader.m_hoverOffset=1.65f;
            // Keep the native Trader/UI and invisible native Animator bindings.
            // Empty inventory is intentional until Jesse designs the economy.
            // Native Say(List) assumes at least one entry, so silence is one
            // empty string rather than an unsafe empty dialogue list.
            foreach(var f in typeof(Trader).GetFields(BindingFlags.Public|BindingFlags.Instance))
            {
                if(f.FieldType==typeof(List<string>))f.SetValue(trader,new List<string>{""});
                else if(f.FieldType==typeof(EffectList))f.SetValue(trader,new EffectList());
                else if(f.Name=="m_items"||f.Name=="m_useItems"||f.Name=="m_randomTalkConditionals")f.SetValue(trader,Activator.CreateInstance(f.FieldType));
            }
        }
        void Spawn(bool npcOnly)
        {
            if(busy){Print("A Wayfarer command is already in progress.");return;}
            if(!CanChange(out var player))return;if(!registered){Print("Wait for the native prefabs to finish registering.");return;}
            busy=true;StartCoroutine(SpawnRoutine(player,npcOnly));
        }
        IEnumerator SpawnRoutine(Player player,bool npcOnly)
        {
            Print("Preparing the Wayfarer assets. The first placement loads the maps once.");
            yield return Assets.Ensure();
            var created=new List<GameObject>();string error=null;ZNetView camp=null;Vector3 origin=Vector3.zero;Quaternion rotation=Quaternion.identity;NatureSiteClearing clearing=null;float campScale=CampInstanceScale.NewCamp,actorScale=1;
            try
            {
                if(!Assets.Ready)throw new InvalidOperationException(Assets.Failure);
                if(!CanChange(out var now)||now!=player)throw new InvalidOperationException("World/player changed during loading; no camp placed.");
                actorScale=CampInstanceScale.ActorFor(player,out float standingHeight);
                Print("Camp size "+campScale.ToString("F2")+"; Wayfarer idle height "+(standingHeight*CampInstanceScale.StandingRatio).ToString("F2")+"m; player standing "+standingHeight.ToString("F2")+"m.");
                NativeCampLighting.Validate();
                Vector3 forward=Vector3.ProjectOnPlane(player.transform.forward,Vector3.up).normalized;if(forward.sqrMagnitude<.8f)forward=Vector3.forward;
                rotation=Quaternion.LookRotation(-forward,Vector3.up);origin=player.transform.position+forward*(npcOnly?3f:8f);
                if(!PrefabManager.Instance.GetPrefab("fire_pit")||!PrefabManager.Instance.GetPrefab("Wood")||!CampCauldron.Prefab||!StrangeCoinItem.Prefab)throw new InvalidOperationException("Native camp/item/station prerequisites are unavailable; no site changed.");
                var settings=CheckGround(ref origin,rotation,npcOnly,npcOnly?actorScale:campScale,out clearing);
                if(clearing!=null){lastClearing="preflight "+clearing.Diagnostics;Print("Site checked: "+clearing.Planned+" natural objects will be cleared after camp setup succeeds.");}
                if(!npcOnly)
                {
                    camp=SpawnNetwork(campPrefab,origin,rotation,Guid.NewGuid().ToString("N"),"camp",created);
                    camp.GetZDO().Set(CampInstanceScale.CampKey,campScale);
                    camp.GetZDO().Set("twa_wf_features_v5",1);
                    CampTerrainSupport.SaveNew(camp.GetZDO(),settings);
                }
            }
            catch(Exception e){error=e.Message;Report("WF_MANUAL_SPAWN_FAILED "+e);}
            if(error==null&&camp)
            {
                var ground=camp.GetComponent<CampTerrainSupport>();yield return ground.Ensure();
                if(!ground||!ground.Ready)error=ground?ground.Failure??"Camp ground was not ready.":"Camp removed during ground preparation.";
            }
            if(error==null)try
            {
                if(!CanChange(out var now)||now!=player)throw new InvalidOperationException("World/player changed during terrain preparation; no camp kept.");
                if(!npcOnly&&(!camp||!camp.IsValid()))throw new InvalidOperationException("Camp removed during preparation.");
                if(npcOnly)
                {
                    var npc=SpawnNetwork(npcPrefab,origin,rotation,Guid.NewGuid().ToString("N"),"npc",created);
                    npc.SetLocalScale(Vector3.one);
                    npc.GetZDO().Set(CampInstanceScale.ActorKey,actorScale);
                }
                else SpawnCampContents(camp, origin, rotation, camp.GetZDO().GetString(GroupKey,""), campScale, actorScale, created);
            }
            catch(Exception e){error=e.Message;Report("WF_MANUAL_SPAWN_FAILED "+e);}
            if(error==null)
            {
                float deadline=Time.realtimeSinceStartup+45;
                while(Time.realtimeSinceStartup<deadline&&created.All(x=>x)&&created.Any(x=>x.GetComponent<CampInstance>()&&!x.GetComponent<CampInstance>().Ready&&x.GetComponent<CampInstance>().Failure==null||x.GetComponent<NpcInstance>()&&!x.GetComponent<NpcInstance>().Ready&&x.GetComponent<NpcInstance>().Failure==null||x.GetComponent<OwnedCampFire>()&&!x.GetComponent<OwnedCampFire>().Ready&&x.GetComponent<OwnedCampFire>().Failure==null||x.GetComponent<OwnedCampCauldron>()&&!x.GetComponent<OwnedCampCauldron>().Ready&&x.GetComponent<OwnedCampCauldron>().Failure==null))yield return null;
                foreach(var obj in created)
                {
                    if(!obj){error="A new instance was removed during setup.";break;}
                    var c=obj.GetComponent<CampInstance>();var n=obj.GetComponent<NpcInstance>();
                    if(c&&!c.Ready){error=c.Failure??"Camp setup timeout.";break;}if(n&&!n.Ready){error=n.Failure??"NPC setup timeout.";break;}
                    var fire=obj.GetComponent<OwnedCampFire>();if(fire&&!fire.Ready){error=fire.Failure??"Native fire setup timeout.";break;}
                    var station=obj.GetComponent<OwnedCampCauldron>();if(station&&!station.Ready){error=station.Failure??"Native cauldron setup timeout.";break;}
                }
            }
            // Irreversible nature clearing is the final commit, after actual
            // ground collision and all camp/NPC visual setup have succeeded.
            // Recheck the site and every exact root/owner before the first delete.
            if(error==null&&clearing!=null)try
            {
                if(!CanChange(out var now)||now!=player||!camp||!camp.IsValid()||!camp.GetComponent<CampTerrainSupport>().Ready)throw new InvalidOperationException("Camp/world changed before clearing; no nature removed.");
                string group=camp.GetZDO().GetString(GroupKey,"");
                foreach(var obj in created){var view=obj?obj.GetComponent<ZNetView>():null;if(!view||!view.IsValid()||!Owned(view.GetZDO())||view.GetZDO().GetString(GroupKey,"")!=group)throw new InvalidOperationException("A staged camp object changed before clearing; no nature removed.");}
                var exactOwnObjects=new List<GameObject>(created);var bag=camp.GetComponent<CampInstance>().Bag;
                // The source bag's two physical bodies are deliberately scene
                // roots. Exempt only this new camp component's exact bodies,
                // never arbitrary objects sharing a helper-like name.
                if(bag&&bag.DynamicBody)exactOwnObjects.Add(bag.DynamicBody.gameObject);
                if(bag&&bag.AnchorBody)exactOwnObjects.Add(bag.AnchorBody.gameObject);
                clearing.Commit(exactOwnObjects);lastClearing="committed "+clearing.Diagnostics;
                camp.GetZDO().Set("twa_wf_cleared_v3",clearing.Removed);camp.GetZDO().Set("twa_wf_clear_summary_v3",clearing.Summary);
                foreach(var obj in created){var f=obj.GetComponent<OwnedCampFire>();if(f)f.RefreshAfterClearing();}
                // Reserve once before materialization. No yield/autopickup is
                // permitted here; later reloads never recreate a missing coin.
                IssueCampCoin(camp, origin, rotation, group, campScale, created);
            }
            catch(Exception e){error=e.Message;lastClearing="failed "+clearing.Diagnostics;Report("WF_SITE_COMMIT_FAILED "+e);}
            if(error!=null){foreach(var obj in created)if(obj)CleanupNewObject(obj);Print("No camp kept: "+error+(clearing!=null&&clearing.Removed>0?" At least "+clearing.Removed+" natural objects were permanently removed before this failure; removing ground support does not restore that nature.":" No natural objects were removed."));}
            else Print(npcOnly?"Wayfarer placed and saved.":"Wayfarer camp saved; cleared "+clearing.Removed+" natural objects.");
            busy=false;
        }
        void SpawnCampContents(ZNetView camp, Vector3 origin, Quaternion rotation, string group, float scale, float actorScale, List<GameObject> created)
        {
            var actor = Assets.Camp.Payload.actorPlacement;
            var npc = SpawnNetwork(npcPrefab,origin+rotation*(PayloadReader.V(actor.position)*scale),
                rotation*PayloadReader.Q(actor.rotation),group,"npc",created);
            npc.SetLocalScale(PayloadReader.V(actor.scale));
            npc.GetZDO().Set(CampInstanceScale.ActorKey,actorScale);
            var placement = Assets.Camp.Payload.nativeInstances.Single(p=>p.prefab=="fire_pit"&&!p.visualOnly);
            var stock = PrefabManager.Instance.GetPrefab("fire_pit");
            if (!stock) throw new InvalidOperationException("Installed native fire_pit missing.");
            var fire = SpawnNetwork(stock,origin+rotation*(PayloadReader.V(placement.position)*scale),
                rotation*PayloadReader.Q(placement.rotation),group,"fire",created,scale,PayloadReader.V(placement.scale)*scale);
            fire.SetLocalScale(PayloadReader.V(placement.scale)*scale);
            fire.GetZDO().Set(CampInstanceScale.CampKey,scale);
            var record = camp.GetZDO();
            record.Set(NpcKey,npc.GetZDO().m_uid);
            record.Set(FireKey,fire.GetZDO().m_uid);
            npc.GetZDO().Set(CampKey,record.m_uid);
            fire.GetZDO().Set(CampKey,record.m_uid);
            Vector3 stationScale = Vector3.one*(CampCauldron.SourceFit*scale);
            var station = SpawnNetwork(CampCauldron.Prefab,origin+rotation*(CampCauldron.SourcePosition*scale),
                rotation,group,"cauldron",created,1,stationScale);
            station.SetLocalScale(stationScale);
            station.GetZDO().Set(CampKey,record.m_uid);
            record.Set(CampCauldron.LinkKey,station.GetZDO().m_uid);
        }
        void IssueCampCoin(ZNetView camp, Vector3 origin, Quaternion rotation, string group, float scale, List<GameObject> created)
        {
            var record = camp.GetZDO();
            if (record.GetBool(StrangeCoinItem.IssuedKey,false))
                throw new InvalidOperationException("This camp already issued its single coin.");
            record.Set(StrangeCoinItem.IssuedKey,true);
            var coin = SpawnNetwork(StrangeCoinItem.Prefab,origin+rotation*(StrangeCoinItem.Contact(Assets.Camp.Payload)*scale),rotation,group,"coin",created);
            coin.GetZDO().Set(CampKey,record.m_uid);
            coin.GetZDO().Set(CampInstanceScale.CampKey,scale);
            record.Set(StrangeCoinItem.LinkKey,coin.GetZDO().m_uid);
            camp.GetComponent<CampInteractionBindings>()?.HideCoinNow();
        }
        static ZNetView SpawnNetwork(GameObject prefab,Vector3 position,Quaternion rotation,string group,string role,List<GameObject> created,float effectScale=1,Vector3? initialScale=null)
        {
            GameObject obj;
            if(role=="fire"||role=="cauldron")
            {
                var stage=new GameObject("WF_Inactive_Native_Fire_Staging");stage.SetActive(false);
                try
                {
                    obj=Object.Instantiate(prefab,stage.transform,false);created.Add(obj);obj.SetActive(false);obj.transform.SetParent(null,false);obj.transform.SetPositionAndRotation(position,rotation);
                    if(initialScale.HasValue)obj.transform.localScale=initialScale.Value;var nv=obj.GetComponent<ZNetView>();nv.m_persistent=true;nv.m_syncInitialScale=true;
                    if(role=="fire"){NativeCampLighting.ConfigureFirePresentation(obj,effectScale);var fire=obj.GetComponent<Fireplace>();fire.m_startFuel=Mathf.Max(fire.m_startFuel,fire.m_maxFuel);obj.AddComponent<OwnedCampFire>();}obj.SetActive(true);
                }
                finally{Object.Destroy(stage);}
            }
            else{obj=Object.Instantiate(prefab,position,rotation);created.Add(obj);}
            var view=obj.GetComponent<ZNetView>();
            if(!view||!view.IsValid()||!view.IsOwner())throw new InvalidOperationException("Host could not create an owned persistent network object.");
            view.m_persistent=true;var z=view.GetZDO();z.Persistent=true;z.Set(OwnerKey,Id);z.Set(GroupKey,group);z.Set(RoleKey,role);
            if(role=="coin"){var rb=obj.GetComponent<Rigidbody>();if(rb){rb.useGravity=false;rb.isKinematic=true;rb.constraints=RigidbodyConstraints.FreezeAll;}}
            return view;
        }
        static void CleanupNewObject(GameObject obj)
        {
            // This private rollback accepts only exact references captured
            // immediately after Instantiate by this operation. It also removes
            // a failed pre-tag object, which ordinary scoped removal must refuse.
            var view=obj.GetComponent<ZNetView>();
            if(view&&view.IsValid()&&ZNetScene.instance&&ZDOMan.instance!=null)
            {
                var z=view.GetZDO();if(!view.IsOwner())view.ClaimOwnership();
                if(view.IsOwner())ZNetScene.instance.Destroy(obj);
                else if(ZNet.instance&&ZNet.instance.IsServer()){ZDOMan.instance.DestroyZDO(z);Object.Destroy(obj);}
            }
            else Object.Destroy(obj);
        }
        CampTerrainSettings CheckGround(ref Vector3 origin,Quaternion rotation,bool npcOnly,float instanceScale,out NatureSiteClearing clearing)
        {
            clearing=null;
            if(!ZoneSystem.instance)throw new InvalidOperationException("Wait for world ground to load.");
            Vector3 low=(npcOnly?new Vector3(-.55f,0,-.55f):PayloadReader.V(Assets.Camp.Payload.boundsMin))*instanceScale,high=(npcOnly?new Vector3(.55f,1.9f,.55f):PayloadReader.V(Assets.Camp.Payload.boundsMax))*instanceScale;
            float grid=1;
            foreach(float x in new[]{low.x,high.x})foreach(float z in new[]{low.z,high.z})
            {
                var hm=Heightmap.FindHeightmap(origin+rotation*new Vector3(x,0,z));if(!hm||hm.IsDistantLod||hm.m_scale<=0||hm.m_scale>2)throw new InvalidOperationException("Wait for nearby camp ground to load.");grid=Mathf.Max(grid,hm.m_scale);
            }
            float pad=npcOnly?0:Mathf.Max(CampGroundPolicy.MinimumPad,1.5f*grid),feather=npcOnly?0:CampGroundPolicy.Feather;
            var core=new List<float>();var all=new List<float>();
            for(int x=0;x<7;x++)for(int z=0;z<7;z++)
            {
                var sample=origin+rotation*new Vector3(Mathf.Lerp(low.x-pad,high.x+pad,x/6f),0,Mathf.Lerp(low.z-pad,high.z+pad,z/6f));
                core.Add(SampleGround(sample));
            }
            if(npcOnly&&core.Max()-core.Min()>.15f)throw new InvalidOperationException("Choose flatter ground for the NPC-only command.");
            float target=npcOnly?core.Min():CampGroundPolicy.Median(core.ToArray());
            if(!npcOnly&&core.Any(h=>Mathf.Abs(h-target)>CampGroundPolicy.MaximumCutFill))throw new InvalidOperationException("This cliff needs more than6m of cut/fill; choose a gentler slope for the camp.");
            if(!npcOnly)feather=CampGroundPolicy.FeatherFor(core.Max(h=>Mathf.Abs(h-target)),grid);
            float extent=pad+feather;
            for(int x=0;x<7;x++)for(int z=0;z<7;z++)
            {
                var edge=origin+rotation*new Vector3(Mathf.Lerp(low.x-extent,high.x+extent,x/6f),0,Mathf.Lerp(low.z-extent,high.z+extent,z/6f));all.Add(SampleGround(edge));
            }
            origin.y=target-.005f;
            var proposedCenter=origin+rotation*new Vector3((low.x+high.x)*.5f,0,(low.z+high.z)*.5f);
            float proposedRadius=new Vector2((high.x-low.x)*.5f+extent,(high.z-low.z)*.5f+extent).magnitude;
            foreach(var existing in CampInstance.Live.Where(c=>c&&c.View&&c.View.IsValid()&&Owned(c.View.GetZDO())))
            {
                var old=CampTerrainSupport.ReadSavedSettings(existing.View.GetZDO());
                float oldScale=CampInstanceScale.Read(existing.View.GetZDO(),CampInstanceScale.CampKey);
                Vector3 oldLow=old?.Low??PayloadReader.V(Assets.Camp.Payload.boundsMin)*oldScale,oldHigh=old?.High??PayloadReader.V(Assets.Camp.Payload.boundsMax)*oldScale;
                float oldExtent=old!=null?old.Pad+old.Feather:CampGroundPolicy.MinimumPad;
                var oldCenter=existing.transform.TransformPoint(new Vector3((oldLow.x+oldHigh.x)*.5f,0,(oldLow.z+oldHigh.z)*.5f));
                float oldRadius=new Vector2((oldHigh.x-oldLow.x)*.5f+oldExtent,(oldHigh.z-oldLow.z)*.5f+oldExtent).magnitude;
                if(Vector2.Distance(new Vector2(proposedCenter.x,proposedCenter.z),new Vector2(oldCenter.x,oldCenter.z))<=proposedRadius+oldRadius)
                    throw new InvalidOperationException("Site protected by other Wayfarer camp support: "+existing.name+". Choose ground farther away.");
            }
            var inverse=Quaternion.Inverse(rotation);
            foreach(var piece in Object.FindObjectsByType<Piece>(FindObjectsSortMode.None))if(piece&&piece.IsPlacedByPlayer())
            {
                // Protect player structures throughout the brush footprint,
                // regardless of whether they are above or below the old hill.
                var point=inverse*(piece.transform.position-origin);
                bool overlaps=point.x>=low.x-extent&&point.x<=high.x+extent&&point.z>=low.z-extent&&point.z<=high.z+extent;
                if(!overlaps)foreach(var c in piece.GetComponentsInChildren<Collider>(true))
                {
                    if(!c||!c.enabled)continue;var b=c.bounds;float minX=float.PositiveInfinity,maxX=float.NegativeInfinity,minZ=float.PositiveInfinity,maxZ=float.NegativeInfinity;
                    for(int i=0;i<8;i++){var v=inverse*(b.center+Vector3.Scale(b.extents,new Vector3((i&1)==0?-1:1,(i&2)==0?-1:1,(i&4)==0?-1:1))-origin);minX=Mathf.Min(minX,v.x);maxX=Mathf.Max(maxX,v.x);minZ=Mathf.Min(minZ,v.z);maxZ=Mathf.Max(maxZ,v.z);}
                    if(maxX>=low.x-extent&&minX<=high.x+extent&&maxZ>=low.z-extent&&minZ<=high.z+extent){overlaps=true;break;}
                }
                if(overlaps)throw new InvalidOperationException("Site protected by player structure: "+piece.name+". Choose ground clear of that structure and its footprint.");
            }
            float bottom=Mathf.Min(all.Min(),target)-.20f,top=Mathf.Max(all.Max(),target)+high.y+.25f;
            var half=new Vector3((high.x-low.x)/2+extent+.10f,(top-bottom)/2,(high.z-low.z)/2+extent+.10f);var center=new Vector3(origin.x,(bottom+top)/2,origin.z)+rotation*new Vector3((low.x+high.x)/2,0,(low.z+high.z)/2);
            if(!npcOnly)
            {
                var settings=new CampTerrainSettings{Low=low,High=high,Target=target,Pad=pad,Feather=feather};settings.Validate();
                clearing=NatureSiteClearing.Plan(origin,rotation,settings,bottom,top);return settings;
            }
            int mask=LayerMask.GetMask("piece","static_solid","Default","character","character_net","character_noenv");
            foreach(var c in Physics.OverlapBox(center,half,rotation,mask,QueryTriggerInteraction.Ignore))if(c&&!c.GetComponentInParent<Heightmap>()&&!c.transform.IsChildOf(Player.m_localPlayer.transform))throw new InvalidOperationException("NPC-only site blocked by "+c.name+". Use an open spot.");
            return null;
        }
        static float SampleGround(Vector3 point)
        {
            var hm=Heightmap.FindHeightmap(point);
            if(!hm||hm.IsDistantLod||!ZNetScene.instance.IsAreaReady(point)||!ZoneSystem.instance.GetGroundHeight(point,out float height)||!PayloadReader.Finite(height)||height<ZoneSystem.instance.m_waterLevel+.15f)throw new InvalidOperationException("Choose loaded, dry ground throughout the camp and its edges.");
            return height;
        }
        void RemoveNearest()
        {
            if(busy){Print("A Wayfarer command is still in progress.");return;}if(!CanChange(out var player))return;
            var choices=CampInstance.Live.Where(x=>x&&x.View&&x.View.IsValid()).Select(x=>x.View).Concat(NpcInstance.Live.Where(x=>x&&x.View&&x.View.IsValid()).Select(x=>x.View)).Where(x=>Owned(x.GetZDO())).OrderBy(x=>(x.transform.position-player.transform.position).sqrMagnitude).ToArray();
            var nearest=choices.FirstOrDefault(x=>(x.transform.position-player.transform.position).sqrMagnitude<=900);
            if(!nearest){Print("No owned Wayfarer camp/NPC within30m.");return;}
            var selected=nearest.GetZDO();var group=selected.GetString(GroupKey,"");var root=selected;
            if(selected.GetString(RoleKey,"")=="npc") {var id=selected.GetZDOID(CampKey);if(!id.IsNone()){var linked=ZDOMan.instance.GetZDO(id);if(Owned(linked)&&linked.GetString(GroupKey,"")==group&&linked.GetString(RoleKey,"")=="camp")root=linked;}}
            int count=0;
            foreach(var key in new[]{NpcKey,FireKey,CampCauldron.LinkKey,StrangeCoinItem.LinkKey}){var id=root.GetZDOID(key);if(id.IsNone())continue;var child=ZDOMan.instance.GetZDO(id);if(Owned(child)&&child.GetString(GroupKey,"")==group&&child.GetZDOID(CampKey)==root.m_uid){DestroyOwned(child);count++;}}
            if(Owned(root)){DestroyOwned(root);count++;}Print("Removed "+count+" owned Wayfarer objects. Other campfires and world objects were left alone.");
        }
        internal static bool Owned(ZDO z)
        {
            if(z==null||z.GetString(OwnerKey,"")!=Id||z.GetString(GroupKey,"").Length!=32)return false;
            string role=z.GetString(RoleKey,"");if(role!="camp"&&role!="npc"&&role!="fire"&&role!="cauldron"&&role!="coin")return false;
            int expected=(role=="camp"?CampPrefab:role=="npc"?NpcPrefab:role=="fire"?"fire_pit":role=="cauldron"?CampCauldron.PrefabName:StrangeCoinItem.PrefabName).GetStableHashCode();return z.GetPrefab()==expected;
        }
        static void DestroyOwned(ZDO z)
        {
            if(!Owned(z))return;var obj=ZNetScene.instance.FindInstance(z.m_uid);
            if(obj){var v=obj.GetComponent<ZNetView>();if(v&&!v.IsOwner())v.ClaimOwnership();ZNetScene.instance.Destroy(obj);}
            else ZDOMan.instance.DestroyZDO(z);
        }
        void Status()
        {
            Print("Wayfarer v"+Version+" prefabs="+registered+" data="+(Assets.Ready?"ready":Assets.Loading?"loading":Assets.Failure??"not loaded")+" naturalSpawns=false stock=empty source="+PayloadReader.NativeSha);
            Print("Loaded camps="+CampInstance.Live.Count+" NPCs="+NpcInstance.Live.Count+" layer="+(Assets.Layer<0?"pending":"static_solid")+" game validation=awaiting Jesse");
            Print("Last site clearing: "+lastClearing);
            foreach(var c in CampInstance.Live.Where(x=>x)){var ground=c.GetComponent<CampTerrainSupport>();Print("camp="+(c.View&&c.View.IsValid()?c.View.GetZDO().m_uid.ToString():"invalid")+" ready="+c.Ready+" reversibleGround="+(ground&&ground.HasTerrain)+" groundReady="+(ground&&ground.Ready)+" clearedNature="+(c.View&&c.View.IsValid()?c.View.GetZDO().GetInt("twa_wf_cleared_v3",0):0)+" groundFailure="+(ground?ground.Failure:"")+" bag="+(c.Bag?c.Bag.Initialized.ToString():"pending")+" anchorGap="+(c.Bag?c.Bag.AnchorGapM.ToString("F5"):"pending")+" failure="+c.Failure);}
            foreach(var n in NpcInstance.Live.Where(x=>x))Print("npc="+(n.View&&n.View.IsValid()?n.View.GetZDO().m_uid.ToString():"invalid")+" ready="+n.Ready+" sourceClip="+(n.Pose?n.Pose.Current:"pending")+" failure="+n.Failure);
        }
        void Update(){ApprovedLedgerPanel.Tick();}
        void OnDestroy(){ApprovedLedgerPanel.Close();PrefabManager.OnVanillaPrefabsAvailable-=Register;ZoneManager.OnVanillaLocationsAvailable-=RegisterNaturalCamp;OwnedCampTerrainMarker.Shutdown();patches?.UnpatchSelf();Assets?.Dispose();CampCauldron.Dispose();StrangeCoinItem.Dispose();if(Instance==this)Instance=null;}
    }
    [HarmonyPatch(typeof(ZNetView),"Awake")]
    static class OwnedFireScaleRestore
    {
        static void Prefix(ZNetView __instance)
        {
            // Restore native per-instance scale only for this module's saved
            // fire ZDO. The global installed fire_pit prefab stays unchanged.
            var z=ZNetView.m_initZDO;
            if(z!=null&&z.GetString(WayfarerPlugin.OwnerKey,"")==WayfarerPlugin.Id&&z.GetString(WayfarerPlugin.RoleKey,"")=="fire"&&z.GetPrefab()=="fire_pit".GetStableHashCode())__instance.m_syncInitialScale=true;
        }
        static void Postfix(ZNetView __instance)
        {if(__instance.IsValid()&&WayfarerPlugin.Owned(__instance.GetZDO())&&__instance.GetZDO().GetString(WayfarerPlugin.RoleKey,"")=="fire"&&!__instance.GetComponent<OwnedCampFire>())__instance.gameObject.AddComponent<OwnedCampFire>();}
    }
    [HarmonyPatch(typeof(Trader),"Interact")]
    static class SourceTraderInteraction
    {
        static bool Prefix(Trader __instance,Humanoid character,bool hold,ref bool __result)
        {
            if(!__instance.GetComponent<NpcInstance>()||hold||__instance.m_items!=null&&__instance.m_items.Count>0)return true;
            if(character==Player.m_localPlayer)character.Message(MessageHud.MessageType.Center,"The Wayfarer has nothing for sale yet.");
            __result=true;return false;
        }
        static void Postfix(Trader __instance,bool hold)
        {if(!hold){var own=__instance.GetComponent<NpcInstance>();if(own)own.Gesture("greet");}}
    }
    [HarmonyPatch(typeof(Trader),"OnBought")]
    static class SourceTraderThanks
    {static void Postfix(Trader __instance){var own=__instance.GetComponent<NpcInstance>();if(own)own.Gesture("trade");}}
}
