using System;
using System.IO;
using System.Reflection;
using BepInEx;
using HarmonyLib;
using UnityEngine;

namespace BlackAbbeyDungeonMap
{
    [BepInPlugin(Id,"Black Abbey Parchment Map",Version)]
    [BepInDependency(AbbeyBridge.HelperId,"0.4.71")]
    public sealed class MapPlugin:BaseUnityPlugin
    {
        public const string Id="studio.otherworld.blackabbeydungeonmap",Version="0.2.10";
        internal static MapPlugin Instance;private AbbeyBridge bridge;private Harmony hooks;private DiscoveryStore store;
        private MapState state;private string identity,lastScope,lastFailure;private object observedPlan;private MapUiLease ui;
        private MapPinStore pinStore;private MapPinBook pins;private MapGraveTracker graves;
        private bool pendingRegeneration,retired;private object requestPreviousPlan;private float nextUiRetry,nextStateRetry,nextSaveRetry;
        private int refreshedFrame=-1;internal bool WorldProtection,Inside;private Point playerPoint;private float playerHeading;
        private string StoreRoot=>Path.Combine(Paths.PluginPath,"BlackAbbeyDungeonMap","discovery");
        private void Awake()
        {
            global::Otherworld.Distribution.BundleRuntime.Initialize(this);

            Instance=this;
            try
            {
                bridge=new AbbeyBridge();store=new DiscoveryStore(StoreRoot);hooks=new Harmony(Id);
                pinStore=new MapPinStore(Path.Combine(Paths.PluginPath,"BlackAbbeyDungeonMap","annotations"));
                graves=new MapGraveTracker(s=>Logger.LogWarning(s)){ContainsRunPoint=bridge.ContainsWorldPoint};
                Patch(typeof(Minimap),"Update",nameof(BeforeMapUpdate));
                foreach(string method in new[]{"UpdateExplore","UpdateDynamicPins"})Patch(typeof(Minimap),method,nameof(AllowWorldUpdate));
                foreach(string method in new[]{"UpdateMap","UpdatePins","UpdateBiome","UpdateNameInput","OnMapLeftDown","OnMapLeftUp","OnMapLeftClick","OnMapDblClick","RemovePinUnderPointer","OnPressedPingIcon"})Patch(typeof(Minimap),method,nameof(AllowNativeView));
                var start=AccessTools.Method(bridge.OwnerType,"StartDungeon");var retire=AccessTools.Method(bridge.OwnerType,"RetireCompletedDungeonWhenEmpty");
                if(start==null||retire==null)throw new MissingMethodException("Abbey generation lifecycle contract differs.");
                hooks.Patch(start,prefix:new HarmonyMethod(typeof(MapPlugin),nameof(BeforeStart)));
                hooks.Patch(retire,prefix:new HarmonyMethod(typeof(MapPlugin),nameof(BeforeRetirement)),postfix:new HarmonyMethod(typeof(MapPlugin),nameof(AfterRetirement)));
                Logger.LogInfo("Parchment map ready. Actual source-bound floor shapes; personal room discovery; original world map retained. No dungeon generated or game settings changed.");
            }
            catch(Exception ex){Logger.LogError("Parchment map startup stopped safely: "+ex);Cleanup();enabled=false;}
        }
        private void Patch(Type type,string method,string prefix)
        {
            var target=AccessTools.Method(type,method);if(target==null)throw new MissingMethodException(type.Name,method);
            hooks.Patch(target,prefix:new HarmonyMethod(typeof(MapPlugin),prefix){priority=Priority.First});
        }
        private static void BeforeMapUpdate(){Instance?.Refresh();}
        private static bool AllowWorldUpdate()=>!Instance||!Instance.WorldProtection;
        private static bool AllowNativeView()=>!Instance||!Instance.Inside||Instance.ui==null;
        private static void BeforeStart(bool regenerate)
        {if(!Instance)return;Instance.pendingRegeneration=regenerate;Instance.requestPreviousPlan=Instance.bridge.Plan;}
        private static void BeforeRetirement(out object __state){__state=Instance?Instance.bridge.Plan:null;}
        private static void AfterRetirement(object __state){if(Instance&&__state!=null&&Instance.bridge.Plan==null)Instance.retired=true;}
        private void Refresh()
        {
            if(refreshedFrame==Time.frameCount)return;refreshedFrame=Time.frameCount;
            var player=Player.m_localPlayer;WorldProtection=false;
            try
            {
                if(bridge==null||!bridge.Authorized(player)){Deactivate();return;}
                object plan=bridge.Plan;
                // This authoritative helper check is deliberately independent of
                // rendering: an unavailable UI never writes sky travel to the
                // overworld exploration data. It does not reveal map rooms.
                WorldProtection=bridge.ProtectWorldAt(player);
                if(plan==null){Deactivate();observedPlan=null;state=null;pins=null;graves?.Clear();return;}
                string scope=bridge.World+"/"+player.GetPlayerID();
                if(!ReferenceEquals(plan,observedPlan)||lastScope!=scope)
                {
                    if(bridge.Busy||Time.unscaledTime<nextStateRetry){Deactivate();return;}Save();
                    var layout=bridge.ReadLayout(player);
                    bool newGeneration=retired||(pendingRegeneration&&!ReferenceEquals(plan,requestPreviousPlan));
                    string run=layout.Mode=="natural"?bridge.PersistentRunId:null;
                    if(string.IsNullOrEmpty(run))run=store.LegacyRun(layout.World,layout.Fingerprint,newGeneration);
                    layout.RunId=run;string nextIdentity=layout.World+"|"+layout.Character+"|"+layout.RunId+"|"+layout.Fingerprint;
                    var nextState=new MapState(layout,store.Load(nextIdentity,layout.Fingerprint));identity=nextIdentity;state=nextState;observedPlan=plan;lastScope=scope;
                    pins=null;try{pins=pinStore.Load(nextIdentity,layout.Fingerprint);}catch(Exception ex){Warn(ex);}
                    pendingRegeneration=false;retired=false;
                }
                Vector3 local=player.transform.position-bridge.Origin;playerPoint=new Point(local.x,local.z);playerHeading=player.transform.eulerAngles.y;
                Inside=state!=null&&state.Layout.InScope(playerPoint,local.y);
                if(!Inside){Deactivate();return;}
                graves?.Tick(state.Layout,bridge.Origin,player,!bridge.Busy);
                if(!player.IsDead()&&!bridge.Busy)
                {
                    state.Visit(playerPoint,local.y,player.IsOnGround()&&player.GetVelocity().y>-3);
                    Save();
                }
                if(ui==null&&Minimap.instance&&Time.unscaledTime>=nextUiRetry)
                {
                    try{ui=new MapUiLease(Minimap.instance);lastFailure=null;}
                    catch(Exception ex){Warn(ex);nextUiRetry=Time.unscaledTime+5;}
                }
            }
            catch(Exception ex){Warn(ex);Deactivate();nextUiRetry=nextStateRetry=Time.unscaledTime+5;}
        }
        private void LateUpdate()
        {
            Refresh();if(!Inside||ui==null||state==null)return;
            try{ui.Show(state,playerPoint,playerHeading,pins,graves?.Markers,graves?.Revision??0,PinError);}
            catch(Exception ex){Warn(ex);ui.Dispose();ui=null;nextUiRetry=Time.unscaledTime+5;}
        }
        private void Warn(Exception ex)
        {string message=(ex is TargetInvocationException&&ex.InnerException!=null?ex.InnerException:ex).Message;if(message==lastFailure)return;lastFailure=message;Logger.LogWarning("Parchment map fallback; saved exploration retained: "+message);}
        private void PinError(Exception ex){Warn(ex);if(Player.m_localPlayer)Player.m_localPlayer.Message(MessageHud.MessageType.Center,"Could not save map marker.");}
        private void Save()
        {
            if(state==null||!state.Dirty||identity==null||Time.unscaledTime<nextSaveRetry)return;
            try{store.Save(state.Capture(identity));state.Dirty=false;}
            catch(Exception ex){Warn(ex);nextSaveRetry=Time.unscaledTime+5;}
        }
        private void Deactivate(){Save();Inside=false;ui?.Dispose();ui=null;}
        private void Cleanup(){Deactivate();graves?.Clear();WorldProtection=false;hooks?.UnpatchSelf();hooks=null;if(Instance==this)Instance=null;}
        private void OnDisable(){Cleanup();}
        private void OnDestroy(){Cleanup();}
        private void OnApplicationQuit(){Save();}
    }
}
