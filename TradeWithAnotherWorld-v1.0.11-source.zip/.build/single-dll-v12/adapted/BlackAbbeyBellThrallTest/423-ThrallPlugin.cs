using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using BepInEx;
using HarmonyLib;
using Jotunn.Entities;
using Jotunn.Managers;
using Newtonsoft.Json;
using UnityEngine;
using Object=UnityEngine.Object;
namespace BlackAbbey.BellThrall {
 [BepInPlugin(Id,"Black Abbey Bell Thrall Test",Version)]
 [BepInDependency(Jotunn.Main.ModGuid,"2.30.2")]
 public sealed class ThrallPlugin:BaseUnityPlugin {
  public const string Id="studio.otherworld.bellthralltest",Version="0.4.7",PrefabName="BA_BellThrall";
  GameObject prefab;ThrallVisual visual;bool attempted;
  string Folder=>global::Otherworld.Distribution.BundleRuntime.Data("BlackAbbeyBellThrallTest");
  void Print(string s){Logger.LogInfo(s);if(Console.instance)Console.instance.AddString(s);}
  Harmony patches;
  string startupError,registrationError;
  void Awake(){
            global::Otherworld.Distribution.BundleRuntime.Initialize(this);

   ThrallInstance.Log=Print;
   CommandManager.Instance.AddConsoleCommand(new Cmd("twa_thrall_spawn",true,Spawn));
   CommandManager.Instance.AddConsoleCommand(new Cmd("twa_thrall_remove",true,Remove));
   CommandManager.Instance.AddConsoleCommand(new Cmd("twa_thrall_status",false,Status));
   CommandManager.Instance.AddConsoleCommand(new MotionCmd(this));
   patches=new Harmony(Id+".navigation");
   try{global::Otherworld.Distribution.BundleRuntime.PatchModule(patches,typeof(ThrallPlugin));PrefabManager.OnVanillaPrefabsAvailable+=Register;}
   catch(Exception e){startupError=e.GetBaseException().Message;patches.UnpatchSelf();Logger.LogError("BT_STARTUP_FAILED; Thrall disabled; use twa_thrall_status: "+e);}
  }
  sealed class Cmd:ConsoleCommand {
   readonly string name;readonly bool host;readonly Action action;public Cmd(string n,bool h,Action a){name=n;host=h;action=a;}
   public override string Name=>name;public override string Help=>"Bell Thrall manual test: one-handed hammer, native log Troll AI. Spawn/remove requires local host and devcommands.";public override bool IsCheat=>host;public override bool OnlyServer=>host;public override void Run(string[] args)=>action();
  }
  sealed class MotionCmd:ConsoleCommand {
   readonly ThrallPlugin owner;public MotionCmd(ThrallPlugin owner){this.owner=owner;}
   public override string Name=>"twa_thrall_motion";public override string Help=>"Local host/devcommands: list or play <source id> on nearest owned living Thrall. Context guards remain active; unarmed/manual phrases do no damage.";public override bool IsCheat=>true;public override bool OnlyServer=>true;public override void Run(string[] args)=>owner.Motion(args);
  }
  void Motion(string[] args){
   if(!Host(out var player))return;var bank=ThrallSourceMotion.Bank;if(bank==null){Status();return;}
   if(args.Length==0||args.Length==1&&args[0].Equals("list",StringComparison.OrdinalIgnoreCase)){foreach(var group in bank.Clips.Values.OrderBy(c=>c.id).GroupBy(c=>c.Descriptor.category))Print(group.Key+": "+string.Join(" ",group.Select(c=>c.id)));Print("Use twa_thrall_motion play <id>. Death uses the native death lifecycle; manual phrases without combat approval are nondamaging.");return;}
   if(args.Length!=2||!args[0].Equals("play",StringComparison.OrdinalIgnoreCase)){Print("Use twa_thrall_motion list or twa_thrall_motion play <id>.");return;}
   string id=args[1];if(id.Length==6&&id.All(char.IsDigit))id="a000_"+id;
   if(!bank.Clips.TryGetValue(id,out var clip)){Print("Unknown motion id. Use twa_thrall_motion list.");return;}if(clip.Descriptor.category=="Death"){Print("Death clips run only from an actual native death; this command does not kill or alter health.");return;}
   var nearest=Object.FindObjectsByType<ThrallSourceMotion>(FindObjectsSortMode.None).Where(m=>m&&m.Ready&&m.gameObject.activeInHierarchy).Where(m=>{var h=m.GetComponent<Humanoid>();var v=m.GetComponent<ZNetView>();return h&&!h.IsDead()&&h.GetHealth()>0&&v&&v.IsValid()&&v.IsOwner()&&(m.transform.position-player.transform.position).sqrMagnitude<=2500;}).OrderBy(m=>(m.transform.position-player.transform.position).sqrMagnitude).FirstOrDefault();
   if(!nearest){Print("No owned living Thrall within50metres. Use twa_thrall_spawn first.");return;}
   if(nearest.RequestContext(id))Print("Playing "+id+"; "+(ThrallMotionPolicy.CombatReady(clip.Descriptor)?"approved combat timeline":"nondamaging context preview")+".");else Print("Motion blocked by current action, declared entry state or actual room clearance. Required state="+clip.Descriptor.startState+"; actor="+JsonConvert.SerializeObject(nearest.Snapshot()));
  }
  static GameObject Required(string name){var p=PrefabManager.Instance.GetPrefab(name);if(!p)throw new InvalidOperationException("Required native prefab unavailable:"+name);return p;}
  void Register(){if(attempted||prefab)return;attempted=true;GameObject enemy=null;try {
   string path=Path.Combine(Folder,"thrall-visual.json");ThrallSourceContract.Require(path);ThrallSourceContract.RequireBell(Path.Combine(Folder,"bell-heave.json"));
   ThrallSourceMotion.Bank=ThrallSourceBank.Read(Folder,ThrallSourceBank.CheckedManifestSha256,ThrallSourceContract.PayloadSha256);ThrallSourceMotion.Log=Print;
   ThrallCombat.BellBank=ThrallBellMotion.Read(Path.Combine(Folder,"bell-heave.json"));ThrallCombat.BellVariants=ThrallBellVariants.Read(Folder,ThrallCombat.BellBank);ThrallCombat.Log=Print;
   if(!ThrallEffects.Bell){ThrallEffects.Initialize(Folder,Required("troll_log_swing_h"));var status=ScriptableObject.CreateInstance<SE_ThrallDeafened>();status.name=ThrallEffects.StatusName;status.m_name="Lesser Deafened";status.m_tooltip="Stamina regenerates 25% slower.";status.m_ttl=ThrallCombatPolicy.DeafenSeconds;status.m_icon=ThrallEffects.Icon;if(!ItemManager.Instance.AddStatusEffect(new CustomStatusEffect(status,false)))throw new InvalidOperationException("Thrall deafening status registration failed");}
ThrallEffects.InitializeAdditional(Folder);
var payload=ThrallVisual.Read(path);var source=Required("Troll");var originalAnimator=source.GetComponentInChildren<Animator>(true);if(!originalAnimator||!originalAnimator.avatar||!originalAnimator.avatar.isHuman)throw new InvalidOperationException("Native Troll Humanoid controller unavailable");
   var material=source.GetComponentsInChildren<SkinnedMeshRenderer>(true).SelectMany(r=>r.sharedMaterials).FirstOrDefault(m=>m&&m.HasProperty("_MainTex"));if(!material)throw new InvalidOperationException("Troll material template unavailable");
   enemy=PrefabManager.Instance.CreateClonedPrefab(PrefabName,source);enemy.SetActive(false);var h=enemy.GetComponent<Humanoid>();var ai=enemy.GetComponent<MonsterAI>();if(!h||!ai||!enemy.GetComponent<ZNetView>())throw new InvalidOperationException("Native Troll lifecycle unavailable");
   visual=ReplaceVisual(enemy,payload,material);ThrallSourceMotion.Bank.Bind(visual.Named,payload);ThrallSourceMotion.ReceiveShapes=ThrallReceiveShape.Fit(payload);ThrallCombat.HeadShape=ThrallHeadShape.Fit(payload);ThrallCombat.WeaponShapes=ThrallWeaponShape.Fit(payload);
   ThrallSourceContract.RequireContact(Path.Combine(Folder,"hammer-contact.json"));var contact=ThrallContactProfile.Read(Path.Combine(Folder,"hammer-contact.json"));if(contact.visualSha256!=ThrallVisual.Hash(path)||contact.attacks?.Length!=2)throw new InvalidOperationException("Hammer contact profile source differs");foreach(var row in contact.attacks)ThrallCombat.MeasuredRanges[row.token]=ThrallSizePolicy.World(Mathf.Clamp(row.frontReach-.35f,1.8f,6f));
   Print("BT_COMBAT_READY speed="+ThrallCombatPolicy.AttackSpeed+" recovery="+ThrallCombatPolicy.Recovery+" bellRange="+ThrallCombatPolicy.BellRange+" swishClips="+ThrallEffects.Swishes.Length+" headVertices="+ThrallCombat.HeadShape.headVertices);

   float sourceRatio=visual.Animator.humanScale/originalAnimator.humanScale;if(sourceRatio<.6f||sourceRatio>1.2f)throw new InvalidOperationException("Unexpected source Thrall dimensions");
   float ratio=sourceRatio*ThrallSizePolicy.Multiplier;visual.Root.localScale*=ThrallSizePolicy.Multiplier;
   var horizontal=Weapon("BA_BellThrall_LogH","troll_log_swing_h",ratio);var vertical=Weapon("BA_BellThrall_LogV","troll_log_swing_v",ratio);
   var hitPresentation=ThrallHitPresentation.Apply(source.GetComponent<Humanoid>(),h,Print);
   h.m_staggerDamageFactor=ThrallReactionPolicy.StaggerHealthFraction;
   h.m_name="Bell Thrall";h.m_group="BlackAbbeyBellThrall";h.m_boss=false;h.m_bossEvent="";h.m_defeatSetGlobalKey="";
   h.m_defaultItems=new[]{horizontal.ItemPrefab,vertical.ItemPrefab};h.m_unarmedWeapon=horizontal.ItemDrop;h.m_randomWeapon=Array.Empty<GameObject>();h.m_randomShield=Array.Empty<GameObject>();h.m_randomArmor=Array.Empty<GameObject>();h.m_randomItems=Array.Empty<Humanoid.RandomItem>();h.m_randomSets=Array.Empty<Humanoid.ItemSet>();
   ai.m_sleeping=false;ai.m_fallAsleepDistance=0;
   foreach(var c in enemy.GetComponentsInChildren<Collider>(true)){
    if(c.transform.IsChildOf(visual.Root))continue;
    if(c is CapsuleCollider cap){cap.center*=ratio;cap.radius*=ratio;cap.height*=ratio;}
    else if(c is BoxCollider box){box.center*=ratio;box.size*=ratio;}
    else if(c is SphereCollider sphere){sphere.center*=ratio;sphere.radius*=ratio;}
    if(c.transform!=enemy.transform)c.transform.localPosition*=ratio;
   }
   var body=enemy.GetComponent<CapsuleCollider>();if(!body)throw new InvalidOperationException("Native character capsule missing");ThrallPhysicalProfile.Configure(body);
   h.m_eye=visual.Named["Head"];
   // Deleted vanilla weak spots cannot remain in a native melee damage scan.
   var nativeHead=source.GetComponent<Character>().m_weakSpots?.FirstOrDefault(w=>w);
   var headCollider=ThrallPhysicalProfile.Head(visual.Named["Head"],enemy.layer);
   var headWeak=headCollider.gameObject.AddComponent<WeakSpot>();headWeak.m_collider=headCollider;
   headWeak.m_damageModifiers=nativeHead?nativeHead.m_damageModifiers.Clone():h.m_damageModifiers.Clone();h.m_weakSpots=new[]{headWeak};
   if(h.m_weakSpots.Any(w=>!w||!w.m_collider||!w.transform.IsChildOf(enemy.transform)))throw new InvalidOperationException("Invalid own weak-spot binding");
   h.m_deathEffects=new EffectList{m_effectPrefabs=(h.m_deathEffects?.m_effectPrefabs??Array.Empty<EffectList.EffectData>()).Where(e=>e?.m_prefab&&!e.m_prefab.GetComponentInChildren<Ragdoll>(true)&&!e.m_prefab.GetComponentInChildren<Renderer>(true)).ToArray()};var drops=enemy.GetComponent<CharacterDrop>();if(drops)drops.m_drops=new List<CharacterDrop.Drop>();
   var audit=AuditAI(ai,source.GetComponent<MonsterAI>());if(!audit.passed)throw new InvalidOperationException("Unexpected change to Troll AI fields");
   ThrallNativeVoice.Prepare(source,enemy);enemy.AddComponent<ThrallInstance>();enemy.AddComponent<ThrallCombat>();enemy.AddComponent<ThrallSourceMotion>();enemy.AddComponent<ThrallTactics>();enemy.AddComponent<ThrallAudio>();PrefabManager.Instance.AddPrefab(new CustomPrefab(enemy,false));if(!enemy.transform.parent||enemy.transform.parent.gameObject.activeInHierarchy)throw new InvalidOperationException("Registered Thrall prefab must be under inactive Jotunn container");prefab=enemy;prefab.SetActive(true);PrefabManager.OnVanillaPrefabsAvailable-=Register;
   var evidence=Path.Combine(BepInEx.Paths.PluginPath,"BlackAbbeyBellThrallTest","evidence");Directory.CreateDirectory(evidence);File.WriteAllText(Path.Combine(evidence,"registration.json"),JsonConvert.SerializeObject(new{version=Version,source="Troll",controller=visual.Animator.runtimeAnimatorController.name,mainHand="Right",offhand="Free",payloadSha256=ThrallVisual.Hash(path),nativeSha256=payload.sourceNative.sha256,ai=audit,hitPresentation,dimensionRatio=ratio,health=h.m_health,staggerHealthFraction=h.m_staggerDamageFactor,horizontal=horizontal.ItemDrop.m_itemData.m_shared.m_attack.m_attackAnimation,vertical=vertical.ItemDrop.m_itemData.m_shared.m_attack.m_attackAnimation,throwing=false,punching=false,naturalSpawns=false,scope="Registration evidence only; actual combat and appearance await Jesse."},Formatting.Indented));Print("Bell Thrall ready: right-hand hammer, native log Troll AI. Use twa_thrall_spawn.");
  }catch(Exception e){registrationError=e.GetBaseException().Message;if(enemy)Object.Destroy(enemy);prefab=null;visual?.Dispose();visual=null;Logger.LogError("BT_REGISTRATION_FAILED; no substitute actor: "+e);}}
  CustomItem Weapon(string name,string source,float ratio){
   var original=Required(source).GetComponent<ItemDrop>().m_itemData;var item=new CustomItem(name,source);item.ItemDrop.m_itemData=original.Clone();var data=item.ItemDrop.m_itemData;data.m_dropPrefab=item.ItemPrefab;data.m_shared=(ItemDrop.ItemData.SharedData)typeof(object).GetMethod("MemberwiseClone",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(original.m_shared,null);var s=data.m_shared;s.m_name="Bell Thrall Hammer";s.m_useDurability=false;s.m_attack=original.m_shared.m_attack.Clone();s.m_secondaryAttack=original.m_shared.m_secondaryAttack?.Clone();
   s.m_attack.m_attackRayWidth*=ratio;s.m_attack.m_attackRange*=ratio;s.m_attack.m_attackHeight*=ratio;s.m_attack.m_attackOffset*=ratio;s.m_aiAttackRange*=ratio;
   if(s.m_secondaryAttack!=null){s.m_secondaryAttack.m_attackRayWidth*=ratio;s.m_secondaryAttack.m_attackRange*=ratio;s.m_secondaryAttack.m_attackHeight*=ratio;s.m_secondaryAttack.m_attackOffset*=ratio;}
   s.m_aiAttackInterval=Mathf.Max(2.8f,s.m_aiAttackInterval*1.6f);s.m_attack.m_attackChainLevels=1;
   if(ThrallCombat.MeasuredRanges.TryGetValue(s.m_attack.m_attackAnimation,out var reach)){s.m_aiAttackRange=reach;s.m_attack.m_attackRange=reach;}
   s.m_startEffect=new EffectList();s.m_trailStartEffect=new EffectList();s.m_attack.m_startEffect=new EffectList();s.m_attack.m_triggerEffect=new EffectList();s.m_attack.m_trailStartEffect=new EffectList();s.m_attack.m_spawnOnTrigger=null;s.m_attack.m_spawnOnHit=null;
   foreach(var renderer in item.ItemPrefab.GetComponentsInChildren<Renderer>(true))renderer.enabled=false;
   foreach(var behaviour in item.ItemPrefab.GetComponentsInChildren<MonoBehaviour>(true))if(behaviour&&behaviour.GetType().Name.IndexOf("Trail",StringComparison.OrdinalIgnoreCase)>=0)behaviour.enabled=false;

   if(!ItemManager.Instance.AddItem(item))throw new InvalidOperationException("Own log attack item failed:"+name);return item;
  }
  ThrallVisual ReplaceVisual(GameObject enemy,ThrallPayload payload,Material material){
   var root=enemy.transform.Find("Visual");if(!root)throw new InvalidOperationException("Native Troll Visual root missing");var old=root.GetComponentInChildren<Animator>(true);var controller=old.runtimeAnimatorController;var evt=old.GetComponent<CharacterAnimEvent>();if(!evt)throw new InvalidOperationException("Native animation event component missing");string events=JsonUtility.ToJson(evt);var names=evt.m_feets?.Select(f=>f.m_transform?f.m_transform.name:null).ToArray();var foot=enemy.GetComponentsInChildren<FootStep>(true).FirstOrDefault();string footsteps=foot?JsonUtility.ToJson(foot):null;
   root.gameObject.SetActive(false);foreach(Transform child in root.Cast<Transform>().ToArray())Object.DestroyImmediate(child.gameObject);foreach(var lod in root.GetComponents<LODGroup>())Object.DestroyImmediate(lod);foreach(var renderer in root.GetComponents<Renderer>())Object.DestroyImmediate(renderer);
   var result=ThrallVisual.Build(root,payload,material,Folder,false);result.Animator.runtimeAnimatorController=controller;JsonUtility.FromJsonOverwrite(events,evt);evt.m_lookAt=result.Named["Head"];evt.m_eyes=new[]{result.Named["Head"]};evt.m_leftShoulder=result.Named["LeftShoulder"];evt.m_rightShoulder=result.Named["RightShoulder"];AccessTools.Field(typeof(CharacterAnimEvent),"m_head").SetValue(evt,result.Named["Head"]);if(!evt.m_loopAudioSource)evt.m_loopAudioSource=null;
   if(evt.m_feets!=null)for(int i=0;i<evt.m_feets.Length;i++){string n=names[i]??"";string mapped=n.IndexOf("left",StringComparison.OrdinalIgnoreCase)>=0?"LeftFoot":n.IndexOf("right",StringComparison.OrdinalIgnoreCase)>=0?"RightFoot":null;if(mapped==null)throw new InvalidOperationException("Unrecognized Troll foot:"+n);evt.m_feets[i].m_transform=result.Named[mapped];}
   if(footsteps!=null){var step=enemy.GetComponentsInChildren<FootStep>(true).FirstOrDefault()??root.gameObject.AddComponent<FootStep>();JsonUtility.FromJsonOverwrite(footsteps,step);step.m_feet=new[]{result.Named["LeftFoot"],result.Named["RightFoot"]};}
   var v=enemy.GetComponent<VisEquipment>();if(!v)throw new InvalidOperationException("Native Troll equipment missing");v.m_bodyModel=result.Skins[0];v.m_rightHand=result.Named["RightHand"];v.m_leftHand=result.Named["LeftHand"];v.m_models=Array.Empty<VisEquipment.PlayerModel>();v.m_randomModelIndex=false;v.m_npcBeardChance=0;v.m_npcHairChance=0;v.m_helmet=result.Named["Head"];v.m_backMelee=v.m_backShield=v.m_backBow=v.m_backTool=v.m_backTwohandedMelee=v.m_backAtgeir=result.Named["Spine2"];root.gameObject.SetActive(true);return result;
  }
  public sealed class AIAudit {public bool passed;public string[] comparedFields;}
  static AIAudit AuditAI(MonsterAI own,MonsterAI source){var fields=typeof(MonsterAI).GetFields(BindingFlags.Public|BindingFlags.Instance).Where(f=>(f.FieldType.IsPrimitive||f.FieldType.IsEnum)&&f.Name!="m_sleeping"&&f.Name!="m_fallAsleepDistance").ToArray();return new AIAudit{passed=fields.All(f=>Equals(f.GetValue(own),f.GetValue(source))),comparedFields=fields.Select(f=>f.Name).ToArray()};}
  bool Host(out Player p){p=Player.m_localPlayer;if(!p||!ZNet.instance||!ZNet.instance.IsServer()||!ZNetScene.instance||!prefab){Print("Use as local host after Bell Thrall registration; see twa_thrall_status.");return false;}return true;}
  void Status(){if(!string.IsNullOrEmpty(startupError))Print("BT_STARTUP_FAILED: "+startupError);if(!string.IsNullOrEmpty(registrationError))Print("BT_REGISTRATION_FAILED: "+registrationError);Print("BT_STATUS version="+Version+" ready="+(prefab!=null)+" source=Troll weapons=log_h,log_v scaleFromPrevious=0.75 hand=Right gripFromButt=0.12 naturalSpawns=false sourceMotionClips="+(ThrallSourceMotion.Bank?.Clips.Count??0)+" contactReady="+(ThrallSourceMotion.Bank?.Clips.Values.Count(c=>ThrallMotionPolicy.CombatReady(c.Descriptor))??0));foreach(var actor in Object.FindObjectsByType<ThrallInstance>(FindObjectsSortMode.None))if(actor&&actor.gameObject.activeInHierarchy)Print(actor.Status());}
  void Spawn(){if(!Host(out var p))return;if(Object.FindObjectsByType<ThrallInstance>(FindObjectsSortMode.None).Count(t=>t.gameObject.activeInHierarchy)>=3){Print("Remove existing test Thralls first.");return;}var f=Vector3.ProjectOnPlane(p.transform.forward,Vector3.up).normalized;var at=p.transform.position+f*8;if(!Physics.Raycast(at+Vector3.up*2,Vector3.down,out var hit,5,LayerMask.GetMask("terrain","static_solid","piece"))||hit.normal.y<.85f){Print("Find flat ground eight metres ahead.");return;}at.y=hit.point.y+.05f;Object.Instantiate(prefab,at,Quaternion.LookRotation(-f)).SetActive(true);Print("Spawned hostile Bell Thrall. Remove with twa_thrall_remove.");}
  void Remove(){if(!Host(out var p))return;int n=0;foreach(var t in Object.FindObjectsByType<ThrallInstance>(FindObjectsSortMode.None)){if(!t.gameObject.activeInHierarchy||(t.transform.position-p.transform.position).sqrMagnitude>10000)continue;var v=t.GetComponent<ZNetView>();if(!v||!v.IsValid()||!v.IsOwner())continue;ZNetScene.instance.Destroy(t.gameObject);n++;}Print("Removed "+n+" nearby owned Bell Thrall test actors.");}
  void OnDestroy(){PrefabManager.OnVanillaPrefabsAvailable-=Register;ThrallDungeonNavigation.Shutdown();ThrallSourceMotion.Shutdown();ThrallAudio.Shutdown();ThrallNativeVoice.Shutdown();ThrallHitPresentation.Shutdown();ThrallEffects.Shutdown();patches?.UnpatchSelf();visual?.Dispose();}
 }
 public sealed class ThrallInstance:MonoBehaviour {
  public float damageReceived;public static Action<string> Log;
  void Start(){var h=GetComponent<Humanoid>();var view=GetComponent<ZNetView>();if(!h||!view||!view.IsValid())return;h.m_onDamaged+=Damaged;ThrallDungeonNavigation.Attach(gameObject,Log);}
  void Damaged(float amount,Character attacker){damageReceived+=amount;Log?.Invoke("BT_DAMAGE_RECEIVED amount="+amount+" total="+damageReceived);}
  public string Status(){var h=GetComponent<Humanoid>();var view=GetComponent<ZNetView>();var nav=GetComponent<ThrallDungeonNavigation>();var events=GetComponentInChildren<CharacterAnimEvent>();return "BT_ACTOR "+(GetComponent<ThrallCombat>()?.Diagnostics()??"")+JsonConvert.SerializeObject(new{hp=h?h.GetHealth():-1,staggerThreshold=h?h.GetMaxHealth()*h.m_staggerDamageFactor:0,damageReceived,owner=view&&view.IsValid()&&view.IsOwner(),liveWeakSpots=h&&h.m_weakSpots!=null&&h.m_weakSpots.All(w=>w&&w.m_collider),liveEyes=events&&events.m_eyes!=null&&events.m_eyes.All(t=>t),navigation=nav?nav.Snapshot():null});}
 }
}
