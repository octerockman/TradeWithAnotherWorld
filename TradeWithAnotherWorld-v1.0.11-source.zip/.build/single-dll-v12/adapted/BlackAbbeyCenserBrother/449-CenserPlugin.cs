using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using BepInEx;
using Jotunn.Entities;
using Jotunn.Managers;
using Newtonsoft.Json;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbey.CenserBrother
{
    [BepInPlugin(Id,"Black Abbey The Profaned",Version)]
    [BepInDependency(Jotunn.Main.ModGuid,"2.30.2")]
    public sealed class CenserPlugin:BaseUnityPlugin
    {
        public const string Id="studio.otherworld.censerbrother",Version="0.3.9",PrefabName="BA_CenserBrother",EmberName="BA_CenserBrother_Ember";
        public static CenserSettings Settings;public static GameObject EmberPrefab;
        CenserVisual visual;GameObject prefab;bool attempted;
        string Folder=>global::Otherworld.Distribution.BundleRuntime.Data("BlackAbbeyCenserBrother");
        static Action<string> trace;public static void Trace(string s)=>trace?.Invoke(s);
        void Log(string s)=>Logger.LogInfo(s);
        void Print(string s){Log(s);if(Console.instance)Console.instance.AddString(s);}
        void Awake(){
            global::Otherworld.Distribution.BundleRuntime.Initialize(this);
trace=Log;Settings=new CenserSettings(Config);PrefabManager.OnVanillaPrefabsAvailable+=Register;CommandManager.Instance.AddConsoleCommand(new Command("twa_censer_spawn",true,Spawn));CommandManager.Instance.AddConsoleCommand(new Command("twa_censer_remove",true,Remove));CommandManager.Instance.AddConsoleCommand(new Command("twa_censer_status",false,Status));Log("CB_PLUGIN_READY version="+Version+" manualOnly=true");}
        sealed class Command:ConsoleCommand
        {
            readonly string name;readonly bool host;readonly Action run;
            internal Command(string n,bool h,Action r){name=n;host=h;run=r;}
            public override string Name=>name;public override string Help=>name=="twa_censer_spawn"?"Spawn The Profaned six metres ahead; own slow movement, censer physics, smoke and ember attacks.":name=="twa_censer_remove"?"Remove nearby owned Profaned test actors.":"Report The Profaned source and readiness.";
            public override bool IsCheat=>host;public override bool OnlyServer=>host;public override void Run(string[] args)=>run();
        }
        static GameObject Required(string name){var p=PrefabManager.Instance.GetPrefab(name);if(!p)throw new InvalidOperationException("Required native prefab absent:"+name);return p;}
        void Register()
        {
            if(attempted||prefab)return;attempted=true;GameObject actor=null;
            try{
                string manifest=Path.Combine(Folder,"censer-visual.json");var payload=CenserVisual.Read(manifest);var motionPath=Path.Combine(Folder,"censer-motion.json");
                if(CenserVisual.Hash(manifest)!=CenserSourceHashes.Visual||CenserVisual.Hash(motionPath)!=CenserSourceHashes.Motion)throw new InvalidDataException("Censer authored payload hash mismatch");
                var bank=JsonConvert.DeserializeObject<MotionBank>(File.ReadAllText(motionPath));ValidateMotion(bank,payload);CenserInstance.Bank=bank;
                var source=Required("Skeleton");var nativeMaterial=source.GetComponent<VisEquipment>()?.m_bodyModel?.sharedMaterial;if(!nativeMaterial)throw new InvalidOperationException("Native Creature material missing");
                actor=PrefabManager.Instance.CreateClonedPrefab(PrefabName,source);actor.SetActive(false);if(actor.activeInHierarchy)throw new InvalidOperationException("Author prefabs inactive");
                var h=actor.GetComponent<Humanoid>();var nativeAI=actor.GetComponent<MonsterAI>();if(!h||!nativeAI)throw new InvalidOperationException("Native humanoid lifecycle missing");string aiJson=JsonUtility.ToJson(nativeAI);Object.DestroyImmediate(nativeAI);
                visual=ReplaceVisual(actor,payload,nativeMaterial);
                h.m_name="The Profaned";h.m_group="BlackAbbeyCenserBrother";h.m_boss=false;h.m_bossEvent="";h.m_defeatSetGlobalKey="";h.m_health=Settings.Health.Value;h.m_walkSpeed=Settings.Walk.Value;h.m_runSpeed=Settings.CombatWalk.Value;h.m_acceleration=1.4f;h.m_turnSpeed=100;h.m_runTurnSpeed=100;
                h.m_defaultItems=Array.Empty<GameObject>();h.m_randomWeapon=Array.Empty<GameObject>();h.m_randomShield=Array.Empty<GameObject>();h.m_randomArmor=Array.Empty<GameObject>();h.m_randomItems=Array.Empty<Humanoid.RandomItem>();h.m_randomSets=Array.Empty<Humanoid.ItemSet>();h.m_unarmedWeapon=null;
                h.m_deathEffects=new EffectList{m_effectPrefabs=(h.m_deathEffects?.m_effectPrefabs??Array.Empty<EffectList.EffectData>()).Where(e=>e?.m_prefab&&!e.m_prefab.GetComponentInChildren<Ragdoll>(true)&&!e.m_prefab.GetComponentInChildren<SkinnedMeshRenderer>(true)&&!e.m_prefab.GetComponentInChildren<MeshRenderer>(true)).ToArray()};
                var drops=actor.GetComponent<CharacterDrop>();if(drops)drops.m_drops=new List<CharacterDrop.Drop>();
                var cap=actor.GetComponent<CapsuleCollider>();cap.height=1.90f;cap.radius=.27f;cap.center=new Vector3(0,.95f,0);
                var eye=new GameObject("CB_Eye").transform;eye.SetParent(actor.transform,false);eye.localPosition=new Vector3(0,1.72f,.03f);h.m_eye=eye;
                var own=actor.AddComponent<CenserInstance>();own.payloadSha256=CenserVisual.Hash(manifest);
                var ai=actor.AddComponent<CenserAI>();JsonUtility.FromJsonOverwrite(aiJson,ai);ai.m_viewRange=18;ai.m_viewAngle=240;ai.m_hearRange=12;ai.m_smoothMovement=true;ai.m_moveMinAngle=180;
                // Constant particles use the actual installed smoke shader, with own
                // soft texture and bounded counts. No third-party audio is reused.
                var grey=Required("Greyling").GetComponent<Character>();var smoke=grey.m_deathEffects.m_effectPrefabs.Where(e=>e?.m_prefab).SelectMany(e=>e.m_prefab.GetComponentsInChildren<ParticleSystemRenderer>(true)).Where(r=>r.sharedMaterial&&r.sharedMaterial.shader&&r.sharedMaterial.shader.isSupported).OrderByDescending(r=>r.name.IndexOf("smoke",StringComparison.OrdinalIgnoreCase)>=0||r.sharedMaterial.name.IndexOf("smoke",StringComparison.OrdinalIgnoreCase)>=0).Select(r=>r.sharedMaterial).FirstOrDefault();if(!smoke)throw new InvalidOperationException("Native Greyling smoke unavailable");
                CenserEffects.Initialize(smoke);Trace("CB2_FX_READY shader="+CenserParticleFactory.SourceShader+" texture="+CenserParticleFactory.SourceTexture);
                var blood=ProfanedBloodEffects.BuildPrefab(actor.transform.parent);
                h.m_hitEffects=ProfanedBloodEffects.ReplaceVisuals(h.m_hitEffects,blood);
                h.m_critHitEffects=ProfanedBloodEffects.ReplaceVisuals(h.m_critHitEffects,blood);
                h.m_backstabHitEffects=ProfanedBloodEffects.ReplaceVisuals(h.m_backstabHitEffects,blood);
                var se=ScriptableObject.CreateInstance<SE_CenserChoking>();se.name=CenserEffects.StatusName;se.m_name="Choking Incense";se.m_tooltip="Thick incense briefly steals your breath.";se.m_ttl=Settings.ChokeDuration.Value;se.m_icon=CenserEffects.StatusIcon;
                if(ObjectDB.instance){var smokeSE=ObjectDB.instance.GetStatusEffect("Smoke".GetStableHashCode());if(smokeSE)se.m_icon=smokeSE.m_icon;}
                if(!ItemManager.Instance.AddStatusEffect(new CustomStatusEffect(se,false)))throw new InvalidOperationException("Own choking status registration failed");
                var rockSource=Required("Greydwarf_throw_projectile");EmberPrefab=PrefabManager.Instance.CreateClonedPrefab(EmberName,rockSource);EmberPrefab.SetActive(false);
                foreach(Transform c in EmberPrefab.transform.Cast<Transform>().ToArray())Object.DestroyImmediate(c.gameObject);
                var projectile=EmberPrefab.GetComponent<Projectile>();if(!projectile)throw new InvalidOperationException("Native projectile lifecycle missing");projectile.m_aoe=0;projectile.m_rayRadius=.12f;projectile.m_gravity=.6f;projectile.m_ttl=5;projectile.m_statusEffect="";projectile.m_spawnOnHit=null;projectile.m_randomSpawnOnHit=new List<GameObject>();projectile.m_spawnOnTtl=false;projectile.m_respawnItemOnHit=false;projectile.m_onlySpawnedProjectilesDealDamage=false;projectile.m_noDamageFriendly=true;projectile.m_dodgeable=true;projectile.m_blockable=true;
                var impact=new GameObject("CB2_Ash_And_Embers_Impact");impact.transform.SetParent(actor.transform.parent,false);impact.SetActive(false);impact.AddComponent<CenserAshImpact>();impact.SetActive(true);
                var impactEffects=new EffectList{m_effectPrefabs=new[]{new EffectList.EffectData{m_prefab=impact,m_enabled=true}}};projectile.m_hitEffects=impactEffects;projectile.m_hitWaterEffects=impactEffects;projectile.m_spawnOnHitEffects=new EffectList();
                CenserEffects.ProjectileVisual(EmberPrefab,rockSource);Trace("CB5_ROCK_MATERIAL_READY shader="+CenserRockFactory.SourceShader+" source="+CenserRockFactory.SourceMaterial);PrefabManager.Instance.AddPrefab(new CustomPrefab(EmberPrefab,false));EmberPrefab.SetActive(true);
                PrefabManager.Instance.AddPrefab(new CustomPrefab(actor,false));prefab=actor;if(!actor.transform.parent||actor.transform.parent.gameObject.activeInHierarchy)throw new InvalidOperationException("Actor prefab must remain under inactive container");actor.SetActive(true);PrefabManager.OnVanillaPrefabsAvailable-=Register;
                string evidence=Path.Combine(BepInEx.Paths.PluginPath,"BlackAbbeyCenserBrother","evidence");Directory.CreateDirectory(evidence);File.WriteAllText(Path.Combine(evidence,"registration.json"),JsonConvert.SerializeObject(new{version=Version,prefab=PrefabName,visual=CenserSourceHashes.Visual,motion=CenserSourceHashes.Motion,native=payload.sourceNative.sha256,avatarValid=visual.Avatar.isValid,avatarHuman=visual.Avatar.isHuman,bodyTriangles=payload.bodyTriangles,totalTriangles=payload.totalTriangles,ownAnimationClips=bank.clips.Select(c=>c.name).ToArray(),manualSpawnOnly=true,vanillaAnimationsShipped=false},Formatting.Indented));
                Print("The Profaned ready. Use twa_censer_spawn; remove with twa_censer_remove.");
            }catch(Exception ex){if(actor)Object.Destroy(actor);prefab=null;visual?.Dispose();visual=null;Logger.LogError("CB_REGISTRATION_FAILED no substitute actor: "+ex);Print("The Profaned setup failed; see LogOutput.log.");}
        }
        public static void ValidateMotion(MotionBank bank,CenserPayload p)
        {
            if(bank?.schema!="censer-brother.motion.v1"||bank.containsVanillaClips||bank.boneNames?.Length!=55||bank.clips?.Length!=9||bank.sourceNative?.sha256!=p.sourceNative.sha256||bank.boneNames.Distinct().Count()!=55||bank.boneNames.Any(n=>!p.nodes.Any(x=>x.name==n)))throw new InvalidDataException("Own motion contract mismatch");
            foreach(var c in bank.clips){if(c.duration<=0||c.frames?.Length<2)throw new InvalidDataException("Empty own motion");foreach(var f in c.frames){if(f.positions?.Length!=bank.boneNames.Length*3||f.rotations?.Length!=bank.boneNames.Length*4||f.positions.Concat(f.rotations).Any(v=>float.IsNaN(v)||float.IsInfinity(v)))throw new InvalidDataException("Invalid pose arrays");}}
        }
        CenserVisual ReplaceVisual(GameObject enemy,CenserPayload p,Material template)
        {
            var root=enemy.transform.Find("Visual");if(!root)throw new InvalidOperationException("Native Visual missing");var animator=root.GetComponentsInChildren<Animator>(true).Single();var controller=animator.runtimeAnimatorController;
            var sourceEvents=animator.GetComponent<CharacterAnimEvent>();if(!sourceEvents)throw new InvalidOperationException("Native animation event interface missing");string eventJson=JsonUtility.ToJson(sourceEvents);
            var foot=enemy.GetComponentsInChildren<FootStep>(true).FirstOrDefault();string footJson=foot?JsonUtility.ToJson(foot):null;
            root.gameObject.SetActive(false);foreach(Transform c in root.Cast<Transform>().ToArray())Object.DestroyImmediate(c.gameObject);foreach(var lod in root.GetComponents<LODGroup>())Object.DestroyImmediate(lod);foreach(var r in root.GetComponents<Renderer>())Object.DestroyImmediate(r);
            var result=CenserVisual.Build(root,p,template,Folder,false);result.Animator.runtimeAnimatorController=controller;result.Animator.enabled=false;
            // Character still retains its native lifecycle/controller interfaces;
            // all visible motion is our exported local-pose bank in LateUpdate.
            var evt=root.GetComponent<CharacterAnimEvent>()??root.gameObject.AddComponent<CharacterAnimEvent>();JsonUtility.FromJsonOverwrite(eventJson,evt);evt.m_lookAt=result.Named["Head"];evt.m_leftShoulder=result.Named["LeftShoulder"];evt.m_rightShoulder=result.Named["RightShoulder"];evt.m_loopAudioSource=null;if(evt.m_feets!=null)for(int i=0;i<evt.m_feets.Length;i++)evt.m_feets[i].m_transform=result.Named[i==0?"LeftFoot":"RightFoot"];evt.enabled=false;
            if(footJson!=null){var step=enemy.GetComponentsInChildren<FootStep>(true).FirstOrDefault()??root.gameObject.AddComponent<FootStep>();JsonUtility.FromJsonOverwrite(footJson,step);step.m_feet=new[]{result.Named["LeftFoot"],result.Named["RightFoot"]};}
            var eq=enemy.GetComponent<VisEquipment>();eq.m_bodyModel=result.Skins[0];eq.m_rightHand=result.Named["RightHand_Attach"];eq.m_leftHand=result.Named["LeftHand_Attach"];eq.m_randomModelIndex=false;eq.m_models=Array.Empty<VisEquipment.PlayerModel>();eq.m_npcBeardChance=0;eq.m_npcHairChance=0;eq.m_helmet=result.Named["Head"];eq.m_backMelee=eq.m_backShield=eq.m_backBow=eq.m_backTool=eq.m_backTwohandedMelee=eq.m_backAtgeir=result.Named["Spine2"];
            root.gameObject.SetActive(true);return result;
        }
        bool Host(out Player p){p=Player.m_localPlayer;if(!p||!ZNet.instance||!ZNet.instance.IsServer()||!ZNetScene.instance){Print("Use as local host with a loaded character.");return false;}if(!prefab){Print("The Profaned prefab is not ready; see twa_censer_status.");return false;}return true;}
        void Spawn(){if(!Host(out var p))return;if(Object.FindObjectsByType<CenserInstance>(FindObjectsSortMode.None).Count(g=>g&&g.gameObject.activeInHierarchy)>=3){Print("Three test The Profaneds already present.");return;}var f=Vector3.ProjectOnPlane(p.transform.forward,Vector3.up).normalized;var at=p.transform.position+f*6;if(!Physics.Raycast(at+Vector3.up*2,Vector3.down,out var hit,5,CenserAI.SolidMask,QueryTriggerInteraction.Ignore)||hit.normal.y<.85f){Print("Find flat ground or floor six metres ahead.");return;}at.y=hit.point.y+.05f;var actor=Object.Instantiate(prefab,at,Quaternion.LookRotation(-f));actor.SetActive(true);Print("Spawned The Profaned. Test slow approach, low smoke sweep, fist up close, ember at distance.");}
        void Remove(){if(!Host(out var p))return;int count=0;foreach(var g in Object.FindObjectsByType<CenserInstance>(FindObjectsSortMode.None)){if(!g||!g.gameObject.activeInHierarchy||(g.transform.position-p.transform.position).sqrMagnitude>10000)continue;var v=g.GetComponent<ZNetView>();if(v&&v.IsValid()&&v.IsOwner()){ZNetScene.instance.Destroy(g.gameObject);count++;}}Print("Removed "+count+" nearby The Profaneds.");}
        void Status(){Print("CB_STATUS version="+Version+" ready="+(prefab!=null)+" manualOnly=true");foreach(var g in Object.FindObjectsByType<CenserInstance>(FindObjectsSortMode.None))if(g&&g.gameObject.activeInHierarchy)Print(g.Status());}
        void OnDestroy(){PrefabManager.OnVanillaPrefabsAvailable-=Register;CenserDungeonNavigation.Shutdown();ProfanedBloodEffects.Shutdown();CenserEffects.Shutdown();visual?.Dispose();}
    }
}
