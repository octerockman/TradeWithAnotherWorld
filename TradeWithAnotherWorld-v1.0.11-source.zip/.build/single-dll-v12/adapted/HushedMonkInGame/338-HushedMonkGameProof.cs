using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbey.HushedMonk
{
    // Invoked only by the explicit localhost proof command. Never runs on load.
    public static class HushedMonkGameProof
    {
        const string NativeSha = "3e0b6a9e3fa25056b4d6c522317f208e9657c3a10dd8fdd3728474e4ee02de0e";
        static RunContext active;
        public static bool Busy => active != null;

        sealed class RunContext
        {
            public MonoBehaviour Host;
            public GameObject Prefab, Actor;
            public Player Player;
            public Humanoid Character;
            public MonsterAI AI;
            public Animator Animator;
            public WristBellPhysics Bell;
            public MonkAudioProofProbe AudioProbe;
            public MonkV4ProofProbe FeatureProbe;
            public MonkCordProofProbe CordProbe;
            public Rigidbody BellBody, BellAnchor;
            public HushedMonkProofAttackListener Listener;
            public Coroutine Coroutine;
            public Action<string> Log;
            public string Directory, Id;
            public float Started;
            public bool DeathObserved, DamageObserved, Aborted, CleanupRequested, ActorSpawned, BellBodiesCreated;
            public int NaturalHitDamageEvents;
            public float NaturalHitDamage;
            public Action<float, Character> PlayerDamageListener;
            public int FrameStarted;
            public readonly List<object> Checks = new List<object>();
            public readonly List<object> Samples = new List<object>();
            public readonly List<bool> Results = new List<bool>();
            public readonly Dictionary<string, object> Details = new Dictionary<string, object>();
            public void Check(string name, bool passed, object detail = null)
            { Checks.Add(new { name, passed, detail }); Results.Add(passed); Log?.Invoke("HM_PROOF_CHECK " + name + "=" + passed); }
        }

        public static bool Begin(MonoBehaviour coroutineHost, GameObject registeredPrefab, Action<string> log, string evidenceDirectory)
        {
            if (Busy) { log?.Invoke("HM_PROOF_BUSY: stop the existing proof first."); return false; }
            if (!coroutineHost || !registeredPrefab || !Player.m_localPlayer || !ZNet.instance ||
                !ZNet.instance.IsServer() || !ZNet.IsSinglePlayer)
            { log?.Invoke("HM_PROOF_DENIED: requires the explicit command in a loaded single-player localhost world."); return false; }
            if (Player.m_localPlayer.IsDead() || Player.m_localPlayer.InGhostMode() || Player.m_localPlayer.IsDebugFlying())
            { log?.Invoke("HM_PROOF_DENIED: use a living, grounded, targetable player; ghost/debug flight prevents an honest AI test."); return false; }
            if (string.IsNullOrWhiteSpace(evidenceDirectory)) throw new ArgumentException("Evidence directory is required.");
            var c = new RunContext { Host = coroutineHost, Prefab = registeredPrefab, Player = Player.m_localPlayer,
                Log = log, Directory = Path.GetFullPath(evidenceDirectory), Started = Time.realtimeSinceStartup,
                FrameStarted = Time.frameCount, Id = DateTime.UtcNow.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture) + "-" + Guid.NewGuid().ToString("N").Substring(0, 8) };
            Directory.CreateDirectory(c.Directory); active = c;
            c.Coroutine = coroutineHost.StartCoroutine(Guarded(c));
            log?.Invoke("HM_PROOF_BEGIN " + c.Id + ": bounded natural AI test; stay nearby on flat safe terrain. No attack or movement is forced.");
            return true;
        }

        public static void Stop(Action<string> log = null)
        {
            var c = active; if (c == null) { log?.Invoke("HM_PROOF_IDLE"); return; }
            c.Aborted = true; c.Check("manual proof completed", false, "Stopped by explicit command.");
            if (c.Host && c.Coroutine != null) c.Host.StopCoroutine(c.Coroutine);
            Finish(c);
        }

        static IEnumerator Guarded(RunContext c)
        {
            var sequence = Sequence(c);
            while (true)
            {
                bool more; object next = null;
                try { more = sequence.MoveNext(); if (more) next = sequence.Current; }
                catch (Exception ex) { c.Check("runtime proof exception-free", false, ex.ToString()); break; }
                if (!more) break;
                yield return next;
            }
            (sequence as IDisposable)?.Dispose();
            Finish(c);
        }

        static IEnumerator Sequence(RunContext c)
        {
            // Select a clear grounded point near the current camera's planar
            // forward direction. These read-only casts do not alter terrain,
            // move the player/camera, or change any enemy's target or behavior.
            Vector3 forward, spawn; object placement;
            if (!TrySpawnPoint(c.Player, out spawn, out forward, out placement))
                throw new InvalidOperationException("No clear level proof spawn point within the current camera's forward sector.");
            c.Details["actualSpawnPlacement"] = placement;
            c.Actor = Object.Instantiate(c.Prefab, spawn, Quaternion.LookRotation(-forward, Vector3.up));
            c.ActorSpawned = c.Actor;
            c.Actor.SetActive(true); // A registered template can be active-self under an inactive prefab container.
            yield return null;
            yield return new WaitForSecondsRealtime(.3f);
            c.Character = c.Actor ? c.Actor.GetComponent<Humanoid>() : null;
            c.AI = c.Actor ? c.Actor.GetComponent<MonsterAI>() : null;
            c.Animator = c.Actor ? c.Actor.GetComponentInChildren<Animator>(true) : null;
            c.Check("owned spawned actor has actual Character AI Animator and ZNet ownership", c.Character && c.AI && c.Animator && c.Character.IsOwner());
            if (!c.Character || !c.AI || !c.Animator) yield break;
            c.Character.m_onDamaged += (amount, attacker) => { if (amount > 0) c.DamageObserved = true; };
            c.Character.m_onDeath += () => c.DeathObserved = true;
            c.PlayerDamageListener = (amount, attacker) =>
            { if (amount > 0 && attacker == c.Character) { c.NaturalHitDamageEvents++; c.NaturalHitDamage += amount; } };
            c.Player.m_onDamaged += c.PlayerDamageListener;
            c.Listener = c.Animator.gameObject.AddComponent<HushedMonkProofAttackListener>();
            c.Listener.Owner = c.Character;
            c.AudioProbe = new MonkAudioProofProbe(c.Actor);
            c.FeatureProbe = new MonkV4ProofProbe(c.Actor, c.Directory);
            c.Details["dungeonRoom"] = MonkDungeonProofRoom.Active?.SourceEvidence;
            c.Details["scale"] = MonkScaleContract.Snapshot(c.Actor);
            c.Details["targetingAtStart"] = MonkDungeonNavigation.TargetDiagnostics(c.Actor, c.Player);
            Snapshot(c);
            c.Bell = c.Actor.GetComponent<WristBellPhysics>();
            c.CordProbe = new MonkCordProofProbe(c.Bell);
            var bellInitial = c.Bell ? c.Bell.Snapshot() : null;
            c.BellBody = c.Bell ? c.Bell.DynamicBody : null; c.BellAnchor = c.Bell ? c.Bell.AnchorBody : null;
            c.BellBodiesCreated = c.BellBody && c.BellAnchor;
            c.Check("actual wrist bell uses dynamic gravity body and joint with isolated fixed band",
                bellInitial != null && bellInitial.initialized && bellInitial.gravity && !bellInitial.bodyIsKinematic && bellInitial.jointExists && bellInitial.colliderCount == 0 && bellInitial.fixedBandIsolated && bellInitial.rendererInsideActor,
                bellInitial);
            c.Details["bellPartitionSha256"] = VisualRuntime.Hash(Path.Combine(global::Otherworld.Distribution.BundleRuntime.Data("HushedMonkInGame"), "bell-partition.json"));

            Vector3 start = c.Actor.transform.position;
            float maximumTravel = 0, previousTime = c.Animator.GetCurrentAnimatorStateInfo(0).normalizedTime;
            int previousState = c.Animator.GetCurrentAnimatorStateInfo(0).fullPathHash;
            int targetSamples = 0, inAttackSamples = 0, animationAdvanceSamples = 0, awakeSamples = 0;
            bool wakeupSeen = false, wakeupStateSeen = false;
            float firstObservedHit = -1f;
            float end = Time.realtimeSinceStartup + 24f;
            while (Time.realtimeSinceStartup < end && c.Actor && c.Character && !c.Character.IsDead())
            {
                if (!c.Player || c.Player.IsDead()) break;
                var state = c.Animator.GetCurrentAnimatorStateInfo(0);
                if (state.fullPathHash != previousState || Mathf.Abs(state.normalizedTime - previousTime) > .0001f) animationAdvanceSamples++;
                previousState = state.fullPathHash; previousTime = state.normalizedTime;
                bool target = c.AI.GetTargetCreature() == c.Player;
                if (target) targetSamples++;
                bool attack = c.Character.InAttack(); if (attack) inAttackSamples++;
                bool wake = c.Animator.GetBool("wakeup"); if (wake) wakeupSeen = true; else awakeSamples++;
                if (state.IsName("Base Layer.Wakeup")) wakeupStateSeen = true;
                maximumTravel = Mathf.Max(maximumTravel, Vector3.ProjectOnPlane(c.Actor.transform.position - start, Vector3.up).magnitude);
                c.Samples.Add(new { elapsed = Time.realtimeSinceStartup - c.Started, frame = Time.frameCount, actor = V(c.Actor.transform.position),
                    health = c.Character.GetHealth(), playerHealth = c.Player.GetHealth(), distanceToPlayer = Vector3.Distance(c.Actor.transform.position, c.Player.transform.position),
                    targetIsLocalPlayer = target, inAttack = attack, wakeup = wake, stateHash = state.fullPathHash,
                    normalizedTime = state.normalizedTime, attackEvents = c.Listener.Events, bellPhysics = c.Bell ? c.Bell.Snapshot() : null, cord = c.CordProbe.Sample(), ownAudio = c.AudioProbe.Sample(), features = c.FeatureProbe.Sample() });
                // Stop after the first connected strike plus its real Hit event.
                // Even a missing observer event must never keep a 25HP private
                // character exposed to another strike: allow a quarter-second
                // event delivery window, then finish with that check FAILED.
                if (c.NaturalHitDamageEvents > 0)
                {
                    if (firstObservedHit < 0) firstObservedHit = Time.realtimeSinceStartup;
                    if (c.Listener.Events > 0 || Time.realtimeSinceStartup - firstObservedHit >= .25f) break;
                }
                yield return new WaitForSecondsRealtime(.1f);
            }
            c.Check("test player remained alive", c.Player && !c.Player.IsDead());
            c.Check("actual Animator frames and state time advanced", Time.frameCount > c.FrameStarted + 5 && animationAdvanceSamples > 5,
                new { frames = Time.frameCount - c.FrameStarted, animationAdvanceSamples });
            c.Check("AI naturally acquired the local player", targetSamples > 0, new { targetSamples });
            c.Check("AI naturally moved more than half a metre", maximumTravel > .5f, new { maximumTravelMetres = maximumTravel });
            c.Check("AI naturally entered attack and emitted native attack AnimationEvent", inAttackSamples > 0 && c.Listener && c.Listener.Events > 0,
                new { inAttackSamples, attackAnimationEvents = c.Listener ? c.Listener.Events : 0, eventRecords = c.Listener ? c.Listener.Records : null });
            c.Check("natural monk strike applied actor-attributed damage to test player", c.NaturalHitDamageEvents > 0,
                new { damageEvents = c.NaturalHitDamageEvents, totalDamage = c.NaturalHitDamage, playerHealth = c.Player ? c.Player.GetHealth() : -1 });
            c.Check("wakeup stayed false and optional Rise state was not entered", !wakeupSeen && !wakeupStateSeen && awakeSamples > 0,
                new { wakeupSeen, wakeupStateSeen, awakeSamples });
            var bellMotion = c.Bell ? c.Bell.Snapshot() : null;
            c.Check("actual wrist bell swings relative to wrist during natural motion", bellMotion != null && bellMotion.fixedSteps > 10 && bellMotion.maxSwingDegrees > 1f && bellMotion.relativeAngularTravelDegrees > 1f, bellMotion);
            c.Check("actual wrist bell attachment remains bounded during observed motion", bellMotion != null && bellMotion.initialized && bellMotion.fixedSteps > 10 && bellMotion.maxAnchorGapMetres < .03f && bellMotion.maxRenderPivotErrorMetres < .002f && bellMotion.maxSwingDegrees < 45f && bellMotion.maxRenderedSwingDegrees < 45f && bellMotion.fixedBandIsolated, bellMotion);
            c.Check("bell simulation avoids large solver corrections during natural motion", bellMotion != null && bellMotion.initialized && bellMotion.fixedSteps > 10 && bellMotion.rawMaximumSwingDegrees < 50f && bellMotion.maximumHardStopCorrectionDegrees < 20f, bellMotion);

            if (!c.Character || c.Character.IsDead()) { c.Check("owned actor available for controlled damage and death checks", false); yield break; }
            c.Details["targetingBeforeControlledDamage"] = MonkDungeonNavigation.TargetDiagnostics(c.Actor, c.Player);
            float health = c.Character.GetHealth();
            var small = new HitData { m_point = c.Character.GetCenterPoint(), m_dir = Vector3.zero };
            small.m_damage.m_damage = Mathf.Min(2f, health * .1f);
            c.Character.Damage(small); // No player attacker: do not manufacture player kill credit.
            yield return new WaitForSecondsRealtime(.5f);
            c.AudioProbe.Sample();
            float damaged = c.Character ? c.Character.GetHealth() : 0;
            c.Check("actual own-actor damage callback and health decrease", c.DamageObserved && damaged < health && damaged > 0,
                new { before = health, after = damaged, callback = c.DamageObserved });
            if (!c.Character || c.Character.IsDead()) yield break;
            var lethal = new HitData { m_point = c.Character.GetCenterPoint(), m_dir = Vector3.zero };
            lethal.m_damage.m_damage = Mathf.Max(10000f, c.Character.GetMaxHealth() * 100f);
            c.FeatureProbe.DeathStarted();
            c.Character.Damage(lethal);
            yield return null;
            c.AudioProbe.Sample();
            float deathEnd = Time.realtimeSinceStartup + 6f;
            while (c.Actor && Time.realtimeSinceStartup < deathEnd) yield return null;
            c.Check("actual own-actor death callback and native root destruction", c.DeathObserved && !c.Actor,
                new { deathCallback = c.DeathObserved, actorDestroyed = !c.Actor });
            yield return null;
            // Detached own death tails last at most five seconds; observe their
            // real expiry after native destruction instead of stopping them.
            float tailEnd = Time.realtimeSinceStartup + 5.3f;
            while (Time.realtimeSinceStartup < tailEnd)
            {
                c.FeatureProbe.Sample();
                yield return new WaitForSecondsRealtime(.1f);
            }
            c.AudioProbe.Check(c.Check);
            c.FeatureProbe.Check(c.Check);
            c.CordProbe.Check(c.Check);
            c.Check("bell cosmetic bodies cleaned after actor death", c.BellBodiesCreated && !c.BellBody && !c.BellAnchor,
                new { resourcesDestroyed = c.BellBodiesCreated && !c.BellBody && !c.BellAnchor, resourcesPreviouslyCreated = c.BellBodiesCreated, bodyDestroyed = !c.BellBody, anchorDestroyed = !c.BellAnchor, rendererDestroyedWithActor = !c.Actor });
            c.Check("manual proof completed", true);
        }

        static float[] V(Vector3 p) => new[] { p.x, p.y, p.z };
        static bool TrySpawnPoint(Player player, out Vector3 position, out Vector3 forward, out object details)
        {
            var camera = Camera.main;
            Vector3 view = MonkDungeonProofRoom.Active != null ? Vector3.forward : Vector3.ProjectOnPlane(camera ? camera.transform.forward : player.transform.forward, Vector3.up).normalized;
            if (view.sqrMagnitude < .5f) view = Vector3.forward;
            int mask = LayerMask.GetMask("terrain", "static_solid", "piece", "Default");
            foreach (float angle in new[] { 0f, 12f, -12f, 25f, -25f })
            {
                Vector3 direction = Quaternion.AngleAxis(angle, Vector3.up) * view;
                Vector3 desired = player.transform.position + direction * 4f;
                if (!Physics.Raycast(desired + Vector3.up * 2f, Vector3.down, out var floor, 5f, mask, QueryTriggerInteraction.Ignore) ||
                    Vector3.Dot(floor.normal, Vector3.up) < .85f || Mathf.Abs(floor.point.y - player.transform.position.y) > .8f) continue;
                Vector3 feet = new Vector3(desired.x, floor.point.y + .05f, desired.z);
                float radius = .24f * MonkScaleContract.Factor, height = 1.68f * MonkScaleContract.Factor;
                if (Physics.CheckCapsule(feet + Vector3.up * radius, feet + Vector3.up * (height - radius), radius, mask, QueryTriggerInteraction.Ignore) ||
                    Physics.Linecast(player.GetCenterPoint(), feet + Vector3.up * .85f, mask, QueryTriggerInteraction.Ignore)) continue;
                position = feet; forward = direction;
                details = new { cameraName = camera ? camera.name : null, cameraPlanarForward = V(view), playerForward = V(player.transform.forward),
                    chosenAngleDegrees = angle, distanceMetres = 4f, position = V(feet), floor = floor.collider ? floor.collider.name : null,
                    floorNormal = V(floor.normal), capsuleAndApproachClear = true, playerOrCameraMoved = false };
                return true;
            }
            position = forward = Vector3.zero; details = null; return false;
        }
        static void Snapshot(RunContext c)
        {
            var avatar = c.Animator.avatar;
            c.Check("actual runtime Avatar is valid and Humanoid", avatar && avatar.isValid && avatar.isHuman,
                new { avatar = avatar ? avatar.name : null, valid = avatar && avatar.isValid, human = avatar && avatar.isHuman });
            var renderers = c.Actor.GetComponentsInChildren<Renderer>(true);
            var own = renderers.Where(r => r.sharedMaterials.Length == 1 && r.sharedMaterial && r.sharedMaterial.name.StartsWith("HM_", StringComparison.Ordinal)).ToArray();
            var materials = own.Select(r => r.sharedMaterial).Distinct().ToArray();
            var skins = own.OfType<SkinnedMeshRenderer>().ToArray();
            var bindings = c.Actor.GetComponent<VisualInstanceBindings>();
            c.Check("own renderer/material/skin inventory matches exact source and partition", bindings && own.Length == bindings.runtimeRendererCount && materials.Length == bindings.sourceMaterialCount && skins.Length == 1 && skins[0].bones.Length == bindings.sourceSkinJointCount,
                new { rendererCount = renderers.Length, ownCount = own.Length, materialCount = materials.Length,
                    renderers = renderers.Select(r => new { r.name, type = r.GetType().Name, materials = r.sharedMaterials.Select(m => m ? m.name : null).ToArray() }).ToArray() });
            c.Check("all own materials use actual Creature shader and three required baked maps", bindings && materials.Length == bindings.sourceMaterialCount && materials.All(m => m.shader && m.shader.name == "Custom/Creature" &&
                new[] { "_MainTex", "_BumpMap", "_MetallicGlossMap" }.All(p => m.HasProperty(p) && m.GetTexture(p))),
                materials.Select(m => new { m.name, shader = m.shader ? m.shader.name : null,
                    maps = new[] { "_MainTex", "_BumpMap", "_MetallicGlossMap" }.ToDictionary(p => p, p => m.HasProperty(p) && m.GetTexture(p) ? m.GetTexture(p).name : null) }).ToArray());
            var skeleton = ZNetScene.instance.GetPrefab("Skeleton");
            var controller = skeleton ? skeleton.GetComponentInChildren<Animator>(true)?.runtimeAnimatorController : null;
            c.Check("exact native Skeleton runtime controller retained", controller && c.Animator.runtimeAnimatorController == controller,
                new { actual = c.Animator.runtimeAnimatorController ? c.Animator.runtimeAnimatorController.name : null, expected = controller ? controller.name : null });
            var maceClip = c.Animator.runtimeAnimatorController.animationClips.FirstOrDefault(clip => clip && clip.name == "Skeleton_mace");
            c.Check("actual loaded mace clip emits the native Hit event", maceClip && maceClip.events.Any(e => e.functionName == "Hit"),
                maceClip ? new { clip = maceClip.name, events = maceClip.events.Select(e => new { e.functionName, e.time }).ToArray() } : null);
            var weapon = c.Character.GetCurrentWeapon();
            c.Check("custom clapper attack item drives mace animation", weapon != null && weapon.m_dropPrefab && weapon.m_dropPrefab.name == "TWA_HushedMonk_Clapper_Test" && weapon.m_shared.m_attack.m_attackAnimation == "attack_mace",
                weapon == null ? null : new { prefab = weapon.m_dropPrefab ? weapon.m_dropPrefab.name : null, attackAnimation = weapon.m_shared.m_attack.m_attackAnimation });
            var token = weapon?.m_dropPrefab;
            int actorLights = c.Actor.GetComponentsInChildren<Light>(true).Length;
            int tokenLights = token ? token.GetComponentsInChildren<Light>(true).Length : -1;
            int tokenEffectAreas = token ? token.GetComponentsInChildren<EffectArea>(true).Length : -1;
            int tokenAoes = token ? token.GetComponentsInChildren<Aoe>(true).Length : -1;
            c.Check("own actor and equipped attack token contain no inherited lights or area effects", actorLights == 0 && tokenLights == 0 && tokenEffectAreas == 0 && tokenAoes == 0,
                new { actorLights, tokenPrefab = token ? token.name : null, tokenLights, tokenEffectAreas, tokenAoes, includesInactiveChildren = true });
            var greyling = ZNetScene.instance.GetPrefab("Greyling");
            var adapter = typeof(HushedMonkGameProof).Assembly.GetType("BlackAbbey.HushedMonk.GraylingAIAdapter");
            var audit = adapter?.GetMethod("Audit", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static, null, new[] { typeof(GameObject), typeof(GameObject) }, null);
            if (audit == null) c.Check("Grayling AI whitelist matches source", false, "GraylingAIAdapter.Audit(GameObject,GameObject) is required; existence alone is insufficient.");
            else
            {
                var result = audit.Invoke(null, new object[] { c.Actor, greyling });
                var tree = Newtonsoft.Json.Linq.JObject.FromObject(result);
                bool pass = tree.Value<bool?>("passed") == true;
                c.Check("Grayling AI whitelist matches source", pass, result);
            }
            c.Details["sourceNativeSha256"] = NativeSha;
            var marker = c.Actor.GetComponent<HushedMonkInstance>();
            c.Check("spawned actor identifies exact approved visual source and payload", marker && marker.approvedNativeSha256 == NativeSha && !string.IsNullOrEmpty(marker.visualPayloadSha256),
                marker ? new { marker.approvedNativeSha256, marker.visualPayloadSha256, marker.nativeControllerName } : null);
            c.Details["visualPayloadSha256"] = marker ? marker.visualPayloadSha256 : null;
            c.Details["spawnHealth"] = c.Character.GetHealth();
            c.Details["playerHealthAtStart"] = c.Player.GetHealth();
            c.Details["playerStatsAndSettingsChangedByProof"] = false;
        }

        static void Finish(RunContext c)
        {
            if (c.CleanupRequested) return;
            c.CleanupRequested = true;
            if (c.Player && c.PlayerDamageListener != null) c.Player.m_onDamaged -= c.PlayerDamageListener;
            bool nativeDeathDestroyedActor = c.ActorSpawned && c.DeathObserved && !c.Actor;
            bool actorAlreadyAbsent = !c.Actor;
            if (c.Actor)
            {
                var view = c.Actor.GetComponent<ZNetView>();
                if (view && view.IsOwner() && ZNetScene.instance) ZNetScene.instance.Destroy(c.Actor);
                else Object.Destroy(c.Actor);
            }
            try
            {
                var record = new { schema = "hushed-monk.actual-game-proof.v1", id = c.Id, generatedUtc = DateTime.UtcNow.ToString("o"),
                    passed = !c.Aborted && c.Results.Count > 0 && c.Results.All(p => p), aborted = c.Aborted,
                    seconds = Time.realtimeSinceStartup - c.Started, sourceNativeSha256 = NativeSha,
                    checks = c.Checks, details = c.Details, samples = c.Samples,
                    cleanup = new { ownActorOnly = true, actorWasSpawned = c.ActorSpawned, actorAlreadyAbsent, nativeDeathDestroyedActor, fallbackDestroyRequested = !actorAlreadyAbsent },
                    limits = new[] { "Explicit local single-player scenario only; no automatic enemy spawns.",
                        "No forced move, alert, target or attack calls; a missing natural attack is a failed check.",
                        "No player health/buffs, world rules or global AI values changed by proof. Normal hostile AI can damage the test player.",
                        "Own source output and event cleanup checked; human audio mix, multiplayer, corpse/drop appearance and artistic clipping need separate review.",
                        "Rise is avoided through awake spawning, not repaired; only states reached in this run are observed." } };
                string path = Path.Combine(c.Directory, "game-proof-" + c.Id + ".json");
                File.WriteAllText(path, JsonConvert.SerializeObject(record, Formatting.Indented));
                c.Log?.Invoke("HM_PROOF_RESULT " + (record.passed ? "PASS" : "FAIL") + " path=" + path);
            }
            catch (Exception ex) { c.Log?.Invoke("HM_PROOF_WRITE_FAILED " + ex); }
            finally { if (ReferenceEquals(active, c)) active = null; }
        }
    }

    // Observes the same Unity AnimationEvent as native CharacterAnimEvent.
    // It never calls the attack, changes the clip or touches another actor.
    public sealed class HushedMonkProofAttackListener : MonoBehaviour
    {
        public Humanoid Owner;
        public int Events { get; private set; }
        public readonly List<object> Records = new List<object>();
        // Actual Skeleton_mace emits Hit at 0.8588761 seconds. Native
        // CharacterAnimEvent.Hit forwards it to Character.OnAttackTrigger.
        public void Hit()
        {
            if (!Owner || !Owner.IsOwner()) return;
            Events++;
            Records.Add(new { functionName = "Hit", frame = Time.frameCount, time = Time.time, ownerInAttack = Owner.InAttack(),
                weapon = Owner.GetCurrentWeapon()?.m_dropPrefab ? Owner.GetCurrentWeapon().m_dropPrefab.name : null });
        }
    }
}
