using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using Jotunn.Entities;
using Jotunn.Managers;
using Jotunn.Utils;
using Newtonsoft.Json;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbey.HushedMonk
{
    [BepInPlugin(Id, "Black Abbey Hushed Monk In-Game Test", Version)]
    [BepInDependency(Jotunn.Main.ModGuid, "2.30.2")]
    [NetworkCompatibility(CompatibilityLevel.EveryoneMustHaveMod, VersionStrictness.Patch)]
    public sealed class HushedMonkPlugin : BaseUnityPlugin
    {
        public const string Id = "studio.otherworld.hushedmonkingametest", Version = "0.6.9";
        public const string PrefabName = "TWA_HushedMonk_Test", WeaponName = "TWA_HushedMonk_Clapper_Test";
        static HushedMonkPlugin instance;
        GameObject registeredPrefab;
        VisualRuntime visual;
        ConfigEntry<float> health, bluntDamage;
        ConfigEntry<bool> audioEnabled;
        ConfigEntry<float> audioVolume;
        MonkAudioBank audioBank;
        Harmony audioHarmony;
        object audioCloneAudit;
        object scaleAudit, deathAudit, bloodAudit;
        public static MonkAudioBank AudioBank => instance ? instance.audioBank : null;
        public static string RegistrationFailure { get; private set; }
        bool registrationAttempted;
        object attackTokenAudit;
        public string EvidenceDirectory => Path.Combine(Path.Combine(BepInEx.Paths.PluginPath,"HushedMonkInGame"), "evidence");
        string Manifest => Path.Combine(global::Otherworld.Distribution.BundleRuntime.Data("HushedMonkInGame"), "monk-visual.json");
        public static void Log(string text) { if (instance) instance.Logger.LogInfo(text); }
        void Awake()
        {
            global::Otherworld.Distribution.BundleRuntime.Initialize(this);

            instance = this;
            health = Config.Bind("Test balance", "Health", 100f, new ConfigDescription("Provisional base health of newly manually spawned monks.", new AcceptableValueRange<float>(10, 1000)));
            bluntDamage = Config.Bind("Test balance", "ClapperBluntDamage", 18f, new ConfigDescription("Provisional clapper base blunt damage; native Skeleton mace attack timing is retained.", new AcceptableValueRange<float>(1, 150)));
            audioEnabled = Config.Bind("Audio", "Enabled", true, "Play the selected original monk sounds; native footsteps are retained.");
            audioVolume = Config.Bind("Audio", "Volume", 1f, new ConfigDescription("Overall multiplier for own monk sounds; the game's SFX mixer still applies.", new AcceptableValueRange<float>(0, 1)));
            audioEnabled.SettingChanged += UpdateAudioMix;
            audioVolume.SettingChanged += UpdateAudioMix;
            UpdateAudioMix(null, EventArgs.Empty);
            audioHarmony = new Harmony(Id + ".runtime");
            global::Otherworld.Distribution.BundleRuntime.PatchModule(audioHarmony,typeof(MonkAudioHooks));
            PrefabManager.OnVanillaPrefabsAvailable += Register;
            CommandManager.Instance.AddConsoleCommand(new Command("twa_monk_spawn", "Spawn one Hushed Monk ahead of the host (devcommands; Greyling-style AI).", true, Spawn));
            CommandManager.Instance.AddConsoleCommand(new Command("twa_monk_remove", "Remove only nearby Hushed Monk test actors, without killing unrelated creatures.", true, Remove));
            CommandManager.Instance.AddConsoleCommand(new Command("twa_monk_status", "Report Hushed Monk registration, visual/avatar, native equipment, health and AI.", false, args => Status()));
            CommandManager.Instance.AddConsoleCommand(new Command("twa_monk_audio_status", "Report loaded original sounds, breathing state and event playback.", false, args => AudioStatus()));
            CommandManager.Instance.AddConsoleCommand(new Command("twa_monk_nav_status", "Report own dungeon navigation readiness and paths.", false, args => NavigationStatus()));
            CommandManager.Instance.AddConsoleCommand(new Command("twa_monk_death_status", "Report own ragdoll, smoke and cleanup.", false, args => Print(JsonConvert.SerializeObject(MonkDeathPresentation.Snapshot()))));
            CommandManager.Instance.AddConsoleCommand(new Command("twa_monk_proof", "Run a bounded actual AI/attack/damage/death proof on one new monk; stand on flat safe terrain.", true, Proof));
            CommandManager.Instance.AddConsoleCommand(new Command("twa_monk_proof_stop", "Stop and clean up only the currently running monk proof actor.", true, args => HushedMonkGameProof.Stop(Log)));
            Log("HM_PLUGIN_READY version=" + Version + " manualOnly=true naturalSpawns=false noRoomHelperChanges=true visual=" + Manifest);
            HushedMonkAutoTest.Attach(this, null, Log, EvidenceDirectory);
        }
        void UpdateAudioMix(object sender, EventArgs args) => MonkAudioController.SetMix(audioEnabled.Value, audioVolume.Value);
        sealed class Command : ConsoleCommand
        {
            readonly string name, help; readonly bool host; readonly Action<string[]> action;
            public Command(string name, string help, bool host, Action<string[]> action) { this.name = name; this.help = help; this.host = host; this.action = action; }
            public override string Name => name; public override string Help => help; public override bool IsCheat => host; public override bool OnlyServer => host;
            public override void Run(string[] args) => action(args);
        }
        void Print(string message) { if (Console.instance) Console.instance.AddString(message); Log(message); }
        static GameObject Required(string name)
        { var prefab = PrefabManager.Instance.GetPrefab(name); if (!prefab) throw new InvalidOperationException("Missing native prefab: " + name); return prefab; }
        void Register()
        {
            if (registeredPrefab || registrationAttempted) return;
            registrationAttempted = true;
            GameObject enemy = null;
            try
            {
                var skeleton = Required("Skeleton"); var greyling = Required(GraylingAIAdapter.SourcePrefab);
                audioBank = MonkAudioBank.Initialize(Path.Combine(Path.GetDirectoryName(Manifest), "audio", "bank.json"), Log);
                MonkAudioHooks.ResolveNativeCreatureMixer(skeleton, Required("skeleton_mace"));
                NativeLayoutSnapshot.Save(skeleton, EvidenceDirectory, Log);
                var sourceBody = skeleton.GetComponent<VisEquipment>()?.m_bodyModel;
                if (!sourceBody || !sourceBody.sharedMaterial || sourceBody.sharedMaterial.shader.name != "Custom/Creature") throw new InvalidOperationException("Installed Skeleton visual contract changed.");
                var weapon = new CustomItem(WeaponName, "skeleton_mace");
                if (!weapon.ItemPrefab || !weapon.ItemDrop) throw new InvalidOperationException("Native mace clone failed.");
                var sourceItem = Required("skeleton_mace").GetComponent<ItemDrop>().m_itemData;
                weapon.ItemDrop.m_itemData = sourceItem.Clone();
                weapon.ItemDrop.m_itemData.m_dropPrefab = weapon.ItemPrefab;
                weapon.ItemDrop.m_itemData.m_shared = (ItemDrop.ItemData.SharedData)typeof(object).GetMethod("MemberwiseClone", BindingFlags.NonPublic | BindingFlags.Instance).Invoke(sourceItem.m_shared, null);
                var shared = weapon.ItemDrop.m_itemData.m_shared;
                shared.m_name = "Worn Bell Clapper"; shared.m_description = "Hushed Monk test weapon; not a player progression item.";
                shared.m_attack = sourceItem.m_shared.m_attack.Clone(); shared.m_secondaryAttack = sourceItem.m_shared.m_secondaryAttack.Clone();
                shared.m_damages = new HitData.DamageTypes { m_blunt = bluntDamage.Value }; shared.m_damagesPerLevel = new HitData.DamageTypes(); shared.m_useDurability = false;
                attackTokenAudit = AttackTokenSanitizer.Clean(Required("skeleton_mace").GetComponent<ItemDrop>(), weapon.ItemDrop, Log);
                if (!ItemManager.Instance.AddItem(weapon)) throw new InvalidOperationException("Own native-timed mace registration failed.");
                enemy = PrefabManager.Instance.CreateClonedPrefab(PrefabName, skeleton); enemy.SetActive(false);
                var humanoid = enemy.GetComponent<Humanoid>();
                if (!humanoid || !enemy.GetComponent<ZNetView>() || !enemy.GetComponent<MonsterAI>()) throw new InvalidOperationException("Native enemy lifecycle missing.");
                humanoid.m_name = "Hushed Monk"; humanoid.m_health = health.Value; humanoid.m_boss = false; humanoid.m_bossEvent = ""; humanoid.m_defeatSetGlobalKey = ""; humanoid.m_group = "BlackAbbeyHushedMonk";
                humanoid.m_defaultItems = new[] { weapon.ItemPrefab }; humanoid.m_randomWeapon = Array.Empty<GameObject>(); humanoid.m_randomArmor = Array.Empty<GameObject>(); humanoid.m_randomShield = Array.Empty<GameObject>(); humanoid.m_randomSets = Array.Empty<Humanoid.ItemSet>(); humanoid.m_randomItems = Array.Empty<Humanoid.RandomItem>(); humanoid.m_unarmedWeapon = weapon.ItemDrop;
                GraylingAIAdapter.Apply(enemy, greyling, Log);
                var deathBefore = humanoid.m_deathEffects?.m_effectPrefabs ?? Array.Empty<EffectList.EffectData>();
                // Keep native non-mesh audio/VFX, never the old Skeleton ragdoll/gibs.
                humanoid.m_deathEffects = new EffectList { m_effectPrefabs = deathBefore.Where(e => e?.m_prefab && !e.m_prefab.GetComponentInChildren<Ragdoll>(true) && !e.m_prefab.GetComponentInChildren<Renderer>(true) && (e.m_prefab.name.StartsWith("sfx_", StringComparison.OrdinalIgnoreCase) || e.m_prefab.name.StartsWith("vfx_", StringComparison.OrdinalIgnoreCase))).ToArray() };
                var drops = enemy.GetComponent<CharacterDrop>(); if (drops) drops.m_drops = new List<CharacterDrop.Drop>();
                visual = VisualRuntime.Apply(enemy, Manifest, sourceBody.sharedMaterial, Log);
                var collider = enemy.GetComponent<CapsuleCollider>();
                if (!collider) throw new InvalidOperationException("Native character capsule missing.");
                collider.height = 1.68f; collider.radius = .24f; collider.center = new Vector3(0, .85f, 0);
                if (humanoid.m_eye) humanoid.m_eye.localPosition = new Vector3(0, 1.50f, .055f);
                var sync = enemy.GetComponent<ZSyncAnimation>(); if (sync && !sync.m_syncBools.Contains("wakeup")) sync.m_syncBools.Add("wakeup");
                var marker = enemy.AddComponent<HushedMonkInstance>(); marker.visualPayloadSha256 = visual.PayloadHash; marker.approvedNativeSha256 = visual.Payload.sourceNative.sha256; marker.nativeControllerName = visual.Animator.runtimeAnimatorController.name;
                scaleAudit = MonkScaleContract.Apply(enemy, shared);
                bloodAudit = MonkRedBlood.Apply(enemy, skeleton, Required("vfx_BloodHit"));
                deathAudit = MonkDeathPresentation.Prepare(enemy, greyling);
                audioCloneAudit = MonkAudioHooks.PrepareOwnedClones(skeleton, enemy, Required("skeleton_mace").GetComponent<ItemDrop>(), weapon.ItemDrop);
                PrefabManager.Instance.AddPrefab(new CustomPrefab(enemy, false)); registeredPrefab = enemy;
                if (!enemy.transform.parent || enemy.transform.parent.gameObject.activeInHierarchy) throw new InvalidOperationException("Registered prefab must remain beneath Jotunn's inactive container.");
                enemy.SetActive(true); // Network clients instantiate the same active-self prefab.
                PrefabManager.OnVanillaPrefabsAvailable -= Register;
                WriteRegistration(skeleton, greyling, weapon, deathBefore);
                HushedMonkAutoTest.Attach(this, registeredPrefab, Log, EvidenceDirectory);
                Print("Hushed Monk ready. Use devcommands, then twa_monk_spawn. AI uses actual Greyling settings; only manual test spawns are enabled.");
            }
            catch (Exception ex)
            {
                RegistrationFailure = ex.Message;
                if (enemy) Object.Destroy(enemy); visual?.Dispose(); visual = null;
                Logger.LogError("HM_REGISTRATION_FAILED; no monk spawned: " + ex); Print("Hushed Monk could not load. Check the BepInEx log; no substitute model was spawned.");
            }
        }
        void WriteRegistration(GameObject skeleton, GameObject greyling, CustomItem weapon, EffectList.EffectData[] originalDeath)
        {
            Directory.CreateDirectory(EvidenceDirectory);
            var humanoid = registeredPrefab.GetComponent<Humanoid>();
            var receipt = new { schema = "hushed-monk.ingame-registration.v1", utc = DateTime.UtcNow, plugin = Id, version = Version, unityVersion = Application.unityVersion, nativeSource = VisualSourceContract.NativeSha256, visualPayloadSha256 = visual.PayloadHash, prefab = PrefabName, weapon = WeaponName, nativeController = visual.Animator.runtimeAnimatorController.name, ownAvatarValid = visual.Avatar.isValid, ownAvatarHuman = visual.Avatar.isHuman, ai = GraylingAIAdapter.Audit(registeredPrefab, greyling), ownOverrides = new { health = health.Value, bluntDamage = bluntDamage.Value, capsuleHeight = 1.68f, capsuleRadius = .24f, eyeHeight = 1.50f, faction = humanoid.m_faction.ToString(), manualAwakeSpawn = true, wakeup = false, noNaturalSpawnEntries = true, noLoot = true, customCorpseImplemented = false }, combat = new { source = "skeleton_mace", attack = weapon.ItemDrop.m_itemData.m_shared.m_attack.m_attackAnimation, range = weapon.ItemDrop.m_itemData.m_shared.m_attack.m_attackRange, aiRange = weapon.ItemDrop.m_itemData.m_shared.m_aiAttackRange }, removedDeathPrefabs = originalDeath.Select(e => e?.m_prefab ? e.m_prefab.name : "null").Except(humanoid.m_deathEffects.m_effectPrefabs.Select(e => e.m_prefab.name)).ToArray() };
            var record = Newtonsoft.Json.Linq.JObject.FromObject(receipt);
            record["attackTokenAudit"] = Newtonsoft.Json.Linq.JToken.FromObject(attackTokenAudit);
            record["audioCloneAudit"] = Newtonsoft.Json.Linq.JToken.FromObject(audioCloneAudit);
            record["audioBank"] = Newtonsoft.Json.Linq.JToken.FromObject(audioBank.Snapshot());
            record["scale"] = Newtonsoft.Json.Linq.JToken.FromObject(scaleAudit);
            record["deathPresentation"] = Newtonsoft.Json.Linq.JToken.FromObject(deathAudit);
            record["redBlood"] = Newtonsoft.Json.Linq.JToken.FromObject(bloodAudit);
            record["ownOverrides"]["customCorpseImplemented"] = true;
            record["ownOverrides"]["capsuleHeight"] = 1.68f * MonkScaleContract.Factor;
            record["ownOverrides"]["capsuleRadius"] = .24f * MonkScaleContract.Factor;
            record["ownOverrides"]["eyeHeight"] = 1.50f * MonkScaleContract.Factor;
            File.WriteAllText(Path.Combine(EvidenceDirectory, "registration.json"), record.ToString(Formatting.Indented));
            File.WriteAllText(Path.Combine(EvidenceDirectory, "attack-token-audit.json"), JsonConvert.SerializeObject(attackTokenAudit, Formatting.Indented));
            File.WriteAllText(Path.Combine(EvidenceDirectory, "audio-clone-audit.json"), JsonConvert.SerializeObject(audioCloneAudit, Formatting.Indented));
        }
        bool Host(out Player player)
        { player = Player.m_localPlayer; if (!player || !ZNet.instance || !ZNet.instance.IsServer() || !ZNetScene.instance) { Print("Use this command as the local host/singleplayer with a loaded character."); return false; } if (!registeredPrefab) { Print("Hushed Monk prefab is not ready. Check twa_monk_status and the log."); return false; } return true; }
        void Spawn(string[] args)
        {
            if (!Host(out var player)) return;
            if (Object.FindObjectsByType<HushedMonkInstance>(FindObjectsSortMode.None).Count(m => m && m.gameObject.activeInHierarchy) >= 3) { Print("Three test monks are already loaded. Use twa_monk_remove first."); return; }
            Vector3 forward = Vector3.ProjectOnPlane(player.transform.forward, Vector3.up).normalized; if (forward.sqrMagnitude < .5f) forward = Vector3.forward;
            Vector3 position = player.transform.position + forward * 6f;
            if (!Physics.Raycast(position + Vector3.up * 2, Vector3.down, out var hit, 5, LayerMask.GetMask("terrain", "static_solid", "piece"))) { Print("No safe ground/floor six metres ahead. Move to a flat area."); return; }
            position.y = hit.point.y + .05f;
            if (Vector3.Dot(hit.normal, Vector3.up) < .85f) { Print("The floor ahead is too steep for this first enemy test."); return; }
            var actor = Object.Instantiate(registeredPrefab, position, Quaternion.LookRotation(-forward)); actor.SetActive(true); Print("Spawned one Hushed Monk six metres ahead. It is hostile; use twa_monk_remove to remove only test monks.");
        }
        void Remove(string[] args)
        {
            if (!Host(out var player)) return; int removed = 0;
            foreach (var monk in Object.FindObjectsByType<HushedMonkInstance>(FindObjectsSortMode.None))
            { if (!monk || !monk.gameObject.activeInHierarchy || (monk.transform.position - player.transform.position).sqrMagnitude > 10000) continue; var view = monk.GetComponent<ZNetView>(); if (!view || !view.IsValid() || !view.IsOwner()) continue; ZNetScene.instance.Destroy(monk.gameObject); removed++; }
            Print("Removed " + removed + " nearby owned test monks. Other enemies were left alone.");
        }
        void Proof(string[] args)
        {
            if (!Host(out _)) return;
            if (args != null && args.Length > 0 && args[0].Equals("stop", StringComparison.OrdinalIgnoreCase)) { HushedMonkGameProof.Stop(Log); return; }
            HushedMonkGameProof.Begin(this, registeredPrefab, Log, EvidenceDirectory);
        }
        void Status()
        {
            Print("HM_STATUS version=" + Version + " ready=" + (registeredPrefab != null) + " payload=" + (visual?.PayloadHash ?? "notloaded") + " naturalSpawns=false");
            foreach (var monk in Object.FindObjectsByType<HushedMonkInstance>(FindObjectsSortMode.None)) if (monk && monk.gameObject.activeInHierarchy) Print(monk.Status());
        }
        void AudioStatus()
        {
            Print("HM_AUDIO_BANK " + JsonConvert.SerializeObject(audioBank?.Snapshot()));
            Print("HM_AUDIO_PLAYBACK " + JsonConvert.SerializeObject(MonkAudioController.PlaybackSnapshot()));
            foreach (var monk in Object.FindObjectsByType<MonkAudioController>(FindObjectsSortMode.None))
                if (monk && monk.gameObject.activeInHierarchy) Print("HM_AUDIO_STATE " + JsonConvert.SerializeObject(monk.Snapshot()));
        }
        void NavigationStatus()
        {
            var rows = new List<object>();
            foreach (var navigation in Object.FindObjectsByType<MonkDungeonNavigation>(FindObjectsSortMode.None))
                if (navigation)
                {
                    object target;
                    try { target = MonkDungeonNavigation.TargetDiagnostics(navigation.gameObject, Player.m_localPlayer); }
                    catch (Exception error) { target = new { diagnosticFailure = error.Message }; }
                    var row = new { state = navigation.Snapshot(), targeting = target };
                    rows.Add(row); Print("HM_NAV_STATE " + JsonConvert.SerializeObject(row));
                }
            Directory.CreateDirectory(EvidenceDirectory);
            File.WriteAllText(Path.Combine(EvidenceDirectory, "last-navigation-status.json"), JsonConvert.SerializeObject(new {
                utc = DateTime.UtcNow.ToString("o"), version = Version, pluginSha256 = VisualRuntime.Hash(typeof(HushedMonkPlugin).Assembly.Location),
                requestedBy = "Manual twa_monk_nav_status command", actors = rows }, Formatting.Indented));
        }
        void OnDestroy()
        {
            PrefabManager.OnVanillaPrefabsAvailable -= Register;
            HushedMonkGameProof.Stop(Log);
            audioEnabled.SettingChanged -= UpdateAudioMix;
            audioVolume.SettingChanged -= UpdateAudioMix;
            MonkAudioController.Shutdown();
            MonkDungeonNavigation.Shutdown();
            MonkDeathPresentation.Shutdown();
            MonkAudioHooks.ReleaseOwnedEffectForks();
            audioHarmony?.UnpatchSelf();
            // Shared own meshes/materials/avatar remain alive until plugin teardown;
            // instances never destroy resources used by another network clone.
            if (registeredPrefab) Object.Destroy(registeredPrefab); visual?.Dispose();
            if (instance == this) instance = null;
        }
    }
}
