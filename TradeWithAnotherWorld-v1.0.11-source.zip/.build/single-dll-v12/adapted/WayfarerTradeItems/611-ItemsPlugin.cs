using System;
using System.IO;
using BepInEx;
using HarmonyLib;
using Jotunn.Managers;
using Wayfarer.InGame;
using UnityEngine;

namespace Wayfarer.Items
{
    [BepInPlugin(Id,"Wayfarer Trade and Equipment",Version)]
    [BepInDependency(WayfarerPlugin.Id,"0.1.7")]
    [BepInDependency(Jotunn.Main.ModGuid,"2.30.2")]
    [BepInDependency("OctoPack_addon_Lantern",BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("randyknapp.mods.equipmentandquickslots",BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("studio.otherworld.blackabbeyroomtest")]
    [Jotunn.Utils.NetworkCompatibility(Jotunn.Utils.CompatibilityLevel.EveryoneMustHaveMod,Jotunn.Utils.VersionStrictness.Patch)]
    public sealed class ItemsPlugin:BaseUnityPlugin
    {
        public const string Id="studio.otherworld.wayfarer.items",Version="0.2.3";
        public static ItemsPlugin Instance{get;private set;}
        public RuntimeCatalogue Catalogue{get;private set;}
        public ItemVisualCache Visuals{get;private set;}
        public CommerceDefinitions Definitions{get;private set;}
        public CommerceCoordinator Commerce{get;private set;}
        public string DataDirectory{get;private set;}
        public bool AssetsReady=>Visuals!=null;
        Harmony patches;
        bool initialized;
        void Awake()
        {
            global::Otherworld.Distribution.BundleRuntime.Initialize(this);

            Instance=this;
            try
            {
                DataDirectory=global::Otherworld.Distribution.BundleRuntime.Data("WayfarerTradeItems");
                Catalogue=RuntimeCatalogue.Load(Path.Combine(DataDirectory,"trade-catalogue.json"));
                Definitions=new CommerceDefinitions(Catalogue);
                Definitions.LoadDialogueMap(Path.Combine(DataDirectory,"dialogue-commission-map.json"));
                Visuals=new ItemVisualCache(Path.Combine(DataDirectory,"assets"),Report);
                StrangeCoinVisual.DroppedVisual=parent=>{Visuals.Attach("jewelry_pouch",parent,parent.gameObject.layer,false);return Visuals.Bounds("jewelry_pouch");};
                Commerce=new CommerceCoordinator(this,Path.Combine(Paths.ConfigPath,"Wayfarer","worlds"));
                JewelleryRuntime.Init();
                patches=new Harmony(Id);global::Otherworld.Distribution.BundleRuntime.PatchModule(patches,typeof(ItemsPlugin));RefinedResinCompatibility.Initialize(patches);AbbeyLoot.Initialize(patches);NativeProgress.Initialize(patches);NativeAbbeyReading.Initialize(patches);WeaponOilHitEffects.Initialize(patches);
                PrefabManager.OnVanillaPrefabsAvailable+=Register;
                CommandManager.Instance.AddConsoleCommand(new ItemStatusCommand());
                initialized=true;
                Report("MODULE_READY version="+Version+" catalogue="+Catalogue.Items.Count+" naturalSpawns=false gameplayValidation=awaiting_Jesse");
            }
            catch(Exception e){StrangeCoinVisual.DroppedVisual=null;initialized=false;patches?.UnpatchSelf();JewelleryRuntime.Dispose();Visuals?.Dispose();Warn("MODULE_DISABLED "+e);Instance=null;}
        }
        void Register()
        {
            if(!initialized)return;
            try{OwnedCombatEffects.Register();ItemRegistry.Register(this);LanternBuild.Register(this);OffhandParticles.Validate();Definitions.ResolveNativeCategories();PrefabManager.OnVanillaPrefabsAvailable-=Register;}
            catch(Exception e){Warn("REGISTRATION_FAILED "+e);}
        }
        void Update()
        {
            if(!initialized)return;
            try{Commerce.Tick();CombatReceipts.Tick();JewelleryRuntime.Tick(Player.m_localPlayer);RingEquipmentPanel.Tick();WeaponOilUse.Tick(Player.m_localPlayer,Time.deltaTime);OffhandRuntime.Tick();NativeProgress.Tick();WayfarerTradeUI.Tick();}
            catch(Exception e){Warn("UPDATE_FAILED "+e);initialized=false;WayfarerTradeUI.Close();}
        }
        public void Report(string message)=>Logger.LogInfo("WF_ITEMS "+message);
        public void Warn(string message)=>Logger.LogWarning("WF_ITEMS "+message);
        void OnDestroy()
        {
            StrangeCoinVisual.DroppedVisual=null;PrefabManager.OnVanillaPrefabsAvailable-=Register;WayfarerTradeUI.Close();RingEquipmentPanel.Dispose();WeaponOilUse.Dispose();JewelleryRuntime.Dispose();Commerce?.Dispose();patches?.UnpatchSelf();Visuals?.Dispose();
            if(Instance==this)Instance=null;
        }
    }
}
