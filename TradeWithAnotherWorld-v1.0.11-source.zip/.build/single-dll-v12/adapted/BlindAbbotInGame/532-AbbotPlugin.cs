using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using Jotunn.Entities;
using Jotunn.Managers;
using UnityEngine;
using UnityEngine.Audio;
using Object=UnityEngine.Object;

namespace BlackAbbey.BlindAbbot
{
    [BepInPlugin(Id,"Black Abbey Blind Abbot Encounter",Version)]
    [BepInDependency(Jotunn.Main.ModGuid,"2.30.2")]
    [BepInDependency("studio.otherworld.blackabbeyroomtest",BepInDependency.DependencyFlags.SoftDependency)]
    public sealed class AbbotPlugin:BaseUnityPlugin
    {
        public const string Id="studio.otherworld.blindabbot",Version="0.1.27",PrefabName="BA_BlindAbbot";
        static AbbotPlugin instance;
        public static string Folder=>global::Otherworld.Distribution.BundleRuntime.Data("BlindAbbotInGame");
        public static bool Ready=>instance&&instance.prefab&&instance.audioBank!=null&&instance.audioBank.Ready&&AbbotRoomBridge.HooksReady;
        public static bool EncounterEnabled=>instance&&instance.encounters.Value;
        public static float MaximumHealth=>instance?instance.health.Value:4000;
        public static float DamageMultiplier=>instance?instance.damage.Value:1;
        public static AudioMixerGroup NativeMixer{get;private set;}
        public static AbbotAudioBank AudioBank=>instance?.audioBank;
        public static Material NativeTemplate{get;private set;}
        public static RuntimeAnimatorController NativeController{get;private set;}
        public static AbbotSourceCombat SourceCombat{get;private set;}
        public static AbbotMotionRepertoire Repertoire{get;private set;}
        public static AbbotSourceControl SourceControl{get;private set;}
        public static AbbotCombatShapeBank CombatShapes{get;private set;}
        GameObject prefab;AbbotVisual visual;AbbotAudioBank audioBank;Harmony harmony;
        ConfigEntry<bool> encounters;ConfigEntry<float> health,damage,voiceVolume,voiceGain;string failure;bool attempted;
        public static void Log(string text){if(instance)instance.Logger.LogInfo(text);}
        void Awake()
        {
            global::Otherworld.Distribution.BundleRuntime.Initialize(this);

            instance=this;
            encounters=Config.Bind("Encounter","Enabled",true,"Enable the owned Abbot in R09; existing dungeon helper is retained.");
            health=Config.Bind("Balance","OriginalMaximumHealth",4000f,new ConfigDescription("Starting test balance; LastToll maximum is exactly40% of this value.",new AcceptableValueRange<float>(100,100000)));
            damage=Config.Bind("Balance","DamageMultiplier",1f,new ConfigDescription("Own authored attack damage multiplier.",new AcceptableValueRange<float>(.1f,5)));
            voiceVolume=Config.Bind("Audio","VoiceAndFoleyVolume",1f,new ConfigDescription("Owned sounds through native SFX/Master mixer.",new AcceptableValueRange<float>(0,1)));
            voiceGain=Config.Bind("Audio","BossVoiceGain",1f,new ConfigDescription("Independent speech trim after the louder arena voice mix; preserves player SFX/Master settings.",new AcceptableValueRange<float>(0,1)));
            harmony=new Harmony(Id);global::Otherworld.Distribution.BundleRuntime.PatchModule(harmony,typeof(AbbotPlugin));
            AbbotRoomBridge.InstallHooks(harmony);
            PrefabManager.OnVanillaPrefabsAvailable+=Register;
            CommandManager.Instance.AddConsoleCommand(new Command("twa_abbot_status",false,Status));
            CommandManager.Instance.AddConsoleCommand(new Command("twa_abbot_retry",true,()=>{if(!Ready){attempted=false;Register();}}));
            Log("BA_ABBOT_MODULE_READY: additive R09 actor module; no dungeon-helper replacement; no game test/capture invoked.");
        }
        void Register()
        {
            if(attempted||prefab)return;attempted=true;GameObject candidate=null;
            try{
                var source=PrefabManager.Instance.GetPrefab("Skeleton");if(!source)throw new InvalidOperationException("Native Skeleton unavailable.");
                var sourceBody=source.GetComponent<VisEquipment>()?.m_bodyModel;if(!sourceBody||!sourceBody.sharedMaterial)throw new InvalidOperationException("Native Creature material unavailable.");
                NativeTemplate=sourceBody.sharedMaterial;NativeController=source.GetComponentInChildren<Animator>(true)?.runtimeAnimatorController;
                if(!NativeController)throw new InvalidOperationException("Native Skeleton controller unavailable.");
                NativeMixer=ResolveMixer(source);
                audioBank=AbbotAudioBank.Initialize(Path.Combine(Folder,"audio","manifest.json"),Log);
                if(!audioBank.Ready)throw new InvalidOperationException("Voice bank is not ready: "+audioBank.Failure);
                candidate=PrefabManager.Instance.CreateClonedPrefab(PrefabName,source);candidate.SetActive(false);
                var humanoid=candidate.GetComponent<Humanoid>();var ai=candidate.GetComponent<MonsterAI>();var view=candidate.GetComponent<ZNetView>();
                if(!humanoid||!ai||!view)throw new InvalidOperationException("Native Character lifecycle unavailable.");
                AbbotNativeEffects.Apply(source,candidate,PrefabManager.Instance.GetPrefab("vfx_BloodHit"),Log);
                view.m_persistent=false;view.m_distant=false;
                var root=candidate.transform.Find("Visual");if(!root)throw new InvalidOperationException("Native Visual root unavailable.");
                root.gameObject.SetActive(false);
                foreach(Transform child in root.Cast<Transform>().ToArray())Object.DestroyImmediate(child.gameObject);
                foreach(var lod in root.GetComponents<LODGroup>())Object.DestroyImmediate(lod);
                foreach(var renderer in root.GetComponents<Renderer>())Object.DestroyImmediate(renderer);
                visual=AbbotVisual.Build(root,Folder,NativeTemplate,NativeController);
                Repertoire=AbbotMotionRepertoire.Load(AbbotVisual.Safe(Folder,"motion-repertoire.json"),visual.MotionBank);
                SourceControl=AbbotSourceControl.Load(AbbotVisual.Safe(Folder,"source-control.json"),visual.MotionBank);
                CombatShapes=AbbotModelFrame.LoadCombat(AbbotVisual.Safe(Folder,"combat-shapes.json"),visual.Payload);
                SourceCombat=AbbotSourceCombat.Load(AbbotVisual.Safe(Folder,"source-combat.json"),visual.MotionBank,Repertoire,CombatShapes);
                root.gameObject.SetActive(true);
                var equipment=candidate.GetComponent<VisEquipment>();
                if(equipment){
                    equipment.m_models=Array.Empty<VisEquipment.PlayerModel>();equipment.m_randomModelIndex=false;equipment.m_npcBeardChance=equipment.m_npcHairChance=0;
                    equipment.m_bodyModel=root.GetComponentsInChildren<SkinnedMeshRenderer>(true).First();
                    equipment.m_rightHand=visual.RightHand;equipment.m_leftHand=visual.Semantic("LeftHand");equipment.m_helmet=visual.Semantic("Head");
                    equipment.m_backMelee=equipment.m_backShield=equipment.m_backBow=equipment.m_backTool=equipment.m_backTwohandedMelee=equipment.m_backAtgeir=visual.Semantic("Spine2");
                }
                var animEvent=root.GetComponent<CharacterAnimEvent>();if(!animEvent)animEvent=root.gameObject.AddComponent<CharacterAnimEvent>();
                animEvent.m_lookAt=null;animEvent.m_leftShoulder=visual.Semantic("LeftShoulder");animEvent.m_rightShoulder=visual.Semantic("RightShoulder");
                animEvent.m_feets=new[]{new CharacterAnimEvent.Foot(visual.Semantic("LeftFoot"),AvatarIKGoal.LeftFoot),new CharacterAnimEvent.Foot(visual.Semantic("RightFoot"),AvatarIKGoal.RightFoot)};
                animEvent.m_eyes=Array.Empty<Transform>();humanoid.m_deathAnimation=false;
                foreach(var foot in candidate.GetComponentsInChildren<FootStep>(true))foot.m_feet=new[]{visual.Semantic("LeftFoot"),visual.Semantic("RightFoot")};
                humanoid.m_name="The Blind Abbot";humanoid.m_group="BlackAbbeyBlindAbbot";humanoid.m_health=MaximumHealth;humanoid.m_boss=true;humanoid.m_bossEvent="";humanoid.m_defeatSetGlobalKey="";
                humanoid.m_defaultItems=Array.Empty<GameObject>();humanoid.m_randomWeapon=Array.Empty<GameObject>();humanoid.m_randomShield=Array.Empty<GameObject>();humanoid.m_randomArmor=Array.Empty<GameObject>();humanoid.m_randomItems=Array.Empty<Humanoid.RandomItem>();humanoid.m_randomSets=Array.Empty<Humanoid.ItemSet>();
                humanoid.m_deathEffects=new EffectList{m_effectPrefabs=Array.Empty<EffectList.EffectData>()};
                var drops=candidate.GetComponent<CharacterDrop>();if(drops)drops.m_drops=new List<CharacterDrop.Drop>();
                ai.m_sleeping=false;ai.m_fallAsleepDistance=0;ai.enabled=false;
                var capsule=candidate.GetComponent<CapsuleCollider>();capsule.height=AbbotEncounterPolicy.CapsuleHeight;capsule.radius=AbbotEncounterPolicy.CapsuleRadius;capsule.center=new Vector3(0,AbbotEncounterPolicy.CapsuleCenterY,0);
                var body=candidate.GetComponent<Rigidbody>();if(body)body.mass*=AbbotEncounterPolicy.BodyScale*AbbotEncounterPolicy.BodyScale*AbbotEncounterPolicy.BodyScale;
                var eye=new GameObject("BA_Abbot_Eye").transform;eye.SetParent(candidate.transform,false);eye.localPosition=new Vector3(0,2.22f*AbbotEncounterPolicy.BodyScale,.03f*AbbotEncounterPolicy.BodyScale);humanoid.m_eye=eye;
                var marker=candidate.AddComponent<AbbotEncounterController>();
                PrefabManager.Instance.AddPrefab(new CustomPrefab(candidate,false));prefab=candidate;candidate.SetActive(true);
                PrefabManager.OnVanillaPrefabsAvailable-=Register;failure=null;
                Log("BA_ABBOT_REGISTERED: actual fitted actor, original pack/staff, warmed starred voices; R09-only localhost encounter. Loot selection remains TBD.");
            }catch(Exception error){if(candidate)Object.Destroy(candidate);visual?.Dispose();visual=null;prefab=null;failure=error.ToString();Log("BA_ABBOT_REGISTRATION_FAILED: no substitute actor spawned. "+failure);}
        }
        static AudioMixerGroup ResolveMixer(GameObject source)
        {
            var candidates=new List<GameObject>{source};
            var h=source.GetComponent<Humanoid>();
            foreach(var e in h.m_hitEffects?.m_effectPrefabs??Array.Empty<EffectList.EffectData>())if(e?.m_prefab)candidates.Add(e.m_prefab);
            var mace=PrefabManager.Instance.GetPrefab("skeleton_mace");if(mace)candidates.Add(mace);
            foreach(var candidate in candidates)foreach(var audio in candidate.GetComponentsInChildren<AudioSource>(true))if(audio.outputAudioMixerGroup)return audio.outputAudioMixerGroup;
            var groups=Resources.FindObjectsOfTypeAll<AudioMixerGroup>();var sfx=groups.FirstOrDefault(g=>g&&g.name.IndexOf("SFX",StringComparison.OrdinalIgnoreCase)>=0);
            if(!sfx)throw new InvalidOperationException("Native SFX mixer is not ready.");return sfx;
        }
        public static AbbotEncounterController Spawn(AbbotRoomBridge room)
        {
            if(!Ready||!room||!room.gameObject.activeInHierarchy||!ZNet.instance||!ZNet.instance.IsServer())return null;
            var point=room.RitualGoal+Vector3.up*.05f;
            if(!room.PlayerNearForSpawn()||!ZNetScene.InActiveArea(point,ZNet.instance.GetReferencePosition()))return null;
            var actor=Object.Instantiate(instance.prefab,point,room.RoomRoot.rotation);actor.SetActive(true);
            var control=actor.GetComponent<AbbotEncounterController>();try{control.Bind(room,AbbotBalanceBridge.Bind(actor.GetComponent<Character>(),MaximumHealth));return control;}catch{if(ZNetScene.instance)ZNetScene.instance.Destroy(actor);else Object.Destroy(actor);throw;}
        }
        public static float AudioVolume=>instance?instance.voiceVolume.Value:1;
        public static float BossVoiceGain=>instance?instance.voiceGain.Value:1;
        public static AbbotVisual BindVisual(Transform root)=>AbbotVisual.BindClone(root,instance.visual);
        void Status(){Print("BA_ABBOT_STATUS version="+Version+" ready="+Ready+" enabled="+EncounterEnabled+" failure="+(failure??"none"));foreach(var c in Object.FindObjectsByType<AbbotEncounterController>(FindObjectsSortMode.None))if(c&&c.IsBound)Print(c.Status());}
        void Print(string s){Log(s);if(Console.instance)Console.instance.AddString(s);}
        sealed class Command:ConsoleCommand
        {
            readonly string name;readonly bool cheat;readonly Action action;public Command(string n,bool c,Action a){name=n;cheat=c;action=a;}
            public override string Name=>name;public override string Help=>"Owned Blind Abbot readiness/status; retry only failed registration.";public override bool IsCheat=>cheat;public override bool OnlyServer=>cheat;public override void Run(string[] args)=>action();
        }
        void OnDestroy(){PrefabManager.OnVanillaPrefabsAvailable-=Register;AbbotRoomBridge.ReleaseModule();foreach(var c in Object.FindObjectsByType<AbbotEncounterController>(FindObjectsSortMode.None))if(c&&c.IsBound)c.Cancel("plugin shutdown");AbbotDeafenedLease.ShutdownAll();AbbotDungeonNavigation.Shutdown();AbbotBellTailLifetime.ShutdownAll();AbbotAudioBank.Shutdown();visual?.Dispose();harmony?.UnpatchSelf();if(instance==this)instance=null;}
    }
}
