using System;
using System.IO;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using Jotunn.Managers;
using BlackAbbey.CenserBrother;
using UnityEngine;
using UnityEngine.Audio;

namespace BlackAbbey.ProfanedAudio
{
    [BepInPlugin(Id,"Black Abbey The Profaned Audio",Version)]
    [BepInDependency(CenserPlugin.Id,"0.3.7")]
    public sealed class ProfanedAudioPlugin:BaseUnityPlugin
    {
        public const string Id="studio.otherworld.profanedaudio",Version="0.1.1";
        public static ProfanedAudioPlugin Instance;public static ProfanedAudioBank Bank;
        public static ProfanedOneShotPool Pool;public static AudioMixerGroup Mixer;
        public static ConfigEntry<float> Master,ChantVolume;public static ConfigEntry<bool> Enabled;
        Harmony harmony;bool failed;float checkAt;bool hadWorld;
        public static float Volume=>Enabled!=null&&Enabled.Value?Mathf.Clamp01(Master.Value):0;
        public static void Log(string s){if(Instance)Instance.Logger.LogInfo(s);}
        public static void Safe(Action f){try{f();}catch(Exception e){if(!Instance||Instance.failed)return;Instance.failed=true;Log("PROFANED_AUDIO_OBSERVER_ERROR "+e);}}
        void Awake()
        {
            global::Otherworld.Distribution.BundleRuntime.Initialize(this);

            Instance=this;Enabled=Config.Bind("Audio","Enabled",true,"Enable The Profaned own audio.");Master=Config.Bind("Audio","Volume",.85f,new ConfigDescription("Creature audio volume",new AcceptableValueRange<float>(0,1)));
            ChantVolume=Config.Bind("Audio","ChantVolume",1f,new ConfigDescription("Chant level relative to the other creature sounds",new AcceptableValueRange<float>(0,2)));
            try{
                Bank=new ProfanedAudioBank();Bank.Load(global::Otherworld.Distribution.BundleRuntime.Data("BlackAbbeyProfanedAudio"),AudioSourceHash.Manifest);
                Pool=new GameObject("The Profaned detached event audio").AddComponent<ProfanedOneShotPool>();Pool.transform.SetParent(transform,false);Pool.Bind(Bank,null);
                harmony=new Harmony(Id);global::Otherworld.Distribution.BundleRuntime.PatchModule(harmony,typeof(ProfanedAudioPlugin));
                PrefabManager.OnVanillaPrefabsAvailable+=ResolveMixer;
                Log("PROFANED_AUDIO_READY clips="+Bank.Clips.Count+" PCMbytes="+Bank.pcmBytes+" decodedFrames="+Bank.decodedFrames+" noMotionChanges=true");
            }catch(Exception e){harmony?.UnpatchSelf();Bank?.Dispose();Logger.LogError("PROFANED_AUDIO_LOAD_FAILED native gameplay retained "+e);}
        }
        void ResolveMixer()
        {
            var skeleton=PrefabManager.Instance.GetPrefab("Skeleton");if(!skeleton)return;
            Mixer=ProfanedNativeAudio.FindMixer(skeleton);Pool?.Bind(Bank,Mixer);
            ProfanedHooks.PrepareProjectile();
            Log("PROFANED_AUDIO_MIXER "+(Mixer?Mixer.name:"native SFX group unavailable; own actor audio attachment held")+" sharedMixerEdited=false");
        }
        void Update()
        {
            if(Time.time<checkAt)return;checkAt=Time.time+.5f;
            bool world=ZNetScene.instance;
            if(hadWorld&&!world)Pool?.StopAll();hadWorld=world;
        }
        void OnDestroy()
        {
            PrefabManager.OnVanillaPrefabsAvailable-=ResolveMixer;harmony?.UnpatchSelf();Pool?.StopAll();
            ProfanedAudioController.StopAll();ProfanedNativeAudio.Release();Bank?.Dispose();Bank=null;Instance=null;
        }
    }
}
