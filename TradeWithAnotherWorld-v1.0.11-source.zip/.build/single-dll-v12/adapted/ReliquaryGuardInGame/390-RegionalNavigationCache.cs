using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.AI;
using Object = UnityEngine.Object;

namespace Otherworld.Navigation.ReliquaryGuardInGame
{
    // This source is linked into each existing actor DLL. Its statics are
    // assembly-local: no cross-module lifetime/dependency or new DLL is needed.
    internal static class RegionalNavigationCache
    {
        internal const float RegionSpan = 72f, RegionSnap = 12f, RefreshSeconds = 1.5f;
        internal const int MaximumRecords = 256, MaximumConcurrentBuilds = 2;
        private static readonly Dictionary<Key, Record> entries = new Dictionary<Key, Record>();
        private static readonly List<Record> records = new List<Record>();
        private static readonly List<Record> poll = new List<Record>();
        private static RegionalNavigationDriver driver;
        private static ZNet network;
        private static ZNetScene scene;
        private static ZNet shutdownNetwork;
        private static ZNetScene shutdownScene;
        private static bool stopping;
        private static int lastFrame = -1, cursor, peakRecords, peakJobs, peakLeases;
        private static long scans, buildStarts, completions, cancellations, cacheHits, rejected;
        private static double scanTotalMs, scanMaximumMs, collectTotalMs, signatureTotalMs;
        private static float nextLog;
        private static Action<string> summaryLog;
        private static string summaryPrefix;

        [StructLayout(LayoutKind.Explicit)]
        private struct Bits
        {
            [FieldOffset(0)] internal float Value;
            [FieldOffset(0)] internal int Integer;
        }
        private static int BitPattern(float value) => new Bits { Value = value }.Integer;

        // Preserve exactly the previous effective private-build field set.
        // The native base agent identity is also keyed; distinct profiles never
        // merge merely because their dimensions happen to be close.
        internal struct Key : IEquatable<Key>
        {
            internal int X, Y, Z, Mask, BaseAgent, Height, Radius, Slope, Climb, Area, Voxel, Tile, Overrides;
            internal static Key Create(NavMeshBuildSettings p, Vector3 position, int mask) => new Key
            {
                X = Mathf.RoundToInt(position.x / RegionSnap), Y = Mathf.RoundToInt(position.y / RegionSnap), Z = Mathf.RoundToInt(position.z / RegionSnap),
                Mask = mask, BaseAgent = p.agentTypeID, Height = BitPattern(p.agentHeight), Radius = BitPattern(p.agentRadius),
                Slope = BitPattern(p.agentSlope), Climb = BitPattern(p.agentClimb), Area = BitPattern(p.minRegionArea),
                Voxel = BitPattern(p.voxelSize), Tile = p.tileSize, Overrides = (p.overrideVoxelSize ? 1 : 0) | (p.overrideTileSize ? 2 : 0)
            };
            internal Vector3 Center => new Vector3(X * RegionSnap, Y * RegionSnap, Z * RegionSnap);
            internal bool ContainsRegion(Vector3 p) => FinitePosition(p) && X == Mathf.RoundToInt(p.x / RegionSnap) && Y == Mathf.RoundToInt(p.y / RegionSnap) && Z == Mathf.RoundToInt(p.z / RegionSnap);
            public bool Equals(Key b) => X == b.X && Y == b.Y && Z == b.Z && Mask == b.Mask && BaseAgent == b.BaseAgent && Height == b.Height && Radius == b.Radius && Slope == b.Slope && Climb == b.Climb && Area == b.Area && Voxel == b.Voxel && Tile == b.Tile && Overrides == b.Overrides;
            public override bool Equals(object value) => value is Key other && Equals(other);
            public override int GetHashCode()
            {
                unchecked
                {
                    int h = X; h = h * 397 ^ Y; h = h * 397 ^ Z; h = h * 397 ^ Mask; h = h * 397 ^ BaseAgent;
                    h = h * 397 ^ Height; h = h * 397 ^ Radius; h = h * 397 ^ Slope; h = h * 397 ^ Climb;
                    h = h * 397 ^ Area; h = h * 397 ^ Voxel; h = h * 397 ^ Tile; return h * 397 ^ Overrides;
                }
            }
        }

        internal sealed class Record
        {
            internal Key Key;
            internal ZNet Network;
            internal ZNetScene Scene;
            internal NavMeshBuildSettings Settings;
            internal NavMeshData Data;
            internal NavMeshDataInstance Instance;
            internal AsyncOperation Operation;
            internal Action<AsyncOperation> Completion;
            internal List<NavMeshBuildSource> Sources;
            internal Action<string> Log;
            internal string Prefix, Failure;
            internal Bounds Bounds;
            internal Vector3 Origin;
            internal int References, Revision, SourceCount, Checks, Builds, Completed;
            internal ulong SourceSignature, RequestedSignature;
            internal float NextScan, BuildStarted, LongestBuild;
            internal bool Ready, Retiring, SettingsCreated, CancelRequested, Finalized;
        }

        internal sealed class Lease : IDisposable
        {
            private Record record;
            private bool disposed;
            internal Lease(Record source) { record = source; }
            internal bool Valid => !disposed && record != null && !record.Retiring && record.References > 0 && IsCurrent(record);
            internal bool Ready => Valid && record.Ready && record.Data && record.Instance.valid;
            internal bool Building => Valid && record.Operation != null && !record.Operation.isDone;
            internal bool Pending => Building;
            internal int Revision => Valid ? record.Revision : 0;
            internal NavMeshBuildSettings Settings => record != null ? record.Settings : default;
            internal Bounds WorldBounds => record != null ? record.Bounds : default;
            internal Vector3 Origin => record != null ? record.Origin : default;
            internal int SourceCount => record?.SourceCount ?? 0;
            internal int Checks => record?.Checks ?? 0;
            internal int Builds => record?.Builds ?? 0;
            internal int Completed => record?.Completed ?? 0;
            internal ulong SourceSignature => record?.SourceSignature ?? 0;
            internal float LongestBuild => record?.LongestBuild ?? 0;
            internal string Failure => record?.Failure;
            internal bool Matches(Vector3 position) => Valid && record.Key.ContainsRegion(position);
            public void Dispose()
            {
                if (disposed) return;
                disposed = true;
                var old = record;
                if (old == null || old.References <= 0) return;
                old.References--;
                if (old.References == 0) Retire(old, "last lease released");
            }
        }

        internal static Lease Acquire(NavMeshBuildSettings profile, Vector3 position, int sourceMask, Action<string> log, string prefix)
        {
            if (!FinitePosition(position) || !ValidProfile(profile) || sourceMask == 0 || !ZNet.instance || !ZNetScene.instance)
            { rejected++; return null; }
            ObserveSession();
            if (stopping) { rejected++; return null; }
            var key = Key.Create(profile, position, sourceMask);
            if (entries.TryGetValue(key, out var old) && !old.Retiring && IsCurrent(old))
            {
                old.References++; cacheHits++; ObservePeaks(); return new Lease(old);
            }
            if (records.Count >= MaximumRecords) { rejected++; return null; }
            Record record = null;
            try
            {
                EnsureDriver();
                record = new Record { Key = key, Network = network, Scene = scene, References = 1, Log = log, Prefix = string.IsNullOrEmpty(prefix) ? "ABBEY" : prefix, Origin = key.Center, Bounds = new Bounds(key.Center, Vector3.one * RegionSpan), NextScan = 0 };
                record.Settings = NavMesh.CreateSettings(); record.SettingsCreated = true;
                // Exactly the prior assignment path: leave the fresh native
                // settings defaults for ledgeDrop/jump/heightMesh/job workers.
                var settings = record.Settings;
                settings.agentHeight = profile.agentHeight; settings.agentRadius = profile.agentRadius;
                settings.agentSlope = profile.agentSlope; settings.agentClimb = profile.agentClimb; settings.minRegionArea = profile.minRegionArea;
                settings.overrideVoxelSize = profile.overrideVoxelSize; settings.voxelSize = profile.voxelSize;
                settings.overrideTileSize = profile.overrideTileSize; settings.tileSize = profile.tileSize;
                record.Settings = settings;
                record.Data = NewData(record);
                entries.Add(key, record); records.Add(record);
                if (summaryLog == null) { summaryLog = log; summaryPrefix = record.Prefix; }
                ObservePeaks(); return new Lease(record);
            }
            catch (Exception error)
            {
                if (record != null)
                {
                    if (record.Data) Object.Destroy(record.Data);
                    if (record.SettingsCreated) NavMesh.RemoveSettings(record.Settings.agentTypeID);
                }
                rejected++; SafeLog(log, (prefix ?? "ABBEY") + "_DUNGEON_NAV_SHARED_WAIT " + error.GetType().Name + ": " + error.Message);
                return null;
            }
        }

        private static NavMeshData NewData(Record record) => new NavMeshData(record.Settings.agentTypeID)
        { name = record.Prefix + " Shared Regional Dungeon Navigation", position = record.Origin, rotation = Quaternion.identity };

        internal static void Tick()
        {
            if (lastFrame == Time.frameCount) return;
            lastFrame = Time.frameCount;
            ObserveSession();
            // Completion and retirement are serviced even with no actor leases.
            // Native cancellation/registration may dispatch a completed callback
            // for another record. Reuse a bounded poll buffer rather than index
            // the mutating owning list or allocate a new array every frame.
            poll.Clear(); poll.AddRange(records);
            for (int i = poll.Count - 1; i >= 0; i--)
            {
                var record = poll[i];
                if (record.Finalized) continue;
                if (record.Operation != null && record.Operation.isDone) FinishOperation(record);
                if (record.Retiring) { FinalizeRetired(record); continue; }
                if (record.Ready && !record.Instance.valid)
                {
                    record.Ready = false;
                    // Existing data can be registered again without cooking a
                    // new region. A failed registration falls back to a rebuild.
                    if (record.Data && record.Operation == null)
                        try { Register(record); record.Revision++; }
                        catch (Exception error) { Fail(record, error); }
                }
            }
            poll.Clear();
            if (!stopping && CurrentJobs() < MaximumConcurrentBuilds)
            {
                var due = OldestDue();
                if (due != null) Scan(due); // At most one synchronous scan/frame.
            }
            ObservePeaks();
            if (Time.realtimeSinceStartup >= nextLog && records.Count > 0)
            {
                nextLog = Time.realtimeSinceStartup + 15f;
                SafeLog(summaryLog, (summaryPrefix ?? "ABBEY") + "_DUNGEON_NAV_SHARED: regions=" + entries.Count + "; leases=" + LeaseCount() + "; pending=" + CurrentJobs() + "; scans=" + scans + "; builds=" + buildStarts + "; completed=" + completions + "; reused=" + cacheHits + "; scanSyncTotalMs=" + scanTotalMs.ToString("F2") + "; scanSyncMaxMs=" + scanMaximumMs.ToString("F2") + "; async elapsed is not CPU; no FPS claim.");
            }
            DestroyDriverWhenEmpty();
        }

        private static Record OldestDue()
        {
            Record selected = null; int selectedIndex = -1, count = records.Count;
            for (int n = 0; n < count; n++)
            {
                int index = (cursor + n) % count; var r = records[index];
                if (r.Retiring || r.References <= 0 || r.Operation != null || !IsCurrent(r) || r.NextScan > Time.realtimeSinceStartup) continue;
                if (selected == null || r.NextScan < selected.NextScan) { selected = r; selectedIndex = index; }
            }
            if (selectedIndex >= 0) cursor = (selectedIndex + 1) % Math.Max(1, count);
            return selected;
        }

        private static void Scan(Record record)
        {
            var all = Stopwatch.StartNew(); record.NextScan = Time.realtimeSinceStartup + RefreshSeconds; record.Checks++; scans++;
            try
            {
                var sources = new List<NavMeshBuildSource>(); var collect = Stopwatch.StartNew();
                NavMeshBuilder.CollectSources(record.Bounds, record.Key.Mask, NavMeshCollectGeometry.PhysicsColliders, 0, new List<NavMeshBuildMarkup>(), sources);
                collectTotalMs += collect.Elapsed.TotalMilliseconds;
                var hashTime = Stopwatch.StartNew();
                sources.RemoveAll(s => s.component is Collider c && (!c.enabled || c.isTrigger || !c.gameObject.activeInHierarchy));
                if (sources.Count == 0 || sources.Count > 4096) throw new InvalidOperationException("No valid bounded dungeon collision sources, or source limit exceeded.");
                sources.Sort((a, b) => (a.component ? a.component.GetInstanceID() : 0).CompareTo(b.component ? b.component.GetInstanceID() : 0));
                ulong signature = Signature(sources); signatureTotalMs += hashTime.Elapsed.TotalMilliseconds;
                if (record.Ready && record.Instance.valid && signature == record.SourceSignature) return;
                record.SourceCount = sources.Count; record.RequestedSignature = signature;
                record.Sources = sources;
                if (!record.Data) record.Data = NewData(record);
                record.BuildStarted = Time.realtimeSinceStartup;
                record.Operation = NavMeshBuilder.UpdateNavMeshDataAsync(record.Data, record.Settings, record.Sources, new Bounds(Vector3.zero, Vector3.one * RegionSpan));
                if (record.Operation == null) throw new InvalidOperationException("Shared asynchronous nav bake did not start.");
                record.Builds++; buildStarts++; record.CancelRequested = false;
                record.Completion = operation => { if (record.Retiring && ReferenceEquals(record.Operation, operation) && operation.isDone) FinishOperation(record); };
                record.Operation.completed += record.Completion;
                // Unity may return an already-completed operation.
                if (record.Operation != null && record.Operation.isDone) FinishOperation(record);
            }
            catch (Exception error) { Fail(record, error); }
            finally { double ms = all.Elapsed.TotalMilliseconds; scanTotalMs += ms; scanMaximumMs = Math.Max(scanMaximumMs, ms); }
        }

        private static ulong Signature(List<NavMeshBuildSource> sources)
        {
            unchecked
            {
                ulong hash = 1469598103934665603;
                foreach (var source in sources)
                {
                    hash = (hash ^ (uint)(source.component ? source.component.GetInstanceID() : 0)) * 1099511628211;
                    hash = (hash ^ (uint)(source.sourceObject ? source.sourceObject.GetInstanceID() : 0)) * 1099511628211;
                    hash = (hash ^ (uint)source.shape) * 1099511628211; hash = (hash ^ (uint)source.area) * 1099511628211;
                    hash = (hash ^ (uint)source.size.GetHashCode()) * 1099511628211;
                    var matrix = source.transform;
                    for (int i = 0; i < 16; i++) hash = (hash ^ (uint)matrix[i].GetHashCode()) * 1099511628211;
                }
                return hash;
            }
        }

        private static void FinishOperation(Record record)
        {
            var operation = record.Operation;
            if (operation == null || !operation.isDone) return;
            if (record.Completion != null) operation.completed -= record.Completion;
            record.Operation = null; record.Completion = null; record.Sources = null;
            if (record.Retiring || !IsCurrent(record)) { Retire(record, "completion belongs to retired session"); FinalizeRetired(record); return; }
            record.Completed++; completions++; record.SourceSignature = record.RequestedSignature;
            record.LongestBuild = Mathf.Max(record.LongestBuild, Time.realtimeSinceStartup - record.BuildStarted);
            try { Register(record); record.Revision++; record.Failure = null; }
            catch (Exception error) { Fail(record, error); }
        }

        private static void Register(Record record)
        {
            if (!record.Instance.valid)
            {
                record.Instance = NavMesh.AddNavMeshData(record.Data);
                if (record.Instance.valid && driver) record.Instance.owner = driver.gameObject;
            }
            record.Ready = record.Data && record.Instance.valid;
            if (!record.Ready) throw new InvalidOperationException("Completed shared nav data did not register.");
        }

        private static void Fail(Record record, Exception error)
        {
            record.Ready = false;
            if (record.Instance.valid) record.Instance.Remove();
            string message = error.GetType().Name + ": " + error.Message;
            if (record.Failure != message) SafeLog(record.Log, record.Prefix + "_DUNGEON_NAV_SHARED_FAILED " + message);
            record.Failure = message; record.NextScan = Time.realtimeSinceStartup + 5f;
            // Never free a source list/data/settings while native work still
            // references them. Normal admission never has two jobs per record.
            if (record.Operation == null) record.Sources = null;
        }

        private static void Retire(Record record, string reason)
        {
            if (!record.Retiring)
            {
                record.Retiring = true; record.Ready = false;
                if (entries.TryGetValue(record.Key, out var current) && ReferenceEquals(current, record)) entries.Remove(record.Key);
                if (record.Instance.valid) record.Instance.Remove();
            }
            if (record.Operation != null && !record.Operation.isDone && !record.CancelRequested)
            {
                record.CancelRequested = true; cancellations++;
                try { if (record.Data) NavMeshBuilder.Cancel(record.Data); }
                catch (Exception error) { record.Failure = "Cancel pending: " + error.Message; }
            }
            // Cancel(data) is not documented as synchronous. Hold the operation,
            // native data/settings and source list until isDone/completed.
            FinalizeRetired(record);
        }

        private static void FinalizeRetired(Record record)
        {
            if (record.Finalized || !record.Retiring || record.Operation != null && !record.Operation.isDone) return;
            if (record.Operation != null && record.Completion != null) record.Operation.completed -= record.Completion;
            record.Operation = null; record.Completion = null; record.Sources = null;
            if (record.Instance.valid) record.Instance.Remove();
            if (record.Data) Object.Destroy(record.Data); record.Data = null;
            if (record.SettingsCreated) { NavMesh.RemoveSettings(record.Settings.agentTypeID); record.SettingsCreated = false; }
            record.Finalized = true;
            records.Remove(record);
        }

        private static bool IsCurrent(Record record) => ZNet.instance && ZNetScene.instance && ReferenceEquals(record.Network, ZNet.instance) && ReferenceEquals(record.Scene, ZNetScene.instance);
        private static void ObserveSession()
        {
            var currentNetwork = ZNet.instance; var currentScene = ZNetScene.instance;
            bool valid = currentNetwork && currentScene;
            if (valid && ReferenceEquals(network, currentNetwork) && ReferenceEquals(scene, currentScene)) return;
            foreach (var record in records.ToArray()) Retire(record, "native session changed");
            network = valid ? currentNetwork : null; scene = valid ? currentScene : null;
            if (valid && (!ReferenceEquals(shutdownNetwork, network) || !ReferenceEquals(shutdownScene, scene))) stopping = false;
        }

        private static void EnsureDriver()
        {
            if (driver) return;
            var root = new GameObject("Black Abbey regional navigation | " + "ReliquaryGuardInGame");
            root.hideFlags = HideFlags.HideAndDontSave; Object.DontDestroyOnLoad(root);
            driver = root.AddComponent<RegionalNavigationDriver>();
        }
        private static void DestroyDriverWhenEmpty()
        {
            if (records.Count != 0 || !driver) return;
            var old = driver; driver = null; Object.Destroy(old.gameObject);
        }
        internal static void DriverDestroyed(RegionalNavigationDriver value)
        {
            if (!ReferenceEquals(driver, value)) return;
            driver = null;
            foreach (var record in records.ToArray()) Retire(record, "cleanup driver destroyed");
        }
        internal static void Shutdown()
        {
            stopping = true; shutdownNetwork = ZNet.instance; shutdownScene = ZNetScene.instance;
            foreach (var record in records.ToArray()) Retire(record, "module shutdown");
            // Driver remains active while cancelled jobs have not completed.
            DestroyDriverWhenEmpty();
        }

        private static int CurrentJobs() { int value = 0; foreach (var record in records) if (record.Operation != null && !record.Operation.isDone) value++; return value; }
        private static int LeaseCount() { int value = 0; foreach (var record in records) if (!record.Retiring) value += record.References; return value; }
        private static void ObservePeaks() { peakRecords = Math.Max(peakRecords, records.Count); peakJobs = Math.Max(peakJobs, CurrentJobs()); peakLeases = Math.Max(peakLeases, LeaseCount()); }
        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        private static bool FinitePosition(Vector3 p) => Finite(p.x) && Finite(p.y) && Finite(p.z) && Mathf.Abs(p.x) <= 10000000f && Mathf.Abs(p.y) <= 10000000f && Mathf.Abs(p.z) <= 10000000f;
        private static bool ValidProfile(NavMeshBuildSettings p) => Finite(p.agentHeight) && p.agentHeight > 0 && Finite(p.agentRadius) && p.agentRadius > 0 && Finite(p.agentSlope) && p.agentSlope >= 0 && p.agentSlope <= 90 && Finite(p.agentClimb) && p.agentClimb >= 0 && Finite(p.minRegionArea) && p.minRegionArea >= 0 && Finite(p.voxelSize) && p.voxelSize > 0 && p.tileSize > 0;
        private static void SafeLog(Action<string> log, string text) { try { log?.Invoke(text); } catch { } }
        internal static object Snapshot() => new
        {
            regions = entries.Count, retainedRecords = records.Count, leases = LeaseCount(), pending = CurrentJobs(),
            maximumRecords = MaximumRecords, maximumConcurrentBuilds = MaximumConcurrentBuilds, maximumScansPerFrame = 1,
            scans, builds = buildStarts, completed = completions, cancellations, reusedAcquires = cacheHits, rejectedAcquires = rejected,
            scanSynchronousTotalMs = scanTotalMs, scanSynchronousMaximumMs = scanMaximumMs, collectSynchronousTotalMs = collectTotalMs, sortSignatureSynchronousTotalMs = signatureTotalMs,
            peakRecords, peakJobs, peakLeases, stopping,
            scope = "Assembly-local exact-profile/fixed-region leases; one synchronous collider scan admission/frame and at most two native async updates. Timing is API wall time, not CPU/GPU/FPS proof."
        };
    }

    [DefaultExecutionOrder(-7000)]
    internal sealed class RegionalNavigationDriver : MonoBehaviour
    {
        private void Update() => RegionalNavigationCache.Tick();
        private void OnDestroy() => RegionalNavigationCache.DriverDestroyed(this);
        private void OnApplicationQuit() => RegionalNavigationCache.Shutdown();
    }
}
