using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx;
using Jotunn.Entities;
using Jotunn.Managers;
using Newtonsoft.Json;
using UnityEngine;
using HarmonyLib;
using Object=UnityEngine.Object;

namespace BlackAbbey.ReliquaryGuard
{
    [BepInPlugin(Id,"Black Abbey Reliquary Guard Test",Version)]
    [BepInDependency(Jotunn.Main.ModGuid,"2.30.2")]
    public sealed class GuardPlugin:BaseUnityPlugin
    {
        public const string Id="studio.otherworld.reliquaryguardtest",Version="0.5.8",PrefabName="BA_ReliquaryGuard",SwordName="BA_ReliquaryGuard_Sword",ShieldName="BA_ReliquaryGuard_Shield";
        GuardVisual visual;GameObject prefab;bool attempted;Harmony harmony;static GuardPlugin instance;
        GuardAudioBank audioBank;
        public static void AttachAudio(GameObject actor){if(instance)GuardAudioController.Attach(actor,instance.audioBank,GuardAudioHooks.CreatureMixer);}
        public static object AudioStatus()=>new{bank=instance?.audioBank?.Snapshot(),actors=GuardAudioController.Snapshots(),contactHook=GuardAudioHooks.MeleeContactHookReady};
        string Folder=>global::Otherworld.Distribution.BundleRuntime.Data("ReliquaryGuardInGame");
        public static void Log(string s){if(instance)instance.Logger.LogInfo(s);}
        void Print(string s){Log(s);if(Console.instance)Console.instance.AddString(s);}
        void Awake(){
            global::Otherworld.Distribution.BundleRuntime.Initialize(this);
instance=this;harmony=new Harmony(Id);global::Otherworld.Distribution.BundleRuntime.PatchModule(harmony,typeof(GuardPlugin));PrefabManager.OnVanillaPrefabsAvailable+=Register;CommandManager.Instance.AddConsoleCommand(new Command("twa_guard_audio_status",false,()=>Print(JsonConvert.SerializeObject(AudioStatus()))));CommandManager.Instance.AddConsoleCommand(new Command("twa_guard_spawn",true,Spawn));CommandManager.Instance.AddConsoleCommand(new Command("twa_guard_remove",true,Remove));CommandManager.Instance.AddConsoleCommand(new Command("twa_guard_status",false,Status));CommandManager.Instance.AddConsoleCommand(new Command("twa_guard_death_status",false,()=>Print(JsonConvert.SerializeObject(GuardDeathPresentation.Snapshot()))));CommandManager.Instance.AddConsoleCommand(new Command("twa_guard_nav_status",false,()=>{foreach(var n in Object.FindObjectsByType<GuardDungeonNavigation>(FindObjectsSortMode.None))Print(JsonConvert.SerializeObject(n.Snapshot()));}));Log("RG_PLUGIN_READY version="+Version+" manualOnly=true naturalSpawns=false");}
        sealed class Command:ConsoleCommand
        {
            readonly string name;readonly bool host;readonly Action action;
            internal Command(string n,bool h,Action a){name=n;host=h;action=a;}
            public override string Name=>name;public override string Help=>name=="twa_guard_spawn"?"Spawn one equipped Reliquary Guard six metres ahead (devcommands, host; native shielded Draugr profile).":name=="twa_guard_remove"?"Remove only nearby Reliquary Guard test actors.":"Report Guard source, sword/shield equipment and native Draugr AI.";
            public override bool IsCheat=>host;public override bool OnlyServer=>host;public override void Run(string[] args)=>action();
        }
        static GameObject Required(string name){var p=PrefabManager.Instance.GetPrefab(name);if(!p)throw new InvalidOperationException("Native prefab unavailable:"+name);return p;}
        void Register()
        {
            if(attempted||prefab)return;attempted=true;GameObject enemy=null;
            try{
                string manifest=Path.Combine(Folder,"guard-visual.json");var payload=GuardSourceContract.Require(manifest);
                var source=Required("Draugr");var nativeBody=source.GetComponent<VisEquipment>()?.m_bodyModel;if(!nativeBody||!nativeBody.sharedMaterial)throw new InvalidOperationException("Draugr body material unavailable");
                enemy=PrefabManager.Instance.CreateClonedPrefab(PrefabName,source);enemy.SetActive(false);if(enemy.activeInHierarchy)throw new InvalidOperationException("Build Guard on an inactive prefab only");var h=enemy.GetComponent<Humanoid>();var ai=enemy.GetComponent<MonsterAI>();if(!h||!ai||!enemy.GetComponent<ZNetView>())throw new InvalidOperationException("Native Draugr lifecycle missing");
                visual=ReplaceVisual(enemy,payload,nativeBody.sharedMaterial);
                var sword=Item(SwordName,"draugr_axe","Reliquary Sword","Sword");var shield=Item(ShieldName,"ShieldBanded","Reliquary Shield","Shield");
                h.m_name="Reliquary Guard";h.m_group="BlackAbbeyReliquaryGuard";h.m_boss=false;h.m_bossEvent="";h.m_defeatSetGlobalKey="";
                h.m_defaultItems=new[]{sword.ItemPrefab,shield.ItemPrefab};h.m_randomWeapon=Array.Empty<GameObject>();h.m_randomShield=Array.Empty<GameObject>();h.m_randomArmor=Array.Empty<GameObject>();h.m_randomItems=Array.Empty<Humanoid.RandomItem>();h.m_randomSets=Array.Empty<Humanoid.ItemSet>();h.m_unarmedWeapon=sword.ItemDrop;
                ai.m_sleeping=false;ai.m_fallAsleepDistance=0;
                h.m_perfectBlockEffect=Required("Player").GetComponent<Humanoid>().m_perfectBlockEffect;
                enemy.AddComponent<GuardCombat>();
                h.m_deathEffects=GuardRedDeathEffects.Build(source,Required("Player"));h.m_hitEffects=GuardRedDeathEffects.Build(source,Required("Player"),true);
                var drops=enemy.GetComponent<CharacterDrop>();if(drops)drops.m_drops=new List<CharacterDrop.Drop>();
                var settings=GuardSourceContract.Presentation(Path.Combine(Folder,"presentation.json"));var presentation=GuardPresentationPose.Configure(visual,settings);
                var cap=enemy.GetComponent<CapsuleCollider>();if(!cap)throw new InvalidOperationException("Native character capsule missing");cap.height=settings.capsuleHeight;cap.radius=settings.capsuleRadius;cap.center=new Vector3(0,settings.capsuleHeight*.5f,0);
                var eye=new GameObject("RG_Eye").transform;eye.SetParent(enemy.transform,false);eye.localPosition=new Vector3(0,settings.eyeHeight,.055f);h.m_eye=eye;
                var marker=enemy.AddComponent<GuardInstance>();marker.payloadSha256=GuardVisual.Hash(manifest);
                marker.presentation=null;marker.fingerGrip=GuardPlayerFingerGrip.Configure(visual);marker.shieldFit=GuardPlayerShieldFit.Configure(visual);GuardPlayerAnimationBindings.Configure(enemy,Required("Player"),visual.Animator);var deathAudit=GuardDeathPresentation.Prepare(enemy,Required("Greyling"));
                audioBank=GuardAudioBank.Initialize(Path.Combine(Folder,"audio","guard-audio.json"),Log);
                if(audioBank.Ready&&GuardAudioHooks.ResolveNativeCreatureMixer(source,Required("draugr_axe"))){
                    var audioAudit=GuardAudioHooks.PrepareOwnedClones(source,enemy,Required("draugr_axe").GetComponent<ItemDrop>(),sword.ItemDrop);
                    GuardAudioHooks.PrepareShield(shield.ItemDrop);
                    Log("RG_AUDIO_PREPARED "+JsonConvert.SerializeObject(audioAudit));
                }else Log("RG_AUDIO_DISABLED; inherited sounds retained: "+audioBank.Failure);
                var sync=enemy.GetComponent<ZSyncAnimation>();if(sync)foreach(string key in new[]{"wakeup","emote_sit"})if(!sync.m_syncBools.Contains(key))sync.m_syncBools.Add(key);
                enemy.AddComponent<GuardRestingStart>();
                var audit=AIProfile(enemy,source);if(!audit.passed)throw new InvalidOperationException("Guard AI differs from Draugr outside declared awake overrides");
                PrefabManager.Instance.AddPrefab(new CustomPrefab(enemy,false));prefab=enemy;if(!prefab.transform.parent||prefab.transform.parent.gameObject.activeInHierarchy)throw new InvalidOperationException("Registered Guard prefab must stay under Jotunn's inactive container");prefab.SetActive(true);PrefabManager.OnVanillaPrefabsAvailable-=Register;
                string evidence=Path.Combine(BepInEx.Paths.PluginPath,"ReliquaryGuardInGame","evidence");Directory.CreateDirectory(evidence);File.WriteAllText(Path.Combine(evidence,"registration.json"),JsonConvert.SerializeObject(new{version=Version,prefab=PrefabName,source="Draugr",payloadSha256=marker.payloadSha256,sourceNativeSha256=payload.sourceNative.sha256,avatarValid=visual.Avatar.isValid,avatarHuman=visual.Avatar.isHuman,controller=visual.Animator.runtimeAnimatorController.name,bodyTriangles=payload.bodyTriangles,totalTriangles=payload.totalTriangles,health=h.m_health,ai=audit,sword=new{source="draugr_axe",prefab=SwordName,attack=sword.ItemDrop.m_itemData.m_shared.m_attack.m_attackAnimation},shield=new{source="ShieldBanded",prefab=ShieldName},presentation=settings,death=deathAudit,manualOnly=true,naturalSpawns=false,loot=false,customCorpse=true,ownDungeonNavigation=true,animationSource="Player",playerControllerMotion=true,customShieldWristFit=true,heldFingerGrip=true},Formatting.Indented));
                Print("Reliquary Guard ready: own sword/shield, native Draugr AI with player animations. Use twa_guard_spawn.");
            }catch(Exception ex){if(enemy)Object.Destroy(enemy);prefab=null;visual?.Dispose();visual=null;Logger.LogError("RG_REGISTRATION_FAILED; no Guard spawned: "+ex);Print("Guard setup failed. Check LogOutput.log; no substitute actor was spawned.");}
        }
        CustomItem Item(string name,string source,string display,string role)
        {
            var item=new CustomItem(name,source);if(!item.ItemDrop||!item.ItemPrefab)throw new InvalidOperationException("Native item clone failed:"+source);
            var original=Required(source).GetComponent<ItemDrop>().m_itemData;item.ItemDrop.m_itemData=original.Clone();var data=item.ItemDrop.m_itemData;data.m_dropPrefab=item.ItemPrefab;
            data.m_shared=(ItemDrop.ItemData.SharedData)typeof(object).GetMethod("MemberwiseClone",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(original.m_shared,null);var shared=data.m_shared;shared.m_name=display;shared.m_description="Reliquary Guard test equipment";shared.m_useDurability=false;shared.m_attack=original.m_shared.m_attack?.Clone();shared.m_secondaryAttack=original.m_shared.m_secondaryAttack?.Clone();
            // Clone the native animation tokens exactly; no custom attack clip.
            if(role=="Sword"){
                var playerSword=Required("SwordIron").GetComponent<ItemDrop>().m_itemData.m_shared;
                shared.m_animationState=playerSword.m_animationState;shared.m_attack.m_attackAnimation=playerSword.m_attack.m_attackAnimation;shared.m_attack.m_attackChainLevels=playerSword.m_attack.m_attackChainLevels;shared.m_attack.m_attackRandomAnimations=playerSword.m_attack.m_attackRandomAnimations;shared.m_attack.m_lastChainDamageMultiplier=1f;
                // Keep the existing damage, AI ranges and attack properties;
                // use the player's real three swing trigger names. Do not add
                // the player's final-combo damage multiplier to an AI change.
            }
            var attach=item.ItemPrefab.transform.Find("attach");if(!attach)throw new InvalidOperationException("Native item has no attach root:"+source);
            foreach(Transform child in attach.Cast<Transform>().ToArray())Object.DestroyImmediate(child.gameObject);
            foreach(var component in attach.GetComponents<Renderer>())Object.DestroyImmediate(component);foreach(var component in attach.GetComponents<MeshFilter>())Object.DestroyImmediate(component);
            visual.BuildItem(attach,visual.Payload.items.Single(r=>r.role==role));
            if(!ItemManager.Instance.AddItem(item))throw new InvalidOperationException("Own item registration failed:"+name);return item;
        }
        GuardVisual ReplaceVisual(GameObject enemy,GuardPayload payload,Material template)
        {
            var root=enemy.transform.Find("Visual");if(!root)throw new InvalidOperationException("Draugr Visual root missing");var old=root.GetComponentsInChildren<Animator>(true).Single();var playerAnimator=Required("Player").GetComponentInChildren<Animator>(true);var controller=playerAnimator.runtimeAnimatorController;if(!controller)throw new InvalidOperationException("Native Draugr controller missing");var evt=playerAnimator.GetComponent<CharacterAnimEvent>();if(!evt)throw new InvalidOperationException("Native animation-event component missing");string eventJson=JsonUtility.ToJson(evt);var footNames=evt.m_feets?.Select(f=>f.m_transform?f.m_transform.name:null).ToArray();
            var foot=enemy.GetComponentsInChildren<FootStep>(true).FirstOrDefault();string footJson=foot?JsonUtility.ToJson(foot):null;
            root.gameObject.SetActive(false);foreach(Transform child in root.Cast<Transform>().ToArray())Object.DestroyImmediate(child.gameObject);foreach(var lod in root.GetComponents<LODGroup>())Object.DestroyImmediate(lod);foreach(var renderer in root.GetComponents<Renderer>())Object.DestroyImmediate(renderer);
            var result=GuardVisual.Build(root,payload,template,Folder,false);result.Animator.runtimeAnimatorController=controller;result.Animator.SetBool("wakeup",false);
            var events=root.GetComponent<CharacterAnimEvent>();if(!events)events=root.gameObject.AddComponent<CharacterAnimEvent>();JsonUtility.FromJsonOverwrite(eventJson,events);events.m_lookAt=null;events.m_femaleHack=false;events.m_leftShoulder=result.Named["LeftShoulder"];events.m_rightShoulder=result.Named["RightShoulder"];
            if(events.m_feets!=null)for(int i=0;i<events.m_feets.Length;i++){string name=footNames[i];if(string.IsNullOrEmpty(name))throw new InvalidOperationException("Native foot event has no transform");string side=name.IndexOf("left",StringComparison.OrdinalIgnoreCase)>=0?"LeftFoot":name.IndexOf("right",StringComparison.OrdinalIgnoreCase)>=0?"RightFoot":null;if(side==null)throw new InvalidOperationException("Unrecognized native foot interface:"+name);events.m_feets[i].m_transform=result.Named[side];}
            if(footJson!=null){var step=enemy.GetComponentsInChildren<FootStep>(true).FirstOrDefault()??root.gameObject.AddComponent<FootStep>();JsonUtility.FromJsonOverwrite(footJson,step);step.m_feet=new[]{result.Named["LeftFoot"],result.Named["RightFoot"]};}
            var equipment=enemy.GetComponent<VisEquipment>();equipment.m_bodyModel=result.Skins[0];equipment.m_rightHand=result.Named["RightHand_Attach"];equipment.m_leftHand=result.Named["LeftHand_Attach"];equipment.m_randomModelIndex=false;equipment.m_models=Array.Empty<VisEquipment.PlayerModel>();equipment.m_npcBeardChance=0;equipment.m_npcHairChance=0;equipment.m_helmet=result.Named["Head"];
            equipment.m_backMelee=equipment.m_backShield=equipment.m_backBow=equipment.m_backTool=equipment.m_backTwohandedMelee=equipment.m_backAtgeir=result.Named["Spine2"];
            root.gameObject.SetActive(true);return result;
        }
        public sealed class ProfileAudit{public bool passed;public object[] fields;}
        static ProfileAudit AIProfile(GameObject own,GameObject source){var rows=new List<object>();bool ok=true;foreach(var type in new[]{typeof(MonsterAI),typeof(Character)})foreach(var field in type.GetFields(BindingFlags.Public|BindingFlags.Instance).Where(f=>(f.FieldType.IsPrimitive||f.FieldType.IsEnum)&&!new[]{"m_sleeping","m_fallAsleepDistance","m_boss"}.Contains(f.Name))){object a=field.GetValue(own.GetComponent(type)),b=field.GetValue(source.GetComponent(type));bool same=Equals(a,b);ok&=same;rows.Add(new{field=type.Name+"."+field.Name,actual=a,expected=b,equal=same});}return new ProfileAudit{passed=ok,fields=rows.ToArray()};}
        bool Host(out Player p){p=Player.m_localPlayer;if(!p||!ZNet.instance||!ZNet.instance.IsServer()||!ZNetScene.instance){Print("Use as the local host with a loaded character.");return false;}if(!prefab){Print("Guard prefab is not ready. Check twa_guard_status.");return false;}return true;}
        void Spawn(){if(!Host(out var p))return;if(Object.FindObjectsByType<GuardInstance>(FindObjectsSortMode.None).Count(g=>g&&g.gameObject.activeInHierarchy)>=3){Print("Three test Guards are already present; use twa_guard_remove.");return;}Vector3 f=Vector3.ProjectOnPlane(p.transform.forward,Vector3.up).normalized;if(f.sqrMagnitude<.5f)f=Vector3.forward;Vector3 at=p.transform.position+f*6;if(!Physics.Raycast(at+Vector3.up*2,Vector3.down,out var hit,5,LayerMask.GetMask("terrain","static_solid","piece"))||Vector3.Dot(hit.normal,Vector3.up)<.85f){Print("Find flat ground/floor six metres ahead.");return;}at.y=hit.point.y+.05f;var actor=Object.Instantiate(prefab,at,Quaternion.LookRotation(-f));actor.SetActive(true);Print("Spawned an equipped hostile Reliquary Guard six metres ahead. Remove with twa_guard_remove.");}
        void Remove(){if(!Host(out var p))return;int count=0;foreach(var g in Object.FindObjectsByType<GuardInstance>(FindObjectsSortMode.None)){if(!g||!g.gameObject.activeInHierarchy||(g.transform.position-p.transform.position).sqrMagnitude>10000)continue;var view=g.GetComponent<ZNetView>();if(!view||!view.IsValid()||!view.IsOwner())continue;ZNetScene.instance.Destroy(g.gameObject);count++;}Print("Removed "+count+" nearby owned Guard test actors.");}
        void Status(){Print("RG_STATUS version="+Version+" ready="+(prefab!=null)+" naturalSpawns=false source=Draugr");foreach(var g in Object.FindObjectsByType<GuardInstance>(FindObjectsSortMode.None))if(g&&g.gameObject.activeInHierarchy)Print(g.Status());}
        void OnDestroy(){PrefabManager.OnVanillaPrefabsAvailable-=Register;harmony?.UnpatchSelf();GuardAudioController.Shutdown();GuardAudioHooks.ReleaseOwnedEffectForks();GuardAudioBank.Shutdown();GuardDungeonNavigation.Shutdown();GuardDeathPresentation.Shutdown();GuardRedDeathEffects.Shutdown();visual?.Dispose();if(instance==this)instance=null;}
    }
    [DefaultExecutionOrder(10000)]
    public sealed class GuardInstance:MonoBehaviour
    {
        public string payloadSha256;public GuardPresentationPose presentation;public GuardPlayerFingerGrip fingerGrip;public GuardPlayerShieldFit shieldFit;Humanoid humanoid;float strength=1;
        void Start(){humanoid=GetComponent<Humanoid>();GuardDungeonNavigation.Attach(gameObject,GuardPlugin.Log);GuardPlugin.AttachAudio(gameObject);}
        void LateUpdate(){if(!humanoid)humanoid=GetComponent<Humanoid>();float target=humanoid&&(humanoid.InAttack()||humanoid.IsStaggering())?0:1;strength=Mathf.MoveTowards(strength,target,Time.deltaTime*8);if(presentation)presentation.Apply(strength);}
        public void ApplyForDeathSnapshot(){if(shieldFit)shieldFit.Apply();if(fingerGrip)fingerGrip.Apply();if(presentation)presentation.Apply(strength);}
        public string Status(){var h=GetComponent<Humanoid>();var shield=h?h.LeftItem:null;return "RG_ACTOR name="+name+" health="+(h?h.GetHealth():0)+" weapon="+(h?.GetCurrentWeapon()?.m_dropPrefab?h.GetCurrentWeapon().m_dropPrefab.name:"none")+" shield="+(shield?.m_dropPrefab?shield.m_dropPrefab.name:"none")+" blocking="+(h&&h.IsBlocking())+" payload="+payloadSha256+" combat="+GetComponent<GuardCombat>()?.Status()+" "+GetComponent<GuardRestingStart>()?.Status();}
    }
}

