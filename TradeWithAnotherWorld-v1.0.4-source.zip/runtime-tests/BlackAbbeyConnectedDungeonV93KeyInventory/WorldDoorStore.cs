using System;
using System.IO;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlackAbbeySixRooms
{
    // Host-owned world sidecar. Player recovery files are independent.
    internal sealed class WorldDoorState
    {
        public int schemaVersion = 1;
        public string worldKey;
        public float[] position, rotation;
        public int? dungeonSeed;
        public string catalogSha256;
    }
    internal sealed class WorldDoorStore
    {
        const int MaximumBytes = 16384;
        readonly string root;
        static readonly UTF8Encoding Utf8 = new UTF8Encoding(false, true);
        internal WorldDoorStore(string root) { this.root = Path.GetFullPath(root); }
        string FileFor(string world)
        {
            if (string.IsNullOrWhiteSpace(world) || Utf8.GetByteCount(world) > 4096) throw new InvalidDataException("Missing/oversized world identity.");
            using (var sha = SHA256.Create())
                return Path.Combine(root, BitConverter.ToString(sha.ComputeHash(Utf8.GetBytes(world))).Replace("-", "").ToLowerInvariant()+".json");
        }
        internal WorldDoorState Load(string world)
        {
            string file = FileFor(world);
            if (!File.Exists(file)) return null;
            if (new FileInfo(file).Length > MaximumBytes) throw new InvalidDataException("World door record is oversized; retained unchanged.");
            using (var stream = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                var bytes = new byte[MaximumBytes + 1]; int count = 0, n;
                while (count < bytes.Length && (n = stream.Read(bytes, count, bytes.Length-count)) > 0) count += n;
                if (count > MaximumBytes) throw new InvalidDataException("World door record is oversized; retained unchanged.");
                return Decode(Utf8.GetString(bytes, 0, count).TrimStart('\uFEFF'), world);
            }
        }
        static WorldDoorState Decode(string json, string world)
        {
            using (var text = new StringReader(json)) using (var reader = new JsonTextReader(text) { MaxDepth=12, DateParseHandling=DateParseHandling.None })
            {
                var token = JObject.Load(reader, new JsonLoadSettings { DuplicatePropertyNameHandling=DuplicatePropertyNameHandling.Error });
                if (reader.Read()) throw new InvalidDataException("Trailing world door data.");
                if (token["schemaVersion"]?.Type != JTokenType.Integer || (int)token["schemaVersion"] != 1 ||
                    token["worldKey"]?.Type != JTokenType.String || (string)token["worldKey"] != world)
                    throw new InvalidDataException("World door schema/identity differs; retained unchanged.");
                var serializer = JsonSerializer.Create(new JsonSerializerSettings { TypeNameHandling=TypeNameHandling.None,
                    MetadataPropertyHandling=MetadataPropertyHandling.Ignore, DateParseHandling=DateParseHandling.None, MaxDepth=12 });
                var state = token.ToObject<WorldDoorState>(serializer); Validate(state, world); return state;
            }
        }
        static bool Finite(float x) => !float.IsNaN(x) && !float.IsInfinity(x);
        internal static void Validate(WorldDoorState state, string world)
        {
            if (state == null || state.schemaVersion != 1 || state.worldKey != world ||
                state.position == null || state.position.Length != 3 || state.position.Any(v => !Finite(v) || Math.Abs(v) > 100000) || state.position[1] > 7000 ||
                state.rotation == null || state.rotation.Length != 4 || state.rotation.Any(v => !Finite(v)) ||
                state.rotation.Sum(v => (double)v*v) < .9 || state.rotation.Sum(v => (double)v*v) > 1.1)
                throw new InvalidDataException("Invalid world door transform/identity; retained unchanged.");
            if (state.dungeonSeed.HasValue && (state.catalogSha256 == null || state.catalogSha256.Length != 64 ||
                state.catalogSha256.Any(c => !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f'))))
                throw new InvalidDataException("Saved world door layout has no valid catalog identity.");
        }
        internal void Save(WorldDoorState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            Validate(state,state.worldKey); string file=FileFor(state.worldKey);
            byte[] bytes;
            using (var text=new StringWriter(CultureInfo.InvariantCulture)) using(var writer=new JsonTextWriter(text) { Formatting=Formatting.Indented })
            {
                JsonSerializer.Create(new JsonSerializerSettings { TypeNameHandling=TypeNameHandling.None, MetadataPropertyHandling=MetadataPropertyHandling.Ignore }).Serialize(writer,state);
                writer.Flush();bytes=Utf8.GetBytes(text.ToString());
            }
            if (bytes.Length > MaximumBytes) throw new InvalidDataException("World door record is oversized.");
            Directory.CreateDirectory(root);
            using (var guard = new FileStream(file+".lock", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None))
            {
                Load(state.worldKey); // Never overwrite a malformed or wrong-world prior record.
                string temp=file+"."+Guid.NewGuid().ToString("N")+".tmp";
                try
                {
                    using (var output=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)) { output.Write(bytes,0,bytes.Length); output.Flush(true); }
                    if (File.Exists(file)) File.Replace(temp,file,file+".bak"); else File.Move(temp,file);
                }
                finally { if (File.Exists(temp)) File.Delete(temp); }
            }
        }
        internal void Clear(string world)
        {
            string file=FileFor(world); if (!File.Exists(file)) return;
            using (var guard=new FileStream(file+".lock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None))
            { Load(world); File.Delete(file); } // Explicit remove only; backup is never automatically restored.
        }
    }
}
