using System;
using Jotunn.Managers;
using UnityEngine;
using Object = UnityEngine.Object;

namespace TradeWithAnotherWorld
{
    /// <summary>
    /// Binds Valheim's continuous Candle_resin flame to authored wick markers.
    /// Call on a loaded room instance after vanilla prefabs are available.
    /// This helper is compiled but is not installed, invoked, or game-tested
    /// by the R01 native modeling review.
    /// </summary>
    public static class ResinCandleFlame
    {
        public const string SourcePrefab = "Candle_resin";
        public const string SocketToken = "FLAME_SOCKET";
        public const string EffectRootName = "BA_ResinCandleEffect";
        public const float LightAboveFlame = 0.0200002f;

        private const string FlamePath = "high/vfx";
        private const string LightPath = "high/Point Light";
        private const string FlameMaterial = "candleflame_flipbook";

        /// <summary>
        /// Returns the number of newly bound wick sockets. Repeated calls are
        /// idempotent. A marker may have any name containing FLAME_SOCKET.
        /// Native particle size is preserved even on a scaled candle marker.
        /// includeLights=false keeps native flame particles without duplicating
        /// a point light when a fixture's shared lighting budget supplies one.
        /// No alternative torch/fire effect is substituted when validation fails.
        /// </summary>
        public static int AttachToRoom(GameObject roomInstance, bool includeLights = true)
        {
            if (!roomInstance) throw new ArgumentNullException(nameof(roomInstance));

            var source = PrefabManager.Instance.GetPrefab(SourcePrefab);
            if (!source)
                throw new InvalidOperationException("Resin candle flame requires the loaded vanilla prefab " + SourcePrefab + ".");

            var flame = source.transform.Find(FlamePath);
            var light = source.transform.Find(LightPath);
            ValidateFlame(flame);
            if (includeLights) ValidateLight(light);

            int attached = 0;
            // Capture the original hierarchy before adding effect children.
            foreach (var socket in roomInstance.GetComponentsInChildren<Transform>(true))
            {
                if (socket.name.IndexOf(SocketToken, StringComparison.Ordinal) < 0) continue;
                var existing = socket.Find(EffectRootName);
                if (existing)
                {
                    if (!existing.GetComponentInChildren<ParticleSystem>(true))
                        throw new InvalidOperationException("Incomplete resin flame binding at " + socket.name + ".");
                    continue;
                }

                // Cancel inherited geometric scaling at an empty host rather
                // than changing the installed ParticleSystem's module values.
                // R01 markers use ordinary TRS transforms, without shear.
                var scale = socket.lossyScale;
                if (Mathf.Abs(scale.x) < 0.00001f || Mathf.Abs(scale.y) < 0.00001f || Mathf.Abs(scale.z) < 0.00001f)
                    throw new InvalidOperationException("Cannot attach a native resin flame to zero-scale socket " + socket.name + ".");

                var host = new GameObject(EffectRootName);
                // Configure leaves before their Awake/OnEnable callbacks can
                // cache the original prefab's .3741/.3941 m local positions.
                host.SetActive(false);
                host.transform.SetParent(socket, false);
                host.transform.localPosition = Vector3.zero;
                host.transform.localRotation = Quaternion.identity;
                host.transform.localScale = new Vector3(1f / scale.x, 1f / scale.y, 1f / scale.z);
                try
                {
                    // Copy the verified continuous leaf only. Candle_resin's
                    // Piece, fuel system, models, PlayerBase and colliders never
                    // enter the room hierarchy.
                    var flameCopy = Object.Instantiate(flame.gameObject, host.transform, false);
                    flameCopy.name = "Native resin candle flame";
                    flameCopy.transform.localPosition = Vector3.zero;
                    flameCopy.transform.localRotation = flame.localRotation;
                    flameCopy.transform.localScale = flame.localScale;
                    flameCopy.SetActive(true);

                    if (includeLights)
                    {
                        // This exact source leaf carries the installed light
                        // and its own light behaviour; cloning preserves flicker.
                        var lightCopy = Object.Instantiate(light.gameObject, host.transform, false);
                        lightCopy.name = "Native resin candle point light";
                        lightCopy.transform.localPosition = Vector3.up * LightAboveFlame;
                        lightCopy.transform.localRotation = light.localRotation;
                        lightCopy.transform.localScale = light.localScale;
                        lightCopy.SetActive(true);
                    }

                    host.SetActive(true);
                    // Preserve emission, flipbook material, simulation space,
                    // scaling mode, lifetime and all other installed modules.
                    flameCopy.GetComponent<ParticleSystem>().Play(true);
                    attached++;
                }
                catch
                {
                    // A failed socket cannot leave a partial effect behind.
                    host.SetActive(false);
                    Object.Destroy(host);
                    throw;
                }
            }
            return attached;
        }

        private static void ValidateFlame(Transform flame)
        {
            if (!flame || flame.childCount != 0)
                throw new InvalidOperationException("Verified resin candle source leaf is missing or changed: " + FlamePath + ".");
            var particles = flame.GetComponent<ParticleSystem>();
            var renderer = flame.GetComponent<ParticleSystemRenderer>();
            if (!particles || !renderer || !particles.main.loop)
                throw new InvalidOperationException("Candle_resin high/vfx must be a continuous looping ParticleSystem.");

            bool correctMaterial = false;
            foreach (var material in renderer.sharedMaterials)
                if (material && (material.name == FlameMaterial || material.name == FlameMaterial + " (Instance)"))
                    correctMaterial = true;
            if (!correctMaterial)
                throw new InvalidOperationException("Candle_resin high/vfx no longer uses " + FlameMaterial + ".");

            foreach (var component in flame.GetComponents<Component>())
                if (!(component is Transform) && !(component is ParticleSystem) && !(component is ParticleSystemRenderer))
                    throw new InvalidOperationException("Unexpected component on resin flame leaf: " + ComponentName(component) + ".");
        }

        private static void ValidateLight(Transform light)
        {
            if (!light || light.childCount != 0 || !light.GetComponent<Light>() || light.GetComponent<Light>().type != LightType.Point)
                throw new InvalidOperationException("Verified resin candle point-light leaf is missing or changed: " + LightPath + ".");

            int lightBehaviours = 0;
            foreach (var component in light.GetComponents<Component>())
            {
                if (component is Transform || component is Light) continue;
                string name = ComponentName(component);
                if (!(component is MonoBehaviour) || IsGameplayComponent(name) || ++lightBehaviours > 1)
                    throw new InvalidOperationException("Unexpected gameplay or additional component on resin point-light leaf: " + name + ".");
            }
        }

        private static string ComponentName(Component component) => component ? component.GetType().Name : "missing script";

        private static bool IsGameplayComponent(string name) =>
            name == "Piece" || name == "ZNetView" || name == "ZSyncTransform" || name == "WearNTear" ||
            name == "Fireplace" || name == "PlayerBase" || name.IndexOf("Fuel", StringComparison.OrdinalIgnoreCase) >= 0 ||
            name.IndexOf("Collider", StringComparison.OrdinalIgnoreCase) >= 0;
    }
}
