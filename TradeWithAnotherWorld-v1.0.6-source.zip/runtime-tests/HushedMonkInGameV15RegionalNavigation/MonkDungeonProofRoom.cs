using System;
using System.IO;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace BlackAbbey.HushedMonk
{
    // The explicit private test loads the exact existing R04 through its own
    // package loader, without entering the room helper or writing checkpoints.
    public sealed class MonkDungeonProofRoom : IDisposable
    {
        public static MonkDungeonProofRoom Active { get; private set; }
        public GameObject Root { get; private set; }
        public object SourceEvidence { get; private set; }
        IDisposable loaded;
        public static MonkDungeonProofRoom Load(Player player, Action<string> log)
        {
            if (Active != null || !player || !ZNet.IsSinglePlayer || !ZNet.instance || !ZNet.instance.IsServer()
                || !Environment.GetCommandLineArgs().Contains("-hm-proof-dungeon"))
                throw new InvalidOperationException("R04 proof requires explicit new private single-player test.");
            string profile = Game.instance?.GetPlayerProfile()?.GetFilename();
            string save = Utils.GetSaveDataPath(FileHelpers.FileSource.Local);
            string marker = Path.Combine(save, ".black-abbey-room-test-profile");
            if (profile == null || !profile.StartsWith("hmproof_", StringComparison.Ordinal) || !File.Exists(marker)
                || File.ReadAllText(marker).Trim() != "BlackAbbeyRoomTest isolated local save profile v1" || FileHelpers.CloudStorageSupported)
                throw new InvalidOperationException("Fresh proof profile/save fence not confirmed.");
            var assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(a => a.GetType("BlackAbbeySixRooms.RuntimeTestPlugin", false) != null)
                ?? throw new InvalidOperationException("Actual Black Abbey helper not loaded.");
            var pluginType = assembly.GetType("BlackAbbeySixRooms.RuntimeTestPlugin", true);
            var plugin = BepInEx.Bootstrap.Chainloader.PluginInfos.Values.Select(p => p.Instance).FirstOrDefault(p => p && p.GetType() == pluginType);
            string data = pluginType.GetProperty("DataPath", BindingFlags.NonPublic | BindingFlags.Instance)?.GetValue(plugin) as string;
            if (string.IsNullOrEmpty(data)) throw new InvalidOperationException("Actual helper data path is unavailable.");
            string catalogFile = Path.Combine(data, "catalog.json");
            var recordJson = JObject.Parse(File.ReadAllText(catalogFile))["rooms"].OfType<JObject>().Single(r => r.Value<string>("roomId") == "R04");
            var recordType = assembly.GetType("BlackAbbeySixRooms.CatalogRoomRecord", true);
            object record = JsonConvert.DeserializeObject(recordJson.ToString(), recordType, new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.None });
            string directory = Path.GetFullPath(Path.Combine(data, recordJson.Value<string>("packageDirectory")));
            if (!directory.StartsWith(Path.GetFullPath(data) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Actual room directory escaped installed data.");
            string manifestFile = Path.Combine(directory, "manifest.json");
            if (VisualRuntime.Hash(manifestFile) != recordJson.Value<string>("manifestSha256")) throw new InvalidOperationException("Installed R04 manifest changed.");
            var result = new MonkDungeonProofRoom();
            try
            {
                var loader = assembly.GetType("BlackAbbeySixRooms.RoomPackage", true).GetMethod("Load", BindingFlags.NonPublic | BindingFlags.Static);
                var room = loader.Invoke(null, new object[] { directory, record, log });
                result.loaded = (IDisposable)room;
                result.Root = (GameObject)room.GetType().GetField("Root", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(room);
                if (!result.Root) throw new InvalidOperationException("Actual R04 loader did not return its room.");
                result.Root.name = "HM Private Actual R04 Proof Only";
                result.Root.transform.position = new Vector3(player.transform.position.x, 8000, player.transform.position.z);
                result.Root.SetActive(true); Physics.SyncTransforms();
                var flameHelper = assembly.GetType("TradeWithAnotherWorld.ResinCandleFlame", false);
                flameHelper?.GetMethod("AttachToRoom", BindingFlags.Public | BindingFlags.Static)?.Invoke(null, new object[] { result.Root, false });
                assembly.GetType("BlackAbbeySixRooms.RoomCandleLighting", true).GetMethod("Attach", BindingFlags.NonPublic | BindingFlags.Static)
                    ?.Invoke(null, new object[] { room, log });
                var floorStart = result.Root.transform.TransformPoint(new Vector3(0, .35f, 4));
                if (!Physics.Raycast(floorStart + Vector3.up, Vector3.down, out var hit, 3, LayerMask.GetMask("static_solid"), QueryTriggerInteraction.Ignore)
                    || !hit.collider.transform.IsChildOf(result.Root.transform) || hit.normal.y < .8f)
                    throw new InvalidOperationException("Actual R04 proof start lacks authored floor.");
                floorStart.y = hit.point.y + .15f;
                result.SourceEvidence = new { room = "R04", helperAssembly = assembly.Location, helperSha256 = VisualRuntime.Hash(assembly.Location),
                    catalog = catalogFile, catalogSha256 = VisualRuntime.Hash(catalogFile), manifest = manifestFile,
                    manifestSha256 = VisualRuntime.Hash(manifestFile), sourceNativeSha256 = recordJson.Value<string>("sourceSha256"),
                    floorCollider = hit.collider.name, origin = V(result.Root.transform.position), playerTarget = V(floorStart),
                    helperEntryCommandsUsed = false, checkpointStoreWritten = false, existingRoomsModified = false,
                    playerMoveScope = "Only the freshly created fenced hmproof profile, explicit -hm-proof-dungeon flag" };
                Active = result;
                player.TeleportTo(floorStart, Quaternion.identity, false);
                log?.Invoke("HM_DUNGEON_PROOF_ROOM_READY " + JsonConvert.SerializeObject(result.SourceEvidence));
                return result;
            }
            catch { result.Dispose(); throw; }
        }
        static float[] V(Vector3 value) => new[] { value.x, value.y, value.z };
        public void Dispose()
        {
            loaded?.Dispose(); loaded = null; Root = null;
            if (ReferenceEquals(Active, this)) Active = null;
        }
    }
}
