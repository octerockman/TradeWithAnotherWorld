using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace BlackAbbey.HushedMonk
{
    // Native animation retains the wrist, arm and complete attack trajectory.
    // Only the fifteen authored right-finger local rotations are overridden.
    [DefaultExecutionOrder(10000)]
    public sealed class MonkRightHandGrip : MonoBehaviour
    {
        [SerializeField] Transform[] fingerBones;
        [SerializeField] Quaternion[] gripRotations, sourceRotations;
        [SerializeField] string sourceNativeSha256, sourcePayloadSha256, gripSha256;
        Quaternion[] animatedRotations;
        Humanoid humanoid;
        bool posing, wasHolding, terminal;

        static readonly string[] FingerHumanNames = {
            "Right Thumb Proximal", "Right Thumb Intermediate", "Right Thumb Distal",
            "Right Index Proximal", "Right Index Intermediate", "Right Index Distal",
            "Right Middle Proximal", "Right Middle Intermediate", "Right Middle Distal",
            "Right Ring Proximal", "Right Ring Intermediate", "Right Ring Distal",
            "Right Little Proximal", "Right Little Intermediate", "Right Little Distal" };

        static bool Finite(float v) => !float.IsNaN(v) && !float.IsInfinity(v);

        public static void Configure(GameObject actor, string directory, VisualPayload payload,
            string payloadHash, Dictionary<string, Transform> named, Action<string> log)
        {
            string file = VisualRuntime.SafePath(directory, "hand-grip.json");
            if (new FileInfo(file).Length > 64 * 1024) throw new InvalidDataException("Oversized required hand-grip.json.");
            string actualHash = VisualRuntime.Hash(file);
            if (VisualSourceContract.HandGripSha256.Length != 64 || actualHash != VisualSourceContract.HandGripSha256)
                throw new InvalidDataException("Hand grip differs from the frozen source-bound V8 grip.");
            var data = MonkGripFileReader.Read(File.ReadAllText(file), payloadHash, payload.sourceNative.sha256, HushedMonkPlugin.WeaponName);
            VisualSourceContract.Require(data.sourcePayloadSha256, data.sourceNativeSha256);
            var expected = FingerHumanNames.Select(h => payload.rig.humanDescription.human.Single(b => b.humanName == h).boneName).ToArray();
            if (expected.Distinct(StringComparer.Ordinal).Count() != 15 ||
                data.poses.Any(p => p == null || !expected.Contains(p.boneName, StringComparer.Ordinal)) ||
                data.poses.Select(p => p.boneName).Distinct(StringComparer.Ordinal).Count() != 15)
                throw new InvalidDataException("Grip must contain each exact mapped right-finger bone once.");
            string handName = payload.rig.humanDescription.human.Single(b => b.humanName == "RightHand").boneName;
            if (!named.TryGetValue(handName, out var hand)) throw new InvalidDataException("Actual right-hand bone is missing.");
            var component = actor.AddComponent<MonkRightHandGrip>();
            component.fingerBones = new Transform[15]; component.gripRotations = new Quaternion[15]; component.sourceRotations = new Quaternion[15];
            for (int i = 0; i < data.poses.Length; i++)
            {
                var pose = data.poses[i]; var q = pose.localRotationXYZW;
                if (!named.TryGetValue(pose.boneName, out var bone) || bone == hand || !bone.IsChildOf(hand) ||
                    q == null || q.Length != 4 || q.Any(v => !Finite(v)) || Math.Abs(q.Sum(v => v * v) - 1f) > .002f)
                    throw new InvalidDataException("Invalid right-finger transform or unit local rotation: " + pose.boneName);
                component.fingerBones[i] = bone;
                component.gripRotations[i] = new Quaternion(q[0], q[1], q[2], q[3]);
                component.sourceRotations[i] = bone.localRotation;
            }
            component.sourceNativeSha256 = data.sourceNativeSha256;
            component.sourcePayloadSha256 = payloadHash; component.gripSha256 = actualHash;
            log?.Invoke("HM_RIGHT_HAND_GRIP_CONFIGURED bones=15 sha256=" + actualHash + " sourceBound=true nativeArmsWristUnchanged=true");
        }

        void Start()
        {
            humanoid = GetComponent<Humanoid>();
            if (!humanoid || !GetComponent<HushedMonkInstance>() || fingerBones == null || fingerBones.Length != 15 ||
                gripRotations == null || gripRotations.Length != 15 || sourceRotations == null || sourceRotations.Length != 15 ||
                fingerBones.Any(b => !b) || sourceNativeSha256 != VisualSourceContract.NativeSha256 ||
                sourcePayloadSha256 != VisualSourceContract.PayloadSha256 || gripSha256 != VisualSourceContract.HandGripSha256)
                throw new InvalidOperationException("Cloned required right-hand grip bindings are incomplete.");
            animatedRotations = (Quaternion[])sourceRotations.Clone();
        }

        bool OwnWeaponHeld()
        {
            var item = humanoid ? humanoid.GetCurrentWeapon() : null;
            return item?.m_dropPrefab && string.Equals(item.m_dropPrefab.name, HushedMonkPlugin.WeaponName, StringComparison.Ordinal);
        }

        void ApplyPose()
        {
            for (int i = 0; i < fingerBones.Length; i++) if (fingerBones[i]) fingerBones[i].localRotation = gripRotations[i];
            posing = true;
        }
        void ResetPose()
        {
            if (!posing || fingerBones == null) return;
            for (int i = 0; i < fingerBones.Length; i++) if (fingerBones[i]) fingerBones[i].localRotation = animatedRotations == null ? sourceRotations[i] : animatedRotations[i];
            posing = false;
        }
        void Update()
        {
            // Remove last frame's override before normal Animator evaluation,
            // so unkeyed digits retain the authored free-hand source pose.
            if (!terminal && humanoid && !humanoid.IsDead()) ResetPose();
        }
        void LateUpdate()
        {
            if (terminal || !humanoid) return;
            if (humanoid.IsDead())
            {
                ApplyForDeathSnapshot(); return;
            }
            bool holding = OwnWeaponHeld();
            if (holding)
            {
                if (!wasHolding)
                    for (int i = 0; i < fingerBones.Length; i++) animatedRotations[i] = fingerBones[i].localRotation;
                ApplyPose();
            }
            else ResetPose();
            wasHolding = holding;
        }
        public void ApplyForDeathSnapshot()
        {
            if (!humanoid) humanoid = GetComponent<Humanoid>();
            // Called directly immediately before corpse CopyNodes. Never reset
            // the fitted pose first; the corpse has no grip/Animator component.
            if (fingerBones != null && (OwnWeaponHeld() || wasHolding || posing)) ApplyPose();
            terminal = true; enabled = false;
        }
        void OnDisable() { if (!terminal) ResetPose(); }
    }
}
