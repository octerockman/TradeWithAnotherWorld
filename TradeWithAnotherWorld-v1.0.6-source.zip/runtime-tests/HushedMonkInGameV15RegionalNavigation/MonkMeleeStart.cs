using HarmonyLib;
using UnityEngine;

namespace BlackAbbey.HushedMonk
{
    // Native AI approaches a last-known target point. Check the live target at
    // commit time on this clapper user only. An already-started swing can miss.
    [HarmonyPatch(typeof(Humanoid),nameof(Humanoid.StartAttack))]
    internal static class MonkMeleeStart
    {
        static bool Prefix(Humanoid __instance,Character target,ref bool __result)
        {
            var marker=__instance?__instance.GetComponent<HushedMonkInstance>():null;
            if(!marker||!target||!__instance.IsOwner())return true;
            var item=__instance.GetCurrentWeapon();
            if(item?.m_dropPrefab==null||item.m_dropPrefab.name!=HushedMonkPlugin.WeaponName)return true;
            Vector3 delta=target.transform.position-__instance.transform.position;
            float surface=Vector3.ProjectOnPlane(delta,Vector3.up).magnitude-target.GetRadius();
            if(MonkAttackApproachPolicy.CanStart(surface,delta.y))return true;
            marker.outOfReachAttempts++;__result=false;return false;
        }
    }
}
