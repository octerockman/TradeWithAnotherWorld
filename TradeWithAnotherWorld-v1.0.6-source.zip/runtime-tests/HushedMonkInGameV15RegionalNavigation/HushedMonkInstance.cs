using System;
using UnityEngine;

namespace BlackAbbey.HushedMonk
{
    // Present only on the own test prefab. Native Character owns health,
    // native MonsterAI owns decisions and CharacterAnimEvent owns hit timing.
    public sealed class HushedMonkInstance : MonoBehaviour
    {
        public string visualPayloadSha256, approvedNativeSha256, nativeControllerName;
        public int attackEvents;
        public int outOfReachAttempts;
        public float damageReceived;
        public bool deathObserved;
        void Start()
        {
            var humanoid = GetComponent<Humanoid>(); var animator = GetComponentInChildren<Animator>(); var view = GetComponent<ZNetView>();
            if (!humanoid || !animator || !view || !view.IsValid()) return;
            // This manually spawned test is an awake encounter, never a prone
            // CreatureSpawner. Set once; never override ongoing attack states.
            animator.SetBool("wakeup", false);
            var sync = GetComponent<ZSyncAnimation>(); if (sync && view.IsOwner()) sync.SetBool("wakeup", false);
            humanoid.m_onDamaged += Damaged; humanoid.m_onDeath += Died;
            var listener = animator.gameObject.GetComponent<HushedMonkAttackEvents>() ?? animator.gameObject.AddComponent<HushedMonkAttackEvents>(); listener.owner = this;
            var ownAudio = MonkAudioController.Attach(gameObject, HushedMonkPlugin.AudioBank, HushedMonkPlugin.Log, MonkAudioHooks.CreatureMixer);
            if (ownAudio) MonkAudioHooks.AttachRelay(gameObject);
            MonkDungeonNavigation.Attach(gameObject, HushedMonkPlugin.Log);
            HushedMonkPlugin.Log("HM_INSTANCE_START " + Status());
        }
        void Damaged(float amount, Character attacker)
        { damageReceived += amount; HushedMonkPlugin.Log("HM_DAMAGE_RECEIVED amount=" + amount + " attacker=" + (attacker ? attacker.m_name : "environment") + " " + Status()); }
        void Died() { deathObserved = true; HushedMonkPlugin.Log("HM_DEATH " + Status()); }
        public string Status()
        {
            var character = GetComponent<Humanoid>(); var animator = GetComponentInChildren<Animator>(); var ai = GetComponent<MonsterAI>(); var view = GetComponent<ZNetView>(); var item = character ? character.GetCurrentWeapon() : null;
            return "name=" + name + " zdo=" + (view && view.GetZDO() != null ? view.GetZDO().m_uid.ToString() : "none") + " hp=" + (character ? character.GetHealth() : -1) + " weapon=" + (item?.m_dropPrefab ? item.m_dropPrefab.name : "none") + " target=" + (ai && ai.GetTargetCreature() ? ai.GetTargetCreature().m_name : "none") + " alerted=" + (ai && ai.IsAlerted()) + " sleeping=" + (ai && ai.IsSleeping()) + " wakeup=" + (animator && animator.GetBool("wakeup")) + " avatarValid=" + (animator && animator.avatar && animator.avatar.isValid) + " human=" + (animator && animator.avatar && animator.avatar.isHuman) + " outOfReachSkipped=" + outOfReachAttempts + " attacks=" + attackEvents + " damaged=" + damageReceived + " dead=" + deathObserved + " payload=" + visualPayloadSha256 + " position=" + transform.position.ToString("F3");
        }
    }
    public sealed class HushedMonkAttackEvents : MonoBehaviour
    {
        public HushedMonkInstance owner;
        // Skeleton_mace emits Hit; CharacterAnimEvent.Hit then invokes the
        // Humanoid attack trigger internally. Observe the actual clip event.
        public void Hit()
        {
            if (!owner) return;
            // The log confirms this retained clip event reaches the new rig.
            // Use it as a second route into the SAME owner/frame-deduplicated
            // relay; the native Attack observer may already have sent it.
            MonkAudioHooks.Relay(owner)?.Swing();
            owner.attackEvents++; HushedMonkPlugin.Log("HM_ATTACK_EVENT " + owner.Status());
        }
    }
}
