using System;
using UnityEngine;

namespace BlackAbbey.HushedMonk
{
    // Reads actual live cosmetic bodies/cord geometry during the explicit
    // private proof. It never creates motion, changes forces or plays events.
    public sealed class MonkCordProofProbe
    {
        readonly WristBellPhysics bell;
        Rigidbody cordBody, bellBody, anchorBody;
        ConfigurableJoint cordJoint, bellJoint;
        Mesh liveCordMesh;
        WristBellPhysics.Telemetry last;
        bool created;
        int samples, steps;
        float swing, travel, endpointMotion, rootError, distalError, lengthError, rootJointGap, bellJointGap;

        public MonkCordProofProbe(WristBellPhysics source) { bell = source; Sample(); }

        public object Sample()
        {
            samples++;
            if (ReferenceEquals(bell, null)) return null;
            last = bell.Snapshot();
            if (!created && last.initialized && last.cordConfigured && last.cosmeticBodyCount == 3 && last.cordMeshAlive && last.cordJointAlive && last.jointAlive)
            {
                var frame = bell.CordTransform;
                var filter = frame ? frame.GetComponent<MeshFilter>() : null;
                var mesh = filter ? filter.sharedMesh : null;
                if (mesh && mesh.name.StartsWith("HM_WristBell_Cord_Live_", StringComparison.Ordinal))
                {
                    cordBody = bell.CordBody; bellBody = bell.DynamicBody; anchorBody = bell.AnchorBody;
                    cordJoint = bell.CordJoint; bellJoint = bell.Joint; liveCordMesh = mesh;
                    created = cordBody && bellBody && anchorBody && cordJoint && bellJoint && last.colliderCount == 0
                        && !cordBody.isKinematic && cordBody.useGravity && !bellBody.isKinematic && bellBody.useGravity
                        && anchorBody.isKinematic && last.cordTriangleCount == 28 && last.cordVertexCount == 56;
                }
            }
            steps = Mathf.Max(steps, last.cordFixedSteps); swing = Mathf.Max(swing, last.maximumCordSwingDegrees);
            travel = Mathf.Max(travel, last.cordRelativeAngularTravelDegrees);
            endpointMotion = Mathf.Max(endpointMotion, last.maximumCordEndpointDisplacementFromFixedPoseMetres);
            rootError = Mathf.Max(rootError, last.maxCordRootGapMetres); distalError = Mathf.Max(distalError, last.maxCordDistalDeformationErrorMetres);
            lengthError = Mathf.Max(lengthError, last.maxCordCentrelineSegmentErrorMetres);
            rootJointGap = Mathf.Max(rootJointGap, last.maxCordRootJointGapMetres); bellJointGap = Mathf.Max(bellJointGap, last.maxCordBellJointGapMetres);
            return new { physicalCord = last, actualBodyCreationObserved = created, samples };
        }

        public void Check(Action<string, bool, object> check)
        {
            Sample();
            check("physical hanging cord swings with anchored continuous endpoints",
                created && steps > 10 && swing > 1 && swing < 45 && travel > 1 && endpointMotion > .002f
                && rootError < .00005f && distalError < .00005f && lengthError < .0001f && rootJointGap < .03f && bellJointGap < .03f,
                new { actualBodyCreationObserved = created, samples, fixedSteps = steps, maximumSwingDegrees = swing,
                    relativeAngularTravelDegrees = travel, endpointDisplacementFromFixedWristPoseM = endpointMotion,
                    maximumProximalRenderGapM = rootError, maximumDistalRenderErrorM = distalError, maximumCentrelineLengthErrorM = lengthError,
                    maximumCordRootJointGapM = rootJointGap, maximumCordBellJointGapM = bellJointGap, telemetry = last });
            check("cord and both pendulum bodies clean after death",
                created && !cordBody && !bellBody && !anchorBody && !cordJoint && !bellJoint && !liveCordMesh
                && last != null && last.resourcesDestroyed && !last.cordMeshAlive && !last.cordBodyAlive && !last.cordJointAlive,
                new { resourcesPreviouslyCreated = created, cordBodyDestroyed = !cordBody, bellBodyDestroyed = !bellBody,
                    anchorDestroyed = !anchorBody, cordJointDestroyed = !cordJoint, bellJointDestroyed = !bellJoint,
                    ownMutableCordMeshDestroyed = !liveCordMesh, telemetry = last });
        }
    }
}
