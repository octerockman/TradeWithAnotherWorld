using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text;
using HarmonyLib;
using Jotunn.Entities;
using Jotunn.Managers;
using UnityEngine;
using UnityEngine.Audio;

namespace BlackAbbey.HushedMonk
{
    // Native damage, AI decisions, animation timing, effect creation and FootStep
    // still run unchanged. These callbacks are observers on our marked actor.
    public static class MonkAudioHooks
    {
        static readonly FieldInfo AttackCharacter = AccessTools.Field(typeof(Attack), "m_character");
        static readonly Type HitPointType = typeof(Attack).GetNestedType("HitPoint", BindingFlags.Public | BindingFlags.NonPublic);
        static readonly FieldInfo HitObject = HitPointType?.GetField("go");
        static readonly FieldInfo HitCollider = HitPointType?.GetField("collider");
        static bool callbackErrorLogged;
        static readonly Dictionary<GameObject, GameObject> SilentEffectForks = new Dictionary<GameObject, GameObject>();
        static readonly List<object> SilentEffectAudits = new List<object>();
        static readonly MethodInfo CloneEffectEntry = typeof(object).GetMethod("MemberwiseClone", BindingFlags.Instance | BindingFlags.NonPublic);
        public static bool MeleeContactHookReady { get; private set; }
        public static AudioMixerGroup CreatureMixer { get; private set; }

        static void Safe(Action action)
        {
            try { action(); }
            catch (Exception ex)
            {
                // An optional sound observer must never abort native damage.
                if (callbackErrorLogged) return;
                callbackErrorLogged = true;
                HushedMonkPlugin.Log("HM_AUDIO_HOOK_CALLBACK_FAILED " + ex);
            }
        }
        internal static MonkAudioEventRelay Relay(Component actor)
        {
            if (!actor || !actor.GetComponent<HushedMonkInstance>()) return null;
            return actor.GetComponent<MonkAudioEventRelay>();
        }
        public static void AttachRelay(GameObject ownActor)
        {
            if (!ownActor || !ownActor.GetComponent<HushedMonkInstance>())
                throw new InvalidOperationException("Monk audio relay requires the own actor marker.");
            if (!ownActor.GetComponent<MonkAudioController>())
                throw new InvalidOperationException("Attach the own audio controller before its event relay.");
            var relay = ownActor.GetComponent<MonkAudioEventRelay>() ?? ownActor.AddComponent<MonkAudioEventRelay>();
            relay.Bind();
        }

        static string Hash(string text)
        {
            using (var sha = SHA256.Create()) return string.Concat(sha.ComputeHash(Encoding.UTF8.GetBytes(text)).Select(b => b.ToString("x2")));
        }
        static FieldInfo[] EffectFields(object value) => value.GetType().GetFields(BindingFlags.Public | BindingFlags.Instance)
            .Where(f => f.FieldType == typeof(EffectList)).ToArray();
        static IEnumerable<GameObject> EffectPrefabs(object value)
        {
            if (value == null) yield break;
            foreach (var field in EffectFields(value))
                foreach (var effect in ((EffectList)field.GetValue(value))?.m_effectPrefabs ?? Array.Empty<EffectList.EffectData>())
                    if (effect?.m_prefab) yield return effect.m_prefab;
        }
        static bool HasSound(GameObject prefab) => prefab &&
            (prefab.GetComponentInChildren<AudioSource>(true) || prefab.GetComponentInChildren<ZSFX>(true));
        static bool HasVisual(GameObject prefab) => prefab &&
            (prefab.GetComponentInChildren<Renderer>(true) || prefab.GetComponentInChildren<ParticleSystem>(true)
                || prefab.GetComponentInChildren<Light>(true) || prefab.GetComponentInChildren<Ragdoll>(true));
        static string NodePath(Transform root, Transform node)
        {
            var parts = new List<string>();
            while (node && node != root) { parts.Add(node.name); node = node.parent; }
            parts.Reverse(); return string.Join("/", parts);
        }
        static string VisualDefinition(GameObject prefab)
        {
            // Root name differs intentionally. Compare actual hierarchy/TRS,
            // component roles, shared mesh/material bindings and main VFX state.
            var nodes = prefab.GetComponentsInChildren<Transform>(true).Select(t => new {
                path = NodePath(prefab.transform, t), active = t.gameObject.activeSelf,
                position = new[] { t.localPosition.x, t.localPosition.y, t.localPosition.z },
                rotation = new[] { t.localRotation.x, t.localRotation.y, t.localRotation.z, t.localRotation.w },
                scale = new[] { t.localScale.x, t.localScale.y, t.localScale.z },
                components = t.GetComponents<Component>().Where(c => c && !(c is AudioSource) && !(c is ZSFX)).Select(c => c.GetType().FullName).OrderBy(n => n).ToArray() }).ToArray();
            var renderers = prefab.GetComponentsInChildren<Renderer>(true).Select(r => new {
                path = NodePath(prefab.transform, r.transform), type = r.GetType().FullName, r.enabled,
                materials = r.sharedMaterials.Select(m => m ? m.GetInstanceID() : 0).ToArray(),
                castShadows = (int)r.shadowCastingMode, r.receiveShadows, r.sortingLayerID, r.sortingOrder }).ToArray();
            var meshes = prefab.GetComponentsInChildren<MeshFilter>(true).Select(m => new {
                path = NodePath(prefab.transform, m.transform), mesh = m.sharedMesh ? m.sharedMesh.GetInstanceID() : 0 }).ToArray();
            var particles = prefab.GetComponentsInChildren<ParticleSystem>(true).Select(p => new {
                path = NodePath(prefab.transform, p.transform), p.main.duration, p.main.loop, p.main.playOnAwake,
                p.main.maxParticles, simulationSpace = (int)p.main.simulationSpace, p.main.simulationSpeed,
                emissionEnabled = p.emission.enabled, burstCount = p.emission.burstCount, shapeEnabled = p.shape.enabled }).ToArray();
            var lights = prefab.GetComponentsInChildren<Light>(true).Select(l => new {
                path = NodePath(prefab.transform, l.transform), l.enabled,
                color = new[] { l.color.r, l.color.g, l.color.b, l.color.a }, l.intensity, l.range, type = (int)l.type }).ToArray();
            return Newtonsoft.Json.JsonConvert.SerializeObject(new { nodes, renderers, meshes, particles, lights });
        }
        static string AudioDefinition(GameObject prefab) => Newtonsoft.Json.JsonConvert.SerializeObject(new {
            sources = prefab.GetComponentsInChildren<AudioSource>(true).Select(s => new { path = NodePath(prefab.transform, s.transform), s.enabled, s.mute, s.playOnAwake, s.volume,
                clip = s.clip ? s.clip.GetInstanceID() : 0, mixer = s.outputAudioMixerGroup ? s.outputAudioMixerGroup.GetInstanceID() : 0 }).ToArray(),
            zsfx = prefab.GetComponentsInChildren<ZSFX>(true).Select(s => new { path = NodePath(prefab.transform, s.transform), definition = JsonUtility.ToJson(s) }).ToArray() });
        static GameObject SilentVisualFork(GameObject native)
        {
            if (SilentEffectForks.TryGetValue(native, out var cached) && cached) return cached;
            var manager = PrefabManager.Instance;
            var container = AccessTools.Property(typeof(PrefabManager), "PrefabContainer")?.GetValue(manager) as GameObject;
            if (!container || container.activeInHierarchy) throw new InvalidOperationException("Silent effect forks require Jotunn's inactive prefab container.");
            string beforeVisual = VisualDefinition(native), beforeAudio = AudioDefinition(native);
            string ownName = "TWA_HM_Silent_" + native.name;
            if (manager.GetPrefab(ownName)) throw new InvalidOperationException("Silent own effect name is already registered: " + ownName);
            var fork = manager.CreateClonedPrefab(ownName, native);
            if (!fork || !fork.transform.parent || fork.transform.parent != container.transform || fork.activeInHierarchy)
                throw new InvalidOperationException("Silent effect fork was not created inactive and separate from the actor.");
            foreach (var source in fork.GetComponentsInChildren<AudioSource>(true))
            { source.mute = true; source.playOnAwake = false; source.volume = 0; source.enabled = false; }
            foreach (var sound in fork.GetComponentsInChildren<ZSFX>(true))
            {
                // Installed ZSFX.Awake only caches the source. Play returns for
                // an empty clip array, never setting AudioSource.mute. Keeping
                // the components avoids breaking native VFX component links.
                sound.m_playOnAwake = false; sound.m_minVol = sound.m_maxVol = 0;
                sound.m_audioClips = Array.Empty<AudioClip>(); sound.m_useVibration = false;
                sound.m_playThroughController = sound.m_playThroughAllControllers = false;
                sound.m_controllerAudioVolume = 0; sound.m_closedCaptionToken = sound.m_secondaryCaptionToken = "";
                sound.enabled = false;
            }
            bool visualPreserved = beforeVisual == VisualDefinition(fork);
            bool nativeUnchanged = beforeVisual == VisualDefinition(native) && beforeAudio == AudioDefinition(native);
            bool silent = fork.GetComponentsInChildren<AudioSource>(true).All(s => s.mute && !s.enabled && !s.playOnAwake && s.volume == 0)
                && fork.GetComponentsInChildren<ZSFX>(true).All(s => !s.enabled && !s.m_playOnAwake && s.m_audioClips.Length == 0
                    && s.m_minVol == 0 && s.m_maxVol == 0 && !s.m_playThroughController && !s.m_playThroughAllControllers);
            if (!visualPreserved || !nativeUnchanged || !silent) { UnityEngine.Object.Destroy(fork); throw new InvalidOperationException("Owned silent VFX fork preservation/silence failed: " + native.name); }
            manager.AddPrefab(new CustomPrefab(fork, false));
            if (manager.GetPrefab(ownName) != fork) { UnityEngine.Object.Destroy(fork); throw new InvalidOperationException("Owned silent VFX fork did not register: " + ownName); }
            SilentEffectForks.Add(native, fork);
            SilentEffectAudits.Add(new { nativePrefab = native.name, ownPrefab = ownName, nativeSourceUnchanged = nativeUnchanged,
                visualHierarchyBindingsAndMainStatePreserved = visualPreserved, visualDefinitionSha256 = Hash(beforeVisual), nativeAudioDefinitionSha256 = Hash(beforeAudio),
                silentAudioSources = fork.GetComponentsInChildren<AudioSource>(true).Length, disabledZSFX = fork.GetComponentsInChildren<ZSFX>(true).Length,
                silenceVerified = silent, registered = true, parent = container.name, inactiveInHierarchy = !fork.activeInHierarchy,
                nativeNetworkViewPreserved = native.GetComponentsInChildren<ZNetView>(true).Length == fork.GetComponentsInChildren<ZNetView>(true).Length,
                scope = "Owned runtime-only VFX prefab fork. Root name and copied sound settings differ; native source is untouched. Mesh/material references, component roles, hierarchy/TRS and recorded main particle/light state are compared. No native media is exported." });
            return fork;
        }
        public static void ReleaseOwnedEffectForks()
        {
            foreach (var fork in SilentEffectForks.Values)
                if (fork) { PrefabManager.Instance.RemovePrefab(fork.name); UnityEngine.Object.Destroy(fork); }
            SilentEffectForks.Clear(); SilentEffectAudits.Clear();
        }
        static void Filter(object target, IEnumerable<string> fields, string scope, List<object> changes)
        {
            foreach (string name in fields)
            {
                var field = target.GetType().GetField(name, BindingFlags.Public | BindingFlags.Instance);
                if (field == null || field.FieldType != typeof(EffectList)) throw new InvalidOperationException("Native effect field changed: " + scope + "." + name);
                var source = ((EffectList)field.GetValue(target))?.m_effectPrefabs ?? Array.Empty<EffectList.EffectData>();
                var retained = new List<EffectList.EffectData>();
                var replacedMixed = new List<string>();
                foreach (var effect in source)
                {
                    if (!effect?.m_prefab) continue;
                    if (!HasSound(effect.m_prefab)) { retained.Add(effect); continue; }
                    if (!HasVisual(effect.m_prefab)) continue;
                    // EffectData is a shared reference type: clone the entry
                    // before changing its prefab, retaining every native flag.
                    var ownEntry = (EffectList.EffectData)CloneEffectEntry.Invoke(effect, null);
                    ownEntry.m_prefab = SilentVisualFork(effect.m_prefab);
                    retained.Add(ownEntry); replacedMixed.Add(effect.m_prefab.name);
                }
                var kept = retained.ToArray();
                field.SetValue(target, new EffectList { m_effectPrefabs = kept });
                changes.Add(new { scope, field = name, before = source.Select(e => e?.m_prefab ? e.m_prefab.name : "null").ToArray(),
                    removedAudio = source.Where(e => e?.m_prefab && HasSound(e.m_prefab) && !HasVisual(e.m_prefab)).Select(e => e.m_prefab.name).ToArray(),
                    replacedMixedAudioVisual = replacedMixed.ToArray(), kept = kept.Select(e => e.m_prefab.name).ToArray(),
                    visualEntriesPreserved = source.Where(e => e?.m_prefab && HasVisual(e.m_prefab)).All(e => kept.Any(k => k == e ||
                        (SilentEffectForks.TryGetValue(e.m_prefab, out var fork) && k.m_prefab == fork && VisualDefinition(e.m_prefab) == VisualDefinition(fork)))) });
            }
        }
        static string[] FootstepDefinitions(GameObject source) => source.GetComponentsInChildren<FootStep>(true)
            .Select(JsonUtility.ToJson).ToArray();

        // Call only after the existing native-poison-token sanitizer and own
        // marker creation. This does not restore its deliberately removed VFX.
        public static object PrepareOwnedClones(GameObject nativeEnemy, GameObject ownEnemy, ItemDrop nativeWeapon, ItemDrop ownWeapon)
        {
            if (!nativeEnemy || !ownEnemy || nativeEnemy == ownEnemy || !ownEnemy.GetComponent<HushedMonkInstance>()
                || !nativeWeapon || !ownWeapon || nativeWeapon == ownWeapon)
                throw new InvalidOperationException("Sound replacement requires distinct own marked clones.");
            var nativeCharacter = nativeEnemy.GetComponent<Humanoid>(); var ownCharacter = ownEnemy.GetComponent<Humanoid>();
            var nativeAI = nativeEnemy.GetComponent<MonsterAI>(); var ownAI = ownEnemy.GetComponent<MonsterAI>();
            if (!nativeCharacter || !ownCharacter || !nativeAI || !ownAI) throw new InvalidOperationException("Native character/AI missing.");
            var ns = nativeWeapon.m_itemData.m_shared; var os = ownWeapon.m_itemData.m_shared;
            if (ReferenceEquals(ns, os) || ReferenceEquals(ns.m_attack, os.m_attack) || ReferenceEquals(ns.m_secondaryAttack, os.m_secondaryAttack))
                throw new InvalidOperationException("Own weapon definitions must already be private clones.");
            var nativeBefore = new[] { JsonUtility.ToJson(nativeCharacter), JsonUtility.ToJson(nativeAI), JsonUtility.ToJson(nativeWeapon) };
            var stepsBefore = FootstepDefinitions(ownEnemy);
            var changes = new List<object>();
            Filter(ownCharacter, new[] { "m_hitEffects", "m_critHitEffects", "m_backstabHitEffects", "m_deathEffects" }, "ownCharacter", changes);
            Filter(ownAI, new[] { "m_idleSound", "m_alertedEffects", "m_wakeupEffects", "m_sleepEffects" }, "ownAI", changes);
            Filter(os, EffectFields(os).Select(f => f.Name), "ownWeapon.shared", changes);
            Filter(os.m_attack, EffectFields(os.m_attack).Select(f => f.Name), "ownWeapon.attack", changes);
            Filter(os.m_secondaryAttack, EffectFields(os.m_secondaryAttack).Select(f => f.Name), "ownWeapon.secondary", changes);
            bool sourceUnchanged = nativeBefore.SequenceEqual(new[] { JsonUtility.ToJson(nativeCharacter), JsonUtility.ToJson(nativeAI), JsonUtility.ToJson(nativeWeapon) });
            bool footstepsUnchanged = stepsBefore.SequenceEqual(FootstepDefinitions(ownEnemy));
            if (!sourceUnchanged || !footstepsUnchanged) throw new InvalidOperationException("Sound replacement changed a native source or own FootStep definition.");
            return new { schema = "hushed-monk.owned-native-sound-replacement.v1", nativeSourceUnchanged = sourceUnchanged,
                footStepDefinitionsUnchanged = footstepsUnchanged, nativeSourceDefinitionSha256 = nativeBefore.Select(Hash).ToArray(),
                changes, silentMixedEffectForks = SilentEffectAudits.ToArray(), attackAnimation = os.m_attack.m_attackAnimation, attackRange = os.m_attack.m_attackRange,
                scope = "New effect-list containers/private mixed-effect entry forks only on the own marked character/AI/private item definitions. Existing VFX retained; mixed-effect audio silenced in separate registered runtime-only forks. Native source assets, FootStep, damage, AI and attack timing unchanged." };
        }

        public static AudioMixerGroup ResolveNativeCreatureMixer(GameObject sourceSkeleton, GameObject sourceMace)
        {
            var prefabs = new List<GameObject>();
            if (sourceSkeleton)
            {
                prefabs.Add(sourceSkeleton);
                foreach (var c in sourceSkeleton.GetComponents<Component>()) if (c) prefabs.AddRange(EffectPrefabs(c));
            }
            if (sourceMace)
            {
                prefabs.Add(sourceMace); var item = sourceMace.GetComponent<ItemDrop>()?.m_itemData;
                if (item?.m_shared != null) { prefabs.AddRange(EffectPrefabs(item.m_shared)); prefabs.AddRange(EffectPrefabs(item.m_shared.m_attack)); }
            }
            // The installed AudioMan has no m_sfxMixer. Borrow the exact group
            // of a real native source read-only, never ambient/gui/music.
            foreach (var source in prefabs.Distinct().SelectMany(p => p.GetComponentsInChildren<AudioSource>(true)))
            {
                var group = source.outputAudioMixerGroup;
                if (!group || group.name.IndexOf("sfx", StringComparison.OrdinalIgnoreCase) < 0) continue;
                CreatureMixer = group;
                HushedMonkPlugin.Log("HM_AUDIO_NATIVE_MIXER source=" + source.gameObject.name + " group=" + group.name + " readOnly=true");
                return group;
            }
            return null;
        }

        static string ClassifyContact(GameObject target, Collider collider)
        {
            var node = collider ? collider.gameObject : target;
            if (!node) return null;
            var wear = node.GetComponentInParent<WearNTear>() ?? (target ? target.GetComponent<WearNTear>() : null);
            if (wear)
            {
                switch (wear.m_materialType.ToString())
                {
                    case "Wood": case "HardWood": case "Timberwood": return "wood";
                    case "Stone": case "Marble": case "Ashstone": case "Ancient": return "stone";
                    case "Iron": return "metal";
                    default: return null; // Ice is not silently relabelled stone.
                }
            }
            if (node.GetComponentInParent<TreeBase>() || node.GetComponentInParent<TreeLog>()) return "wood";
            if (node.GetComponentInParent<MineRock>() || node.GetComponentInParent<MineRock5>()) return "stone";
            // For generic destructibles inspect their actual native impact SFX
            // references, not the world object's display name or a new raycast.
            var destructible = node.GetComponentInParent<Destructible>();
            if (destructible)
            {
                var names = string.Join(" ", EffectPrefabs(destructible).Where(HasSound).Select(p => p.name)).ToLowerInvariant();
                if (names.Contains("wood")) return "wood";
                if (names.Contains("metal") || names.Contains("iron")) return "metal";
                if (names.Contains("stone") || names.Contains("rock")) return "stone";
            }
            // Soil/grass/unknown surfaces deliberately have no invented hard
            // stone hit. The swing cue still plays at native attack timing.
            return null;
        }
        static string BlockerMaterial(Humanoid defender)
        {
            var getBlocker = AccessTools.Method(typeof(Humanoid), "GetCurrentBlocker");
            var blocker = getBlocker?.Invoke(defender, null) as ItemDrop.ItemData;
            if (blocker?.m_shared == null) return null;
            var names = string.Join(" ", EffectPrefabs(blocker.m_shared).Where(HasSound).Select(p => p.name)).ToLowerInvariant();
            if (names.Contains("wood")) return "wood";
            if (names.Contains("metal") || names.Contains("iron") || names.Contains("bronze")) return "metal";
            if (names.Contains("stone")) return "stone";
            return null;
        }
        internal static void ObserveMeleeContact(Attack attack, object hitPoint, Vector3 position)
        {
            Safe(() =>
            {
                var attacker = AttackCharacter?.GetValue(attack) as Humanoid;
                var relay = Relay(attacker); if (!relay || hitPoint == null) return;
                var target = HitObject?.GetValue(hitPoint) as GameObject;
                var collider = HitCollider?.GetValue(hitPoint) as Collider;
                var character = target ? target.GetComponent<Character>() : null;
                if (!character && collider) character = collider.GetComponentInParent<Character>();
                // Native collision alone is not a body hit: dodge/block/armor
                // resolve later in Character.RPC_Damage on the victim owner.
                if (character) return;
                string material = ClassifyContact(target, collider);
                if (material != null) relay.EnvironmentImpact(material, position, target ? target.GetInstanceID() : collider.GetInstanceID());
            });
        }
        static void ConfirmCharacterContact(Character victim, HitData hit, string material)
        {
            if (!victim || hit == null || hit.m_ranged || material == null) return;
            var relay = Relay(hit.GetAttacker());
            if (relay) relay.ResolvedCharacterImpact(victim, material, hit.m_point);
        }

        [HarmonyPatch(typeof(Attack), nameof(Attack.Start))]
        static class AttackStart
        {
            static void Postfix(Humanoid character, bool __result)
            { if (__result) Safe(() => Relay(character)?.Windup()); }
        }
        [HarmonyPatch(typeof(Attack), nameof(Attack.OnAttackTrigger))]
        static class Swing
        {
            static void Prefix(Humanoid ___m_character)
            { Safe(() => Relay(___m_character)?.Swing()); }
        }
        [HarmonyPatch(typeof(Attack), "DoMeleeAttack")]
        static class MeleeContact
        {
            static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
            {
                var code = instructions.ToList();
                var sharedHit = AccessTools.Field(typeof(ItemDrop.ItemData.SharedData), "m_hitEffect");
                var weapon = AccessTools.Field(typeof(Attack), "m_weapon");
                var shared = AccessTools.Field(typeof(ItemDrop.ItemData), "m_shared");
                var hitGo = code.FindIndex(c => c.opcode == OpCodes.Ldfld && Equals(c.operand, HitObject));
                var hitSites = Enumerable.Range(0, code.Count).Where(i => code[i].opcode == OpCodes.Ldfld && Equals(code[i].operand, sharedHit)).ToArray();
                if (hitGo < 1 || hitSites.Length != 1) throw new InvalidOperationException("Native melee audio anchor changed; expected one real accepted-hit site.");
                int site = hitSites[0], start = site - 3;
                if (start < 0 || code[start].opcode != OpCodes.Ldarg_0 || !Equals(code[site - 2].operand, weapon)
                    || !Equals(code[site - 1].operand, shared) || !IsLoadLocal(code[site + 1]) || !IsLoadLocal(code[hitGo - 1]))
                    throw new InvalidOperationException("Native melee hit locals changed; audio observer was not injected.");
                // Original shared hit EffectList.Create executes exactly once
                // per accepted native hit point. Load those exact locals and
                // leave every original instruction/call/label in place.
                var extra = new List<CodeInstruction> { new CodeInstruction(OpCodes.Ldarg_0),
                    new CodeInstruction(code[hitGo - 1].opcode, code[hitGo - 1].operand),
                    new CodeInstruction(code[site + 1].opcode, code[site + 1].operand),
                    new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(MonkAudioHooks), nameof(ObserveMeleeContact))) };
                extra[0].labels.AddRange(code[start].labels); code[start].labels.Clear();
                extra[0].blocks.AddRange(code[start].blocks); code[start].blocks.Clear();
                code.InsertRange(start, extra); MeleeContactHookReady = true;
                return code;
            }
            static bool IsLoadLocal(CodeInstruction c) => c.opcode == OpCodes.Ldloc || c.opcode == OpCodes.Ldloc_S
                || c.opcode == OpCodes.Ldloc_0 || c.opcode == OpCodes.Ldloc_1 || c.opcode == OpCodes.Ldloc_2 || c.opcode == OpCodes.Ldloc_3;
        }
        [HarmonyPatch(typeof(Character), nameof(Character.ApplyDamage))]
        static class Damaged
        {
            static void Prefix(Character __instance, out float __state) { __state = __instance ? __instance.GetHealth() : 0; }
            static void Postfix(Character __instance, HitData hit, float __state)
            {
                Safe(() =>
                {
                    if (!__instance) return;
                    float actual = Mathf.Max(0, __state - __instance.GetHealth());
                    if (actual <= 0) return;
                    Relay(__instance)?.Hurt(actual);
                    if (hit != null && hit.GetTotalPhysicalDamage() > 0) ConfirmCharacterContact(__instance, hit, "body");
                });
            }
        }
        [HarmonyPatch(typeof(Humanoid), "BlockAttack")]
        static class Blocked
        {
            static void Postfix(Humanoid __instance, HitData hit, bool __result)
            { if (__result) Safe(() => ConfirmCharacterContact(__instance, hit, BlockerMaterial(__instance))); }
        }
        [HarmonyPatch(typeof(BaseAI), "SetAlerted")]
        static class Alerted
        {
            static void Prefix(BaseAI __instance, out bool __state) { __state = __instance.IsAlerted(); }
            static void Postfix(BaseAI __instance, bool __state)
            { if (!__state && __instance.IsAlerted()) Safe(() => Relay(__instance)?.Alert()); }
        }
        [HarmonyPatch(typeof(Character), nameof(Character.OnDeath))]
        static class Died
        {
            // Native OnDeath invokes effects/callbacks then destroys ZNetView.
            // Publish before that destruction so each controller owns its tail.
            static void Prefix(Character __instance)
            {
                if (!__instance || !__instance.GetComponent<HushedMonkInstance>() || !__instance.IsOwner()) return;
                Safe(() =>
                {
                    // Owner hears the tail synchronously even if the final
                    // network event cannot be dispatched before native destroy.
                    __instance.GetComponent<MonkAudioController>()?.OnDeath();
                    Relay(__instance)?.Death();
                });
            }
        }
    }

    public sealed class MonkAudioEventRelay : MonoBehaviour
    {
        const string EventRpc = "HM_AudioEventV1", ContactRpc = "HM_AudioContactV1";
        enum Cue { Windup = 1, Swing = 2, Wood = 3, Stone = 4, Metal = 5, Body = 6, Hurt = 7, Alert = 8, Death = 9 }
        ZNetView view; MonkAudioController controller; bool bound, dead;
        int outgoingSequence, lastSwingFrame = -1;
        readonly MonkAudioPolicy.EventSequenceGate receivedSequence = new MonkAudioPolicy.EventSequenceGate();
        float lastSwingTime = -100;
        readonly HashSet<int> environmentTargets = new HashSet<int>();
        readonly HashSet<ZDOID> characterTargets = new HashSet<ZDOID>();
        int emitted, received, duplicateRejected, contactRequestsRejected;
        public void Bind()
        {
            if (bound) return;
            if (!GetComponent<HushedMonkInstance>()) throw new InvalidOperationException("Unmarked actor cannot register monk audio RPCs.");
            view = GetComponent<ZNetView>(); controller = GetComponent<MonkAudioController>();
            if (!view || !view.IsValid() || !controller) throw new InvalidOperationException("Own audio relay requires a live native view and controller.");
            view.Register<ZPackage>(EventRpc, Receive);
            view.Register<ZPackage>(ContactRpc, ReceiveContact);
            bound = true;
        }
        bool Owner => bound && view && view.IsValid() && view.IsOwner();
        static bool Finite(Vector3 p) => !(float.IsNaN(p.x) || float.IsInfinity(p.x) || float.IsNaN(p.y) || float.IsInfinity(p.y) || float.IsNaN(p.z) || float.IsInfinity(p.z));
        void Send(Cue kind, Vector3 point, float amount = 0)
        {
            if (!Owner || !Finite(point)) return;
            var p = new ZPackage(); p.Write(++outgoingSequence); p.Write((int)kind); p.Write(point); p.Write(amount);
            // Deliver owner presentation before optional routing. The echo
            // carries the same sequence and is rejected by Receive, so this
            // does not double sounds on a host with a working local echo.
            emitted++; Receive(view.GetZDO().GetOwner(), new ZPackage(p.GetArray()));
            view.InvokeRPC(ZNetView.Everybody, EventRpc, p);
        }
        void Receive(long sender, ZPackage p)
        {
            try
            {
                if (!bound || !view || !view.IsValid() || sender != view.GetZDO().GetOwner() || !controller) { duplicateRejected++; return; }
                int sequence = p.ReadInt(); var kind = (Cue)p.ReadInt(); Vector3 point = p.ReadVector3(); float amount = p.ReadSingle();
                if (!Finite(point) || float.IsNaN(amount) || float.IsInfinity(amount) || amount < 0 || sequence <= 0
                    || kind < Cue.Windup || kind > Cue.Death || (point - transform.position).sqrMagnitude > 64) { duplicateRejected++; return; }
                if (!receivedSequence.Accept(sender,sequence)) { duplicateRejected++; return; }
                received++;
                switch (kind)
                {
                    case Cue.Windup: controller.OnAttackWindup(); break;
                    case Cue.Swing: controller.OnAttackHit(); break;
                    case Cue.Wood: controller.OnImpact("wood", point); break;
                    case Cue.Stone: controller.OnImpact("stone", point); break;
                    case Cue.Metal: controller.OnImpact("metal", point); break;
                    case Cue.Body: controller.OnImpact("body", point); break;
                    case Cue.Hurt: controller.OnDamaged(amount); break;
                    case Cue.Alert: controller.OnAlert(); break;
                    case Cue.Death: controller.OnDeath(); MonkDeathPresentation.Present(gameObject); break;
                }
            }
            catch (Exception ex) { HushedMonkPlugin.Log("HM_AUDIO_RPC_REJECTED " + ex.Message); }
        }
        static Cue MaterialCue(string material)
        {
            switch (material) { case "wood": return Cue.Wood; case "stone": return Cue.Stone; case "metal": return Cue.Metal; case "body": return Cue.Body; default: return 0; }
        }
        public void Windup() { if (!dead) Send(Cue.Windup, transform.position); }
        public void Swing()
        {
            if (!Owner || dead || lastSwingFrame == Time.frameCount) return;
            lastSwingFrame = Time.frameCount; lastSwingTime = Time.time;
            environmentTargets.Clear(); characterTargets.Clear(); Send(Cue.Swing, transform.position);
        }
        public void EnvironmentImpact(string material, Vector3 point, int target)
        {
            if (!Owner || dead || Time.time - lastSwingTime > 2.5f || !environmentTargets.Add(target)) return;
            var kind = MaterialCue(material); if (kind != 0) Send(kind, point);
        }
        public void ResolvedCharacterImpact(Character victim, string material, Vector3 point)
        {
            if (!bound || dead || !victim || !Finite(point)) return;
            var victimView = victim.GetComponent<ZNetView>(); var kind = MaterialCue(material);
            if (!victimView || !victimView.IsValid() || !victimView.IsOwner() || kind == 0) return;
            if (Owner) { AcceptContact(victimView.GetZDO().m_uid, kind, point); return; }
            // Damage/block resolution belongs to the victim's owner, which may
            // differ from the monk's. Ask the monk owner to emit it once; never
            // directly play a second local sound on that victim client.
            var p = new ZPackage(); p.Write(victimView.GetZDO().m_uid); p.Write((int)kind); p.Write(point);
            view.InvokeRPC(ContactRpc, p);
        }
        void ReceiveContact(long sender, ZPackage p)
        {
            try
            {
                if (!Owner) { contactRequestsRejected++; return; }
                ZDOID victimId = p.ReadZDOID(); var kind = (Cue)p.ReadInt(); Vector3 point = p.ReadVector3();
                var victim = ZNetScene.instance ? ZNetScene.instance.FindInstance(victimId) : null;
                var targetView = victim ? victim.GetComponent<ZNetView>() : null;
                if (!targetView || !targetView.IsValid() || targetView.GetZDO().GetOwner() != sender || !victim.GetComponent<Character>()) { contactRequestsRejected++; return; }
                AcceptContact(victimId, kind, point);
            }
            catch { contactRequestsRejected++; }
        }
        void AcceptContact(ZDOID victim, Cue kind, Vector3 point)
        {
            if (!Owner || dead || kind < Cue.Wood || kind > Cue.Body || !Finite(point) || (point - transform.position).sqrMagnitude > 36
                || Time.time - lastSwingTime > 2.5f || !characterTargets.Add(victim)) { contactRequestsRejected++; return; }
            Send(kind, point);
        }
        public void Hurt(float actual) { if (!dead && actual > 0) Send(Cue.Hurt, transform.position, actual); }
        public void Alert() { if (!dead) Send(Cue.Alert, transform.position); }
        public void Death()
        {
            if (!Owner || dead) return;
            dead = true;
            controller.OnDeath(); // Idempotent local delivery before the RPC.
            Send(Cue.Death, transform.position);
        }
        public object Snapshot() => new { bound, owner = Owner, emitted, received, duplicateRejected, contactRequestsRejected,
            meleeContactHookReady = MonkAudioHooks.MeleeContactHookReady,
            policy = "Owner emits unique sequenced own-actor events; victim-owner resolved contact requests are owner-validated and deduplicated per native swing. Multiplayer acceptance still requires actual multi-client tests." };
        void OnDestroy()
        {
            if (bound && view) { view.Unregister(EventRpc); view.Unregister(ContactRpc); }
            bound = false;
        }
    }
}
