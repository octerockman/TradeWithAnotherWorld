using UnityEngine;

namespace BlackAbbey.HushedMonk
{
    // Measure the coupled cord + bell about the fixed wrist suspension.
    // Spin about the hanging axis does not become an invented swing.
    public static class BellMotionMetrics
    {
        public readonly struct Signal
        {
            public readonly Vector3 rate;
            public readonly float angle;
            public readonly bool valid;
            public Signal(Vector3 rate, float angle, bool valid) { this.rate=rate; this.angle=angle; this.valid=valid; }
        }
        static bool Finite(Vector3 p) => Finite(p.x) && Finite(p.y) && Finite(p.z);
        static bool Finite(float x) => !float.IsNaN(x) && !float.IsInfinity(x);

        public static Signal Measure(Vector3 wristPivot, Vector3 bellPivot, Vector3 bellCom,
            Vector3 bellAngularVelocity, Vector3 cordAngularVelocity, Vector3 gravity)
        {
            if (!Finite(wristPivot) || !Finite(bellPivot) || !Finite(bellCom) ||
                !Finite(bellAngularVelocity) || !Finite(cordAngularVelocity) || !Finite(gravity)) return default;
            Vector3 ray=bellCom-wristPivot;
            float length=ray.magnitude;
            if (length < .01f || length > .5f || gravity.sqrMagnitude < .0001f) return default;
            Vector3 velocity=Vector3.Cross(cordAngularVelocity,bellPivot-wristPivot) +
                Vector3.Cross(bellAngularVelocity,bellCom-bellPivot);
            Vector3 rate=Vector3.ProjectOnPlane(velocity,ray/length)/length;
            float angle=Vector3.Angle(ray,gravity);
            return new Signal(rate,angle,Finite(rate) && Finite(angle));
        }
    }
}
