using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbey.HushedMonk
{
    // The invisible attack item supplies timing, not the Rancid Remains art,
    // green point light, poison/aura or VFX. The own authored clapper is separate.
    internal static class AttackTokenSanitizer
    {
        static string Hash(string value)
        { using (var sha = SHA256.Create()) return string.Concat(sha.ComputeHash(Encoding.UTF8.GetBytes(value)).Select(b => b.ToString("x2"))); }
        static string Name(Object value) => value ? value.name : null;
        static string PathFrom(Transform root, Transform node)
        { var names = new List<string>(); while (node && node != root) { names.Add(node.name); node = node.parent; } names.Reverse(); return string.Join("/", names); }
        static object[] Lights(GameObject root) => root.GetComponentsInChildren<Light>(true).Select(l => (object)new { path = PathFrom(root.transform, l.transform), enabled = l.enabled, active = l.gameObject.activeSelf, color = new[] { l.color.r, l.color.g, l.color.b, l.color.a }, intensity = l.intensity, range = l.range, shadows = l.shadows.ToString() }).ToArray();
        static object[] Effects(object value) => value.GetType().GetFields(BindingFlags.Public | BindingFlags.Instance).Where(f => f.FieldType == typeof(EffectList)).Select(f => (object)new { field = f.Name, prefabs = ((EffectList)f.GetValue(value))?.m_effectPrefabs?.Select(e => Name(e?.m_prefab)).ToArray() }).ToArray();
        static bool AudioOnly(GameObject prefab)
        {
            if (!prefab || prefab.GetComponentInChildren<Light>(true) || prefab.GetComponentInChildren<Renderer>(true) || prefab.GetComponentInChildren<ParticleSystem>(true) || prefab.GetComponentInChildren<EffectArea>(true) || prefab.GetComponentInChildren<Aoe>(true)) return false;
            return prefab.name.StartsWith("sfx_", StringComparison.OrdinalIgnoreCase) || prefab.GetComponentInChildren<AudioSource>(true) || prefab.GetComponentInChildren<ZSFX>(true);
        }
        static void KeepAudioOnly(object value, List<object> changes)
        {
            foreach (var field in value.GetType().GetFields(BindingFlags.Public | BindingFlags.Instance).Where(f => f.FieldType == typeof(EffectList)))
            {
                var list = (EffectList)field.GetValue(value);
                var source = list?.m_effectPrefabs ?? Array.Empty<EffectList.EffectData>();
                var kept = source.Where(e => e != null && AudioOnly(e.m_prefab)).ToArray();
                // Assign new containers only; never mutate native shared lists/data.
                field.SetValue(value, new EffectList { m_effectPrefabs = kept });
                changes.Add(new { scope = value.GetType().Name, field = field.Name, before = source.Select(e => Name(e?.m_prefab)).ToArray(), keptAudio = kept.Select(e => Name(e.m_prefab)).ToArray(), removed = source.Except(kept).Select(e => Name(e?.m_prefab)).ToArray() });
            }
        }
        public static object Clean(ItemDrop native, ItemDrop owned, Action<string> log)
        {
            if (!native || !owned || native == owned || native.gameObject == owned.gameObject) throw new InvalidOperationException("Only a distinct own attack-item clone can be sanitized.");
            string nativeDefinition = JsonUtility.ToJson(native); string sourceHash = Hash(nativeDefinition);
            var nativeLights = Lights(native.gameObject); var ownLightsBefore = Lights(owned.gameObject);
            int nativeEffectAreas = native.GetComponentsInChildren<EffectArea>(true).Length, nativeAoes = native.GetComponentsInChildren<Aoe>(true).Length;
            var shared = owned.m_itemData.m_shared;
            var borrowedStatuses = new { attack = Name(shared.m_attackStatusEffect), equip = Name(shared.m_equipStatusEffect) };
            var borrowedSpawns = new { sharedHit = Name(shared.m_spawnOnHit), sharedTerrain = Name(shared.m_spawnOnHitTerrain), attackHit = Name(shared.m_attack.m_spawnOnHit), attackTrigger = Name(shared.m_attack.m_spawnOnTrigger), secondaryHit = Name(shared.m_secondaryAttack.m_spawnOnHit), secondaryTrigger = Name(shared.m_secondaryAttack.m_spawnOnTrigger) };
            var beforeEffectLists = new { shared = Effects(shared), attack = Effects(shared.m_attack), secondary = Effects(shared.m_secondaryAttack) };
            var attach = owned.transform.Find("attach");
            if (!attach) throw new InvalidOperationException("Native attack-token attachment interface missing.");
            var removedBranches = attach.Cast<Transform>().Select(t => PathFrom(owned.transform, t)).ToArray();
            var removedControllers = attach.GetComponentsInChildren<MonoBehaviour>(true).Where(c => c).Select(c => new { path = PathFrom(owned.transform, c.transform), type = c.GetType().FullName }).ToArray();
            // This whole branch is native visible/poison FX. Keeping the empty
            // attach transform retains VisEquipment's native item interface.
            foreach (Transform child in attach.Cast<Transform>().ToArray()) Object.DestroyImmediate(child.gameObject);
            foreach (var controller in attach.GetComponents<MonoBehaviour>()) Object.DestroyImmediate(controller);
            foreach (var flicker in owned.GetComponentsInChildren<LightFlicker>(true)) Object.DestroyImmediate(flicker);
            foreach (var light in owned.GetComponentsInChildren<Light>(true)) Object.DestroyImmediate(light);
            foreach (var area in owned.GetComponentsInChildren<EffectArea>(true)) Object.DestroyImmediate(area);
            foreach (var aoe in owned.GetComponentsInChildren<Aoe>(true)) Object.DestroyImmediate(aoe);
            foreach (var renderer in owned.GetComponentsInChildren<Renderer>(true)) Object.DestroyImmediate(renderer);
            foreach (var filter in owned.GetComponentsInChildren<MeshFilter>(true)) Object.DestroyImmediate(filter);
            foreach (var particles in owned.GetComponentsInChildren<ParticleSystem>(true)) Object.DestroyImmediate(particles);
            // No borrowed on-hit/equipped status or spawned poison entity is
            // part of this plain blunt clapper. Native audio is retained below.
            shared.m_attackStatusEffect = null; shared.m_equipStatusEffect = null; shared.m_attackStatusEffectChance = 0;
            shared.m_spawnOnHit = null; shared.m_spawnOnHitTerrain = null;
            shared.m_attack.m_spawnOnHit = null; shared.m_attack.m_spawnOnTrigger = null;
            shared.m_secondaryAttack.m_spawnOnHit = null; shared.m_secondaryAttack.m_spawnOnTrigger = null;
            var effectChanges = new List<object>(); KeepAudioOnly(shared, effectChanges); KeepAudioOnly(shared.m_attack, effectChanges); KeepAudioOnly(shared.m_secondaryAttack, effectChanges);
            int lights = owned.GetComponentsInChildren<Light>(true).Length, areas = owned.GetComponentsInChildren<EffectArea>(true).Length, aoes = owned.GetComponentsInChildren<Aoe>(true).Length;
            bool nativeUnchanged = Hash(JsonUtility.ToJson(native)) == sourceHash && native.GetComponentsInChildren<Light>(true).Length == nativeLights.Length;
            if (!nativeUnchanged || lights != 0 || areas != 0 || aoes != 0 || owned.GetComponentsInChildren<Renderer>(true).Length != 0 || owned.GetComponentsInChildren<ParticleSystem>(true).Length != 0 || attach.childCount != 0) throw new InvalidOperationException("Own attack-token cleanup/source-preservation assertion failed.");
            var receipt = new { schema = "hushed-monk.owned-attack-token-sanitization.v1", nativePrefab = native.name, ownPrefab = owned.name, nativeLights, ownLightsBefore, nativeVisualLightsRemoved = ownLightsBefore.Length, ownAttackTokenLightCount = lights, nativeEffectAreaCount = nativeEffectAreas, nativeAoeCount = nativeAoes, ownAttackTokenEffectAreaCount = areas, ownAttackTokenAoeCount = aoes, removedNativeVisualBranches = removedBranches, removedNativeVisualControllers = removedControllers, borrowedStatuses, borrowedSpawns, beforeEffectLists, effectChanges, afterStatuses = new { attack = Name(shared.m_attackStatusEffect), equip = Name(shared.m_equipStatusEffect) }, nativeSerializedDefinitionSha256 = sourceHash, nativeSourceUnchanged = nativeUnchanged, attackAnimation = shared.m_attack.m_attackAnimation, attackRange = shared.m_attack.m_attackRange, bluntDamage = shared.m_damages.m_blunt, scope = "Only own invisible attack-item descendants/status/effect references cleaned. Own clapper/body/bell meshes/maps, native source prefab, AI, melee timing/range and configured blunt damage unchanged." };
            log?.Invoke("HM_ATTACK_TOKEN_CLEAN " + Newtonsoft.Json.JsonConvert.SerializeObject(receipt)); return receipt;
        }
    }
}
