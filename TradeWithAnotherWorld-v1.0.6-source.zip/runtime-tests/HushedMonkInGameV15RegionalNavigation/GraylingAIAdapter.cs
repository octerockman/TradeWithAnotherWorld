using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace BlackAbbey.HushedMonk
{
    // User requested Greyling decisions, not the Skeleton's AI defaults.
    // Only declared public behavioral scalars/enums cross this boundary.
    public static class GraylingAIAdapter
    {
        public const string SourcePrefab = "Greyling";
        public static readonly string[] FieldNames = {
            "m_viewRange","m_viewAngle","m_hearRange","m_mistVision","m_pathAgentType","m_moveMinAngle","m_smoothMovement","m_serpentMovement","m_serpentTurnRadius","m_jumpInterval",
            "m_randomCircleInterval","m_randomMoveInterval","m_randomMoveRange","m_randomFly","m_chanceToTakeoff","m_chanceToLand","m_groundDuration","m_airDuration","m_maxLandAltitude","m_takeoffTime","m_flyAltitudeMin","m_flyAltitudeMax","m_flyAbsMinAltitude",
            "m_avoidFire","m_afraidOfFire","m_avoidWater","m_avoidLava","m_skipLavaTargets","m_avoidLavaFlee","m_aggravatable","m_passiveAggresive","m_canBeAlerted","m_fleeRange","m_fleeAngle","m_fleeInterval",
            "m_alertRange","m_crownFearRange","m_fleeIfHurtWhenTargetCantBeReached","m_fleeUnreachableSinceAttacking","m_fleeUnreachableSinceHurt","m_fleeIfNotAlerted","m_fleeIfLowHealth","m_fleeTimeSinceHurt","m_fleeInLava","m_fleePheromoneMin","m_fleePheromoneMax",
            "m_circulateWhileCharging","m_circulateWhileChargingFlying","m_enableHuntPlayer","m_attackPlayerObjects","m_privateAreaTriggerTreshold","m_interceptTimeMax","m_interceptTimeMin","m_maxChaseDistance","m_minAttackInterval","m_circleTargetInterval","m_circleTargetDuration","m_circleTargetDistance",
            "m_wakeupRange","m_noiseWakeup","m_maxNoiseWakeupRange","m_wakeUpDelayMin","m_wakeUpDelayMax","m_avoidLand","m_consumeRange","m_consumeSearchRange","m_consumeSearchInterval"
        };
        public static readonly string[] MovementFields = { "m_speed","m_acceleration","m_walkSpeed","m_runSpeed","m_turnSpeed","m_runTurnSpeed","m_jumpForce","m_jumpForceForward","m_airControl" };
        static FieldInfo Field(Type type, string name)
        {
            var field = type.GetField(name, BindingFlags.Public | BindingFlags.Instance);
            if (field == null || !(field.FieldType.IsPrimitive || field.FieldType.IsEnum)) throw new InvalidOperationException("AI whitelist no longer matches installed public scalar field: " + name);
            return field;
        }
        public static object Audit(GameObject own, GameObject greyling)
        {
            var ai = own.GetComponent<MonsterAI>(); var source = greyling.GetComponent<MonsterAI>();
            var character = own.GetComponent<Character>(); var sourceCharacter = greyling.GetComponent<Character>();
            var rows = new List<object>(); bool passed = true;
            foreach (string name in FieldNames)
            {
                var field = Field(typeof(MonsterAI), name); object actual = field.GetValue(ai), expected = field.GetValue(source); bool equal = Equals(actual, expected); passed &= equal;
                rows.Add(new { field = name, actual, expected, equal });
            }
            foreach (string name in MovementFields)
            {
                var field = Field(typeof(Character), name); object actual = field.GetValue(character), expected = field.GetValue(sourceCharacter); bool equal = Equals(actual, expected); passed &= equal;
                rows.Add(new { field = name, actual, expected, equal });
            }
            return new { sourcePrefab = SourcePrefab, passed, fields = rows, overrides = new { awake = !ai.m_sleeping, automaticSleepDisabled = ai.m_fallAsleepDistance == 0, ownFaction = character.m_faction.ToString(), ownHealth = character.m_health, sourceSoundEffectsCopied = false, sourceConsumptionItemsCopied = false } };
        }
        public static void Apply(GameObject own, GameObject greyling, Action<string> log)
        {
            var ai = own.GetComponent<MonsterAI>(); var source = greyling.GetComponent<MonsterAI>();
            var character = own.GetComponent<Character>(); var sourceCharacter = greyling.GetComponent<Character>();
            if (!ai || !source || !character || !sourceCharacter) throw new InvalidOperationException("Expected real Skeleton and Greyling native components.");
            foreach (string name in FieldNames) { var field = Field(typeof(MonsterAI), name); field.SetValue(ai, field.GetValue(source)); }
            foreach (string name in MovementFields) { var field = Field(typeof(Character), name); field.SetValue(character, field.GetValue(sourceCharacter)); }
            ai.m_sleeping = false; ai.m_fallAsleepDistance = 0;
            // Source food references/audio/visual effects do not belong to this monk.
            ai.m_consumeItems = new List<ItemDrop>();
            log?.Invoke("HM_GREYLING_AI " + Newtonsoft.Json.JsonConvert.SerializeObject(Audit(own, greyling)));
        }
    }
}
