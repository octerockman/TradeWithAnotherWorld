using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace BlackAbbey.HushedMonk
{
    // Client-local coupled cosmetic pendulums. No physics body has colliders or
    // a ZNetView; the actor's own Rigidbody and world physics settings are untouched.
    public sealed class WristBellPhysics : MonoBehaviour
    {
        [Serializable]
        public sealed class Settings
        {
            // All three vectors are in the ORIGINAL fixed renderer's coordinates.
            public Vector3 pivotLocal, centerOfMassLocal, downLocal;
            public float mass = .15f;
            public float angularDamping = 1.25f, linearDamping = .20f;
            public float maximumSwingDegrees = 28f, twistLimitDegrees = 30f;
            public float shellRadius = .032f, shellHeight = .070f;
            public float teleportDistance = .65f, resetGapMetres = .12f;
            // Optional measured principal inertia about COM, per unit mass.
            // Zero selects the explicit hollow-bell approximation below.
            public Vector3 inertiaTensorPerUnitMass;
            public Quaternion inertiaTensorRotation = Quaternion.identity;
            public Settings Copy() => (Settings)MemberwiseClone();
        }

        [Serializable]
        public sealed class Telemetry
        {
            public bool configured, initialized, gravity, bodyIsKinematic, jointExists;
            public bool settingsRestored, initializationFailed;
            public bool fixedBandIsolated, rendererInsideActor, resourcesDestroyed;
            public bool bodyAlive, anchorAlive, jointAlive, clientLocal = true;
            public int colliderCount, fixedSteps, resetCount, initializationCount;
            public float currentAnchorGapMetres, maxAnchorGapMetres, maxRenderPivotErrorMetres;
            public float currentSwingDegrees, maxSwingDegrees, maxRenderedSwingDegrees, angularTravelDegrees, relativeAngularTravelDegrees;
            public float maximumAngularSpeed, maximumRenderTranslationCorrectionMetres;
            public float rawMaximumSwingDegrees, rawMaximumAngularSpeed, maximumHardStopCorrectionDegrees;
            public int hardStopProjectionCount, angularVelocityClampCount;
            public string angularConstraintMode;
            public float maximumFilteredAnchorLagMetres, maximumFilteredAnchorAcceleration, maximumFilteredAnchorSpeed;
            public float filteredAnchorAccelerationLimit, filteredAnchorSpeedLimit, rootTransportDistanceMetres;
            public string anchorDriverMode;
            public float mass, pendulumLengthMetres;
            public float[] worldGravity, bodyCenterOfMass, inertiaTensor;
            public string actor, cleanupReason, initializationFailure;
            public bool cordConfigured, cordBodyAlive, cordJointAlive, cordMeshAlive, cordRootPinned;
            public int cosmeticBodyCount, cordTriangleCount, cordVertexCount;
            public float cordPendulumLengthMetres, cordMass, maximumCordSwingDegrees, rawMaximumCordSwingDegrees;
            public float maxCordRootGapMetres, maxCordDistalDeformationErrorMetres, maxCordCentrelineSegmentErrorMetres;
            public float maximumCordEndpointDisplacementFromFixedPoseMetres, cordRelativeAngularTravelDegrees;
            public string cordMotionMode;
            public int cordFixedSteps;
            public bool idleHeld, audioMotionAllowed;
            public float idleSettle;
            public float maxCordRootJointGapMetres, maxCordBellJointGapMetres;
        }

        [SerializeField] GameObject owner;
        [SerializeField] Transform fixedFrame, hangingVisual;
        [SerializeField] Transform cordVisual;
        [SerializeField] bool cordConfigured;
        [SerializeField] Vector3 cordPivotLocal, cordBodyEndLocal;
        [SerializeField] Vector3[] serializedCordRingCentres;
        [SerializeField] int serializedCordTriangleCount;
        [SerializeField] int[] cordVertexRings, cordRootSamples, cordDistalSamples;
        [NonSerialized] Settings settings;
        // Runtime-loaded mod MonoBehaviours do not reliably clone a nested
        // managed Settings object. Only native Unity references and primitive
        // fields cross the prefab boundary; reconstruct the exact DTO locally.
        [SerializeField] int serializedSettingsVersion;
        [SerializeField] float pivotX, pivotY, pivotZ, comX, comY, comZ, downX, downY, downZ;
        [SerializeField] float storedMass, storedAngularDamping, storedLinearDamping;
        [SerializeField] float storedSwing, storedTwist, storedRadius, storedHeight, storedTeleport, storedResetGap;
        [SerializeField] float inertiaX, inertiaY, inertiaZ, inertiaQX, inertiaQY, inertiaQZ, inertiaQW;
        [SerializeField] bool configured;
        [SerializeField] Vector3 authoredVisualPosition, authoredVisualScale;
        [SerializeField] Quaternion authoredVisualRotation;
        [SerializeField] Vector3 authoredFixedPosition, authoredFixedScale;
        [SerializeField] Quaternion authoredFixedRotation;

        [NonSerialized] Rigidbody body, anchor;
        [NonSerialized] Rigidbody cordBody;
        [NonSerialized] ConfigurableJoint joint;
        [NonSerialized] ConfigurableJoint cordJoint;
        [NonSerialized] Mesh cordMesh, cordTemplateMesh;
        [NonSerialized] Vector3[] cordRestVertices, cordWorkingVertices, cordRingCentres;
        [NonSerialized] float[] cordSegmentLengths;
        [NonSerialized] Vector3[] cordWorkingCentres;
        [NonSerialized] Quaternion[] cordWorkingTwists;
        [NonSerialized] float[] cordTwistWeights;
        [NonSerialized] Vector3 cordEnd, cordCom;
        [NonSerialized] Quaternion baseCordRestRotation, previousCordRelativeRotation;
        [NonSerialized] float maxCordSwing, rawMaxCordSwing, maxCordRootGap, maxCordDistalError, maxCordLengthError, maxCordEndpointMotion, cordAngularTravel;
        [NonSerialized] float maxCordRootJointGap, maxCordBellJointGap;
        [NonSerialized] Character character;
        [NonSerialized] ZNetView networkView;
        [NonSerialized] Animator animator;
        [NonSerialized] Action<string> logger;
        [NonSerialized] bool initialized, cleaned;
        [NonSerialized] bool initializationFailed;
        [NonSerialized] string initializationFailure;
        [NonSerialized] string ownerLabel, cleanupReason;
        [NonSerialized] Vector3 bodyCom, renderPivotLocal, renderComLocal, renderPositionOffset;
        [NonSerialized] Quaternion renderRotationOffset, baseRestRotation, baseActorYaw;
        [NonSerialized] Vector3 lastPivot, lastActorPosition, previousGravity;
        [NonSerialized] Quaternion previousBodyRotation, previousRelativeRotation;
        [NonSerialized] int steps, resets, initializationCount;
        [NonSerialized] float maxGap, maxRenderError, maxSwing, currentSwing;
        [NonSerialized] float angularTravel, relativeAngularTravel, maxAngularSpeed, maxRenderCorrection;
        [NonSerialized] float rawMaxSwing, rawMaxAngularSpeed, maxHardStopCorrection;
        [NonSerialized] float maxRenderedSwing;
        [NonSerialized] int hardStopProjections, velocityClamps;
        [NonSerialized] Vector3 filteredWristOffset, filteredWristVelocity;
        [NonSerialized] float maxFilteredLag, maxFilteredAcceleration, maxFilteredSpeed, rootTransportDistance;
        [NonSerialized] BellRestPolicy restGate;
        [NonSerialized] float lastActorYaw,restRootYaw;
        [NonSerialized] Vector3 restRootPosition;
        const float AngularSpeedCap = 8f;
        const float TwistSpeedCap = 2f;
        const float AnchorNaturalFrequency = 10f;
        const float AnchorAccelerationLimit = 8f;
        const float AnchorSpeedLimit = .9f;
        const float MinimumCordLengthMetres = .005f;

        public Rigidbody DynamicBody => body;
        public Rigidbody AnchorBody => anchor;
        public Rigidbody CordBody => cordBody;
        public ConfigurableJoint CordJoint => cordJoint;
        public Transform CordTransform => cordVisual;
        public Rigidbody KinematicAnchor => anchor;
        public ConfigurableJoint Joint => joint;
        public bool Initialized => initialized;
        public bool AudioMotionAllowed => initialized && restGate!=null && restGate.Driven;
        public float CurrentAnchorGap => body && anchor && cordBody ? Mathf.Max(Vector3.Distance(cordBody.position, anchor.position), Vector3.Distance(body.position, cordBody.position + cordBody.rotation * cordEnd)) : 0;
        public float MaxAnchorGapMetres => maxGap;
        public float MaxRenderPivotErrorMetres => maxRenderError;
        public float MaximumSwingDegrees => maxSwing;
        public int FixedSteps => steps;
        public int ResetCount => resets;
        public bool ResourcesDestroyed => cleaned && !body && !anchor && !joint && !cordBody && !cordJoint && !cordMesh;

        public static WristBellPhysics Configure(GameObject actor, Transform fixedFrame,
            Transform hangingVisual, Settings settings, Action<string> log = null)
        {
            if (!actor || !fixedFrame || !hangingVisual || settings == null)
                throw new ArgumentException("Bell physics requires actor, fixed frame, hanging visual and measured settings.");
            if (!fixedFrame.IsChildOf(actor.transform) || hangingVisual.parent != fixedFrame)
                throw new ArgumentException("Keep the hanging renderer as a child of the original fixed bell frame.");
            Validate(settings);
            var result = actor.GetComponent<WristBellPhysics>() ?? actor.AddComponent<WristBellPhysics>();
            if (result.configured) throw new InvalidOperationException("Bell physics already configured on this actor.");
            result.owner = actor; result.fixedFrame = fixedFrame; result.hangingVisual = hangingVisual;
            result.settings = settings.Copy(); result.StoreSettings(settings); result.logger = log; result.configured = true;
            result.authoredVisualPosition = hangingVisual.localPosition;
            result.authoredVisualRotation = hangingVisual.localRotation;
            result.authoredVisualScale = hangingVisual.localScale;
            result.authoredFixedPosition = fixedFrame.localPosition;
            result.authoredFixedRotation = fixedFrame.localRotation;
            result.authoredFixedScale = fixedFrame.localScale;
            // Intentionally no bodies/joints/forces here: this also runs on
            // Jotunn's inactive registered template, before any live spawn.
            return result;
        }

        public void ConfigureCord(Transform visual, int[] vertexRings, Vector3[] ringCentres, Vector3 knotPivot,
            Vector3 distalBight, int[] rootSamples, int[] distalSamples)
        {
            if (!configured || cordConfigured || !visual || visual.parent != fixedFrame || vertexRings == null || vertexRings.Length < 4 ||
                ringCentres == null || ringCentres.Length < 2 || ringCentres.Length > 256 || rootSamples == null || rootSamples.Length < 1 || distalSamples == null || distalSamples.Length < 1)
                throw new ArgumentException("Exact cord source and measured variable rings are required.");
            for (int i = 0; i < vertexRings.Length; i++) if (vertexRings[i] < 0 || vertexRings[i] >= ringCentres.Length) throw new ArgumentException("Invalid cord vertex ring.");
            foreach (var p in ringCentres) if (!Finite(p)) throw new ArgumentException("Invalid measured cord centre.");
            if (!Finite(knotPivot) || !Finite(distalBight) || Vector3.Distance(knotPivot, distalBight) < MinimumCordLengthMetres)
                throw new ArgumentException("Cord suspension is not at the measured knot support.");
            foreach (int i in rootSamples) if (i < 0 || i >= vertexRings.Length || vertexRings[i] != 0) throw new ArgumentException("Invalid proximal cord sample.");
            foreach (int i in distalSamples) if (i < 0 || i >= vertexRings.Length || vertexRings[i] != ringCentres.Length - 1) throw new ArgumentException("Invalid distal cord sample.");
            var filter = visual.GetComponent<MeshFilter>();
            if (!filter || !filter.sharedMesh || filter.sharedMesh.vertexCount != vertexRings.Length || filter.sharedMesh.triangles.Length < 6 || filter.sharedMesh.triangles.Length % 3 != 0)
                throw new ArgumentException("Cord mesh differs from measured partition inventory.");
            cordVisual = visual; cordVertexRings = (int[])vertexRings.Clone();
            serializedCordRingCentres = (Vector3[])ringCentres.Clone(); serializedCordTriangleCount = filter.sharedMesh.triangles.Length / 3;
            cordPivotLocal = knotPivot; cordBodyEndLocal = distalBight;
            cordRootSamples = (int[])rootSamples.Clone(); cordDistalSamples = (int[])distalSamples.Clone(); cordConfigured = true;
        }

        void StoreSettings(Settings value)
        {
            pivotX = value.pivotLocal.x; pivotY = value.pivotLocal.y; pivotZ = value.pivotLocal.z;
            comX = value.centerOfMassLocal.x; comY = value.centerOfMassLocal.y; comZ = value.centerOfMassLocal.z;
            downX = value.downLocal.x; downY = value.downLocal.y; downZ = value.downLocal.z;
            storedMass = value.mass; storedAngularDamping = value.angularDamping; storedLinearDamping = value.linearDamping;
            storedSwing = value.maximumSwingDegrees; storedTwist = value.twistLimitDegrees;
            storedRadius = value.shellRadius; storedHeight = value.shellHeight;
            storedTeleport = value.teleportDistance; storedResetGap = value.resetGapMetres;
            inertiaX = value.inertiaTensorPerUnitMass.x; inertiaY = value.inertiaTensorPerUnitMass.y; inertiaZ = value.inertiaTensorPerUnitMass.z;
            inertiaQX = value.inertiaTensorRotation.x; inertiaQY = value.inertiaTensorRotation.y;
            inertiaQZ = value.inertiaTensorRotation.z; inertiaQW = value.inertiaTensorRotation.w;
            serializedSettingsVersion = 1;
        }
        bool RestoreSettings()
        {
            if (settings != null) return true;
            if (!configured) return false;
            try
            {
                if (serializedSettingsVersion != 1) throw new InvalidOperationException("Missing exact serialized bell settings; no guessed defaults used.");
                var restored = new Settings {
                    pivotLocal = new Vector3(pivotX, pivotY, pivotZ), centerOfMassLocal = new Vector3(comX, comY, comZ),
                    downLocal = new Vector3(downX, downY, downZ), mass = storedMass,
                    angularDamping = storedAngularDamping, linearDamping = storedLinearDamping,
                    maximumSwingDegrees = storedSwing, twistLimitDegrees = storedTwist,
                    shellRadius = storedRadius, shellHeight = storedHeight,
                    teleportDistance = storedTeleport, resetGapMetres = storedResetGap,
                    inertiaTensorPerUnitMass = new Vector3(inertiaX, inertiaY, inertiaZ),
                    inertiaTensorRotation = new Quaternion(inertiaQX, inertiaQY, inertiaQZ, inertiaQW)
                };
                Validate(restored); settings = restored; return true;
            }
            catch (Exception error) { FailInitialization("serialized configuration: " + error.Message); return false; }
        }
        void FailInitialization(string reason)
        {
            if (initializationFailed) return;
            initializationFailed = true; initializationFailure = reason;
            Cleanup("initialization failed: " + reason);
            Report("HM_BELL_PHYSICS_INIT_FAILED " + reason);
        }

        static void Validate(Settings s)
        {
            if (!Finite(s.pivotLocal) || !Finite(s.centerOfMassLocal) || !Finite(s.downLocal) ||
                (s.centerOfMassLocal - s.pivotLocal).sqrMagnitude < .0001f ||
                s.mass < .03f || s.mass > .5f || s.maximumSwingDegrees < 5 || s.maximumSwingDegrees > 45 ||
                s.twistLimitDegrees < 0 || s.twistLimitDegrees > 90 || s.angularDamping < 0 || s.angularDamping > 8 ||
                s.linearDamping < 0 || s.linearDamping > 5 || s.shellRadius < .005f || s.shellRadius > .08f ||
                s.shellHeight < .01f || s.shellHeight > .2f || s.teleportDistance < .2f || s.resetGapMetres < .02f)
                throw new ArgumentException("Invalid measured bell physics settings.");
        }
        static bool Finite(Vector3 v) => float.IsFinite(v.x) && float.IsFinite(v.y) && float.IsFinite(v.z);
        static Vector3 Down => Physics.gravity.sqrMagnitude > .00001f ? Physics.gravity.normalized : Vector3.down;
        static Quaternion Yaw(Transform actor)
        {
            Vector3 up = -Down, forward = Vector3.ProjectOnPlane(actor.forward, up);
            if (forward.sqrMagnitude < .00001f) forward = Vector3.ProjectOnPlane(Vector3.forward, up);
            if (forward.sqrMagnitude < .00001f) forward = Vector3.ProjectOnPlane(Vector3.right, up);
            return Quaternion.LookRotation(forward.normalized, up);
        }
        void Report(string text)
        { if (logger != null) logger(text); else Debug.Log(text); }

        bool LiveActor()
        {
            if (!configured || !cordConfigured || !cordVisual || !owner || !owner.activeInHierarchy || !fixedFrame || !hangingVisual ||
                !fixedFrame.gameObject.activeInHierarchy || !hangingVisual.gameObject.activeInHierarchy) return false;
            if (!character) character = owner.GetComponent<Character>();
            if (!networkView) networkView = owner.GetComponent<ZNetView>();
            if (!animator) animator = owner.GetComponentInChildren<Animator>(true);
            // No IsOwner requirement: every client independently simulates this
            // cosmetic assembly, including remote network actors.
            return character && !character.IsDead() && networkView && networkView.IsValid() &&
                animator && animator.isInitialized && animator.avatar && animator.avatar.isValid;
        }

        void LateUpdate()
        {
            if (initializationFailed) return;
            if (!LiveActor())
            {
                if (initialized) Cleanup(character && character.IsDead() ? "actor death" : "actor hidden/invalid");
                return;
            }
            if (!initialized)
            {
                if (!RestoreSettings()) return;
                try { Initialize(); }
                catch (Exception error) { FailInitialization(error.ToString()); return; }
            }
            if (!initialized || !body || !anchor || !cordBody) return;
            if(restGate?.Held!=true)EnforcePhysicalAngularStop();
            Vector3 wristPivot = fixedFrame.TransformPoint(cordPivotLocal);
            Vector3 pivot = wristPivot + cordBody.rotation * cordEnd;
            // Render orientation comes from the actual simulated pendulum.
            // Only the suspension translation is projected to this render
            // frame's animated wrist, eliminating fixed-step/interpolation gaps.
            hangingVisual.rotation = body.rotation * renderRotationOffset;
            Vector3 rawPosition = body.position + body.rotation * renderPositionOffset;
            Vector3 pivotOffset = hangingVisual.TransformVector(renderPivotLocal);
            Vector3 renderedPosition = pivot - pivotOffset;
            maxRenderCorrection = Mathf.Max(maxRenderCorrection, Vector3.Distance(rawPosition, renderedPosition));
            hangingVisual.position = renderedPosition;
            maxRenderError = Mathf.Max(maxRenderError, Vector3.Distance(hangingVisual.TransformPoint(renderPivotLocal), pivot));
            Vector3 renderedRay = hangingVisual.TransformPoint(renderComLocal) - hangingVisual.TransformPoint(renderPivotLocal);
            if (renderedRay.sqrMagnitude > .000001f) maxRenderedSwing = Mathf.Max(maxRenderedSwing, Vector3.Angle(renderedRay, Down));
            UpdateCordMesh();
        }

        void InitializeCordMesh()
        {
            var filter = cordVisual ? cordVisual.GetComponent<MeshFilter>() : null;
            if (!filter || !filter.sharedMesh || filter.sharedMesh.vertexCount != cordVertexRings.Length || filter.sharedMesh.triangles.Length != serializedCordTriangleCount * 3 ||
                serializedCordRingCentres == null || serializedCordRingCentres.Length < 2)
                throw new InvalidOperationException("Exact variable-ring cord inventory did not survive actor cloning.");
            cordTemplateMesh = filter.sharedMesh;
            cordMesh = Object.Instantiate(cordTemplateMesh); cordMesh.name = "HM_WristBell_Cord_Live_" + owner.GetInstanceID(); cordMesh.MarkDynamic();
            filter.sharedMesh = cordMesh;
            cordRestVertices = cordTemplateMesh.vertices; cordWorkingVertices = (Vector3[])cordRestVertices.Clone();
            cordRingCentres = (Vector3[])serializedCordRingCentres.Clone();
            cordSegmentLengths = new float[cordRingCentres.Length - 1];
            cordWorkingCentres = new Vector3[cordRingCentres.Length]; cordWorkingTwists = new Quaternion[cordRingCentres.Length];
            cordTwistWeights = new float[cordRingCentres.Length]; float length = 0;
            for (int i = 0; i < cordSegmentLengths.Length; i++)
            {
                cordSegmentLengths[i] = Vector3.Distance(cordRingCentres[i], cordRingCentres[i + 1]);
                if (cordSegmentLengths[i] < .000001f) throw new InvalidOperationException("Cord rings must have distinct ordered centres.");
                length += cordSegmentLengths[i]; cordTwistWeights[i + 1] = length;
            }
            for (int i = 1; i < cordTwistWeights.Length; i++) cordTwistWeights[i] /= length;
        }

        void UpdateCordMesh()
        {
            if (!cordMesh || !cordBody || cordRingCentres == null) return;
            // Work entirely in small renderer-local coordinates. Subtracting
            //6km dungeon translations from every tiny cord vertex would lose
            // avoidable precision. All whole-actor scale is applied once by
            // the fixedFrame transform, not baked into these source vertices.
            Quaternion localMotion = Quaternion.Inverse(fixedFrame.rotation) * cordBody.rotation;
            var centres = cordWorkingCentres; var twist = cordWorkingTwists;
            for (int r = 0; r < cordRingCentres.Length; r++)
            {
                centres[r] = r == 0 ? cordRingCentres[r] : cordPivotLocal + localMotion * (cordRingCentres[r] - cordPivotLocal);
                twist[r] = Quaternion.Slerp(Quaternion.identity, localMotion, cordTwistWeights[r]);
            }
            for (int i = 0; i < cordWorkingVertices.Length; i++)
            {
                int ring = cordVertexRings[i];
                cordWorkingVertices[i] = centres[ring] + twist[ring] * (cordRestVertices[i] - cordRingCentres[ring]);
            }
            cordMesh.vertices = cordWorkingVertices;
            cordMesh.RecalculateNormals(); cordMesh.RecalculateTangents(); cordMesh.RecalculateBounds();
            Vector3 root = Vector3.zero, distal = Vector3.zero;
            foreach (int i in cordRootSamples) root += cordWorkingVertices[i];
            foreach (int i in cordDistalSamples) distal += cordWorkingVertices[i];
            root /= cordRootSamples.Length; distal /= cordDistalSamples.Length;
            int last = cordRingCentres.Length - 1;
            maxCordRootGap = Mathf.Max(maxCordRootGap, fixedFrame.TransformVector(root - cordRingCentres[0]).magnitude);
            maxCordDistalError = Mathf.Max(maxCordDistalError, fixedFrame.TransformVector(distal - centres[last]).magnitude);
            maxCordEndpointMotion = Mathf.Max(maxCordEndpointMotion, fixedFrame.TransformVector(distal - cordRingCentres[last]).magnitude);
            for (int i = 0; i < cordSegmentLengths.Length; i++) maxCordLengthError = Mathf.Max(maxCordLengthError,
                Mathf.Abs(fixedFrame.TransformVector(centres[i + 1] - centres[i]).magnitude - fixedFrame.TransformVector(cordRingCentres[i + 1] - cordRingCentres[i]).magnitude));
        }

        void Initialize()
        {
            ownerLabel = owner.name + "#" + owner.GetInstanceID(); cleaned = false; cleanupReason = null;
            if (!cordConfigured || !cordVisual) throw new InvalidOperationException("Measured cord suspension configuration is required.");
            Vector3 wristPivot = fixedFrame.TransformPoint(cordPivotLocal);
            Vector3 pivot = fixedFrame.TransformPoint(settings.pivotLocal);
            Quaternion sourceRotation = hangingVisual.rotation;
            renderPivotLocal = hangingVisual.InverseTransformPoint(pivot);
            renderComLocal = hangingVisual.InverseTransformPoint(fixedFrame.TransformPoint(settings.centerOfMassLocal));
            renderPositionOffset = Quaternion.Inverse(sourceRotation) * (hangingVisual.position - pivot);
            renderRotationOffset = Quaternion.Inverse(sourceRotation) * hangingVisual.rotation;
            bodyCom = Quaternion.Inverse(sourceRotation) * (fixedFrame.TransformPoint(settings.centerOfMassLocal) - pivot);
            if (!Finite(bodyCom) || bodyCom.magnitude < .01f || bodyCom.magnitude > .25f)
                throw new InvalidOperationException("Measured bell COM/pivot are outside the cosmetic pendulum envelope.");
            // Gravity aligns the real COM beneath the joint; wrist roll is not
            // used as an artificial spring target that could hold it sideways.
            baseRestRotation = Quaternion.FromToRotation(sourceRotation * bodyCom.normalized, Down) * sourceRotation;
            cordEnd = Quaternion.Inverse(sourceRotation) * (fixedFrame.TransformPoint(cordBodyEndLocal) - wristPivot);
            if (!Finite(cordEnd) || cordEnd.magnitude < MinimumCordLengthMetres || cordEnd.magnitude > .20f) throw new InvalidOperationException("Measured live cord pendulum length is outside its envelope.");
            cordCom = cordEnd * .5f;
            baseCordRestRotation = Quaternion.FromToRotation(sourceRotation * cordEnd.normalized, Down) * sourceRotation;
            baseActorYaw = Yaw(owner.transform);
            anchor = NewBody("Anchor", wristPivot, baseCordRestRotation, true);
            cordBody = NewBody("Cord", wristPivot, baseCordRestRotation, false);
            body = NewBody("Body", wristPivot + baseCordRestRotation * cordEnd, baseRestRotation, false);
            // The cord is deliberately light relative to the bell while
            // keeping a bounded solver mass ratio. Cosmetic masses are tuning
            // parameters, not claims of measured hemp density.
            cordBody.mass = settings.mass * .25f; cordBody.centerOfMass = cordCom;
            cordBody.linearDamping = settings.linearDamping; cordBody.angularDamping = settings.angularDamping;
            cordBody.maxAngularVelocity = AngularSpeedCap; cordBody.solverIterations = 24; cordBody.solverVelocityIterations = 16;
            cordBody.sleepThreshold = .00001f;
            float cordRadius = .0023f * fixedFrame.lossyScale.magnitude / Mathf.Sqrt(3);
            float rodAxial = cordBody.mass * cordRadius * cordRadius * .5f;
            float rodTransverse = cordBody.mass * (cordEnd.sqrMagnitude / 12f + cordRadius * cordRadius * .25f);
            cordBody.inertiaTensor = new Vector3(Mathf.Max(rodTransverse, .000001f), Mathf.Max(rodAxial, .000001f), Mathf.Max(rodTransverse, .000001f));
            cordBody.inertiaTensorRotation = Quaternion.FromToRotation(Vector3.up, cordEnd.normalized);
            body.mass = settings.mass; body.centerOfMass = bodyCom;
            body.linearDamping = settings.linearDamping; body.angularDamping = settings.angularDamping;
            body.maxAngularVelocity = AngularSpeedCap; body.solverIterations = 24; body.solverVelocityIterations = 16;
            body.sleepThreshold = .00001f;
            Vector3 inertia;
            if (settings.inertiaTensorPerUnitMass.x > 0 && settings.inertiaTensorPerUnitMass.y > 0 && settings.inertiaTensorPerUnitMass.z > 0)
                inertia = settings.inertiaTensorPerUnitMass * settings.mass;
            else
            {
                float axial = settings.mass * settings.shellRadius * settings.shellRadius;
                float transverse = settings.mass * (settings.shellRadius * settings.shellRadius * .5f + settings.shellHeight * settings.shellHeight / 12f);
                inertia = new Vector3(transverse, axial, transverse);
            }
            // Supplied tensor is in renderer-local metres; a uniform mount
            // scale changes inertia by scale squared, while COM above already
            // uses actual live world-space measurements.
            float scaleSquared = fixedFrame.lossyScale.sqrMagnitude / 3f;
            inertia *= scaleSquared;
            body.inertiaTensor = new Vector3(Mathf.Max(inertia.x, .000001f), Mathf.Max(inertia.y, .000001f), Mathf.Max(inertia.z, .000001f));
            body.inertiaTensorRotation = settings.inertiaTensorRotation;
            cordJoint = NewJoint(cordBody, anchor, Vector3.zero, cordEnd.normalized);
            joint = NewJoint(body, cordBody, cordEnd, bodyCom.normalized);
            InitializeCordMesh();
            initialized = true; initializationCount++; previousGravity = Physics.gravity;
            restGate=new BellRestPolicy();lastActorYaw=owner.transform.eulerAngles.y;
            restRootPosition=owner.transform.position;restRootYaw=lastActorYaw;
            lastPivot = wristPivot; lastActorPosition = owner.transform.position;
            filteredWristOffset = wristPivot - lastActorPosition; filteredWristVelocity = Vector3.zero;
            previousBodyRotation = body.rotation; previousRelativeRotation = Quaternion.Inverse(anchor.rotation) * body.rotation;
            previousCordRelativeRotation = Quaternion.Inverse(anchor.rotation) * cordBody.rotation;
            body.WakeUp(); cordBody.WakeUp();
            Report("HM_BELL_PHYSICS_INIT actor=" + ownerLabel + " bellMass=" + settings.mass + " bellPendulum=" + bodyCom.magnitude + " cordPendulum=" + cordEnd.magnitude + " bodies=3 joints=2 cordTriangles=28 gravity=" + Physics.gravity + " colliders=0 clientLocal=true");
        }

        ConfigurableJoint NewJoint(Rigidbody moving, Rigidbody support, Vector3 connectedAnchor, Vector3 axis)
        {
            var result = moving.gameObject.AddComponent<ConfigurableJoint>(); result.connectedBody = support;
            result.autoConfigureConnectedAnchor = false; result.anchor = Vector3.zero; result.connectedAnchor = connectedAnchor;
            result.axis = axis;
            Vector3 second = Vector3.ProjectOnPlane(Vector3.up, axis);
            if (second.sqrMagnitude < .001f) second = Vector3.ProjectOnPlane(Vector3.forward, axis);
            result.secondaryAxis = second.normalized;
            result.xMotion = result.yMotion = result.zMotion = ConfigurableJointMotion.Locked;
            // PhysX angular-limit impulses became unstable on this tiny,
            // colliderless body under the animated support's acceleration.
            // Keep the real positional joint and gravity; apply the physical
            // angular hard stop and velocity projection explicitly below.
            result.angularXMotion = result.angularYMotion = result.angularZMotion = ConfigurableJointMotion.Free;
            result.enableCollision = false; result.enablePreprocessing = true;
            // With all angular motions free, native joint projection acts on
            // the locked position; there is no angular cone left to fight it.
            result.projectionMode = JointProjectionMode.PositionAndRotation; result.projectionDistance = .003f;
            result.breakForce = result.breakTorque = float.PositiveInfinity;
            return result;
        }

        Rigidbody NewBody(string role, Vector3 position, Quaternion rotation, bool kinematic)
        {
            var ob = new GameObject("HM_WristBell_" + owner.GetInstanceID() + "_" + initializationCount + "_" + role);
            ob.hideFlags = HideFlags.DontSave; ob.transform.SetPositionAndRotation(position, rotation);
            // Renderers stay on the actor. These three root objects have no
            // geometry, colliders, network views, audio or combat components.
            if (owner.scene.IsValid()) SceneManager.MoveGameObjectToScene(ob, owner.scene);
            var rb = ob.AddComponent<Rigidbody>(); rb.isKinematic = kinematic; rb.useGravity = !kinematic;
            // A post-solve hard stop must not render an older interpolated
            // orientation that was outside its actual physical limit.
            rb.detectCollisions = false; rb.interpolation = RigidbodyInterpolation.None;
            return rb;
        }

        void FixedUpdate()
        {
            if (!initialized || !body || !anchor || !cordBody || !owner || !fixedFrame) return;
            if (!LiveActor()) { Cleanup(character && character.IsDead() ? "actor death" : "actor invalid"); return; }
            Vector3 pivot = fixedFrame.TransformPoint(cordPivotLocal);
            Vector3 actorPosition = owner.transform.position;
            Vector3 rootDelta = actorPosition - lastActorPosition;
            float dt=Mathf.Max(.0001f,Time.fixedDeltaTime),yaw=owner.transform.eulerAngles.y;
            if(restGate==null)restGate=new BellRestPolicy();
            restGate.Step(dt,Mathf.Max(Vector3.ProjectOnPlane(character.GetVelocity(),Down).magnitude,rootDelta.magnitude/dt),
                Mathf.Abs(Mathf.DeltaAngle(lastActorYaw,yaw))/dt,character.InAttack(),
                Vector3.Distance(actorPosition,restRootPosition),Mathf.Abs(Mathf.DeltaAngle(restRootYaw,yaw)));
            if(restGate.Driven){restRootPosition=actorPosition;restRootYaw=yaw;}
            Quaternion anchorRotation = Yaw(owner.transform) * Quaternion.Inverse(baseActorYaw) * baseCordRestRotation;
            if (!Finite(body.position) || !Finite(body.linearVelocity) || !Finite(body.angularVelocity) || !Finite(cordBody.position) || !Finite(cordBody.linearVelocity) || !Finite(cordBody.angularVelocity) ||
                Vector3.Distance(pivot, lastPivot) > settings.teleportDistance ||
                Vector3.Distance(owner.transform.position, lastActorPosition) > settings.teleportDistance * 2 ||
                CurrentAnchorGap > settings.resetGapMetres || (Physics.gravity - previousGravity).sqrMagnitude > .01f)
            {
                ResumeCosmeticBodies();restGate.Reset();
                restRootPosition=actorPosition;restRootYaw=yaw;
                cordBody.position = pivot; cordBody.rotation = anchorRotation;
                cordBody.linearVelocity = Vector3.zero; cordBody.angularVelocity = Vector3.zero;
                body.position = pivot + anchorRotation * cordEnd;
                body.rotation = Yaw(owner.transform) * Quaternion.Inverse(baseActorYaw) * baseRestRotation;
                body.linearVelocity = Vector3.zero; body.angularVelocity = Vector3.zero;
                anchor.position = pivot; anchor.rotation = anchorRotation;
                filteredWristOffset = pivot - actorPosition; filteredWristVelocity = Vector3.zero;
                resets++; body.WakeUp(); cordBody.WakeUp();
                ApplyIdleRest(pivot,anchorRotation,dt);
            }
            else if(restGate.Settle>0)ApplyIdleRest(pivot,anchorRotation,dt);
            else
            {
                ResumeCosmeticBodies();
                // Transport the entire cosmetic simulation with root motion.
                // This is a moving reference frame, not a delayed body trailing
                // behind the actor. Neither actor transform nor velocity changes.
                body.position += rootDelta; cordBody.position += rootDelta; anchor.position += rootDelta;
                rootTransportDistance += rootDelta.magnitude;
                Vector3 targetOffset = pivot - actorPosition;
                Vector3 acceleration = (targetOffset - filteredWristOffset) * (AnchorNaturalFrequency * AnchorNaturalFrequency)
                    - filteredWristVelocity * (2f * AnchorNaturalFrequency);
                acceleration = Vector3.ClampMagnitude(acceleration, AnchorAccelerationLimit);
                Vector3 previousVelocity = filteredWristVelocity;
                filteredWristVelocity = Vector3.ClampMagnitude(filteredWristVelocity + acceleration * dt, AnchorSpeedLimit);
                filteredWristOffset += filteredWristVelocity * dt;
                Vector3 driverPosition = actorPosition + filteredWristOffset;
                maxFilteredLag = Mathf.Max(maxFilteredLag, Vector3.Distance(driverPosition, pivot));
                maxFilteredAcceleration = Mathf.Max(maxFilteredAcceleration, (filteredWristVelocity - previousVelocity).magnitude / dt);
                maxFilteredSpeed = Mathf.Max(maxFilteredSpeed, filteredWristVelocity.magnitude);
                anchor.MovePosition(driverPosition); anchor.MoveRotation(anchorRotation);
                if (filteredWristVelocity.sqrMagnitude > .00000001f) { body.WakeUp(); cordBody.WakeUp(); }
            }
            if(!restGate.Held)EnforcePhysicalAngularStop();
            lastActorYaw=yaw;
            steps++; lastPivot = pivot; lastActorPosition = owner.transform.position; previousGravity = Physics.gravity;
            maxGap = Mathf.Max(maxGap, CurrentAnchorGap);
            maxCordRootJointGap = Mathf.Max(maxCordRootJointGap, Vector3.Distance(cordBody.position, anchor.position));
            maxCordBellJointGap = Mathf.Max(maxCordBellJointGap, Vector3.Distance(body.position, cordBody.position + cordBody.rotation * cordEnd));
            currentSwing = Vector3.Angle(body.rotation * bodyCom.normalized, Down); maxSwing = Mathf.Max(maxSwing, currentSwing);
            Quaternion relative = Quaternion.Inverse(anchor.rotation) * body.rotation;
            angularTravel += Quaternion.Angle(previousBodyRotation, body.rotation);
            relativeAngularTravel += Quaternion.Angle(previousRelativeRotation, relative);
            previousBodyRotation = body.rotation; previousRelativeRotation = relative;
            Quaternion cordRelative = Quaternion.Inverse(anchor.rotation) * cordBody.rotation;
            cordAngularTravel += Quaternion.Angle(previousCordRelativeRotation, cordRelative); previousCordRelativeRotation = cordRelative;
            maxAngularSpeed = Mathf.Max(maxAngularSpeed, body.angularVelocity.magnitude);
        }

        void ResumeCosmeticBodies()
        {
            if(body.isKinematic){body.isKinematic=false;body.linearVelocity=body.angularVelocity=Vector3.zero;body.WakeUp();}
            if(cordBody.isKinematic){cordBody.isKinematic=false;cordBody.linearVelocity=cordBody.angularVelocity=Vector3.zero;cordBody.WakeUp();}
        }
        void ApplyIdleRest(Vector3 pivot,Quaternion cordRest,float dt)
        {
            // Preserve the real wrist attachment and gravity-down orientation.
            // Only the two collider-free cosmetic bodies are parked; never the
            // actor body, Animator, joint setup or global physics settings.
            float amount=restGate.Held?1:1-Mathf.Exp(-14f*dt);
            Quaternion bellRest=Yaw(owner.transform)*Quaternion.Inverse(baseActorYaw)*baseRestRotation;
            anchor.position=pivot;anchor.rotation=cordRest;
            cordBody.position=pivot;cordBody.rotation=Quaternion.Slerp(cordBody.rotation,cordRest,amount);
            body.position=pivot+cordBody.rotation*cordEnd;body.rotation=Quaternion.Slerp(body.rotation,bellRest,amount);
            if(!body.isKinematic){body.linearVelocity=Vector3.zero;body.angularVelocity*=1-amount;}
            if(!cordBody.isKinematic){cordBody.linearVelocity=Vector3.zero;cordBody.angularVelocity*=1-amount;}
            if(restGate.Held){body.isKinematic=true;cordBody.isKinematic=true;}
            filteredWristOffset=pivot-owner.transform.position;filteredWristVelocity=Vector3.zero;
        }

        void EnforcePhysicalAngularStop()
        {
            if (!body || !anchor || !cordBody || settings == null) return;
            Vector3 before = cordBody.position + cordBody.rotation * cordEnd;
            Vector3 beforeVelocity = cordBody.GetPointVelocity(before);
            LimitBody(cordBody, cordCom, anchor.linearVelocity, true);
            Vector3 after = cordBody.position + cordBody.rotation * cordEnd;
            // Transport the second pivot with an explicit first-joint angular
            // stop. Keeping the bell pivot continuous prevents the next
            // position solve from manufacturing a large corrective impulse.
            body.position += after - before;
            body.linearVelocity += cordBody.GetPointVelocity(after) - beforeVelocity;
            LimitBody(body, bodyCom, cordBody.GetPointVelocity(after), false);
        }

        void LimitBody(Rigidbody target, Vector3 localCom, Vector3 supportVelocity, bool isCord)
        {
            Vector3 down = Down, ray = (target.rotation * localCom).normalized;
            float rawAngle = Vector3.Angle(ray, down);
            Vector3 velocity = target.angularVelocity;
            rawMaxSwing = Mathf.Max(rawMaxSwing, rawAngle);
            if (isCord) rawMaxCordSwing = Mathf.Max(rawMaxCordSwing, rawAngle);
            rawMaxAngularSpeed = Mathf.Max(rawMaxAngularSpeed, velocity.magnitude);
            bool corrected = false;
            if (rawAngle > settings.maximumSwingDegrees)
            {
                Vector3 radial = Vector3.ProjectOnPlane(ray, down);
                if (radial.sqrMagnitude < .000001f) radial = Vector3.ProjectOnPlane(target.rotation * (isCord ? cordJoint.secondaryAxis : joint.secondaryAxis), down);
                if (radial.sqrMagnitude < .000001f) radial = Vector3.ProjectOnPlane(Vector3.right, down);
                float limit = settings.maximumSwingDegrees * Mathf.Deg2Rad;
                Vector3 boundedRay = (down * Mathf.Cos(limit) + radial.normalized * Mathf.Sin(limit)).normalized;
                Quaternion correction = Quaternion.FromToRotation(ray, boundedRay);
                target.rotation = correction * target.rotation;
                maxHardStopCorrection = Mathf.Max(maxHardStopCorrection, Quaternion.Angle(Quaternion.identity, correction));
                ray = boundedRay; hardStopProjections++; corrected = true;
                // Remove velocity driving farther into the stop, retaining
                // inward swing. This is an absorbing physical contact limit.
                Vector3 outward = Vector3.ProjectOnPlane(-down, ray).normalized;
                float outwardRate = Vector3.Dot(Vector3.Cross(velocity, ray), outward);
                if (outwardRate > 0) velocity -= Vector3.Cross(ray, outward) * outwardRate;
                velocity *= .65f;
            }
            float twist = Vector3.Dot(velocity, ray);
            float boundedTwist = Mathf.Clamp(twist, -TwistSpeedCap, TwistSpeedCap);
            if (Mathf.Abs(twist - boundedTwist) > .0001f)
            { velocity += ray * (boundedTwist - twist); velocityClamps++; corrected = true; }
            if (velocity.sqrMagnitude > AngularSpeedCap * AngularSpeedCap)
            { velocity = velocity.normalized * AngularSpeedCap; velocityClamps++; corrected = true; }
            if (corrected)
            {
                target.angularVelocity = velocity;
                // Rigidbody.linearVelocity is COM velocity. Project it onto
                // the same constrained motion so the next positional solve
                // cannot re-inject the discarded angular energy.
                target.linearVelocity = supportVelocity + Vector3.Cross(velocity, target.rotation * localCom);
            }
            float swing = Vector3.Angle(target.rotation * localCom.normalized, down);
            if (isCord) maxCordSwing = Mathf.Max(maxCordSwing, swing);
            else { currentSwing = swing; maxSwing = Mathf.Max(maxSwing, swing); }
            maxAngularSpeed = Mathf.Max(maxAngularSpeed, target.angularVelocity.magnitude);
        }

        public Telemetry Snapshot()
        {
            if (!initializationFailed && configured && settings == null) RestoreSettings();
            bool fixedUntouched = fixedFrame && (fixedFrame.localPosition - authoredFixedPosition).sqrMagnitude < .00000001f &&
                Quaternion.Angle(fixedFrame.localRotation, authoredFixedRotation) < .001f && (fixedFrame.localScale - authoredFixedScale).sqrMagnitude < .00000001f;
            return new Telemetry {
                configured = configured, initialized = initialized, gravity = body && body.useGravity,
                settingsRestored = settings != null, initializationFailed = initializationFailed, initializationFailure = initializationFailure,
                bodyIsKinematic = body && body.isKinematic, jointExists = joint,
                idleHeld=restGate?.Held==true,audioMotionAllowed=AudioMotionAllowed,idleSettle=restGate?.Settle??0,
                fixedBandIsolated = fixedUntouched, rendererInsideActor = owner && hangingVisual && hangingVisual.IsChildOf(owner.transform),
                bodyAlive = body, anchorAlive = anchor, jointAlive = joint, resourcesDestroyed = ResourcesDestroyed,
                colliderCount = (body ? body.GetComponentsInChildren<Collider>(true).Length : 0) + (anchor ? anchor.GetComponentsInChildren<Collider>(true).Length : 0) + (cordBody ? cordBody.GetComponentsInChildren<Collider>(true).Length : 0),
                fixedSteps = steps, resetCount = resets, initializationCount = initializationCount,
                currentAnchorGapMetres = CurrentAnchorGap, maxAnchorGapMetres = maxGap, maxRenderPivotErrorMetres = maxRenderError,
                currentSwingDegrees = currentSwing, maxSwingDegrees = maxSwing, maxRenderedSwingDegrees = maxRenderedSwing, angularTravelDegrees = angularTravel,
                relativeAngularTravelDegrees = relativeAngularTravel, maximumAngularSpeed = maxAngularSpeed,
                maximumRenderTranslationCorrectionMetres = maxRenderCorrection, mass = settings != null ? settings.mass : 0,
                rawMaximumSwingDegrees = rawMaxSwing, rawMaximumAngularSpeed = rawMaxAngularSpeed,
                hardStopProjectionCount = hardStopProjections, angularVelocityClampCount = velocityClamps,
                maximumHardStopCorrectionDegrees = maxHardStopCorrection,
                angularConstraintMode = "two real positional joints + explicit Rigidbody cone hard stops and post-solve velocity caps",
                maximumFilteredAnchorLagMetres = maxFilteredLag, maximumFilteredAnchorAcceleration = maxFilteredAcceleration,
                maximumFilteredAnchorSpeed = maxFilteredSpeed, filteredAnchorAccelerationLimit = AnchorAccelerationLimit,
                filteredAnchorSpeedLimit = AnchorSpeedLimit, rootTransportDistanceMetres = rootTransportDistance,
                anchorDriverMode = "root-transported cosmetic frame; acceleration-bounded critically damped wrist offset; cord render pinned to wrist and bell render pinned to real cord endpoint",
                pendulumLengthMetres = bodyCom.magnitude, worldGravity = Array(Physics.gravity),
                bodyCenterOfMass = Array(bodyCom), inertiaTensor = Array(body ? body.inertiaTensor : Vector3.zero),
                actor = ownerLabel, cleanupReason = cleanupReason
                ,cordConfigured = cordConfigured, cordBodyAlive = cordBody, cordJointAlive = cordJoint, cordMeshAlive = cordMesh,
                cordRootPinned = cordConfigured && maxCordRootGap < .00001f,
                cosmeticBodyCount = (body ? 1 : 0) + (anchor ? 1 : 0) + (cordBody ? 1 : 0),
                cordTriangleCount = cordMesh ? cordMesh.triangles.Length / 3 : 0, cordVertexCount = cordMesh ? cordMesh.vertexCount : 0,
                cordPendulumLengthMetres = cordEnd.magnitude, cordMass = cordBody ? cordBody.mass : 0,
                maximumCordSwingDegrees = maxCordSwing, rawMaximumCordSwingDegrees = rawMaxCordSwing,
                maxCordRootGapMetres = maxCordRootGap, maxCordDistalDeformationErrorMetres = maxCordDistalError,
                maxCordCentrelineSegmentErrorMetres = maxCordLengthError,
                maximumCordEndpointDisplacementFromFixedPoseMetres = maxCordEndpointMotion, cordRelativeAngularTravelDegrees = cordAngularTravel,
                cordFixedSteps = steps, maxCordRootJointGapMetres = maxCordRootJointGap, maxCordBellJointGapMetres = maxCordBellJointGap,
                cordMotionMode = "two coupled real gravity bodies: knot-to-bight cord plus independent bell; fixed proximal cord ring, real-body centreline, distributed cross-section twist"
            };
        }
        static float[] Array(Vector3 value) => new[] { value.x, value.y, value.z };

        void Cleanup(string reason)
        {
            initialized = false; cleaned = true; cleanupReason = reason;
            if (body) { body.isKinematic = true; body.detectCollisions = false; Object.Destroy(body.gameObject); }
            if (cordBody) { cordBody.isKinematic = true; cordBody.detectCollisions = false; Object.Destroy(cordBody.gameObject); }
            if (anchor) { anchor.detectCollisions = false; Object.Destroy(anchor.gameObject); }
            // Keep references until Unity actually destroys them so Snapshot's
            // resourcesDestroyed reflects real lifetime, not merely cleared fields.
            if (hangingVisual)
            { hangingVisual.localPosition = authoredVisualPosition; hangingVisual.localRotation = authoredVisualRotation; hangingVisual.localScale = authoredVisualScale; }
            if (cordVisual && cordTemplateMesh)
            {
                var filter = cordVisual.GetComponent<MeshFilter>();
                if (filter && filter.sharedMesh == cordMesh) filter.sharedMesh = cordTemplateMesh;
            }
            if (cordMesh) Object.Destroy(cordMesh);
        }
        void OnDisable() { if (initialized || body || anchor || cordBody || cordMesh) Cleanup("actor disabled"); }
        void OnDestroy() { Cleanup("actor destroyed"); }
    }
}
