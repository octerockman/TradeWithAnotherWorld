using System;
using System.Linq;
using UnityEngine;

namespace BlackAbbey.HushedMonk
{
    // Borrow the installed game's red blood prefab read-only. Only this
    // marked monk's two EffectList containers change; no native material,
    // effect asset, corpse, audio, AI or another creature is recoloured.
    internal static class MonkRedBlood
    {
        internal static object Apply(GameObject own, GameObject skeleton, GameObject nativeBlood)
        {
            if (!own || !own.GetComponent<HushedMonkInstance>() || !skeleton || own == skeleton ||
                !nativeBlood || nativeBlood.name != "vfx_BloodHit" ||
                nativeBlood.GetComponentsInChildren<ParticleSystem>(true).Length == 0)
                throw new InvalidOperationException("Own marked monk and actual native vfx_BloodHit required.");
            var target = own.GetComponent<Character>();
            var source = skeleton.GetComponent<Character>();
            if (!target || !source) throw new InvalidOperationException("Monk blood requires real Character components.");
            var nativeHit = source.m_hitEffects;
            var nativeDeath = source.m_deathEffects;
            var hitEntries = target.m_hitEffects?.m_effectPrefabs ?? Array.Empty<EffectList.EffectData>();
            var deathEntries = target.m_deathEffects?.m_effectPrefabs ?? Array.Empty<EffectList.EffectData>();
            // Replace the inherited dry bone dust, retaining unrelated hit
            // and death events. Existing audio isolation runs afterwards.
            var hit = hitEntries.Where(e => e?.m_prefab && e.m_prefab.name != "vfx_skeleton_hit" && e.m_prefab != nativeBlood).ToList();
            var death = deathEntries.Where(e => e?.m_prefab && e.m_prefab != nativeBlood).ToList();
            hit.Add(Blood(nativeBlood)); death.Add(Blood(nativeBlood));
            target.m_hitEffects = new EffectList { m_effectPrefabs = hit.ToArray() };
            target.m_deathEffects = new EffectList { m_effectPrefabs = death.ToArray() };
            if (!ReferenceEquals(source.m_hitEffects,nativeHit) || !ReferenceEquals(source.m_deathEffects,nativeDeath) ||
                ReferenceEquals(source.m_hitEffects,target.m_hitEffects) || ReferenceEquals(source.m_deathEffects,target.m_deathEffects))
                throw new InvalidOperationException("Blood assignment escaped the owned monk lists.");
            return new {
                schema = "hushed-monk.native-red-blood.v1", nativePrefab = nativeBlood.name,
                hitBloodCount = target.m_hitEffects.m_effectPrefabs.Count(e => e.m_prefab == nativeBlood),
                deathBloodCount = target.m_deathEffects.m_effectPrefabs.Count(e => e.m_prefab == nativeBlood),
                removedDryBoneHitDust = hitEntries.Any(e => e?.m_prefab && e.m_prefab.name == "vfx_skeleton_hit"),
                nativeAssetModified = false, nativeDefinitionContainersUnchanged = true,
                customCorpseAndOrangeRedExpirySmokeUnchanged = true,
                scope = "Owned Hushed Monk hit/death EffectLists only; native red blood particle prefab borrowed in memory."
            };
        }
        static EffectList.EffectData Blood(GameObject nativeBlood) => new EffectList.EffectData {
            m_prefab = nativeBlood, m_enabled = true, m_variant = -1,
            m_attach = false, m_follow = false, m_inheritParentRotation = false,
            m_inheritParentScale = false, m_multiplyParentVisualScale = false,
            m_randomRotation = false, m_scale = false
        };
    }
}
