using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbey.HushedMonk
{
    public sealed class MonkAudioBank : IDisposable
    {
        public sealed class ClipRecord
        {
            public string id, category, path, sha256;
            public int sampleRate, channels, bits, frames;
            public double duration;
            public bool loop;
            public float gain, pitchMin = 1, pitchMax = 1;
            [JsonIgnore] public AudioClip Clip;
        }
        sealed class Manifest
        {
            public string schema;
            public ClipRecord[] clips;
            public Dictionary<string, string[]> groups;
        }
        public sealed class Telemetry
        {
            public bool ready, disposed;
            public string manifestHash, failure;
            public int clipCount, loadedClipCount, decodeCount;
            public long decodedFrames, pcmBytes;
        }
        static readonly Dictionary<string, MonkAudioBank> Cache = new Dictionary<string, MonkAudioBank>(StringComparer.OrdinalIgnoreCase);
        readonly Dictionary<string, ClipRecord> clips = new Dictionary<string, ClipRecord>(StringComparer.Ordinal);
        readonly Dictionary<string, ClipRecord[]> groups = new Dictionary<string, ClipRecord[]>(StringComparer.Ordinal);
        public bool Ready { get; private set; }
        public string Failure { get; private set; }
        public string ManifestHash { get; private set; }
        public int ClipCount => clips.Count;
        int decodeCount; long decodedFrames, pcmBytes; bool disposed;

        public static MonkAudioBank Initialize(string manifestPath, Action<string> log = null)
        {
            string key;
            try { key = Path.GetFullPath(manifestPath); }
            catch (Exception error) { var bad = new MonkAudioBank(); bad.Failure = error.Message; log?.Invoke("HM_AUDIO_DISABLED " + bad.Failure); return bad; }
            if (Cache.TryGetValue(key, out var cached)) return cached;
            var bank = new MonkAudioBank(); Cache[key] = bank;
            try { bank.Load(key); log?.Invoke("HM_AUDIO_BANK_READY clips=" + bank.ClipCount + " manifest=" + bank.ManifestHash); }
            catch (Exception error)
            {
                bank.ClearClips(); bank.Failure = error.Message; bank.Ready = false;
                log?.Invoke("HM_AUDIO_DISABLED own audio only; enemy remains available: " + error);
            }
            return bank;
        }
        void Load(string path)
        {
            if (new FileInfo(path).Length > 1024 * 1024) throw new InvalidDataException("Oversized monk audio manifest.");
            var bytes = File.ReadAllBytes(path);
            if (bytes.Length > 1024 * 1024) throw new InvalidDataException("Oversized monk audio manifest.");
            ManifestHash = Hash(bytes);
            var manifest = JsonConvert.DeserializeObject<Manifest>(Encoding.UTF8.GetString(bytes).TrimStart('\ufeff'));
            if (manifest == null || manifest.schema != "hushed-monk.audio-bank.v1" || manifest.clips == null || manifest.clips.Length != 56 || manifest.groups == null)
                throw new InvalidDataException("Expected the selected 56-cue monk audio bank.");
            var directory = Path.GetDirectoryName(path);
            foreach (var entry in manifest.clips)
            {
                if (entry == null || string.IsNullOrWhiteSpace(entry.id) || clips.ContainsKey(entry.id) || string.IsNullOrWhiteSpace(entry.category) ||
                    string.IsNullOrEmpty(entry.path) || Path.GetFileName(entry.path) != entry.path || entry.path.Contains("..") || Path.IsPathRooted(entry.path) ||
                    !entry.path.EndsWith(".wav", StringComparison.OrdinalIgnoreCase) || !ValidHash(entry.sha256) ||
                    entry.sampleRate != 48000 || entry.channels != 1 || entry.bits != 16 || entry.frames <= 0 || entry.frames > 48000 * 30 ||
                    !MonkAudioPolicy.Finite(entry.gain) || entry.gain < 0 || entry.gain > 1 || entry.pitchMin != 1 || entry.pitchMax != 1 ||
                    double.IsNaN(entry.duration) || double.IsInfinity(entry.duration) || Math.Abs(entry.duration - entry.frames / 48000d) > .001)
                    throw new InvalidDataException("Invalid monk audio cue metadata: " + entry?.id);
                var full = Path.Combine(directory, entry.path);
                if ((File.GetAttributes(full) & FileAttributes.ReparsePoint) != 0) throw new InvalidDataException("Audio dependency cannot be a filesystem link.");
                if (new FileInfo(full).Length > 4 * 1024 * 1024) throw new InvalidDataException("Oversized monk WAV: " + entry.id);
                var raw = File.ReadAllBytes(full);
                if (raw.Length > 4 * 1024 * 1024 || !string.Equals(Hash(raw), entry.sha256, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("Monk WAV size/hash mismatch: " + entry.id);
                pcmBytes += raw.Length;
                if (pcmBytes > 32 * 1024 * 1024) throw new InvalidDataException("Monk bank exceeds bounded PCM budget.");
                var samples = DecodePcm16(raw, entry.frames);
                var clip = AudioClip.Create("HM Own | " + entry.id, samples.Length, 1, 48000, false);
                if (!clip || !clip.SetData(samples, 0)) { if (clip) Object.Destroy(clip); throw new InvalidDataException("Unity rejected own PCM: " + entry.id); }
                entry.Clip = clip; clips.Add(entry.id, entry); decodeCount++; decodedFrames += samples.Length;
            }
            var referenced = new HashSet<string>(StringComparer.Ordinal);
            if (manifest.groups.Count != MonkAudioPolicy.RequiredGroups.Length) throw new InvalidDataException("Unexpected monk audio groups.");
            foreach (var groupName in MonkAudioPolicy.RequiredGroups)
            {
                if (!manifest.groups.TryGetValue(groupName, out var ids) || ids == null || ids.Length == 0) throw new InvalidDataException("Missing monk cue group: " + groupName);
                var entries = new ClipRecord[ids.Length]; var seen = new HashSet<string>(StringComparer.Ordinal);
                for (int i = 0; i < ids.Length; i++)
                {
                    if (!seen.Add(ids[i]) || !clips.TryGetValue(ids[i], out entries[i])) throw new InvalidDataException("Invalid group reference: " + groupName);
                    if (entries[i].loop && groupName != "idleBreath" && groupName != "combatBreath") throw new InvalidDataException("A loop is referenced as an event cue.");
                    referenced.Add(ids[i]);
                }
                groups.Add(groupName, entries);
            }
            if (referenced.Count != clips.Count) throw new InvalidDataException("A selected monk cue has no playback group.");
            RequireLoop("idleBreath", "hm_breathing_idle_v1", 384000);
            RequireLoop("combatBreath", "hm_breathing_combat_steady_v2_loop", 182400);
            foreach (var entry in clips.Values)
                if (entry.loop && entry.id != "hm_breathing_idle_v1" && entry.id != "hm_breathing_combat_steady_v2_loop") throw new InvalidDataException("Unexpected loop cue.");
            Ready = true;
        }
        void RequireLoop(string group, string id, int frames)
        {
            var entries = groups[group];
            if (entries.Length != 1 || entries[0].id != id || !entries[0].loop || entries[0].frames != frames)
                throw new InvalidDataException("Selected breathing loop differs from checked source: " + group);
        }
        public ClipRecord Pick(string group, System.Random random, string previousId = null)
        {
            if (!Ready || disposed || !groups.TryGetValue(group, out var entries)) return null;
            if (entries.Length == 1) return entries[0];
            int offset = random.Next(entries.Length);
            if (entries[offset].id == previousId) offset = (offset + 1 + random.Next(entries.Length - 1)) % entries.Length;
            return entries[offset];
        }
        public Telemetry Snapshot() => new Telemetry { ready = Ready, disposed = disposed, manifestHash = ManifestHash, failure = Failure,
            clipCount = clips.Count, loadedClipCount = clips.Count, decodeCount = decodeCount, decodedFrames = decodedFrames, pcmBytes = pcmBytes };
        static string Hash(byte[] bytes)
        { using (var hash = SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
        static bool ValidHash(string value)
        { if (value == null || value.Length != 64) return false; foreach (char c in value) if (!Uri.IsHexDigit(c)) return false; return true; }
        static bool Tag(byte[] b, int p, string value)
        { if (p < 0 || p + value.Length > b.Length) return false; for (int i = 0; i < value.Length; i++) if (b[p + i] != value[i]) return false; return true; }
        static uint U32(byte[] b, int p) => (uint)(b[p] | b[p + 1] << 8 | b[p + 2] << 16 | b[p + 3] << 24);
        static int U16(byte[] b, int p) => b[p] | b[p + 1] << 8;
        public static float[] DecodePcm16(byte[] bytes, int expectedFrames)
        {
            if (bytes == null || bytes.Length < 44 || bytes.Length > 4 * 1024 * 1024 || !Tag(bytes, 0, "RIFF") || !Tag(bytes, 8, "WAVE") || U32(bytes, 4) + 8L != bytes.Length)
                throw new InvalidDataException("Invalid PCM WAV RIFF envelope.");
            bool format = false, data = false; int start = 0, count = 0;
            for (long at = 12; at < bytes.Length;)
            {
                if (at + 8 > bytes.Length) throw new InvalidDataException("Truncated WAV chunk.");
                int p = (int)at; uint length = U32(bytes, p + 4); long end = at + 8 + length, padded = end + (length & 1);
                if (padded > bytes.Length) throw new InvalidDataException("WAV chunk outside RIFF.");
                if (Tag(bytes, p, "fmt "))
                {
                    if (format || (length != 16 && length != 18) || U16(bytes, p + 8) != 1 || U16(bytes, p + 10) != 1 || U32(bytes, p + 12) != 48000 ||
                        U32(bytes, p + 16) != 96000 || U16(bytes, p + 20) != 2 || U16(bytes, p + 22) != 16) throw new InvalidDataException("Requires mono48k PCM16.");
                    format = true;
                }
                if (Tag(bytes, p, "data"))
                { if (data || length == 0 || length % 2 != 0 || length / 2 != expectedFrames) throw new InvalidDataException("PCM data/frame mismatch."); data = true; start = p + 8; count = (int)length / 2; }
                at = padded;
            }
            if (!format || !data) throw new InvalidDataException("Missing PCM format/data.");
            var result = new float[count]; double energy = 0;
            for (int i = 0; i < count; i++)
            {
                short sample = (short)U16(bytes, start + i * 2);
                if (sample == short.MinValue) throw new InvalidDataException("Monk PCM reaches negative full scale.");
                result[i] = sample / 32768f; energy += result[i] * result[i];
            }
            if (energy < 1e-12) throw new InvalidDataException("Empty/silent PCM cue.");
            return result;
        }
        void ClearClips() { foreach (var entry in clips.Values) if (entry.Clip) Object.Destroy(entry.Clip); clips.Clear(); groups.Clear(); }
        public void Dispose() { if (disposed) return; disposed = true; Ready = false; ClearClips(); }
        public static void Shutdown() { foreach (var bank in Cache.Values) bank.Dispose(); Cache.Clear(); }
    }
}
