using System;
using System.IO;
using UnityEngine;

namespace BlackAbbey.HushedMonk
{
    // Root freezes these after the exact authored source and export are checked.
    // Pending pins deliberately reject a load/build; no earlier source is substituted.
    public static class VisualSourceContract
    {
        public const string NativeSha256 = "9c161cb995f5a4238e5d1b1b7982e3fb5ccb19f7eb6e98c21aa4d9d9cb30801c";
        public const string PayloadSha256 = "b977d6f4d7e69aede58a23e4c910ff3654da65e1edf069ed8383b844d722e926";
        public const string HandGripSha256 = "6b0ea577d0064fa33d88f28d7d20237ccd453ff2e26a05baba777d4b6e285716";

        public static void Require(string payloadHash, string nativeHash)
        {
            if (NativeSha256.Length != 64 || PayloadSha256.Length != 64 ||
                !string.Equals(nativeHash, NativeSha256, StringComparison.Ordinal) ||
                !string.Equals(payloadHash, PayloadSha256, StringComparison.Ordinal))
                throw new InvalidDataException("Visual is not the exact checked Meshy Monk source/payload.");
        }
    }

    // Native Unity references and primitive inventory fields are the intended
    // serialized clone interface. Actual Unity clone retention is a separate check.
    public sealed class VisualInstanceBindings : MonoBehaviour
    {
        public Transform rightHand, leftHand, head, chest, leftShoulder, rightShoulder;
        public Transform leftFoot, rightFoot, clapper, bellFrame;
        public int sourceSkinJointCount, sourceRendererCount, sourceMaterialCount, runtimeRendererCount;
    }
}
