using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbey.HushedMonk
{
    // Only the authored wrist-bell triangles are separated. Positions, split
    // normals, UVs, tangents and the original material remain exact.
    public static class BellPartitionRuntime
    {
        [Serializable] sealed class Partition
        {
            public string schema, rendererName;
            public FileRecord sourcePayload;
            public int vertexCount, triangleCount;
            public int[] fixedTriangleIds, dynamicTriangleIds, cordTriangleIds;
            public int[] cordSourceVertexIds, cordVertexRings, cordRootSampleCompactVertexIds, cordDistalSampleCompactVertexIds;
            public float[] cordPivotRendererLocal, cordBodyEndRendererLocal, cordRingCentresRendererLocal;
            public float[] dynamicPivotRendererLocal, centerOfMassRendererLocal, authoredDownRendererLocal;
            public float[] inertiaTensorPerUnitMassPrincipalMetresSquared, inertiaTensorRotationXYZW;
        }
        static Vector3 V(float[] v)
        {
            if (v == null || v.Length != 3 || v.Any(f => float.IsNaN(f) || float.IsInfinity(f))) throw new InvalidDataException("Invalid bell attachment vector.");
            return new Vector3(v[0], v[1], v[2]);
        }
        public static void Apply(GameObject actor, string directory, string payloadHash, Transform fixedFrame, IList<Object> resources, Action<string> log)
        {
            string path = VisualRuntime.SafePath(directory, "bell-partition.json");
            if (new FileInfo(path).Length > 512 * 1024) throw new InvalidDataException("Oversized bell partition.");
            var data = JsonConvert.DeserializeObject<Partition>(File.ReadAllText(path));
            if (data == null || data.schema != "hushed-monk.wrist-bell-triangle-partition.v3" || data.sourcePayload?.sha256 != payloadHash || data.rendererName != fixedFrame.name) throw new InvalidDataException("Cord/bell partition is not bound to the current checked visual.");
            var filter = fixedFrame.GetComponent<MeshFilter>(); var renderer = fixedFrame.GetComponent<MeshRenderer>();
            if (!filter || !renderer || !filter.sharedMesh || !renderer.sharedMaterial) throw new InvalidDataException("Required authored wrist-bell renderer is missing.");
            Mesh source = filter.sharedMesh;
            int[] original = source.triangles;
            if (source.vertexCount != data.vertexCount || original.Length != data.triangleCount * 3 || data.fixedTriangleIds == null || data.dynamicTriangleIds == null || data.fixedTriangleIds.Length == 0 || data.dynamicTriangleIds.Length == 0) throw new InvalidDataException("Bell geometry differs from partition authority.");
            if (data.cordRingCentresRendererLocal == null || data.cordRingCentresRendererLocal.Length % 3 != 0) throw new InvalidDataException("Missing exact cord ring centres.");
            int ringCount = data.cordRingCentresRendererLocal.Length / 3;
            if (ringCount < 2 || ringCount > 256 || data.cordTriangleIds == null || data.cordTriangleIds.Length < 2 ||
                data.cordSourceVertexIds == null || data.cordSourceVertexIds.Length < 4 || data.cordVertexRings == null ||
                data.cordVertexRings.Length != data.cordSourceVertexIds.Length || data.cordVertexRings.Any(r => r < 0 || r >= ringCount) ||
                data.cordVertexRings.Distinct().Count() != ringCount)
                throw new InvalidDataException("Missing exact variable-ring source cord inventory.");
            int[] ids = data.fixedTriangleIds.Concat(data.dynamicTriangleIds).Concat(data.cordTriangleIds).ToArray();
            if (ids.Length != data.triangleCount || !ids.OrderBy(n => n).SequenceEqual(Enumerable.Range(0, data.triangleCount))) throw new InvalidDataException("Bell triangles are missing, duplicated or outside the source.");
            Mesh Part(int[] faces, string name)
            {
                var mesh = Object.Instantiate(source); mesh.name = name;
                mesh.triangles = faces.SelectMany(n => new[] { original[n * 3], original[n * 3 + 1], original[n * 3 + 2] }).ToArray();
                var vertices = source.vertices; var bounds = new Bounds(vertices[original[faces[0] * 3]], Vector3.zero);
                foreach (int face in faces) for (int j = 0; j < 3; j++) bounds.Encapsulate(vertices[original[face * 3 + j]]);
                mesh.bounds = bounds; resources.Add(mesh); return mesh;
            }
            filter.sharedMesh = Part(data.fixedTriangleIds, "HM_WristBand_Fixed_ExactTriangles");
            var hanging = new GameObject("HM_WRIST_BELL_HANGING"); hanging.layer = fixedFrame.gameObject.layer;
            hanging.transform.SetParent(fixedFrame, false);
            hanging.AddComponent<MeshFilter>().sharedMesh = Part(data.dynamicTriangleIds, "HM_WristBell_Hanging_ExactTriangles");
            var movingRenderer = hanging.AddComponent<MeshRenderer>(); movingRenderer.sharedMaterial = renderer.sharedMaterial;
            movingRenderer.shadowCastingMode = renderer.shadowCastingMode; movingRenderer.receiveShadows = renderer.receiveShadows;
            var sourceIds = data.cordTriangleIds.SelectMany(n => new[] { original[n * 3], original[n * 3 + 1], original[n * 3 + 2] }).Distinct().OrderBy(n => n).ToArray();
            if (!sourceIds.SequenceEqual(data.cordSourceVertexIds)) throw new InvalidDataException("Cord compact vertices differ from exact source faces.");
            var compactMap = sourceIds.Select((v, i) => new { v, i }).ToDictionary(x => x.v, x => x.i);
            var cordMesh = new Mesh { name = "HM_WristBell_Cord_ExactSource_Rest", indexFormat = source.indexFormat };
            cordMesh.vertices = sourceIds.Select(i => source.vertices[i]).ToArray();
            cordMesh.normals = sourceIds.Select(i => source.normals[i]).ToArray();
            cordMesh.tangents = sourceIds.Select(i => source.tangents[i]).ToArray();
            cordMesh.uv = sourceIds.Select(i => source.uv[i]).ToArray();
            cordMesh.triangles = data.cordTriangleIds.SelectMany(n => new[] { compactMap[original[n * 3]], compactMap[original[n * 3 + 1]], compactMap[original[n * 3 + 2]] }).ToArray();
            cordMesh.RecalculateBounds(); resources.Add(cordMesh);
            var cord = new GameObject("HM_WRIST_BELL_CORD"); cord.layer = fixedFrame.gameObject.layer;
            cord.transform.SetParent(fixedFrame, false);
            cord.AddComponent<MeshFilter>().sharedMesh = cordMesh;
            var cordRenderer = cord.AddComponent<MeshRenderer>(); cordRenderer.sharedMaterial = renderer.sharedMaterial;
            cordRenderer.shadowCastingMode = renderer.shadowCastingMode; cordRenderer.receiveShadows = renderer.receiveShadows;
            float[] q = data.inertiaTensorRotationXYZW;
            if (q == null || q.Length != 4 || q.Any(f => float.IsNaN(f) || float.IsInfinity(f))) throw new InvalidDataException("Missing measured bell inertia orientation.");
            var settings = new WristBellPhysics.Settings { pivotLocal = V(data.dynamicPivotRendererLocal), centerOfMassLocal = V(data.centerOfMassRendererLocal), downLocal = V(data.authoredDownRendererLocal), inertiaTensorPerUnitMass = V(data.inertiaTensorPerUnitMassPrincipalMetresSquared), inertiaTensorRotation = new Quaternion(q[0], q[1], q[2], q[3]) };
            var centres = Enumerable.Range(0, ringCount).Select(r => V(data.cordRingCentresRendererLocal.Skip(r * 3).Take(3).ToArray())).ToArray();
            var physics = WristBellPhysics.Configure(actor, fixedFrame, hanging.transform, settings, log);
            physics.ConfigureCord(cord.transform, data.cordVertexRings, centres, V(data.cordPivotRendererLocal), V(data.cordBodyEndRendererLocal), data.cordRootSampleCompactVertexIds, data.cordDistalSampleCompactVertexIds);
            log?.Invoke("HM_BELL_PARTITION_READY fixedTriangles=" + data.fixedTriangleIds.Length + " movingTriangles=" + data.dynamicTriangleIds.Length + " cordTriangles=" + data.cordTriangleIds.Length + " sourceTriangles=" + data.triangleCount + " partition=" + VisualRuntime.Hash(path) + " sourceRestGeometryAndMapsUnchanged=true cordConsumesRealPhysics=true");
        }
    }
}
