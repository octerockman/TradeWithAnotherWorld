using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json.Linq;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbey.HushedMonk
{
    // Explicit proof observer only. It never moves an actor, forces an AI
    // target, changes a camera, creates obstacles or manufactures death events.
    public sealed class MonkV4ProofProbe
    {
        readonly GameObject actor;
        readonly MonkDungeonNavigation navigation;
        readonly string actorId, directory, captureId;
        readonly bool dungeonScenario;
        readonly int ownRendererCount, ownRigidCount, ownSkinJointCount;
        readonly JObject initialScale;
        readonly List<object> detourAttempts = new List<object>();
        readonly List<object> captures = new List<object>();
        readonly List<string> captureErrors = new List<string>();
        JObject latestDeath, latestNavigation;
        MonkDeathPresentation.CorpseRecord corpseRecord;
        bool scaleAlwaysValid = true, navigationReady, detourPassed;
        bool deathStarted, visibleAfterRootDeath, visibleAtTwoSeconds, cameraVisibilitySeen, captureVisibilitySeen;
        bool physicalRigSeen, smokeParticlesSeen, corpseCaptureAttempted, smokeCaptureAttempted;
        bool smokeObservedBeforeHide, smokeObservedAfterHide;
        int scaleSamples, corpseSamples, maxActiveCorpses, maxActiveSmoke;
        int baselineCreated, baselineRemoved, baselinePuffs, baselineSmokeRemoved, baselineFailures;
        float deathTime, nextDetour;
        Vector3 lastCorpseCenter;

        public MonkV4ProofProbe(GameObject actor, string evidenceDirectory = null)
        {
            if (!actor || !actor.GetComponent<HushedMonkInstance>()) throw new ArgumentException("Own live proof actor required.");
            this.actor = actor; navigation = actor.GetComponent<MonkDungeonNavigation>();
            var view = actor.GetComponent<ZNetView>();
            actorId = view && view.IsValid() ? view.GetZDO().m_uid.ToString() : "instance:" + actor.GetInstanceID();
            dungeonScenario = MonkDungeonProofRoom.Active != null && MonkDungeonProofRoom.Active.Root;
            initialScale = JObject.FromObject(MonkScaleContract.Snapshot(actor));
            var own = actor.GetComponentsInChildren<Renderer>(true).Where(r => r.sharedMaterials.Length > 0
                && r.sharedMaterials.All(m => m && m.name.StartsWith("HM_", StringComparison.Ordinal))).ToArray();
            ownRendererCount = own.Length; ownRigidCount = own.Count(r => r is MeshRenderer && r.GetComponent<MeshFilter>());
            ownSkinJointCount = own.OfType<SkinnedMeshRenderer>().Sum(r => r.bones.Length);
            lastCorpseCenter = actor.transform.position + Vector3.up;
            captureId = Guid.NewGuid().ToString("N").Substring(0, 8);
            if (!string.IsNullOrWhiteSpace(evidenceDirectory))
            {
                if (!Path.IsPathRooted(evidenceDirectory) || !Directory.Exists(evidenceDirectory))
                    throw new ArgumentException("Proof capture directory must already exist and be absolute.");
                directory = Path.GetFullPath(evidenceDirectory);
            }
            latestDeath = JObject.FromObject(MonkDeathPresentation.Snapshot());
        }

        public void DeathStarted()
        {
            if (deathStarted) throw new InvalidOperationException("Proof death phase was already started.");
            deathStarted = true; deathTime = Time.time;
            latestDeath = JObject.FromObject(MonkDeathPresentation.Snapshot());
            baselineCreated = Int(latestDeath, "corpsesCreated"); baselineRemoved = Int(latestDeath, "corpsesRemoved");
            baselinePuffs = Int(latestDeath, "smokeCreated"); baselineSmokeRemoved = Int(latestDeath, "smokeRemoved");
            baselineFailures = Int(latestDeath, "failures");
        }

        public object Sample()
        {
            if (actor)
            {
                scaleSamples++; scaleAlwaysValid &= ActualScaleValid();
                if (navigation)
                {
                    latestNavigation = JObject.FromObject(navigation.Snapshot()); navigationReady |= navigation.Ready;
                    if (dungeonScenario && navigation.Ready && !detourPassed && Time.realtimeSinceStartup >= nextDetour)
                    { nextDetour = Time.realtimeSinceStartup + .5f; TryColumnDetour(); }
                }
            }
            latestDeath = JObject.FromObject(MonkDeathPresentation.Snapshot());
            if (deathStarted)
            {
                float elapsed = Time.time - deathTime;
                var corpse = Object.FindObjectsByType<MonkDeathPresentation.Corpse>(FindObjectsSortMode.None)
                    .FirstOrDefault(c => c && c.Record != null && c.Record.actorId == actorId);
                maxActiveCorpses = Mathf.Max(maxActiveCorpses, Int(latestDeath, "corpsesActive"));
                maxActiveSmoke = Mathf.Max(maxActiveSmoke, Int(latestDeath, "smokeActive"));
                if (corpse)
                {
                    corpseSamples++; corpseRecord = corpse.Record;
                    var bodies = corpse.Bodies.Where(b => b).ToArray();
                    if (bodies.Length > 0) lastCorpseCenter = bodies.Aggregate(Vector3.zero, (v, b) => v + b.worldCenterOfMass) / bodies.Length;
                    var renderers = corpse.GetComponentsInChildren<Renderer>(true);
                    bool renderEnabled = renderers.Length == ownRendererCount && renderers.All(r => r && r.enabled && r.gameObject.activeInHierarchy);
                    cameraVisibilitySeen |= renderers.Any(r => r && r.isVisible);
                    visibleAfterRootDeath |= !actor && elapsed <= .8f && renderEnabled;
                    visibleAtTwoSeconds |= elapsed >= 1.9f && elapsed <= 2.4f && renderEnabled;
                    var skins = renderers.OfType<SkinnedMeshRenderer>().ToArray();
                    physicalRigSeen |= bodies.Length == 15 && bodies.All(b => !b.isKinematic && b.useGravity)
                        && corpse.Joints.Count == 14 && corpse.Joints.All(j => j && j.connectedBody)
                        && skins.Length == 1 && skins[0].bones.Length == ownSkinJointCount && skins[0].bones.All(t => t && t.IsChildOf(corpse.transform))
                        && corpse.Record.clonedRigidMeshes == ownRigidCount;
                }
                foreach (var smoke in Object.FindObjectsByType<MonkDeathPresentation.Smoke>(FindObjectsSortMode.None))
                {
                    if (!smoke) continue;
                    var particles = smoke.GetComponent<ParticleSystem>();
                    if (particles && particles.particleCount > 0 && Int(latestDeath, "smokeCreated") > baselinePuffs)
                    {
                        smokeParticlesSeen = true;
                        smokeObservedBeforeHide |= corpse;
                        smokeObservedAfterHide |= !corpse;
                    }
                }
                if (directory != null && !corpseCaptureAttempted && elapsed >= .35f && corpse)
                { corpseCaptureAttempted = true; Capture("corpse", elapsed); }
                if (directory != null && !smokeCaptureAttempted && elapsed >= 2.65f && Int(latestDeath, "smokeActive") > 0)
                { smokeCaptureAttempted = true; Capture("smoke", elapsed); }
            }
            return new { scale = actor ? MonkScaleContract.Snapshot(actor) : initialScale, scaleSamples, scaleAlwaysValid,
                navigation = latestNavigation, navigationReady, detourPassed, detourAttempts,
                detourScope = dungeonScenario ? "Actual isolated R04 source geometry" : "Skipped outside actual R04 proof scenario; no detour pass is inferred",
                death = latestDeath, actorId, elapsedSinceDeath = deathStarted ? Time.time - deathTime : -1,
                corpseSamples, visibleAfterRootDeath, visibleAtTwoSeconds, cameraVisibilitySeen, captureVisibilitySeen, physicalRigSeen, smokeParticlesSeen,
                captures, captureErrors };
        }

        bool ActualScaleValid()
        {
            var marker = actor.GetComponent<MonkScaleMarker>(); var visual = actor.transform.Find("Visual"); var capsule = actor.GetComponent<CapsuleCollider>();
            float factor = MonkScaleContract.Factor;
            return marker && visual && capsule && Mathf.Abs(marker.factor - factor) < .0001f
                && Vector3.Distance(actor.transform.localScale, Vector3.one) < .0001f
                && Mathf.Abs(marker.visualFactor - MonkScaleContract.ActorScale) < .0001f
                && Vector3.Distance(visual.localScale, marker.sourceVisualScale * MonkScaleContract.ActorScale) < .0001f
                && Mathf.Abs(capsule.height - 1.68f * factor) < .0001f && Mathf.Abs(capsule.radius - .24f * factor) < .0001f
                && Vector3.Distance(capsule.center, new Vector3(0, .85f * factor, 0)) < .0001f
                && Mathf.Abs(capsule.bounds.size.y - 1.68f * factor) < .02f;
        }

        void TryColumnDetour()
        {
            var room = MonkDungeonProofRoom.Active;
            if (room == null || !room.Root || !actor || !navigation) return;
            var capsule = actor.GetComponent<CapsuleCollider>();
            if (!capsule) return;
            float radius = Mathf.Max(capsule.bounds.extents.x, capsule.bounds.extents.z), height = capsule.bounds.size.y;
            int mask = LayerMask.GetMask("static_solid");
            foreach (float z in new[] { 4f, 12f }) foreach (float x in new[] { -4f, 4f })
            {
                if (detourAttempts.Count >= 24) return;
                var start = room.Root.transform.TransformPoint(new Vector3(x, .05f, z - 2));
                var goal = room.Root.transform.TransformPoint(new Vector3(x, .05f, z + 3));
                if (!TryFloor(room.Root.transform, start, mask, out start) || !TryFloor(room.Root.transform, goal, mask, out goal)) continue;
                bool startFree = !Physics.CheckCapsule(start + Vector3.up * (radius + .06f), start + Vector3.up * (height - radius - .02f), radius, mask, QueryTriggerInteraction.Ignore);
                bool goalFree = !Physics.CheckCapsule(goal + Vector3.up * (radius + .06f), goal + Vector3.up * (height - radius - .02f), radius, mask, QueryTriggerInteraction.Ignore);
                float chest = Mathf.Min(1.4f, height * .6f);
                bool blocked = Physics.Linecast(start + Vector3.up * chest, goal + Vector3.up * chest, out var obstacle, mask, QueryTriggerInteraction.Ignore);
                var column = room.Root.transform.TransformPoint(new Vector3(x, 0, z));
                bool actualColumn = blocked && obstacle.collider && obstacle.collider.transform.IsChildOf(room.Root.transform)
                    && obstacle.collider.name.IndexOf("collision_structure", StringComparison.OrdinalIgnoreCase) >= 0
                    && Vector3.ProjectOnPlane(obstacle.point - column, Vector3.up).magnitude < 1.2f;
                if (!startFree || !goalFree || !actualColumn) continue;
                bool complete = navigation.TryProbePath(start, goal, out var corners);
                float straight = Vector3.ProjectOnPlane(goal - start, Vector3.up).magnitude, length = 0, lateral = 0;
                var direction = Vector3.ProjectOnPlane(goal - start, Vector3.up).normalized;
                bool segmentsClear = corners.Count > 1;
                for (int i = 0; i < corners.Count; i++)
                {
                    var displacement = Vector3.ProjectOnPlane(corners[i] - start, Vector3.up);
                    lateral = Mathf.Max(lateral, Vector3.Cross(direction, displacement).magnitude);
                    if (i == 0) continue;
                    length += Vector3.ProjectOnPlane(corners[i] - corners[i - 1], Vector3.up).magnitude;
                    if (Physics.Linecast(corners[i - 1] + Vector3.up * chest, corners[i] + Vector3.up * chest, mask, QueryTriggerInteraction.Ignore)) segmentsClear = false;
                }
                bool passed = complete && corners.Count >= 3 && lateral > .3f && length > straight + .15f && segmentsClear;
                detourAttempts.Add(new { passed, complete, start = V(start), goal = V(goal), actualColumn, obstruction = obstacle.collider.name,
                    columnCenter = V(column), obstructionPoint = V(obstacle.point), startFree, goalFree, corners = corners.Select(V).ToArray(),
                    cornerCount = corners.Count, lateralDeviation = lateral, straightLength = straight, routeLength = length, segmentsClear,
                    nativeAIForced = false, navigation = navigation.Snapshot() });
                if (passed) { detourPassed = true; return; }
            }
        }
        static bool TryFloor(Transform room, Vector3 point, int mask, out Vector3 grounded)
        {
            if (Physics.Raycast(point + Vector3.up, Vector3.down, out var hit, 2, mask, QueryTriggerInteraction.Ignore)
                && hit.collider && hit.collider.transform.IsChildOf(room) && hit.normal.y > .8f)
            { grounded = hit.point + Vector3.up * .03f; return true; }
            grounded = point; return false;
        }

        void Capture(string phase, float elapsed)
        {
            GameObject node = null; RenderTexture target = null; Texture2D image = null; var previous = RenderTexture.active;
            try
            {
                var main = Camera.main; if (!main) throw new InvalidOperationException("Actual game camera unavailable.");
                string file = Path.Combine(directory, "v4-" + phase + "-" + captureId + ".png");
                if (File.Exists(file)) throw new IOException("Diagnostic capture target already exists.");
                node = new GameObject("HM private V4 diagnostic camera"); node.hideFlags = HideFlags.DontSave;
                var camera = node.AddComponent<Camera>(); camera.CopyFrom(main); camera.enabled = false;
                camera.orthographic = false; camera.fieldOfView = 45; camera.aspect = 16f / 9; camera.nearClipPlane = .04f; camera.farClipPlane = 40;
                camera.transform.position = lastCorpseCenter + new Vector3(-2.5f, 1.8f, -3.5f); camera.transform.LookAt(lastCorpseCenter);
                target = new RenderTexture(960, 540, 24, RenderTextureFormat.ARGB32); target.Create(); camera.targetTexture = target;
                camera.Render(); RenderTexture.active = target;
                object geometry = null;
                if (phase == "corpse") geometry = ObserveCaptureVisibility(camera);
                image = new Texture2D(960, 540, TextureFormat.RGB24, false); image.ReadPixels(new Rect(0, 0, 960, 540), 0, 0); image.Apply();
                File.WriteAllBytes(file, ImageConversion.EncodeToPNG(image));
                captures.Add(new { phase, elapsedAfterDeath = elapsed, path = file, sha256 = VisualRuntime.Hash(file), bytes = new FileInfo(file).Length,
                    focus = V(lastCorpseCenter), width = 960, height = 540,
                    method = "Temporary in-engine diagnostic camera rendering the actual current scene; not a main gameplay view or an OS capture",
                    geometry, mainCameraChanged = false, actorOrPhysicsMovedForCapture = false });
            }
            catch (Exception error) { captureErrors.Add(phase + ": " + error); }
            finally
            {
                RenderTexture.active = previous;
                if (node) Object.Destroy(node); if (image) Object.Destroy(image);
                if (target) { target.Release(); Object.Destroy(target); }
            }
        }

        object ObserveCaptureVisibility(Camera camera)
        {
            var corpse = Object.FindObjectsByType<MonkDeathPresentation.Corpse>(FindObjectsSortMode.None)
                .FirstOrDefault(c => c && c.Record != null && c.Record.actorId == actorId);
            if (!corpse) return new { visible = false, reason = "Own corpse absent at actual capture" };
            var planes = GeometryUtility.CalculateFrustumPlanes(camera);
            var renderers = corpse.GetComponentsInChildren<Renderer>(true);
            int visibleBounds = renderers.Count(r => r && r.enabled && r.gameObject.activeInHierarchy
                && (camera.cullingMask & (1 << r.gameObject.layer)) != 0 && GeometryUtility.TestPlanesAABB(planes, r.bounds));
            int mask = LayerMask.GetMask("Default", "Default_small", "static_solid", "terrain", "piece", "character", "character_net", "character_noenv");
            var points = new List<object>(); int projected = 0, unobstructed = 0;
            foreach (var body in corpse.Bodies.Where(b => b))
            {
                var point = body.worldCenterOfMass; var viewport = camera.WorldToViewportPoint(point);
                bool onScreen = viewport.z > camera.nearClipPlane && viewport.z < camera.farClipPlane
                    && viewport.x > .02f && viewport.x < .98f && viewport.y > .02f && viewport.y < .98f;
                if (!onScreen) continue; projected++;
                var ray = point - camera.transform.position; float length = ray.magnitude;
                bool hit = Physics.Raycast(camera.transform.position, ray.normalized, out var obstacle, Mathf.Max(0, length - .03f), mask, QueryTriggerInteraction.Ignore);
                bool clear = !hit || (obstacle.collider && obstacle.collider.transform.IsChildOf(corpse.transform));
                if (clear) unobstructed++;
                points.Add(new { body = body.name, world = V(point), viewport = V(viewport), unobstructed = clear,
                    obstruction = hit && obstacle.collider ? obstacle.collider.name : null });
            }
            bool visible = visibleBounds > 0 && projected > 0 && unobstructed > 0;
            captureVisibilitySeen |= visible;
            return new { visible, visibleRendererBounds = visibleBounds, projectedBodyLandmarks = projected, unobstructedBodyLandmarks = unobstructed,
                cameraPosition = V(camera.transform.position), points,
                method = "Enabled source renderer frustum/culling check plus actual physical body-landmark projection and world/actor occlusion rays at capture time",
                limit = "Technical view geometry; direct inspection of the SHA-bound rendered frame remains the appearance review. Renderer.isVisible is retained separately because a transient manual Camera.Render need not update it." };
        }

        public void Check(Action<string, bool, object> check)
        {
            Sample();
            check("actual monk visual and physical dimensions match current selected scale", scaleSamples > 0 && scaleAlwaysValid,
                new { scaleSamples, initialScale, currentScale = actor ? MonkScaleContract.Snapshot(actor) : null });
            if (dungeonScenario)
            {
                check("own high-altitude navigation completed authored collider bake", navigationReady, latestNavigation);
                check("complete private nav path detours around actual R04 pillar", detourPassed,
                    new { actualRoomScenario = dungeonScenario, attempts = detourAttempts, forcedAI = false });
            }
            check("own corpse is visible after native actor death and persists at two seconds", deathStarted && visibleAfterRootDeath && visibleAtTwoSeconds && (cameraVisibilitySeen || captureVisibilitySeen),
                new { visibleAfterRootDeath, visibleAtTwoSeconds, cameraVisibilitySeen, captureVisibilitySeen, corpseSamples, captures, captureErrors });
            check("actual corpse has15bodies14joints and exact remapped source joints", physicalRigSeen && corpseRecord != null
                && corpseRecord.bodies == 15 && corpseRecord.joints == 14 && corpseRecord.skinnedBones == ownSkinJointCount
                && corpseRecord.renderers == ownRendererCount && corpseRecord.clonedRigidMeshes == ownRigidCount
                && corpseRecord.originalPoseCopied && corpseRecord.originalSkinAndMaterialBindings && corpseRecord.liveActorComponentsAbsent,
                corpseRecord);
            check("ragdoll reaches real floor with bounded joint separation", corpseRecord != null && corpseRecord.fixedSteps > 10
                && corpseRecord.floorContacts > 0 && corpseRecord.maximumPelvisTravel > .05f
                && corpseRecord.maximumJointGap < .15f && corpseRecord.maximumRenderedJointGap < .15f, corpseRecord);
            check("smoke starts before body removal and persists after removal", corpseRecord != null && corpseRecord.expired
                && corpseRecord.lifetime >= 2 && corpseRecord.lifetime <= 3.5f && corpseRecord.smokeAt > 0
                && corpseRecord.disappearedAt - corpseRecord.smokeAt >= .3f
                && Int(latestDeath, "corpsesCreated") - baselineCreated == 1 && Int(latestDeath, "smokeCreated") - baselinePuffs == 1
                && smokeParticlesSeen && smokeObservedBeforeHide && smokeObservedAfterHide,
                new { record = corpseRecord, smokeParticlesSeen, smokeObservedBeforeHide, smokeObservedAfterHide, latestDeath, maxActiveCorpses, maxActiveSmoke });
            check("corpse and smoke fully clean without presentation failures", corpseRecord != null && corpseRecord.expired
                && Int(latestDeath, "corpsesActive") == 0 && Int(latestDeath, "smokeActive") == 0
                && Int(latestDeath, "corpsesRemoved") - baselineRemoved == 1 && Int(latestDeath, "smokeRemoved") - baselineSmokeRemoved == 1
                && Int(latestDeath, "failures") == baselineFailures && !actor,
                new { latestDeath, initialFailures = baselineFailures, actorDestroyed = !actor });
            if (directory != null)
                check("actual corpse and smoke diagnostic frames saved", captures.Count == 2 && captureErrors.Count == 0,
                    new { captures, captureErrors, scope = "Technical capture integrity only; direct visual inspection remains separate." });
        }
        static int Int(JObject record, string key) => record?.Value<int?>(key) ?? 0;
        static float[] V(Vector3 value) => new[] { value.x, value.y, value.z };
    }
}
