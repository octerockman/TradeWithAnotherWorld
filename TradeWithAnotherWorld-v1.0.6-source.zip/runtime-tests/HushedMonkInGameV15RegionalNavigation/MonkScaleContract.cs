using System;
using UnityEngine;

namespace BlackAbbey.HushedMonk
{
    // Scale the accepted visual uniformly while sizing physical/native attack
    // dimensions explicitly. Character.GetHeight reads unscaled capsule values.
    public static class MonkScaleContract
    {
        public const float PreviousFactor = 1.5f;
        public const float ReductionFromPrevious = .15f;
        // Physical dimensions retain V5. Visual scale compensates only for the
        // new source body, preserving the prior final absolute crown height.
        public const float Factor = PreviousFactor * (1 - ReductionFromPrevious);
        public const float PreviousSourceBodyHeightMetres = 1.708461046218872f;
        public const float SourceBodyHeightMetres = 1.67f;
        public const float DesiredBodyHeightMetres = PreviousSourceBodyHeightMetres * Factor;
        public const float ActorScale = DesiredBodyHeightMetres / SourceBodyHeightMetres;
        public static object Apply(GameObject prefab, ItemDrop.ItemData.SharedData weapon)
        {
            if (!prefab || prefab.activeInHierarchy || weapon == null || weapon.m_attack == null)
                throw new InvalidOperationException("Scale requires the inactive own prefab and private weapon.");
            var visual = prefab.transform.Find("Visual");
            var capsule = prefab.GetComponent<CapsuleCollider>();
            var character = prefab.GetComponent<Character>();
            if (!visual || !capsule || !character || prefab.GetComponent<MonkScaleMarker>())
                throw new InvalidOperationException("Missing/already scaled character contract.");
            if ((prefab.transform.localScale - Vector3.one).sqrMagnitude > .00001f)
                throw new InvalidOperationException("Expected unchanged unit actor root.");
            Vector3 sourceScale = visual.localScale;
            visual.localScale = sourceScale * ActorScale;
            capsule.height = 1.68f * Factor;
            capsule.radius = .24f * Factor;
            capsule.center = new Vector3(0, .85f * Factor, 0);
            if (character.m_eye && !character.m_eye.IsChildOf(visual))
                character.m_eye.localPosition = new Vector3(0, 1.5f * Factor, .055f * Factor);
            ScaleAttack(weapon.m_attack);
            ScaleAttack(weapon.m_secondaryAttack);
            float scaledAiRange = weapon.m_aiAttackRange * Factor;
            weapon.m_aiAttackRange = MonkAttackApproachPolicy.Range(scaledAiRange, weapon.m_attack.m_attackRange);
            // Negative minimum is a native mode sentinel, not a distance to scale.
            weapon.m_aiAttackRangeMin = MonkAttackApproachPolicy.Minimum(weapon.m_aiAttackRangeMin < 0
                ? weapon.m_aiAttackRangeMin : weapon.m_aiAttackRangeMin * Factor, weapon.m_aiAttackRange);
            var marker = prefab.AddComponent<MonkScaleMarker>();
            marker.factor = Factor; marker.visualFactor = ActorScale; marker.sourceVisualScale = sourceScale;
            marker.scaledAuthoredAiRange = scaledAiRange; marker.attackApproachRange = weapon.m_aiAttackRange;
            return Snapshot(prefab);
        }
        static void ScaleAttack(Attack attack)
        {
            if (attack == null) return;
            attack.m_attackRange *= Factor;
            attack.m_attackHeight *= Factor;
            attack.m_attackHeightChar1 *= Factor;
            attack.m_attackHeightChar2 *= Factor;
            attack.m_attackOffset *= Factor;
            attack.m_attackRayWidth *= Factor;
            attack.m_attackRayWidthCharExtra *= Factor;
        }
        public static object Snapshot(GameObject actor)
        {
            var marker = actor ? actor.GetComponent<MonkScaleMarker>() : null;
            var visual = actor ? actor.transform.Find("Visual") : null;
            var capsule = actor ? actor.GetComponent<CapsuleCollider>() : null;
            var character = actor ? actor.GetComponent<Character>() : null;
            var humanoid = actor ? actor.GetComponent<Humanoid>() : null;
            var current = humanoid ? humanoid.GetCurrentWeapon()?.m_shared : null;
            return new { previousFactor = PreviousFactor, reductionFromPrevious = ReductionFromPrevious,
                requestedFactor = Factor, appliedFactor = marker ? marker.factor : 0,
                requestedVisualFactor = ActorScale, appliedVisualFactor = marker ? marker.visualFactor : 0,
                sourceBodyHeightMetres = SourceBodyHeightMetres, desiredBodyHeightMetres = DesiredBodyHeightMetres,
                rootScale = actor ? V(actor.transform.localScale) : null,
                visualScale = visual ? V(visual.localScale) : null,
                sourceVisualScale = marker ? V(marker.sourceVisualScale) : null,
                capsuleHeight = capsule ? capsule.height : 0, capsuleRadius = capsule ? capsule.radius : 0,
                capsuleCenter = capsule ? V(capsule.center) : null,
                actualWorldCapsuleHeight = capsule && actor.activeInHierarchy ? capsule.bounds.size.y : 0,
                eyeHeight = character && character.m_eye ? character.m_eye.position.y - actor.transform.position.y : 0,
                attackRange = current?.m_attack?.m_attackRange, attackHeight = current?.m_attack?.m_attackHeight,
                aiRange = current?.m_aiAttackRange, scaledAuthoredAiRange = marker ? marker.scaledAuthoredAiRange : 0,
                attackApproachRange = marker ? marker.attackApproachRange : 0,
                approachSafetyMarginMetres = MonkAttackApproachPolicy.SafetyMarginMetres,
                maximumVisibleClapperApproachMetres = MonkAttackApproachPolicy.MaximumApproachMetres,
                nativeDistanceRule = "Creature centre distance minus target radius only; own radius is not subtracted",
                movementSpeedUnchanged = true, damageAndTimingUnchanged = true };
        }
        static float[] V(Vector3 value) => new[] { value.x, value.y, value.z };
    }
    public sealed class MonkScaleMarker : MonoBehaviour
    { public float factor, visualFactor, scaledAuthoredAiRange, attackApproachRange; public Vector3 sourceVisualScale; }

    // Native AI stops on the target-surface threshold. Keep a small margin
    // before the real sweep limit so a slightly moving target is not already
    // outside that limit at the retained native Hit animation event.
    public static class MonkAttackApproachPolicy
    {
        public const float SafetyMarginMetres = .35f;
        // Target-surface distance, not centre-to-centre. The inherited mace
        // sweep is deliberately generous; it must not be the stopping range
        // for this much shorter, visibly held bell clapper.
        public const float MaximumApproachMetres = 1.35f;
        public static bool CanStart(float targetSurfaceDistance,float heightDifference) =>
            Finite(targetSurfaceDistance)&&Finite(heightDifference)&&targetSurfaceDistance<=MaximumApproachMetres&&Math.Abs(heightDifference)<=1.5f;
        static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        public static float Range(float scaledAuthoredAiRange, float physicalSweepRange)
        {
            if (!Finite(scaledAuthoredAiRange) || scaledAuthoredAiRange < 0)
                throw new ArgumentOutOfRangeException(nameof(scaledAuthoredAiRange));
            if (!Finite(physicalSweepRange) || physicalSweepRange <= 0)
                throw new ArgumentOutOfRangeException(nameof(physicalSweepRange));
            return Math.Min(MaximumApproachMetres, Math.Min(scaledAuthoredAiRange,
                Math.Max(physicalSweepRange * .5f, physicalSweepRange - SafetyMarginMetres)));
        }
        public static float Minimum(float authoredScaledMinimum, float approachRange)
        {
            if (!Finite(authoredScaledMinimum) || !Finite(approachRange) || approachRange < 0)
                throw new ArgumentOutOfRangeException();
            if (authoredScaledMinimum < 0) return authoredScaledMinimum;
            return Math.Min(authoredScaledMinimum, Math.Max(0, approachRange - .05f));
        }
    }
}
