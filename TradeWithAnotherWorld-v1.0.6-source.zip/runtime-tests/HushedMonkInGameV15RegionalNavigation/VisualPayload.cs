using System;

namespace BlackAbbey.HushedMonk
{
    [Serializable] public sealed class FileRecord { public string path, sha256, colorSpace; public long bytes; }
    [Serializable] public sealed class VisualPayload
    {
        public string schema, sourceRootName;
        public FileRecord sourceNative, sourceFBX;
        public RigRecord rig;
        public SemanticInterfaceRecord interfaces;
        public VisualInventoryRecord inventory;
        public RendererRecord[] renderers;
        public MaterialRecord[] materials;
    }
    [Serializable] public sealed class SemanticInterfaceRecord
    {
        public string rightHand, leftHand, head, chest, leftShoulder, rightShoulder;
        public string leftFoot, rightFoot, clapper, bellFrame;
    }
    [Serializable] public sealed class VisualInventoryRecord
    {
        public int nodeCount, rendererCount, materialCount, skinnedRendererCount, skinJointCount;
    }
    [Serializable] public sealed class RigRecord
    {
        public int rootNodeId, animatorNodeId;
        public NodeRecord[] nodes;
        public HumanDescriptionRecord humanDescription;
    }
    [Serializable] public sealed class NodeRecord
    {
        public int id, parentId;
        public string name;
        public float[] position, rotation, scale;
    }
    [Serializable] public sealed class HumanDescriptionRecord
    {
        public HumanBoneRecord[] human;
        public SkeletonBoneRecord[] skeleton;
        public float upperArmTwist, lowerArmTwist, upperLegTwist, lowerLegTwist, armStretch, legStretch, feetSpacing;
        public bool hasTranslationDoF;
    }
    [Serializable] public sealed class HumanBoneRecord { public string boneName, humanName; public LimitRecord limit; }
    [Serializable] public sealed class LimitRecord { public bool useDefaultValues; public float[] min, max, center; public float axisLength; }
    [Serializable] public sealed class SkeletonBoneRecord { public string name; public float[] position, rotation, scale; }
    [Serializable] public sealed class MatrixRecord { public float[] values; }
    [Serializable] public sealed class WeightRecord
    {
        public int boneIndex0, boneIndex1, boneIndex2, boneIndex3;
        public float weight0, weight1, weight2, weight3;
    }
    [Serializable] public sealed class RendererRecord
    {
        public string name, type, materialId;
        public int nodeId, rootBoneNodeId, vertexCount, triangleCount;
        public float[] positions, normals, tangents, uv, boundsCenter, boundsSize;
        public int[] triangles, boneNodeIds;
        public MatrixRecord[] bindposes;
        public WeightRecord[] weights;
    }
    [Serializable] public sealed class MaterialRecord
    {
        public string id;
        public FileRecord diffuse, normal, metallicGloss, orm;
    }
}
