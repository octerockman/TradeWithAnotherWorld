using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace BlackAbbey.HushedMonk
{
    // Plain own-data reconstruction. No asset bundle or game asset is shipped.
    public sealed class VisualRuntime : IDisposable
    {
        public VisualPayload Payload { get; private set; }
        public Animator Animator { get; private set; }
        public SkinnedMeshRenderer Body { get; private set; }
        public Transform RightHand { get; private set; }
        public Transform LeftHand { get; private set; }
        public Avatar Avatar { get; private set; }
        public string PayloadHash { get; private set; }
        readonly List<Object> resources = new List<Object>();
        public static string Hash(string path)
        { using (var sha = SHA256.Create()) using (var input = File.OpenRead(path)) return string.Concat(sha.ComputeHash(input).Select(b => b.ToString("x2"))); }
        public static string SafePath(string folder, string relative)
        {
            if (string.IsNullOrWhiteSpace(relative) || Path.IsPathRooted(relative)) throw new InvalidDataException("Expected package-relative path.");
            string root = Path.GetFullPath(folder).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string file = Path.GetFullPath(Path.Combine(root, relative));
            if (!file.StartsWith(root, StringComparison.OrdinalIgnoreCase) || !File.Exists(file)) throw new InvalidDataException("Missing/outside visual resource: " + relative);
            return file;
        }
        static bool Finite(float f) => !float.IsNaN(f) && !float.IsInfinity(f);
        static void Validate(float[] a, int length, string label)
        { if (a == null || a.Length != length || a.Any(v => !Finite(v))) throw new InvalidDataException("Invalid " + label); }
        static Vector3 V(float[] v) { Validate(v, 3, "Vector3"); return new Vector3(v[0], v[1], v[2]); }
        static Quaternion Q(float[] q) { Validate(q, 4, "Quaternion"); var result = new Quaternion(q[0], q[1], q[2], q[3]); if (Mathf.Abs(Quaternion.Dot(result, result) - 1) > .002f) throw new InvalidDataException("Non-unit node quaternion"); return result; }
        static Matrix4x4 M(MatrixRecord value)
        { Validate(value?.values, 16, "row-major matrix"); var m = new Matrix4x4(); for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) m[i, j] = value.values[4 * i + j]; return m; }

        public static VisualRuntime Apply(GameObject enemy, string manifest, Material creatureTemplate, Action<string> log)
        {
            var result = new VisualRuntime();
            try { result.Build(enemy, manifest, creatureTemplate, log); return result; }
            catch { result.Dispose(); throw; }
        }
        void Build(GameObject enemy, string manifest, Material template, Action<string> log)
        {
            if (!enemy || enemy.activeInHierarchy) throw new InvalidOperationException("Build monk visual on an inactive clone only.");
            if (!template || template.shader.name != "Custom/Creature") throw new InvalidOperationException("Expected actual loaded Custom/Creature template.");
            if (!File.Exists(manifest) || new FileInfo(manifest).Length > 32 * 1024 * 1024) throw new InvalidDataException("Missing/oversized monk-visual.json");
            PayloadHash = Hash(manifest); Payload = JsonConvert.DeserializeObject<VisualPayload>(File.ReadAllText(manifest));
            if (Payload == null || Payload.schema != "hushed-monk.runtime-visual.v2" || Payload.rig?.nodes == null || Payload.interfaces == null || Payload.inventory == null || Payload.renderers == null || Payload.materials == null)
                throw new InvalidDataException("Expected source-bound Meshy Monk visual schema v2 and semantic interfaces.");
            VisualSourceContract.Require(PayloadHash, Payload.sourceNative?.sha256);
            var inventory = Payload.inventory;
            if (inventory.nodeCount != Payload.rig.nodes.Length || inventory.nodeCount < 15 || inventory.nodeCount > 256 ||
                inventory.rendererCount != Payload.renderers.Length || inventory.rendererCount < 2 || inventory.rendererCount > 16 ||
                inventory.materialCount != Payload.materials.Length || inventory.materialCount < 1 || inventory.materialCount > 16 ||
                inventory.skinnedRendererCount != 1 || Payload.renderers.Count(r => r.type == "skin") != inventory.skinnedRendererCount ||
                inventory.skinJointCount < 15 || inventory.skinJointCount > 256 ||
                Payload.renderers.Where(r => r.type == "skin").Sum(r => r.boneNodeIds?.Length ?? 0) != inventory.skinJointCount)
                throw new InvalidDataException("Visual arrays differ from the pinned payload inventory.");
            if (Payload.rig.animatorNodeId != Payload.rig.rootNodeId) throw new InvalidDataException("Only inspected root-Animator hierarchy is supported.");
            Transform visual = enemy.transform.Find("Visual");
            if (!visual) throw new InvalidOperationException("Skeleton has no required Visual root.");
            var nativeAnimators = visual.GetComponentsInChildren<Animator>(true);
            if (nativeAnimators.Length != 1 || !nativeAnimators[0].runtimeAnimatorController) throw new InvalidOperationException("Expected exactly one actual native Skeleton Animator/controller.");
            var nativeAnimator = nativeAnimators[0];
            var nativeEvents = nativeAnimator.GetComponent<CharacterAnimEvent>();
            if (!nativeEvents) throw new InvalidOperationException("Actual native Animator has no CharacterAnimEvent interface.");
            var controller = nativeAnimator.runtimeAnimatorController; var updateMode = nativeAnimator.updateMode; var animationSpeed = nativeAnimator.speed;
            string eventDefinition = JsonUtility.ToJson(nativeEvents);
            string[] ikFeet = nativeEvents.m_feets?.Select(f => f.m_transform ? f.m_transform.name : null).ToArray();
            string ownLookAt = nativeEvents.m_lookAt && nativeEvents.m_lookAt.IsChildOf(visual) ? nativeEvents.m_lookAt.name : null;
            string ownLoopAudio = nativeEvents.m_loopAudioSource && nativeEvents.m_loopAudioSource.transform.IsChildOf(visual) ? nativeEvents.m_loopAudioSource.name : null;
            var footsteps = enemy.GetComponentsInChildren<FootStep>(true).Select(step => new { component = step, feet = step.m_feet?.Select(f => f ? f.name : null).ToArray() }).ToArray();
            log?.Invoke("HM_NATIVE_ANIMATION_INTERFACE animator=" + PathFrom(enemy.transform, nativeAnimator.transform) + " events=" + PathFrom(enemy.transform, nativeEvents.transform) + " footstepPaths=" + string.Join(",", footsteps.Select(s => PathFrom(enemy.transform, s.component.transform))));
            // Prevent Awake/OnEnable while detaching the Avatar construction root.
            visual.gameObject.SetActive(false);
            foreach (Transform child in visual.Cast<Transform>().ToArray()) Object.DestroyImmediate(child.gameObject);
            foreach (var lod in visual.GetComponents<LODGroup>()) Object.DestroyImmediate(lod);
            foreach (var renderer in visual.GetComponents<Renderer>()) Object.DestroyImmediate(renderer);
            foreach (var filter in visual.GetComponents<MeshFilter>()) Object.DestroyImmediate(filter);
            // Character.Awake/ZSyncAnimation find this Animator in children;
            // Character then obtains CharacterAnimEvent on that same object.
            // Migrate the real native event settings before any actor activation.
            Animator = visual.GetComponent<Animator>() ?? visual.gameObject.AddComponent<Animator>();
            var animEvent = visual.GetComponent<CharacterAnimEvent>() ?? visual.gameObject.AddComponent<CharacterAnimEvent>();
            JsonUtility.FromJsonOverwrite(eventDefinition, animEvent);
            Animator.updateMode = updateMode; Animator.speed = animationSpeed;
            var nodes = new Dictionary<int, Transform>();
            foreach (var record in Payload.rig.nodes)
            {
                if (nodes.ContainsKey(record.id) || string.IsNullOrWhiteSpace(record.name)) throw new InvalidDataException("Duplicate/unnamed hierarchy node.");
                Transform node;
                if (record.id == Payload.rig.rootNodeId)
                { if (record.name != "Visual" || record.parentId >= 0) throw new InvalidDataException("Root must be detached Visual."); node = visual; }
                else
                { if (!nodes.TryGetValue(record.parentId, out var parent)) throw new InvalidDataException("Nodes must be ordered parent-first."); node = new GameObject(record.name).transform; node.SetParent(parent, false); }
                node.localPosition = V(record.position); node.localRotation = Q(record.rotation); node.localScale = V(record.scale);
                if (node.localScale.x <= 0 || node.localScale.y <= 0 || node.localScale.z <= 0) throw new InvalidDataException("Nonpositive imported scale.");
                node.gameObject.layer = visual.gameObject.layer; nodes.Add(record.id, node);
            }
            var named = nodes.Values.ToDictionary(t => t.name, StringComparer.Ordinal);
            // An FBX import can retain stale unit scales in Avatar.humanDescription
            // after its live hierarchy was normalized. JSON parity can reproduce
            // that same broken Avatar, so reject the mismatch before construction.
            foreach (var bone in Payload.rig.humanDescription?.skeleton ?? Array.Empty<SkeletonBoneRecord>())
                if (!named.TryGetValue(bone.name, out var actual) || Vector3.Distance(V(bone.scale), actual.localScale) > .0001f)
                    throw new InvalidDataException("Humanoid description scale differs from actual source node: " + bone.name);
            var rootPosition = visual.localPosition; var rootRotation = visual.localRotation; var rootScale = visual.localScale;
            visual.SetParent(null, false);
            try
            {
                Avatar = AvatarBuilder.BuildHumanAvatar(visual.gameObject, Human(Payload.rig.humanDescription)); resources.Add(Avatar);
                if (!Avatar || !Avatar.isValid || !Avatar.isHuman) throw new InvalidDataException("Runtime authored Humanoid Avatar is invalid.");
                Avatar.name = "HM_Meshy_V6_RuntimeHumanoid";
            }
            finally { visual.SetParent(enemy.transform, false); visual.localPosition = rootPosition; visual.localRotation = rootRotation; visual.localScale = rootScale; }
            Animator.avatar = Avatar; Animator.runtimeAnimatorController = controller; Animator.applyRootMotion = false; Animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
            var materials = Payload.materials.ToDictionary(m => m.id, m => Material(Path.GetDirectoryName(manifest), m, template));
            foreach (var record in Payload.renderers)
            {
                if (!nodes.TryGetValue(record.nodeId, out var node) || !materials.TryGetValue(record.materialId, out var material)) throw new InvalidDataException("Renderer hierarchy/material missing.");
                var mesh = Mesh(record); resources.Add(mesh); Renderer renderer;
                if (record.type == "skin")
                {
                    if (Body || record.boneNodeIds?.Length != inventory.skinJointCount || record.bindposes?.Length != inventory.skinJointCount || record.weights?.Length != mesh.vertexCount)
                        throw new InvalidDataException("Skin differs from the pinned joint/weight inventory.");
                    if (record.boneNodeIds.Distinct().Count() != record.boneNodeIds.Length || record.boneNodeIds.Any(id => !nodes.ContainsKey(id)) || !nodes.ContainsKey(record.rootBoneNodeId))
                        throw new InvalidDataException("Skin references missing or repeated joint nodes.");
                    mesh.bindposes = record.bindposes.Select(M).ToArray();
                    mesh.boneWeights = record.weights.Select(w => Weight(w, record.boneNodeIds.Length)).ToArray();
                    Body = node.gameObject.AddComponent<SkinnedMeshRenderer>(); Body.sharedMesh = mesh; Body.bones = record.boneNodeIds.Select(id => nodes[id]).ToArray(); Body.rootBone = nodes[record.rootBoneNodeId]; Body.localBounds = new Bounds(V(record.boundsCenter), V(record.boundsSize)); Body.updateWhenOffscreen = true; Body.quality = SkinQuality.Bone4; renderer = Body;
                }
                else if (record.type == "rigid") { node.gameObject.AddComponent<MeshFilter>().sharedMesh = mesh; renderer = node.gameObject.AddComponent<MeshRenderer>(); }
                else throw new InvalidDataException("Unknown renderer type.");
                renderer.sharedMaterial = material; renderer.shadowCastingMode = ShadowCastingMode.On; renderer.receiveShadows = true;
            }
            if (!Body) throw new InvalidDataException("No authored body skin.");
            Transform Required(string name, string role)
            {
                if (string.IsNullOrWhiteSpace(name) || !named.TryGetValue(name, out var value)) throw new InvalidDataException("Missing semantic visual interface: " + role);
                return value;
            }
            var semantic = Payload.interfaces;
            var bindings = enemy.AddComponent<VisualInstanceBindings>();
            RightHand = bindings.rightHand = Required(semantic.rightHand, "rightHand");
            LeftHand = bindings.leftHand = Required(semantic.leftHand, "leftHand");
            bindings.head = Required(semantic.head, "head"); bindings.chest = Required(semantic.chest, "chest");
            bindings.leftShoulder = Required(semantic.leftShoulder, "leftShoulder"); bindings.rightShoulder = Required(semantic.rightShoulder, "rightShoulder");
            bindings.leftFoot = Required(semantic.leftFoot, "leftFoot"); bindings.rightFoot = Required(semantic.rightFoot, "rightFoot");
            bindings.clapper = Required(semantic.clapper, "clapper"); bindings.bellFrame = Required(semantic.bellFrame, "bellFrame");
            bindings.sourceSkinJointCount = inventory.skinJointCount; bindings.sourceRendererCount = inventory.rendererCount; bindings.sourceMaterialCount = inventory.materialCount;
            BellPartitionRuntime.Apply(enemy, Path.GetDirectoryName(manifest), PayloadHash, bindings.bellFrame, resources, log);
            bindings.runtimeRendererCount = inventory.rendererCount + 2; // One fixed source renderer becomes fixed, hanging and cord.
            if (visual.GetComponentsInChildren<Renderer>(true).Length != bindings.runtimeRendererCount)
                throw new InvalidDataException("Live renderer inventory differs from source plus declared bell partition.");
            Transform NativeFoot(string name)
            {
                if (name == "LeftFoot") return bindings.leftFoot;
                if (name == "RightFoot") return bindings.rightFoot;
                return name != null && named.TryGetValue(name, out var value) ? value : throw new InvalidDataException("Required native foot interface missing: " + name);
            }
            if (ikFeet != null) for (int i = 0; i < ikFeet.Length; i++)
                animEvent.m_feets[i].m_transform = NativeFoot(ikFeet[i]);
            foreach (var entry in footsteps)
                if (entry.component && entry.feet != null) entry.component.m_feet = entry.feet.Select(NativeFoot).ToArray();
            animEvent.m_eyes = Array.Empty<Transform>();
            animEvent.m_leftShoulder = bindings.leftShoulder; animEvent.m_rightShoulder = bindings.rightShoulder;
            if (ownLookAt != null) animEvent.m_lookAt = named.TryGetValue(ownLookAt, out var lookAt) ? lookAt : bindings.head;
            if (ownLoopAudio != null) animEvent.m_loopAudioSource = named.TryGetValue(ownLoopAudio, out var loopAudio) ? loopAudio.gameObject : null;
            var equipment = enemy.GetComponent<VisEquipment>();
            if (!equipment) throw new InvalidOperationException("Skeleton has no native VisEquipment.");
            equipment.m_bodyModel = Body; equipment.m_rightHand = RightHand; equipment.m_leftHand = LeftHand; equipment.m_randomModelIndex = false; equipment.m_models = Array.Empty<VisEquipment.PlayerModel>(); equipment.m_npcBeardChance = 0; equipment.m_npcHairChance = 0;
            equipment.m_helmet = bindings.head; equipment.m_backMelee = bindings.chest; equipment.m_backShield = bindings.chest; equipment.m_backBow = bindings.chest; equipment.m_backTool = bindings.chest; equipment.m_backTwohandedMelee = bindings.chest; equipment.m_backAtgeir = bindings.chest;
            MonkRightHandGrip.Configure(enemy, Path.GetDirectoryName(manifest), Payload, PayloadHash, named, log);
            Animator.SetBool("wakeup", false); visual.gameObject.SetActive(true);
            log?.Invoke("HM_VISUAL_READY payload=" + PayloadHash + " avatarValid=" + Avatar.isValid + " human=" + Avatar.isHuman + " bones=" + Body.bones.Length + " bodyVertices=" + Body.sharedMesh.vertexCount + " nativeController=" + controller.name + " noScaleOverride=true");
        }
        public static HumanDescription Human(HumanDescriptionRecord record)
        {
            if (record?.human == null || record.skeleton == null || record.human.Length < 15) throw new InvalidDataException("Missing actual Humanoid description.");
            return new HumanDescription { human = record.human.Select(h => new HumanBone { boneName = h.boneName, humanName = h.humanName, limit = new HumanLimit { useDefaultValues = h.limit.useDefaultValues, min = V(h.limit.min), max = V(h.limit.max), center = V(h.limit.center), axisLength = h.limit.axisLength } }).ToArray(), skeleton = record.skeleton.Select(b => new SkeletonBone { name = b.name, position = V(b.position), rotation = Q(b.rotation), scale = V(b.scale) }).ToArray(), upperArmTwist = record.upperArmTwist, lowerArmTwist = record.lowerArmTwist, upperLegTwist = record.upperLegTwist, lowerLegTwist = record.lowerLegTwist, armStretch = record.armStretch, legStretch = record.legStretch, feetSpacing = record.feetSpacing, hasTranslationDoF = record.hasTranslationDoF };
        }
        static string PathFrom(Transform root, Transform t)
        { if (t == root) return "."; var names = new List<string>(); while (t && t != root) { names.Add(t.name); t = t.parent; } names.Reverse(); return string.Join("/", names); }
        static BoneWeight Weight(WeightRecord w, int count)
        {
            var indices = new[] { w.boneIndex0, w.boneIndex1, w.boneIndex2, w.boneIndex3 }; var values = new[] { w.weight0, w.weight1, w.weight2, w.weight3 };
            if (indices.Any(i => i < 0 || i >= count) || values.Any(v => !Finite(v) || v < 0 || v > 1) || Mathf.Abs(values.Sum() - 1) > .0001f) throw new InvalidDataException("Invalid imported normalized four-bone weight.");
            return new BoneWeight { boneIndex0 = w.boneIndex0, boneIndex1 = w.boneIndex1, boneIndex2 = w.boneIndex2, boneIndex3 = w.boneIndex3, weight0 = w.weight0, weight1 = w.weight1, weight2 = w.weight2, weight3 = w.weight3 };
        }
        static Mesh Mesh(RendererRecord r)
        {
            int count = (r.positions?.Length ?? 0) / 3;
            if (count < 4 || count > 100000 || r.positions.Length != count * 3 || r.triangles == null || r.triangles.Length % 3 != 0 || r.triangles.Length > 300000 || r.triangles.Any(i => i < 0 || i >= count)) throw new InvalidDataException("Invalid visual mesh/index inventory.");
            if (r.vertexCount != count || r.triangleCount != r.triangles.Length / 3) throw new InvalidDataException("Renderer arrays differ from the pinned source inventory.");
            Validate(r.positions, count * 3, "vertices"); Validate(r.normals, count * 3, "split normals"); Validate(r.tangents, count * 4, "tangents"); Validate(r.uv, count * 2, "UV");
            var positions = new Vector3[count]; var normals = new Vector3[count]; var tangents = new Vector4[count]; var uv = new Vector2[count];
            for (int i = 0; i < count; i++) { positions[i] = new Vector3(r.positions[i * 3], r.positions[i * 3 + 1], r.positions[i * 3 + 2]); normals[i] = new Vector3(r.normals[i * 3], r.normals[i * 3 + 1], r.normals[i * 3 + 2]); tangents[i] = new Vector4(r.tangents[i * 4], r.tangents[i * 4 + 1], r.tangents[i * 4 + 2], r.tangents[i * 4 + 3]); uv[i] = new Vector2(r.uv[i * 2], r.uv[i * 2 + 1]); }
            var mesh = new Mesh { name = r.name, indexFormat = count > 65535 ? IndexFormat.UInt32 : IndexFormat.UInt16 }; mesh.vertices = positions; mesh.normals = normals; mesh.tangents = tangents; mesh.uv = uv; mesh.triangles = r.triangles; mesh.bounds = new Bounds(V(r.boundsCenter), V(r.boundsSize)); return mesh;
        }
        Texture2D Texture(string folder, FileRecord record, bool linear)
        {
            string path = SafePath(folder, record?.path);
            if (new FileInfo(path).Length > 32 * 1024 * 1024 || Hash(path) != record.sha256) throw new InvalidDataException("Map hash mismatch: " + record.path);
            var texture = new Texture2D(2, 2, TextureFormat.RGBA32, true, linear); resources.Add(texture);
            if (!ImageConversion.LoadImage(texture, File.ReadAllBytes(path), true) || texture.width > 4096 || texture.height > 4096) throw new InvalidDataException("Invalid map: " + record.path);
            texture.name = record.path; texture.wrapMode = TextureWrapMode.Clamp; texture.filterMode = FilterMode.Trilinear; texture.anisoLevel = 4; return texture;
        }
        Material Material(string folder, MaterialRecord record, Material template)
        {
            var material = new Material(template) { name = "HM_" + record.id + "_Creature" }; resources.Add(material);
            foreach (string property in material.GetTexturePropertyNames()) { material.SetTexture(property, null); material.SetTextureScale(property, Vector2.one); material.SetTextureOffset(property, Vector2.zero); }
            material.SetTexture("_MainTex", Texture(folder, record.diffuse, false)); material.SetTexture("_BumpMap", Texture(folder, record.normal, true)); material.SetTexture("_MetallicGlossMap", Texture(folder, record.metallicGloss, true)); material.SetFloat("_UseGlossmap", 1); material.SetFloat("_BumpScale", 1); material.SetColor("_Color", Color.white);
            foreach (string property in new[] { "_Hue", "_Saturation", "_Value", "_UseStyles", "_Style", "_NoiseGlowEnabled", "_SnowCover", "_AddRain" }) if (material.HasProperty(property)) material.SetFloat(property, 0);
            if (material.HasProperty("_MetalColor")) material.SetColor("_MetalColor", Color.white); if (material.HasProperty("_EmissionColor")) material.SetColor("_EmissionColor", Color.black);
            material.EnableKeyword("_NORMALMAP"); material.DisableKeyword("_ALPHATEST_ON"); material.DisableKeyword("_EMISSION"); return material;
        }
        public void Dispose() { foreach (var resource in resources) if (resource) Object.Destroy(resource); resources.Clear(); }
    }
}
