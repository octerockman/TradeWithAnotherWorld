using System;
using System.IO;
using System.Linq;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BlackAbbey.HushedMonk
{
    // Explicit test-only closeup. This renders the real current game pose;
    // it does not move the player, main camera, bell, model or scene lights.
    public static class BellDiagnosticCapture
    {
        public static object Capture(HushedMonkInstance actor, string path)
        {
            var source = Camera.main;
            var bell = actor.GetComponentsInChildren<MeshRenderer>(true).Single(r => r.name == "HM_WRIST_BELL_HANGING");
            var bindings = actor.GetComponent<VisualInstanceBindings>();
            var frame = bindings && bindings.bellFrame ? bindings.bellFrame.GetComponent<MeshRenderer>() : null;
            if (!source || !bell || !frame) throw new InvalidOperationException("Actual camera and partitioned bell required.");
            GameObject host = null; RenderTexture target = null; Texture2D pixels = null;
            RenderTexture previous = RenderTexture.active;
            try
            {
                Bounds bounds = frame.bounds; bounds.Encapsulate(bell.bounds);
                Vector3 center = bounds.center;
                host = new GameObject("HM_AUTOTEST_BELL_DIAGNOSTIC_CAMERA");
                host.hideFlags = HideFlags.HideAndDontSave;
                var camera = host.AddComponent<Camera>(); camera.enabled = false;
                camera.CopyFrom(source); camera.enabled = false;
                target = new RenderTexture(900, 700, 24, RenderTextureFormat.ARGB32); target.Create();
                camera.targetTexture = target; camera.aspect = 900f / 700f;
                camera.fieldOfView = 32; camera.nearClipPlane = .025f;
                camera.transform.position = center + actor.transform.forward * .42f - actor.transform.right * .48f + Vector3.up * .08f;
                camera.transform.LookAt(center, Vector3.up);
                camera.Render(); RenderTexture.active = target;
                pixels = new Texture2D(900, 700, TextureFormat.RGB24, false);
                pixels.ReadPixels(new Rect(0, 0, 900, 700), 0, 0); pixels.Apply(false, false);
                File.WriteAllBytes(path, pixels.EncodeToPNG());
                return new { path, frame = Time.frameCount, classification = "Actual live-game secondary-camera wrist-bell closeup", changes = "Temporary camera only; no pose, physics, light, material or player-camera changes", bellPosition = bell.transform.position.ToString("F6"), bellRotation = bell.transform.rotation.ToString("F6") };
            }
            finally
            {
                RenderTexture.active = previous;
                if (host) { host.GetComponent<Camera>().targetTexture = null; Object.Destroy(host); }
                if (target) { target.Release(); Object.Destroy(target); }
                if (pixels) Object.Destroy(pixels);
            }
        }
    }
}
