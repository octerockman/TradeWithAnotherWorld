using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using Object = UnityEngine.Object;

namespace BlackAbbey.HushedMonk
{
    // Client-local presentation only. No AI, damage, native FootStep or shared mixer edits.
    public sealed class MonkAudioController : MonoBehaviour
    {
        [Serializable] public sealed class Telemetry
        {
            public bool initialized, bankReady, audioEnabled, liveActor, dead, combatWanted, combatState, resourcesCleaned;
            public bool idleLoopPlaying, combatLoopPlaying, clientLocal = true;
            public float masterVolume, idleLoopVolume, combatLoopVolume, combatBlend, duck;
            public int allocatedSources, activeOneShots, oneShotsPlayed, bellEvents, clothEvents, voiceEvents;
            public int windupEvents, attackHitEvents, impactEvents, hurtEvents, alertEvents, deathEvents, bellSuppressions;
            public int tailVoicesActive, tailsCreated, tailsDestroyed;
            public int deathTailFailures;
            public int bellTriggerRequests, bellVoiceDrops;
            public float bellMotionSpeed, bellMotionAngle;
            public bool deathVoiceDispatched, deathBellDispatched;
            public string deathCueId;
            public float deathVoiceGainBoost;
            public Dictionary<string, int> groupPlaybackCommands, cuePlaybackCommands;
            public string bankHash, failure, mixerName, combatReplication;
        }
        sealed class Voice
        {
            public AudioSource source; public float baseVolume, end; public int importance, emitter;
            public Vector3 point;
        }
        static readonly HashSet<MonkAudioController> Actors = new HashSet<MonkAudioController>();
        static readonly HashSet<MonkAudioTail> Tails = new HashSet<MonkAudioTail>();
        static bool mixEnabled = true;
        static float masterVolume = 1;
        static int tailsCreated, tailsDestroyed;
        static readonly Dictionary<string, int> GlobalGroupCommands = new Dictionary<string, int>(StringComparer.Ordinal);
        static readonly Dictionary<string, int> GlobalCueCommands = new Dictionary<string, int>(StringComparer.Ordinal);
        static int globalDeathRequests, globalDeathVoiceCommands, globalDeathVoiceObservedPlaying, globalDeathTailFailures, globalDeathSuppressed;
        static int lastDeathSourceId;
        static bool lastDeathVoiceCommand, lastDeathPlayingObserved;
        static string lastDeathCue, lastDeathFailure;
        static float lastDeathGain;
        const float DeathVoiceGainBoost = 2f; // +6dB, selected death cues retain at least11dB peak headroom.
        MonkAudioBank bank; Action<string> log; AudioMixerGroup mixer;
        Character character; MonsterAI ai; ZNetView view; WristBellPhysics bell;
        Transform head, clapper; GameObject audioRoot;
        AudioSource idle, combat; MonkAudioBank.ClipRecord idleClip, combatClip;
        readonly Voice[] voices = new Voice[MonkAudioPolicy.MaximumActorOneShots];
        readonly MonkAudioPolicy.Cooldowns cooldown = new MonkAudioPolicy.Cooldowns();
        readonly MonkAudioPolicy.CombatGate combatGate = new MonkAudioPolicy.CombatGate();
        readonly MonkAudioPolicy.BellGate bellGate = new MonkAudioPolicy.BellGate();
        readonly Dictionary<string, string> previous = new Dictionary<string, string>(StringComparer.Ordinal);
        readonly Dictionary<string, int> groupPlaybackCommands = new Dictionary<string, int>(StringComparer.Ordinal);
        readonly Dictionary<string, int> cuePlaybackCommands = new Dictionary<string, int>(StringComparer.Ordinal);
        System.Random random;
        bool initialized, dead, cleaned, wanted, lastPublished, published;
        float blend, duck = 1, duckUntil, eventCombatUntil, nextQuietVoice, nextCloth, clothDistance;
        float lastTurnYaw;
        Vector3 lastPosition, previousBellVelocity;
        int played, bellEvents, clothEvents, voiceEvents, windupEvents, attackHitEvents, impactEvents, hurtEvents, alertEvents, deathEvents;
        int deathTailFailures;
        int bellTriggerRequests, bellVoiceDrops;
        float bellMotionSpeed, bellMotionAngle;
        bool deathVoiceDispatched, deathBellDispatched;
        string deathCueId;
        string failure;

        public static MonkAudioController Attach(GameObject actor, MonkAudioBank bank,
            Action<string> log = null, AudioMixerGroup mixer = null)
        {
            if (!actor || !actor.GetComponent<HushedMonkInstance>()) return null;
            if (actor.GetComponent<MonkAudioController>()) return actor.GetComponent<MonkAudioController>();
            var network = actor.GetComponent<ZNetView>();
            // Called only from the live marker's Start; never configure the registered template.
            if (!actor.activeInHierarchy || !network || !network.IsValid()) return null;
            if (bank == null || !bank.Ready) { log?.Invoke("HM_AUDIO_ACTOR_DISABLED bank unavailable; enemy unchanged"); return null; }
            var result = actor.AddComponent<MonkAudioController>();
            try { result.Initialize(bank, log, mixer); return result; }
            catch (Exception error) { result.failure = error.Message; result.Cleanup("initialization failure"); log?.Invoke("HM_AUDIO_ACTOR_DISABLED " + error); return result; }
        }
        void Initialize(MonkAudioBank value, Action<string> logger, AudioMixerGroup output)
        {
            if (!output) throw new InvalidOperationException("Verified native creature SFX mixer unavailable; own monk audio disabled, enemy unchanged.");
            bank = value; log = logger; mixer = output;
            character = GetComponent<Character>(); ai = GetComponent<MonsterAI>(); view = GetComponent<ZNetView>(); bell = GetComponent<WristBellPhysics>();
            random = new System.Random(GetInstanceID() ^ Environment.TickCount);
            var animator = GetComponentInChildren<Animator>(true);
            var bindings = GetComponent<VisualInstanceBindings>();
            if (!bindings || !bindings.head || !bindings.clapper) throw new InvalidOperationException("Source-bound audio emitter interfaces unavailable.");
            head = bindings.head; clapper = bindings.clapper;
            audioRoot = new GameObject("HM_Own_Audio"); audioRoot.transform.SetParent(transform, false);
            idle = NewSource("Idle breathing", 128, 16); combat = NewSource("Combat breathing", 128, 18);
            idleClip = bank.Pick("idleBreath", random); combatClip = bank.Pick("combatBreath", random);
            if (idleClip == null || combatClip == null) throw new InvalidOperationException("Selected breathing loops missing.");
            idle.clip = idleClip.Clip; combat.clip = combatClip.Clip; idle.loop = combat.loop = true;
            for (int i = 0; i < voices.Length; i++) voices[i] = new Voice { source = NewSource("Event " + i, 160, 28) };
            lastPosition = transform.position; lastTurnYaw = transform.eulerAngles.y;
            nextQuietVoice = Now + 30 + (float)random.NextDouble() * 25; nextCloth = Now + 2;
            bellGate.Reset(Now); Actors.Add(this); initialized = true;
            log?.Invoke("HM_AUDIO_ACTOR_READY sources=6 bank=" + bank.ManifestHash + " mixer=" + mixer.name);
        }
        static float Now => Time.time;
        AudioSource NewSource(string label, int priority, float distance)
        {
            var node = new GameObject("HM Audio | " + label); node.transform.SetParent(audioRoot.transform, false);
            var source = node.AddComponent<AudioSource>(); ConfigureSource(source, mixer, priority, distance); return source;
        }
        static void ConfigureSource(AudioSource source, AudioMixerGroup mixer, int priority, float distance)
        {
            source.playOnAwake = false; source.loop = false; source.spatialBlend = 1; source.dopplerLevel = 0;
            source.rolloffMode = AudioRolloffMode.Logarithmic; source.minDistance = 1.4f; source.maxDistance = distance;
            source.priority = priority; source.pitch = 1; source.volume = 0; source.outputAudioMixerGroup = mixer;
        }
        Vector3 Position(int emitter)
        {
            if (emitter == 2 && bell && bell.DynamicBody) return bell.DynamicBody.worldCenterOfMass;
            if (emitter == 3 && clapper) return clapper.position;
            return head ? head.position : transform.position + Vector3.up * 1.45f;
        }
        bool Live => initialized && !cleaned && !dead && character && !character.IsDead() && view && view.IsValid() && bank != null && bank.Ready;
        void Update()
        {
            if (!initialized || cleaned) return;
            if (!character || !view || !view.IsValid()) { StopSources(); bellGate.Reset(Now); lastPosition = transform.position; return; }
            if (dead || character.IsDead()) { StopSources(); return; }
            float now = Now, dt = Mathf.Min(Time.deltaTime, .1f);
            Vector3 position = transform.position;
            float distance = Vector3.Distance(position, lastPosition);
            bool teleport = distance > MonkAudioPolicy.TeleportDistance;
            lastPosition = position;
            if (teleport) { bellGate.Reset(now); clothDistance = 0; previousBellVelocity = Vector3.zero; }
            bool request;
            if (view.IsOwner())
            {
                request = (ai && (ai.IsAlerted() || ai.GetTargetCreature())) || now < eventCombatUntil;
                if (!published || request != lastPublished)
                { view.GetZDO().Set(MonkAudioPolicy.CombatZdoKey, request); lastPublished = request; published = true; }
            }
            else request = view.GetZDO().GetBool(MonkAudioPolicy.CombatZdoKey, false);
            wanted = request; bool inCombat = combatGate.Update(now, request);
            blend = Mathf.MoveTowards(blend, inCombat ? 1 : 0, dt / MonkAudioPolicy.LoopCrossfadeSeconds);
            duck = Mathf.MoveTowards(duck, now < duckUntil ? .24f : 1, dt * (now < duckUntil ? 8 : 2));
            idle.transform.position = combat.transform.position = Position(1);
            if (mixEnabled && masterVolume > 0)
            {
                StartLoop(idle, idleClip, "idleBreath"); StartLoop(combat, combatClip, "combatBreath");
                idle.volume = idleClip.gain * Mathf.Cos(blend * Mathf.PI * .5f) * duck * masterVolume;
                combat.volume = combatClip.gain * Mathf.Sin(blend * Mathf.PI * .5f) * duck * masterVolume;
            }
            else { idle.Stop(); combat.Stop(); idle.volume = combat.volume = 0; }
            foreach (var voice in voices)
            {
                if (!voice.source) continue;
                if (voice.source.isPlaying)
                { voice.source.transform.position = voice.emitter == 0 ? voice.point : Position(voice.emitter); voice.source.volume = mixEnabled ? voice.baseVolume * masterVolume : 0; }
            }
            float speed = character.GetVelocity().magnitude;
            if (!teleport && speed > .18f && speed < 12) clothDistance += distance;
            if (clothDistance > 2.3f && now >= nextCloth && speed > .18f)
            { Play("clothWalk", 1, 1, .75f); clothDistance = 0; nextCloth = now + 1.8f + (float)random.NextDouble(); }
            float yaw = transform.eulerAngles.y;
            if (Mathf.Abs(Mathf.DeltaAngle(lastTurnYaw, yaw)) > 50 && now >= nextCloth && speed < 5)
            { Play("clothTurn", 1, 1, .8f); lastTurnYaw = yaw; nextCloth = now + 2.2f; }
            if (!inCombat && now >= nextQuietVoice && now >= duckUntil)
            { Play(random.Next(4) == 0 ? "investigate" : "idleVoice", 1, 2, 1); nextQuietVoice = now + 45 + (float)random.NextDouble() * 35; }
            SampleBell(now, teleport);
        }
        void RecordPlaybackCommand(string group, string id)
        {
            groupPlaybackCommands.TryGetValue(group, out var grouped); groupPlaybackCommands[group] = grouped + 1;
            cuePlaybackCommands.TryGetValue(id, out var selected); cuePlaybackCommands[id] = selected + 1;
            GlobalGroupCommands.TryGetValue(group, out var globalGroup); GlobalGroupCommands[group] = globalGroup + 1;
            GlobalCueCommands.TryGetValue(id, out var globalCue); GlobalCueCommands[id] = globalCue + 1;
        }
        void StartLoop(AudioSource source, MonkAudioBank.ClipRecord cue, string group)
        {
            if (source.isPlaying) return;
            source.volume = 0; source.time = (float)random.NextDouble() * Mathf.Max(.01f, source.clip.length - .02f);
            source.Play(); RecordPlaybackCommand(group, cue.id);
        }
        void SampleBell(float now, bool teleport)
        {
            if (!bell) bell = GetComponent<WristBellPhysics>();
            if (!bell || !bell.Initialized || !bell.DynamicBody || !bell.KinematicAnchor || !bell.CordBody)
            { bellGate.Sample(now, false, 0, 0, 0, 0, false, teleport); previousBellVelocity=Vector3.zero; return; }
            if(!bell.AudioMotionAllowed)
            {bellGate.SuppressIdle(now,bell.ResetCount,teleport);previousBellVelocity=Vector3.zero;bellMotionSpeed=bellMotionAngle=0;return;}
            var signal = BellMotionMetrics.Measure(bell.KinematicAnchor.position, bell.DynamicBody.position,
                bell.DynamicBody.worldCenterOfMass, bell.DynamicBody.angularVelocity, bell.CordBody.angularVelocity, Physics.gravity);
            bool reversal = signal.rate.sqrMagnitude > .04f && previousBellVelocity.sqrMagnitude > .04f && Vector3.Dot(signal.rate, previousBellVelocity) < 0;
            previousBellVelocity = signal.valid ? signal.rate : Vector3.zero;
            bellMotionSpeed = signal.rate.magnitude; bellMotionAngle = signal.angle;
            string group = bellGate.Sample(now, signal.valid, bell.ResetCount, bellMotionSpeed, bellMotionAngle, bell.CurrentAnchorGap, reversal, teleport);
            if (group == null) return;
            bellTriggerRequests++;
            if (group == "bellSoft" && random.Next(8) == 0) group = "bellBuzz";
            else if (random.Next(7) == 0) group = "bellDouble";
            if (!Play(group, 2, 2, 1)) bellVoiceDrops++;
        }
        bool Play(string group, int emitter, int importance, float intensity, Vector3? point = null)
        {
            if (!Live || !mixEnabled || masterVolume <= 0) return false;
            previous.TryGetValue(group, out var last);
            var cue = bank.Pick(group, random, last); if (cue == null || cue.loop) return false;
            Voice selected = null;
            int lane = MonkAudioPolicy.ReservedWeaponLane(group);
            if (lane >= 0) selected = voices[lane];
            else for (int i = 0; i < 2; i++) if (!voices[i].source.isPlaying) { selected = voices[i]; break; }
            if (selected == null)
                for (int i = 0; i < 2; i++) { var voice = voices[i]; if (voice.importance < importance && (selected == null || voice.importance < selected.importance)) selected = voice; }
            if (selected == null) return false;
            selected.source.Stop(); selected.source.clip = cue.Clip; selected.source.loop = false; selected.source.pitch = 1;
            selected.baseVolume = cue.gain * Mathf.Clamp01(intensity); selected.source.volume = selected.baseVolume * masterVolume;
            selected.emitter = point.HasValue ? 0 : emitter; selected.point = point ?? Position(emitter); selected.importance = importance;
            selected.source.transform.position = selected.point;
            selected.source.priority = importance >= 3 ? 80 : emitter == 2 && group.StartsWith("bell", StringComparison.Ordinal) ? 112 : 160;
            selected.end = Now + cue.Clip.length + .1f; selected.source.Play(); previous[group] = cue.id; played++;
            RecordPlaybackCommand(group, cue.id);
            if (group.StartsWith("bell", StringComparison.Ordinal)) bellEvents++;
            else if (group.StartsWith("cloth", StringComparison.Ordinal)) clothEvents++;
            else if (group == "idleVoice" || group == "investigate" || group == "alert" || group == "attack" || group.StartsWith("hurt", StringComparison.Ordinal))
            { voiceEvents++; duckUntil = Mathf.Max(duckUntil, Now + cue.Clip.length); }
            return true;
        }
        public void OnAttackWindup()
        {
            if (!Live || !cooldown.Take("windup", Now, .45f)) return;
            windupEvents++; eventCombatUntil = Now + 6; duckUntil = Mathf.Max(duckUntil, Now + 1.5f);
            Play("clothWindup", 1, 2, 1); Play("attack", 1, 3, 1);
        }
        public void OnAttackHit()
        {
            if (!Live || !cooldown.Take("attackHit", Now, .25f)) return;
            attackHitEvents++; duckUntil = Mathf.Max(duckUntil, Now + .7f); Play("clapperWhoosh", 3, 3, 1);
        }
        public void OnImpact(string material, Vector3 position)
        {
            string group = MonkAudioPolicy.ImpactGroup(material);
            if (!Live || group == null || !cooldown.Take("impact", Now, .16f)) return;
            impactEvents++; duckUntil = Mathf.Max(duckUntil, Now + .7f); Play(group, 3, 4, 1, position);
        }
        public void OnDamaged(float amount)
        {
            if (!Live || amount <= 0 || !cooldown.Take("hurt", Now, .65f)) return;
            hurtEvents++; eventCombatUntil = Now + 5; Play(amount >= 12 ? "hurtHeavy" : "hurtLight", 1, 4, 1);
        }
        public void OnAlert()
        {
            if (!Live || !cooldown.Take("alert", Now, 8)) return;
            alertEvents++; eventCombatUntil = Now + 5; Play("alert", 1, 3, 1);
        }
        public void OnDeath()
        {
            if (!initialized || dead || cleaned) return;
            dead = true; deathEvents++; StopSources();
            globalDeathRequests++; lastDeathVoiceCommand = lastDeathPlayingObserved = false; lastDeathCue = null; lastDeathGain = 0;
            if (!mixEnabled || masterVolume <= 0 || bank == null || !bank.Ready)
            { globalDeathSuppressed++; lastDeathFailure = "Own audio disabled/muted or selected bank unavailable"; return; }
            previous.TryGetValue("death", out var last);
            var voice = bank.Pick("death", random, last);
            var jingle = bank.Pick("bellSoft", random);
            deathCueId = voice?.id;
            lastDeathCue = deathCueId;
            deathVoiceDispatched = SpawnTail(voice, Position(1), DeathVoiceGainBoost, mixer, 2);
            deathBellDispatched = SpawnTail(jingle, Position(2), .35f, mixer, 1);
            lastDeathVoiceCommand = deathVoiceDispatched;
            if (deathVoiceDispatched)
            { RecordPlaybackCommand("death", voice.id); previous["death"] = voice.id; globalDeathVoiceCommands++; lastDeathFailure = null; }
            else { deathTailFailures++; globalDeathTailFailures++; lastDeathFailure = "Selected death cue/clip, SFX route or tail slot unavailable"; }
            if (deathBellDispatched) RecordPlaybackCommand("bellSoft", jingle.id);
            log?.Invoke("HM_AUDIO_DEATH_DISPATCH voice=" + deathVoiceDispatched + " cue=" + (deathCueId ?? "missing")
                + " bell=" + deathBellDispatched + " gainBoost=" + DeathVoiceGainBoost + " mixer=" + (mixer ? mixer.name : "missing")
                + " detached=true; playback command, not listening approval");
        }
        void StopSources()
        { if (idle) { idle.Stop(); idle.volume = 0; } if (combat) { combat.Stop(); combat.volume = 0; } foreach (var voice in voices) if (voice != null && voice.source) { voice.source.Stop(); voice.source.volume = 0; } }
        void Cleanup(string reason)
        {
            if (cleaned) return; cleaned = true; StopSources(); Actors.Remove(this);
            if (audioRoot) Object.Destroy(audioRoot); audioRoot = null;
            log?.Invoke("HM_AUDIO_ACTOR_CLEANUP " + reason);
        }
        void ResetPresentation()
        {
            StopSources(); combatGate.Reset(); bellGate.Reset(Now); blend = 0; duck = 1;
            clothDistance = 0; previousBellVelocity = Vector3.zero; lastPosition = transform.position;
            lastTurnYaw = transform.eulerAngles.y; published = false;
            nextCloth = Now + 2; nextQuietVoice = Now + 45;
        }
        void DeathBeforeRemoval()
        {
            // A native network destroy may outrun its final RPC. A local
            // zero-health actor still gets one independent tail before cleanup.
            // Healthy manual removals/pooling do not create a death sound.
            if (!initialized || cleaned || dead || !character) return;
            try { if (character.IsDead() || (view && view.IsValid() && character.GetHealth() <= 0)) OnDeath(); }
            catch (Exception error) { log?.Invoke("HM_AUDIO_DEATH_FALLBACK_FAILED " + error.Message); }
        }
        void OnDisable() { DeathBeforeRemoval(); if (initialized && !cleaned) ResetPresentation(); }
        void OnEnable() { if (initialized && !cleaned) ResetPresentation(); }
        void OnDestroy() { DeathBeforeRemoval(); Cleanup("destroyed"); }
        public Telemetry Snapshot()
        {
            int active = 0; foreach (var voice in voices) if (voice != null && voice.source && voice.source.isPlaying) active++;
            return new Telemetry { initialized = initialized, bankReady = bank != null && bank.Ready, audioEnabled = mixEnabled,
                liveActor = Live, dead = dead, combatWanted = wanted, combatState = combatGate.State, resourcesCleaned = cleaned,
                idleLoopPlaying = idle && idle.isPlaying, combatLoopPlaying = combat && combat.isPlaying,
                masterVolume = masterVolume, idleLoopVolume = idle ? idle.volume : 0, combatLoopVolume = combat ? combat.volume : 0,
                combatBlend = blend, duck = duck, allocatedSources = audioRoot ? 6 : 0, activeOneShots = active, oneShotsPlayed = played,
                bellEvents = bellEvents, clothEvents = clothEvents, voiceEvents = voiceEvents, windupEvents = windupEvents,
                attackHitEvents = attackHitEvents, impactEvents = impactEvents, hurtEvents = hurtEvents, alertEvents = alertEvents, deathEvents = deathEvents,
                bellSuppressions = bellGate.Suppressed, tailVoicesActive = Tails.Count, tailsCreated = tailsCreated, tailsDestroyed = tailsDestroyed,
                bellTriggerRequests = bellTriggerRequests, bellVoiceDrops = bellVoiceDrops, bellMotionSpeed = bellMotionSpeed, bellMotionAngle = bellMotionAngle,
                deathTailFailures = deathTailFailures, deathVoiceDispatched = deathVoiceDispatched, deathBellDispatched = deathBellDispatched,
                deathCueId = deathCueId, deathVoiceGainBoost = DeathVoiceGainBoost,
                groupPlaybackCommands = new Dictionary<string, int>(groupPlaybackCommands, StringComparer.Ordinal),
                cuePlaybackCommands = new Dictionary<string, int>(cuePlaybackCommands, StringComparer.Ordinal),
                bankHash = bank?.ManifestHash, failure = failure, mixerName = mixer ? mixer.name : "unavailable; own audio disabled",
                combatReplication = "owner writes own ZDO HM_AudioCombatV1 on change; clients read for cosmetic hysteresis" };
        }
        public AudioSource[] OwnedSourcesForDiagnostics()
        {
            var result = new List<AudioSource>();
            if (idle) result.Add(idle); if (combat) result.Add(combat);
            foreach (var voice in voices) if (voice != null && voice.source) result.Add(voice.source);
            return result.ToArray();
        }
        public static void SetMix(bool enabled, float volume)
        {
            mixEnabled = enabled; masterVolume = MonkAudioPolicy.Finite(volume) ? Mathf.Clamp01(volume) : 0;
            if (!enabled || masterVolume <= 0)
            { foreach (var actor in Actors) if (actor) actor.StopSources(); foreach (var tail in Tails) if (tail && tail.Source) { tail.Source.Stop(); tail.Source.volume = 0; } }
        }
        public static object PlaybackSnapshot() => new {
            groupPlaybackCommands = new Dictionary<string, int>(GlobalGroupCommands, StringComparer.Ordinal),
            cuePlaybackCommands = new Dictionary<string, int>(GlobalCueCommands, StringComparer.Ordinal),
            globalDeathRequests, globalDeathVoiceCommands, globalDeathVoiceObservedPlaying, globalDeathTailFailures, globalDeathSuppressed,
            lastDeathCue, lastDeathVoiceCommand, lastDeathPlayingObserved, lastDeathFailure, lastDeathGain,
            activeTailSources = Tails.Count, tailsCreated, tailsDestroyed, audioEnabled = mixEnabled, masterVolume,
            scope = "Session counters survive actor destruction. Play commands and observed AudioSource.isPlaying are separate; neither establishes listener audibility or human mix approval. Both breathing source commands can be counted while one is at zero crossfade gain." };
        public static void Shutdown()
        {
            foreach (var actor in new List<MonkAudioController>(Actors)) if (actor) actor.Cleanup("plugin shutdown");
            foreach (var tail in new List<MonkAudioTail>(Tails))
                if (tail) { tail.Stop(); if (Tails.Remove(tail)) tailsDestroyed++; Object.Destroy(tail.gameObject); }
            Tails.Clear(); MonkAudioBank.Shutdown();
        }
        static bool SpawnTail(MonkAudioBank.ClipRecord cue, Vector3 position, float intensity, AudioMixerGroup mixer, int importance)
        {
            if (cue == null || !cue.Clip || !mixer) return false;
            if (Tails.Count >= MonkAudioPolicy.MaximumTailSources)
            {
                MonkAudioTail oldest = null;
                foreach (var candidate in Tails)
                    if (candidate && (oldest == null || candidate.Importance < oldest.Importance
                        || (candidate.Importance == oldest.Importance && candidate.Expires < oldest.Expires))) oldest = candidate;
                if (!oldest || oldest.Importance > importance) return false;
                oldest.Stop(); if (Tails.Remove(oldest)) tailsDestroyed++; Object.Destroy(oldest.gameObject);
            }
            var node = new GameObject("HM Owned Death Audio Tail"); node.transform.position = position;
            var source = node.AddComponent<AudioSource>(); ConfigureSource(source, mixer, 80, 28);
            float gain = Mathf.Clamp01(cue.gain * intensity);
            source.clip = cue.Clip; source.volume = gain * masterVolume;
            var tail = node.AddComponent<MonkAudioTail>(); tail.Source = source;
            tail.BaseVolume = gain; tail.Importance = importance;
            if (importance == 2) { lastDeathSourceId = source.GetInstanceID(); lastDeathGain = source.volume; }
            tail.Expires = Time.realtimeSinceStartup + Mathf.Min(5, cue.Clip.length + .25f); Tails.Add(tail); tailsCreated++;
            source.Play(); return true;
        }
        public sealed class MonkAudioTail : MonoBehaviour
        {
            public AudioSource Source; public float Expires, BaseVolume; public int Importance;
            bool reportedPlaying;
            public void Stop() { if (Source) { Source.Stop(); Source.volume = 0; } }
            void Update()
            {
                if (Source) Source.volume = mixEnabled ? BaseVolume * masterVolume : 0;
                if (!reportedPlaying && Importance == 2 && Source && Source.isPlaying)
                {
                    reportedPlaying = true; globalDeathVoiceObservedPlaying++;
                    if (Source.GetInstanceID() == lastDeathSourceId) lastDeathPlayingObserved = true;
                }
                if (!Source || Time.realtimeSinceStartup >= Expires) { Stop(); Object.Destroy(gameObject); }
            }
            void OnDestroy() { Stop(); if (Tails.Remove(this)) tailsDestroyed++; }
        }
    }
}
