using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BlackAbbey.HushedMonk
{
    // Explicit private proof only. Reads owned source output; no microphone,
    // system loopback, native sound recording or manufactured gameplay events.
    public sealed class MonkAudioProofProbe
    {
        readonly MonkAudioController controller;
        readonly MonkAudioEventRelay relay;
        readonly AudioSource[] sources;
        readonly float[] buffer = new float[256];
        readonly Dictionary<string, float> peaks = new Dictionary<string, float>();
        readonly Dictionary<string, int> outputSamples = new Dictionary<string, int>();
        readonly HashSet<string> heardClips = new HashSet<string>();
        public MonkAudioController.Telemetry Last;
        public bool CombatObserved, IdleObserved;
        public int Samples;
        public MonkAudioProofProbe(GameObject actor)
        {
            controller = actor.GetComponent<MonkAudioController>();
            relay = actor.GetComponent<MonkAudioEventRelay>();
            sources = controller ? controller.OwnedSourcesForDiagnostics() : Array.Empty<AudioSource>();
        }
        public object Sample()
        {
            Samples++;
            if (ReferenceEquals(controller, null)) return null;
            Last = controller.Snapshot();
            CombatObserved |= Last.combatState && Last.combatBlend > .9f && Last.combatLoopPlaying;
            IdleObserved |= !Last.combatState && Last.combatBlend < .1f && Last.idleLoopPlaying;
            foreach (var source in sources)
            {
                if (!source || !source.isPlaying || !source.clip || source.volume < .00001f) continue;
                if (!source.clip.name.StartsWith("HM Own | ", StringComparison.Ordinal)) throw new InvalidOperationException("Probe encountered unowned audio.");
                source.GetOutputData(buffer, 0);
                float peak = 0;
                foreach (float value in buffer) peak = Mathf.Max(peak, Mathf.Abs(value));
                string id = source.clip.name;
                peaks.TryGetValue(id, out var previous); peaks[id] = Mathf.Max(previous, peak);
                outputSamples.TryGetValue(id, out var count); outputSamples[id] = count + 1;
                if (peak > .000001f) heardClips.Add(id);
            }
            return new { audio = Last, relay = relay ? relay.Snapshot() : null };
        }
        public void Check(Action<string, bool, object> check)
        {
            Sample();
            var bank = HushedMonkPlugin.AudioBank?.Snapshot();
            var policies = Tests.MonkAudioPolicyChecks.Run();
            check("production audio policies and real PCM decoder adversarial checks", policies.Count == 21 && policies.Values.All(x => x), policies);
            check("selected56 clips decoded once into shared runtime bank", bank != null && bank.ready && bank.clipCount == 56 && bank.loadedClipCount == 56 && bank.decodeCount == 56, bank);
            check("owned audio has six bounded sources and native SFX mixer route", sources.Length == 6 && Last != null && !string.IsNullOrEmpty(Last.mixerName) && Last.mixerName != "native default output", Last?.mixerName);
            check("natural combat activated faster breathing loop", CombatObserved, Last);
            check("actual engine produced nonzero owned audio output", heardClips.Count > 0, new { samples = Samples, nonzeroClips = heardClips.ToArray(), peaks, outputSamples, idleStateObserved = IdleObserved });
            check("actual attack relayed one windup swing and confirmed impact", Last != null && Last.windupEvents == 1 && Last.attackHitEvents == 1 && Last.impactEvents >= 1, Last);
            check("actual damage and death relayed exactly once", Last != null && Last.hurtEvents == 1 && Last.deathEvents == 1, Last);
            check("wool and physical wristbell emitted during natural movement", Last != null && Last.clothEvents > 0 && Last.bellEvents > 0, Last);
            check("owned actor sources and detached death tails cleaned", Last != null && Last.resourcesCleaned && Last.allocatedSources == 0 && Last.tailVoicesActive == 0 && Last.tailsCreated >= 1 && Last.tailsCreated == Last.tailsDestroyed, Last);
        }
    }
}
