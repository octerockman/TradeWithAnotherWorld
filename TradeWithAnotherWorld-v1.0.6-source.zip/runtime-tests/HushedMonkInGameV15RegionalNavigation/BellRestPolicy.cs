using System;

namespace BlackAbbey.HushedMonk
{
    // Root/action driven hysteresis. Animated breathing/wrist bob alone cannot
    // wake the cosmetic bell. Sound eligibility stops before visual settling.
    public sealed class BellRestPolicy
    {
        public const float WakeSpeed=.12f,KeepMovingSpeed=.06f,WakeTurnRate=15f,KeepTurningRate=6f;
        public const float QuietDelay=.20f,SettleSeconds=.30f;
        public const float WakeDisplacement=.02f,WakeTurnDisplacement=3f;
        float quietFor=QuietDelay+SettleSeconds;
        public bool Driven {get;private set;}
        public bool Held {get;private set;}=true;
        public float Settle {get;private set;}=1;
        public void Reset(){quietFor=QuietDelay+SettleSeconds;Driven=false;Held=true;Settle=1;}
        public void Step(float delta,float speed,float turnRate,bool action,float displacement=0,float turnDisplacement=0)
        {
            if(!Finite(delta)||delta<=0||!Finite(speed)||speed<0||!Finite(turnRate)||turnRate<0||!Finite(displacement)||displacement<0||!Finite(turnDisplacement)||turnDisplacement<0){Reset();return;}
            bool drive=action||speed>(Driven?KeepMovingSpeed:WakeSpeed)||turnRate>(Driven?KeepTurningRate:WakeTurnRate)||
                displacement>WakeDisplacement||turnDisplacement>WakeTurnDisplacement;
            Driven=drive;
            if(drive){quietFor=0;Held=false;Settle=0;return;}
            quietFor+=Math.Min(delta,.1f);
            Settle=Math.Max(0,Math.Min(1,(quietFor-QuietDelay)/SettleSeconds));Held=Settle>=1;
        }
        static bool Finite(float n)=>!float.IsNaN(n)&&!float.IsInfinity(n);
    }
}
