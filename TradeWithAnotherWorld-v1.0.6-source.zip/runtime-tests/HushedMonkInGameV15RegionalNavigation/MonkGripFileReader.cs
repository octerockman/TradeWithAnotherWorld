using System;
using System.Globalization;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace BlackAbbey.HushedMonk
{
    // Own-data DTOs use the same managed JSON library as the visual payload.
    // Do not rely on Unity's player-side type serialization for a mod DLL.
    public static class MonkGripFileReader
    {
        [Serializable, JsonObject(MemberSerialization.Fields)]
        public sealed class GripFile
        {
            public string schema, sourceNativeSha256, sourcePayloadSha256, weaponPrefab;
            public FingerPose[] poses;
        }
        [Serializable, JsonObject(MemberSerialization.Fields)]
        public sealed class FingerPose { public string boneName; public float[] localRotationXYZW; }

        public static GripFile Read(string text, string payloadHash, string nativeHash, string weaponName)
        {
            if (string.IsNullOrWhiteSpace(text) || text.Length > 64 * 1024)
                throw new InvalidDataException("Required hand-grip.json is empty or oversized.");
            GripFile data;
            try
            {
                // Create (not CreateDefault) prevents another mod's global JSON
                // settings or converters from altering this exact file contract.
                var serializer = JsonSerializer.Create(new JsonSerializerSettings {
                    ContractResolver = new DefaultContractResolver(), Culture = CultureInfo.InvariantCulture,
                    TypeNameHandling = TypeNameHandling.None, MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
                    // The frozen sidecar also carries authoring provenance.
                    MissingMemberHandling = MissingMemberHandling.Ignore, MaxDepth = 16, CheckAdditionalContent = true
                });
                using (var reader = new JsonTextReader(new StringReader(text))) data = serializer.Deserialize<GripFile>(reader);
            }
            catch (JsonException ex) { throw new InvalidDataException("Required hand-grip.json could not be read: " + ex.Message, ex); }
            if (data == null) throw new InvalidDataException("Required hand-grip.json is null.");
            Require(data.schema == "hushed-monk.right-hand-grip.v1", "schema");
            Require(data.weaponPrefab == weaponName, "weaponPrefab");
            Require(data.sourcePayloadSha256 == payloadHash, "sourcePayloadSha256");
            Require(data.sourceNativeSha256 == nativeHash, "sourceNativeSha256");
            Require(data.poses != null && data.poses.Length == 15, "fifteen-finger pose inventory");
            return data;
        }

        static void Require(bool condition, string field)
        { if (!condition) throw new InvalidDataException("Required hand-grip.json differs in " + field + ". No substitute grip or model will be loaded."); }
    }
}
