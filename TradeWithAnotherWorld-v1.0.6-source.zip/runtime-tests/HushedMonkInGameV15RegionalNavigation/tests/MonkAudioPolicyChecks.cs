using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace BlackAbbey.HushedMonk.Tests
{
    // Production-policy cases usable from the private Unity batch probe or a console harness.
    // No mocked AI or artificial success counters in the live game proof.
    public static class MonkAudioPolicyChecks
    {
        public static Dictionary<string, bool> Run()
        {
            var result = new Dictionary<string, bool>();
            var cd = new MonkAudioPolicy.Cooldowns();
            result["cooldown allows initial event and suppresses rapid duplicate"] = cd.Take("hurt", 0, 1) && !cd.Take("hurt", .2f, 1) && cd.Take("hurt", 1.1f, 1);
            result["clock reset cannot permanently suppress events"] = cd.Take("hurt", -2, 1);
            var combat = new MonkAudioPolicy.CombatGate();
            result["combat entry requires sustained request"] = !combat.Update(0, true) && !combat.Update(.1f, true) && combat.Update(.3f, true);
            result["brief quiet interval does not flap combat loop"] = combat.Update(1, false) && combat.Update(4.9f, false) && !combat.Update(5.1f, false);
            combat.Update(6, true); combat.Update(6.3f, true); combat.Reset();
            result["presentation reset releases prior combat and requires fresh entry"] = !combat.State && !combat.Update(7, true) && combat.Update(7.3f, true);
            var settled = new MonkAudioPolicy.BellGate();
            bool silent = true;
            for (int i = 0; i < 500; i++) silent &= settled.Sample(i*.02f, true, 0, .01f, .2f, .001f, false, false) == null;
            result["settled bell stays silent without a timer strike"] = silent;
            var bell = new MonkAudioPolicy.BellGate();
            result["first physics initialization is silent"] = bell.Sample(0, true, 0, 2, 10, .001f, false, false) == null;
            bool built = bell.Sample(1.6f, true, 0, 2, 10, .001f, false, false) == null;
            result["physical swing build then slowdown produces one strike"] = built && bell.Sample(1.7f, true, 0, .1f, 12, .001f, false, false) == "bellSoft";
            bell.Sample(1.8f, true, 0, 2, 12, .001f, false, false);
            result["bell cooldown blocks rapid second swing"] = bell.Sample(1.9f, true, 0, .1f, 10, .001f, true, false) == null;
            result["teleport suppresses apparent swing"] = bell.Sample(3, true, 0, 3, 20, .001f, true, true) == null && bell.Sample(3.1f, true, 0, .1f, 20, .001f, true, false) == null;
            result["physics reset suppresses apparent swing"] = bell.Sample(5, true, 1, 4, 20, .001f, true, false) == null;
            result["solver-speed spike is not an audio strike"] = bell.Sample(7, true, 1, 20, 20, .001f, true, false) == null;
            result["unknown and soil impacts do not become stone"] = MonkAudioPolicy.ImpactGroup("soil") == null && MonkAudioPolicy.ImpactGroup("terrain") == null && MonkAudioPolicy.ImpactGroup(null) == null;
            result["confirmed body wood stone metal map to distinct selected groups"] = MonkAudioPolicy.ImpactGroup("body") == "clapperBody" && MonkAudioPolicy.ImpactGroup("Wood") == "clapperWood" && MonkAudioPolicy.ImpactGroup("stone") == "clapperStone" && MonkAudioPolicy.ImpactGroup("metal") == "clapperMetal";
            byte[] valid = Wave(48000, 1, 16, new short[] { 100, -100, 200, -200 });
            result["actual PCM decoder accepts coherent mono48k16"] = MonkAudioBank.DecodePcm16(valid, 4).Length == 4;
            result["actual PCM decoder rejects stereo"] = Reject(() => MonkAudioBank.DecodePcm16(Wave(48000,2,16,new short[]{100,-100,200,-200}),4));
            result["actual PCM decoder rejects wrong rate"] = Reject(() => MonkAudioBank.DecodePcm16(Wave(44100,1,16,new short[]{100,-100,200,-200}),4));
            result["actual PCM decoder rejects metadata frame mismatch"] = Reject(() => MonkAudioBank.DecodePcm16(valid,3));
            result["actual PCM decoder rejects truncated RIFF"] = Reject(() => MonkAudioBank.DecodePcm16(new ArraySegment<byte>(valid,0,valid.Length-1).ToArray(),4));
            result["actual PCM decoder rejects silent data"] = Reject(() => MonkAudioBank.DecodePcm16(Wave(48000,1,16,new short[4]),4));
            result["actual PCM decoder rejects full-scale sample"] = Reject(() => MonkAudioBank.DecodePcm16(Wave(48000,1,16,new short[]{100,short.MinValue,100,0}),4));
            return result;
        }
        static bool Reject(Action action) { try { action(); return false; } catch (InvalidDataException) { return true; } }
        static byte[] Wave(int rate, short channels, short bits, short[] samples)
        {
            using (var memory = new MemoryStream())
            using (var writer = new BinaryWriter(memory))
            {
                writer.Write(Encoding.ASCII.GetBytes("RIFF")); writer.Write(36 + samples.Length*2); writer.Write(Encoding.ASCII.GetBytes("WAVEfmt "));
                writer.Write(16); writer.Write((short)1); writer.Write(channels); writer.Write(rate); writer.Write(rate*channels*(bits/8));
                writer.Write((short)(channels*(bits/8))); writer.Write(bits); writer.Write(Encoding.ASCII.GetBytes("data")); writer.Write(samples.Length*2);
                foreach (short sample in samples) writer.Write(sample); return memory.ToArray();
            }
        }
    }
}
