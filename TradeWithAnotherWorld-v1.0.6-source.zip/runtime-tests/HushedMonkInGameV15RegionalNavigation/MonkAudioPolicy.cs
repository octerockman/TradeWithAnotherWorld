using System;
using System.Collections.Generic;

namespace BlackAbbey.HushedMonk
{
    // Pure timing/state policy; no game, physics, audio-source or network mutation.
    public static class MonkAudioPolicy
    {
        public static readonly string[] RequiredGroups = {
            "idleBreath", "combatBreath", "idleVoice", "investigate", "alert", "attack",
            "hurtLight", "hurtHeavy", "death", "bellSoft", "bellMedium", "bellDouble", "bellBuzz",
            "clothWalk", "clothTurn", "clothWindup", "clapperWhoosh", "clapperBody",
            "clapperStone", "clapperWood", "clapperMetal"
        };
        public const int MaximumActorOneShots = 4, MaximumTailSources = 6;
        public const float LoopCrossfadeSeconds = .65f, CombatEnterSeconds = .25f, CombatExitSeconds = 4f;
        public const float TeleportDistance = 1.25f, BellCooldown = .95f, BellStartupSeconds = 1.5f;
        public const string CombatZdoKey = "HM_AudioCombatV1";

        // Keep the existing four event sources, reserving two for weapon
        // feedback. Long voices/hurts/bells cannot occupy every attack slot.
        public static int ReservedWeaponLane(string group) => group == "clapperWhoosh" ? 2 :
            group == "clapperBody" || group == "clapperStone" || group == "clapperWood" || group == "clapperMetal" ? 3 : -1;
        public sealed class EventSequenceGate
        {
            long owner;int sequence;
            public bool Accept(long nextOwner,int nextSequence)
            {
                if(nextSequence<=0)return false;
                if(nextOwner!=owner){owner=nextOwner;sequence=0;}
                if(nextSequence<=sequence)return false;
                sequence=nextSequence;return true;
            }
        }

        public sealed class Cooldowns
        {
            readonly Dictionary<string, float> next = new Dictionary<string, float>(StringComparer.Ordinal);
            float lastTime = float.NegativeInfinity;
            public bool Take(string key, float now, float interval)
            {
                if (now < lastTime) next.Clear();
                lastTime = now;
                if (next.TryGetValue(key, out var due) && now < due) return false;
                next[key] = now + Math.Max(0, interval); return true;
            }
        }
        public sealed class CombatGate
        {
            public bool State { get; private set; }
            float requestedSince = -1, quietSince = -1;
            public void Reset() { State = false; requestedSince = quietSince = -1; }
            public bool Update(float now, bool requested)
            {
                if (requested)
                {
                    quietSince = -1;
                    if (requestedSince < 0) requestedSince = now;
                    if (now - requestedSince >= CombatEnterSeconds) State = true;
                }
                else
                {
                    requestedSince = -1;
                    if (quietSince < 0) quietSince = now;
                    if (now - quietSince >= CombatExitSeconds) State = false;
                }
                return State;
            }
        }
        public sealed class BellGate
        {
            float quietUntil, lastStrike = -100, maximumEnergy, sampledAt, travelled, motionUntil;
            int previousReset = -1;
            bool armed;
            public int Suppressed { get; private set; }
            public void Reset(float now)
            {
                sampledAt = Finite(now) ? now : 0;
                quietUntil = sampledAt + BellStartupSeconds; lastStrike = sampledAt - BellCooldown;
                armed = false; maximumEnergy = travelled = 0; motionUntil = sampledAt;
            }
            public void SuppressIdle(float now,int resetCount,bool teleport)
            {
                if(!Finite(now)||now<sampledAt||resetCount!=previousReset||teleport)
                {previousReset=resetCount;Reset(now);}
                sampledAt=Finite(now)?now:sampledAt;
                armed=false;maximumEnergy=travelled=0;motionUntil=sampledAt;Suppressed++;
            }
            // Cosmetic strike approximation: the internal clapper has no separate body.
            // Continuous coupled motion need not bring every rotation axis to
            // a simultaneous stop. Travel is actual motion, never a timer cue.
            public string Sample(float now, bool initialized, int resetCount, float speed,
                float angle, float anchorGap, bool reversal, bool teleport)
            {
                if (!Finite(now) || now < sampledAt || !initialized || resetCount != previousReset || teleport ||
                    !Finite(anchorGap) || anchorGap < 0 || anchorGap > .03f ||
                    !Finite(speed) || speed < 0 || speed > 8.25f || !Finite(angle) || angle < 0)
                {
                    previousReset = resetCount; Reset(now); Suppressed++; return null;
                }
                float dt = Math.Min(.05f, Math.Max(0, now - sampledAt)); sampledAt = now;
                if (now < quietUntil) { Suppressed++; return null; }
                bool moving = speed > .45f && angle > 1.5f;
                if (moving)
                {
                    armed = true; maximumEnergy = Math.Max(maximumEnergy, speed);
                    travelled += speed * dt; motionUntil = now + .20f;
                }
                if (now > motionUntil) { armed = false; maximumEnergy = travelled = 0; }
                bool strike = reversal || speed < .35f || moving && travelled >= .18f;
                if (!armed || !strike || now - lastStrike < BellCooldown) return null;
                armed = false; lastStrike = now;
                string group = maximumEnergy > 3.8f ? "bellMedium" : "bellSoft";
                maximumEnergy = travelled = 0; return group;
            }
        }
        public static string ImpactGroup(string material)
        {
            switch ((material ?? "").ToLowerInvariant())
            {
                case "body": case "flesh": case "skin": return "clapperBody";
                case "wood": case "hardwood": return "clapperWood";
                case "stone": case "rock": return "clapperStone";
                case "metal": case "block": case "shield": return "clapperMetal";
                default: return null; // Unknown contact is not invented as a hard impact.
            }
        }
        public static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
    }
}
