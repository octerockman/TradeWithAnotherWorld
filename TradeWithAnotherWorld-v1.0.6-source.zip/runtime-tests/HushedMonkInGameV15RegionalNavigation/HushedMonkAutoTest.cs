using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace BlackAbbey.HushedMonk
{
    // Purpose-built game API harness. No GUI/pointer input, no default saves,
    // no existing character/world, no forced enemy behavior and no startup
    // action whatsoever without the two explicit flags and verified fence.
    public static class HushedMonkAutoTest
    {
        const string Flag = "-hm-proof-autostart";
        const string SaveFlag = "-ba-test-save-dir";
        const string Marker = ".black-abbey-room-test-profile";
        const string MarkerText = "BlackAbbeyRoomTest isolated local save profile v1";
        static Context current;
        static bool attempted;
        sealed class Context
        {
            public MonoBehaviour Host;
            public GameObject Prefab;
            public Action<string> Log;
            public string SaveRoot, Workspace, Output, ProfileName, WorldName, Id;
            public bool Capture, Quit, SkipIntro, SessionRequested, Completed, Passed, Dungeon, StartupOwned;
            public MonkDungeonProofRoom DungeonRoom;
            public bool PreviousRunInBackground;
            public int StartFrame;
            public float Started;
            public readonly List<object> Steps = new List<object>();
            public readonly List<object> Captures = new List<object>();
            public readonly List<object> DiagnosticCaptures = new List<object>();
            public readonly List<string> DiagnosticErrors = new List<string>();
        }

        // Call once in plugin Awake with null prefab, and again after successful
        // registration with the actual prefab. The latter merely supplies data
        // to the existing opted-in run; it cannot start a second session.
        public static void Attach(MonoBehaviour host, GameObject prefab, Action<string> log, string installedEvidenceDirectory)
        {
            if (current != null) { if (prefab) current.Prefab = prefab; return; }
            if (attempted) return;
            string[] args = Environment.GetCommandLineArgs();
            if (!args.Any(a => string.Equals(a, Flag, StringComparison.OrdinalIgnoreCase))) return;
            attempted = true;
            try
            {
                if (!host) throw new InvalidOperationException("Autotest needs the persistent plugin host.");
                if (args.Count(a => string.Equals(a, Flag, StringComparison.OrdinalIgnoreCase)) != 1) throw new InvalidOperationException("Duplicate autostart flag.");
                string save = Argument(args, SaveFlag);
                if (!Path.IsPathRooted(save) || !Directory.Exists(save)) throw new InvalidOperationException("An existing absolute marked private save directory is required.");
                save = Normalize(save);
                if (save == Normalize(Path.GetPathRoot(save))) throw new InvalidOperationException("Filesystem roots cannot be save fences.");
                string marker = Path.Combine(save, Marker);
                if (!File.Exists(marker) || File.ReadAllText(marker).Trim() != MarkerText) throw new InvalidOperationException("Private-save marker mismatch; nothing was created or loaded.");
                // The established isolation helper owns process-level routing.
                // Its Awake and platform setup may still be running: verify the
                // active routes after native menu setup, before any game save.
                string workspace = FindWorkspace(save);
                string id = DateTime.UtcNow.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0, 8);
                string output = Path.Combine(workspace, "models", "black-abbey", "enemies", "hushed-monk", "runtime-test-v5-combat-polish", "validation", "game-runs", "autotest-" + id);
                if (Directory.Exists(output) || File.Exists(output)) throw new IOException("New run output unexpectedly exists.");
                Directory.CreateDirectory(output);
                current = new Context { Host = host, Prefab = prefab, Log = log, SaveRoot = save, Workspace = workspace, Output = output,
                    Id = id, ProfileName = "hmproof_" + id.Replace("-", "").ToLowerInvariant(), WorldName = "HMProof_" + id.Replace("-", ""),
                    Capture = Has(args, "-hm-proof-capture"), Quit = Has(args, "-hm-proof-quit"), SkipIntro = Has(args, "-hm-proof-skip-intro"), Dungeon = Has(args, "-hm-proof-dungeon"), Started = Time.realtimeSinceStartup,
                    StartFrame = Time.frameCount, PreviousRunInBackground = Application.runInBackground };
                Application.runInBackground = true; // Process property only; no persisted game settings.
                Step(current, "explicit opt-in and marked private folder; active routing check pending", new { save, marker, workspace,
                    installedEvidenceDirectory, capturesOptedIn = current.Capture, quitOptedIn = current.Quit, skipNewProfileIntroOptedIn = current.SkipIntro });
                host.StartCoroutine(Guarded(current));
            }
            catch (Exception ex) { log?.Invoke("HM_AUTOTEST_DENIED " + ex); }
        }

        static string Argument(string[] args, string name)
        {
            int[] indices = args.Select((a, i) => new { a, i }).Where(x => string.Equals(x.a, name, StringComparison.OrdinalIgnoreCase)).Select(x => x.i).ToArray();
            if (indices.Length != 1 || indices[0] + 1 >= args.Length || string.IsNullOrWhiteSpace(args[indices[0] + 1]) || args[indices[0] + 1].StartsWith("-", StringComparison.Ordinal))
                throw new InvalidOperationException("Provide exactly one " + name + " followed by an absolute directory.");
            return args[indices[0] + 1];
        }
        static bool Has(string[] args, string flag) => args.Any(a => string.Equals(a, flag, StringComparison.OrdinalIgnoreCase));
        static string Normalize(string p) => Path.GetFullPath(p).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        static bool Same(string a, string b) => string.Equals(Normalize(a), Normalize(b), StringComparison.OrdinalIgnoreCase);
        static void Fence(string expected)
        {
            string local = Utils.GetSaveDataPath(FileHelpers.FileSource.Local), auto = Utils.GetSaveDataPath(FileHelpers.FileSource.Auto);
            if (!Same(expected, local) || !Same(expected, auto) || FileHelpers.CloudStorageSupported || FileHelpers.CloudStorageSupportedAndEnabled)
                throw new InvalidOperationException("Active save isolation/cloud fence failed. The harness will not patch it or use default saves.");
        }
        static void Inside(string root, string path)
        {
            string prefix = Normalize(root) + Path.DirectorySeparatorChar;
            if (!Path.GetFullPath(path).StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new IOException("Path escapes the verified private fence: " + path);
        }
        static string FindWorkspace(string save)
        {
            for (var dir = new DirectoryInfo(save); dir != null; dir = dir.Parent)
                if (File.Exists(Path.Combine(dir.FullName, "project-core", "README.md")) && File.Exists(Path.Combine(dir.FullName, "AGENTS.md"))) return dir.FullName;
            throw new IOException("Private save directory must be inside the project workspace; capture output may not use default or arbitrary directories.");
        }
        static void Step(Context c, string stage, object details = null)
        {
            c.Steps.Add(new { stage, elapsed = Time.realtimeSinceStartup - c.Started, frame = Time.frameCount, details });
            c.Log?.Invoke("HM_AUTOTEST " + stage + " " + JsonConvert.SerializeObject(details));
        }
        static IEnumerator Guarded(Context c)
        {
            var sequence = Run(c);
            while (true)
            {
                object next = null; bool more;
                try { more = sequence.MoveNext(); if (more) next = sequence.Current; }
                catch (Exception ex) { Step(c, "FAILED", ex.ToString()); c.Passed = false; break; }
                if (!more) break;
                yield return next;
            }
            (sequence as IDisposable)?.Dispose();
            if (HushedMonkGameProof.Busy) HushedMonkGameProof.Stop(c.Log);
            // A minimized game can update without yielding EndOfFrame. Never
            // hang the test on a render wait: allow three real seconds for the
            // requested PNGs to finish, then record a missing-capture failure.
            float flushDeadline = Time.realtimeSinceStartup + 3f;
            while (c.Capture && c.Captures.Count > 0 && Time.realtimeSinceStartup < flushDeadline)
            {
                string[] pending = Directory.GetFiles(c.Output, "actual-game-*.png");
                if (pending.Length == c.Captures.Count && pending.All(CaptureComplete)) break;
                yield return null;
            }
            c.DungeonRoom?.Dispose(); c.DungeonRoom = null;
            try { Finish(c); }
            finally { Application.runInBackground = c.PreviousRunInBackground; }
            if (c.Quit && ((c.SessionRequested && OwnSession(c)) || (c.StartupOwned && !c.SessionRequested && !Game.instance && !Player.m_localPlayer)))
            { Step(c, "graceful quit of this opted-in private session", null); Application.Quit(); }
        }
        static bool OwnSession(Context c)
        {
            if (!Game.instance && !Player.m_localPlayer) return true;
            if (!Game.instance || Game.instance.GetPlayerProfile()?.GetFilename() != c.ProfileName) return false;
            return ZNet.instance && ZNet.instance.GetWorld()?.m_name == c.WorldName;
        }
        static IEnumerator Run(Context c)
        {
            // Never replace an already loaded world or character.
            if (Game.instance || Player.m_localPlayer) throw new InvalidOperationException("Autostart refuses an already loaded game.");
            c.StartupOwned = true;
            float menuDeadline = Time.realtimeSinceStartup + 30f;
            while (!FejdStartup.instance && Time.realtimeSinceStartup < menuDeadline) yield return null;
            if (!FejdStartup.instance) throw new TimeoutException("Native menu startup was not available.");
            yield return null; // Allow FejdStartup.Start to finish native setup.
            Fence(c.SaveRoot);
            Step(c, "active Local/Auto private routing and cloud fence verified", new { c.SaveRoot });
            if (Game.instance || Player.m_localPlayer) throw new InvalidOperationException("A game was loaded while waiting for menu setup.");
            if (!string.IsNullOrEmpty(HushedMonkPlugin.RegistrationFailure)) throw new InvalidOperationException("Monk registration failed: " + HushedMonkPlugin.RegistrationFailure);

            var profile = new PlayerProfile(c.ProfileName, FileHelpers.FileSource.Local);
            profile.SetName("Monk Proof " + c.Id);
            string profilePath = profile.GetPath(); Inside(c.SaveRoot, profilePath);
            if (File.Exists(profilePath)) throw new IOException("Refusing to overwrite a character, even inside the test folder.");
            // Installed IL: m_firstSpawn only queues/passes native intro and is
            // then cleared. This is a brand-new, not-yet-saved private profile;
            // never load/edit an existing profile or a remembered preference.
            if (c.SkipIntro) profile.m_firstSpawn = false;
            if (!profile.Save()) throw new IOException("New private character save failed.");
            var world = new World(c.WorldName, "HMProof" + c.Id.Replace("-", "")) { m_fileSource = FileHelpers.FileSource.Local, m_needsDB = false };
            string worldPath = world.GetSaveFWLPath(); Inside(c.SaveRoot, worldPath);
            if (File.Exists(worldPath) || Directory.Exists(Path.GetDirectoryName(worldPath))) throw new IOException("Refusing to overwrite/reuse the new world metadata directory.");
            foreach (string path in world.GetSavePaths()) { Inside(c.SaveRoot, path); if (File.Exists(path) || Directory.Exists(path)) throw new IOException("Refusing to reuse existing world data: " + path); }
            world.SaveWorldFWLData(DateTime.Now);
            if (!File.Exists(profilePath) || !File.Exists(worldPath)) throw new IOException("Native new-save files were not written at the checked paths.");
            Step(c, "created new local character and world only", new { character = c.ProfileName, world = c.WorldName, profilePath, worldPath,
                characterSha256 = Hash(profilePath), worldMetaSha256 = Hash(worldPath), firstSpawnIntro = profile.m_firstSpawn,
                introPolicy = c.SkipIntro ? "Explicit opt-in m_firstSpawn=false on this new unsaved private profile only" : "Untouched native first-spawn intro" });
            Fence(c.SaveRoot);
            // Native API equivalent of starting this new closed local world.
            // Avoid OnCharacterStart/OnWorldStart UI handlers: those also write
            // globally remembered profile/world and server toggle preferences.
            Game.SetProfile(c.ProfileName, FileHelpers.FileSource.Local);
            ZNet.SetServer(true, false, false, c.WorldName, "", world);
            ZNet.ResetServerHost(); c.SessionRequested = true;
            Step(c, "native closed single-player scene startup requested", new { openServer = false, publicServer = false, guiActions = false });
            SystemResourceManager.FastLoadScene(FejdStartup.instance.m_mainScene, SoftReferenceableAssets.SceneManagement.LoadSceneMode.Single);

            float playerDeadline = Time.realtimeSinceStartup + 300f;
            float nextStatus = Time.realtimeSinceStartup;
            while (Time.realtimeSinceStartup < playerDeadline)
            {
                if (!string.IsNullOrEmpty(HushedMonkPlugin.RegistrationFailure)) throw new InvalidOperationException("Monk registration failed: " + HushedMonkPlugin.RegistrationFailure);
                var player = Player.m_localPlayer;
                if (player && !OwnSession(c)) throw new InvalidOperationException("Loaded character/world does not match this harness's newly created records.");
                if (player && !player.IsDead() && !player.InIntro() && !player.InCutscene() && !player.IsTeleporting() && player.IsOnGround() && c.Prefab) break;
                if (Time.realtimeSinceStartup >= nextStatus)
                {
                    Step(c, "waiting for native player control and monk registration", new { player = player != null, intro = player && player.InIntro(),
                        cutscene = player && player.InCutscene(), teleporting = player && player.IsTeleporting(), grounded = player && player.IsOnGround(), prefabReady = c.Prefab != null });
                    nextStatus = Time.realtimeSinceStartup + 10f;
                }
                yield return new WaitForSecondsRealtime(.2f);
            }
            var local = Player.m_localPlayer;
            if (!local || !c.Prefab || local.IsDead() || local.InIntro() || local.InCutscene() || local.IsTeleporting() || !local.IsOnGround())
                throw new TimeoutException("Native local player did not become grounded/controllable with the monk ready within 300 seconds.");
            Step(c, "allowing native camera and arrival environment to settle", new { seconds = 8, playerOrCameraMoved = false });
            float settleDeadline = Time.realtimeSinceStartup + 8f;
            while (Time.realtimeSinceStartup < settleDeadline)
            {
                if (!OwnSession(c) || !Player.m_localPlayer || Player.m_localPlayer.IsDead()) throw new InvalidOperationException("Owned private session/player changed during the settling interval.");
                yield return null;
            }
            Fence(c.SaveRoot);
            if (!OwnSession(c) || !ZNet.IsSinglePlayer || !ZNet.instance.IsServer()) throw new InvalidOperationException("Final new-session ownership or local-only check failed.");
            Step(c, "actual new local player ready for natural AI proof", new { profile = c.ProfileName, world = c.WorldName, health = local.GetHealth(), position = V(local.transform.position) });
            if (c.Dungeon)
            {
                c.DungeonRoom = MonkDungeonProofRoom.Load(local, c.Log);
                float travelEnd = Time.realtimeSinceStartup + 30;
                while (Time.realtimeSinceStartup < travelEnd && (local.IsTeleporting() || !local.IsOnGround())) yield return null;
                if (local.IsTeleporting() || !local.IsOnGround() || local.transform.position.y < 7900)
                    throw new InvalidOperationException("Private authored-room placement did not become grounded.");
                yield return new WaitForSecondsRealtime(2);
                Step(c, "private R04 floor and high altitude ready", c.DungeonRoom.SourceEvidence);
            }
            // No teleport, healing, invulnerability, forced AI target or forced
            // animation. The existing bounded proof observes actual behavior.
            if (!HushedMonkGameProof.Begin(c.Host, c.Prefab, c.Log, c.Output)) throw new InvalidOperationException("Bounded game proof refused to begin.");
            float proofStart = Time.realtimeSinceStartup, proofDeadline = proofStart + 60f;
            int capture = 0; float[] captureTimes = { .75f, 1.5f, 3f, 6f, 8f };
            while (HushedMonkGameProof.Busy && Time.realtimeSinceStartup < proofDeadline)
            {
                if (!OwnSession(c)) throw new InvalidOperationException("Session changed during the proof.");
                if (c.Capture && capture < captureTimes.Length && Time.realtimeSinceStartup - proofStart >= captureTimes[capture])
                { Capture(c, capture, Time.realtimeSinceStartup - proofStart); capture++; }
                yield return null;
            }
            if (HushedMonkGameProof.Busy) throw new TimeoutException("Bounded proof did not finish within 40 seconds.");
            string[] reports = Directory.GetFiles(c.Output, "game-proof-*.json");
            if (reports.Length != 1) throw new IOException("Expected exactly one actual game proof receipt in the new run folder.");
            var proof = JObject.Parse(File.ReadAllText(reports[0]));
            c.Passed = proof.Value<bool?>("passed") == true;
            c.Completed = true;
            Step(c, "actual proof completed", new { passed = c.Passed, path = reports[0], sha256 = Hash(reports[0]) });
        }
        static float[] V(Vector3 p) => new[] { p.x, p.y, p.z };
        static string Hash(string path)
        { using (var input = File.OpenRead(path)) using (var sha = SHA256.Create()) return string.Concat(sha.ComputeHash(input).Select(b => b.ToString("x2"))); }
        static bool CaptureComplete(string path)
        {
            try
            {
                using (var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    if (file.Length < 32) return false;
                    byte[] header = new byte[8], tail = new byte[12];
                    if (file.Read(header, 0, 8) != 8) return false;
                    file.Seek(-12, SeekOrigin.End); if (file.Read(tail, 0, 12) != 12) return false;
                    return header.SequenceEqual(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 }) &&
                        tail.SequenceEqual(new byte[] { 0, 0, 0, 0, 73, 69, 78, 68, 174, 66, 96, 130 });
                }
            }
            catch (IOException) { return false; }
        }
        static void Capture(Context c, int index, float elapsed)
        {
            string path = Path.Combine(c.Output, "actual-game-" + index.ToString("00") + ".png");
            Inside(c.Output, path);
            var actors = UnityEngine.Object.FindObjectsByType<HushedMonkInstance>(FindObjectsSortMode.None).Where(m => m && m.gameObject.activeInHierarchy).ToArray();
            ScreenCapture.CaptureScreenshot(path);
            c.Captures.Add(new { path, requestedAtFrame = Time.frameCount, proofElapsed = elapsed, actorCount = actors.Length,
                actorStates = actors.Select(a => a.Status()).ToArray(), mechanism = "UnityEngine.ScreenCapture, actual current game camera; no OS capture or generated image" });
            Step(c, "actual game ScreenCapture requested", new { path, elapsed, actors = actors.Length });
            // A separate, explicitly labelled scene diagnostic avoids the
            // third-person player's silhouette. The real camera is untouched.
            if (actors.Length == 1)
            {
                CaptureDiagnostic(c, actors[0], index, elapsed);
                try { c.DiagnosticCaptures.Add(BellDiagnosticCapture.Capture(actors[0], Path.Combine(c.Output, "diagnostic-bell-" + index.ToString("00") + ".png"))); }
                catch (Exception ex) { c.DiagnosticErrors.Add("Bell closeup: " + ex); }
            }
        }
        static Bounds ActualVisualBounds(HushedMonkInstance actor, Renderer[] renderers)
        {
            bool first = true; Bounds result = default;
            foreach (var renderer in renderers)
            {
                Bounds world = renderer.bounds;
                if (renderer is SkinnedMeshRenderer skin)
                {
                    var mesh = new Mesh();
                    try
                    {
                        skin.BakeMesh(mesh); mesh.RecalculateBounds();
                        var b = mesh.bounds; world = new Bounds(skin.transform.TransformPoint(b.center), Vector3.zero);
                        for (int i = 0; i < 8; i++) world.Encapsulate(skin.transform.TransformPoint(b.center + Vector3.Scale(b.extents,
                            new Vector3((i & 1) == 0 ? -1 : 1, (i & 2) == 0 ? -1 : 1, (i & 4) == 0 ? -1 : 1))));
                    }
                    finally { UnityEngine.Object.Destroy(mesh); }
                }
                if (first) { result = world; first = false; } else result.Encapsulate(world);
            }
            if (first) throw new InvalidOperationException("No actual own visual renderers for diagnostic framing.");
            return result;
        }
        static void CaptureDiagnostic(Context c, HushedMonkInstance actor, int index, float elapsed)
        {
            GameObject host = null; RenderTexture target = null; Texture2D pixels = null;
            RenderTexture previous = RenderTexture.active;
            try
            {
                Camera source = Camera.main;
                if (!source) throw new InvalidOperationException("Actual game main camera unavailable.");
                var own = actor.GetComponentsInChildren<Renderer>(true).Where(r => r.sharedMaterial && r.sharedMaterial.name.StartsWith("HM_", StringComparison.Ordinal)).ToArray();
                if (own.Length != 4) throw new InvalidOperationException("Diagnostic requires the actual four-renderer monk.");
                Bounds bounds = ActualVisualBounds(actor, own);
                host = new GameObject("HM_AUTOTEST_DIAGNOSTIC_CAMERA"); host.hideFlags = HideFlags.HideAndDontSave;
                Camera camera = host.AddComponent<Camera>(); camera.enabled = false; camera.CopyFrom(source); camera.enabled = false;
                target = new RenderTexture(900, 1100, 24, RenderTextureFormat.ARGB32); target.Create(); camera.targetTexture = target;
                camera.aspect = 900f / 1100f; camera.fieldOfView = 32f; camera.nearClipPlane = .05f;
                bool framed = false; float chosenAngle = 0;
                int mask = LayerMask.GetMask("terrain", "static_solid", "piece", "Default");
                foreach (float angle in new[] { 35f, -35f, 55f, -55f })
                {
                    Vector3 direction = Quaternion.AngleAxis(angle, Vector3.up) * actor.transform.forward;
                    for (float distance = 2.8f; distance < 6.5f; distance += .25f)
                    {
                        camera.transform.position = bounds.center + direction * distance + Vector3.up * .15f;
                        camera.transform.LookAt(bounds.center, Vector3.up);
                        bool inside = true;
                        for (int i = 0; i < 8; i++)
                        {
                            Vector3 corner = bounds.center + Vector3.Scale(bounds.extents,
                                new Vector3((i & 1) == 0 ? -1 : 1, (i & 2) == 0 ? -1 : 1, (i & 4) == 0 ? -1 : 1));
                            Vector3 v = camera.WorldToViewportPoint(corner);
                            if (v.z <= .05f || v.x < .06f || v.x > .94f || v.y < .06f || v.y > .94f) { inside = false; break; }
                        }
                        if (!inside || Physics.Linecast(bounds.center, camera.transform.position, mask, QueryTriggerInteraction.Ignore)) continue;
                        framed = true; chosenAngle = angle; break;
                    }
                    if (framed) break;
                }
                if (!framed) throw new InvalidOperationException("No clear full-body diagnostic camera fit in the bounded oblique views.");
                camera.Render(); RenderTexture.active = target;
                pixels = new Texture2D(900, 1100, TextureFormat.RGB24, false);
                pixels.ReadPixels(new Rect(0, 0, 900, 1100), 0, 0); pixels.Apply(false, false);
                string path = Path.Combine(c.Output, "diagnostic-portrait-" + index.ToString("00") + ".png"); Inside(c.Output, path);
                File.WriteAllBytes(path, pixels.EncodeToPNG());
                c.DiagnosticCaptures.Add(new { path, frame = Time.frameCount, proofElapsed = elapsed, actor = actor.Status(),
                    approvedNativeSha256 = actor.approvedNativeSha256, visualPayloadSha256 = actor.visualPayloadSha256,
                    sourceCamera = source.name, diagnosticCameraPosition = V(camera.transform.position), diagnosticCameraRotation = V(camera.transform.eulerAngles),
                    chosenObliqueAngleDegrees = chosenAngle, actualVisualBoundsCenter = V(bounds.center), actualVisualBoundsSize = V(bounds.size),
                    ownRenderers = own.Select(r => new { r.name, material = r.sharedMaterial.name, shader = r.sharedMaterial.shader.name }).ToArray(),
                    classification = "Actual live-game diagnostic scene-camera portrait, not the normal player camera",
                    changes = "Temporary camera/RenderTexture only; no player/main-camera move, pose, AI, renderer, light or material edits. Camera component settings copied; camera-attached postprocessing components are not duplicated." });
                Step(c, "actual live-game diagnostic portrait saved", new { path, elapsed, chosenAngle });
            }
            catch (Exception ex) { c.DiagnosticErrors.Add(ex.ToString()); Step(c, "diagnostic portrait failed", ex.Message); }
            finally
            {
                RenderTexture.active = previous;
                if (host) { var camera = host.GetComponent<Camera>(); if (camera) camera.targetTexture = null; UnityEngine.Object.Destroy(host); }
                if (pixels) UnityEngine.Object.Destroy(pixels);
                if (target) { target.Release(); UnityEngine.Object.Destroy(target); }
            }
        }
        static void Finish(Context c)
        {
            var files = Directory.GetFiles(c.Output, "actual-game-*.png").Select(p => new { path = p, bytes = new FileInfo(p).Length, sha256 = Hash(p) }).ToArray();
            var diagnostics = Directory.GetFiles(c.Output, "diagnostic-*.png").Select(p => new { path = p, bytes = new FileInfo(p).Length, sha256 = Hash(p) }).ToArray();
            bool captureWritten = !c.Capture || (c.Captures.Count > 0 && files.Length == c.Captures.Count && files.All(f => CaptureComplete(f.path)));
            bool diagnosticWritten = !c.Capture || (diagnostics.Length > 0 && diagnostics.All(f => CaptureComplete(f.path)));
            var result = new { schema = "hushed-monk.opted-in-private-game-autotest.v1", id = c.Id, utc = DateTime.UtcNow.ToString("o"),
                passed = c.Completed && c.Passed && captureWritten && diagnosticWritten, proofCompleted = c.Completed, proofPassed = c.Passed,
                capturesOptedIn = c.Capture, capturesWritten = captureWritten, saveRoot = c.SaveRoot, profile = c.ProfileName, world = c.WorldName,
                skipNewProfileIntroOptedIn = c.SkipIntro, diagnosticPortraitsWritten = diagnosticWritten,
                sourceNativeSha256 = "3e0b6a9e3fa25056b4d6c522317f208e9657c3a10dd8fdd3728474e4ee02de0e",
                pluginSha256 = Hash(typeof(HushedMonkAutoTest).Assembly.Location), unityVersion = Application.unityVersion,
                seconds = Time.realtimeSinceStartup - c.Started, frames = Time.frameCount - c.StartFrame, steps = c.Steps,
                requestedCaptures = c.Captures, actualCaptureFiles = files, diagnosticCaptures = c.DiagnosticCaptures,
                actualDiagnosticCaptureFiles = diagnostics, diagnosticCaptureErrors = c.DiagnosticErrors,
                limits = new[] { "Opted-in newly created local test character/world only; no existing/default saves loaded.",
                    "Game API startup and actual game camera captures; no GUI/pointer automation or OS screenshot workaround.",
                "Optional intro flag affects only the new private profile. Explicit dungeon flag moves only that new fenced profile to the exact authored R04. No existing profiles, health/buff, persisted settings, forced AI target/move/attack or animator changes.",
                    "Diagnostic portraits use a temporary oblique camera rendering the actual scene; normal main-camera screenshots remain separately labelled and unchanged.",
                    "A failed natural attack remains failed; screenshots require direct review and do not create appearance approval.",
                    "Skeleton Rise remains avoided, not repaired. Multiplayer, corpse physics and final balance remain outside this test." } };
            string path = Path.Combine(c.Output, "autotest-result.json");
            File.WriteAllText(path, JsonConvert.SerializeObject(result, Formatting.Indented));
            c.Log?.Invoke("HM_AUTOTEST_RESULT " + (result.passed ? "PASS" : "FAIL") + " path=" + path);
        }
    }
}
