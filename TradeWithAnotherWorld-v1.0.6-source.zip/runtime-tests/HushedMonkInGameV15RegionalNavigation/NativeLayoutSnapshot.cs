using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using UnityEngine;

namespace BlackAbbey.HushedMonk
{
    // Actual loaded source-prefab evidence, without instantiating a character.
    internal static class NativeLayoutSnapshot
    {
        static string Path(Transform root, Transform transform)
        {
            if (!transform) return null;
            if (transform == root) return ".";
            var names = new List<string>();
            while (transform && transform != root) { names.Add(transform.name); transform = transform.parent; }
            names.Reverse(); return string.Join("/", names);
        }
        internal static void Save(GameObject source, string directory, Action<string> log)
        {
            var root = source.transform;
            var data = new {
                schema = "hushed-monk.actual-game-native-layout.v1", utc = DateTime.UtcNow,
                unityVersion = Application.unityVersion, prefab = source.name,
                gameAssembly = new { path = typeof(Character).Assembly.Location, sha256 = VisualRuntime.Hash(typeof(Character).Assembly.Location) },
                components = source.GetComponentsInChildren<Component>(true).Where(c => c && !(c is Transform)).Select(c => new { path = Path(root, c.transform), type = c.GetType().FullName }).ToArray(),
                outerVisualScripts = source.transform.Find("Visual").GetComponents<MonoBehaviour>().Where(c => c).Select(c => new { type = c.GetType().FullName, serializedDefinition = JsonUtility.ToJson(c) }).ToArray(),
                animators = source.GetComponentsInChildren<Animator>(true).Select(a => new { path = Path(root, a.transform), controller = a.runtimeAnimatorController ? a.runtimeAnimatorController.name : null, avatar = a.avatar ? a.avatar.name : null }).ToArray(),
                events = source.GetComponentsInChildren<CharacterAnimEvent>(true).Select(e => new { path = Path(root, e.transform), feet = e.m_feets?.Select(f => Path(root, f.m_transform)).ToArray(), lookAt = Path(root, e.m_lookAt), leftShoulder = Path(root, e.m_leftShoulder), rightShoulder = Path(root, e.m_rightShoulder) }).ToArray(),
                footsteps = source.GetComponentsInChildren<FootStep>(true).Select(f => new { path = Path(root, f.transform), feet = f.m_feet?.Select(t => Path(root, t)).ToArray() }).ToArray(),
                sourceActiveInHierarchy = source.activeInHierarchy,
                scope = "Read-only actual loaded native prefab before own clone visual migration; no character spawned by this inspection."
            };
            Directory.CreateDirectory(directory); File.WriteAllText(System.IO.Path.Combine(directory, "native-skeleton-layout.json"), JsonConvert.SerializeObject(data, Formatting.Indented));
            log?.Invoke("HM_NATIVE_LAYOUT " + JsonConvert.SerializeObject(new { data.animators, data.events, data.footsteps }));
        }
    }
}
