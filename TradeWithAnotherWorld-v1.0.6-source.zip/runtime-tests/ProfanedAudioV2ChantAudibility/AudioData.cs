using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Newtonsoft.Json;

namespace BlackAbbey.ProfanedAudio
{
    [Serializable] public sealed class AudioManifest { public string schema;public int sampleRate,channels,sampleBytes;public AudioCue[] clips; }
    [Serializable] public sealed class AudioCue { public string id,path,sha256,family;public int frames;public bool loop;public float gain; }
    public static class AudioData
    {
        public static readonly string[] Required={"voice_idle","voice_combat","voice_prayer","voice_alert","voice_punch","hurt_light","hurt_heavy","death","punch_air","punch_hit","sweep_warning","sweep_release","cloud_body","ember_warning","ember_release","ember_flight","ember_hit","censer_coals","chain_light","chain_heavy","cloth","chant"};
        static readonly string[] Loops={"voice_idle","voice_combat","cloud_body","ember_flight","censer_coals","chant"};
        public static string Hash(byte[] bytes){using(var s=SHA256.Create())return string.Concat(s.ComputeHash(bytes).Select(b=>b.ToString("x2")));}
        public static AudioManifest Read(string folder,string expectedHash)
        {
            string path=Path.Combine(folder,"audio-manifest.json");var raw=File.ReadAllBytes(path);
            if(raw.Length>65536||Hash(raw)!=expectedHash)throw new InvalidDataException("Profaned audio manifest differs from selected bank");
            var m=JsonConvert.DeserializeObject<AudioManifest>(System.Text.Encoding.UTF8.GetString(raw),new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MaxDepth=16});
            if(m?.schema!="profaned.audio.runtime.v1"||m.sampleRate!=48000||m.channels!=1||m.sampleBytes!=2||m.clips?.Length!=Required.Length)throw new InvalidDataException("Wrong audio bank contract");
            var seen=new HashSet<string>();
            foreach(var c in m.clips){
                if(c==null||!Required.Contains(c.id)||!seen.Add(c.id)||c.path!="clips/"+c.id+".wav"||c.sha256?.Length!=64||!c.sha256.All(Uri.IsHexDigit)||c.frames<=0||c.frames>48000*60||float.IsNaN(c.gain)||float.IsInfinity(c.gain)||c.gain<0||c.gain>1||c.loop!=Loops.Contains(c.id))throw new InvalidDataException("Invalid selected cue");
            }
            return m;
        }
        static bool Tag(byte[] b,int p,string tag){if(p<0||p+tag.Length>b.Length)return false;for(int i=0;i<tag.Length;i++)if(b[p+i]!=tag[i])return false;return true;}
        static uint U32(byte[] b,int p)=>(uint)(b[p]|b[p+1]<<8|b[p+2]<<16|b[p+3]<<24);
        static int U16(byte[] b,int p)=>b[p]|b[p+1]<<8;
        public static float[] Decode(byte[] b,int frames)
        {
            if(b==null||b.Length<44||b.Length>6*1024*1024||!Tag(b,0,"RIFF")||!Tag(b,8,"WAVE")||U32(b,4)+8L!=b.Length)throw new InvalidDataException("Invalid WAV envelope");
            bool format=false,data=false;int start=0;
            for(long at=12;at<b.Length;){
                if(at+8>b.Length)throw new InvalidDataException("Truncated chunk");int p=(int)at;uint n=U32(b,p+4);long end=at+8+n+(n&1);
                if(end>b.Length)throw new InvalidDataException("WAV chunk outside envelope");
                if(Tag(b,p,"fmt ")){if(format||(n!=16&&n!=18)||U16(b,p+8)!=1||U16(b,p+10)!=1||U32(b,p+12)!=48000||U32(b,p+16)!=96000||U16(b,p+20)!=2||U16(b,p+22)!=16)throw new InvalidDataException("Requires mono48k PCM16");format=true;}
                if(Tag(b,p,"data")){if(data||n==0||n%2!=0||n/2!=frames)throw new InvalidDataException("Wrong PCM frame count");data=true;start=p+8;}
                at=end;
            }
            if(!format||!data)throw new InvalidDataException("Missing WAV chunks");
            var samples=new float[frames];double energy=0;
            for(int i=0;i<frames;i++){short v=(short)U16(b,start+2*i);if(v==short.MinValue)throw new InvalidDataException("Clipped PCM");samples[i]=v/32768f;energy+=samples[i]*samples[i];}
            if(energy<1e-10)throw new InvalidDataException("Silent selected cue");return samples;
        }
    }
    // Observes replicated attack phases; it never changes a gameplay clock.
    public sealed class AudioTimeline
    {
        readonly struct Event { public readonly float at;public readonly string cue;public Event(float a,string c){at=a;cue=c;} }
        static readonly Event[][] Events={Array.Empty<Event>(),new[]{new Event(.32f,"voice_punch"),new Event(.48f,"punch_air")},new[]{new Event(.10f,"sweep_warning"),new Event(.32f,"chain_heavy")},new[]{new Event(.10f,"ember_warning"),new Event(.38f,"chain_heavy")}};
        long token=long.MinValue;int action;float previous;
        public void Poll(int kind,long start,float age,Action<string> emit)
        {
            if(kind<1||kind>3||age<0||float.IsNaN(age)||float.IsInfinity(age)){action=0;return;}
            if(start!=token||kind!=action){token=start;action=kind;previous=age<=.25f?-.001f:Math.Max(0,age-.10f);}
            if(age<previous){previous=age;return;}
            foreach(var e in Events[kind])if(e.at>previous&&e.at<=age&&age-e.at<=.20f)emit(e.cue);
            previous=age;
        }
    }
}
