namespace BlackAbbey.ProfanedAudio
{
    public static class AudioMixPolicy
    {
        // A latched alert does not mean an attack is occurring. Keep the chant
        // present whenever the nearby actor is not speaking another voice cue.
        public static float ChantFactor(bool nearby,bool attacking,bool speaking)
            =>nearby?(attacking?.60f:1f)*(speaking?.35f:1f):0;
        public const int ChantPriority=130;
        // Jesse removed the light walking-chain jingle. Preserve its recording
        // in the selected bank/archive without allowing runtime playback.
        public static bool AllowsCue(string id)=>id!="chain_light";
    }
}
