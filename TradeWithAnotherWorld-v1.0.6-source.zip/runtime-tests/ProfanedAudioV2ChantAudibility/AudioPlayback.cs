using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Audio;
using Object=UnityEngine.Object;

namespace BlackAbbey.ProfanedAudio
{
    public sealed class ProfanedAudioBank:IDisposable
    {
        public sealed class Loaded { public AudioCue cue;public AudioClip clip; }
        public readonly Dictionary<string,Loaded> Clips=new Dictionary<string,Loaded>();
        public long pcmBytes,decodedFrames;public bool Ready;
        public void Load(string folder,string expectedHash)
        {
            if(Ready)throw new InvalidOperationException("Bank already loaded");
            try{foreach(var c in AudioData.Read(folder,expectedHash).clips){
                string path=Path.Combine(folder,c.path);
                if((File.GetAttributes(path)&FileAttributes.ReparsePoint)!=0)throw new InvalidDataException("Linked audio input rejected");
                var raw=File.ReadAllBytes(path);pcmBytes+=raw.Length;
                if(pcmBytes>16*1024*1024||AudioData.Hash(raw)!=c.sha256)throw new InvalidDataException("Selected sound hash/budget mismatch: "+c.id);
                var data=AudioData.Decode(raw,c.frames);var clip=AudioClip.Create("Profaned | "+c.id,c.frames,1,48000,false);
                if(!clip||!clip.SetData(data,0)){if(clip)Object.Destroy(clip);throw new InvalidDataException("AudioClip upload failed");}
                Clips.Add(c.id,new Loaded{cue=c,clip=clip});decodedFrames+=c.frames;
            }Ready=true;}catch{Dispose();throw;}
        }
        public void Dispose(){Ready=false;foreach(var c in Clips.Values)if(c.clip){if(Application.isPlaying)Object.Destroy(c.clip);else Object.DestroyImmediate(c.clip);}Clips.Clear();}
    }
    public static class ProfanedAudioSource
    {
        public static AudioSource Create(Transform parent,string name,AudioMixerGroup mixer,int priority=140)
        {
            var node=new GameObject(name);node.transform.SetParent(parent,false);var s=node.AddComponent<AudioSource>();
            s.playOnAwake=false;s.spatialBlend=1;s.dopplerLevel=0;s.spread=0;s.minDistance=2.2f;s.maxDistance=24;
            s.rolloffMode=AudioRolloffMode.Logarithmic;s.outputAudioMixerGroup=mixer;s.priority=priority;s.volume=0;return s;
        }
    }
    // Persistent, bounded sources own impact/death tails after an actor disappears.
    public sealed class ProfanedOneShotPool:MonoBehaviour
    {
        readonly List<AudioSource> sources=new List<AudioSource>();readonly List<float> until=new List<float>();
        ProfanedAudioBank bank;AudioMixerGroup mixer;
        public int Played {get;private set;}
        public void Bind(ProfanedAudioBank b,AudioMixerGroup m){bank=b;mixer=m;}
        public void Play(string cue,Vector3 at,float master,float gain=1,int priority=120)
        {
            if(bank==null||!bank.Ready||!bank.Clips.TryGetValue(cue,out var c))return;
            int slot=-1;for(int i=0;i<sources.Count;i++)if(!sources[i].isPlaying){slot=i;break;}
            if(slot<0&&sources.Count<24){slot=sources.Count;sources.Add(ProfanedAudioSource.Create(transform,"Profaned event "+slot,mixer));until.Add(0);}
            if(slot<0){slot=0;for(int i=1;i<until.Count;i++)if(until[i]<until[slot])slot=i;}
            var s=sources[slot];s.Stop();s.transform.position=at;s.outputAudioMixerGroup=mixer;s.clip=c.clip;s.loop=false;s.pitch=1;
            s.volume=Mathf.Clamp01(c.cue.gain*master*gain);s.priority=priority;s.Play();until[slot]=Time.time+c.clip.length;Played++;
        }
        public void StopAll(){foreach(var s in sources)if(s)s.Stop();}
        public int SourceCount=>sources.Count;
    }
}
