using System;
using System.Collections.Generic;
using UnityEngine;

namespace BlackAbbey.CenserBrother
{
    public sealed class CenserAI:BaseAI
    {
        Character target;CenserInstance own;CenserDungeonNavigation navigation;
        Vector3 home,patrolGoal,lastGoal,lastFist;List<Vector3> corners;int spacing,routeRevision;
        readonly CenserRouteFollower follower=new CenserRouteFollower();
        float senseAt,seenAt,planAt,patrolAt,punchReady,sweepReady,emberReady,attackTime;bool released,punchHit,retaliating;CenserAction action;
        public string MotionIntent="idle";
        public Character Target=>target;
        public CenserAction Action=>action;
        public override Character GetTargetCreature()=>target;
        protected override void Awake(){base.Awake();own=GetComponent<CenserInstance>();home=transform.position;patrolGoal=home;navigation=CenserDungeonNavigation.Attach(gameObject);}
        protected override void OnDamaged(float damage,Character attacker){base.OnDamaged(damage,attacker);if(attacker is Player p&&!p.IsDead()&&!p.InGhostMode()&&!p.m_aiSkipTarget){target=attacker;retaliating=true;seenAt=Time.time;SetAlerted(true);}}
        bool PassiveWorld=>ZoneSystem.instance&&ZoneSystem.instance.GetGlobalKey(GlobalKeys.PassiveMobs);
        void ClearTarget(){target=null;retaliating=false;spacing=0;corners=null;planAt=0;patrolAt=0;CancelAttack();SetAlerted(false);}
        public override bool UpdateAI(float dt)
        {
            if(!base.UpdateAI(dt))return false;
            if(!own||m_character.IsDead())return true;
            // Recheck before a committed attack, including a live modifier change.
            if(target&&!CenserPolicy.MayKeepTarget(PassiveWorld,retaliating))ClearTarget();
            if(!m_character.CanMove()||m_character.IsStaggering()){Halt(dt);CancelAttack();return true;}
            float now=Time.time;if(now>=senseAt){senseAt=now+.30f;Sense(now);}bool combat=target&&!target.IsDead();
            m_character.SetRun(false);m_character.SetWalk(true);m_character.m_walkSpeed=combat?CenserPlugin.Settings.CombatWalk.Value:CenserPlugin.Settings.Walk.Value;
            if(action!=CenserAction.None){Halt(dt);Attack(dt);return true;}
            if(!combat){Patrol(now,dt);return true;}
            Vector3 delta=Vector3.ProjectOnPlane(target.transform.position-transform.position,Vector3.up);float distance=delta.magnitude;bool sight=Sight(m_character.GetCenterPoint(),target.GetCenterPoint());
            LookTowards(delta);
            var selected=CenserPolicy.Choose(distance,sight,punchReady,sweepReady,emberReady,now);
            if(selected!=CenserAction.None&&IsLookingTowards(delta,25f)){Begin(selected);return true;}
            float range=target is Humanoid h?h.GetCurrentWeapon()?.m_shared?.m_attack?.m_attackRange??2.3f:2.3f;float preferred=CenserPolicy.PreferredGap(range);int desired=sight?CenserPolicy.Spacing(distance,preferred,spacing):1;
            if(desired==0){spacing=0;MotionIntent="hold";Halt(dt);return true;}
            if(now>=planAt||desired!=spacing||routeRevision!=navigation.Revision){
                planAt=now+.60f;spacing=desired;Vector3 goal;
                if(!sight){goal=target.transform.position;MotionIntent="seek";Plan(goal,.55f);}
                else if(desired>0){goal=target.transform.position-delta.normalized*preferred;MotionIntent="approach";Plan(goal,.28f);}
                else{
                    MotionIntent="give-space";bool found=false;
                    // Hold a chosen route between plans instead of changing left/right every frame.
                    foreach(float angle in new[]{0f,50f,-50f,88f,-88f}){goal=transform.position+(Quaternion.AngleAxis(angle,Vector3.up)*-delta.normalized)*1.65f;if(Plan(goal,.23f)){found=true;break;}}
                    if(!found){corners=null;MotionIntent="cornered";}
                }
            }
            Follow(dt,.25f,delta);return true;
        }
        void Sense(float now)
        {
            if(target&&(target.IsDead()||target.InGhostMode()||(target is Player player&&player.m_aiSkipTarget)||(target.transform.position-transform.position).sqrMagnitude>900))ClearTarget();
            if(!target&&retaliating)ClearTarget();
            if(target){if(Sight(m_character.GetCenterPoint(),target.GetCenterPoint()))seenAt=now;else if(now-seenAt>8)ClearTarget();}
            if(!target){float best=18*18;foreach(var p in Player.GetAllPlayers()){
                if(!p||p.IsDead()||p.InGhostMode()||p.m_aiSkipTarget)continue;
                float d=(p.transform.position-transform.position).sqrMagnitude;
                // Explicit false prevents a prefab's passiveAggresive flag from
                // bypassing the world's PassiveMobs modifier during acquisition.
                if(d<best&&CenserPolicy.MayAcquire(PassiveWorld,CanSenseTarget(p,false))&&Sight(m_character.GetCenterPoint(),p.GetCenterPoint())){best=d;target=p;retaliating=false;seenAt=now;}
            }}
            SetAlerted(target!=null);
        }
        void Patrol(float now,float dt)
        {
            if(now>=patrolAt){patrolAt=now+UnityEngine.Random.Range(7f,11f);Vector2 v=UnityEngine.Random.insideUnitCircle*2.5f;patrolGoal=home+new Vector3(v.x,0,v.y);Plan(patrolGoal,.35f);MotionIntent="patrol";}
            if(navigation&&navigation.Ready&&navigation.Revision!=routeRevision)Plan(patrolGoal,.35f);
            Follow(dt,.35f,null);
        }
        bool Plan(Vector3 goal,float stop)
        {
            corners=null;
            if(!navigation||!navigation.Ready)return false;
            if(!Physics.Raycast(goal+Vector3.up*.65f,Vector3.down,out var floor,1.6f,SolidMask,QueryTriggerInteraction.Ignore)||floor.normal.y<.7f)return false;goal.y=floor.point.y+.03f;
            if(!navigation.TryProbePath(transform.position,goal,out var route))return false;
            corners=route;lastGoal=goal;follower.Corner=1;routeRevision=navigation.Revision;return true;
        }
        void Halt(float dt){var input=follower.Smooth(Vector3.zero,dt);m_character.SetMoveDir(input);m_character.SetRun(false);m_character.SetWalk(true);}
        void Follow(float dt,float stop,Vector3? face)
        {
            if(!navigation||!navigation.Ready){corners=null;Halt(dt);return;}
            if(corners!=null&&follower.Corner+1<corners.Count&&navigation.Straight(transform.position,corners[follower.Corner+1]))follower.Corner++;
            Vector3 input=follower.Follow(corners,transform.position,stop,dt);
            if(input.sqrMagnitude>.002f){
                var cap=GetComponent<CapsuleCollider>();Vector3 center=transform.TransformPoint(cap.center);float radius=cap.radius*Mathf.Max(transform.lossyScale.x,transform.lossyScale.z);float extent=cap.height*transform.lossyScale.y*.5f-radius-.04f;
                if(Physics.CapsuleCast(center+Vector3.up*extent,center-Vector3.up*extent,radius*.96f,input.normalized,out var wall,.30f,SolidMask,QueryTriggerInteraction.Ignore)){input=Vector3.ProjectOnPlane(input,wall.normal);if(Vector3.Dot(input,follower.Input)<0)input=Vector3.zero;}
                Vector3 ahead=transform.position+input.normalized*.42f;if(!Physics.Raycast(ahead+Vector3.up*.45f,Vector3.down,1.0f,SolidMask,QueryTriggerInteraction.Ignore))input=Vector3.zero;
            }
            m_character.SetMoveDir(input);m_character.SetRun(false);m_character.SetWalk(true);
            if(face.HasValue){LookTowards(face.Value);float sideways=Mathf.Abs(Vector3.Dot(input,transform.right));float backward=-Vector3.Dot(input,transform.forward);if(sideways>.55f)m_character.m_walkSpeed=Mathf.Min(m_character.m_walkSpeed,.65f);else if(backward>.5f)m_character.m_walkSpeed=Mathf.Min(m_character.m_walkSpeed,.85f);}
            else if(input.sqrMagnitude>.01f)LookTowards(input);
        }
        public string NavigationStatus()=>"intent="+MotionIntent+" passiveWorld="+PassiveWorld+" retaliating="+retaliating+" "+(navigation?navigation.Status():"no navigation");
        void Begin(CenserAction a){StopMoving();action=a;attackTime=0;released=false;punchHit=false;lastFist=own.RightFist?own.RightFist.position:transform.position;own.StartAction(a);float now=Time.time;if(a==CenserAction.Punch)punchReady=now+2.7f;if(a==CenserAction.Sweep)sweepReady=now+9f;if(a==CenserAction.Ember)emberReady=now+5.5f;}
        void CancelAttack(){if(action==CenserAction.None)return;action=CenserAction.None;own?.StopAction();}
        void Attack(float dt)
        {
            attackTime=own.ActionSeconds;
            if(action==CenserAction.Punch){if(!punchHit&&CenserPolicy.IsPunchTime(attackTime))punchHit=Punch();if(own.RightFist)lastFist=own.RightFist.position;}
            if(!released&&attackTime>=CenserPolicy.Release(action)){
                released=true;if(action==CenserAction.Ember)Ember();else if(action==CenserAction.Sweep)own.PublishSweep();
            }
            if(attackTime>=CenserPolicy.Duration(action)){action=CenserAction.None;own.StopAction();}
        }
        bool Punch()
        {
            if(!target||target.IsDead())return false;
            var fist=own.RightFist;if(!fist)return false;Vector3 center=target.GetCenterPoint();var collider=target.GetComponent<Collider>();Vector3 point=collider?collider.ClosestPoint(fist.position):center;
            float distance=Vector3.ProjectOnPlane(target.transform.position-transform.position,Vector3.up).magnitude;
            float dot=Vector3.Dot(transform.forward,(target.transform.position-transform.position).normalized);
            Vector3 segment=fist.position-lastFist;float u=segment.sqrMagnitude>.000001f?Mathf.Clamp01(Vector3.Dot(point-lastFist,segment)/segment.sqrMagnitude):1;float contact=Vector3.Distance(point,lastFist+segment*u);lastFist=fist.position;
            if(!CenserPolicy.CanPunch(contact,distance,dot,Sight(fist.position,point)))return false;
            var hit=new HitData{m_point=point,m_dir=(center-m_character.GetCenterPoint()).normalized,m_pushForce=3f,m_dodgeable=true,m_blockable=true,m_hitType=HitData.HitType.EnemyHit};hit.m_damage.m_blunt=CenserPlugin.Settings.Punch.Value;hit.SetAttacker(m_character);target.Damage(hit);return true;
        }
        void Ember()
        {
            if(!target||target.IsDead()||!own.EmberSocket||!CenserPlugin.EmberPrefab)return;
            Vector3 at=own.EmberSocket.position;Vector3 aim=target.GetCenterPoint()+target.GetVelocity()*.18f;
            if(!Sight(at,aim))return;
            Vector3 dir=(aim-at).normalized;var go=UnityEngine.Object.Instantiate(CenserPlugin.EmberPrefab,at+dir*.12f,Quaternion.LookRotation(dir));go.SetActive(true);
            var hit=new HitData{m_point=aim,m_dir=dir,m_pushForce=2f,m_dodgeable=true,m_blockable=true,m_hitType=HitData.HitType.EnemyHit};hit.m_damage.m_blunt=CenserPlugin.Settings.EmberImpact.Value;hit.m_damage.m_fire=CenserPlugin.Settings.EmberFire.Value;hit.SetAttacker(m_character);
            go.GetComponent<Projectile>().Setup(m_character,dir*11f+Vector3.up*.25f,15f,hit,null,null);
        }
        public static int SolidMask=>LayerMask.GetMask("Default","static_solid","Default_small","piece","terrain","vehicle");
        public static bool Sight(Vector3 from,Vector3 to)=>!Physics.Linecast(from,to,SolidMask,QueryTriggerInteraction.Ignore);
    }
}
