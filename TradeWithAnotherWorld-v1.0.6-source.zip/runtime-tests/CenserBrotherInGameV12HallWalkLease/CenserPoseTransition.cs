using UnityEngine;

namespace BlackAbbey.CenserBrother
{
    // Inertialize a moving destination clip. The outgoing displayed pose and
    // velocity decay smoothly while the new clip keeps advancing underneath.
    public sealed class CenserPoseTransition
    {
        readonly Vector3[] positionOffset,positionVelocity,rotationOffset,rotationVelocity;
        float age,duration;
        public CenserPoseTransition(int count)
        {positionOffset=new Vector3[count];positionVelocity=new Vector3[count];rotationOffset=new Vector3[count];rotationVelocity=new Vector3[count];}
        public void Begin(float seconds){age=0;duration=Mathf.Max(.01f,seconds);}
        public void Clear(){age=1;duration=0;}
        public void Advance(float dt){age+=Mathf.Max(0,dt);}
        public void Capture(int i,Vector3 current,Quaternion currentRotation,Vector3 velocity,Vector3 angularVelocity,
            Vector3 target,Quaternion targetRotation,Vector3 targetVelocity,Vector3 targetAngularVelocity)
        {
            positionOffset[i]=current-target;
            positionVelocity[i]=Vector3.ClampMagnitude(velocity-targetVelocity,1.5f);
            rotationOffset[i]=Log(currentRotation*Quaternion.Inverse(targetRotation));
            rotationVelocity[i]=Vector3.ClampMagnitude(angularVelocity-targetAngularVelocity,540f);
        }
        public void Apply(int i,ref Vector3 position,ref Quaternion rotation)
        {
            if(duration<=0||age>=duration)return;
            float u=Mathf.Clamp01(age/duration),u2=u*u,u3=u2*u,u4=u3*u,u5=u4*u;
            float h=1-10*u3+15*u4-6*u5,v=u-6*u3+8*u4-3*u5;
            position+=positionOffset[i]*h+positionVelocity[i]*(duration*v);
            rotation=Exp(rotationOffset[i]*h+rotationVelocity[i]*(duration*v))*rotation;
        }
        public static Vector3 Log(Quaternion q)
        {
            q=q.normalized;if(q.w<0)q=new Quaternion(-q.x,-q.y,-q.z,-q.w);
            q.ToAngleAxis(out float angle,out Vector3 axis);
            return angle<.00001f||!float.IsFinite(axis.x)?Vector3.zero:axis*Mathf.DeltaAngle(0,angle);
        }
        public static Quaternion Exp(Vector3 v)=>v.sqrMagnitude<.000000001f?Quaternion.identity:Quaternion.AngleAxis(v.magnitude,v.normalized);
    }
}
