using UnityEngine;
namespace BlackAbbey.CenserBrother
{
    // Pure, bounded accessory physics. The top ring is outside this transform;
    // all skin weights below its hanger follow this same chain/bowl direction.
    public sealed class CenserPendulum
    {
        public Vector3 Direction=Vector3.down,Velocity;
        public void Reset(){Direction=Vector3.down;Velocity=Vector3.zero;}
        public Vector3 Step(float dt,Vector3 anchorAcceleration)
        {
            dt=Mathf.Clamp(dt,0,.05f);var accel=Vector3.ClampMagnitude(anchorAcceleration,18);
            var force=Vector3.ProjectOnPlane(Vector3.down*18-accel*1.1f,Direction);
            Velocity+=(force-Velocity*2.2f)*dt;Direction=(Direction+Velocity*dt).normalized;Velocity=Vector3.ProjectOnPlane(Velocity,Direction);
            if(Vector3.Angle(Direction,Vector3.down)>65){Direction=Vector3.RotateTowards(Vector3.down,Direction,65*Mathf.Deg2Rad,0);Velocity=Vector3.ProjectOnPlane(Velocity,Direction);}
            return Direction;
        }
        public void FollowAuthored(Vector3 direction,float dt){Direction=Vector3.Slerp(Direction,direction,Mathf.Clamp01(dt*10));}
    }
}
