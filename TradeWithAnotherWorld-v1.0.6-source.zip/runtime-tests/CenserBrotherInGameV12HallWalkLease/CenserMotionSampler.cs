using UnityEngine;
namespace BlackAbbey.CenserBrother
{
    // Shared by the visible runtime driver and the offline Unity verification.
    public static class CenserMotionSampler
    {
        public static void Sample(MotionClip clip,float normalized,int i,out Vector3 position,out Quaternion rotation)
        {
            normalized=clip.loop?Mathf.Repeat(normalized,1):Mathf.Clamp01(normalized);
            float f=normalized*(clip.frames.Length-1);int a=Mathf.FloorToInt(f),b=Mathf.Min(a+1,clip.frames.Length-1);float t=f-a;
            var x=clip.frames[a];var y=clip.frames[b];int p=i*3,q=i*4;
            position=Vector3.Lerp(new Vector3(x.positions[p],x.positions[p+1],x.positions[p+2]),new Vector3(y.positions[p],y.positions[p+1],y.positions[p+2]),t);
            rotation=Quaternion.Slerp(new Quaternion(x.rotations[q],x.rotations[q+1],x.rotations[q+2],x.rotations[q+3]),new Quaternion(y.rotations[q],y.rotations[q+1],y.rotations[q+2],y.rotations[q+3]),t);
        }
    }
}
