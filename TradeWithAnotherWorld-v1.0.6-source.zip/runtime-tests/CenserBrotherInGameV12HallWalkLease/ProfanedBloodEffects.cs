using System;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbey.CenserBrother
{
    // Own visual-only effect: no audio cue, native creature prefab or game patch.
    public static class ProfanedBloodParticles
    {
        static Material material;
        static GameObject template;
        public static GameObject BuildPrefab(Transform inactiveContainer)
        {
            if(!inactiveContainer||inactiveContainer.gameObject.activeInHierarchy)
                throw new InvalidOperationException("Blood template requires inactive prefab container");
            if(!CenserParticleFactory.SmokeMaterial)
                throw new InvalidOperationException("Supported particle material required");
            material=new Material(CenserParticleFactory.SmokeMaterial){name="Profaned_Red_Blood"};
            material.DisableKeyword("_EMISSION");
            if(material.HasProperty("_EmissionColor"))material.SetColor("_EmissionColor",Color.black);
            template=new GameObject("BA_Profaned_RedBlood_Hit");template.SetActive(false);
            template.transform.SetParent(inactiveContainer,false);
            Droplets(template.transform,"Red droplets",28,.045f,.64f,new Color(.58f,.012f,.020f,1),1.6f);
            Droplets(template.transform,"Red fine spray",10,.10f,.26f,new Color(.42f,.008f,.014f,.62f),.40f);
            template.AddComponent<ProfanedBloodImpact>();template.SetActive(true);
            return template;
        }
        static void Droplets(Transform root,string name,int count,float size,float lifetime,Color color,float speed)
        {
            var ps=CenserParticleFactory.Smoke(root,name,count,0,lifetime,size,color,.025f);
            ps.Stop(false,ParticleSystemStopBehavior.StopEmittingAndClear);
            var main=ps.main;main.loop=false;main.playOnAwake=false;main.duration=.05f;
            main.startLifetime=new ParticleSystem.MinMaxCurve(lifetime*.65f,lifetime);
            main.startSpeed=new ParticleSystem.MinMaxCurve(speed*.35f,speed);
            main.gravityModifier=speed>.5f?.8f:.16f;
            var velocity=ps.velocityOverLifetime;velocity.enabled=false;
            var noise=ps.noise;noise.enabled=false;
            var scale=ps.sizeOverLifetime;scale.enabled=true;
            scale.size=new ParticleSystem.MinMaxCurve(1,AnimationCurve.Linear(0,1,1,.45f));
            var fade=ps.colorOverLifetime;var gradient=new Gradient();
            gradient.SetKeys(new[]{new GradientColorKey(Color.white,0),new GradientColorKey(Color.white,1)},
                new[]{new GradientAlphaKey(1,0),new GradientAlphaKey(.9f,.6f),new GradientAlphaKey(0,1)});
            fade.color=gradient;
            ps.GetComponent<ParticleSystemRenderer>().sharedMaterial=material;
        }
        public static void Shutdown()
        {
            if(template){if(Application.isPlaying)Object.Destroy(template);else Object.DestroyImmediate(template);}
            if(material){if(Application.isPlaying)Object.Destroy(material);else Object.DestroyImmediate(material);}
            template=null;material=null;
        }
    }
    public sealed class ProfanedBloodImpact:MonoBehaviour
    {
        void Start()
        {
            foreach(var ps in GetComponentsInChildren<ParticleSystem>()){
                ps.Play(false);ps.Emit(ps.main.maxParticles);
            }
            Destroy(gameObject,1.1f);
        }
    }
}
