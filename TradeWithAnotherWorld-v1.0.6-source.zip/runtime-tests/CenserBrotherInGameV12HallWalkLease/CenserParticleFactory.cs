using System;
using UnityEngine;
using UnityEngine.Rendering;
using Object=UnityEngine.Object;

namespace BlackAbbey.CenserBrother
{
    // Shared verbatim by the runtime and the offline rendered visibility check.
    // Preserve the native smoke texture and shader together as a matched pair.
    public static class CenserParticleFactory
    {
        public static Material SmokeMaterial,EmberMaterial,CoalMaterial;
        public static string SourceShader,SourceTexture;static Texture2D softMask;
        public static void Initialize(Material smoke,Shader solidShader)
        {
            if(!smoke||!smoke.shader||!smoke.shader.isSupported)throw new InvalidOperationException("Supported native smoke material required");
            SourceShader=smoke.shader.name;SourceTexture=smoke.mainTexture?smoke.mainTexture.name:"Native procedural smoke (no MainTex)";
            SmokeMaterial=new Material(smoke){name="CB2_Visible_Incense"};
            foreach(string prop in new[]{"_TintColor","_Color"})if(SmokeMaterial.HasProperty(prop))SmokeMaterial.SetColor(prop,Color.white);
            // The native surface particle material defaults to opaque mesh puffs.
            // Explicit standard alpha blending makes a readable, fading cloud edge.
            if(SmokeMaterial.HasProperty("_Mode"))SmokeMaterial.SetFloat("_Mode",2);
            if(SmokeMaterial.HasProperty("_SrcBlend"))SmokeMaterial.SetFloat("_SrcBlend",(float)BlendMode.SrcAlpha);
            if(SmokeMaterial.HasProperty("_DstBlend"))SmokeMaterial.SetFloat("_DstBlend",(float)BlendMode.OneMinusSrcAlpha);
            if(SmokeMaterial.HasProperty("_ZWrite"))SmokeMaterial.SetFloat("_ZWrite",0);
            SmokeMaterial.DisableKeyword("_ALPHATEST_ON");SmokeMaterial.DisableKeyword("_ALPHAPREMULTIPLY_ON");SmokeMaterial.EnableKeyword("_ALPHABLEND_ON");SmokeMaterial.SetOverrideTag("RenderType","Transparent");
            if(SmokeMaterial.HasProperty("_MainTex")&&!SmokeMaterial.GetTexture("_MainTex")){
                softMask=new Texture2D(64,64,TextureFormat.RGBA32,false,true){name="CB2_Procedural_Soft_Incense_Mask"};var pixels=new Color[4096];for(int y=0;y<64;y++)for(int x=0;x<64;x++){float d=Vector2.Distance(new Vector2(x,y),new Vector2(31.5f,31.5f))/31.5f;pixels[y*64+x]=new Color(1,1,1,Mathf.Pow(Mathf.Clamp01(1-d*d),2));}softMask.SetPixels(pixels);softMask.Apply(false,true);SmokeMaterial.SetTexture("_MainTex",softMask);
            }
            SmokeMaterial.renderQueue=3000;EmberMaterial=new Material(SmokeMaterial){name="CB2_Ember_Motes"};
            if(solidShader&&solidShader.isSupported){CoalMaterial=new Material(solidShader){name="CB2_Glowing_Coal"};CoalMaterial.color=new Color(.75f,.09f,.015f);if(CoalMaterial.HasProperty("_EmissionColor")){CoalMaterial.SetColor("_EmissionColor",new Color(2f,.28f,.025f));CoalMaterial.EnableKeyword("_EMISSION");}if(CoalMaterial.HasProperty("_Glossiness"))CoalMaterial.SetFloat("_Glossiness",.1f);}
        }
        public static ParticleSystem Smoke(Transform parent,string name,int max,float rate,float life,float size,Color color,float shapeRadius=.10f)
        {
            if(!SmokeMaterial)throw new InvalidOperationException("Incense factory not initialized");
            var go=new GameObject(name);go.transform.SetParent(parent,false);var ps=go.AddComponent<ParticleSystem>();ps.Stop(true,ParticleSystemStopBehavior.StopEmittingAndClear);
            var m=ps.main;m.loop=true;m.playOnAwake=false;m.simulationSpace=ParticleSystemSimulationSpace.World;m.cullingMode=ParticleSystemCullingMode.AlwaysSimulate;m.maxParticles=max;m.startLifetime=life;m.startSize=new ParticleSystem.MinMaxCurve(size*.72f,size);m.startRotation=new ParticleSystem.MinMaxCurve(0,Mathf.PI*2);m.startSpeed=new ParticleSystem.MinMaxCurve(.035f,.12f);m.startColor=color;m.gravityModifier=-.007f;
            var emission=ps.emission;emission.rateOverTime=rate;var shape=ps.shape;shape.shapeType=ParticleSystemShapeType.Sphere;shape.radius=shapeRadius;
            var velocity=ps.velocityOverLifetime;velocity.enabled=true;velocity.space=ParticleSystemSimulationSpace.World;velocity.y=.15f;
            var noise=ps.noise;noise.enabled=true;noise.strength=.11f;noise.frequency=.42f;noise.scrollSpeed=.16f;
            var scale=ps.sizeOverLifetime;scale.enabled=true;scale.size=new ParticleSystem.MinMaxCurve(1,AnimationCurve.Linear(0,.45f,1,1.8f));
            var fade=ps.colorOverLifetime;fade.enabled=true;var gradient=new Gradient();gradient.SetKeys(new[]{new GradientColorKey(Color.white,0),new GradientColorKey(Color.white,1)},new[]{new GradientAlphaKey(.15f,0),new GradientAlphaKey(1,.10f),new GradientAlphaKey(.85f,.65f),new GradientAlphaKey(0,1)});fade.color=gradient;
            var renderer=ps.GetComponent<ParticleSystemRenderer>();renderer.sharedMaterial=SmokeMaterial;renderer.renderMode=ParticleSystemRenderMode.Billboard;renderer.sortMode=ParticleSystemSortMode.Distance;renderer.minParticleSize=0;renderer.maxParticleSize=1;renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;renderer.lightProbeUsage=LightProbeUsage.Off;ps.Play();return ps;
        }
        public static void SmallImpact(Transform root)
        {
            var ash=Smoke(root,"CB2_Small_Ash_Puff",35,0,.65f,.20f,new Color(.66f,.60f,.50f,.80f),.045f);ash.Stop(false,ParticleSystemStopBehavior.StopEmittingAndClear);var main=ash.main;main.loop=false;main.duration=.1f;main.startSpeed=new ParticleSystem.MinMaxCurve(.07f,.25f);ash.Play();ash.Emit(18);
            var motes=Smoke(root,"CB2_Impact_Embers",18,0,.42f,.025f,new Color(1,.26f,.025f,1),.035f);motes.Stop(false,ParticleSystemStopBehavior.StopEmittingAndClear);main=motes.main;main.loop=false;main.duration=.1f;main.startSpeed=new ParticleSystem.MinMaxCurve(.18f,.55f);main.gravityModifier=.25f;motes.GetComponent<ParticleSystemRenderer>().sharedMaterial=EmberMaterial;motes.Play();motes.Emit(9);
        }
        public static void Shutdown(){foreach(var m in new[]{SmokeMaterial,EmberMaterial,CoalMaterial})if(m){if(Application.isPlaying)Object.Destroy(m);else Object.DestroyImmediate(m);}if(softMask){if(Application.isPlaying)Object.Destroy(softMask);else Object.DestroyImmediate(softMask);}SmokeMaterial=EmberMaterial=CoalMaterial=null;}
    }
    public static class CenserCloudGeometry
    {
        public const int Lobes=9;public const float Radius=1.16f,HalfHeight=.9f,Reach=2.35f,ArcDegrees=156f;
        public static Vector3 Center(Vector3 origin,Vector3 facing,int index){var dir=Quaternion.AngleAxis(-ArcDegrees/2+ArcDegrees*index/(Lobes-1),Vector3.up)*Vector3.ProjectOnPlane(facing,Vector3.up).normalized;return origin+Vector3.up*.60f+dir*Reach;}
        public static bool Contains(Vector3 center,Vector3 point,float age=10){var d=point-center;float r=Radius*Mathf.SmoothStep(0,1,Mathf.Clamp01((age-.10f)/.65f));if(r<.01f)return false;return (d.x*d.x+d.z*d.z)/(r*r)+d.y*d.y/(HalfHeight*HalfHeight)<=1;}
        public static float BirthTime(int index)=>index*.115f;
    }
}
