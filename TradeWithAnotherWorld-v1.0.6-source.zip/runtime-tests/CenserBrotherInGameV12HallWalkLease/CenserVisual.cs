using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using UnityEngine;
using UnityEngine.Rendering;
using Object=UnityEngine.Object;

namespace BlackAbbey.CenserBrother
{
    // The same own-data builder runs in the offline Editor check and in-game.
    // It has no creature/AI dependency and never creates an AssetBundle.
    public sealed class CenserVisual : IDisposable
    {
        public CenserPayload Payload;public Animator Animator;public Avatar Avatar;public Transform Root;
        public readonly Dictionary<string,Transform> Named=new Dictionary<string,Transform>(StringComparer.Ordinal);
        public readonly List<SkinnedMeshRenderer> Skins=new List<SkinnedMeshRenderer>();
        public readonly List<Object> Resources=new List<Object>();
        readonly Dictionary<string,Material> materials=new Dictionary<string,Material>();
        public static string Hash(string path){using(var h=SHA256.Create())using(var s=File.OpenRead(path))return string.Concat(h.ComputeHash(s).Select(b=>b.ToString("x2")));}
        public static Vector3 V(float[] a){if(a==null||a.Length!=3||a.Any(n=>!Finite(n)))throw new InvalidDataException("Invalid vector");return new Vector3(a[0],a[1],a[2]);}
        public static Quaternion Q(float[] a){if(a==null||a.Length!=4||a.Any(n=>!Finite(n)))throw new InvalidDataException("Invalid quaternion");var q=new Quaternion(a[0],a[1],a[2],a[3]);if(Mathf.Abs(Quaternion.Dot(q,q)-1)>.002f)throw new InvalidDataException("Nonunit quaternion");return q;}
        static bool Finite(float n)=>!float.IsNaN(n)&&!float.IsInfinity(n);
        static Matrix4x4 M(MatrixRecord a){if(a?.values==null||a.values.Length!=16||a.values.Any(n=>!Finite(n)))throw new InvalidDataException("Invalid matrix");var m=new Matrix4x4();for(int i=0;i<4;i++)for(int j=0;j<4;j++)m[i,j]=a.values[4*i+j];return m;}
        public static string Safe(string folder,string relative){if(string.IsNullOrWhiteSpace(relative)||Path.IsPathRooted(relative))throw new InvalidDataException("Expected relative map path");string root=Path.GetFullPath(folder).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;string p=Path.GetFullPath(Path.Combine(root,relative));if(!p.StartsWith(root,StringComparison.OrdinalIgnoreCase)||!File.Exists(p))throw new InvalidDataException("Outside/missing map");return p;}
        public static CenserPayload Read(string path)=>CenserPayloadReader.Read(path);
        public static CenserVisual Build(Transform root,CenserPayload p,Material template,string folder,bool equipment)
        {
            var r=new CenserVisual{Root=root,Payload=p};
            try{r.Construct(template,folder,equipment);return r;}catch{r.Dispose();throw;}
        }
        void Construct(Material template,string folder,bool equipment)
        {
            var nodes=new Dictionary<int,Transform>();
            foreach(var record in Payload.nodes){
                if(nodes.ContainsKey(record.id)||Named.ContainsKey(record.name))throw new InvalidDataException("Duplicate hierarchy node");
                Transform t;if(record.id==0){if(record.parentId!=-1||record.name!="Visual")throw new InvalidDataException("Wrong root");t=Root;}
                else{if(!nodes.TryGetValue(record.parentId,out var parent))throw new InvalidDataException("Hierarchy must be parent first");t=new GameObject(record.name).transform;t.SetParent(parent,false);}
                t.localPosition=V(record.position);t.localRotation=Q(record.rotation);t.localScale=V(record.scale);if(t.localScale.x<=0||t.localScale.y<=0||t.localScale.z<=0)throw new InvalidDataException("Nonpositive scale");t.gameObject.layer=Root.gameObject.layer;nodes.Add(record.id,t);Named.Add(record.name,t);
            }
            var d=Payload.humanDescription;
            var desc=new HumanDescription{human=d.human.Select(h=>new HumanBone{boneName=h.boneName,humanName=h.humanName,limit=new HumanLimit{useDefaultValues=h.limit.useDefaultValues,min=V(h.limit.min),max=V(h.limit.max),center=V(h.limit.center),axisLength=h.limit.axisLength}}).ToArray(),skeleton=d.skeleton.Select(s=>new SkeletonBone{name=s.name,position=V(s.position),rotation=Q(s.rotation),scale=V(s.scale)}).ToArray(),upperArmTwist=d.upperArmTwist,lowerArmTwist=d.lowerArmTwist,upperLegTwist=d.upperLegTwist,lowerLegTwist=d.lowerLegTwist,armStretch=d.armStretch,legStretch=d.legStretch,feetSpacing=d.feetSpacing,hasTranslationDoF=d.hasTranslationDoF};
            var parentRoot=Root.parent;var pos=Root.localPosition;var rot=Root.localRotation;var scale=Root.localScale;Root.SetParent(null,false);
            try{Avatar=AvatarBuilder.BuildHumanAvatar(Root.gameObject,desc);Resources.Add(Avatar);if(!Avatar||!Avatar.isValid||!Avatar.isHuman)throw new InvalidDataException("Own Censer Brother humanoid Avatar invalid");Avatar.name="BA_CenserBrother_Humanoid";}
            finally{Root.SetParent(parentRoot,false);Root.localPosition=pos;Root.localRotation=rot;Root.localScale=scale;}
            Animator=Root.GetComponent<Animator>();if(!Animator)Animator=Root.gameObject.AddComponent<Animator>();Animator.avatar=Avatar;Animator.applyRootMotion=false;Animator.cullingMode=AnimatorCullingMode.AlwaysAnimate;
            foreach(var m in Payload.materials)materials.Add(m.id,MakeMaterial(template,folder,m));
            foreach(var record in Payload.renderers){
                if(record.type!="skin"||(record.boneNodeIds?.Length!=53&&record.boneNodeIds?.Length!=3)||record.bindposes?.Length!=record.boneNodeIds.Length||record.weights?.Length!=record.vertexCount)throw new InvalidDataException("Censer skin contract changed");
                var go=new GameObject(record.name);go.transform.SetParent(Root,false);go.layer=Root.gameObject.layer;var mesh=Mesh(record);mesh.bindposes=record.bindposes.Select(M).ToArray();mesh.boneWeights=record.weights.Select(w=>Weight(w,record.boneNodeIds.Length)).ToArray();
                var skin=go.AddComponent<SkinnedMeshRenderer>();skin.sharedMesh=mesh;skin.bones=record.boneNodeIds.Select(i=>nodes[i]).ToArray();skin.rootBone=nodes[record.rootBoneNodeId];skin.localBounds=new Bounds(V(record.boundsCenter),V(record.boundsSize));skin.updateWhenOffscreen=true;skin.quality=SkinQuality.Bone4;skin.sharedMaterial=materials[record.materialId];skin.shadowCastingMode=ShadowCastingMode.On;skin.receiveShadows=true;Skins.Add(skin);
            }
            if(equipment)foreach(var record in Payload.items)BuildItem(Named[record.attachmentName],record);
        }
        BoneWeight Weight(WeightRecord w,int count){var inds=new[]{w.boneIndex0,w.boneIndex1,w.boneIndex2,w.boneIndex3};var values=new[]{w.weight0,w.weight1,w.weight2,w.weight3};if(inds.Any(i=>i<0||i>=count)||values.Any(v=>!Finite(v)||v<0||v>1)||Mathf.Abs(values.Sum()-1)>.0001)throw new InvalidDataException("Invalid four-influence skin");return new BoneWeight{boneIndex0=w.boneIndex0,boneIndex1=w.boneIndex1,boneIndex2=w.boneIndex2,boneIndex3=w.boneIndex3,weight0=w.weight0,weight1=w.weight1,weight2=w.weight2,weight3=w.weight3};}
        public Mesh Mesh(MeshRecord r){
            int n=r.vertexCount;if(n<3||n>100000||r.positions?.Length!=n*3||r.normals?.Length!=n*3||r.tangents?.Length!=n*4||r.uv?.Length!=n*2||r.triangles?.Length!=r.triangleCount*3||r.triangles.Any(i=>i<0||i>=n))throw new InvalidDataException("Invalid mesh arrays");
            if(r.positions.Concat(r.normals).Concat(r.tangents).Concat(r.uv).Any(v=>!Finite(v)))throw new InvalidDataException("Nonfinite mesh");
            var vs=new Vector3[n];var ns=new Vector3[n];var ts=new Vector4[n];var uv=new Vector2[n];for(int i=0;i<n;i++){vs[i]=new Vector3(r.positions[i*3],r.positions[i*3+1],r.positions[i*3+2]);ns[i]=new Vector3(r.normals[i*3],r.normals[i*3+1],r.normals[i*3+2]);ts[i]=new Vector4(r.tangents[i*4],r.tangents[i*4+1],r.tangents[i*4+2],r.tangents[i*4+3]);uv[i]=new Vector2(r.uv[i*2],r.uv[i*2+1]);}
            var mesh=new Mesh{name=r.name,indexFormat=n>65535?IndexFormat.UInt32:IndexFormat.UInt16};mesh.vertices=vs;mesh.normals=ns;mesh.tangents=ts;mesh.uv=uv;mesh.triangles=r.triangles;mesh.RecalculateBounds();Resources.Add(mesh);return mesh;
        }
        public GameObject BuildItem(Transform parent,MeshRecord record){var go=new GameObject(record.name);go.transform.SetParent(parent,false);go.transform.localPosition=V(record.position);go.transform.localRotation=Q(record.rotation);go.transform.localScale=V(record.scale);go.AddComponent<MeshFilter>().sharedMesh=Mesh(record);var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=materials[record.materialId];renderer.shadowCastingMode=ShadowCastingMode.On;return go;}
        Texture2D Texture(string folder,FileRecord record,bool linear){if(record==null)return null;string path=Safe(folder,record.path);if(new FileInfo(path).Length>32*1024*1024||Hash(path)!=record.sha256)throw new InvalidDataException("Texture source mismatch:"+record.path);var texture=new Texture2D(2,2,TextureFormat.RGBA32,true,linear);Resources.Add(texture);if(!ImageConversion.LoadImage(texture,File.ReadAllBytes(path),true)||texture.width>4096||texture.height>4096)throw new InvalidDataException("Invalid texture");texture.name=record.path;texture.wrapMode=TextureWrapMode.Clamp;texture.filterMode=FilterMode.Trilinear;texture.anisoLevel=4;return texture;}
        Material MakeMaterial(Material template,string folder,MaterialRecord record){var m=new Material(template){name="CB_"+record.id};Resources.Add(m);foreach(string prop in m.GetTexturePropertyNames()){m.SetTexture(prop,null);m.SetTextureScale(prop,Vector2.one);m.SetTextureOffset(prop,Vector2.zero);}m.SetColor("_Color",Color.white);if(record.diffuse!=null)m.SetTexture("_MainTex",Texture(folder,record.diffuse,false));else if(record.baseColor?.Length==4)m.SetColor("_Color",new Color(record.baseColor[0],record.baseColor[1],record.baseColor[2],record.baseColor[3]));if(record.normal!=null){m.SetTexture("_BumpMap",Texture(folder,record.normal,true));m.SetFloat("_BumpScale",1);m.EnableKeyword("_NORMALMAP");}if(record.metallicGloss!=null){m.SetTexture("_MetallicGlossMap",Texture(folder,record.metallicGloss,true));m.SetFloat("_UseGlossmap",1);m.EnableKeyword("_METALLICGLOSSMAP");}else{if(m.HasProperty("_Glossiness"))m.SetFloat("_Glossiness",1-record.roughness);if(m.HasProperty("_Metallic"))m.SetFloat("_Metallic",record.metallic);}foreach(string prop in new[]{"_Hue","_Saturation","_Value","_UseStyles","_Style","_NoiseGlowEnabled","_SnowCover","_AddRain"})if(m.HasProperty(prop))m.SetFloat(prop,0);if(m.HasProperty("_MetalColor"))m.SetColor("_MetalColor",Color.white);if(m.HasProperty("_EmissionColor"))m.SetColor("_EmissionColor",Color.black);m.DisableKeyword("_ALPHATEST_ON");m.DisableKeyword("_EMISSION");return m;}
        public void Dispose(){foreach(var r in Resources)if(r)Object.DestroyImmediate(r);Resources.Clear();}
    }
}
