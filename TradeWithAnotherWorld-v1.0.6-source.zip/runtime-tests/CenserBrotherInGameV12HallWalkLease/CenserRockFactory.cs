using System;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
using Object=UnityEngine.Object;

namespace BlackAbbey.CenserBrother
{
    // Read the installed rock at load time. No game mesh/material is shipped.
    public static class CenserRockFactory
    {
        public static Material BlackMaterial;
        public static string SourceShader,SourceMaterial;
        public const float Scale=.5f;
        public static Transform Build(GameObject root,GameObject source)
        {
            if(!source)throw new InvalidOperationException("Installed Greydwarf rock required");
            var pieces=source.GetComponentsInChildren<MeshFilter>(true).Where(f=>f.sharedMesh&&f.GetComponent<MeshRenderer>()).ToArray();
            if(pieces.Length==0)throw new InvalidOperationException("Native rock has no mesh renderer");
            if(!BlackMaterial){
                // Clone the material already referenced by the ready native rock.
                // Shader.Find can fail at startup even when that rock renders.
                var original=pieces[0].GetComponent<MeshRenderer>().sharedMaterial;
                if(!original||!original.shader)throw new InvalidOperationException("Native rock material missing");
                SourceShader=original.shader.name;SourceMaterial=original.name;
                BlackMaterial=new Material(original){name="CB5_Black_Ember_Rock"};
                bool tinted=false;foreach(string property in new[]{"_Color","_TintColor","_BaseColor"})if(BlackMaterial.HasProperty(property)){BlackMaterial.SetColor(property,new Color(.018f,.017f,.016f,1));tinted=true;}
                if(!tinted)throw new InvalidOperationException("Native rock material has no tint property: "+SourceShader);
                if(BlackMaterial.HasProperty("_Glossiness"))BlackMaterial.SetFloat("_Glossiness",.04f);
                if(BlackMaterial.HasProperty("_Metallic"))BlackMaterial.SetFloat("_Metallic",0);
                if(BlackMaterial.HasProperty("_EmissionColor"))BlackMaterial.SetColor("_EmissionColor",Color.black);
                BlackMaterial.DisableKeyword("_EMISSION");
            }
            var visual=new GameObject("CB3_Black_Greydwarf_Rock").transform;visual.SetParent(root.transform,false);
            Bounds bounds=new Bounds();bool first=true;
            foreach(var piece in pieces){
                Matrix4x4 local=source.transform.worldToLocalMatrix*piece.transform.localToWorldMatrix;
                var child=new GameObject(piece.name).transform;child.SetParent(visual,false);child.localPosition=local.GetColumn(3);child.localRotation=local.rotation;child.localScale=local.lossyScale;
                child.gameObject.AddComponent<MeshFilter>().sharedMesh=piece.sharedMesh;
                var renderer=child.gameObject.AddComponent<MeshRenderer>();renderer.sharedMaterials=Enumerable.Repeat(BlackMaterial,piece.sharedMesh.subMeshCount).ToArray();renderer.shadowCastingMode=ShadowCastingMode.Off;
                var b=piece.sharedMesh.bounds;for(int i=0;i<8;i++){var at=local.MultiplyPoint3x4(b.center+Vector3.Scale(b.extents,new Vector3((i&1)==0?-1:1,(i&2)==0?-1:1,(i&4)==0?-1:1)));if(first){bounds=new Bounds(at,Vector3.zero);first=false;}else bounds.Encapsulate(at);}
            }
            // Scale the visible stone only; keep native collision and flight units.
            foreach(Transform child in visual)child.localPosition-=bounds.center;
            visual.localScale=Vector3.one*Scale;return visual;
        }
        public static void Shutdown(){if(BlackMaterial){if(Application.isPlaying)Object.Destroy(BlackMaterial);else Object.DestroyImmediate(BlackMaterial);}BlackMaterial=null;}
    }
    public sealed class CenserRockSpin:MonoBehaviour
    { void Update(){transform.Rotate(new Vector3(95,145,70)*Time.deltaTime,Space.Self);} }
}
