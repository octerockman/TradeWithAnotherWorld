using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BlackAbbey.CenserBrother
{
    [DefaultExecutionOrder(900)]
    public sealed class CenserInstance:MonoBehaviour
    {
        public static MotionBank Bank;
        float wardingHallWalkUntil;
        public bool WardingHallWalkActive=>Time.time<wardingHallWalkUntil;
        // Presentation-only, expiring lease for a produced actor held in the
        // forced-perspective hallway. The helper refreshes it while advancing.
        public void SetWardingHallWalk(bool enabled){wardingHallWalkUntil=enabled?Time.time+.5f:0;}
        public string payloadSha256;
        public Transform RightFist,EmberSocket;
        ZNetView view;Character character;CenserAI ai;FootStep feet;Animator lifecycleAnimator;
        int spineIndex=-1;Transform spine;
        Transform[] bones;Transform gravity,swing,anchor;Quaternion gravityLocal,swingLocal;
        readonly Dictionary<string,MotionClip> clips=new Dictionary<string,MotionClip>();
        string previous="",gait="Idle";float phase,lastStepPhase=-1,speedSmooth,kindAt,lastYaw,turnLean,lastPoseDt=.0333f;Vector3[] priorPos,lastPos;Quaternion[] priorRot,lastRot;CenserPoseTransition transition;ParticleSystem carrySmoke;Light censerGlow;float idlePhase;bool posed,twoPoses;
        Vector3 lastAnchor,lastVelocity;readonly CenserPendulum physics=new CenserPendulum();bool initialized,firstPhysics=true;long lastSweep;
        public static long NowTicks=>ZNet.instance?ZNet.instance.GetTime().Ticks:DateTime.UtcNow.Ticks;
        void Awake(){view=GetComponent<ZNetView>();character=GetComponent<Character>();ai=GetComponent<CenserAI>();feet=GetComponentInChildren<FootStep>(true);}
        void Start()
        {
            if(!view||!view.IsValid()||Bank==null){enabled=false;return;}
            var named=new Dictionary<string,Transform>();foreach(var t in GetComponentsInChildren<Transform>(true))if(!named.ContainsKey(t.name))named.Add(t.name,t);
            bones=new Transform[Bank.boneNames.Length];for(int i=0;i<bones.Length;i++)bones[i]=named[Bank.boneNames[i]];
            // The motion-bank skeleton is immutable for this instance. Resolve once.
            spineIndex=Array.FindIndex(Bank.boneNames,n=>n=="Spine1");spine=spineIndex>=0?bones[spineIndex]:null;
            priorPos=new Vector3[bones.Length];priorRot=new Quaternion[bones.Length];lastPos=new Vector3[bones.Length];lastRot=new Quaternion[bones.Length];transition=new CenserPoseTransition(bones.Length);transition.Clear();foreach(var c in Bank.clips)clips.Add(c.name,c);
            gravity=named["Censer_Gravity"];swing=named["Censer_Swing"];anchor=named["Censer_Grip"];gravityLocal=gravity.localRotation;swingLocal=swing.localRotation;
            RightFist=named["RightHandIndex1"];EmberSocket=named["CenserEmber"];
            carrySmoke=CenserEffects.AttachCenser(named["CenserSmoke"],named["CenserEmber"]);censerGlow=named["CenserEmber"].GetComponentInChildren<Light>();lastYaw=transform.eulerAngles.y;
            lifecycleAnimator=GetComponentInChildren<Animator>(true);
            if(lifecycleAnimator){lifecycleAnimator.enabled=false;lifecycleAnimator.fireEvents=false;lifecycleAnimator.Rebind();lifecycleAnimator.SetBool("wakeup",false);lifecycleAnimator.Play("Base Layer.Movement",0,0);lifecycleAnimator.Update(0);}
            lastAnchor=gravity.position;physics.Reset();initialized=true;
        }
        public float ActionSeconds=>view&&view.IsValid()?(float)((NowTicks-view.GetZDO().GetLong("cb_start",NowTicks))/10000000d):0;
        public void StartAction(CenserAction action){if(!Own)return;view.GetZDO().Set("cb_action",(int)action);view.GetZDO().Set("cb_start",NowTicks);}
        public void StopAction(){if(Own)view.GetZDO().Set("cb_action",0);}
        public void PublishSweep(){if(!Own)return;var z=view.GetZDO();z.Set("cb_sweep_pos",transform.position);z.Set("cb_sweep_fwd",transform.forward);z.Set("cb_cloudLife",CenserPlugin.Settings.CloudDuration.Value);z.Set("cb_chokeLife",CenserPlugin.Settings.ChokeDuration.Value);z.Set("cb_chokeDps",CenserPlugin.Settings.ChokeDamage.Value);z.Set("cb_sweep_at",NowTicks);}
        bool Own=>view&&view.IsValid()&&view.IsOwner()&&character&&!character.IsDead();
        void LateUpdate()
        {
            if(!initialized||!view.IsValid())return;
            float dt=Mathf.Min(Time.deltaTime,.05f);var z=view.GetZDO();var action=(CenserAction)z.GetInt("cb_action",0);float elapsed=(float)((NowTicks-z.GetLong("cb_start",NowTicks))/10000000d);
            // Advance native lifecycle tags (initial freeze, stagger, death)
            // explicitly, then overwrite all visible bones with owned motion.
            if(lifecycleAnimator){lifecycleAnimator.enabled=false;lifecycleAnimator.Update(dt);}
            if(character.IsDead()){return;}
            if(elapsed>CenserPolicy.Duration(action)+.25f)action=CenserAction.None;
            bool hallWalk=WardingHallWalkActive;
            Vector3 velocity=Vector3.ProjectOnPlane(character.GetVelocity(),Vector3.up);float speed=hallWalk?.65f:velocity.magnitude;speedSmooth=Mathf.Lerp(speedSmooth,speed,1-Mathf.Exp(-dt*10));Vector3 local=hallWalk?Vector3.forward*.65f:transform.InverseTransformDirection(velocity);
            string desired=hallWalk?"Walk":speedSmooth>.10f?(Mathf.Abs(local.x)>Mathf.Abs(local.z)*1.3f?(local.x<0?"StrafeLeft":"StrafeRight"):local.z<-.12f?"BackWalk":ai&&ai.IsAlerted()?"CombatWalk":"Walk"):"Idle";
            if(Time.time>=kindAt||desired=="Idle"){if(gait!=desired){gait=desired;kindAt=Time.time+.25f;}}
            string name=action==CenserAction.Punch?"Punch":action==CenserAction.Sweep?"Sweep":action==CenserAction.Ember?"Ember":gait;var clip=clips[name];
            bool changed=name!=previous;float normalized,phaseRate;
            if(clip.loop){float nominal=name=="Walk"?.65f:name=="CombatWalk"?1.05f:name=="BackWalk"?.85f:.65f;float rate=name=="Idle"?1:Mathf.Clamp(speedSmooth/nominal,0,2.4f);phaseRate=rate/clip.duration;if(name=="Idle"){idlePhase=Mathf.Repeat(idlePhase+dt*phaseRate,1);normalized=idlePhase;}else{phase=Mathf.Repeat(phase+dt*phaseRate,1);normalized=phase;}}else {normalized=Mathf.Clamp01(elapsed/clip.duration);phaseRate=1/clip.duration;}
            if(changed){if(posed)transition.Begin(.24f);else transition.Clear();previous=name;}else transition.Advance(dt);
            for(int i=0;i<bones.Length;i++){
                CenserMotionSampler.Sample(clip,normalized,i,out var position,out var rotation);
                if(changed&&posed){CenserMotionSampler.Sample(clip,normalized+dt*phaseRate,i,out var nextPosition,out var nextRotation);transition.Capture(i,lastPos[i],lastRot[i],twoPoses?(lastPos[i]-priorPos[i])/lastPoseDt:Vector3.zero,twoPoses?CenserPoseTransition.Log(lastRot[i]*Quaternion.Inverse(priorRot[i]))/lastPoseDt:Vector3.zero,position,rotation,(nextPosition-position)/Mathf.Max(.001f,dt),CenserPoseTransition.Log(nextRotation*Quaternion.Inverse(rotation))/Mathf.Max(.001f,dt));}
                transition.Apply(i,ref position,ref rotation);priorPos[i]=lastPos[i];priorRot[i]=lastRot[i];bones[i].localPosition=lastPos[i]=position;bones[i].localRotation=lastRot[i]=rotation;
            }twoPoses=posed;posed=true;lastPoseDt=Mathf.Max(.001f,dt);
            float yaw=transform.eulerAngles.y,turn=Mathf.Clamp(Mathf.DeltaAngle(lastYaw,yaw)/Mathf.Max(dt,.001f),-140,140);lastYaw=yaw;turnLean=Mathf.Lerp(turnLean,action==CenserAction.None?Mathf.Clamp(-turn*.025f,-3.5f,3.5f)*Mathf.Clamp01(speedSmooth):0,1-Mathf.Exp(-dt*7));
            if(spine){spine.rotation=Quaternion.AngleAxis(turnLean,transform.forward)*spine.rotation;lastRot[spineIndex]=spine.localRotation;}
            if(clip.loop&&name!="Idle"&&speedSmooth>.08f){float half=Mathf.Floor(phase*2);if(lastStepPhase>=0&&half!=lastStepPhase&&feet)feet.OnFoot(half==0?"LeftFoot":"RightFoot");lastStepPhase=half;}else lastStepPhase=-1;
            if(carrySmoke){bool smoking=action==CenserAction.Sweep&&CenserPolicy.IsSweepTime(elapsed);var emission=carrySmoke.emission;emission.rateOverTime=smoking?180:24;var main=carrySmoke.main;var color=main.startColor.color;color.a=Mathf.Lerp(color.a,smoking?.85f:.20f,1-Mathf.Exp(-dt*8));main.startColor=color;}
            if(censerGlow){float charge=action==CenserAction.Ember?Mathf.SmoothStep(0,1,Mathf.Clamp01(elapsed/.72f))*(1-Mathf.SmoothStep(0,1,Mathf.Clamp01((elapsed-.86f)/.25f))):0;censerGlow.intensity=1.35f+1.4f*charge;}
            // Restored V12 locomotion uses the previous live censer pendulum.
            Pendulum(dt,action,elapsed);
            long sweep=z.GetLong("cb_sweep_at",0);
            if(sweep>0&&sweep!=lastSweep){lastSweep=sweep;float age=(float)((NowTicks-sweep)/10000000d),duration=z.GetFloat("cb_cloudLife",4.5f);if(age>=0&&age<duration)CenserEffects.SweepCloud(z.GetVec3("cb_sweep_pos",transform.position),z.GetVec3("cb_sweep_fwd",transform.forward),age,character,duration,z.GetFloat("cb_chokeLife",3),z.GetFloat("cb_chokeDps",2.5f));}
        }
        void Pendulum(float dt,CenserAction action,float elapsed)
        {
            gravity.localRotation=gravityLocal;swing.localRotation=swingLocal;
            Vector3 at=gravity.position;
            if(firstPhysics){firstPhysics=false;lastAnchor=at;lastVelocity=Vector3.zero;physics.Reset();}
            if((at-lastAnchor).sqrMagnitude>4){physics.Reset();lastVelocity=Vector3.zero;lastAnchor=at;}
            Vector3 velocity=(at-lastAnchor)/Mathf.Max(.001f,dt);Vector3 accel=Vector3.ClampMagnitude((velocity-lastVelocity)/Mathf.Max(.001f,dt),18);lastAnchor=at;lastVelocity=Vector3.Lerp(lastVelocity,velocity,.35f);
            // A damped gravity pendulum moves the chain and bowl below the fixed ring.
            Vector3 pendulum=physics.Step(dt,accel);
            Vector3 wanted=pendulum;
            if(action==CenserAction.Sweep){float s=Mathf.SmoothStep(0,1,Mathf.Clamp01((elapsed-.42f)/.28f))*(1-Mathf.SmoothStep(0,1,Mathf.Clamp01((elapsed-1.78f)/.70f)));Vector3 low=Quaternion.AngleAxis(CenserPolicy.SweepAngle(elapsed),Vector3.up)*Vector3.forward;low=(low*.60f+Vector3.down*.80f).normalized;wanted=Vector3.Slerp(pendulum,transform.TransformDirection(low),s);}
            if(action==CenserAction.Ember){float s=Mathf.Clamp01(1-Mathf.Abs(elapsed-.86f)/.35f);wanted=Vector3.Slerp(pendulum,transform.TransformDirection(new Vector3(0,-.34f,.94f)),Mathf.SmoothStep(0,1,s));}
            gravity.rotation=Quaternion.FromToRotation(gravity.up,Vector3.down)*gravity.rotation;
            swing.rotation=Quaternion.FromToRotation(swing.up,wanted)*swing.rotation;
            if(action!=CenserAction.None){physics.FollowAuthored(wanted,dt);}
        }
        public string Status()=>"CB_ACTOR health="+(character?character.GetHealth():0)+" target="+(ai&&ai.Target?ai.Target.m_name:"none")+" action="+(ai?ai.Action.ToString():"none")+" "+(ai?ai.NavigationStatus():"")+" source="+payloadSha256;
    }
}
