using System;
using System.Linq;
using UnityEngine;

namespace BlackAbbey.CenserBrother
{
    public static class ProfanedBloodEffects
    {
        public static GameObject BuildPrefab(Transform inactiveContainer)=>ProfanedBloodParticles.BuildPrefab(inactiveContainer);
        public static void Shutdown()=>ProfanedBloodParticles.Shutdown();
        public static EffectList ReplaceVisuals(EffectList original,GameObject blood)
        {
            // Keep native pure sound/nonvisual effects; replace skeleton debris.
            var retained=(original?.m_effectPrefabs??Array.Empty<EffectList.EffectData>())
                .Where(e=>e?.m_prefab&&e.m_prefab.GetComponentsInChildren<Renderer>(true).Length==0);
            return new EffectList{m_effectPrefabs=retained.Concat(new[]{
                new EffectList.EffectData{m_prefab=blood,m_enabled=true}}).ToArray()};
        }
    }
}
