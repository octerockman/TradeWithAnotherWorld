using System;
namespace BlackAbbey.CenserBrother
{
    [Serializable]public sealed class MotionFrame{public float[] positions,rotations;}
    [Serializable]public sealed class MotionClip{public string name;public float duration;public bool loop;public MotionFrame[] frames;}
    [Serializable]public sealed class MotionBank{public string schema;public FileRecord sourceNative;public string[] boneNames;public int fps;public MotionClip[] clips;public bool containsVanillaClips;}
}
