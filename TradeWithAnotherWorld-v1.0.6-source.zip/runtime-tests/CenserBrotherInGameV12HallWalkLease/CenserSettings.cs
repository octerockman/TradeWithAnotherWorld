using BepInEx.Configuration;
namespace BlackAbbey.CenserBrother
{
    public sealed class CenserSettings
    {
        public ConfigEntry<float> Walk,CombatWalk,Health,Punch,ChokeDamage,ChokeDuration,CloudDuration,EmberImpact,EmberFire;
        public CenserSettings(ConfigFile c){
            Walk=c.Bind("Movement","CalmWalkSpeed",.65f,new ConfigDescription("Steady idle patrol speed (metres/sec).",new AcceptableValueRange<float>(.2f,1.5f)));
            CombatWalk=c.Bind("Movement","CombatWalkSpeed",1.05f,new ConfigDescription("Controlled combat walking speed; no sprint.",new AcceptableValueRange<float>(.4f,2f)));
            Health=c.Bind("Balance","Health",140f,new ConfigDescription("Base health before native level scaling.",new AcceptableValueRange<float>(20f,2000f)));
            Punch=c.Bind("Balance","RightFistBlunt",14f,new ConfigDescription("Right fist damage; actual contact and line of sight required.",new AcceptableValueRange<float>(0f,100f)));
            ChokeDamage=c.Bind("Balance","ChokeDamagePerSecond",2.5f,new ConfigDescription("Brief non-stacking incense suffocation.",new AcceptableValueRange<float>(0f,30f)));
            ChokeDuration=c.Bind("Balance","ChokeSeconds",3f,new ConfigDescription("Time to recover after leaving smoke.",new AcceptableValueRange<float>(1f,6f)));
            CloudDuration=c.Bind("Balance","CloudSeconds",4.5f,new ConfigDescription("Lingering low sweep cloud lifetime.",new AcceptableValueRange<float>(2f,8f)));
            EmberImpact=c.Bind("Balance","EmberImpactBlunt",12f,new ConfigDescription("Visible ember impact damage.",new AcceptableValueRange<float>(0f,100f)));
            EmberFire=c.Bind("Balance","EmberFire",18f,new ConfigDescription("Native fire damage and its burning effect.",new AcceptableValueRange<float>(0f,100f)));
        }
    }
}
