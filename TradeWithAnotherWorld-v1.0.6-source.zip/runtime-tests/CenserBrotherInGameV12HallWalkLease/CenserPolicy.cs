using System;

namespace BlackAbbey.CenserBrother
{
    public enum CenserAction { None=0, Punch=1, Sweep=2, Ember=3 }
    // Pure combat decisions, shared by the actor and offline boundary checks.
    public static class CenserPolicy
    {
        public static bool MayAcquire(bool passiveWorld,bool nativeCanSense)=>!passiveWorld&&nativeCanSense;
        public static bool MayKeepTarget(bool passiveWorld,bool provoked)=>!passiveWorld||provoked;
        public static float Duration(CenserAction a)=>a==CenserAction.Punch?1.6f:a==CenserAction.Sweep?2.65f:a==CenserAction.Ember?1.85f:0;
        public static float Release(CenserAction a)=>a==CenserAction.Punch?.72f:a==CenserAction.Sweep?.78f:a==CenserAction.Ember?.86f:float.PositiveInfinity;
        public static float PreferredGap(float weaponRange)=>Math.Max(3.2f,Math.Min(4.8f,weaponRange+.85f));
        public static int Spacing(float distance,float preferred,int previous)
        {
            // Hysteresis keeps a stationary player from provoking foot shuffling.
            if(previous<0&&distance<preferred+.1f)return -1;
            if(previous>0&&distance>preferred-.15f)return 1;
            if(distance<preferred-.65f)return -1;
            if(distance>preferred+.8f)return 1;
            return 0;
        }
        public static CenserAction Choose(float distance,bool sight,float punchReady,float sweepReady,float emberReady,float now)
        {
            if(!sight)return CenserAction.None;
            if(distance<=1.35f&&now>=punchReady)return CenserAction.Punch;
            if(distance>=1.7f&&distance<=3.45f&&now>=sweepReady)return CenserAction.Sweep;
            if(distance>=3.35f&&distance<=15f&&now>=emberReady)return CenserAction.Ember;
            return CenserAction.None;
        }
        public static bool CanPunch(float fistToSurface,float centerDistance,float facingDot,bool sight)=>fistToSurface<=.48f&&centerDistance<=1.85f&&facingDot>.35f&&sight;
        public static bool IsSweepTime(float time)=>time>=.78f&&time<=1.70f;
        public static float SweepAngle(float time)=>-78f+156f*Smooth((time-.55f)/1.20f);
        static float Smooth(float t){t=Math.Max(0,Math.Min(1,t));return t*t*(3-2*t);}
        public static bool IsPunchTime(float t)=>t>=.50f&&t<=1.03f;
        public static bool Authority(bool valid,bool owner,bool alive)=>valid&&owner&&alive;
    }
}
