using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
using Object=UnityEngine.Object;

namespace BlackAbbey.CenserBrother
{
    public sealed class SE_CenserChoking:StatusEffect
    {
        float tick,damagePerSecond=2.5f;Character attacker;
        public override void Setup(Character c){base.Setup(c);tick=0;}
        public override void SetAttacker(Character c){attacker=c;}
        public override void SetLevel(int itemLevel,float skillLevel){damagePerSecond=Mathf.Clamp(itemLevel*.1f,0,30);m_ttl=Mathf.Clamp(skillLevel,1,6);}
        public override void UpdateStatusEffect(float dt){base.UpdateStatusEffect(dt);tick+=dt;if(tick<1||!m_character||m_character.IsDead())return;tick-=1;var view=m_character.GetComponent<ZNetView>();if(!view||!view.IsValid()||!view.IsOwner())return;
            var hit=new HitData{m_point=m_character.GetCenterPoint(),m_hitType=HitData.HitType.EnemyHit};hit.m_damage.m_damage=damagePerSecond;if(attacker)hit.SetAttacker(attacker);
            // Same direct smoke-damage path as native SE_Smoke; no repeated hit stagger.
            m_character.ApplyDamage(hit,true,false,HitData.DamageModifier.Normal);
        }
    }
    public static class CenserEffects
    {
        public const string StatusName="BA_CenserChoking";
        public static Sprite StatusIcon;static Texture2D icon;static readonly List<CenserCloud> clouds=new List<CenserCloud>();
        public static void Initialize(Material smoke){CenserParticleFactory.Initialize(smoke,Shader.Find("Standard"));icon=new Texture2D(2,2,TextureFormat.RGBA32,false);icon.SetPixels(new[]{Color.gray,Color.clear,Color.clear,Color.gray});icon.Apply();StatusIcon=Sprite.Create(icon,new Rect(0,0,2,2),new Vector2(.5f,.5f));}
        static ParticleSystem Smoke(Transform parent,string name,int maximum,float rate,float life,float size,Color color)=>CenserParticleFactory.Smoke(parent,name,maximum,rate,life,size,color);
        public static ParticleSystem AttachCenser(Transform smoke,Transform ember)
        {
            var incense=Smoke(smoke,"CB6_Light_Carry_Incense",220,24f,2.5f,.40f,new Color(.66f,.62f,.54f,.20f));
            var glow=new GameObject("CB_Ember_Glow");glow.transform.SetParent(ember,false);var light=glow.AddComponent<Light>();light.type=LightType.Point;light.color=new Color(1,.19f,.035f);light.intensity=1.35f;light.range=2.8f;light.shadows=LightShadows.None;
            var sparks=Smoke(ember,"CB_Coal_Sparks",22,4f,.65f,.025f,new Color(1,.24f,.035f,.95f));sparks.GetComponent<ParticleSystemRenderer>().sharedMaterial=CenserParticleFactory.EmberMaterial;return incense;
        }
        public static void SweepCloud(Vector3 origin,Vector3 facing,float age,Character owner,float duration,float chokeDuration,float damage)
        {
            clouds.RemoveAll(c=>!c);while(clouds.Count>=8){var old=clouds[0];clouds.RemoveAt(0);if(old)Object.Destroy(old.gameObject);}
            var go=new GameObject("CB_Low_Incense_Sweep");go.transform.position=origin;go.transform.rotation=Quaternion.LookRotation(Vector3.ProjectOnPlane(facing,Vector3.up).normalized);var c=go.AddComponent<CenserCloud>();c.age=age;c.owner=owner;c.duration=duration;c.chokeDuration=chokeDuration;c.damage=damage;clouds.Add(c);
            for(int i=0;i<CenserCloudGeometry.Lobes;i++){
                Vector3 from=origin+Vector3.up*.60f;Vector3 at=CenserCloudGeometry.Center(origin,facing,i);Vector3 dir=(at-from).normalized;
                if(Physics.Linecast(from,at,out var hit,CenserAI.SolidMask,QueryTriggerInteraction.Ignore))at=hit.point-dir*.25f;
                c.centers.Add(at);var child=new GameObject("Incense billow "+i).transform;child.SetParent(go.transform,true);child.position=at;var ps=Smoke(child,"CB2_Visible_Choking_Billow",85,38f,2.2f,1.10f,new Color(.70f,.65f,.56f,.95f));var shape=ps.shape;shape.radius=.58f;var emission=ps.emission;emission.enabled=false;c.particles.Add(ps);
            }
        }
        public static void ProjectileVisual(GameObject root,GameObject source)
        {
            foreach(var r in root.GetComponentsInChildren<Renderer>(true))r.enabled=false;
            CenserRockFactory.Build(root,source).gameObject.AddComponent<CenserRockSpin>();
            var ps=Smoke(root.transform,"CB_Flying_Ember",32,24,.32f,.045f,new Color(1,.18f,.02f,.95f));ps.GetComponent<ParticleSystemRenderer>().sharedMaterial=CenserParticleFactory.EmberMaterial;var light=ps.gameObject.AddComponent<Light>();light.color=new Color(1,.16f,.02f);light.range=1.2f;light.intensity=.65f;light.shadows=LightShadows.None;
        }
        public static void Shutdown(){foreach(var c in clouds)if(c)Object.Destroy(c.gameObject);clouds.Clear();if(StatusIcon)Object.Destroy(StatusIcon);if(icon)Object.Destroy(icon);CenserRockFactory.Shutdown();CenserParticleFactory.Shutdown();}

    }
    public sealed class CenserAshImpact:MonoBehaviour
    {void Start(){CenserParticleFactory.SmallImpact(transform);Destroy(gameObject,1.1f);}}
    public sealed class CenserCloud:MonoBehaviour
    {
        public float age,duration,chokeDuration,damage;public Character owner;public readonly List<Vector3> centers=new List<Vector3>();public readonly List<ParticleSystem> particles=new List<ParticleSystem>();float next;bool stopped;
        void Update(){age+=Time.deltaTime;if(age>=duration&&!stopped){stopped=true;foreach(var ps in particles)if(ps)ps.Stop(false,ParticleSystemStopBehavior.StopEmitting);}if(age>=duration+2.3f){Destroy(gameObject);return;}
            if(!stopped)for(int i=0;i<particles.Count;i++){var emission=particles[i].emission;emission.enabled=age>=CenserCloudGeometry.BirthTime(i);}
            if(stopped||Time.time<next)return;next=Time.time+.45f;
            // Each peer applies one unique status only to its own authoritative player.
            var p=Player.m_localPlayer;if(!p||p.IsDead()||p.InGhostMode())return;var view=p.GetComponent<ZNetView>();if(!view||!view.IsValid()||!view.IsOwner())return;
            Vector3 at=p.GetCenterPoint();for(int i=0;i<centers.Count;i++){var center=centers[i];if(age<CenserCloudGeometry.BirthTime(i)+.12f||particles[i].particleCount==0)continue;if(CenserCloudGeometry.Contains(center,at,age-CenserCloudGeometry.BirthTime(i))&&CenserAI.Sight(center,at)){
                int hash=CenserEffects.StatusName.GetStableHashCode();p.GetSEMan().AddStatusEffect(hash,true,Mathf.RoundToInt(damage*10),chokeDuration);var effect=p.GetSEMan().GetStatusEffect(hash);if(effect)effect.SetAttacker(owner);break;
            }
            }
        }
    }
}
