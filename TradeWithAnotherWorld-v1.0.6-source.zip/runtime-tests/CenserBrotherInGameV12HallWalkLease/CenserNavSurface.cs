using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using Object=UnityEngine.Object;
namespace BlackAbbey.CenserBrother
{
    // Actor-sized private navigation, also checked against synthetic static
    // geometry in the Editor. It never edits native or other actors' agents.
    public sealed class CenserNavSurface:IDisposable
    {
        NavMeshBuildSettings settings;NavMeshData data;NavMeshDataInstance instance;
        AsyncOperation pending;List<NavMeshBuildSource> retained;readonly NavMeshPath path=new NavMeshPath();
        public bool Ready=>instance.valid;public bool Building=>pending!=null&&!pending.isDone;public int Revision{get;private set;}
        public int AgentId=>settings.agentTypeID;public Bounds Bounds{get;private set;}
        public CenserNavSurface(float height,float radius,float climb,float slope,Vector3 origin){settings=NavMesh.CreateSettings();settings.agentHeight=height;settings.agentRadius=radius;settings.agentClimb=climb;settings.agentSlope=slope;settings.minRegionArea=.5f;settings.overrideVoxelSize=true;settings.voxelSize=.08f;settings.overrideTileSize=true;settings.tileSize=128;data=new NavMeshData(settings.agentTypeID){position=origin,rotation=Quaternion.identity,name="CB2 Private Navigation"};}
        public void Build(List<NavMeshBuildSource> sources,Bounds bounds,bool synchronous=false){if(Building)return;Bounds=bounds;retained=sources;var local=new Bounds(bounds.center-data.position,bounds.size);if(synchronous){NavMeshBuilder.UpdateNavMeshData(data,settings,sources,local);Register();retained=null;}else pending=NavMeshBuilder.UpdateNavMeshDataAsync(data,settings,sources,local);}
        void Register(){if(!instance.valid)instance=NavMesh.AddNavMeshData(data);if(!instance.valid)throw new InvalidOperationException("Private navigation registration failed");Revision++;}
        public bool Complete(){if(pending==null||!pending.isDone)return false;pending=null;retained=null;Register();return true;}
        NavMeshQueryFilter Filter=>new NavMeshQueryFilter{agentTypeID=settings.agentTypeID,areaMask=NavMesh.AllAreas};
        public bool Route(Vector3 from,Vector3 to,List<Vector3> output){output.Clear();if(!Ready||!Bounds.Contains(from)||!Bounds.Contains(to))return false;if(!NavMesh.SamplePosition(from,out var a,.8f,Filter)||!NavMesh.SamplePosition(to,out var b,.8f,Filter)||Mathf.Abs(a.position.y-from.y)>.55f||Mathf.Abs(b.position.y-to.y)>.55f)return false;if(!NavMesh.CalculatePath(a.position,b.position,Filter,path)||path.status!=NavMeshPathStatus.PathComplete||path.corners.Length<2)return false;output.AddRange(path.corners);return true;}
        public bool Straight(Vector3 a,Vector3 b)=>Ready&&!NavMesh.Raycast(a,b,out _,Filter);
        public void Dispose(){if(data)NavMeshBuilder.Cancel(data);if(instance.valid)instance.Remove();if(data){if(Application.isPlaying)Object.Destroy(data);else Object.DestroyImmediate(data);}NavMesh.RemoveSettings(settings.agentTypeID);retained=null;pending=null;}
    }
    public sealed class CenserRouteFollower
    {
        public Vector3 Input;public int Corner=1;
        public Vector3 Follow(IList<Vector3> corners,Vector3 position,float stop,float dt)
        {
            if(corners==null||corners.Count<2)return Smooth(Vector3.zero,dt);
            while(Corner<corners.Count-1&&Vector3.ProjectOnPlane(corners[Corner]-position,Vector3.up).sqrMagnitude<.22f)Corner++;
            var delta=Vector3.ProjectOnPlane(corners[Mathf.Min(Corner,corners.Count-1)]-position,Vector3.up);float distance=delta.magnitude;
            float arrive=Corner==corners.Count-1?Mathf.Clamp01((distance-stop)/.55f):1;
            return Smooth(distance<=stop?Vector3.zero:delta.normalized*arrive,dt);
        }
        public Vector3 Smooth(Vector3 wanted,float dt){Input=Vector3.MoveTowards(Input,wanted,Mathf.Clamp(dt,0,.1f)*3.5f);return Input;}
    }
}
