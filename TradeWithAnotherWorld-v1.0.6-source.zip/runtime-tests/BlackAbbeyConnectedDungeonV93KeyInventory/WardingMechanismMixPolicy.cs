namespace BlackAbbeySixRooms
{
    // Jesse requested a louder closing creak, with the accepted motion timing.
    // The exact approved clip peaks at -12dBFS; +5dB leaves 7dB headroom.
    internal static class WardingMechanismMixPolicy
    {
        internal const float ClosingGain = 1.77827941f;
        internal static float Sample(string clipId,float sample)=>clipId=="door_closing_creak"?sample*ClosingGain:sample;
    }
}
