using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Audio;
using Object=UnityEngine.Object;
namespace BlackAbbeySixRooms
{
    internal sealed class WardingMechanismAudio:IDisposable
    {
        sealed class Manifest {public string schema="";public ClipRow[] clips=Array.Empty<ClipRow>();}
        sealed class ClipRow {public string id="",path="",sha256="";public int frames=0,sampleRate=0,channels=0;public bool loop=false;public float gain=1;}
        internal sealed class Loaded {internal AudioClip Clip;internal bool Loop;internal float Gain;}
        internal const int MaximumSources=8;
        static WardingMechanismAudio current;
        readonly Dictionary<string,Loaded> clips=new Dictionary<string,Loaded>();
        readonly List<VerifiedResourceFile> leases=new List<VerifiedResourceFile>();
        readonly HashSet<WardingMechanismEmitter> emitters=new HashSet<WardingMechanismEmitter>();
        AudioMixerGroup mixer;float nextMixer;bool mixerPending,disposed;Action<string> log;
        internal static void Initialize(string directory,Action<string> logger)
        {
            Shutdown();var bank=new WardingMechanismAudio{log=logger};current=bank;
            try
            {
                var manifest=new VerifiedResourceFile(Path.GetFullPath(Path.Combine(directory,"manifest.json")),WardingMechanismSource.ManifestSha256,65536);bank.leases.Add(manifest);
                var data=JsonConvert.DeserializeObject<Manifest>(Encoding.UTF8.GetString(manifest.Read()));
                if(data?.schema!="black-abbey.warding-mechanism-audio.v1"||data.clips==null||data.clips.Length!=4)throw new InvalidDataException("Four approved mechanism sounds required");
                foreach(var row in data.clips)
                {
                    int expected=row.id=="door_closing_creak"||row.id=="bar_lowering_creak"?480000:row.id=="bar_slam"?144000:row.id=="locking_pin"?96000:0;
                    if(expected==0||row.frames!=expected||row.sampleRate!=48000||row.channels!=1||row.loop!=(expected==480000)||row.gain<0||row.gain>1||float.IsNaN(row.gain)||
                        string.IsNullOrEmpty(row.path)||row.path!=Path.GetFileName(row.path)||row.path.IndexOfAny(new[]{'/','\\',':'})>=0||bank.clips.ContainsKey(row.id))
                        throw new InvalidDataException("Mechanism sound contract differs");
                    var lease=new VerifiedResourceFile(Path.GetFullPath(Path.Combine(directory,row.path)),row.sha256,1000000);bank.leases.Add(lease);
                    var pcm=PcmWave.Read(lease.Read());if(pcm.Frames!=expected)throw new InvalidDataException("Mechanism PCM length differs");
                    // AudioSource.volume caps at1. Boost only this checked PCM
                    // cache; original WAV/gains, mixer and pose timing stay exact.
                    if(row.id=="door_closing_creak")for(int i=0;i<pcm.Samples.Length;i++)pcm.Samples[i]=WardingMechanismMixPolicy.Sample(row.id,pcm.Samples[i]);
                    var clip=AudioClip.Create("Abbey threshold | "+row.id,expected,1,48000,false);
                    if(!clip||!clip.SetData(pcm.Samples,0)){if(clip)Object.Destroy(clip);throw new InvalidDataException("Mechanism PCM upload failed");}
                    bank.clips.Add(row.id,new Loaded{Clip=clip,Loop=row.loop,Gain=row.gain});
                }
                bank.ResolveMixer();logger?.Invoke("WARD_MECHANISM_AUDIO_READY:4approved clips, closing creak +5dB PCM only, positional native SFX, max8source mechanisms; saved poses start quietly; accepted timing retained.");
            }
            catch(Exception ex){bank.Dispose();logger?.Invoke("WARD_MECHANISM_AUDIO_UNAVAILABLE: "+ex.Message+"; existing source logic and legacy audio retained.");}
        }
        internal static void Attach(string id,WardingSpawnerArt art)
        {
            var bank=current;if(bank==null||bank.disposed||!art)return;
            if(bank.emitters.Count>=MaximumSources){bank.log?.Invoke("WARD_MECHANISM_AUDIO_LIMIT: source count exceeds8; extra mechanism remains silent.");return;}
            var existing=art.GetComponent<WardingMechanismEmitter>();if(existing)return;
            var emitter=art.gameObject.AddComponent<WardingMechanismEmitter>();
            try{emitter.Bind(bank,art,id);bank.emitters.Add(emitter);}
            catch(Exception ex){emitter.DisposeAudio();Object.Destroy(emitter);bank.log?.Invoke("WARD_MECHANISM_ATTACH_UNAVAILABLE: "+ex.Message);}
        }
        internal Loaded Get(string id)=>clips[id];
        internal AudioMixerGroup ResolveMixer()
        {
            if(disposed)return null;if(mixer)return mixer;if(Time.realtimeSinceStartup<nextMixer)return null;nextMixer=Time.realtimeSinceStartup+2;
            try
            {
                var ambient=AudioMan.instance?AudioMan.instance.m_ambientMixer:null;
                if(ambient&&ambient.audioMixer)mixer=ambient.audioMixer.FindMatchingGroups("SFX").FirstOrDefault(g=>g&&string.Equals(g.name,"SFX",StringComparison.Ordinal));
            }
            catch(Exception ex){if(!mixerPending)log?.Invoke("WARD_MECHANISM_MIXER_PENDING: "+ex.GetType().Name);}
            if(mixer){log?.Invoke("WARD_MECHANISM_MIXER: native SFX borrowed read-only; no mixer or listener settings changed.");mixerPending=false;}
            else if(!mixerPending){mixerPending=true;log?.Invoke("WARD_MECHANISM_MIXER_PENDING: silence until exact native SFX output is ready.");}
            return mixer;
        }
        internal void Remove(WardingMechanismEmitter emitter)=>emitters.Remove(emitter);
        public void Dispose()
        {
            if(disposed)return;disposed=true;
            foreach(var e in emitters.ToArray())if(e){e.DisposeAudio();Object.Destroy(e);}emitters.Clear();
            foreach(var x in clips.Values)if(x.Clip)Object.Destroy(x.Clip);clips.Clear();
            foreach(var lease in leases)lease.Dispose();leases.Clear();mixer=null;if(current==this)current=null;
        }
        internal static void Shutdown()=>current?.Dispose();
    }
    [DefaultExecutionOrder(200)]
    internal sealed class WardingMechanismEmitter:MonoBehaviour
    {
        readonly WardingMechanismSoundPolicy policy=new WardingMechanismSoundPolicy();
        WardingMechanismAudio bank;WardingSpawnerArt art;GameObject audioRoot;bool bound;
        AudioSource door,bar,impact,pin;WardingMechanismAudio.Loaded doorClip,barClip,impactClip,pinClip;
        AudioSource[] voices=Array.Empty<AudioSource>();
        internal void Bind(WardingMechanismAudio owner,WardingSpawnerArt source,string id)
        {
            bank=owner;art=source;policy.Seed(art.PresentedProgress,art.PresentedPin);
            audioRoot=new GameObject("Threshold mechanism audio | "+id);audioRoot.transform.SetParent(transform,false);
            doorClip=bank.Get("door_closing_creak");barClip=bank.Get("bar_lowering_creak");impactClip=bank.Get("bar_slam");pinClip=bank.Get("locking_pin");
            door=Voice("Door strain",doorClip,180);bar=Voice("Bar strain",barClip,180);impact=Voice("Oak seating",impactClip,110);pin=Voice("Pin catch",pinClip,100);
            voices=new[]{door,bar,impact,pin};
            door.transform.position=bar.transform.position=impact.transform.position=art.InnerDoor+Vector3.up*1.3f;pin.transform.position=art.PinPoint;bound=true;
        }
        AudioSource Voice(string name,WardingMechanismAudio.Loaded clip,int priority)
        {
            var node=new GameObject(name);node.transform.SetParent(audioRoot.transform,false);var s=node.AddComponent<AudioSource>();
            s.playOnAwake=false;s.loop=clip.Loop;s.clip=clip.Clip;s.volume=0;s.pitch=1;s.spatialBlend=1;s.dopplerLevel=0;s.spread=0;
            s.minDistance=2;s.maxDistance=26;s.rolloffMode=AudioRolloffMode.Logarithmic;s.priority=priority;return s;
        }
        void LateUpdate()
        {
            if(!bound||!art)return;float dt=Mathf.Min(Time.deltaTime,.25f);var mixer=bank.ResolveMixer();
            var player=Player.m_localPlayer;bool audible=dt>0&&mixer&&player&&(player.transform.position-door.transform.position).sqrMagnitude<26*26;
            var step=policy.Sample(art.PresentedProgress,art.PresentedPin,dt,audible);
            if(!mixer||dt<=0){StopAll();return;} // Never bypass SFX or continue a work loop through game pause.
            foreach(var s in voices)if(s)s.outputAudioMixerGroup=mixer;
            if(!audible){impact.Stop();pin.Stop();}
            Loop(door,step.Phase==WardingMechanismPhase.Door?doorClip.Gain:0,dt);
            Loop(bar,step.Phase==WardingMechanismPhase.Bar?barClip.Gain:0,dt);
            if(step.ImpactGain>0)Play(impact,step.ImpactGain*impactClip.Gain,0);
            if(step.PinStarted)Play(pin,pinClip.Gain,WardingMechanismSoundPolicy.PinStartSample(art.PresentedPin,pinClip.Clip.frequency,pinClip.Clip.samples));
        }
        static void Loop(AudioSource s,float target,float dt)
        {
            if(!s)return;
            if(target>0&&!s.isPlaying){s.UnPause();if(!s.isPlaying)s.Play();}
            s.volume=Mathf.MoveTowards(s.volume,target,dt/.06f);
            if(target==0&&s.volume==0&&s.isPlaying)s.Pause(); // Resume the same long take after a brief work pause.
        }
        static void Play(AudioSource s,float gain,int sample)
        {if(!s)return;s.Stop();s.volume=Mathf.Clamp01(gain);s.pitch=1;s.timeSamples=sample;s.Play();}
        void StopAll(){foreach(var s in voices)if(s){s.Stop();s.volume=0;}}
        internal void DisposeAudio(){if(!bound&& !audioRoot)return;bound=false;StopAll();if(audioRoot)Destroy(audioRoot);audioRoot=null;bank?.Remove(this);bank=null;art=null;}
        void OnDisable(){if(bound){StopAll();if(art)policy.Seed(art.PresentedProgress,art.PresentedPin);}}
        void OnEnable(){if(bound&&art)policy.Seed(art.PresentedProgress,art.PresentedPin);}
        void OnDestroy()=>DisposeAudio();
    }
}
