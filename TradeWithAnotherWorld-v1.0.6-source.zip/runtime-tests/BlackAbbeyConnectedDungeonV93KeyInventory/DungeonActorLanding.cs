using System;
using System.Linq;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        bool actorGeometryReady;
        void ParkDungeonActors()
        {
            actorGeometryReady=false;
            encounterSetupReady=false;
            string world=persistentRun?.worldKey??persistentRunWorld??selectedWorldKey;
            if(!string.IsNullOrEmpty(world)&&!string.IsNullOrEmpty(naturalRunId))DungeonActorResidency.ParkRun(world,naturalRunId);
        }
        internal static bool DungeonActorPositionValid(string world,string run,Vector3 position)
        {
            var owner=persistentOwner;
            return owner&&owner.actorGeometryReady&&owner.gridOrigin.HasValue&&MonkWorldMatches(world)&&owner.naturalRunId==run&&
                FiniteActorPoint(position)&&owner.RunContains(position);
        }
        static bool FiniteActorPoint(Vector3 p)=>!float.IsNaN(p.x)&&!float.IsNaN(p.y)&&!float.IsNaN(p.z)&&
            !float.IsInfinity(p.x)&&!float.IsInfinity(p.y)&&!float.IsInfinity(p.z);
        internal static bool TryDungeonActorLanding(string world,string run,GameObject actor,Vector3 desired,out Vector3 landing)
        {
            landing=default;var owner=persistentOwner;
            if(!actor||!DungeonActorPositionValid(world,run,desired))return false;
            int mask=LayerMask.GetMask("static_solid");if(mask==0)return false;
            if(!Physics.Raycast(desired+Vector3.up*.75f,Vector3.down,out var hit,3f,mask,QueryTriggerInteraction.Ignore)||hit.normal.y<.6f||!hit.collider)return false;
            var t=hit.collider.transform;
            if(!owner.rooms.Values.Any(room=>room.Root&&t.IsChildOf(room.Root.transform))&&!(owner.dungeonArt&&t.IsChildOf(owner.dungeonArt.transform)))return false;
            var cap=actor.GetComponent<CapsuleCollider>();if(!cap)return false;
            Vector3 p=hit.point+Vector3.up*.05f,scale=actor.transform.lossyScale;
            float radius=cap.radius*Mathf.Max(Mathf.Abs(scale.x),Mathf.Abs(scale.z))*.94f;
            float height=Mathf.Max(radius*2,cap.height*Mathf.Abs(scale.y));
            Vector3 center=p+actor.transform.TransformVector(cap.center),extent=Vector3.up*(height*.5f-radius);
            var overlaps=Physics.OverlapCapsule(center+extent,center-extent,radius,LayerMask.GetMask("static_solid","character","character_net","piece","Default"),QueryTriggerInteraction.Ignore);
            if(overlaps.Any(c=>c&&!c.transform.IsChildOf(actor.transform)))return false;
            landing=p;return DungeonActorPositionValid(world,run,landing);
        }
        Vector3? WardingRecoveryAnchor(string id)
        {var view=wardingViews.FirstOrDefault(v=>v.State.id==id);return view?.Art?.ActorExit;}
    }
}
