using System;
using System.Collections;
using System.IO;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        private LoadedRoom inFlightRoom;
        private int renderRefreshDeferral;
        private float nextSpawnProgress;
        private void CancelRoomLoading()
        {
            CancelDoorLoading("Room load cancelled");
            StopAllCoroutines();
            // Explicit ownership cleanup also covers Unity versions/paths that
            // stop nested iterators without running their finally blocks.
            if(inFlightRoom!=null)AbbeyLoadDiagnostics.EndRoom(inFlightRoom.Diagnostic,"cancelled-inflight",inFlightRoom);
            inFlightRoom?.Dispose(); inFlightRoom = null;
            busy = false; renderRefreshDeferral = 0;
            retiringPersistentRun=false;replayingGraveExits=false;nextGraveReplay=0;
            AbbeyLoadDiagnostics.Finish("cancelled",rooms.Values);
        }
        private void LogRoomDetail(string id, string message)
        {
            if (message.StartsWith("CANDLE_FIXTURE:", StringComparison.Ordinal) || message.StartsWith("CANDLE_GROUP:", StringComparison.Ordinal))
                Logger.LogDebug(id + " | " + message);
            else Logger.LogInfo(id + " | " + message);
        }
        private void SpawnProgress(string id, string phase)
        {
            if (Time.unscaledTime < nextSpawnProgress) return;
            nextSpawnProgress = Time.unscaledTime + 1;
            var player = Player.m_localPlayer;
            if (player) player.Message(MessageHud.MessageType.Center, "Preparing Black Abbey: " + id + " (" + phase + ")");
        }
        private void FinishRenderRefreshBatch()
        {
            renderRefreshDeferral = Math.Max(0, renderRefreshDeferral - 1);
            if (renderRefreshDeferral == 0) RefreshRenderBudget();
        }
        private IEnumerator LoadRoomRoutine(CatalogRoomRecord record, string instanceId, Action<bool> completed)
        {
            string key = instanceId ?? record.roomId;
            var diagnostic=AbbeyLoadDiagnostics.BeginRoom(record,key);
            if (rooms.TryGetValue(key, out var existing) && existing.Root)
            { diagnostic?.Event("placed-root-reused");AbbeyLoadDiagnostics.EndRoom(diagnostic,"existing-placed-root-reused",existing);completed(true);yield break; }
            if (existing != null) { existing.Dispose(); rooms.Remove(key); }
            LoadedRoom loaded = null; bool committed = false;
            var result = new RoomLoadScheduling.Result();
            try
            {
                var steps = RoomPackage.LoadSteps(CatalogReader.PackagePath(DataPath, record), record,
                    s => LogRoomDetail(record.roomId, s), value => loaded = value,
                    value => inFlightRoom = value, true, phase => SpawnProgress(key, phase),diagnostic);
                yield return RoomLoadScheduling.Run(steps, result);
                if (result.Error != null) { ReportRoomLoadFailure(record, result.Error); completed(false); yield break; }
                loaded.DoorSourceSha256=VariantFor(loaded)?.doorSourceSha256;
                loaded.InstanceId = key; loaded.Root.name = "BA_" + key + "_" + record.roomId;
                bool sanctum = R09SplitIdentity.IsPiece(record.roomId);
                var setup = new Action[] {
                    () => {
                        var low = RoomPackage.Vector(loaded.Manifest.boundsMin, "boundsMin"); var high = RoomPackage.Vector(loaded.Manifest.boundsMax, "boundsMax");
                        if (Mathf.Max(Mathf.Abs(low.x),Mathf.Abs(high.x),Mathf.Abs(low.z),Mathf.Abs(high.z)) > 100f) throw new InvalidDataException("Room exceeds the test footprint.");
                        loaded.Root.transform.position = gridOrigin.Value + new Vector3((record.Slot % 3) * RoomSpacing,0,(record.Slot / 3) * RoomSpacing);
                        if (!sanctum) loaded.Root.SetActive(true);
                    },
                    () => {
                        R09CandleSocketOverrides.ApplyToRoom(loaded);
                        loaded.FlameCount = TradeWithAnotherWorld.ResinCandleFlame.AttachToRoom(loaded.Root, false);
                    },
                    () => {
                        if (loaded.FlameCount != R09CandleSocketOverrides.ForRoom(loaded.Manifest).Length) throw new InvalidOperationException("Not every source/effective wick received a native flame.");
                        if (sanctum) RoomCandleLighting.Attach(loaded,s => LogRoomDetail(record.roomId,s));
                    },
                    () => {
                        if (sanctum) {
                            bossMusic?.Prepare();
                            // Attach the one shared encounter after BOTH exact pieces are positioned.
                            // Roots remain inactive until their cross-piece source contract passes.
                        }
                        else if (R07InteractionRuntime.Available(loaded.Manifest)) {
                            if (r07Run == null) r07Run = new R07RoomStates<Inventory>(catalog.dungeonSeed ?? Guid.NewGuid().GetHashCode());
                            R07InteractionRuntime.Attach(loaded,CatalogReader.PackagePath(DataPath,record),r07Run.ForRoom(key),RefreshRenderBudget,s => LogRoomDetail(record.roomId,s));
                        }
                        else RoomCandleLighting.Attach(loaded,s => LogRoomDetail(record.roomId,s));
                    },
                    () => R08ShaftRuntime.Attach(loaded,p => p == Player.m_localPlayer && ZNet.instance && ZNet.instance.IsServer() && Matches(p),s => Logger.LogInfo(s)),
                    () => ScriptoriumParchment.Attach(loaded)
                };
                var setupNames=new[]{"instance.position-activate","candles.native-flames","candles.validate-and-boss-lighting","room-specific-fixtures","stairs.runtime-fixtures","scriptorium.parchment"};
                for (int i = 0; i < setup.Length; i++)
                {
                    Exception error = null; var step = System.Diagnostics.Stopwatch.StartNew();
                    try { using(AbbeyLoadDiagnostics.Measure(diagnostic,setupNames[i],"placed-instance"))setup[i](); } catch (Exception ex) { error = ex; }
                    result.MaximumMainStepMilliseconds = Math.Max(result.MaximumMainStepMilliseconds,step.Elapsed.TotalMilliseconds);
                    if (error != null) { ReportRoomLoadFailure(record,error); completed(false); yield break; }
                    SpawnProgress(key,"fixtures " + (i + 1) + "/" + setup.Length); yield return null;
                }
                if (PewBreakContract.Available(record.roomId))
                {
                    if (pewRun == null) pewRun = new PewRunState();
                    var pewWork = new RoomLoadScheduling.Result();
                    using(AbbeyLoadDiagnostics.Wait(diagnostic,"pews.attach-coroutine-inclusive"))
                    yield return RoomLoadScheduling.Run(PewRoomRuntime.AttachSteps(loaded, DataPath, pewRun.ForRoom(key),
                        () => isActiveAndEnabled && !busy && Player.m_localPlayer && ZNet.instance && ZNet.instance.IsServer() && Matches(Player.m_localPlayer),
                        s => LogRoomDetail(record.roomId, s)), pewWork);
                    result.MaximumMainStepMilliseconds = Math.Max(result.MaximumMainStepMilliseconds, pewWork.MaximumMainStepMilliseconds);
                    if (pewWork.Error != null) { ReportRoomLoadFailure(record, pewWork.Error); completed(false); yield break; }
                }
                Exception waxError = null;
                try { using (AbbeyLoadDiagnostics.Measure(diagnostic, "boss-wax.presentation", "placed-instance")) BossWaxRetirement.Attach(loaded, s => LogRoomDetail(record.roomId, s)); }
                catch (Exception error) { waxError = error; }
                if (waxError != null) { ReportRoomLoadFailure(record, waxError); completed(false); yield break; }
                rooms[key] = loaded; inFlightRoom = null; committed = true;
                // Synchronize once after all connected rooms are positioned,
                // or after this standalone load, rather than once per clone.
                if (renderRefreshDeferral == 0)
                    using(AbbeyLoadDiagnostics.Measure(diagnostic,"instance.physics-sync-and-render-refresh","placed-instance")){ Physics.SyncTransforms(); RefreshRenderBudget(); }
                Logger.LogInfo($"ROOM_LOAD_PROFILE: instance={key}; resourceWallMs={result.WallMilliseconds:F1}; largestMainStepMs={result.MaximumMainStepMilliseconds:F1}; yieldedResourceFrames={result.Frames}; managedIO/decode on worker, Unity uploads/cooking on main. Not GPU timing.");
                Print("Loaded " + record.roomId + " â€” " + record.displayName + "."); completed(true);
            }
            finally
            {
                AbbeyLoadDiagnostics.EndRoom(diagnostic,committed?"loaded":"failed-or-cancelled",loaded??inFlightRoom,result);
                if (!committed) { (loaded ?? inFlightRoom)?.Dispose(); inFlightRoom = null; }
            }
        }
        private void ReportRoomLoadFailure(CatalogRoomRecord record, Exception error)
        {
            Logger.LogError(record.roomId + " failed before travel: " + error);
            Print(record.roomId + " could not load; the current floor/return remain available.");
        }
    }
}
