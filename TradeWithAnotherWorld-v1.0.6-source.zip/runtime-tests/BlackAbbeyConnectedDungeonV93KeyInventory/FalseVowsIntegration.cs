using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace BlackAbbeySixRooms
{
    public sealed partial class RuntimeTestPlugin
    {
        private FalseVowsState falseVows;
        private FalseVowsAssets falseVowsAssets;
        private FalseVowsNativePresence falseVowsPresence;
        private readonly HashSet<string> falseVowsFailedLiveDeliveries=new HashSet<string>(StringComparer.Ordinal);
        private float nextFalseVowsRecovery;
        private Player falseVowsObservedPlayer;
        private string falseVowsObservedParticipants;
        private bool falseVowsNeedsNativeScan;
        private Player pendingFalseVowsExitPlayer;
        private string pendingFalseVowsExitRun;
        private Vector3 pendingFalseVowsKeyPosition;
        private Quaternion pendingFalseVowsKeyRotation;
        private float nextFalseVowsExitRetry;
        private bool UsesFalseVowsRoster=>persistentRun==null||persistentRun.falseVows!=null||persistentRun.unrecordedDead!=null;
        private FalseVowsAssets QuestAssets=>falseVowsAssets??(falseVowsAssets=new FalseVowsAssets(DataPath,s=>Logger.LogInfo(s)));
        private void InitializeFalseVows()
        {
            FalseVowsItems.Initialize(id=>id==UnrecordedDeadState.Key?CreateUnrecordedKeyVisual():QuestAssets.CreateItemVisual(id),id=>id==UnrecordedDeadState.Key?UnrecordedKeyIcon():QuestAssets.Icon(id),s=>Logger.LogInfo(s));
            Add("twa_unrecorded_dead_status","Report the saved boss-unlock route and its progress.",false,()=>Print(unrecordedDead==null?"Boss-unlock route: "+(persistentRun?.bossUnlockRoute??"legacy/showcase")+". New dungeons randomly choose their route.":"Unrecorded Dead: wall="+unrecordedDead.WallBroken+"; panel="+unrecordedDead.PanelRemoved+"; key="+unrecordedDead.KeyClaimed+"; boss lock="+unrecordedDead.BossUnlocked+"."));
            Add("twa_false_vows_status","Show the current Abbey evidence quest; existing saved runs keep their original route.",false,()=>Print(falseVows==null?
                "New natural dungeons choose a boss-unlock path at generation. This legacy/showcase run is unchanged.":
                "Three False Vows: book="+falseVows.BookPlaced+"; cabinets="+falseVows.CabinetsUnlocked+"; resolved seals="+falseVows.SolvedMask+"/7; pending native receipts="+(falseVows.Capture().deliveries.Count+falseVows.Capture().consumptions.Count)+"."));
        }
        private static FalseVowsRoomBinding SelectFalseVowsRooms(DungeonPlan plan)
        {
            bool split=plan.Rooms.Any(p=>p.Spec.SourceId==R09SplitIdentity.Chamber);
            var boss=System.Array.FindIndex(plan.Rooms,p=>p.Spec.SourceId==(split?R09SplitIdentity.FalseVowsHall:"R09"));
            if(boss<0)throw new InvalidDataException("Quest route has no boss room.");
            int arena=split?System.Array.FindIndex(plan.Rooms,p=>p.Spec.SourceId==R09SplitIdentity.Chamber):boss;
            var edge=plan.Links.Single(l=>split?l.Kind=="R09BossThreshold"&&(l.A==boss&&l.B==arena||l.B==boss&&l.A==arena):l.A==boss||l.B==boss);
            var nodes=plan.Rooms.Select(p=>new FalseVowsRoomNode(p.Spec.Id,p.Spec.SourceId));
            var edges=plan.Links.Select(l=>new FalseVowsRoomEdge(plan.Rooms[l.A].Spec.Id,plan.Rooms[l.B].Spec.Id));
            return FalseVowsRoomSelector.Select(nodes,edges,"R01",plan.Rooms[boss].Spec.Id,plan.Rooms[edge.A].Spec.Id,plan.Rooms[edge.B].Spec.Id,plan.FalseVowsMinimumHops);
        }
        private void BindFalseVows(DungeonPlan plan,bool isNew)
        {
            falseVowsFailedLiveDeliveries.Clear();falseVowsPresence?.Dispose();falseVowsPresence=null;
            var saved=FalseVowsPersistence.Read(persistentRun.falseVows,persistentRun.runId);
            if(isNew&&plan.BossUnlockRoute!=UnrecordedDeadState.RouteId&&FalseVowsState.SelectedForNewRun(true,plan.Mode))
            {
                falseVows=FalseVowsState.CreateNew(persistentRun.runId,SelectFalseVowsRooms(plan));
                persistentRun.falseVows=JObject.FromObject(falseVows.Capture());
            }
            else falseVows=FalseVowsState.Restore(saved,persistentRun.runId);
            if(falseVows!=null)
            {
                FalseVowsRoomSelector.Validate(falseVows.Rooms,plan.Rooms.Select(p=>new FalseVowsRoomNode(p.Spec.Id,p.Spec.SourceId)),
                    plan.Links.Select(l=>new FalseVowsRoomEdge(plan.Rooms[l.A].Spec.Id,plan.Rooms[l.B].Spec.Id)),"R01");
                if(plan.Rooms.Count(p=>p.Spec.SourceId=="R03")!=1)throw new InvalidDataException("The selected Abbey route requires exactly one broken-saint room.");
                falseVowsPresence=new FalseVowsNativePresence(s=>Logger.LogInfo(s));
                falseVowsPresence.Begin(falseVows.RunId,persistentRun.participants.Select(p=>p.playerId).ToArray());
                falseVowsPresence.AdditionalPresence=StoredShrineEvidence;
                falseVowsObservedPlayer=null;falseVowsObservedParticipants=null;
            }
        }
        private bool CommitFalseVows(FalseVowsSnapshot candidate)
        {
            if(persistentRun==null||!persistentRunBound||falseVows==null||candidate.runId!=persistentRun.runId)return false;
            var prior=persistentRun.falseVows;persistentRun.falseVows=JObject.FromObject(candidate);RequestRunCheckpoint();
            if(SavePersistentRun(true))return true;
            persistentRun.falseVows=prior;return false;
        }
        private bool CanUseFalseVows(Player p)=>isActiveAndEnabled&&!busy&&falseVows!=null&&persistentRunBound&&p&&p==Player.m_localPlayer&&!p.IsDead()&&ZNet.instance&&ZNet.instance.IsServer()&&Matches(p);
        private void PrepareFalseVowsRoom(LoadedRoom room)
        {
            bool quest=falseVows!=null&&FalseVowsRoomSelector.UsesQuestVariant(falseVows.Rooms,room.InstanceId);
            bool ordinarySaint=room.Manifest.roomId=="R03"||room.Manifest.roomId=="R03_complete";
            if(FalseVowsRouteVisibilityPolicy.NeedsInactiveMasks(quest,room.Manifest.roomId)&&
                KitArchitectureProfile.Matches(room.Manifest.sourceSha256,room.Record.manifestSha256))
            {
                QuestAssets.ApplyInactiveRouteMasks(room);
                return;
            }
            if(!quest&&!ordinarySaint)return;
            if(!FalseVowsItems.Ready){FalseVowsItems.Register();if(!FalseVowsItems.Ready)throw new InvalidOperationException("Abbey evidence prefabs are not ready; no travel occurred.");}
            if(room.Root.GetComponent<FalseVowsRoomRuntime>())return;
            var data=QuestAssets.Room(room.Manifest.roomId);if(data==null)throw new InvalidDataException("Missing source-bound quest room export: "+room.Manifest.roomId);
            QuestAssets.ApplyMasks(room);
            FalseVowsRoomRuntime.Attach(room,QuestAssets,data,quest?falseVows:null,CanUseFalseVows,PickupFalseVows,UnlockFalseVows,PlaceFalseVowsBook,OfferFalseVows,s=>Logger.LogInfo(s));
        }
        private bool CanReceiveFalseVows(Player player,string id)
        {
            var prefab=FalseVowsItems.Prefab(id);return prefab&&player&&player.GetInventory().CanAddItem(prefab.GetComponent<ItemDrop>().m_itemData,1);
        }
        private bool DeliverFalseVows(Player player,FalseVowsReceipt receipt)
        {
            bool delivered=FalseVowsItems.TryAdd(player,receipt.itemId,falseVows.RunId,receipt.token,out _);
            if(delivered)falseVowsFailedLiveDeliveries.Remove(receipt.token);else falseVowsFailedLiveDeliveries.Add(receipt.token);
            falseVowsPresence?.Invalidate();return delivered;
        }
        private void PickupFalseVows(Player player,string id,string roomId)
        {
            if(!CanUseFalseVows(player))return;
            string actor=player.GetPlayerID().ToString();
            var receipt=falseVows.Capture().deliveries.SingleOrDefault(r=>r.itemId==id&&r.actorId==actor);
            var result=receipt==null?falseVows.TryPickup(id,actor,roomId,()=>CanReceiveFalseVows(player,id),CommitFalseVows,r=>DeliverFalseVows(player,r)):
                falseVows.TryRecoverDelivery(receipt.token,actor,t=>falseVowsFailedLiveDeliveries.Contains(t)?(bool?)false:falseVowsPresence?.Presence(player,id,t),()=>CanReceiveFalseVows(player,id),CommitFalseVows,r=>DeliverFalseVows(player,r));
            if(result==FalseVowsResult.InventoryFull)player.Message(MessageHud.MessageType.Center,"Make room in your inventory.");
            else if(result==FalseVowsResult.Locked)player.Message(MessageHud.MessageType.Center,"The desk is locked.");
            else if(result==FalseVowsResult.PersistenceFailed)player.Message(MessageHud.MessageType.Center,"The Abbey cannot record your progress yet. Try again shortly.");
            else if(result==FalseVowsResult.DeliveryPending||result==FalseVowsResult.RecoveryHeld)player.Message(MessageHud.MessageType.Center,"Your claim is kept. Make room, then try again when the world has settled.");
            RefreshFalseVowsRooms();
        }
        private bool ConsumeFalseVows(Player player,FalseVowsReceipt receipt)
        {
            var item=FalseVowsItems.Find(player,receipt.itemId,falseVows.RunId,receipt.token);
            bool success=item==null||FalseVowsItems.RemoveExact(player,receipt.itemId,falseVows.RunId,receipt.token,item);
            falseVowsPresence?.Invalidate();return success;
        }
        private void UnlockFalseVows(Player player,string roomId)
        {
            if(!CanUseFalseVows(player))return;
            var result=falseVows.TryUnlockCabinets(player.GetPlayerID().ToString(),roomId,falseVows.Token(FalseVowsState.Key),()=>FalseVowsItems.Has(player,FalseVowsState.Key,falseVows.RunId,falseVows.Token(FalseVowsState.Key)),CommitFalseVows);
            if(result==FalseVowsResult.MissingItem)player.Message(MessageHud.MessageType.Center,"A small iron lock holds the cabinet shut.");
            else if(result==FalseVowsResult.Applied)player.Message(MessageHud.MessageType.Center,"The cabinet lock yields.");
            else if(result==FalseVowsResult.PersistenceFailed)player.Message(MessageHud.MessageType.Center,"The lock resists. Try again shortly.");
            RefreshFalseVowsRooms();
        }
        private void PlaceFalseVowsBook(Player player,string roomId)
        {
            if(!CanUseFalseVows(player))return;
            var result=falseVows.TryPlaceBook(player.GetPlayerID().ToString(),roomId,falseVows.Token(FalseVowsState.Book),()=>FalseVowsItems.Has(player,FalseVowsState.Book,falseVows.RunId,falseVows.Token(FalseVowsState.Book)),CommitFalseVows,r=>ConsumeFalseVows(player,r));
            if(result==FalseVowsResult.MissingItem)player.Message(MessageHud.MessageType.Center,"The empty pan waits for the Abbey's Rule.");
            else if(result==FalseVowsResult.PersistenceFailed)player.Message(MessageHud.MessageType.Center,"The balance will not settle. Try again shortly.");
            RefreshFalseVowsRooms();
        }
        private void OfferFalseVows(Player player,string roomId,ItemDrop.ItemData offered)
        {
            if(!CanUseFalseVows(player))return;
            var id=offered==null?new[]{FalseVowsState.Deposition,FalseVowsState.Purse,FalseVowsState.Seal}.FirstOrDefault(x=>!falseVows.Consumed(x)&&FalseVowsItems.Has(player,x,falseVows.RunId,falseVows.Token(x))):FalseVowsItems.Id(offered);
            if(id==null||FalseVowsState.EvidenceIndex(id)<0){player.Message(MessageHud.MessageType.Center,"The balance waits for proof.");return;}
            if(offered!=null&&!FalseVowsItems.Matches(offered,id,falseVows.RunId,falseVows.Token(id))){player.Message(MessageHud.MessageType.Center,"This proof belongs to another reckoning.");return;}
            var result=falseVows.TryOfferEvidence(player.GetPlayerID().ToString(),roomId,id,falseVows.Token(id),()=>FalseVowsItems.Has(player,id,falseVows.RunId,falseVows.Token(id)),()=>Guid.NewGuid().GetHashCode(),CommitFalseVows,r=>ConsumeFalseVows(player,r));
            if(result==FalseVowsResult.Locked)player.Message(MessageHud.MessageType.Center,"The other pan must bear the Abbey's Rule.");
            else if(result==FalseVowsResult.MissingItem||result==FalseVowsResult.WrongRun)player.Message(MessageHud.MessageType.Center,"This proof does not belong to this reckoning.");
            else if(result==FalseVowsResult.PersistenceFailed)player.Message(MessageHud.MessageType.Center,"The balance will not settle. Your proof is kept.");
            RefreshFalseVowsRooms();
        }
        private void RefreshFalseVowsRooms()
        {foreach(var r in rooms.Values)if(r.Root)r.Root.GetComponent<FalseVowsRoomRuntime>()?.Refresh();}
        private void TickFalseVows(Player player)
        {
            if(pendingFalseVowsExitRun!=null)
            {
                if(falseVows==null||falseVows.RunId!=pendingFalseVowsExitRun||!pendingFalseVowsExitPlayer||player!=pendingFalseVowsExitPlayer)
                {pendingFalseVowsExitRun=null;pendingFalseVowsExitPlayer=null;}
                else if(!RunContains(player.transform.position)&&Time.unscaledTime>=nextFalseVowsExitRetry)
                {
                    nextFalseVowsExitRetry=Time.unscaledTime+1;
                    if(CleanupFalseVowsExit(player,pendingFalseVowsExitRun,pendingFalseVowsKeyPosition,pendingFalseVowsKeyRotation))
                    {pendingFalseVowsExitRun=null;pendingFalseVowsExitPlayer=null;}
                }
            }
            if(falseVows==null||falseVowsPresence==null||!CanUseFalseVows(player))return;
            string participants=string.Join("|",persistentRun.participants.Select(p=>p.playerId).OrderBy(p=>p,StringComparer.Ordinal));
            if(falseVowsObservedPlayer!=player||falseVowsObservedParticipants!=participants)
            {
                falseVowsPresence.Begin(falseVows.RunId,persistentRun.participants.Select(p=>p.playerId).ToArray());
                falseVowsPresence.AdditionalPresence=StoredShrineEvidence;
                falseVowsObservedPlayer=player;falseVowsObservedParticipants=participants;
            }
            // Ordinary carried/stored proof needs no repeated world sweep.
            // Only an unresolved receipt with unknown native presence starts
            // the bounded reconciliation scan.
            if(falseVowsNeedsNativeScan)falseVowsPresence.Tick();
            if(Time.unscaledTime<nextFalseVowsRecovery)return;nextFalseVowsRecovery=Time.unscaledTime+1;
            falseVowsNeedsNativeScan=false;
            string actor=player.GetPlayerID().ToString();var snapshot=falseVows.Capture();
            foreach(var r in snapshot.consumptions.Where(r=>r.actorId==actor))
            {
                // Replay only an already committed consumption, against the
                // exact same-run token, never another ordinary inventory item.
                var item=FalseVowsItems.Find(player,r.itemId,falseVows.RunId,r.token);
                if(item!=null)ConsumeFalseVows(player,r);
                // Retain this bounded receipt. Live absence does not prove a
                // written native profile/world save; replay after rollback.
            }
            foreach(var r in snapshot.deliveries.Where(r=>r.actorId==actor))
            {
                bool? present=falseVowsFailedLiveDeliveries.Contains(r.token)?(bool?)false:falseVowsPresence.Presence(player,r.itemId,r.token);
                if(!present.HasValue){falseVowsNeedsNativeScan=true;continue;}
                falseVows.TryRecoverDelivery(r.token,actor,_=>present,()=>CanReceiveFalseVows(player,r.itemId),CommitFalseVows,x=>DeliverFalseVows(player,x));
                // Keep the receipt until a later native-save reconciliation.
                // Finding a live ItemData is not proof of a written profile.
            }
            RefreshFalseVowsRooms();
        }
        private void ReleaseFalseVowsRun()
        {ReleaseUnrecordedDead();falseVowsPresence?.Dispose();falseVowsPresence=null;falseVows=null;falseVowsObservedPlayer=null;falseVowsObservedParticipants=null;falseVowsNeedsNativeScan=false;falseVowsFailedLiveDeliveries.Clear();pendingFalseVowsExitRun=null;pendingFalseVowsExitPlayer=null;}
        private bool? StoredShrineEvidence(string id,string token)
        {
            if(falseVows==null||r07Run==null||!persistentRunBound)return null;
            foreach(var room in r07Run.ExistingRooms)foreach(var inventory in room.Value.ExistingInventories)
                if(inventory.Value.GetAllItems().Any(item=>FalseVowsItems.Matches(item,id,falseVows.RunId,token)))return true;
            return false;
        }
        private void ShutdownFalseVows()
        {FalseVowsItems.Shutdown();ReleaseFalseVowsRun();ShutdownUnrecordedDead();falseVowsAssets?.Dispose();falseVowsAssets=null;}
    }
}
