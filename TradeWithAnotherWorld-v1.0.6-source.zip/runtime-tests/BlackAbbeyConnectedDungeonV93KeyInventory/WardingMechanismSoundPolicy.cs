using System;
namespace BlackAbbeySixRooms
{
    internal enum WardingMechanismPhase { None, Door, Bar }
    internal struct WardingMechanismSoundStep
    {
        internal WardingMechanismPhase Phase;
        internal bool DoorClosed, BarsSeated, PinStarted;
        internal float ImpactGain => BarsSeated ? 1f : DoorClosed ? .65f : 0;
    }
    // Presentation only. No spawn clock, saved state or native movement writes.
    internal sealed class WardingMechanismSoundPolicy
    {
        internal const float DoorEnd = 92f / 132f, PinSeconds = .4f;
        internal const int PinImpactSample = 73200; // Approved clip's strongest10ms contact at1.525s.
        const float Epsilon = .0000001f, Rearm = .005f, GapGrace = .05f;
        float progress, pin, idle;
        bool seeded, doorArmed, barArmed, pinArmed;
        WardingMechanismPhase lastMoving;
        static void Valid(float p,float v)
        {
            if(float.IsNaN(p)||float.IsInfinity(p)||p<0||p>1||float.IsNaN(v)||float.IsInfinity(v)||v<0||v>1)
                throw new ArgumentOutOfRangeException("Finite mechanism pose required");
        }
        internal void Seed(float p,float v)
        {
            Valid(p,v);progress=p;pin=v;idle=GapGrace;lastMoving=WardingMechanismPhase.None;seeded=true;
            doorArmed=p<DoorEnd-Epsilon;barArmed=p<1-Epsilon;pinArmed=v<=Epsilon;
        }
        internal WardingMechanismSoundStep Sample(float p,float v,float dt,bool audible)
        {
            Valid(p,v);
            if(float.IsNaN(dt)||float.IsInfinity(dt)||dt<0||dt>1)throw new ArgumentOutOfRangeException(nameof(dt));
            if(!seeded){Seed(p,v);return default;}
            float change=p-progress;bool forward=change>Epsilon;
            bool door=doorArmed&&forward&&progress<DoorEnd&&p>=DoorEnd;
            bool bar=barArmed&&forward&&progress<1&&p>=1;
            bool locking=pinArmed&&v>pin+Epsilon;
            if(door)doorArmed=false;if(bar)barArmed=false;if(locking)pinArmed=false;
            if(p<DoorEnd-Rearm)doorArmed=true;if(p<1-Rearm)barArmed=true;if(v<=Epsilon)pinArmed=true;
            if(forward)
            {
                idle=0;
                lastMoving=p<DoorEnd?WardingMechanismPhase.Door:p>DoorEnd&&p<1?WardingMechanismPhase.Bar:WardingMechanismPhase.None;
            }
            else if(change< -Epsilon){idle=GapGrace;lastMoving=WardingMechanismPhase.None;}
            else idle=Math.Min(GapGrace,idle+dt);
            var phase=audible&&dt>0&&idle<GapGrace?lastMoving:WardingMechanismPhase.None;
            progress=p;pin=v;
            return new WardingMechanismSoundStep{Phase=phase,DoorClosed=audible&&dt>0&&door,BarsSeated=audible&&dt>0&&bar,PinStarted=audible&&dt>0&&locking};
        }
        internal static int PinStartSample(float displayedPin,int rate,int frames)
        {
            Valid(1,displayedPin);
            int at=PinImpactSample-(int)Math.Round((1-displayedPin)*PinSeconds*rate);
            return Math.Max(0,Math.Min(frames-1,at));
        }
    }
}
