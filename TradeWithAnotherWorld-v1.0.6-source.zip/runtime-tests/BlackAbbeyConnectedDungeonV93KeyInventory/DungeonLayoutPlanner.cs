using System;
using System.Collections.Generic;
using System.Linq;

namespace BlackAbbeySixRooms
{
    // Pure geometry: no Unity objects, world writes, enemies or game RNG.
    internal readonly struct PlanPoint
    {
        internal readonly double X, Z;
        internal PlanPoint(double x, double z) { X=x; Z=z; }
        internal static PlanPoint Rotate(PlanPoint p,int q)
        { switch ((q%4+4)%4) { case 1:return new PlanPoint(p.Z,-p.X); case 2:return new PlanPoint(-p.X,-p.Z); case 3:return new PlanPoint(-p.Z,p.X); default:return p; } }
        public static PlanPoint operator +(PlanPoint a,PlanPoint b)=>new PlanPoint(a.X+b.X,a.Z+b.Z);
        public static PlanPoint operator -(PlanPoint a,PlanPoint b)=>new PlanPoint(a.X-b.X,a.Z-b.Z);
        public static PlanPoint operator *(PlanPoint a,double k)=>new PlanPoint(a.X*k,a.Z*k);
        internal double Length=>Math.Sqrt(X*X+Z*Z);
    }
    internal sealed class DungeonRoomSpec
    {
        internal string Id;
        private string sourceId;
        // Id identifies a loaded instance; source identity never changes its
        // authored ports, material/door bindings or full render reservation.
        internal string SourceId { get => string.IsNullOrEmpty(sourceId) ? Id : sourceId; set => sourceId=value; }
        private string assetId;
        internal string AssetId { get => string.IsNullOrEmpty(assetId) ? SourceId : assetId; set => assetId=value; }
        internal PortRecord[] Ports;
        internal double[] Bounds; // minX,minZ,maxX,maxZ; conservative complete render envelope
        internal double[] BoundsY; // actual full height, including the R08 deep shaft
        // Complete source-bound component boxes [minX,minY,minZ,maxX,maxY,maxZ].
        // Null retains the exact historical single-envelope collision behavior.
        internal double[][] Reservations;
        internal bool KitConnectedExteriorCollar;
        internal bool SplitBossProxy;
    }
    internal static class DungeonRoomSpecFactory
    {
        // Runtime and regression tests must use this identical conversion of
        // the CURRENT manifest. Authored floor footprints omit roof overhangs.
        internal static DungeonRoomSpec FromManifest(PackageManifest manifest,string assetId=null)
        {
            if(manifest==null||manifest.boundsMin?.Length!=3||manifest.boundsMax?.Length!=3||
                manifest.boundsMin.Concat(manifest.boundsMax).Any(v=>float.IsNaN(v)||float.IsInfinity(v))||
                Enumerable.Range(0,3).Any(i=>manifest.boundsMin[i]>=manifest.boundsMax[i])||
                Enumerable.Range(0,3).Sum(i=>Math.Pow((double)manifest.boundsMax[i]-manifest.boundsMin[i],2))>40000)
                throw new ArgumentException("Complete finite full source bounds are required for "+manifest?.roomId+".");
            var spec=new DungeonRoomSpec{Id=manifest.roomId,SourceId=manifest.roomId,Ports=manifest.ports,
                Bounds=new double[]{manifest.boundsMin[0],manifest.boundsMin[2],manifest.boundsMax[0],manifest.boundsMax[2]},
                BoundsY=new double[]{manifest.boundsMin[1],manifest.boundsMax[1]}};
            KitPlanningReservationPolicy.Apply(spec,manifest.sourceSha256,assetId??manifest.roomId);return spec;
        }
    }
    internal sealed class DungeonPlanningDiagnostics
    {
        internal int Attempts, CandidatePlacements, RoomOverlapRejections, PassageRejections, CrossingRejections, BudgetExhaustions, MaximumPlaced;
        internal int RosterAttempts, RosterRejections, SelectedRoomCount;
        internal int ClosedLoops;
        internal int RouteAttempts,RouteMatches,RouteContinuations,RouteBranchLimits;
        internal int NormalTargetRooms,ExtensionRooms,ExtensionAttempts,ThirdLoopNormalFailures;
        internal string ExtensionReason="none";
        internal int BossDirectAttempts,BossNormalFailures,BossAnchorAttempts,BossExtensionAttempts,BossExtensionRooms,BossAnchorDepth;
        internal string BossExtensionReason="none",BossAnchorRoomId,BossAnchorPortId;
        public override string ToString()=>"attempts="+Attempts+"; candidates="+CandidatePlacements+"; roomOverlapRejects="+RoomOverlapRejections+
            "; passageRejects="+PassageRejections+"; crossingRejects="+CrossingRejections+"; budgetExhaustions="+BudgetExhaustions+"; maximumPlaced="+MaximumPlaced+
            (RosterAttempts>0?"; rosterAttempts="+RosterAttempts+"; rosterRejects="+RosterRejections+"; selectedRooms="+SelectedRoomCount+"; closedLoops="+ClosedLoops+"; routeAttempts="+RouteAttempts+"; exactClosureMatches="+RouteMatches+"; downstreamAlternatives="+RouteContinuations+"; routeBranchLimits="+RouteBranchLimits+
                "; normalTarget="+NormalTargetRooms+"; thirdLoopNormalFailures="+ThirdLoopNormalFailures+"; extensionAttempts="+ExtensionAttempts+"; thirdExtensionRooms="+ExtensionRooms+"; extensionReason="+ExtensionReason+
                "; bossAnchor="+BossAnchorRoomId+"/"+BossAnchorPortId+"; bossAnchorDepth="+BossAnchorDepth+"; bossDirectAttempts="+BossDirectAttempts+"; bossDirectFailures="+BossNormalFailures+
                "; bossExtensionAttempts="+BossExtensionAttempts+"; bossExtensionRooms="+BossExtensionRooms+"; bossExtensionReason="+BossExtensionReason:"");
    }
    internal sealed class DungeonPlacement
    {
        internal DungeonRoomSpec Spec;
        internal int QuarterTurns;
        internal PlanPoint Position;
        internal double Elevation;
        internal double Height(float[] a)=>Elevation+a[1];
        internal double LowY=>Elevation+(Spec.BoundsY==null?-.25:Spec.BoundsY[0]);
        internal double HighY=>Elevation+(Spec.BoundsY==null?10:Spec.BoundsY[1]);
        internal PlanPoint Point(float[] a)=>Position+PlanPoint.Rotate(new PlanPoint(a[0],a[2]),QuarterTurns);
        internal PlanPoint Normal(PortRecord p)=>PlanPoint.Rotate(new PlanPoint(p.outward[0],p.outward[2]),QuarterTurns);
        internal PlanPoint Outer(PortRecord p)=>Point(p.position)+Normal(p)*p.depth;
        internal double[] Envelope()
            => EnvelopeOf(Spec.Bounds);
        private double[] EnvelopeOf(double[] b)
        {
            // Exact cardinal AABB, retaining the same corner arithmetic without
            // allocating four corner objects and repeated LINQ enumerators for
            // every candidate/overlap check in the larger roster.
            switch((QuarterTurns%4+4)%4)
            {
                case 1:return new[]{Position.X+b[1],Position.Z-b[2],Position.X+b[3],Position.Z-b[0]};
                case 2:return new[]{Position.X-b[2],Position.Z-b[3],Position.X-b[0],Position.Z-b[1]};
                case 3:return new[]{Position.X-b[3],Position.Z+b[0],Position.X-b[1],Position.Z+b[2]};
                default:return new[]{Position.X+b[0],Position.Z+b[1],Position.X+b[2],Position.Z+b[3]};
            }
        }
        internal IEnumerable<Tuple<double[],double,double>> Volumes()
        {
            if (Spec.Reservations == null) { yield return Tuple.Create(Envelope(),LowY,HighY); yield break; }
            foreach (var b in Spec.Reservations)
                yield return Tuple.Create(EnvelopeOf(new[]{b[0],b[2],b[3],b[5]}),Elevation+b[1],Elevation+b[4]);
        }
    }
    internal sealed class DungeonLink
    {
        internal int A,B;
        internal PortRecord PortA,PortB;
        internal PlanPoint Start,End;
        internal double Elevation;
        internal bool IsLoop;
        internal string Kind;
        internal double LowY=>Elevation-.25;
        internal double HighY=>Elevation+Math.Max(PortA.height,PortB.height)+(Kind==R08KnightReturnPolicy.SleeveKind?.35:.25);
        internal double[] Envelope()
        { return new[]{Math.Min(Start.X,End.X)-2.0,Math.Min(Start.Z,End.Z)-2.0,Math.Max(Start.X,End.X)+2.0,Math.Max(Start.Z,End.Z)+2.0}; }
    }
    internal sealed class DungeonPlan
    {
        internal int Seed;
        internal string Mode="showcase";
        internal DungeonPlacement[] Rooms;
        internal DungeonLink[] Links;
        internal string EntryPort;
        internal int FalseVowsMinimumHops;
        // Saved policy identity is separate from the unchanged spatial fingerprint.
        internal int GenerationRevision;
        internal int KnightReturnLoopRevision;
        internal string BossUnlockRoute;
        internal DungeonPlanningDiagnostics Diagnostics;
        internal int CycleRank=>Links.Length-Rooms.Length+1;
        internal bool IsLinked(int room,string port)=>Links.Any(l=>l.A==room&&l.PortA.id==port||l.B==room&&l.PortB.id==port);
    }
    internal static class DungeonLayoutPlanner
    {
        internal const double JointClearance=.02;
        internal static double JointGap(PortRecord a,PortRecord b)=>StoneDoorwayJoinPolicy.JointGap(a,b);
        internal static double ThresholdGap(PortRecord a,PortRecord b)=>(double)a.depth+b.depth+JointGap(a,b);
        internal static bool Overlap(double[] a,double[] b)=>Math.Min(a[2],b[2])-Math.Max(a[0],b[0])>.015&&Math.Min(a[3],b[3])-Math.Max(a[1],b[1])>.015;
        internal static bool Overlap3D(double[] a,double lowA,double highA,double[] b,double lowB,double highB)=>Overlap(a,b)&&Math.Min(highA,highB)-Math.Max(lowA,lowB)>.015;
        internal static bool OverlapsRoom(double[] box,double low,double high,DungeonPlacement room)
        {
            if(!Overlap3D(box,low,high,room.Envelope(),room.LowY,room.HighY))return false;
            if(room.Spec.Reservations==null)return true;
            // Move one query into source-local space. Do not allocate/rotate
            // thousands of cell boxes for every candidate against this room.
            var a=PlanPoint.Rotate(new PlanPoint(box[0]-room.Position.X,box[1]-room.Position.Z),-room.QuarterTurns);
            var b=PlanPoint.Rotate(new PlanPoint(box[2]-room.Position.X,box[3]-room.Position.Z),-room.QuarterTurns);
            double minX=Math.Min(a.X,b.X),maxX=Math.Max(a.X,b.X),minZ=Math.Min(a.Z,b.Z),maxZ=Math.Max(a.Z,b.Z);
            low-=room.Elevation;high-=room.Elevation;
            foreach(var volume in room.Spec.Reservations)
                if(Math.Min(maxX,volume[3])-Math.Max(minX,volume[0])>.015&&
                    Math.Min(maxZ,volume[5])-Math.Max(minZ,volume[2])>.015&&
                    Math.Min(high,volume[4])-Math.Max(low,volume[1])>.015)return true;
            return false;
        }
        internal static bool RoomsOverlap(DungeonPlacement a,DungeonPlacement b)
        {
            if(!Overlap3D(a.Envelope(),a.LowY,a.HighY,b.Envelope(),b.LowY,b.HighY))return false;
            if(a.Spec.Reservations==null&&b.Spec.Reservations==null)return true;
            if(a.Spec.Reservations==null)return OverlapsRoom(a.Envelope(),a.LowY,a.HighY,b);
            if(b.Spec.Reservations==null)return OverlapsRoom(b.Envelope(),b.LowY,b.HighY,a);
            return a.Volumes().Any(v=>OverlapsRoom(v.Item1,v.Item2,v.Item3,b));
        }
        private static void Shuffle<T>(IList<T> list,Random random)
        { for(int i=list.Count-1;i>0;i--){int j=random.Next(i+1);T x=list[i];list[i]=list[j];list[j]=x;} }
        private static DungeonRoomSpec[] ValidateSpecs(IEnumerable<DungeonRoomSpec> input)
        {
            var specs=input?.ToArray()??Array.Empty<DungeonRoomSpec>();
            if(specs.Length<2||specs.Any(s=>s==null||string.IsNullOrWhiteSpace(s.Id)||string.IsNullOrWhiteSpace(s.SourceId)||s.Ports==null||s.Ports.Length<1||s.Bounds==null||s.Bounds.Length!=4||s.Bounds.Any(v=>double.IsNaN(v)||double.IsInfinity(v))||s.Bounds[0]>=s.Bounds[2]||s.Bounds[1]>=s.Bounds[3])||specs.Select(s=>s.Id).Distinct().Count()!=specs.Length)throw new ArgumentException("Complete unique room definitions and at least one port are required.");
            foreach(var s in specs)foreach(var p in s.Ports)
                if(p==null||string.IsNullOrWhiteSpace(p.id)||s.Ports.Count(q=>q?.id==p.id)!=1||p.position?.Length!=3||p.outward?.Length!=3||p.position.Concat(p.outward).Concat(new[]{p.width,p.height,p.depth}).Any(v=>float.IsNaN(v)||float.IsInfinity(v))||p.width<2.4f||p.height<3f||p.depth<0||p.depth>1&&!(s.AssetId=="R08-UD"&&StoneDoorwayJoinPolicy.IsLongPort(p))||Math.Abs(p.position[1])>100||!((Math.Abs(Math.Abs(p.outward[0])-1)<.001&&Math.Abs(p.outward[2])<.001)||(Math.Abs(Math.Abs(p.outward[2])-1)<.001&&Math.Abs(p.outward[0])<.001))||Math.Abs(p.outward[1])>.001)
                    throw new ArgumentException("Unsupported connector dimensions or noncardinal threshold.");
            if(specs.Any(s=>s.BoundsY!=null&&(s.BoundsY.Length!=2||s.BoundsY.Any(v=>double.IsNaN(v)||double.IsInfinity(v))||s.BoundsY[0]>=s.BoundsY[1])))throw new ArgumentException("Invalid room height envelope.");
            if(specs.Where(s=>s.SourceId=="R08"&&s.AssetId==s.SourceId).Any(stair=>stair.Ports.Length!=2||Math.Abs(stair.Ports.Min(p=>p.position[1]))>.001||Math.Abs(stair.Ports.Max(p=>p.position[1])-10.8)>.001||stair.BoundsY==null))throw new ArgumentException("Every R08 requires the actual lower0/upper10.8m thresholds and full shaft height.");
            foreach(var spec in specs){UnrecordedDeadGeneration.ValidateReservations(spec);if(spec.SplitBossProxy)R09SplitPlanning.RequireSearchProxy(spec);else if(spec.AssetId!=spec.SourceId)UnrecordedDeadGeneration.ValidateVariant(new DungeonRoomSpec{Id=spec.SourceId,SourceId=spec.SourceId,AssetId=spec.AssetId,Ports=spec.Ports,Bounds=spec.Bounds,BoundsY=spec.BoundsY,Reservations=spec.Reservations});}
            var first=specs.SingleOrDefault(s=>s.Id=="R01"&&s.SourceId=="R01");
            if(first==null||specs.Where(s=>s.SourceId=="R01").Any(r=>r.Ports.Length<2||r.Ports.Count(p=>p.outward[2]<-.9f)!=1))throw new ArgumentException("R01 must retain its original south entrance and at least one interior port.");
            return specs;
        }
        // Explicit source showcase: retain its exact seeded all-room behavior.
        internal static DungeonPlan Generate(IEnumerable<DungeonRoomSpec> input,int seed)
        {
            var specs=ValidateSpecs(input);
            var stairs=specs.Where(s=>s.SourceId=="R08").ToArray();
            var first=specs.Single(s=>s.Id=="R01"&&s.SourceId=="R01");
            var entrance=first.Ports.Single(p=>p.outward[2]<-.9f);
            var diagnostics=new DungeonPlanningDiagnostics{MaximumPlaced=1};
            for(int attempt=0;attempt<64;attempt++)
            {
                diagnostics.Attempts++;
                var random=new Random(unchecked(seed+attempt*104729));var order=specs.Where(s=>s!=first).ToList();Shuffle(order,random);
                // Keep connecting rooms available before attaching terminal
                // shrines. Existing all-multiport catalogs retain their same
                // seeded shuffle/order; a one-port room is a legitimate leaf.
                order=order.OrderBy(s=>s.Ports.Length==1?1:0).ToList();
                // The test deliberately includes the stair and its upper room;
                // its two ports must both be connected, rather than a barred
                // upper landing that cannot test the elevation transition.
                foreach(var stair in stairs.Reverse()){order.Remove(stair);order.Insert(0,stair);}
                var placed=new List<DungeonPlacement>{new DungeonPlacement{Spec=first,Position=new PlanPoint(0,0)}};var links=new List<DungeonLink>();int budget=10000;
                if(Add(0,order,placed,links,entrance.id,random,ref budget,diagnostics))return new DungeonPlan{Seed=seed,Mode="showcase",Rooms=placed.ToArray(),Links=links.ToArray(),EntryPort=entrance.id,Diagnostics=diagnostics};
            }
            throw new InvalidOperationException("Could not fit all source rooms without overlap; seed="+seed+"; "+diagnostics+"; current floors were preserved.");
        }
        internal static DungeonPlan GenerateNatural(IEnumerable<DungeonRoomSpec> input,int seed)
            => GenerateNatural(input,seed,false);
        internal static DungeonPlan GenerateNatural(IEnumerable<DungeonRoomSpec> input,int seed,bool oneBrokenSaint)
            => GenerateNatural(input,seed,oneBrokenSaint,0);
        internal static DungeonPlan GenerateNatural(IEnumerable<DungeonRoomSpec> input,int seed,bool oneBrokenSaint,int minimumQuestHops)
            => GenerateNatural(input,seed,oneBrokenSaint,minimumQuestHops,null);
        internal static DungeonPlan GenerateNatural(IEnumerable<DungeonRoomSpec> input,int seed,bool oneBrokenSaint,int minimumQuestHops,IReadOnlyDictionary<string,DungeonRoomSpec> variants)
            =>GenerateNaturalCore(input,seed,oneBrokenSaint,minimumQuestHops,variants,false);
        internal static DungeonPlan GenerateNaturalKnightLoop(IEnumerable<DungeonRoomSpec> input,int seed,IReadOnlyDictionary<string,DungeonRoomSpec> variants)
            =>GenerateNaturalCore(input,seed,false,0,variants,true);
        private static DungeonPlan GenerateNaturalCore(IEnumerable<DungeonRoomSpec> input,int seed,bool oneBrokenSaint,int minimumQuestHops,IReadOnlyDictionary<string,DungeonRoomSpec> variants,bool knightLoop)
        {
            if(minimumQuestHops!=0&&minimumQuestHops!=4||minimumQuestHops>0&&!oneBrokenSaint)throw new ArgumentOutOfRangeException(nameof(minimumQuestHops));
            var canonical=ValidateSpecs(input);NaturalDungeonRoster.ValidateCanonical(canonical);
            var diagnostics=new DungeonPlanningDiagnostics{MaximumPlaced=1};string lastRoster="none";
            for(int rosterAttempt=0;rosterAttempt<NaturalDungeonRoster.MaximumRosterAttempts;rosterAttempt++)
            {
                diagnostics.RosterAttempts++;
                var selected=NaturalDungeonRoster.Select(canonical,seed,rosterAttempt,oneBrokenSaint);
                if(selected==null){diagnostics.RosterRejections++;continue;}
                selected=UnrecordedDeadGeneration.ApplyVariants(selected,variants);
                var specs=ValidateSpecs(selected);diagnostics.SelectedRoomCount=specs.Length;
                lastRoster=string.Join(",",specs.Select(s=>s.Id+":"+s.SourceId));
                var first=specs.Single(s=>s.Id=="R01"&&s.SourceId=="R01");var entrance=first.Ports.Single(p=>p.outward[2]<-.9f);
                for(int attempt=0;attempt<NaturalDungeonRoster.MaximumLayoutAttempts;attempt++)
                {
                    diagnostics.Attempts++;
                    diagnostics.NormalTargetRooms=specs.Length;diagnostics.ExtensionRooms=0;diagnostics.ExtensionReason="none";
                    diagnostics.BossExtensionRooms=0;diagnostics.BossExtensionReason="none";diagnostics.BossAnchorRoomId=diagnostics.BossAnchorPortId=null;diagnostics.BossAnchorDepth=0;
                    var random=new Random(unchecked(seed+rosterAttempt*15485863+attempt*104729));
                    var pool=specs.Where(s=>s!=first&&s.SourceId!="R09").ToList();Shuffle(pool,random);
                    var placed=new List<DungeonPlacement>{new DungeonPlacement{Spec=first,Position=new PlanPoint(0,0)}};
                    var links=new List<DungeonLink>();int budget=NaturalDungeonRoster.PlacementBudget;
                    int loopCount=NaturalDungeonRoster.LoopCount(seed);
                    if(loopCount>0)
                    {
                        int last=0;bool okay=true;
                        int prefix=random.Next(4);
                        for(int i=0;i<prefix&&okay;i++)okay=AppendFromPool(pool,s=>s.SourceId=="R01"||s.SourceId=="R02"||!knightLoop&&s.SourceId=="R08",last,placed,links,entrance.id,random,ref budget,diagnostics,out last);
                        if(!okay||!AppendFromPool(pool,s=>s.SourceId=="R04",last,placed,links,entrance.id,random,ref budget,diagnostics,out int anchor))continue;
                        last=anchor;
                        // The backbone and both return routes share the same
                        // finite room allowance. Small rosters reserve more of
                        // it for actual closures instead of a long first spine.
                        int middle=1+random.Next(specs.Length<24?2:3);
                        for(int i=0;i<middle&&okay;i++)okay=AppendFromPool(pool,s=>s.Ports.Length>=2&&s.SourceId!="R08"&&s.SourceId!="R04",last,placed,links,entrance.id,random,ref budget,diagnostics,out last);
                        if(!okay||!AppendFromPool(pool,s=>s.SourceId=="R03"||s.SourceId=="R03_complete"||s.SourceId=="R04",last,placed,links,entrance.id,random,ref budget,diagnostics,out int other,true))continue;
                        // Tight small rosters benefit from a few alternate
                        // closures. Larger rosters have spare route pieces;
                        // prefer a new spine over a deep three-cycle search.
                        var search=new RouteNetworkSearch{RemainingAlternatives=specs.Length<24?32:loopCount-1,NormalSpecs=specs,WantedCycles=loopCount,OneBrokenSaint=oneBrokenSaint};
                        if(!CloseRouteNetwork(pool,placed,links,entrance.id,random,ref budget,diagnostics,loopCount,canonical,search,anchor,other))continue;
                    }
                    var order=pool.ToList();Shuffle(order,random);
                    // Leaves follow connecting rooms, but stairs retain their
                    // seeded random positions rather than fixed early slots.
                    order=order.OrderBy(s=>s.Ports.Length==1?1:0).ToList();
                    if(knightLoop)
                    {
                        var stair=order.Single(s=>s.AssetId=="R08-UD");order.Remove(stair);
                        var source=canonical.Single(s=>s.SourceId=="R04");
                        var junction=new DungeonRoomSpec{Id="KNIGHT_LOOP_JUNCTION",SourceId=source.SourceId,Ports=source.Ports.ToArray(),Bounds=source.Bounds.ToArray(),BoundsY=source.BoundsY.ToArray(),Reservations=source.Reservations?.Select(v=>v.ToArray()).ToArray(),KitConnectedExteriorCollar=source.KitConnectedExteriorCollar};
                        order.Insert(0,junction);order.Insert(0,stair);
                    }
                    order.Add(specs.Single(s=>s.SourceId=="R09"));
                    if(Add(0,order,placed,links,entrance.id,random,ref budget,diagnostics,true,true,new NaturalCompletion{Canonical=canonical,NormalSpecs=specs,OneBrokenSaint=oneBrokenSaint,KnightLoop=knightLoop,Seed=seed}))
                    {
                        diagnostics.ClosedLoops=links.Count-placed.Count+1;
                        if(diagnostics.ClosedLoops!=loopCount+(knightLoop?1:0))throw new InvalidOperationException("A route search changed the selected loop target.");
                        int extras=placed.Count(p=>ThirdLoopExtensionPolicy.IsExtraId(p.Spec.Id)),bossExtras=placed.Count(p=>BossConnectionExtensionPolicy.IsExtraId(p.Spec.Id));
                        if(placed.Count!=specs.Length+extras+bossExtras+placed.Count(p=>p.Spec.Id.StartsWith("KNIGHT_LOOP_",StringComparison.Ordinal))||placed.Count>ThirdLoopExtensionPolicy.MaximumRooms||
                            extras>0&&(loopCount!=3||!ThirdLoopExtensionPolicy.Accepts(specs.Length,extras))||
                            bossExtras>0&&!BossConnectionExtensionPolicy.Accepts(specs.Length,extras,bossExtras))throw new InvalidOperationException("Only the third route and necessary boss approach may exceed the normal room target.");
                        diagnostics.ExtensionRooms=extras;diagnostics.ExtensionReason=extras>0?ThirdLoopExtensionPolicy.Reason:"none";
                        diagnostics.BossExtensionRooms=bossExtras;diagnostics.BossExtensionReason=bossExtras>0?BossConnectionExtensionPolicy.Reason:"none";
                        var result=new DungeonPlan{Seed=seed,Mode="natural",Rooms=placed.ToArray(),Links=links.ToArray(),EntryPort=entrance.id,Diagnostics=diagnostics,FalseVowsMinimumHops=minimumQuestHops};
                        if(minimumQuestHops>0)
                        {
                            int boss=Array.FindIndex(result.Rooms,p=>p.Spec.SourceId=="R09");var gate=result.Links.Single(l=>l.A==boss||l.B==boss);
                            if(!FalseVowsRoomSelector.TrySelect(result.Rooms.Select(p=>new FalseVowsRoomNode(p.Spec.Id,p.Spec.SourceId)),
                                result.Links.Select(l=>new FalseVowsRoomEdge(result.Rooms[l.A].Spec.Id,result.Rooms[l.B].Spec.Id)),"R01",result.Rooms[boss].Spec.Id,
                                result.Rooms[gate.A].Spec.Id,result.Rooms[gate.B].Spec.Id,minimumQuestHops,out _))continue;
                        }
                        return result;
                    }
                }
            }
            throw new InvalidOperationException("Could not fit a natural source roster without overlap; seed="+seed+"; "+diagnostics+"; lastRoster="+lastRoster+"; current floors were preserved.");
        }
        private static bool Used(List<DungeonLink> links,int room,PortRecord port)=>links.Any(l=>l.A==room&&l.PortA.id==port.id||l.B==room&&l.PortB.id==port.id);
        private sealed class RouteNetworkSearch
        {
            internal int RemainingAlternatives;
            internal int WantedCycles;
            internal DungeonRoomSpec[] NormalSpecs;
            internal bool OneBrokenSaint;
            internal readonly HashSet<string> Failed=new HashSet<string>(StringComparer.Ordinal);
        }
        private static bool CloseRouteNetwork(List<DungeonRoomSpec> pool,List<DungeonPlacement> placed,List<DungeonLink> links,string entrance,Random random,ref int budget,DungeonPlanningDiagnostics diagnostics,int remaining,DungeonRoomSpec[] canonical,RouteNetworkSearch search,int anchor=-1,int other=-1)
        {
            if(--budget<=0){budget=0;return false;}
            string signature=remaining+"|"+string.Join(";",placed.Select(p=>p.Spec.Id+":"+p.QuarterTurns+":"+Math.Round(p.Position.X*10000)+":"+Math.Round(p.Position.Z*10000)+":"+Math.Round(p.Elevation*10000)))+"|"+
                string.Join(";",links.Select(l=>l.A+":"+l.PortA.id+":"+l.B+":"+l.PortB.id))+"|"+string.Join(",",pool.Select(s=>s.Id));
            if(search.Failed.Contains(signature))return false;
            Func<int,int> continuation=null;
            if(remaining>1)continuation=available=>
            {
                // A few alternative closures are useful; thousands of nearly
                // equivalent first-loop solutions are not. Restart a different
                // spatial spine when this deterministic branch limit is spent.
                if(search.RemainingAlternatives--<=0){diagnostics.RouteBranchLimits++;return -1;}
                diagnostics.RouteContinuations++;
                int next=available;bool okay=CloseRouteNetwork(pool,placed,links,entrance,random,ref next,diagnostics,remaining-1,canonical,search);
                return okay?next:-Math.Max(0,next)-1;
            };
            bool success=DungeonRouteClosure.TryClose(pool,placed,links,entrance,random,ref budget,diagnostics,anchor,other,remaining>1,continuation,canonical);
            if(!success&&remaining==1&&search.NormalSpecs!=null&&ThirdLoopExtensionPolicy.Eligible(search.NormalSpecs.Length,search.WantedCycles,links.Count-placed.Count+1,true,search.NormalSpecs.Length))
            {
                diagnostics.ThirdLoopNormalFailures++;
                success=TryThirdLoopExtension(canonical,search.NormalSpecs,pool,placed,links,entrance,random,ref budget,diagnostics,search.WantedCycles,search.NormalSpecs.Length,true,search.OneBrokenSaint);
            }
            if(!success&&search.Failed.Count<2048)search.Failed.Add(signature);return success;
        }
        internal static bool TryThirdLoopExtension(DungeonRoomSpec[] canonical,DungeonRoomSpec[] normalSpecs,List<DungeonRoomSpec> pool,List<DungeonPlacement> placed,List<DungeonLink> links,string entrance,Random random,ref int budget,DungeonPlanningDiagnostics diagnostics,int wantedCycles,int normalTarget,bool normalClosureFailed,bool oneBrokenSaint=false)
        {
            if(normalSpecs==null||pool==null||placed==null||links==null||random==null||diagnostics==null||
                !ThirdLoopExtensionPolicy.Eligible(normalTarget,wantedCycles,links.Count-placed.Count+1,normalClosureFailed,normalSpecs.Length))return false;
            if(placed.Count==0||links.Count(l=>l.IsLoop)!=2||Enumerable.Range(0,placed.Count).Any(i=>DungeonRouteClosure.Distance(0,i,placed.Count,links)<0))return false;
            var normalIds=new HashSet<string>(normalSpecs.Select(s=>s.Id),StringComparer.Ordinal);
            var accounted=placed.Select(p=>p.Spec).Concat(pool).ToArray();
            if(normalIds.Count!=normalSpecs.Length||accounted.Any(s=>!normalIds.Contains(s.Id)||ThirdLoopExtensionPolicy.IsExtraId(s.Id))||
                accounted.Select(s=>s.Id).Distinct(StringComparer.Ordinal).Count()!=accounted.Length||
                normalSpecs.Where(s=>s.SourceId!="R09").Any(s=>!accounted.Any(a=>a.Id==s.Id)))return false;
            NaturalDungeonRoster.ValidateCanonical(canonical);
            diagnostics.ExtensionAttempts++;
            var counts=normalSpecs.GroupBy(s=>NaturalDungeonRoster.Family(s.SourceId)).ToDictionary(g=>g.Key,g=>g.Count(),StringComparer.Ordinal);
            var options=new List<DungeonRoomSpec>();
            foreach(var family in canonical.Where(s=>ThirdLoopExtensionPolicy.EligibleSource(s.SourceId,s.Ports.Length)&&(!oneBrokenSaint||s.SourceId!="R03")).GroupBy(s=>NaturalDungeonRoster.Family(s.SourceId)).OrderBy(g=>g.Key,StringComparer.Ordinal))
            {
                int existing=counts.TryGetValue(family.Key,out int n)?n:0;
                int allowance=Math.Min(ThirdLoopExtensionPolicy.MaximumRouteExtras,NaturalDungeonRoster.MaximumOrdinaryRepeats-existing);
                var sources=family.OrderBy(s=>s.SourceId,StringComparer.Ordinal).ToArray();int offset=random.Next(sources.Length);
                var ordinals=new Dictionary<string,int>(StringComparer.Ordinal);
                for(int i=0;i<allowance;i++)
                {
                    var source=sources[(offset+i)%sources.Length];int ordinal=ordinals.TryGetValue(source.SourceId,out int old)?old+1:1;ordinals[source.SourceId]=ordinal;
                    options.Add(new DungeonRoomSpec{Id=source.SourceId+"_loop3_extra_"+ordinal.ToString("00",System.Globalization.CultureInfo.InvariantCulture),SourceId=source.SourceId,
                        Ports=source.Ports.ToArray(),Bounds=source.Bounds.ToArray(),BoundsY=source.BoundsY.ToArray(),Reservations=source.Reservations?.Select(v=>v.ToArray()).ToArray(),KitConnectedExteriorCollar=source.KitConnectedExteriorCollar});
                }
            }
            if(options.Count==0)return false;
            int originalRooms=placed.Count,originalEdges=links.Count;bool success=false;pool.AddRange(options);
            int extensionBudget=ThirdLoopExtensionPolicy.PlacementBudget;
            try
            {
                Func<int,int> accept=available=>
                {
                    var extras=placed.Where(p=>ThirdLoopExtensionPolicy.IsExtraId(p.Spec.Id)).Select(p=>p.Spec).ToArray();
                    bool valid=ThirdLoopExtensionPolicy.Accepts(normalTarget,extras.Length)&&links.Count-placed.Count+1==3&&
                        extras.All(s=>placed.FindIndex(p=>p.Spec.Id==s.Id)>=originalRooms)&&
                        normalSpecs.Concat(extras).GroupBy(s=>NaturalDungeonRoster.Family(s.SourceId)).Where(g=>g.Key!="R08"&&g.Key!="R09").All(g=>g.Count()<=NaturalDungeonRoster.MaximumOrdinaryRepeats);
                    return valid?available:-Math.Max(0,available)-1;
                };
                success=DungeonRouteClosure.TryClose(pool,placed,links,entrance,random,ref extensionBudget,diagnostics,-1,-1,false,accept,canonical);
                if(success)
                {
                    budget=Math.Max(Math.Max(0,budget),extensionBudget);diagnostics.NormalTargetRooms=normalTarget;
                    diagnostics.ExtensionRooms=placed.Count(p=>ThirdLoopExtensionPolicy.IsExtraId(p.Spec.Id));diagnostics.ExtensionReason=ThirdLoopExtensionPolicy.Reason;
                }
                return success;
            }
            finally
            {
                // Offered definitions are not selected rooms. Keep only the
                // consumed route instances, never extra filler for normal Add.
                pool.RemoveAll(s=>ThirdLoopExtensionPolicy.IsExtraId(s.Id));
                if(!success){if(links.Count>originalEdges)links.RemoveRange(originalEdges,links.Count-originalEdges);if(placed.Count>originalRooms)placed.RemoveRange(originalRooms,placed.Count-originalRooms);}
            }
        }
        private static PortRecord Facing(DungeonPlacement room,PlanPoint direction)=>room.Spec.Ports.SingleOrDefault(p=>(room.Normal(p)-direction).Length<.001);
        private static bool AppendFromPool(List<DungeonRoomSpec> pool,Func<DungeonRoomSpec,bool> eligible,int from,List<DungeonPlacement> placed,List<DungeonLink> links,string entrance,Random random,ref int budget,DungeonPlanningDiagnostics diagnostics,out int appended,bool preferStem=false)
        {
            appended=from;var choices=new List<Tuple<DungeonRoomSpec,PortRecord,PortRecord>>();
            foreach(var source in pool.Where(eligible))foreach(var a in placed[from].Spec.Ports)if(!(from==0&&a.id==entrance)&&!Used(links,from,a))foreach(var b in source.Ports)choices.Add(Tuple.Create(source,a,b));
            Shuffle(choices,random);
            var incoming=links.LastOrDefault(l=>l.A==from||l.B==from);
            var incomingPort=incoming==null?null:incoming.A==from?incoming.PortA:incoming.PortB;
            var forward=incomingPort==null?new PlanPoint(0,1):placed[from].Normal(incomingPort)*-1;
            // Search the less obstructed backbone sockets first. This is a
            // preference, not an orientation restriction: random ties and all
            // other legal cardinal poses remain in the candidate list.
            choices=choices.OrderByDescending(c=>
            {
                var n=placed[from].Normal(c.Item2);int score=n.X*forward.X+n.Z*forward.Z>.9?2:0;
                if(preferStem&&c.Item1.Ports.Length==3)
                {var others=c.Item1.Ports.Where(p=>p.id!=c.Item3.id).ToArray();if(new PlanPoint(others[0].outward[0]+others[1].outward[0],others[0].outward[2]+others[1].outward[2]).Length<.001)score++;}
                return score;
            }).ToList();
            foreach(var choice in choices)
            {
                if(--budget<=0)return false;if(choice.Item1.SourceId=="R08"&&placed[from].Spec.SourceId=="R08")continue;
                if(!TryPlacement(choice.Item1,from,choice.Item2,choice.Item3,placed,links,diagnostics,out var room,out var link))continue;
                appended=placed.Count;placed.Add(room);links.Add(link);pool.Remove(choice.Item1);diagnostics.MaximumPlaced=Math.Max(diagnostics.MaximumPlaced,placed.Count);return true;
            }
            return false;
        }
        internal static bool TryPlacement(DungeonRoomSpec next,int ai,PortRecord ap,PortRecord bp,List<DungeonPlacement> placed,List<DungeonLink> links,DungeonPlanningDiagnostics diagnostics,out DungeonPlacement b,out DungeonLink link)
        {
            b=null;link=null;
            if(!FamilyChainPolicy.AllowsNewRoom(placed,links,ai,next.SourceId))return false;
            diagnostics.CandidatePlacements++;var a=placed[ai];var normal=a.Normal(ap);
            int q=Enumerable.Range(0,4).First(v=>(PlanPoint.Rotate(new PlanPoint(bp.outward[0],bp.outward[2]),v)+normal).Length<.001);
            b=new DungeonPlacement{Spec=next,QuarterTurns=q,Elevation=a.Height(ap.position)-bp.position[1]};b.Position=a.Point(ap.position)+normal*ThresholdGap(ap,bp)-PlanPoint.Rotate(new PlanPoint(bp.position[0],bp.position[2]),q);
            var candidate=b;var box=b.Envelope();var low=b.LowY;var high=b.HighY;link=null;
            if(placed.Any(p=>ReferenceEquals(p,a)?KitPlanningReservationPolicy.ConnectedRoomsOverlap(a,ap,candidate,bp):RoomsOverlap(candidate,p))){diagnostics.RoomOverlapRejections++;return false;}
            link=new DungeonLink{A=ai,B=placed.Count,PortA=ap,PortB=bp,Start=a.Outer(ap),End=b.Outer(bp),Elevation=a.Height(ap.position)};
            var envelope=link.Envelope();double linkLow=link.LowY,linkHigh=link.HighY;
            if(Math.Abs((link.End-link.Start).Length-JointGap(ap,bp))>.0001||Math.Abs(link.Elevation-b.Height(bp.position))>.0001||placed.Where((p,i)=>i!=ai).Any(p=>OverlapsRoom(envelope,linkLow,linkHigh,p))||links.Any(l=>OverlapsRoom(l.Envelope(),l.LowY,l.HighY,candidate))){diagnostics.PassageRejections++;return false;}
            if(links.Any(l=>Overlap3D(envelope,linkLow,linkHigh,l.Envelope(),l.LowY,l.HighY))){diagnostics.CrossingRejections++;return false;}
            return true;
        }
        private static int[] Depths(int count,List<DungeonLink> links)
        {
            var depth=Enumerable.Repeat(-1,count).ToArray();depth[0]=0;var queue=new Queue<int>();queue.Enqueue(0);
            while(queue.Count>0){int a=queue.Dequeue();foreach(var l in links){int b=l.A==a?l.B:l.B==a?l.A:-1;if(b>=0&&depth[b]<0){depth[b]=depth[a]+1;queue.Enqueue(b);}}}
            return depth;
        }
        private sealed class NaturalCompletion{internal DungeonRoomSpec[] Canonical,NormalSpecs;internal bool OneBrokenSaint,KnightLoop;internal int Seed,LoopAttempts;}
        private static bool Add(int index,List<DungeonRoomSpec> order,List<DungeonPlacement> placed,List<DungeonLink> links,string entrance,Random random,ref int budget,DungeonPlanningDiagnostics diagnostics,bool natural=false,bool requireAllStairs=true,NaturalCompletion completion=null)
        {
            diagnostics.MaximumPlaced=Math.Max(diagnostics.MaximumPlaced,placed.Count);
            if(index==order.Count)
            {
                if(natural&&!FamilyChainPolicy.IsValid(placed,links))return false;
                if(requireAllStairs&&!placed.Where(p=>p.Spec.SourceId=="R08").All(p=>p.Spec.Ports.All(port=>links.Any(l=>l.A==placed.IndexOf(p)&&l.PortA.id==port.id||l.B==placed.IndexOf(p)&&l.PortB.id==port.id))))return false;
                if(natural){int boss=placed.FindIndex(p=>p.Spec.SourceId=="R09");int depth=boss<0?-1:Depths(placed.Count,links)[boss];if(depth<NaturalDungeonRoster.MinimumBossDepth||depth>=placed.Count)return false;}
                return true;
            }
            if(--budget<=0){if(natural)budget=0;diagnostics.BudgetExhaustions++;return false;}
            var next=order[index];var choices=new List<Tuple<int,PortRecord,PortRecord>>();
            if(natural&&next.SourceId=="R09"&&completion!=null&&index==order.Count-1)
            {
                int rooms=placed.Count,edges=links.Count;
                if(completion.KnightLoop)
                {
                    var loopPlan=new DungeonPlan{Seed=completion.Seed,Rooms=placed.ToArray(),Links=links.ToArray(),EntryPort=entrance,Diagnostics=diagnostics};
                    if(!R08KnightReturnPolicy.CloseReturnLoop(loopPlan,completion.Canonical))return false;
                    placed.Clear();placed.AddRange(loopPlan.Rooms);links.Clear();links.AddRange(loopPlan.Links);
                }
                if(!BossConnectionPlanner.TryConnect(completion.Canonical,completion.NormalSpecs,next,placed,links,entrance,random,ref budget,diagnostics,completion.OneBrokenSaint,completion.KnightLoop)){if(links.Count>edges)links.RemoveRange(edges,links.Count-edges);if(placed.Count>rooms)placed.RemoveRange(rooms,placed.Count-rooms);return false;}
                // Keep the common completion gate as well as the helper's own
                // source/chain checks: in particular every stair landing must
                // remain connected before this plan can reach runtime loading.
                if(Add(index+1,order,placed,links,entrance,random,ref budget,diagnostics,natural,requireAllStairs,completion))return true;
                links.RemoveRange(edges,links.Count-edges);placed.RemoveRange(rooms,placed.Count-rooms);
                diagnostics.BossExtensionRooms=0;diagnostics.BossExtensionReason="none";return false;
            }
            for(int i=0;i<placed.Count;i++)foreach(var a in placed[i].Spec.Ports)
                if(!(i==0&&a.id==entrance)&&!links.Any(l=>l.A==i&&l.PortA.id==a.id||l.B==i&&l.PortB.id==a.id))foreach(var b in next.Ports)
                    if((natural||next.SourceId!="R08"||Math.Abs(b.position[1])<.001)&&
                       (completion?.KnightLoop!=true||
                        (placed[i].Spec.Id!="KNIGHT_LOOP_JUNCTION"&&
                         (next.AssetId!="R08-UD"||b.id=="SOUTH")&&
                         (next.Id!="KNIGHT_LOOP_JUNCTION"||placed[i].Spec.AssetId=="R08-UD"&&a.id=="KNIGHT-RETURN")&&
                         (placed[i].Spec.AssetId!="R08-UD"||a.id!="KNIGHT-RETURN"||next.Id=="KNIGHT_LOOP_JUNCTION"))))choices.Add(Tuple.Create(i,a,b));
            Shuffle(choices,random);
            var depths=natural?Depths(placed.Count,links):null;
            foreach(var choice in choices)
            {
                if(natural&&budget<=0)break;
                // Two .75m-deep R08 ports would require an unauthored1.52m
                // sleeve. An ordinary room separates shafts instead; do not
                // stretch another kit module or silently weaken preflight.
                if(natural&&next.SourceId=="R08"&&placed[choice.Item1].Spec.SourceId=="R08")continue;
                if(natural&&next.SourceId=="R09"&&depths[choice.Item1]+1<NaturalDungeonRoster.MinimumBossDepth)continue;
                if(!TryPlacement(next,choice.Item1,choice.Item2,choice.Item3,placed,links,diagnostics,out var b,out var link))continue;
                int originalRooms=placed.Count,originalEdges=links.Count;placed.Add(b);links.Add(link);
                bool loopOkay=true;
                if(completion?.KnightLoop==true&&next.Id=="KNIGHT_LOOP_JUNCTION")
                {
                    if(completion.LoopAttempts++>=2){links.RemoveRange(originalEdges,links.Count-originalEdges);placed.RemoveRange(originalRooms,placed.Count-originalRooms);return false;}
                    var loopPlan=new DungeonPlan{Seed=completion.Seed,Rooms=placed.ToArray(),Links=links.ToArray(),EntryPort=entrance,Diagnostics=diagnostics};
                    loopOkay=R08KnightReturnPolicy.CloseReturnLoop(loopPlan,completion.Canonical);
                    if(loopOkay){placed.Clear();placed.AddRange(loopPlan.Rooms);links.Clear();links.AddRange(loopPlan.Links);}
                }
                if(loopOkay&&Add(index+1,order,placed,links,entrance,random,ref budget,diagnostics,natural,requireAllStairs,completion))return true;
                links.RemoveRange(originalEdges,links.Count-originalEdges);placed.RemoveRange(originalRooms,placed.Count-originalRooms);
            }
            return false;
        }
    }
}
