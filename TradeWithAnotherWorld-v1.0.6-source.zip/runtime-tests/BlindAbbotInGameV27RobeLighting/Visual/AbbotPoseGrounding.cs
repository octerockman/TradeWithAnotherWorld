using System;
using System.Linq;
using UnityEngine;

namespace BlackAbbey.BlindAbbot
{
    // Only cancels a positive floor gap caused by the actor being supported by
    // props. The immutable sampled pose already contains its vertical motion;
    // lowering every kneel/death would bury the fitted feet and robe further.
    internal sealed class AbbotPoseGrounding
    {
        readonly Transform visual, actor;
        readonly Vector3 baseLocalPosition;
        Transform[] supportBones;
        Matrix4x4[] bindposes, skinMatrices;
        Vector3[] restPoints;
        WeightRecord[] pointWeights;
        readonly AbbotVisual sourceVisual;int family=-1;
        Transform room;
        float localFloor, offset, desired, support, floorY, nextFloorQuery;
        string floorName = "not configured", currentClip;
        bool hasFloor;

        public AbbotPoseGrounding(AbbotVisual source)
        {
            visual = source.Root; actor = visual.parent; baseLocalPosition = visual.localPosition;
            sourceVisual=source;SelectFamily();
        }
        void SelectFamily(){
            if(family==sourceVisual.ActiveFamily)return;family=sourceVisual.ActiveFamily;
            var source=sourceVisual;MeshRecord body=Array.Find(source.Payload.renderers,r=>r.role=="body"&&r.familyId==family);
            if(body==null)throw new InvalidOperationException("Current body skin missing");
            var footIds=source.Payload.nodes.Where(n=>n.name=="L_Foot"||n.name=="R_Foot"||n.name=="L_Toe0"||n.name=="R_Toe0").Select(n=>n.id).ToArray();
            var candidate=Enumerable.Range(0,body.vertexCount).Where(i=>{var w=body.weights[i];return (footIds.Contains(body.boneNodeIds[w.boneIndex0])?w.weight0:0)+(footIds.Contains(body.boneNodeIds[w.boneIndex1])?w.weight1:0)+(footIds.Contains(body.boneNodeIds[w.boneIndex2])?w.weight2:0)+(footIds.Contains(body.boneNodeIds[w.boneIndex3])?w.weight3:0)>.5f;}).ToArray();
            if(candidate.Length==0)throw new InvalidOperationException("Exact current foot supports missing");float min=candidate.Min(i=>body.positions[i*3+1]);var supportIndices=candidate.Where(i=>body.positions[i*3+1]<min+.04f).ToArray();
            supportBones = new Transform[body.boneNodeIds.Length];
            bindposes = new Matrix4x4[supportBones.Length]; skinMatrices = new Matrix4x4[supportBones.Length];
            for (int i = 0; i < supportBones.Length; i++)
            {
                var node = Array.Find(source.Payload.nodes, n => n.id == body.boneNodeIds[i]);
                supportBones[i] = source.Named[node.name]; var matrix = new Matrix4x4();
                for (int a = 0; a < 4; a++) for (int b = 0; b < 4; b++) matrix[a, b] = body.bindposes[i].values[a * 4 + b];
                bindposes[i] = matrix;
            }
            restPoints = new Vector3[supportIndices.Length]; pointWeights = new WeightRecord[supportIndices.Length];
            for (int i = 0; i < supportIndices.Length; i++)
            {
                int index = supportIndices[i];
                restPoints[i] = new Vector3(body.positions[index * 3], body.positions[index * 3 + 1], body.positions[index * 3 + 2]);
                pointWeights[i] = body.weights[index];
            }
        }

        public void Configure(Transform roomRoot, float floorLocalY)
        { room = roomRoot; localFloor = floorLocalY; nextFloorQuery = 0; hasFloor = false; }

        public void Apply(string clip, float phase, float seconds, bool snap = false)
        {
            SelectFamily();currentClip = clip;
            bool referenced = clip == "a000_008700" || clip == "a000_007600";
            desired = 0;
            if (room && actor && referenced)
            {
                if (!hasFloor || Time.unscaledTime >= nextFloorQuery || snap) FindFloor();
                float worldSupport = CurrentFootSupport();
                support = worldSupport + offset - actor.position.y;
                // Source body has a few centimetres of fitted sole penetration.
                // Compensate only an actual positive gap, never that penetration.
                desired = hasFloor ? Mathf.Clamp(worldSupport + offset - floorY - .015f, 0, 2f) : 0;
            }
            if (snap) offset = desired;
            else if (seconds > 0) offset = Mathf.MoveTowards(offset, desired, 3f * seconds);
            var delta = actor ? actor.InverseTransformVector(Vector3.down * offset) : Vector3.zero;
            visual.localPosition = baseLocalPosition + delta;
        }

        float CurrentFootSupport()
        {
            for (int i = 0; i < skinMatrices.Length; i++)
                skinMatrices[i] = supportBones[i].localToWorldMatrix * bindposes[i];
            float minimum = float.PositiveInfinity;
            for (int i = 0; i < restPoints.Length; i++)
            {
                var p = restPoints[i]; var w = pointWeights[i];
                var world = skinMatrices[w.boneIndex0].MultiplyPoint3x4(p) * w.weight0
                    + skinMatrices[w.boneIndex1].MultiplyPoint3x4(p) * w.weight1
                    + skinMatrices[w.boneIndex2].MultiplyPoint3x4(p) * w.weight2
                    + skinMatrices[w.boneIndex3].MultiplyPoint3x4(p) * w.weight3;
                minimum = Mathf.Min(minimum, world.y);
            }
            return minimum;
        }

        void FindFloor()
        {
            nextFloorQuery = Time.unscaledTime + .2f;
            hasFloor = true;
            floorY = room.TransformPoint(new Vector3(0, localFloor, 0)).y;
            floorName = "authored room floor datum";
            // Actual room masonry can be uneven. Ignore character/pew/debris
            // collision: those are exactly the props that can raise the capsule.
            var origin = actor.position + Vector3.up * 1.5f;
            float nearest = float.PositiveInfinity;
            foreach (var hit in Physics.RaycastAll(origin, Vector3.down, 5f, ~0, QueryTriggerInteraction.Ignore))
            {
                var collider = hit.collider;
                if (!collider || !(collider is MeshCollider) || !collider.transform.IsChildOf(room)
                    || collider.attachedRigidbody || hit.normal.y < .7f || hit.distance >= nearest) continue;
                bool prop = false;
                for (var t = collider.transform; t && t != room && !prop; t = t.parent)
                    foreach (var component in t.GetComponents<Component>())
                        if (component && component.GetType().Name == "AbbeyBreakablePew") { prop = true; break; }
                if (prop) continue;
                nearest = hit.distance; floorY = hit.point.y; floorName = collider.name;
            }
        }

        public object Snapshot() => new { configured = room != null, clip = currentClip,
            actorY = actor ? actor.position.y : 0, floorY, floor = floorName,
            sourceFootSupportY = support, downwardOffset = offset, desiredOffset = desired,
            rule = "positive floor gap only; immutable pose and capsule preserved" };

    }
}
