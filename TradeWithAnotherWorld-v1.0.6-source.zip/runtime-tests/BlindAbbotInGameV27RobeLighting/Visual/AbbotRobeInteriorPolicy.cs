using System;
using System.IO;
namespace BlackAbbey.BlindAbbot
{
    // Exact V97 payload construction, proven from the immutable four source
    // families. Other outfit parts and future authoring sources are untouched.
    public static class AbbotRobeInteriorPolicy
    {
        public const string NativeSha="a6613da0663d7267a7f2097e13b97c15682070404309c093c89df688cdeb4852";
        public static int ExteriorIndexCount(string name,string role,int vertices,int triangles)
        {
            if(role!="robe"||name==null)return 0;
            if(name.IndexOf("Robe body and hood",StringComparison.Ordinal)>=0)
            {
                if(vertices!=24978||triangles!=8362)throw new InvalidDataException("Reviewed V97 robe partition changed; refresh source proof before applying interior render policy.");
                return 5169*3;
            }
            if(name.IndexOf("Torn hem fragment",StringComparison.Ordinal)>=0||name.IndexOf("Torn side strip",StringComparison.Ordinal)>=0)
            {
                if(vertices!=84||triangles!=28)throw new InvalidDataException("Reviewed V97 torn-cloth partition changed.");
                return 14*3;
            }
            return 0;
        }
    }
}
