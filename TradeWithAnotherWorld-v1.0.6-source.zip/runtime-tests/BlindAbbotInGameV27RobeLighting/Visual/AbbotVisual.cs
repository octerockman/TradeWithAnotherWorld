using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using UnityEngine;
using UnityEngine.Rendering;
using Object=UnityEngine.Object;

namespace BlackAbbey.BlindAbbot
{
    // The same own-data builder runs in the offline Editor check and in-game.
    // It has no creature/AI dependency and never creates an AssetBundle.
    public sealed class AbbotVisual : IDisposable
    {
        public AbbotPayload Payload;public Animator Animator;public Avatar Avatar;public Transform Root;
        public Action<string,float> MotionObserved;
        public Transform StaffTip=>Semantic("StaffTip");public Transform RightHand=>Semantic("RightHand");
        public Transform Semantic(string key,bool optional=false){if(Payload.semanticNodes!=null&&Payload.semanticNodes.TryGetValue(key,out var name)&&Named.TryGetValue(name,out var value))return value;if(optional)return null;throw new InvalidDataException("Abbot semantic node unavailable: "+key);}
        readonly List<(Material,float)> emberMaterials=new List<(Material,float)>();AbbotPoseDriver driver;MotionBank bank;AbbotScarfCloth scarfCloth;
        public int ActiveFamily {get;private set;}=-1;
        public readonly Dictionary<int,List<SkinnedMeshRenderer>> FamilySkins=new Dictionary<int,List<SkinnedMeshRenderer>>();
        public readonly Dictionary<int,SkinnedMeshRenderer> FamilyContacts=new Dictionary<int,SkinnedMeshRenderer>();
        public void EnableScarfCloth(Action<string> logger){if(!scarfCloth)scarfCloth=AbbotScarfCloth.Attach(this,logger);}
        public object ScarfClothSnapshot()=>scarfCloth?scarfCloth.Snapshot():null;
        public void BakeSkirtInto(SkinnedMeshRenderer source,Mesh mesh){if(scarfCloth)scarfCloth.BakeInto(source,mesh);}
        public void SetFamily(int family){foreach(var contact in FamilyContacts.Values)if(contact)contact.forceRenderingOff=true;if(ActiveFamily==family)return;if(!FamilySkins.ContainsKey(family))throw new InvalidDataException("Unknown reviewed bind family");ActiveFamily=family;Skins.Clear();foreach(var entry in FamilySkins){bool active=entry.Key==family;foreach(var skin in entry.Value)if(skin)skin.gameObject.SetActive(active);if(active)Skins.AddRange(entry.Value);}if(Payload.staffTipPositions!=null&&family<Payload.staffTipPositions.Length&&Named.TryGetValue("StaffTip",out var tip))tip.localPosition=V(Payload.staffTipPositions[family]);if(scarfCloth)scarfCloth.SetFamily(family);}
        public void SetMotion(string motion,float normalizedTime,float blend=1,float transitionDuration=-1){string resolved=bank.aliases!=null&&bank.aliases.TryGetValue(motion,out var mapped)?mapped:motion;SetFamily(bank.clips.First(c=>c.name==resolved).familyId);driver.SetMotion(motion,normalizedTime,blend,transitionDuration);if(MotionObserved!=null){string id=bank.aliases!=null&&bank.aliases.TryGetValue(motion,out var raw)?raw:motion;MotionObserved(id,Mathf.Clamp01(normalizedTime)*MotionDuration(id));}}
        public void ClearMotion(){driver.ClearMotion();}
        public void SetEmber(float amount){foreach(var entry in emberMaterials)entry.Item1.SetColor("_EmissionColor",Color.white*entry.Item2*Mathf.Clamp(amount,0,4));}
        public static AbbotVisual Build(Transform visualRoot,string dataFolder,Material nativeTemplate,RuntimeAnimatorController controller){var payload=Read(Safe(dataFolder,"abbot-visual.json.gz"));var result=Build(visualRoot,payload,nativeTemplate,dataFolder,false);try{result.Animator.runtimeAnimatorController=controller;result.bank=AbbotPayloadReader.ReadMotion(Safe(dataFolder,"abbot-motion.json.gz"));result.driver=visualRoot.gameObject.AddComponent<AbbotPoseDriver>();result.driver.Initialize(result,result.bank);return result;}catch{result.Dispose();throw;}}
        public bool HasMotion(string id)=>bank.clips.Any(c=>c.name==id)||bank.aliases!=null&&bank.aliases.ContainsKey(id);
        public MotionBank MotionBank=>bank;
        public string CurrentMotion=>driver?driver.CurrentMotion:null;
        public bool IsDrivingSourceMotion=>driver&&driver.IsDriving;
        public float MotionDuration(string id){if(bank.aliases!=null&&bank.aliases.TryGetValue(id,out var raw))id=raw;return bank.clips.First(c=>c.name==id).duration;}
        public static AbbotVisual BindClone(Transform visualRoot,AbbotVisual prefab){var result=new AbbotVisual{Root=visualRoot,Payload=prefab.Payload,bank=prefab.bank,Animator=visualRoot.GetComponent<Animator>(),Avatar=prefab.Avatar};foreach(var t in visualRoot.GetComponentsInChildren<Transform>(true))if(t==visualRoot||prefab.Named.ContainsKey(t.name))result.Named.Add(t==visualRoot?"Visual":t.name,t);var all=visualRoot.GetComponentsInChildren<SkinnedMeshRenderer>(true).ToDictionary(x=>x.name);foreach(var record in result.Payload.renderers){if(!result.FamilySkins.TryGetValue(record.familyId,out var family)){family=new List<SkinnedMeshRenderer>();result.FamilySkins.Add(record.familyId,family);}family.Add(all[record.name]);if(all.TryGetValue(record.name+"__interior",out var interior))family.Add(interior);}foreach(var record in result.Payload.contacts)result.FamilyContacts.Add(record.familyId,all[record.name]);result.SetFamily(result.Payload.defaultFamily);var copies=new Dictionary<Material,Material>();foreach(var entry in prefab.emberMaterials){var material=new Material(entry.Item1);copies.Add(entry.Item1,material);result.Resources.Add(material);result.emberMaterials.Add((material,entry.Item2));}foreach(var skin in result.Skins){if(copies.TryGetValue(skin.sharedMaterial,out var material))skin.sharedMaterial=material;}result.driver=visualRoot.GetComponent<AbbotPoseDriver>();if(!result.driver)result.driver=visualRoot.gameObject.AddComponent<AbbotPoseDriver>();result.driver.Initialize(result,result.bank);return result;}
        public readonly Dictionary<string,Transform> Named=new Dictionary<string,Transform>(StringComparer.Ordinal);
        public readonly List<SkinnedMeshRenderer> Skins=new List<SkinnedMeshRenderer>();
        public readonly List<Object> Resources=new List<Object>();
        readonly Dictionary<string,Texture2D> textureCache=new Dictionary<string,Texture2D>();
        readonly Dictionary<string,Material> materials=new Dictionary<string,Material>();
        public static string Hash(string path){using(var h=SHA256.Create())using(var s=File.OpenRead(path))return string.Concat(h.ComputeHash(s).Select(b=>b.ToString("x2")));}
        public static Vector3 V(float[] a){if(a==null||a.Length!=3||a.Any(n=>!Finite(n)))throw new InvalidDataException("Invalid vector");return new Vector3(a[0],a[1],a[2]);}
        public static Quaternion Q(float[] a){if(a==null||a.Length!=4||a.Any(n=>!Finite(n)))throw new InvalidDataException("Invalid quaternion");var q=new Quaternion(a[0],a[1],a[2],a[3]);if(Mathf.Abs(Quaternion.Dot(q,q)-1)>.002f)throw new InvalidDataException("Nonunit quaternion");return q;}
        static bool Finite(float n)=>!float.IsNaN(n)&&!float.IsInfinity(n);
        static Matrix4x4 M(MatrixRecord a){if(a?.values==null||a.values.Length!=16||a.values.Any(n=>!Finite(n)))throw new InvalidDataException("Invalid matrix");var m=new Matrix4x4();for(int i=0;i<4;i++)for(int j=0;j<4;j++)m[i,j]=a.values[4*i+j];return m;}
        public void ConfigureGrounding(Transform roomRoot,float floorLocalY=.025f)=>driver?.ConfigureGrounding(roomRoot,floorLocalY);
        public object GroundingSnapshot()=>driver?.GroundingSnapshot();
        public void RefreshGrounding()=>driver?.RefreshGrounding();
        public static string Safe(string folder,string relative){if(string.IsNullOrWhiteSpace(relative)||Path.IsPathRooted(relative))throw new InvalidDataException("Expected relative map path");string root=Path.GetFullPath(folder).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;string p=Path.GetFullPath(Path.Combine(root,relative));if(!p.StartsWith(root,StringComparison.OrdinalIgnoreCase)||!File.Exists(p))throw new InvalidDataException("Outside/missing map");return p;}
        public static AbbotPayload Read(string path)=>AbbotPayloadReader.Read(path);
        public static AbbotVisual Build(Transform root,AbbotPayload p,Material template,string folder,bool equipment)
        {
            var r=new AbbotVisual{Root=root,Payload=p};
            try{r.Construct(template,folder,equipment);AbbotModelFrame.AlignVisual(r);return r;}catch{r.Dispose();throw;}
        }
        void Construct(Material template,string folder,bool equipment)
        {
            var nodes=new Dictionary<int,Transform>();
            foreach(var record in Payload.nodes){
                if(nodes.ContainsKey(record.id)||Named.ContainsKey(record.name))throw new InvalidDataException("Duplicate hierarchy node");
                Transform t;if(record.id==0){if(record.parentId!=-1||record.name!="Visual")throw new InvalidDataException("Wrong root");t=Root;t.name="Visual";}
                else{if(!nodes.TryGetValue(record.parentId,out var parent))throw new InvalidDataException("Hierarchy must be parent first");t=new GameObject(record.name).transform;t.SetParent(parent,false);}
                t.localPosition=V(record.position);t.localRotation=Q(record.rotation);t.localScale=V(record.scale);if(t.localScale.x<=0||t.localScale.y<=0||t.localScale.z<=0)throw new InvalidDataException("Nonpositive scale");t.gameObject.layer=Root.gameObject.layer;nodes.Add(record.id,t);Named.Add(record.name,t);
            }
            var d=Payload.humanDescription;
            if(d?.human!=null&&d.human.Length>0){
            var desc=new HumanDescription{human=d.human.Select(h=>new HumanBone{boneName=h.boneName,humanName=h.humanName,limit=new HumanLimit{useDefaultValues=h.limit.useDefaultValues,min=V(h.limit.min),max=V(h.limit.max),center=V(h.limit.center),axisLength=h.limit.axisLength}}).ToArray(),skeleton=d.skeleton.Select(s=>new SkeletonBone{name=s.name,position=V(s.position),rotation=Q(s.rotation),scale=V(s.scale)}).ToArray(),upperArmTwist=d.upperArmTwist,lowerArmTwist=d.lowerArmTwist,upperLegTwist=d.upperLegTwist,lowerLegTwist=d.lowerLegTwist,armStretch=d.armStretch,legStretch=d.legStretch,feetSpacing=d.feetSpacing,hasTranslationDoF=d.hasTranslationDoF};
            var parentRoot=Root.parent;var pos=Root.localPosition;var rot=Root.localRotation;var scale=Root.localScale;Root.SetParent(null,false);
            try{Avatar=AvatarBuilder.BuildHumanAvatar(Root.gameObject,desc);Resources.Add(Avatar);if(!Avatar||!Avatar.isValid||!Avatar.isHuman)throw new InvalidDataException("Own Abbot Brother humanoid Avatar invalid");Avatar.name="BA_AbbotBrother_Humanoid";}
            finally{Root.SetParent(parentRoot,false);Root.localPosition=pos;Root.localRotation=rot;Root.localScale=scale;}
            }
            Animator=Root.GetComponent<Animator>();if(!Animator)Animator=Root.gameObject.AddComponent<Animator>();Animator.avatar=Avatar;Animator.applyRootMotion=false;Animator.cullingMode=AnimatorCullingMode.AlwaysAnimate;
            foreach(var m in Payload.materials)materials.Add(m.id,MakeMaterial(template,folder,m));
            foreach(var record in Payload.renderers.Concat(Payload.contacts??Array.Empty<MeshRecord>())){
                if(record.type!="skin"||record.boneNodeIds==null||record.boneNodeIds.Length<1||record.boneNodeIds.Length>256||record.bindposes?.Length!=record.boneNodeIds.Length||record.weights?.Length!=record.vertexCount||record.boneNodeIds.Any(i=>!nodes.ContainsKey(i)))throw new InvalidDataException("Abbot skin contract changed");
                var go=new GameObject(record.name);go.transform.SetParent(Root,false);go.layer=Root.gameObject.layer;var mesh=Mesh(record);mesh.bindposes=record.bindposes.Select(M).ToArray();mesh.boneWeights=record.weights.Select(w=>Weight(w,record.boneNodeIds.Length)).ToArray();
                var skin=go.AddComponent<SkinnedMeshRenderer>();skin.sharedMesh=mesh;skin.bones=record.boneNodeIds.Select(i=>nodes[i]).ToArray();skin.rootBone=nodes[record.rootBoneNodeId];skin.localBounds=new Bounds(V(record.boundsCenter),V(record.boundsSize));skin.updateWhenOffscreen=true;skin.quality=SkinQuality.Bone4;skin.sharedMaterial=materials[record.materialId];skin.shadowCastingMode=ShadowCastingMode.On;skin.receiveShadows=true;if(record.role=="contact"){skin.forceRenderingOff=true;FamilyContacts.Add(record.familyId,skin);}else{if(!FamilySkins.TryGetValue(record.familyId,out var family)){family=new List<SkinnedMeshRenderer>();FamilySkins.Add(record.familyId,family);}family.Add(skin);}
            }
            ConfigureRobeInteriors();
            SetFamily(Payload.defaultFamily);
            if(equipment)foreach(var record in Payload.items)BuildItem(Named[record.attachmentName],record);
        }
        BoneWeight Weight(WeightRecord w,int count){var inds=new[]{w.boneIndex0,w.boneIndex1,w.boneIndex2,w.boneIndex3};var values=new[]{w.weight0,w.weight1,w.weight2,w.weight3};if(inds.Any(i=>i<0||i>=count)||values.Any(v=>!Finite(v)||v<0||v>1)||Mathf.Abs(values.Sum()-1)>.0001)throw new InvalidDataException("Invalid four-influence skin");return new BoneWeight{boneIndex0=w.boneIndex0,boneIndex1=w.boneIndex1,boneIndex2=w.boneIndex2,boneIndex3=w.boneIndex3,weight0=w.weight0,weight1=w.weight1,weight2=w.weight2,weight3=w.weight3};}
        public Mesh Mesh(MeshRecord r){
            int n=r.vertexCount;if(n<3||n>1000000||r.positions?.Length!=n*3||r.normals?.Length!=n*3||r.uv?.Length!=n*2||r.triangles?.Length!=r.triangleCount*3||r.triangles.Any(i=>i<0||i>=n))throw new InvalidDataException("Invalid mesh arrays");
            if(r.positions.Concat(r.normals).Concat(r.uv).Any(v=>!Finite(v)))throw new InvalidDataException("Nonfinite mesh");
            var vs=new Vector3[n];var ns=new Vector3[n];var ts=new Vector4[n];var uv=new Vector2[n];for(int i=0;i<n;i++){vs[i]=new Vector3(r.positions[i*3],r.positions[i*3+1],r.positions[i*3+2]);ns[i]=new Vector3(r.normals[i*3],r.normals[i*3+1],r.normals[i*3+2]);uv[i]=new Vector2(r.uv[i*2],r.uv[i*2+1]);}
            var mesh=new Mesh{name=r.name,indexFormat=n>65535?IndexFormat.UInt32:IndexFormat.UInt16};mesh.vertices=vs;mesh.normals=ns;mesh.uv=uv;mesh.triangles=r.triangles;mesh.RecalculateTangents();mesh.RecalculateBounds();Resources.Add(mesh);return mesh;
        }
        public GameObject BuildItem(Transform parent,MeshRecord record){var go=new GameObject(record.name);go.transform.SetParent(parent,false);go.transform.localPosition=V(record.position);go.transform.localRotation=Q(record.rotation);go.transform.localScale=V(record.scale);go.AddComponent<MeshFilter>().sharedMesh=Mesh(record);var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=materials[record.materialId];renderer.shadowCastingMode=ShadowCastingMode.On;return go;}
        Texture2D Texture(string folder,FileRecord record,bool linear){if(record==null)return null;string key=record.sha256+linear;if(textureCache.TryGetValue(key,out var cached))return cached;string path=Safe(folder,record.path);if(new FileInfo(path).Length>32*1024*1024||Hash(path)!=record.sha256)throw new InvalidDataException("Texture source mismatch:"+record.path);var texture=new Texture2D(2,2,TextureFormat.RGBA32,true,linear);Resources.Add(texture);if(!ImageConversion.LoadImage(texture,File.ReadAllBytes(path),true)||texture.width>4096||texture.height>4096)throw new InvalidDataException("Invalid texture");texture.name=record.path;texture.wrapMode=TextureWrapMode.Clamp;texture.filterMode=FilterMode.Trilinear;texture.anisoLevel=4;textureCache.Add(key,texture);return texture;}
        Material MakeMaterial(Material template,string folder,MaterialRecord record){var m=new Material(template){name="BA_"+record.id};Resources.Add(m);foreach(string prop in m.GetTexturePropertyNames()){m.SetTexture(prop,null);m.SetTextureScale(prop,Vector2.one);m.SetTextureOffset(prop,Vector2.zero);}m.SetColor("_Color",Color.white);if(record.diffuse!=null)m.SetTexture("_MainTex",Texture(folder,record.diffuse,false));else if(record.baseColor?.Length==4)m.SetColor("_Color",new Color(record.baseColor[0],record.baseColor[1],record.baseColor[2],record.baseColor[3]));if(record.normal!=null){m.SetTexture("_BumpMap",Texture(folder,record.normal,true));m.SetFloat("_BumpScale",1);m.EnableKeyword("_NORMALMAP");}if(record.metallicGloss!=null){m.SetTexture("_MetallicGlossMap",Texture(folder,record.metallicGloss,true));m.SetFloat("_UseGlossmap",1);m.EnableKeyword("_METALLICGLOSSMAP");}else{if(m.HasProperty("_Glossiness"))m.SetFloat("_Glossiness",1-record.roughness);if(m.HasProperty("_Metallic"))m.SetFloat("_Metallic",record.metallic);}foreach(string prop in new[]{"_Hue","_Saturation","_Value","_UseStyles","_Style","_NoiseGlowEnabled","_SnowCover","_AddRain"})if(m.HasProperty(prop))m.SetFloat(prop,0);if(m.HasProperty("_MetalColor"))m.SetColor("_MetalColor",Color.white);if(record.emission!=null){m.SetTexture("_EmissionMap",Texture(folder,record.emission,false));if(m.HasProperty("_EmissionColor"))m.SetColor("_EmissionColor",Color.white*record.emissionStrength);m.EnableKeyword("_EMISSION");emberMaterials.Add((m,record.emissionStrength));}else if(m.HasProperty("_EmissionColor"))m.SetColor("_EmissionColor",Color.black);if(record.colorMultiplier?.Length==4){var c=record.colorMultiplier;if(c.Any(x=>!Finite(x)||x<0||x>2))throw new InvalidDataException("Invalid local surface multiplier");m.SetColor("_Color",m.GetColor("_Color")*new Color(c[0],c[1],c[2],c[3]));}m.DisableKeyword("_ALPHATEST_ON");return m;}
        public void Dispose(){if(scarfCloth){scarfCloth.Release();Object.Destroy(scarfCloth);}if(driver)Object.DestroyImmediate(driver);foreach(var r in Resources)if(r)Object.DestroyImmediate(r);Resources.Clear();}
        void ConfigureRobeInteriors()
        {
            if(Payload.sourceNative.sha256!=AbbotRobeInteriorPolicy.NativeSha)return;
            foreach(var record in Payload.renderers)
            {
                int exteriorIndices=AbbotRobeInteriorPolicy.ExteriorIndexCount(record.name,record.role,record.vertexCount,record.triangleCount);if(exteriorIndices==0)continue;
                var outer=FamilySkins[record.familyId].Single(s=>s.name==record.name);
                var original=record.triangles;var source=outer.sharedMesh;
                // The admitted payload appends exact coplanar reversed faces.
                // Keep exterior shadow casting; the separate inside is visible
                // only from within and cannot cast onto its coincident outside.
                source.triangles=original.Take(exteriorIndices).ToArray();
                var insideMesh=Object.Instantiate(source);insideMesh.name=source.name+"__interior";insideMesh.triangles=original.Skip(exteriorIndices).ToArray();Resources.Add(insideMesh);
                var surface=new Material(outer.sharedMaterial){name=outer.sharedMaterial.name+"_explicit_front_faces"};Resources.Add(surface);
                if(!surface.HasProperty("_Cull"))throw new InvalidDataException("Native cloth material lacks culling contract");surface.SetFloat("_Cull",(float)CullMode.Back);outer.sharedMaterial=surface;
                var go=new GameObject(record.name+"__interior");go.layer=outer.gameObject.layer;go.transform.SetParent(outer.transform.parent,false);
                var inside=go.AddComponent<SkinnedMeshRenderer>();inside.sharedMesh=insideMesh;inside.bones=outer.bones;inside.rootBone=outer.rootBone;inside.localBounds=outer.localBounds;inside.updateWhenOffscreen=outer.updateWhenOffscreen;inside.quality=outer.quality;inside.sharedMaterial=surface;inside.shadowCastingMode=ShadowCastingMode.Off;inside.receiveShadows=true;
                FamilySkins[record.familyId].Add(inside);
            }
        }
    }
}
