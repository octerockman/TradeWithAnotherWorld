using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using MagicaCloth2;
using UnityEngine;
using Object=UnityEngine.Object;

namespace BlackAbbey.BlindAbbot
{
    // V97's two moving scarf panels against its all-fixed, source-skinned robe.
    // No leg collider and no skirt simulation. Each matching bind is independent.
    [DefaultExecutionOrder(12010)]
    public sealed class AbbotScarfCloth:MonoBehaviour
    {
        sealed class Family
        {
            public int Id,BuildAfter,BuildWaitTicks;public bool Started,Ready,Failed,Reset=true,Frozen;
            public readonly HashSet<MagicaCloth> Completed=new HashSet<MagicaCloth>();
            public SkinnedMeshRenderer Contact;public SkinnedMeshRenderer[] Scarves;
            public readonly List<MagicaCloth> Cloths=new List<MagicaCloth>();
            public Action<MagicaCloth,bool> Handler;public Vector3 LastPosition;public float LastTime;
        }
        readonly Dictionary<int,Family> families=new Dictionary<int,Family>();
        AbbotVisual visual;Action<string> log;int selected=-1;bool released;
        string status="waiting for source family";
        static readonly MethodInfo managerInitialize=typeof(MagicaManager).GetMethod("Initialize",BindingFlags.Static|BindingFlags.NonPublic,null,Type.EmptyTypes,null);
        static readonly MethodInfo completeJobs=typeof(ClothManager).GetMethod("CompleteJob",BindingFlags.Instance|BindingFlags.NonPublic,null,Type.EmptyTypes,null);
        public static AbbotScarfCloth Attach(AbbotVisual visual,Action<string> logger)
        {
            if(visual==null||!visual.Root)throw new ArgumentException("Scarf visual source missing");
            var c=visual.Root.gameObject.AddComponent<AbbotScarfCloth>();c.visual=visual;c.log=logger;
            try{EnsureManager();if(visual.ActiveFamily>=0)c.SetFamily(visual.ActiveFamily);}catch(Exception e){c.status="manager unavailable; source scarf retained";logger?.Invoke("BA_ABBOT_SCARF_INIT_FAILED "+e);c.released=true;}
            return c;
        }
        static bool ManagerReady(){var manager=MagicaManager.Cloth;return manager!=null&&manager.IsValid();}
        static void FinishJobs(){if(ManagerReady())completeJobs?.Invoke(MagicaManager.Cloth,null);}
        static void EnsureManager()
        {
            // BepInEx may load after Unity's runtime-attribute scan. Never reset
            // another user's live Magica manager or take over its global settings.
            if(ManagerReady())return;
            if(managerInitialize==null)throw new MissingMethodException("Pinned Magica manager initializer missing");
            managerInitialize.Invoke(null,null);
            if(!ManagerReady())throw new InvalidOperationException("Magica manager did not initialize");
            MagicaManager.SetSimulationFrequency(90);MagicaManager.SetMaxSimulationCountPerFrame(3);
        }
        public void SetFamily(int family)
        {
            if(released||selected==family)return;
            selected=family;
            foreach(var f in families.Values){f.Reset=true;Enable(f,f.Id==selected&&Visible(f));}
            status=families.TryGetValue(family,out var cached)&&cached.Ready&&!cached.Failed?"ready family "+family:"family "+family+" pending";
        }
        bool Visible(Family f)=>visual.FamilySkins.TryGetValue(f.Id,out var skins)&&skins.Any(s=>s&&s.enabled&&s.gameObject.activeInHierarchy);
        Family Create(int id)
        {
            FinishJobs();
            if(!visual.FamilyContacts.TryGetValue(id,out var contact)||!contact||!contact.sharedMesh)throw new InvalidOperationException("Exact robe contact missing for family "+id);
            if(!visual.FamilySkins.TryGetValue(id,out var skins))throw new InvalidOperationException("Scarf family missing "+id);
            var names=new HashSet<string>(visual.Payload.renderers.Where(r=>r.familyId==id&&r.role=="scarf").Select(r=>r.name),StringComparer.Ordinal);
            var scarves=skins.Where(s=>s&&names.Contains(s.name)).ToArray();
            if(scarves.Length!=2)throw new InvalidOperationException("Expected two source scarf panels for family "+id);
            var f=new Family{Id=id,Contact=contact,Scarves=scarves,BuildAfter=Time.frameCount+2,LastPosition=visual.Root.position,LastTime=Time.unscaledTime};
            families.Add(id,f);contact.forceRenderingOff=true;contact.enabled=true;
            try
            {
                var robe=CreateCloth(f,contact,true,null);
                foreach(var scarf in scarves)CreateCloth(f,scarf,false,robe);
                f.Handler=(c,ok)=>Built(f,c,ok);
                return f;
            }
            catch{DisposeFamily(f);families.Remove(id);throw;}
        }
        MagicaCloth CreateCloth(Family family,SkinnedMeshRenderer skin,bool fixedSurface,MagicaCloth partner)
        {
            var host=new GameObject(fixedSurface?"BA_V97_Fixed_Robe_Contact":"BA_V97_Scarf_Robe_Contact");host.layer=visual.Root.gameObject.layer;host.SetActive(false);host.transform.SetParent(visual.Root,false);
            var c=host.AddComponent<MagicaCloth>();c.DisableAutoBuild();family.Cloths.Add(c);
            var d=c.SerializeData;d.clothType=ClothProcess.ClothType.MeshCloth;d.sourceRenderers=new List<Renderer>{skin};d.paintMode=ClothSerializeData.PaintMode.Manual;
            var attributes=skin.sharedMesh.vertices.Select(p=>fixedSurface||p.y>=2.1f?VertexAttribute.Fixed:VertexAttribute.Move).ToArray();
            c.GetSerializeData2().vertexAttributeList=new List<VertexAttribute[]>{attributes};
            d.reductionSetting.simpleDistance=0;d.reductionSetting.shapeDistance=0;d.updateMode=ClothUpdateMode.Normal;
            d.animationPoseRatio=1;d.blendWeight=1;d.gravity=fixedSurface?0:9.81f;d.gravityFalloff=0;d.stablizationTimeAfterReset=.2f;
            d.distanceConstraint.stiffness=new CurveSerializeData(1);d.triangleBendingConstraint.stiffness=.35f;d.damping=new CurveSerializeData(.35f);d.radius=new CurveSerializeData(.004f);
            d.angleRestorationConstraint.useAngleRestoration=!fixedSurface;d.angleRestorationConstraint.stiffness=new CurveSerializeData(.12f);d.angleRestorationConstraint.velocityAttenuation=.9f;
            d.angleLimitConstraint.useAngleLimit=false;d.motionConstraint.useMaxDistance=false;d.motionConstraint.useBackstop=false;
            d.selfCollisionConstraint.selfMode=SelfCollisionConstraint.SelfCollisionMode.None;
            d.selfCollisionConstraint.syncMode=partner?SelfCollisionConstraint.SelfCollisionMode.FullMesh:SelfCollisionConstraint.SelfCollisionMode.None;
            d.selfCollisionConstraint.syncPartner=partner;d.selfCollisionConstraint.surfaceThickness=new CurveSerializeData(.004f);d.selfCollisionConstraint.clothMass=fixedSurface?1:.15f;
            d.colliderCollisionConstraint.mode=ColliderCollisionConstraint.Mode.None;d.colliderCollisionConstraint.colliderList=new List<ColliderComponent>();
            d.wind.influence=0;d.wind.movingWind=0;d.inertiaConstraint.worldInertia=.3f;d.inertiaConstraint.localInertia=.5f;d.inertiaConstraint.depthInertia=.3f;
            d.inertiaConstraint.teleportMode=InertiaConstraint.TeleportMode.Keep;d.inertiaConstraint.teleportDistance=20;d.inertiaConstraint.teleportRotation=180;
            host.SetActive(true);c.Initialize();return c;
        }
        void Built(Family f,MagicaCloth c,bool success)
        {
            if(released||f.Failed)return;
            if(!success){Fail(f,new InvalidOperationException(c.Process.Result.GetResultString()));return;}
            if(!f.Completed.Add(c))return;
            if(f.Completed.Count==3)
            {
                if(f.Cloths.Skip(1).Any(s=>s.SyncPartnerCloth!=f.Cloths[0])){Fail(f,new InvalidOperationException("Scarf partner differs from actual robe"));return;}
                f.Ready=true;f.Reset=true;Enable(f,f.Id==selected&&Visible(f));status="ready family "+f.Id;
                log?.Invoke("BA_ABBOT_SCARF_READY family="+f.Id+" panels=2 fixedRobeVertices="+f.Contact.sharedMesh.vertexCount+" legColliders=0");
            }
        }
        void Enable(Family f,bool enabled)
        {
            if(f.Failed)return;
            if(f.Cloths.Any(c=>c&&c.enabled!=enabled))FinishJobs();
            if(f.Contact)f.Contact.enabled=enabled;
            foreach(var c in f.Cloths)if(c&&c.enabled!=enabled)c.enabled=enabled;
        }
        void LateUpdate()
        {
            if(released||visual==null||selected<0)return;
            try
            {
                if(!families.TryGetValue(selected,out var f))f=Create(selected);
                if(f.Failed||f.Frozen)return;
                bool visible=Visible(f);Enable(f,visible);if(!visible){f.Reset=true;return;}
                if(!f.Started&&Time.frameCount>=f.BuildAfter)
                {
                    f.Started=true;foreach(var c in f.Cloths.ToArray()){if(f.Failed)break;c.OnBuildComplete+=f.Handler;if(!c.BuildAndRun())throw new InvalidOperationException("Manual scarf build rejected");}
                }
                if(f.Started&&!f.Ready&&!f.Failed&&++f.BuildWaitTicks>900)throw new InvalidOperationException("Scarf build timeout");
                if(f.Ready)
                {
                    float now=Time.unscaledTime;
                    if(f.Reset||(visual.Root.position-f.LastPosition).sqrMagnitude>9||now-f.LastTime>.4f){FinishJobs();foreach(var c in f.Cloths)if(c)c.ResetCloth(true);f.Reset=false;}
                    f.LastPosition=visual.Root.position;f.LastTime=now;
                }
            }
            catch(Exception e)
            {
                if(families.TryGetValue(selected,out var f))Fail(f,e);
                else{status="family unavailable; source scarf retained";log?.Invoke("BA_ABBOT_SCARF_FAILED family="+selected+" "+e);selected=-1;}
            }
        }
        void Fail(Family f,Exception error)
        {
            f.Failed=true;f.Ready=false;status="family "+f.Id+" disabled; source scarf retained";
            DisposeFamily(f);log?.Invoke("BA_ABBOT_SCARF_FAILED family="+f.Id+" source skin retained: "+error);
        }
        public void BakeInto(SkinnedMeshRenderer source,Mesh destination)
        {
            if(released||!families.TryGetValue(selected,out var f)||!f.Ready||f.Failed||!f.Scarves.Contains(source))return;
            // The custom Magica render mesh/bones are the actual simulated
            // surface. BakeMesh reads that surface, as verified by V97 probes.
            // Complete the pending render write before taking the inert copy.
            FinishJobs();
            foreach(var c in f.Cloths)if(c)c.SetTimeScale(0);
            source.BakeMesh(destination,false);f.Frozen=true;
        }
        void OnEnable(){foreach(var f in families.Values)f.Reset=true;}
        void OnDisable(){foreach(var f in families.Values){f.Reset=true;Enable(f,false);}}
        void DisposeFamily(Family f)
        {
            FinishJobs();
            // Stop partner dependants before the fixed contact. Explicit
            // process disposal cancels async builds before source meshes go.
            for(int i=f.Cloths.Count-1;i>=0;i--)
            {
                var c=f.Cloths[i];if(!c)continue;
                if(f.Handler!=null)c.OnBuildComplete-=f.Handler;
                try{c.enabled=false;c.Process.Dispose();}catch(Exception e){log?.Invoke("BA_ABBOT_SCARF_RELEASE "+e.Message);}
                if(c)Object.Destroy(c.gameObject);
            }
            f.Cloths.Clear();if(f.Contact)f.Contact.enabled=false;
        }
        public void Release()
        {
            if(released)return;released=true;foreach(var f in families.Values)DisposeFamily(f);families.Clear();status="released";
        }
        public object Snapshot()=>new{status,selectedFamily=selected,cachedFamilies=families.Count,readyFamilies=families.Values.Count(f=>f.Ready&&!f.Failed),frequency=ManagerReady()?MagicaManager.GetSimulationFrequency():0,maxSteps=ManagerReady()?MagicaManager.GetMaxSimulationCountPerFrame():0,scope="scarf to fixed animated robe; zero leg colliders; skirt remains source skinned"};
        void OnDestroy(){Release();}
    }
}
