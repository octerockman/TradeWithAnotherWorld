using System;
using UnityEngine;
namespace BlackAbbey.ReliquaryGuard
{
    // The player clips permit a round shield to roll freely. Fit this kite
    // shield by wrist roll only: keep the actual player hand position,
    // shield-facing normal, arm trajectory and attack motion unchanged.
    [DefaultExecutionOrder(10500)]
    public sealed class GuardPlayerShieldFit:MonoBehaviour
    {
        public Transform hand,visual;public Vector3 localNormal,localUp;Quaternion baseline,applied;bool hasApplied;
        public static GuardPlayerShieldFit Configure(GuardVisual v){var p=v.Root.gameObject.AddComponent<GuardPlayerShieldFit>();p.visual=v.Root;p.hand=v.Named["LeftHand"];var item=Array.Find(v.Payload.items,x=>x.role=="Shield");var attach=v.Named[item.attachmentName];p.localNormal=p.hand.InverseTransformDirection(attach.TransformDirection(GuardVisual.Q(item.rotation)*Vector3.down));p.localUp=p.hand.InverseTransformDirection(attach.TransformDirection(GuardVisual.Q(item.rotation)*Vector3.forward));return p;}
        public void Apply(){if(hasApplied&&Quaternion.Angle(hand.localRotation,applied)<.0005f)hand.localRotation=baseline;baseline=hand.localRotation;var normal=hand.TransformDirection(localNormal).normalized;var up=hand.TransformDirection(localUp).normalized;var target=Vector3.ProjectOnPlane(visual.up,normal);if(target.sqrMagnitude<.0001f){hasApplied=false;return;}hand.rotation=Quaternion.FromToRotation(up,target.normalized)*hand.rotation;applied=hand.localRotation;hasApplied=true;}
        void LateUpdate()=>Apply();
    }
}
