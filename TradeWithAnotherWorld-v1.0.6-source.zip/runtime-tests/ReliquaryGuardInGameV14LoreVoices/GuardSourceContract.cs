using System;
using System.IO;
namespace BlackAbbey.ReliquaryGuard
{
    public static class GuardSourceContract
    {
        public const string PayloadSha256="81bcafb062f777aeebd26ceed01199f2337ad7d5a4afe4eec89cb41e342e81d2";
        public const string NativeSha256="237e0ec41106963a7a5b6f7ff75f289b1d8a255c9200dd097ca219049def652c";
        public const string PresentationSha256="a2c33cd88459130f52a9ea362ee47612f15e4ed82c8c5b931b84ac05ceaf0fa9";
        public static GuardPresentationSettings Presentation(string path){if(GuardVisual.Hash(path)!=PresentationSha256)throw new InvalidDataException("Guard presentation differs from checked source");return GuardPresentationSettings.Read(path);}
        public static GuardPayload Require(string path){if(!File.Exists(path)||GuardVisual.Hash(path)!=PayloadSha256)throw new InvalidDataException("Guard visual differs from the checked payload");var payload=GuardVisual.Read(path);if(payload.sourceNative?.sha256!=NativeSha256)throw new InvalidDataException("Guard visual authority changed");return payload;}
    }
}
