using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Jotunn.Managers;
using UnityEngine;
using Object=UnityEngine.Object;
namespace BlackAbbey.ReliquaryGuard
{
    public static class GuardRedDeathEffects
    {
        static readonly List<Object> owned=new List<Object>();
        public static EffectList Build(GameObject native,GameObject nativePlayer,bool hit=false){
            var character=native?native.GetComponent<Character>():null;var player=nativePlayer?nativePlayer.GetComponent<Character>():null;
            if(!character||!player)throw new InvalidOperationException("Native Guard source and player blood are required.");
            // Red tint multiplied by a green Draugr texture is not red blood.
            // Borrow the actual native player blood visual, never its hurt voice.
            var blood=player.m_hitEffects.m_effectPrefabs.SingleOrDefault(e=>e?.m_prefab&&e.m_prefab.name=="vfx_player_hit");
            var source=blood?.m_prefab;
            if(!SafeBloodVisual(source))throw new InvalidOperationException("Verified native vfx_player_hit visual is unavailable or unsafe.");
            var result=new List<EffectList.EffectData>();
            foreach(var effect in (hit?character.m_hitEffects:character.m_deathEffects).m_effectPrefabs){
                if(effect?.m_prefab==null)continue;var original=effect.m_prefab;
                if(original.GetComponentInChildren<Ragdoll>(true)||original.GetComponentInChildren<SkinnedMeshRenderer>(true)||original.GetComponentInChildren<Character>(true))continue;
                // Retain the established audio-only slots. Replace inherited
                // green visuals once; custom corpse/puff ownership stays separate.
                if(!original.GetComponentInChildren<Renderer>(true)&&!original.GetComponentInChildren<ParticleSystem>(true)&&!original.GetComponentInChildren<Light>(true))result.Add(effect);
            }
            var clone=PrefabManager.Instance.CreateClonedPrefab("BA_Guard_RedBlood_"+(hit?"Hit":"Death"),source);owned.Add(clone);clone.SetActive(true);
            // Native red materials and textures remain shared and immutable.
            var own=(EffectList.EffectData)typeof(object).GetMethod("MemberwiseClone",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(blood,null);own.m_prefab=clone;result.Add(own);
            GuardPlugin.Log("RG_RED_EFFECTS role="+(hit?"hit":"death")+" source=vfx_player_hit nativeUnchanged=true ownRagdollAndPuff=true");return new EffectList{m_effectPrefabs=result.ToArray()};
        }
        internal static bool SafeBloodVisual(GameObject source)
        {
            // Installed native vfx_player_hit has a root ZNetView and timed
            // destruction. Preserve that effect lifecycle on the private clone;
            // a network component alone does not make a blood effect an actor.
            return source && source.name=="vfx_player_hit" &&
                source.GetComponentInChildren<ParticleSystem>(true) && source.GetComponentInChildren<Renderer>(true) &&
                !source.GetComponentInChildren<Character>(true) && !source.GetComponentInChildren<Ragdoll>(true) &&
                !source.GetComponentInChildren<Projectile>(true) && !source.GetComponentInChildren<Aoe>(true) &&
                !source.GetComponentInChildren<EffectArea>(true) && !source.GetComponentInChildren<SkinnedMeshRenderer>(true) &&
                source.GetComponentsInChildren<ZNetView>(true).All(v=>v.gameObject==source);
        }
        public static void Shutdown(){foreach(var resource in owned)if(resource)Object.Destroy(resource);owned.Clear();}
    }
}
