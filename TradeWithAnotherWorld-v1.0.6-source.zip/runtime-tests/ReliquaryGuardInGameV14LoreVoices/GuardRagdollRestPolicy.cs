using System;
namespace BlackAbbey.ReliquaryGuard
{
    // Observe actual physics; elapsed time alone can never release speech.
    public sealed class GuardRagdollRestPolicy
    {
        public const float LinearSpeed=.06f,AngularSpeed=.25f,QuietSeconds=.4f,MinimumAge=.55f,MaximumWaitSeconds=8f;
        public float QuietFor{get;private set;}
        public bool Settled{get;private set;}
        public void Observe(float age,float dt,int steps,bool bodiesValid,bool supported,float maximumLinear,float maximumAngular)
        {
            bool quiet=Finite(age)&&age>=0&&Finite(dt)&&dt>0&&bodiesValid&&supported&&Finite(maximumLinear)&&Finite(maximumAngular)&&maximumLinear>=0&&maximumAngular>=0&&maximumLinear<=LinearSpeed&&maximumAngular<=AngularSpeed;
            QuietFor=quiet?QuietFor+Math.Min(dt,.05f):0;
            Settled=quiet&&age>=MinimumAge&&steps>=3&&QuietFor+1e-6f>=QuietSeconds;
        }
        public void Reset(){QuietFor=0;Settled=false;}
        static bool Finite(float v)=>!float.IsNaN(v)&&!float.IsInfinity(v);
    }
}
