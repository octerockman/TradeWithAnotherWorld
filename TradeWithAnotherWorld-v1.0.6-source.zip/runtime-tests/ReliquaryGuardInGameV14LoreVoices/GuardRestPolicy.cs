namespace BlackAbbey.ReliquaryGuard
{
    // UID-based, reproducible per actor; no Unity random state or reload reroll.
    internal static class GuardRestPolicy
    {
        internal const int Standing = 1, Seated = 2;
        internal static int Choose(long user, uint id)
        {
            unchecked {
                ulong n = (ulong)user ^ ((ulong)id + 0x9e3779b97f4a7c15UL);
                n = (n ^ (n >> 30)) * 0xbf58476d1ce4e5b9UL;
                n = (n ^ (n >> 27)) * 0x94d049bb133111ebUL;
                return Bucket((uint)(n ^ (n >> 31)) % 10);
            }
        }
        internal static int Bucket(uint n) => n < 6 ? Standing : Seated;
        internal static bool Valid(int n) => n == Standing || n == Seated;
        internal static bool Wake(bool alerted, bool target, bool directed, bool hurt, bool attacking)
            => alerted || target || directed || hurt || attacking;
    }
}
