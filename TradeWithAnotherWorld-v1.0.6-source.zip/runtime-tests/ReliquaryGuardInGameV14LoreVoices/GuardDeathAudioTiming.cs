using System;
namespace BlackAbbey.ReliquaryGuard
{
    public static class GuardDeathAudioTiming
    {
        public const double StartLead=.02,SpeechDelay=1.5;
        public readonly struct Plan
        {
            public readonly double InitialAt,SpeechAt;
            public readonly float Lifetime;
            public Plan(double initial,double speech,float lifetime){InitialAt=initial;SpeechAt=speech;Lifetime=lifetime;}
        }
        public static Plan Schedule(double dspNow,float painSeconds,float armorSeconds,float speechSeconds)
        {
            if(double.IsNaN(dspNow)||double.IsInfinity(dspNow)||dspNow<0||!Finite(painSeconds)||!Finite(armorSeconds)||!Finite(speechSeconds)||painSeconds<0||armorSeconds<0||speechSeconds<0)throw new ArgumentOutOfRangeException();
            double initial=dspNow+StartLead,speech=dspNow+SpeechDelay;
            return new Plan(initial,speech,(float)(Math.Max(StartLead+Math.Max(painSeconds,armorSeconds),SpeechDelay+speechSeconds)+.3));
        }
        static bool Finite(float v)=>!float.IsNaN(v)&&!float.IsInfinity(v);
    }
}
