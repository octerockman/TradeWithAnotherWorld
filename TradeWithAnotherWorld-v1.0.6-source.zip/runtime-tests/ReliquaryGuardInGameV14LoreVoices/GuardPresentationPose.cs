using System;
using System.Collections.Generic;
using System.IO;
using System.Globalization;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using UnityEngine;

namespace BlackAbbey.ReliquaryGuard
{
    [Serializable] public sealed class GuardPresentationSettings
    {
        public string schema;public float bodyScale,maximumTorsoLean,minimumHeadPitch,maximumHeadPitch,capsuleHeight,capsuleRadius,eyeHeight;public float[] swordDirection,shieldDirection;
        public static GuardPresentationSettings Read(string path){
            var serializer=JsonSerializer.Create(new JsonSerializerSettings{ContractResolver=new DefaultContractResolver(),TypeNameHandling=TypeNameHandling.None,Culture=CultureInfo.InvariantCulture,MaxDepth=12,CheckAdditionalContent=true});GuardPresentationSettings s;
            using(var r=new JsonTextReader(new StringReader(File.ReadAllText(path))))s=serializer.Deserialize<GuardPresentationSettings>(r);
            if(s==null||s.schema!="reliquary-guard.presentation.v7"||s.bodyScale<1.1f||s.bodyScale>1.4f||s.maximumTorsoLean<0||s.maximumTorsoLean>20||s.capsuleHeight<2||s.capsuleHeight>2.5f||s.capsuleRadius<.24f||s.capsuleRadius>.4f||s.swordDirection?.Length!=3||s.shieldDirection?.Length!=3)throw new InvalidDataException("Guard presentation inventory differs from the checked candidate");return s;
        }
    }
    // Presentation only: the native Animator and AI still supply locomotion,
    // attack timing and body motion. Apply after the authored shield forearm.
    public sealed class GuardPresentationPose:MonoBehaviour
    {
        public Transform visual,chest,head,rightHand,leftHand;public Vector3 chestLocalUp,headLocalForward,swordLocalDirection,shieldLocalDirection,shieldLocalUp,swordDirection,shieldDirection;public float maximumTorsoLean,minimumHeadPitch,maximumHeadPitch;
        readonly Dictionary<Transform,Quaternion> baseline=new Dictionary<Transform,Quaternion>(),applied=new Dictionary<Transform,Quaternion>();
        public static GuardPresentationPose Configure(GuardVisual v,GuardPresentationSettings s){
            var p=v.Root.gameObject.AddComponent<GuardPresentationPose>();p.visual=v.Root;p.maximumTorsoLean=s.maximumTorsoLean;p.minimumHeadPitch=s.minimumHeadPitch;p.maximumHeadPitch=s.maximumHeadPitch;p.swordDirection=GuardVisual.V(s.swordDirection);p.shieldDirection=GuardVisual.V(s.shieldDirection);p.chest=v.Named["Spine1"];p.head=v.Named["Head"];p.rightHand=v.Named["RightHand"];p.leftHand=v.Named["LeftHand"];
            p.chestLocalUp=p.chest.InverseTransformDirection(v.Root.up);p.headLocalForward=p.head.InverseTransformDirection(v.Root.forward);
            var sword=Array.Find(v.Payload.items,x=>x.role=="Sword");var shield=Array.Find(v.Payload.items,x=>x.role=="Shield");
            // Item mesh space is D(-x,y,z), not world C(-x,z,-y).
            p.swordLocalDirection=p.rightHand.InverseTransformDirection(v.Named[sword.attachmentName].TransformDirection(GuardVisual.Q(sword.rotation)*Vector3.back));
            p.shieldLocalDirection=p.leftHand.InverseTransformDirection(v.Named[shield.attachmentName].TransformDirection(GuardVisual.Q(shield.rotation)*Vector3.down));
            p.shieldLocalUp=p.leftHand.InverseTransformDirection(v.Named[shield.attachmentName].TransformDirection(GuardVisual.Q(shield.rotation)*Vector3.forward));
            v.Root.localScale=Vector3.one*s.bodyScale;return p;
        }
        void SetWorld(Transform bone,Quaternion rotation){baseline[bone]=bone.localRotation;bone.rotation=rotation;applied[bone]=bone.localRotation;}
        public void Apply(float strength){
            foreach(var pair in applied)if(pair.Key&&Quaternion.Angle(pair.Key.localRotation,pair.Value)<.0005f)pair.Key.localRotation=baseline[pair.Key];applied.Clear();baseline.Clear();strength=Mathf.Clamp01(strength);if(strength<=0)return;
            var up=visual.up;var fwd=visual.forward;
            var current=chest.TransformDirection(chestLocalUp).normalized;float lean=Vector3.Angle(up,current);
            if(lean>maximumTorsoLean){var desired=Vector3.Slerp(up,current,maximumTorsoLean/lean);SetWorld(chest,Quaternion.Slerp(Quaternion.identity,Quaternion.FromToRotation(current,desired),strength)*chest.rotation);}
            current=head.TransformDirection(headLocalForward).normalized;float pitch=Mathf.Asin(Mathf.Clamp(Vector3.Dot(current,up),-1,1))*Mathf.Rad2Deg;float clamped=Mathf.Clamp(pitch,minimumHeadPitch,maximumHeadPitch);
            if(Mathf.Abs(pitch-clamped)>.01f){var horizontal=Vector3.ProjectOnPlane(current,up).normalized;if(horizontal.sqrMagnitude<.5f)horizontal=fwd;var desired=horizontal*Mathf.Cos(clamped*Mathf.Deg2Rad)+up*Mathf.Sin(clamped*Mathf.Deg2Rad);SetWorld(head,Quaternion.Slerp(Quaternion.identity,Quaternion.FromToRotation(current,desired),strength)*head.rotation);}
            Aim(rightHand,swordLocalDirection,visual.TransformDirection(swordDirection).normalized,strength);
            var sourceFrame=Quaternion.LookRotation(leftHand.TransformDirection(shieldLocalDirection),leftHand.TransformDirection(shieldLocalUp));var targetFrame=Quaternion.LookRotation(visual.TransformDirection(shieldDirection),visual.up);var shieldDelta=targetFrame*Quaternion.Inverse(sourceFrame);SetWorld(leftHand,Quaternion.Slerp(Quaternion.identity,shieldDelta,strength)*leftHand.rotation);
        }
        void Aim(Transform bone,Vector3 local,Vector3 desired,float strength){var delta=Quaternion.FromToRotation(bone.TransformDirection(local),desired);SetWorld(bone,Quaternion.Slerp(Quaternion.identity,delta,strength)*bone.rotation);}
    }
}
