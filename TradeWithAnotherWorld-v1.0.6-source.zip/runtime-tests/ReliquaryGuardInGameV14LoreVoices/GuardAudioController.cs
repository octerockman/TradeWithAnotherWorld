using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Audio;
using Object = UnityEngine.Object;

namespace BlackAbbey.ReliquaryGuard
{
    // Presentation only. All attacks, hits, blocks, navigation and death are native.
    public sealed class GuardAudioController : MonoBehaviour
    {
        static readonly HashSet<GuardAudioController> Actors = new HashSet<GuardAudioController>();
        static readonly List<GameObject> Tails = new List<GameObject>();
        // Death happens once per actor. Cross-actor history prevents repeated
        // pain takes (and repeated spoken takes when alternatives are supplied).
        static string lastDeathPain,lastDeathSpeech;
        static float nextIdleSpeech;
        MonsterAI ai; ZNetView view; float nextIdleAt; string speechGroup;
        GuardAudioBank bank; AudioMixerGroup mixer; Humanoid human; Transform head;
        readonly GuardAudioPolicy.Gate gate = new GuardAudioPolicy.Gate();
        readonly Dictionary<string,string> previous = new Dictionary<string,string>();
        readonly Dictionary<string,int> counts = new Dictionary<string,int>();
        System.Random random; AudioSource voice; AudioSource[] effects;
        Vector3 lastPosition; float walked, lastYaw, turned, voiceUntil, attackQuietUntil;
        bool dead, wasBlocking; string failure,deathIdentity;

        public static void Attach(GameObject actor, GuardAudioBank bank, AudioMixerGroup mixer)
        {
            if (!actor || !actor.activeInHierarchy || !actor.GetComponent<GuardInstance>() || actor.GetComponent<GuardAudioController>() || bank == null || !bank.Ready || !mixer) return;
            var view = actor.GetComponent<ZNetView>(); if (!view || !view.IsValid()) return;
            var c = actor.AddComponent<GuardAudioController>();
            try
            {
                c.bank = bank; c.mixer = mixer; c.human = actor.GetComponent<Humanoid>(); c.random = new System.Random(actor.GetInstanceID());c.deathIdentity=GuardDeathPresentation.ActorIdentity(actor);
                c.ai = actor.GetComponent<MonsterAI>(); c.view = view;
                c.nextIdleAt = Time.time + GuardDialoguePolicy.FirstIdleDelay(c.random.NextDouble());
                c.head = actor.GetComponentInChildren<Animator>()?.GetBoneTransform(HumanBodyBones.Head) ?? actor.transform;
                c.voice = c.MakeSource(c.head, "RG Voice", true);
                c.effects = Enumerable.Range(0,4).Select(i => c.MakeSource(actor.transform, "RG Foley " + i, false)).ToArray();
                c.lastPosition = actor.transform.position; c.lastYaw = actor.transform.eulerAngles.y;
                Actors.Add(c); GuardAudioHooks.AttachRelay(actor);
                var ai = actor.GetComponent<MonsterAI>(); if(ai && ai.IsAlerted()) GuardAudioHooks.Relay(c.human)?.Alert();
            }
            catch (Exception error) { c.failure = error.Message; GuardPlugin.Log("RG_AUDIO_ACTOR_FAILED " + error); }
        }
        AudioSource MakeSource(Transform parent, string name, bool speech)
        {
            var node = new GameObject(name); node.transform.SetParent(parent, false);
            if (!speech) node.transform.localPosition = Vector3.up * 1.2f;
            var source = node.AddComponent<AudioSource>(); Configure(source, mixer, speech); return source;
        }
        static void Configure(AudioSource source, AudioMixerGroup mixer, bool speech)
        {
            source.playOnAwake = false; source.loop = false; source.outputAudioMixerGroup = mixer;
            source.spatialBlend = 1; source.rolloffMode = AudioRolloffMode.Linear; source.minDistance = 2; source.maxDistance = speech ? 24 : 18;
            source.dopplerLevel = 0; source.spread = 0; source.pitch = 1; source.priority = speech ? 80 : 140;
        }
        GuardAudioBank.ClipRecord Pick(string group)
        {
            previous.TryGetValue(group, out var last); var cue = bank.Pick(group, random, last);
            if (cue != null) previous[group] = cue.id; return cue;
        }
        void Count(string group) { counts.TryGetValue(group, out var n); counts[group] = n + 1; }
        void Play(string group, float cooldown, float gain = 1, Vector3? point = null)
        {
            if (dead || effects == null || !gate.Take(group, Time.time, cooldown)) return;
            var cue = Pick(group); if (cue == null || !cue.Clip) return;
            var source = effects.FirstOrDefault(s => !s.isPlaying);
            // Movement never steals a combat transient. Combat may replace the quietest movement slot.
            if (!source && (group == "armorWalk" || group == "armorTurn" || group == "cloth" || group == "shieldRaise")) return;
            if (!source) source = effects.OrderBy(s => s.volume).First();
            source.Stop(); source.transform.position = point ?? transform.position + Vector3.up * 1.2f;
            source.clip = cue.Clip; source.volume = cue.gain * gain; source.Play(); Count(group);
        }
        bool Speak(string group, float interval)
        {
            if (dead || !voice || Time.time < voiceUntil || !gate.Take("speech:"+GuardDialoguePolicy.CooldownGroup(group),Time.time,interval)) return false;
            var cue = Pick(group); if (cue == null || !cue.Clip) return false;
            voice.Stop(); voice.clip = cue.Clip; voice.volume = cue.gain; voice.Play(); voiceUntil = Time.time + cue.Clip.length; Count(group);
            speechGroup = group;
            return true;
        }
        void Update()
        {
            if (!human || bank == null || effects == null || dead) return;
            if (human.IsDead() || human.GetHealth() <= 0) { OnDeath(); return; }
            Vector3 at = transform.position; float distance = Vector3.ProjectOnPlane(at-lastPosition,Vector3.up).magnitude;
            float yaw = transform.eulerAngles.y; float angle = Mathf.Abs(Mathf.DeltaAngle(lastYaw,yaw));
            lastPosition = at; lastYaw = yaw;
            if (distance > 1.25f) { walked = turned = 0; return; }
            TickIdle();
            if (human.InAttack() || human.IsStaggering() || human.InDodge()) { walked = turned = 0; }
            else
            {
                walked += distance; turned += angle;
                if (walked >= .95f) { walked = 0; Play("armorWalk",.55f,.55f); Play("cloth",1.5f,.4f); }
                if (turned >= 70) { turned = 0; Play("armorTurn",1.5f,.5f); }
            }
            bool blocking = human.IsBlocking(); if (blocking && !wasBlocking) Play("shieldRaise",1.1f,.65f); wasBlocking = blocking;
        }
        bool QuietAllowed() => human && ai && GuardDialoguePolicy.QuietAllowed(
            !human.IsDead() && human.GetHealth() > 0, ai.enabled, ai.IsAlerted(), ai.GetTargetCreature(),
            human.InAttack(), human.IsStaggering(), human.InDodge());
        void TickIdle()
        {
            if (Time.time < nextIdleAt) return;
            nextIdleAt = Time.time + GuardDialoguePolicy.NextIdleDelay(random.NextDouble());
            if (!view || !view.IsValid() || !view.IsOwner() || Time.time < nextIdleSpeech || !QuietAllowed()) return;
            if (!Player.GetClosestPlayer(transform.position,18)) return;
            GuardAudioHooks.Relay(human)?.Idle();
        }
        public void OnIdleRequested()
        {
            if (Time.time < nextIdleSpeech || !QuietAllowed()) return;
            if (Speak("idleSpeech",70)) nextIdleSpeech = Time.time + GuardDialoguePolicy.IdleSharedInterval;
        }
        bool TargetCarriesRule()
        {
            var player = ai ? ai.GetTargetCreature() as Player : null;
            var inventory = player ? player.GetInventory() : null;
            if (inventory == null) return false;
            foreach (var item in inventory.GetAllItems())
                if (item?.m_dropPrefab && GuardDialoguePolicy.IsRule(item.m_dropPrefab.name)) return true;
            return false;
        }
        public void OnAlert()
        {
            // A quiet recollection must not suppress the actual alert warning.
            if (speechGroup == "idleSpeech" && voice) { voice.Stop(); voiceUntil = 0; }
            Speak(GuardDialoguePolicy.WarningGroup(TargetCarriesRule(),random.NextDouble()),25);
        }
        public void OnAttackWindup()
        {
            // The native attack relay sends windup only for combo level0.
            if (Time.time >= attackQuietUntil && random != null && random.NextDouble() < .25)
            {
                // A busy warning must not slide the retry window forward on
                // every combo hit and starve the attack line indefinitely.
                if(Speak("attack",8))attackQuietUntil=Time.time+2;
            }
        }
        public void OnAttackHit() => Play("swing",.12f);
        public void OnImpact(string material, Vector3 point)
        {
            if (material == "body") Play("body",.08f,1,point);
            else if (material == "stone") Play("stone",.1f,.8f,point);
        }
        public void OnDamaged(float actual)
        {
            if (actual <= 0 || !human || human.GetHealth() <= 0 || dead) return;
            if (voice && voice.isPlaying) { voice.Stop(); voiceUntil = 0; }
            Play("hurt",.7f);
        }
        public void OnBlock(bool parry)
        {
            Play(parry ? "parry" : "block",parry ? .7f : .1f);
            if (random != null && random.NextDouble() < GuardDialoguePolicy.DefenseChance(parry))
                Speak("voiceBlock",GuardDialoguePolicy.DefenseInterval);
        }
        public void OnDeath()
        {
            if (dead || bank == null || !bank.Ready || !mixer) return;
            double deathAt=AudioSettings.dspTime;dead = true;
            if (voice) voice.Stop(); if (effects != null) foreach (var s in effects) if(s) s.Stop();
            Tails.RemoveAll(t => !t); while(Tails.Count >= 6) { Object.Destroy(Tails[0]); Tails.RemoveAt(0); }
            var tail = new GameObject("RG Detached Death Audio"); tail.transform.position = transform.position + Vector3.up * 1.2f;
            // Reuse the two approved pain-vocal/impact takes; do not invent a
            // new voice or alter the accepted armor-collapse recordings.
            var pain=bank.Pick("hurt",random,lastDeathPain);if(pain!=null)lastDeathPain=pain.id;
            var armor=Pick("deathArmor");
            float painSeconds=pain?.Clip?pain.Clip.length:0,armorSeconds=armor?.Clip?armor.Clip.length:0;
            var plan=GuardDeathAudioTiming.Schedule(deathAt,painSeconds,armorSeconds,bank.MaximumDuration("death"));
            ScheduleDeath(tail,pain,"deathPain",true,plan.InitialAt);
            ScheduleDeath(tail,armor,"deathArmor",false,plan.InitialAt);
            // Queue immediately on the audio clock: no rendered-frame, pain
            // duration or ragdoll-settling gate can move the1.5s deadline.
            tail.AddComponent<GuardDeathVoiceFollow>().Configure(deathIdentity??GuardDeathPresentation.ActorIdentity(gameObject));
            if(ScheduleDeathSpeech(tail,bank,mixer,random,plan.SpeechAt))Count("deathSpeechScheduled");Count("deathQueued");
            Tails.Add(tail); Object.Destroy(tail,plan.Lifetime);
        }
        internal static bool ScheduleDeathSpeech(GameObject tail,GuardAudioBank bank,AudioMixerGroup mixer,System.Random random,double at)
        {
            var cue=bank?.Pick("death",random,lastDeathSpeech);if(cue==null||!cue.Clip||!mixer)return false;
            var source=tail.AddComponent<AudioSource>();Configure(source,mixer,true);source.clip=cue.Clip;source.volume=cue.gain;source.PlayScheduled(at);lastDeathSpeech=cue.id;
            GuardPlugin.Log("RG_DEATH_SPEECH_SCHEDULED cue="+cue.id+" delay=1.500s clock=DSP");
            Object.Destroy(tail,(float)Math.Max(0,at-AudioSettings.dspTime)+cue.Clip.length+.3f);return true;
        }
        void ScheduleDeath(GameObject tail,GuardAudioBank.ClipRecord cue,string group,bool speech,double at)
        {
            if(cue==null||!cue.Clip)return;
            var source=tail.AddComponent<AudioSource>();Configure(source,mixer,speech);
            source.clip=cue.Clip;source.volume=cue.gain;source.PlayScheduled(at);Count(group);
        }
        void DeathBeforeRemoval()
        {
            if (!dead && human) { try { if(human.IsDead() || human.GetHealth() <= 0) OnDeath(); } catch(Exception error) { GuardPlugin.Log("RG_AUDIO_TAIL_FAILED " + error.Message); } }
        }
        void OnDisable() { DeathBeforeRemoval(); if(voice)voice.Stop(); if(effects != null)foreach(var s in effects)if(s)s.Stop(); }
        void OnDestroy() { DeathBeforeRemoval(); Actors.Remove(this); }
        public object Snapshot() => new { enabled = bank != null && bank.Ready && mixer, dead, failure, events = counts, mixer = mixer ? mixer.name : null, sourceCount = effects != null ? 5 : 0, activeTails = Tails.Count(t => t) };
        public static object[] Snapshots() => Actors.Where(a => a).Select(a => a.Snapshot()).ToArray();
        public static void Shutdown() { foreach(var t in Tails)if(t)Object.Destroy(t); Tails.Clear(); Actors.Clear();lastDeathPain=lastDeathSpeech=null;nextIdleSpeech=0; }
    }
}
