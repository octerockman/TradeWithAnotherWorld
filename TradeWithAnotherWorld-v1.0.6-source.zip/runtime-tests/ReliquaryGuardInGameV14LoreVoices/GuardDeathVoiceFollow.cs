using UnityEngine;
namespace BlackAbbey.ReliquaryGuard
{
    // Spatial position only. The audio is already queued at death+1.5 DSP
    // seconds and survives the actor/corpse disappearing at its last position.
    public sealed class GuardDeathVoiceFollow:MonoBehaviour
    {
        string actorId;
        public void Configure(string id){actorId=id;}
        void Update()
        {
            if(actorId==null)return;
            var corpse=GuardDeathPresentation.FindCorpse(actorId);
            if(corpse)transform.position=corpse.VoicePosition;
        }
    }
}
