using HarmonyLib;
using UnityEngine;

namespace BlackAbbey.ReliquaryGuard
{
    // Only the Guard owns this component. Native Player_animator states were
    // read from the installed controller, not inferred from clip filenames.
    [DefaultExecutionOrder(9000)]
    public sealed class GuardRestingStart : MonoBehaviour
    {
        const string StyleKey = "twa_rg_rest_style", AwakeKey = "twa_rg_rest_awake";
        internal const string StandingState = "Base Layer.Movement", SittingState = "Base Layer.Emote_sit";
        static readonly int Movement = Animator.StringToHash(StandingState), Sit = Animator.StringToHash(SittingState),
            SittingDown = Animator.StringToHash("Base Layer.sit down"), Rising = Animator.StringToHash("Base Layer.standup 0");
        Humanoid human; MonsterAI ai; ZNetView view; ZSyncAnimation sync; Animator animator;
        bool applied, awake, rising, failed; int style;

        void OnEnable() { applied = false; Refresh(); }
        void Start() { Refresh(); }
        void LateUpdate() { Refresh(); HoldMovement(); }

        bool Refresh()
        {
            if (!human) human = GetComponent<Humanoid>();
            if (!ai) ai = GetComponent<MonsterAI>();
            if (!view) view = GetComponent<ZNetView>();
            if (!sync) sync = GetComponent<ZSyncAnimation>();
            if (!animator) animator = GetComponent<GuardPlayerAnimationBindings>()?.animator;
            if (failed || !human || human.IsDead() || human.GetHealth() <= 0 || !view || !view.IsValid()
                || !animator || !animator.isActiveAndEnabled || !gameObject.activeInHierarchy) return false;
            var z = view.GetZDO(); if (z == null) return false;
            style = z.GetInt(StyleKey, 0);
            if (!GuardRestPolicy.Valid(style)) {
                style = GuardRestPolicy.Choose(z.m_uid.UserID, z.m_uid.ID);
                if (view.IsOwner()) z.Set(StyleKey, style);
            }
            // Emerging threshold Guards already have a directed walk; never
            // insert a seated pose into that sequence. Native AI still senses
            // targets while a stationed Guard rests.
            bool wake = GuardRestPolicy.Wake(ai && ai.IsAlerted(), ai && ai.GetTargetCreature(),
                z.GetString("twa_ward_run", "").Length != 0 || (ai && !ai.enabled),
                human.GetHealth() < human.GetMaxHealth() || human.IsStaggering(), human.InAttack());
            bool nextAwake = awake || z.GetInt(AwakeKey, 0) != 0 || wake;
            if (view.IsOwner() && nextAwake && z.GetInt(AwakeKey, 0) == 0) z.Set(AwakeKey, 1);
            if (!applied) {
                awake = nextAwake;
                // Do not reset a live attack/reaction when geometry parking
                // re-enables an already running actor.
                if (!human.InAttack() && !human.IsStaggering()) ApplyInitial(style == GuardRestPolicy.Seated && !awake);
                applied = true;
            } else if (nextAwake && !awake) {
                awake = true; rising = true; SetSitting(false);
                // Native Emote_sit -> standup 0 -> Movement owns the rise.
            }
            return true;
        }

        void SetSitting(bool value)
        {
            animator.SetBool("emote_sit", value);
            if (view.IsOwner() && sync) sync.SetBool("emote_sit", value);
        }
        void ApplyInitial(bool seated)
        {
            animator.SetBool("wakeup", false); animator.SetBool("intro", false);
            animator.SetBool("onGround", true); animator.SetBool("blocking", false);
            animator.SetFloat("forward_speed", 0); animator.SetFloat("sideway_speed", 0);
            animator.SetFloat("statef", 4); animator.SetInteger("statei", 4);
            if (view.IsOwner() && sync) { sync.SetBool("wakeup", false); sync.SetBool("intro", false); }
            SetSitting(seated);
            int state = seated ? Sit : Movement;
            if (!animator.HasState(0, state)) {
                failed = true; SetSitting(false);
                GuardPlugin.Log("RG_REST_DISABLED actual Player controller is missing " + (seated ? SittingState : StandingState));
                return;
            }
            animator.Play(state, 0, 0); animator.Update(0);
            rising = false;
        }
        bool Locked()
        {
            if (!applied || failed || !human || human.IsDead() || human.IsStaggering()) return false;
            if (style == GuardRestPolicy.Seated && !awake) return true;
            if (!rising) return false;
            var state = animator.GetCurrentAnimatorStateInfo(0);
            var next = animator.IsInTransition(0) ? animator.GetNextAnimatorStateInfo(0) : default;
            bool busy = RestState(state.fullPathHash) || RestState(next.fullPathHash);
            if (!busy) rising = false;
            return busy;
        }
        static bool RestState(int hash) => hash == Sit || hash == SittingDown || hash == Rising;
        void HoldMovement()
        {
            if (view && view.IsValid() && view.IsOwner() && Locked()) {
                human.SetMoveDir(Vector3.zero); human.SetRun(false); human.SetWalk(false);
            }
        }
        void AfterAI() { if (Refresh()) HoldMovement(); }
        bool AllowAttack()
        {
            Refresh();
            // A native attack request is itself an engagement, even if target
            // acquisition and alert flag replication happened in this tick.
            if (applied && !awake && view && view.IsOwner()) {
                awake = true; rising = true; view.GetZDO().Set(AwakeKey, 1); SetSitting(false);
            }
            return !Locked();
        }
        public string Status() => "rest:" + (style == GuardRestPolicy.Seated ? "seated" : "standing") + ",awake:" + awake + ",rising:" + rising;

        [HarmonyPatch(typeof(MonsterAI), nameof(MonsterAI.UpdateAI))]
        static class SensingThenRest {
            [HarmonyPriority(Priority.Last)]
            static void Postfix(MonsterAI __instance) { __instance.GetComponent<GuardRestingStart>()?.AfterAI(); }
        }
        [HarmonyPatch(typeof(Humanoid), nameof(Humanoid.StartAttack))]
        static class FinishRiseBeforeAttack {
            static bool Prefix(Humanoid __instance, ref bool __result) {
                var own = __instance.GetComponent<GuardRestingStart>();
                if (!own || own.AllowAttack()) return true;
                __result = false; return false;
            }
        }
        [HarmonyPatch(typeof(Character), nameof(Character.SetMoveDir))]
        static class NoSeatedWandering {
            static void Prefix(Character __instance, ref Vector3 __0) {
                var own = __instance.GetComponent<GuardRestingStart>();
                if (own && own.Refresh() && own.Locked()) __0 = Vector3.zero;
            }
        }
    }
}
