using System;
namespace BlackAbbey.ReliquaryGuard
{
    // Audio selection only; never changes sensing, combat, movement or inventory.
    public static class GuardDialoguePolicy
    {
        public const string RulePrefab = "abbey_oath_tome";
        public const float IdleSharedInterval = 35, DefenseInterval = 18;
        public static bool IsRule(string prefab) => string.Equals(prefab, RulePrefab, StringComparison.Ordinal);
        public static string WarningGroup(bool carriesRule, double roll) => carriesRule && roll < .5 ? "warningBooks" : "warning";
        public static string CooldownGroup(string group) => group == "warningBooks" ? "warning" : group;
        public static double DefenseChance(bool parry) => parry ? .4 : .2;
        public static bool QuietAllowed(bool alive, bool aiEnabled, bool alerted, bool target, bool attacking, bool staggered, bool dodging) =>
            alive && aiEnabled && !alerted && !target && !attacking && !staggered && !dodging;
        public static float FirstIdleDelay(double roll) => 45 + (float)Math.Max(0, Math.Min(1, roll)) * 30;
        public static float NextIdleDelay(double roll) => 70 + (float)Math.Max(0, Math.Min(1, roll)) * 40;
    }
}
