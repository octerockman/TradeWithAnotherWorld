using System;
using System.Linq;
using UnityEngine;
namespace BlackAbbey.ReliquaryGuard
{
    [Serializable] public sealed class GuardFingerPose {public string boneName;public float[] position,rotation,scale;}
    [DefaultExecutionOrder(11000)]
    public sealed class GuardPlayerFingerGrip:MonoBehaviour
    {
        public Transform[] bones;public Vector3[] positions,scales;public Quaternion[] rotations;
        public static GuardPlayerFingerGrip Configure(GuardVisual visual){
            var poses=visual.Payload.fingerGrips;if(poses==null||poses.Length!=30)throw new InvalidOperationException("Required thirty-finger grip missing");var grip=visual.Root.gameObject.AddComponent<GuardPlayerFingerGrip>();grip.bones=poses.Select(p=>visual.Named[p.boneName]).ToArray();grip.positions=poses.Select(p=>GuardVisual.V(p.position)).ToArray();grip.rotations=poses.Select(p=>GuardVisual.Q(p.rotation)).ToArray();grip.scales=poses.Select(p=>GuardVisual.V(p.scale)).ToArray();grip.Apply();return grip;
        }
        public void Apply(){for(int i=0;i<bones.Length;i++){bones[i].localPosition=positions[i];bones[i].localRotation=rotations[i];bones[i].localScale=scales[i];}}
        void LateUpdate()=>Apply();
    }
}
