using System;
using System.Globalization;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace BlackAbbey.ReliquaryGuard
{
    // Plain authored DTOs use a managed reader. Unity's player serializer did
    // not populate the same DTO reliably in the reported Valheim0.1.0 session.
    public static class GuardPayloadReader
    {
        public const int MaximumBytes=16*1024*1024;
        public static GuardPayload Read(string path)
        {
            if(new FileInfo(path).Length>MaximumBytes)throw new InvalidDataException("Oversized guard payload");
            return Parse(File.ReadAllText(path));
        }
        public static GuardPayload Parse(string text)
        {
            if(string.IsNullOrWhiteSpace(text)||text.Length>MaximumBytes)throw new InvalidDataException("Empty/oversized guard payload");
            GuardPayload p;
            try{
                var serializer=JsonSerializer.Create(new JsonSerializerSettings{
                    ContractResolver=new DefaultContractResolver(),
                    TypeNameHandling=TypeNameHandling.None,MetadataPropertyHandling=MetadataPropertyHandling.Ignore,
                    MaxDepth=64,Culture=CultureInfo.InvariantCulture,CheckAdditionalContent=true
                });
                using(var reader=new JsonTextReader(new StringReader(text.TrimStart('\ufeff'))))p=serializer.Deserialize<GuardPayload>(reader);
            }catch(JsonException ex){throw new InvalidDataException("Invalid guard JSON: "+ex.Message,ex);}
            if(p==null)throw new InvalidDataException("Guard payload is null");
            if(p.schema!="reliquary-guard.runtime-visual.v1"||p.nodes?.Length!=56||p.renderers?.Length!=3||p.items?.Length!=2||p.materials?.Length!=5||p.bodyTriangles!=6848||p.totalTriangles!=11820||p.containsAnimationClips||p.containsGameOwnedMeshes)
                throw new InvalidDataException("Guard source inventory changed: schema="+p.schema+" nodes="+(p.nodes?.Length??-1)+" renderers="+(p.renderers?.Length??-1)+" items="+(p.items?.Length??-1)+" materials="+(p.materials?.Length??-1)+" body="+p.bodyTriangles+" equipped="+p.totalTriangles);
            if(p.sourceNative==null||string.IsNullOrWhiteSpace(p.sourceNative.path)||!Hex(p.sourceNative.sha256)||p.humanDescription?.human?.Length!=52||p.humanDescription.skeleton?.Length!=56||p.shieldForearmOffset?.Length!=4)
                throw new InvalidDataException("Incomplete Guard authority/Avatar data");
            if(p.nodes.Any(n=>n==null)||p.renderers.Any(m=>m==null)||p.items.Any(m=>m==null)||p.materials.Any(m=>m==null)||p.fingerGrips?.Length!=30)throw new InvalidDataException("Null/incomplete Guard inventory or grip entry");
            foreach(var material in p.materials)foreach(var map in new[]{material.diffuse,material.normal,material.metallicGloss})
                if(map==null||string.IsNullOrWhiteSpace(map.path)||!Hex(map.sha256))throw new InvalidDataException("Incomplete Guard material map:"+material.id);
            return p;
        }
        static bool Hex(string s)=>s!=null&&s.Length==64&&s.All(c=>c>='0'&&c<='9'||c>='a'&&c<='f');
    }
}
