using System;
namespace BlackAbbey.ReliquaryGuard
{
    // Input decisions only. Native Humanoid resolves shield direction, damage,
    // block power, the0.25s parry window, stagger and animation synchronization.
    public sealed class GuardDefensePolicy
    {
        public const float ReactionSeconds=.12f, HoldSeconds=.85f, RecoverySeconds=.65f;
        object threat;float age,remaining,recovery;bool reacted;
        public bool Blocking=>remaining>0;
        public int Raises{get;private set;}
        public bool Step(float dt,bool capable,bool incoming,object token)
        {
            if(float.IsNaN(dt)||float.IsInfinity(dt)||dt<0)throw new ArgumentOutOfRangeException(nameof(dt));
            recovery=Math.Max(0,recovery-dt);
            if(!capable){if(remaining>0)recovery=RecoverySeconds;remaining=0;return false;}
            if(remaining>0){remaining=Math.Max(0,remaining-dt);if(remaining<=0)recovery=RecoverySeconds;return remaining>0;}
            if(!incoming||token==null){threat=null;age=0;reacted=false;return false;}
            if(!ReferenceEquals(threat,token)){threat=token;age=0;reacted=false;}
            age+=dt;
            if(!reacted&&age>=ReactionSeconds&&recovery<=0){remaining=HoldSeconds;reacted=true;Raises++;return true;}
            return false;
        }
        public static bool CanContinue(bool attacking,bool chainWindow,bool targetInReach,bool interrupted,bool defending)
            =>attacking&&chainWindow&&targetInReach&&!interrupted&&!defending;
    }
}
