using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using Jotunn.Managers;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace BlackAbbey.ReliquaryGuard
{
    // Cosmetic local proxy driven by the owner's existing death event. It has
    // no Character, ZNetView, AI, Animator, damage receiver or loot component.
    public static class GuardDeathPresentation
    {
        public const float CorpseSeconds = GuardDeathTimeline.CorpseSeconds;
        const int MaximumCorpses = 6, MaximumSmoke = 8;
        static readonly List<Corpse> Corpses = new List<Corpse>();
        static readonly List<Smoke> Smokes = new List<Smoke>();
        static readonly Dictionary<string, float> Presented = new Dictionary<string, float>();
        static Material smokeMaterial;
        static int corpseLayer = -1, created, removed, puffs, smokeRemoved, duplicates, failures, capEvictions;
        static string lastFailure, sourceSmoke, sourceShader, collisionLayerSource;
        static bool prepared;
        static CorpseRecord last;
        public static string ActorIdentity(GameObject actor)
        {
            var view=actor?actor.GetComponent<ZNetView>():null;
            return view&&view.IsValid()?view.GetZDO().m_uid.ToString():"instance:"+actor.GetInstanceID();
        }
        public static Corpse FindCorpse(string actorId)=>Corpses.FirstOrDefault(c=>c&&c.Record.actorId==actorId&&c.Available);

        [Serializable] public sealed class CorpseRecord
        {
            public string actorId, lastFloorCollider;
            public float spawnedAt, disappearedAt, smokeAt, smokeEndedAt, lifetime, scale, smokeLeadSeconds, smokeTailSeconds;
            public int smokeParticlesAtHide, smokeCoverageRestarts;
            public bool hiddenUnderSmoke, capacityForcedExpiry;
            public int bodies, joints, colliders, renderers, skinnedBones, clonedRigidMeshes, fixedSteps, floorContacts;
            public float maximumPelvisTravel, maximumJointGap, maximumRenderedJointGap;
            public bool originalPoseCopied, originalSkinAndMaterialBindings, liveActorComponentsAbsent, expired;
        }

        public static object Prepare(GameObject ownPrefab, GameObject nativeGreyling)
        {
            if (!ownPrefab || !ownPrefab.GetComponent<GuardInstance>() || !nativeGreyling)
                throw new InvalidOperationException("Own marked Guard and native Greyling are required for death presentation.");
            var animator = ownPrefab.GetComponentInChildren<Animator>(true);
            if (!animator || !animator.avatar || !animator.avatar.isValid || !animator.avatar.isHuman)
                throw new InvalidOperationException("Corpse requires the actual imported Humanoid Avatar.");
            foreach (var bone in RequiredBones)
                if (!animator.GetBoneTransform(bone)) throw new InvalidOperationException("Required corpse bone missing: " + bone);
            var character = nativeGreyling.GetComponent<Character>();
            var effects = character?.m_deathEffects?.m_effectPrefabs ?? Array.Empty<EffectList.EffectData>();
            var candidates = effects.Where(e => e?.m_prefab).SelectMany(e => e.m_prefab.GetComponentsInChildren<ParticleSystemRenderer>(true))
                .Where(r => r.sharedMaterial && r.sharedMaterial.shader && r.sharedMaterial.shader.isSupported)
                .OrderByDescending(r => r.name.IndexOf("smoke", StringComparison.OrdinalIgnoreCase) >= 0 || r.sharedMaterial.name.IndexOf("smoke", StringComparison.OrdinalIgnoreCase) >= 0).ToArray();
            if (candidates.Length == 0) throw new InvalidOperationException("Native Greyling death effect has no supported particle material; refusing a pink/missing smoke substitute.");
            var source = candidates[0].sharedMaterial;
            if (!smokeMaterial)
            {
                smokeMaterial = new Material(source) { name = "RG Own Orange Red Death Smoke" };
                if (smokeMaterial.HasProperty("_TintColor")) smokeMaterial.SetColor("_TintColor", Color.white);
                if (smokeMaterial.HasProperty("_Color")) smokeMaterial.SetColor("_Color", Color.white);
                sourceSmoke = candidates[0].name + "/" + source.name; sourceShader = source.shader.name;
            }
            var skeleton = PrefabManager.Instance.GetPrefab("Skeleton");
            var ragdoll = skeleton ? skeleton.GetComponent<Character>()?.m_deathEffects?.m_effectPrefabs
                .Where(e => e?.m_prefab).Select(e => e.m_prefab.GetComponentInChildren<Ragdoll>(true)).FirstOrDefault(r => r) : null;
            var nativeCollider = ragdoll ? ragdoll.GetComponentsInChildren<Collider>(true).FirstOrDefault(c => c && !c.isTrigger) : null;
            corpseLayer = nativeCollider ? nativeCollider.gameObject.layer : LayerMask.NameToLayer("ragdoll");
            collisionLayerSource = nativeCollider ? "Actual loaded native ragdoll collider" : "Native named ragdoll layer";
            if (corpseLayer < 0)
            {
                // Some installed ragdoll templates populate their physical
                // children later and expose neither collider nor named layer.
                // The real Default layer is sufficient: every owned collider
                // explicitly includes world solids and excludes live character
                // layers below. This changes no global collision matrix.
                corpseLayer = LayerMask.NameToLayer("Default");
                collisionLayerSource = "Default fallback; per-owned-collider world includes and live-character exclusions";
            }
            if (corpseLayer < 0) throw new InvalidOperationException("Actual Default world collision layer was unavailable.");
            prepared = true;
            return new { prepared, seconds = CorpseSeconds, smokeStartsSeconds = GuardDeathTimeline.SmokeStartSeconds,
                minimumSmokeLeadSeconds = GuardDeathTimeline.MinimumSmokeLeadSeconds, minimumSmokeTailSeconds = GuardDeathTimeline.MinimumSmokeTailSeconds,
                collisionLayer = corpseLayer, collisionLayerName = LayerMask.LayerToName(corpseLayer), collisionLayerSource,
                sourceSmoke, sourceShader, nativeMediaExported = false, nativeMaterialModified = false,
                corpseBodies = 15, corpseJoints = 14, noCharacterOrLoot = true,
                scope = "Own posed visual hierarchy and actual own skin/materials; local fifteen-body ragdoll then own orange-red particle puff. Native Greyling particle material is borrowed read-only in memory." };
        }

        static readonly HumanBodyBones[] RequiredBones = { HumanBodyBones.Hips, HumanBodyBones.Chest, HumanBodyBones.Head,
            HumanBodyBones.LeftUpperArm, HumanBodyBones.LeftLowerArm, HumanBodyBones.LeftHand,
            HumanBodyBones.RightUpperArm, HumanBodyBones.RightLowerArm, HumanBodyBones.RightHand,
            HumanBodyBones.LeftUpperLeg, HumanBodyBones.LeftLowerLeg, HumanBodyBones.LeftFoot,
            HumanBodyBones.RightUpperLeg, HumanBodyBones.RightLowerLeg, HumanBodyBones.RightFoot };

        public static bool Present(GameObject actor)
        {
            if (!prepared || !actor || !actor.GetComponent<GuardInstance>()) return false;
            var view = actor.GetComponent<ZNetView>();
            string id = ActorIdentity(actor);
            foreach (var expired in Presented.Where(p => Time.time - p.Value > 60).Select(p => p.Key).ToArray()) Presented.Remove(expired);
            if (Presented.ContainsKey(id)) { duplicates++; return false; }
            Presented[id] = Time.time;
            GameObject root = null;
            try
            {
                if (Corpses.Count >= MaximumCorpses) { capEvictions++; Corpses[0].Expire(); }
                var animator = actor.GetComponentInChildren<Animator>(true);
                var originalVisual = actor.transform.Find("Visual");
                var sourceOwnRenderers = originalVisual.GetComponentsInChildren<Renderer>(true).Where(r => r.sharedMaterials.All(m => m && m.name.StartsWith("RG_", StringComparison.Ordinal))).ToArray();
                int sourceSkinJointCount = sourceOwnRenderers.OfType<SkinnedMeshRenderer>().Sum(r=>r.bones.Length);
                if (!animator || !originalVisual || sourceOwnRenderers.OfType<SkinnedMeshRenderer>().Count()!=3) throw new InvalidOperationException("Live source-bound pose hierarchy missing.");
                root = new GameObject("RG Own Corpse " + id); root.SetActive(false);
                root.transform.SetPositionAndRotation(actor.transform.position, actor.transform.rotation);
                root.transform.localScale = actor.transform.lossyScale;
                var map = new Dictionary<Transform, Transform>();
                actor.GetComponent<GuardInstance>()?.ApplyForDeathSnapshot();
                CopyNodes(originalVisual, root.transform, map);
                var corpse = root.AddComponent<Corpse>();
                corpse.Record = new CorpseRecord { actorId = id, spawnedAt = Time.time, scale = Mathf.Abs(originalVisual.lossyScale.x),
                    originalPoseCopied = map.All(p => Vector3.Distance(p.Key.position, p.Value.position) < .0025f
                        && Quaternion.Angle(p.Key.rotation, p.Value.rotation) < .05f
                        && Vector3.Distance(p.Key.lossyScale, p.Value.lossyScale) < .001f) };
                var rendererPairs = new List<KeyValuePair<Renderer, Renderer>>();
                foreach (var source in originalVisual.GetComponentsInChildren<Renderer>(true))
                {
                    if (!source.sharedMaterials.All(m => m && m.name.StartsWith("RG_", StringComparison.Ordinal))) continue;
                    if (source is SkinnedMeshRenderer skin)
                    {
                        var target = map[source.transform].gameObject.AddComponent<SkinnedMeshRenderer>();
                        target.sharedMesh = skin.sharedMesh; target.bones = skin.bones.Select(t => map[t]).ToArray(); target.rootBone = map[skin.rootBone];
                        var corpseBounds = skin.localBounds; corpseBounds.Expand(3);
                        target.localBounds = corpseBounds; target.updateWhenOffscreen = true; target.quality = skin.quality;
                        CopyRenderer(source, target); rendererPairs.Add(new KeyValuePair<Renderer, Renderer>(source, target)); corpse.Record.skinnedBones += target.bones.Length;
                    }
                    else if (source is MeshRenderer)
                    {
                        var filter = source.GetComponent<MeshFilter>(); if (!filter || !filter.sharedMesh) continue;
                        // Bell cord is mutable and dies with the source actor.
                        // Snapshot every small rigid mesh; only stable own skin
                        // and complete own materials remain shared resources.
                        var mesh = Object.Instantiate(filter.sharedMesh); mesh.name = "RG Corpse Snapshot " + filter.sharedMesh.name;
                        corpse.OwnedMeshes.Add(mesh); map[source.transform].gameObject.AddComponent<MeshFilter>().sharedMesh = mesh;
                        var target = map[source.transform].gameObject.AddComponent<MeshRenderer>(); CopyRenderer(source, target);
                        rendererPairs.Add(new KeyValuePair<Renderer, Renderer>(source, target)); corpse.Record.clonedRigidMeshes++;
                    }
                    else continue;
                    corpse.Record.renderers++;
                }
                corpse.Record.originalSkinAndMaterialBindings = rendererPairs.All(p => p.Key.sharedMaterials.SequenceEqual(p.Value.sharedMaterials))
                    && rendererPairs.Where(p => p.Key is SkinnedMeshRenderer).All(p => {
                        var a = (SkinnedMeshRenderer)p.Key; var b = (SkinnedMeshRenderer)p.Value;
                        return a.sharedMesh == b.sharedMesh && a.bones.Select(t => map[t]).SequenceEqual(b.bones) && b.rootBone == map[a.rootBone]; });
                if (!corpse.Record.originalPoseCopied || !corpse.Record.originalSkinAndMaterialBindings)
                    throw new InvalidOperationException("Actual corpse pose or skin/material preservation check failed.");
                if (corpse.Record.skinnedBones != sourceSkinJointCount || corpse.Record.renderers != sourceOwnRenderers.Length)
                    throw new InvalidOperationException("Own complete corpse inventory differs from the exact source visual and partition.");
                var bones = RequiredBones.ToDictionary(b => b, b => map[animator.GetBoneTransform(b)]);
                BuildBodies(corpse, bones, actor.GetComponent<Character>()?.GetVelocity() ?? Vector3.zero, actor.transform.forward);
                corpse.Rest=root.AddComponent<GuardRagdollRestMonitor>();corpse.Rest.Configure(corpse.Bodies,Time.fixedTime);
                corpse.Record.bodies = corpse.Bodies.Count; corpse.Record.joints = corpse.Joints.Count; corpse.Record.colliders = corpse.Colliders.Count;
                corpse.StartPelvis = corpse.BoneBodies[HumanBodyBones.Hips].position; corpse.Pelvis = corpse.BoneBodies[HumanBodyBones.Hips].transform;
                foreach (var collider in corpse.Colliders)
                    foreach (var other in corpse.Colliders) if (collider != other) Physics.IgnoreCollision(collider, other);
                if (root.GetComponentInChildren<Character>(true) || root.GetComponentInChildren<ZNetView>(true) || root.GetComponentInChildren<Animator>(true))
                    throw new InvalidOperationException("Cosmetic corpse unexpectedly contains a live actor component.");
                corpse.Record.liveActorComponentsAbsent = true;
                Corpses.Add(corpse); created++; last = corpse.Record;
                root.SetActive(true);
                GuardPlugin.Log("RG_CORPSE_CREATED id=" + id + " bodies=15 joints=14 ttl=" + CorpseSeconds + " renderers=" + corpse.Record.renderers);
                return true;
            }
            catch (Exception error)
            {
                failures++; lastFailure = error.ToString(); if (root) Object.Destroy(root);
                GuardPlugin.Log("RG_CORPSE_FAILED " + error); return false;
            }
        }

        static void CopyNodes(Transform source, Transform parent, Dictionary<Transform, Transform> map)
        {
            var target = new GameObject(source.name).transform; target.SetParent(parent, false);
            target.localPosition = source.localPosition; target.localRotation = source.localRotation; target.localScale = source.localScale;
            target.gameObject.layer = corpseLayer; map.Add(source, target);
            foreach (Transform child in source) CopyNodes(child, target, map);
        }
        static void CopyRenderer(Renderer source, Renderer target)
        {
            target.sharedMaterials = source.sharedMaterials; target.enabled = source.enabled;
            target.shadowCastingMode = source.shadowCastingMode; target.receiveShadows = source.receiveShadows;
            target.lightProbeUsage = source.lightProbeUsage; target.reflectionProbeUsage = source.reflectionProbeUsage;
        }

        static void BuildBodies(Corpse corpse, Dictionary<HumanBodyBones, Transform> bones, Vector3 velocity, Vector3 forward)
        {
            // Every physical segment belongs to a measured anatomical bone.
            // Local collider length derives from the live child landmark.
            Add(corpse, bones, HumanBodyBones.Hips, HumanBodyBones.Chest, null, .14f, 8, velocity, forward);
            Add(corpse, bones, HumanBodyBones.Chest, HumanBodyBones.Neck, HumanBodyBones.Hips, .15f, 8, velocity, forward);
            Add(corpse, bones, HumanBodyBones.Head, null, HumanBodyBones.Chest, .12f, 2, velocity, forward);
            foreach (bool left in new[] { true, false })
            {
                var upperArm = left ? HumanBodyBones.LeftUpperArm : HumanBodyBones.RightUpperArm;
                var lowerArm = left ? HumanBodyBones.LeftLowerArm : HumanBodyBones.RightLowerArm;
                var hand = left ? HumanBodyBones.LeftHand : HumanBodyBones.RightHand;
                var thigh = left ? HumanBodyBones.LeftUpperLeg : HumanBodyBones.RightUpperLeg;
                var shin = left ? HumanBodyBones.LeftLowerLeg : HumanBodyBones.RightLowerLeg;
                var foot = left ? HumanBodyBones.LeftFoot : HumanBodyBones.RightFoot;
                Add(corpse, bones, upperArm, lowerArm, HumanBodyBones.Chest, .065f, 2, velocity, forward);
                Add(corpse, bones, lowerArm, hand, upperArm, .052f, 1.2f, velocity, forward);
                Add(corpse, bones, hand, null, lowerArm, .055f, .5f, velocity, forward);
                Add(corpse, bones, thigh, shin, HumanBodyBones.Hips, .085f, 4, velocity, forward);
                Add(corpse, bones, shin, foot, thigh, .065f, 2, velocity, forward);
                Add(corpse, bones, foot, null, shin, .075f, .8f, velocity, forward);
            }
        }
        static void Add(Corpse corpse, Dictionary<HumanBodyBones, Transform> bones, HumanBodyBones id,
            HumanBodyBones? endpoint, HumanBodyBones? parent, float radius, float mass, Vector3 velocity, Vector3 forward)
        {
            var bone = bones[id];
            if (Vector3.Distance(corpse.transform.lossyScale, Vector3.one) > .001f)
                throw new InvalidOperationException("Flat corpse physics requires the own unit-scale actor root.");
            float worldRadius = radius * Mathf.Abs(bone.lossyScale.x);
            Vector3 worldDelta = bone.up * worldRadius;
            if (endpoint.HasValue && bones.TryGetValue(endpoint.Value, out var end)) worldDelta = end.position - bone.position;
            else if (id == HumanBodyBones.Chest) worldDelta = (bones[HumanBodyBones.Head].position - bone.position) * .65f;
            // Physical nodes are flat, unscaled siblings, never Rigidbody
            // children of scaled/interpolated skin bones. This avoids solver
            // anchors inheriting the1.5x animated hierarchy or parent updates.
            var physical = new GameObject("RG Corpse Body " + id).transform;
            physical.SetParent(corpse.transform, false); physical.SetPositionAndRotation(bone.position, bone.rotation);
            physical.localScale = Vector3.one; physical.gameObject.layer = corpseLayer;
            Vector3 delta = physical.InverseTransformDirection(worldDelta);
            float length = Mathf.Max(worldRadius * 2, delta.magnitude);
            var colliderNode = new GameObject("RG Corpse Collider " + id); colliderNode.layer = corpseLayer;
            colliderNode.transform.SetParent(physical, false); colliderNode.transform.localPosition = delta * .5f;
            colliderNode.transform.localRotation = Quaternion.FromToRotation(Vector3.up, delta.sqrMagnitude > .000001f ? delta.normalized : Vector3.up);
            var collider = colliderNode.AddComponent<CapsuleCollider>(); collider.radius = worldRadius; collider.height = length + worldRadius; collider.direction = 1;
            collider.contactOffset = .005f;
            collider.excludeLayers = LayerMask.GetMask("character", "character_net", "character_ghost", "character_noenv");
            collider.includeLayers = LayerMask.GetMask("Default", "Default_small", "terrain", "static_solid", "piece");
            collider.layerOverridePriority = int.MaxValue;
            var body = physical.gameObject.AddComponent<Rigidbody>(); body.mass = mass; body.useGravity = true;
            body.linearDamping = .15f; body.angularDamping = .4f; body.maxAngularVelocity = 10; body.maxDepenetrationVelocity = 1.5f;
            body.solverIterations = 20; body.solverVelocityIterations = 8; body.interpolation = RigidbodyInterpolation.Interpolate;
            body.collisionDetectionMode = CollisionDetectionMode.ContinuousSpeculative;
            var initialAngular = Vector3.Cross(Vector3.up, forward).normalized * .6f;
            body.linearVelocity = Vector3.ClampMagnitude(velocity, 4) + Vector3.ProjectOnPlane(forward, Vector3.up).normalized * .25f
                + Vector3.Cross(initialAngular, body.position - bones[HumanBodyBones.Hips].position);
            body.angularVelocity = initialAngular;
            corpse.Bodies.Add(body); corpse.Colliders.Add(collider);
            corpse.BoneBodies.Add(id, body); corpse.PoseBindings.Add(new KeyValuePair<Transform, Rigidbody>(bone, body));
            var contact = physical.gameObject.AddComponent<CorpseContact>(); contact.Owner = corpse;
            if (parent.HasValue)
            {
                var connected = corpse.BoneBodies[parent.Value];
                if (!connected) throw new InvalidOperationException("Corpse parent body was not created first.");
                var joint = physical.gameObject.AddComponent<CharacterJoint>(); joint.connectedBody = connected; joint.autoConfigureConnectedAnchor = false;
                joint.anchor = Vector3.zero; joint.connectedAnchor = Quaternion.Inverse(connected.rotation) * (body.position - connected.position);
                joint.axis = delta.sqrMagnitude > .000001f ? delta.normalized : Vector3.up;
                var cross = Vector3.Cross(joint.axis, physical.InverseTransformDirection(forward));
                joint.swingAxis = cross.sqrMagnitude > .01f ? cross.normalized : Vector3.right;
                bool limb = id.ToString().Contains("Arm") || id.ToString().Contains("Leg");
                joint.lowTwistLimit = new SoftJointLimit { limit = limb ? -35 : -25 };
                joint.highTwistLimit = new SoftJointLimit { limit = limb ? 35 : 25 };
                joint.swing1Limit = new SoftJointLimit { limit = limb ? 75 : 35 };
                joint.swing2Limit = new SoftJointLimit { limit = limb ? 45 : 30 };
                joint.enableCollision = false; joint.enablePreprocessing = false; joint.enableProjection = true;
                joint.projectionDistance = .01f; joint.projectionAngle = 8;
                corpse.Joints.Add(joint);
            }
        }

        public static object Snapshot() => new { prepared, corpseSeconds = CorpseSeconds,
            smokeStartsSeconds = GuardDeathTimeline.SmokeStartSeconds, minimumSmokeLeadSeconds = GuardDeathTimeline.MinimumSmokeLeadSeconds,
            minimumSmokeTailSeconds = GuardDeathTimeline.MinimumSmokeTailSeconds,
            collisionLayer = corpseLayer, collisionLayerName = LayerMask.LayerToName(corpseLayer), collisionLayerSource, sourceSmoke, sourceShader,
            corpsesCreated = created, corpsesActive = Corpses.Count, corpsesRemoved = removed, smokeCreated = puffs, smokeActive = Smokes.Count,
            smokeRemoved, duplicatesSuppressed = duplicates, failures, lastFailure, capEvictions, lastCorpse = last,
            scope = "Client-local visual ragdoll and puff only; no damage receiver, loot or force interaction with live characters. Multiplayer delivery requires actual multi-client validation." };
        public static void Shutdown()
        {
            foreach (var corpse in Corpses.ToArray()) if (corpse) Object.Destroy(corpse.gameObject);
            foreach (var smoke in Smokes.ToArray()) if (smoke) Object.Destroy(smoke.gameObject);
            Corpses.Clear(); Smokes.Clear(); Presented.Clear(); prepared = false;
            if (smokeMaterial) Object.Destroy(smokeMaterial); smokeMaterial = null;
        }
        static Smoke Puff(Bounds coverage, float scale, Corpse owner)
        {
            if (!smokeMaterial) return null;
            if (Smokes.Count >= MaximumSmoke)
            {
                // A live corpse's masking cloud cannot be evicted underneath it.
                var released = Smokes.FirstOrDefault(s => s && !s.HeldCorpse);
                if (!released) return null;
                Smokes.Remove(released); smokeRemoved++; Object.Destroy(released.gameObject);
            }
            var node = new GameObject("RG Own Orange Red Death Puff"); node.transform.position = coverage.center;
            var particle = node.AddComponent<ParticleSystem>(); particle.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            var main = particle.main; main.loop = false; main.playOnAwake = false; main.duration = .35f;
            main.simulationSpace = ParticleSystemSimulationSpace.Local; main.cullingMode = ParticleSystemCullingMode.AlwaysSimulate;
            main.startLifetime = new ParticleSystem.MinMaxCurve(GuardDeathTimeline.SmokeMinimumLifetime, GuardDeathTimeline.SmokeMaximumLifetime);
            main.startSpeed = new ParticleSystem.MinMaxCurve(.2f, .45f);
            main.startSize = new ParticleSystem.MinMaxCurve(.35f * scale, .65f * scale); main.startRotation = new ParticleSystem.MinMaxCurve(0, Mathf.PI * 2);
            main.startColor = new ParticleSystem.MinMaxGradient(new Color(.7f, .10f, .025f, .7f), new Color(1, .32f, .07f, .85f));
            main.gravityModifier = -.025f; main.maxParticles = 48;
            var emission = particle.emission; emission.rateOverTime = 0; emission.rateOverDistance = 0;
            emission.SetBursts(Array.Empty<ParticleSystem.Burst>());
            var shape = particle.shape; shape.shapeType = ParticleSystemShapeType.Box;
            shape.scale = new Vector3(Mathf.Max(.65f * scale, coverage.size.x), Mathf.Max(.35f * scale, coverage.size.y), Mathf.Max(.65f * scale, coverage.size.z));
            shape.randomDirectionAmount = 1;
            var color = particle.colorOverLifetime; color.enabled = true;
            var gradient = new Gradient(); gradient.SetKeys(new[] { new GradientColorKey(Color.white, 0), new GradientColorKey(new Color(.65f, .19f, .12f), 1) },
                new[] { new GradientAlphaKey(.8f, 0), new GradientAlphaKey(.9f, .2f), new GradientAlphaKey(.85f, .65f), new GradientAlphaKey(0, 1) }); color.color = gradient;
            var size = particle.sizeOverLifetime; size.enabled = true;
            size.size = new ParticleSystem.MinMaxCurve(1, new AnimationCurve(new Keyframe(0, .35f), new Keyframe(.2f, 1), new Keyframe(.65f, 1.35f), new Keyframe(1, 1.7f)));
            var renderer = particle.GetComponent<ParticleSystemRenderer>(); renderer.sharedMaterial = smokeMaterial;
            renderer.renderMode = ParticleSystemRenderMode.Billboard; renderer.shadowCastingMode = ShadowCastingMode.Off; renderer.receiveShadows = false;
            var life = node.AddComponent<Smoke>(); life.HeldCorpse = owner; life.Record = owner.Record; life.Particles = particle;
            life.CoverageSize = .8f * scale; life.Expires = Time.time + GuardDeathTimeline.SmokeMaximumLifetime + GuardDeathTimeline.CleanupPaddingSeconds;
            Smokes.Add(life); puffs++; life.Prime(false); return life;
        }

        public sealed class Corpse : MonoBehaviour
        {
            public GuardRagdollRestMonitor Rest;
            public bool Available=>!expired&&gameObject.activeInHierarchy;
            public bool IsSettled=>Available&&Rest&&Rest.Settled;
            public Vector3 VoicePosition=>BoneBodies.TryGetValue(HumanBodyBones.Head,out var head)&&head?head.worldCenterOfMass:Pelvis?Pelvis.position:transform.position;
            public void MarkGroundSupport(){if(Rest)Rest.MarkGroundSupport(Time.fixedTime);}
            public CorpseRecord Record; public Vector3 StartPelvis; public Transform Pelvis;
            public readonly List<Rigidbody> Bodies = new List<Rigidbody>();
            public readonly Dictionary<HumanBodyBones, Rigidbody> BoneBodies = new Dictionary<HumanBodyBones, Rigidbody>();
            public readonly List<KeyValuePair<Transform, Rigidbody>> PoseBindings = new List<KeyValuePair<Transform, Rigidbody>>();
            public readonly List<CharacterJoint> Joints = new List<CharacterJoint>();
            public readonly List<Collider> Colliders = new List<Collider>();
            public readonly List<Mesh> OwnedMeshes = new List<Mesh>();
            bool expired;
            Smoke maskingSmoke;
            void FixedUpdate()
            {
                if (expired) return; Record.fixedSteps++;
                if (Pelvis) Record.maximumPelvisTravel = Mathf.Max(Record.maximumPelvisTravel, Vector3.Distance(StartPelvis, Pelvis.position));
                foreach (var joint in Joints) if (joint && joint.connectedBody)
                {
                    var body = joint.GetComponent<Rigidbody>();
                    var ownAnchor = body.position + body.rotation * joint.anchor;
                    var otherAnchor = joint.connectedBody.position + joint.connectedBody.rotation * joint.connectedAnchor;
                    Record.maximumJointGap = Mathf.Max(Record.maximumJointGap, Vector3.Distance(ownAnchor, otherAnchor));
                    Record.maximumRenderedJointGap = Mathf.Max(Record.maximumRenderedJointGap,
                        Vector3.Distance(joint.transform.TransformPoint(joint.anchor), joint.connectedBody.transform.TransformPoint(joint.connectedAnchor)));
                }
            }
            void LateUpdate()
            {
                if (expired) return;
                // Bindings are created anatomical parent first. Copy the
                // interpolated physical pose into the unchanged skin rig;
                // physics never receives a transform write from this step.
                foreach (var binding in PoseBindings)
                    if (binding.Key && binding.Value) binding.Key.SetPositionAndRotation(binding.Value.transform.position, binding.Value.transform.rotation);
            }
            Bounds Coverage()
            {
                var first = Bodies.FirstOrDefault(b => b);
                var bounds = new Bounds(first ? first.worldCenterOfMass : transform.position, Vector3.one * (.2f * Record.scale));
                foreach (var body in Bodies) if (body) bounds.Encapsulate(body.worldCenterOfMass);
                // Include the clapper and hanging parts as well as anatomy.
                // The skin has deliberately expanded culling bounds, so it
                // must not inflate the masking cloud to a huge empty volume.
                foreach (var rigid in GetComponentsInChildren<MeshRenderer>()) if (rigid.enabled) bounds.Encapsulate(rigid.bounds);
                bounds.Expand(.25f * Record.scale); return bounds;
            }
            void EnsureSmoke()
            {
                if (!maskingSmoke)
                {
                    maskingSmoke = Puff(Coverage(), Record.scale, this);
                    if (!maskingSmoke) return;
                    Record.smokeAt = Time.time;
                }
                maskingSmoke.transform.position = Coverage().center;
                if (maskingSmoke.Particles.particleCount == 0)
                { maskingSmoke.Prime(false); Record.smokeCoverageRestarts++; }
            }
            void Update()
            {
                if (expired) return;
                float age = Time.time - Record.spawnedAt;
                // Give a still-moving corpse time to settle. The bound only
                // permits cleanup; it never fabricates a settled speech event.
                bool canFinish=IsSettled||age>=GuardRagdollRestPolicy.MaximumWaitSeconds;
                if (canFinish&&GuardDeathTimeline.ShouldStartSmoke(age)) EnsureSmoke();
                if (canFinish&&maskingSmoke && GuardDeathTimeline.CanHideBody(age, Time.time - maskingSmoke.CoverageStartedAt,
                    maskingSmoke.Particles.particleCount > 0, Time.frameCount > maskingSmoke.CoverageStartedFrame)) Hide(false);
            }
            public void Expire()
            {
                // Explicit capacity eviction is exceptional. Seed a full-sized
                // masking cloud immediately rather than popping a bare body.
                if (expired) return; EnsureSmoke();
                if (maskingSmoke) maskingSmoke.Prime(true);
                Hide(true);
            }
            void Hide(bool capacityForced)
            {
                if (expired) return; expired = true; Record.expired = true; Record.disappearedAt = Time.time;
                Record.lifetime = Time.time - Record.spawnedAt; Record.capacityForcedExpiry = capacityForced;
                Record.smokeLeadSeconds = Mathf.Max(0, Time.time - Record.smokeAt);
                Record.smokeParticlesAtHide = maskingSmoke ? maskingSmoke.Particles.particleCount : 0;
                Record.hiddenUnderSmoke = maskingSmoke && Record.smokeParticlesAtHide > 0;
                if (Corpses.Remove(this)) removed++;
                if (maskingSmoke) maskingSmoke.Release(Time.time);
                foreach (var renderer in GetComponentsInChildren<Renderer>()) renderer.enabled = false;
                foreach (var body in Bodies) if (body) body.isKinematic = true;
                Object.Destroy(gameObject);
            }
            void OnDestroy()
            {
                if (maskingSmoke && maskingSmoke.HeldCorpse == this) maskingSmoke.Release(Time.time);
                foreach (var mesh in OwnedMeshes) if (mesh) Object.Destroy(mesh);
                if (Corpses.Remove(this)) removed++;
            }
        }
        public sealed class CorpseContact : MonoBehaviour
        {
            static readonly int SolidMask=LayerMask.GetMask("Default", "Default_small", "terrain", "static_solid", "piece");
            public Corpse Owner;
            void OnCollisionEnter(Collision collision)
            { Observe(collision,true); }
            void OnCollisionStay(Collision collision)
            { Observe(collision,false); }
            void Observe(Collision collision,bool entered)
            {
                if (!Owner || collision.collider.isTrigger || collision.collider.GetComponentInParent<Character>()) return;
                if ((SolidMask & (1 << collision.collider.gameObject.layer)) == 0) return;
                for (int i = 0; i < collision.contactCount; i++)
                    if (collision.GetContact(i).normal.y > .45f)
                    { if(entered){Owner.Record.floorContacts++;Owner.Record.lastFloorCollider = collision.collider.name;}Owner.MarkGroundSupport();break; }
            }
        }
        public sealed class Smoke : MonoBehaviour
        {
            public float Expires, CoverageStartedAt, CoverageSize;
            public int CoverageStartedFrame;
            public Corpse HeldCorpse;
            public CorpseRecord Record;
            public ParticleSystem Particles;
            readonly ParticleSystem.Particle[] buffer = new ParticleSystem.Particle[48];
            public void Prime(bool fullSized)
            {
                Particles.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
                Particles.Play(); Particles.Emit(38);
                CoverageStartedAt = Time.time; CoverageStartedFrame = Time.frameCount;
                if (!fullSized) return;
                var size = Particles.sizeOverLifetime; size.enabled = false;
                int count = Particles.GetParticles(buffer);
                for (int i = 0; i < count; i++) buffer[i].startSize = Mathf.Max(buffer[i].startSize, CoverageSize);
                Particles.SetParticles(buffer, count);
            }
            public void Release(float hiddenAt)
            {
                HeldCorpse = null;
                // Preserve a visible tail even if a slow frame delayed hiding.
                int count = Particles.GetParticles(buffer);
                for (int i = 0; i < count; i++)
                    buffer[i].remainingLifetime = Mathf.Max(buffer[i].remainingLifetime, GuardDeathTimeline.MinimumSmokeTailSeconds);
                Particles.SetParticles(buffer, count);
                Expires = GuardDeathTimeline.SmokeCleanupAt(Record.smokeAt, hiddenAt);
            }
            void Update() { if (!HeldCorpse && Time.time >= Expires) Object.Destroy(gameObject); }
            void OnDestroy()
            {
                if (Record != null)
                { Record.smokeEndedAt = Time.time; Record.smokeTailSeconds = Record.disappearedAt > 0 ? Mathf.Max(0, Time.time - Record.disappearedAt) : 0; }
                if (Smokes.Remove(this)) smokeRemoved++;
            }
        }
        [HarmonyPatch(typeof(Character), nameof(Character.OnDeath))]
        static class OwnDeathFallback
        {
            [HarmonyPrefix, HarmonyPriority(Priority.Last)]
            static void Prefix(Character __instance)
            {
                if (!__instance || !__instance.GetComponent<GuardInstance>()) return;
                var view = __instance.GetComponent<ZNetView>();
                if (view && view.IsValid() && view.IsOwner()) Present(__instance.gameObject);
            }
        }
    }
}
