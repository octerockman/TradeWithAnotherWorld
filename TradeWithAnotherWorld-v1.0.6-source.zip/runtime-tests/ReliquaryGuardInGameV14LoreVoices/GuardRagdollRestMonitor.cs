using System.Collections.Generic;
using UnityEngine;
namespace BlackAbbey.ReliquaryGuard
{
    // Read-only observer: never freezes, sleeps, wakes or moves a Rigidbody.
    public sealed class GuardRagdollRestMonitor:MonoBehaviour
    {
        readonly GuardRagdollRestPolicy policy=new GuardRagdollRestPolicy();
        List<Rigidbody> bodies;float born,lastSupport=float.NegativeInfinity;bool grounded;int steps;
        // Confirm again after the physics step, before an Update starts speech.
        // A fresh collision/impulse must not use last FixedUpdate's quiet flag.
        public bool Settled=>isActiveAndEnabled&&policy.Settled&&ReadMotion(out float linear,out float angular,out bool sleeping)&&linear<=GuardRagdollRestPolicy.LinearSpeed&&angular<=GuardRagdollRestPolicy.AngularSpeed;
        public float QuietFor=>policy.QuietFor;
        public void Configure(List<Rigidbody> input,float fixedNow){bodies=input;born=fixedNow;lastSupport=float.NegativeInfinity;grounded=false;steps=0;policy.Reset();}
        public void MarkGroundSupport(float fixedNow){lastSupport=fixedNow;grounded=true;}
        public void Sample(float fixedNow,float dt)
        {
            steps++;bool valid=ReadMotion(out float linear,out float angular,out bool allSleeping);
            // Sleeping bodies no longer receive collision-stay callbacks. They
            // still require a previous genuine floor/support contact.
            bool supported=grounded&&(allSleeping||fixedNow-lastSupport<=dt*2.1f);
            policy.Observe(fixedNow-born,dt,steps,valid,supported,linear,angular);
        }
        bool ReadMotion(out float linear,out float angular,out bool allSleeping)
        {
            bool valid=bodies!=null&&bodies.Count>0;allSleeping=valid;linear=angular=0;
            if(valid)foreach(var body in bodies)
            {
                if(!body||body.isKinematic){valid=false;allSleeping=false;break;}
                allSleeping&=body.IsSleeping();float speed=body.linearVelocity.magnitude,spin=body.angularVelocity.magnitude;
                if(!GuardAudioPolicy.Finite(speed)||!GuardAudioPolicy.Finite(spin)){valid=false;break;}
                linear=Mathf.Max(linear,speed);angular=Mathf.Max(angular,spin);
            }
            return valid;
        }
        void FixedUpdate()=>Sample(Time.fixedTime,Time.fixedDeltaTime);
        void OnDisable()=>policy.Reset();
    }
}
