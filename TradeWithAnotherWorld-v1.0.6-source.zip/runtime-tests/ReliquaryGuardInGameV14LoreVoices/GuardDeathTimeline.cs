using System;

namespace BlackAbbey.ReliquaryGuard
{
    // Pure timing policy. The runtime additionally requires real live particles
    // and a later frame before hiding the corpse.
    public static class GuardDeathTimeline
    {
        public const float CorpseSeconds = 2.5f;
        public const float SmokeStartSeconds = 1.8f;
        public const float MinimumSmokeLeadSeconds = .5f;
        public const float SmokeMinimumLifetime = 2f;
        public const float SmokeMaximumLifetime = 2.2f;
        public const float MinimumSmokeTailSeconds = 1.1f;
        public const float CleanupPaddingSeconds = .25f;

        static bool Valid(float value) => !float.IsNaN(value) && !float.IsInfinity(value) && value >= 0;
        public static bool ShouldStartSmoke(float corpseAge) => Valid(corpseAge) && corpseAge >= SmokeStartSeconds;
        public static bool CanHideBody(float corpseAge, float smokeCoverageAge, bool particlesAlive, bool laterFrame)
            => Valid(corpseAge) && Valid(smokeCoverageAge) && corpseAge >= CorpseSeconds
                && smokeCoverageAge >= MinimumSmokeLeadSeconds && particlesAlive && laterFrame;
        public static float SmokeCleanupAt(float smokeStartedAt, float bodyHiddenAt)
        {
            if (!Valid(smokeStartedAt) || !Valid(bodyHiddenAt)) throw new ArgumentOutOfRangeException("Invalid death timeline timestamp.");
            return Math.Max(smokeStartedAt + SmokeMaximumLifetime + CleanupPaddingSeconds,
                bodyHiddenAt + MinimumSmokeTailSeconds + CleanupPaddingSeconds);
        }
    }
}
