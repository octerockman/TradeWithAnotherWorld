using System;
using System.Collections.Generic;

namespace BlackAbbey.ReliquaryGuard
{
    public static class GuardAudioPolicy
    {
        public static readonly string[] RequiredGroups = { "warning", "attack", "death", "armorWalk", "armorTurn", "shieldRaise", "block", "stone", "cloth", "deathArmor", "parry", "swing", "body", "hurt", "warningBooks", "voiceBlock", "idleSpeech" };
        public static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        public sealed class Gate
        {
            readonly Dictionary<string, float> next = new Dictionary<string, float>(StringComparer.Ordinal);
            public bool Take(string group, float now, float interval)
            {
                if (!Finite(now) || !Finite(interval) || interval < 0) return false;
                if (next.TryGetValue(group, out var until) && now < until) return false;
                next[group] = now + interval; return true;
            }
        }
    }
}
