using System;
using HarmonyLib;
using UnityEngine;
namespace BlackAbbey.ReliquaryGuard
{
    // Add decisions to this Guard only. Keep native sensing, movement and
    // Humanoid attacks/blocks; do not replace damage or player combat methods.
    public sealed class GuardCombat:MonoBehaviour
    {
        static readonly AccessTools.FieldRef<Character,bool> BlockInput=AccessTools.FieldRefAccess<Character,bool>("m_blocking");
        static readonly AccessTools.FieldRef<Humanoid,Attack> CurrentAttack=AccessTools.FieldRefAccess<Humanoid,Attack>("m_currentAttack");
        static readonly AccessTools.FieldRef<Attack,int> ChainLevel=AccessTools.FieldRefAccess<Attack,int>("m_currentAttackCainLevel");
        static readonly AccessTools.FieldRef<Humanoid,float> BlockTimer=AccessTools.FieldRefAccess<Humanoid,float>("m_blockTimer");
        // Reuse the native chain index already used by combat counters. Audio
        // reads it only; it does not alter an attack or its continuation.
        internal static bool IsComboStart(Attack attack)=>attack!=null&&ChainLevel(attack)==0;
        Humanoid human;MonsterAI ai;ZNetView view;GuardDefensePolicy defense;
        bool requestChain,wantsBlock;float nextChainAttempt;
        int attacks,secondSwings,thirdSwings,blocks,timedBlocks;
        void Initialize(){if(human)return;human=GetComponent<Humanoid>();ai=GetComponent<MonsterAI>();view=GetComponent<ZNetView>();defense=new GuardDefensePolicy();}
        bool Owner()=>view&&view.IsValid()&&view.IsOwner();
        bool Alive()=>human&&!human.IsDead()&&human.GetHealth()>0;
        bool Reach(Character target,float distance,float facing)
        {
            if(!target||target.IsDead())return false;
            var d=target.transform.position-human.transform.position;
            return Mathf.Abs(d.y)<1.6f&&Vector3.ProjectOnPlane(d,Vector3.up).sqrMagnitude<=distance*distance&&Vector3.Dot(human.transform.forward,d.normalized)>=facing;
        }
        void BeforeAI(float dt)
        {
            Initialize();if(!Owner())return;
            var target=ai.GetTargetCreature();bool inReach=Reach(target,3.6f,.35f);
            bool incoming=inReach&&target.InAttack()&&Vector3.Dot(target.transform.forward,(human.transform.position-target.transform.position).normalized)>.15f;
            object token=target is Humanoid opponent?(object)CurrentAttack(opponent):target;
            bool capable=Alive()&&human.LeftItem!=null&&inReach&&!human.InAttack()&&!human.IsStaggering()&&!human.InDodge()&&human.CanMove();
            wantsBlock=defense.Step(Mathf.Clamp(dt,0,.1f),capable,incoming,token);
            BlockInput(human)=wantsBlock;
        }
        void AfterAI()
        {
            if(!Owner()||!Alive())return;
            var target=ai.GetTargetCreature();
            if(wantsBlock){human.SetMoveDir(Vector3.zero);if(target)human.SetLookDir(target.transform.position-human.transform.position,0);return;}
            var attack=CurrentAttack(human);
            if(Time.time<nextChainAttempt||!GuardDefensePolicy.CanContinue(human.InAttack(),attack!=null&&attack.CanStartChainAttack(),Reach(target,3.2f,.4f),human.IsStaggering()||human.InDodge(),wantsBlock))return;
            // Native Chain events open the window. StartAttack retains the
            // previous Attack's next level and closes the window itself.
            requestChain=true;
            try{if(human.StartAttack(target,false))nextChainAttempt=Time.time+.12f;}
            finally{requestChain=false;}
        }
        void Started(){attacks++;var a=CurrentAttack(human);if(a!=null){int n=ChainLevel(a);if(n==1)secondSwings++;if(n==2)thirdSwings++;}}
        public string Status()=>"attacks:"+attacks+",swing2:"+secondSwings+",swing3:"+thirdSwings+",shieldRaises:"+(defense?.Raises??0)+",blocks:"+blocks+",timedBlocks:"+timedBlocks;
        void OnDisable(){if(human)BlockInput(human)=false;wantsBlock=false;}
        [HarmonyPatch(typeof(MonsterAI),nameof(MonsterAI.UpdateAI))]
        static class Decisions
        {
            static void Prefix(MonsterAI __instance,float dt){__instance.GetComponent<GuardCombat>()?.BeforeAI(dt);}
            static void Postfix(MonsterAI __instance){__instance.GetComponent<GuardCombat>()?.AfterAI();}
        }
        [HarmonyPatch(typeof(MonsterAI),"DoAttack")]
        static class HoldShield
        {
            static bool Prefix(MonsterAI __instance,ref bool __result){var c=__instance.GetComponent<GuardCombat>();if(!c||!c.wantsBlock)return true;__result=false;return false;}
        }
        [HarmonyPatch(typeof(Humanoid),"HaveQueuedChain")]
        static class NativeChainGate
        {
            static bool Prefix(Humanoid __instance,ref bool __result){var c=__instance.GetComponent<GuardCombat>();if(!c||!c.requestChain)return true;__result=true;return false;}
        }
        [HarmonyPatch(typeof(Humanoid),nameof(Humanoid.StartAttack))]
        static class AttackCounters
        {
            static void Postfix(Humanoid __instance,bool __result){if(__result){var c=__instance.GetComponent<GuardCombat>();if(c){c.Initialize();c.Started();}}}
        }
        [HarmonyPatch(typeof(Humanoid),"BlockAttack")]
        static class BlockCounters
        {
            static void Prefix(Humanoid __instance,out bool __state){var c=__instance.GetComponent<GuardCombat>();var s=c?__instance.LeftItem:null;float age=c?BlockTimer(__instance):-1;__state=s!=null&&s.m_shared.m_timedBlockBonus>1&&age>=0&&age<.25f;}
            static void Postfix(Humanoid __instance,bool __state,bool __result){if(!__result)return;var c=__instance.GetComponent<GuardCombat>();if(!c)return;c.blocks++;if(__state&&!__instance.IsStaggering())c.timedBlocks++;}
        }
    }
}
