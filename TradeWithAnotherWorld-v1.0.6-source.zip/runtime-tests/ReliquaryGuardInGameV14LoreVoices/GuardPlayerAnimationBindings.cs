using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using UnityEngine;
namespace BlackAbbey.ReliquaryGuard
{
    // The AI remains a Humanoid/MonsterAI. Borrow only the actual player's
    // animation interface, never a Player component or player control logic.
    public sealed class GuardPlayerAnimationBindings:MonoBehaviour
    {
        public Animator animator;HashSet<int> parameters;
        public static void Configure(GameObject actor,GameObject nativePlayer,Animator animator){
            var own=actor.GetComponent<ZSyncAnimation>();var source=nativePlayer.GetComponent<ZSyncAnimation>();if(!own||!source)throw new InvalidOperationException("Player animation synchronization contract unavailable");
            own.m_syncBools=new List<string>(source.m_syncBools);own.m_syncFloats=new List<string>(source.m_syncFloats);own.m_syncInts=new List<string>(source.m_syncInts);own.m_smoothCharacterSpeeds=source.m_smoothCharacterSpeeds;
            var bindings=actor.AddComponent<GuardPlayerAnimationBindings>();bindings.animator=animator;
        }
        bool Supports(int hash){if(!animator)return true;if(parameters==null){var p=animator.parameters;if(p.Length==0)return true;parameters=new HashSet<int>(p.Select(x=>x.nameHash));}return parameters.Contains(hash);}
        static bool Allow(ZSyncAnimation sync,int hash){var own=sync?sync.GetComponent<GuardPlayerAnimationBindings>():null;return !own||own.Supports(hash);}
        // Ignore NPC-only parameters absent from this controller (sleeping,
        // turn_speed). Every other creature/player retains the native method.
        [HarmonyPatch(typeof(ZSyncAnimation),nameof(ZSyncAnimation.SetBool),new[]{typeof(int),typeof(bool)})]
        static class BoolParameter {static bool Prefix(ZSyncAnimation __instance,int __0)=>Allow(__instance,__0);}
        [HarmonyPatch(typeof(ZSyncAnimation),nameof(ZSyncAnimation.SetFloat),new[]{typeof(int),typeof(float)})]
        static class FloatParameter {static bool Prefix(ZSyncAnimation __instance,int __0)=>Allow(__instance,__0);}
    }
}
