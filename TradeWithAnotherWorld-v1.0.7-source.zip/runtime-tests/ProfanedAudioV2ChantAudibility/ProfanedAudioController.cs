using System;
using System.Collections.Generic;
using BlackAbbey.CenserBrother;
using UnityEngine;

namespace BlackAbbey.ProfanedAudio
{
    [DefaultExecutionOrder(980)]
    public sealed class ProfanedAudioController:MonoBehaviour
    {
        const string EventRpc="BA_ProfanedAudio_V1";
        static readonly HashSet<ProfanedAudioController> Live=new HashSet<ProfanedAudioController>();
        CenserInstance own;Character actor;CenserAI ai;ZNetView view;
        AudioSource chant,idle,combat,coals;readonly AudioTimeline timeline=new AudioTimeline();Action<string> timelineEmit;
        float voiceUntil,hurtAt,clothAt,prayerAt,nearAt,nextChantReport;int chantReports;bool bound,dead,nearby,chantStarted;
        long receiveOwner;int sentSequence,receivedSequence;
        public int EventsPlayed {get;private set;}
        public void Bind()
        {
            if(bound)return;own=GetComponent<CenserInstance>();actor=GetComponent<Character>();ai=GetComponent<CenserAI>();view=GetComponent<ZNetView>();
            if(!own||!actor||!view||!view.IsValid()||ProfanedAudioPlugin.Bank?.Ready!=true||!ProfanedAudioPlugin.Mixer)throw new InvalidOperationException("Own actor and native creature SFX route required");
            var nodes=new Dictionary<string,Transform>();foreach(var t in GetComponentsInChildren<Transform>(true))if(!nodes.ContainsKey(t.name))nodes.Add(t.name,t);
            var mouth=nodes.TryGetValue("Head",out var head)?head:transform;
            var bowl=nodes.TryGetValue("CenserEmber",out var ember)?ember:transform;
            chant=Loop(mouth,"chant",AudioMixPolicy.ChantPriority);idle=Loop(mouth,"voice_idle",190);combat=Loop(mouth,"voice_combat",180);coals=Loop(bowl,"censer_coals",215);
            int phrase=Math.Abs(gameObject.GetInstanceID()%8);chant.timeSamples=phrase*320000;
            timelineEmit=TimelineEvent;prayerAt=Time.time+36+(phrase*2);clothAt=Time.time+1;
            var player=Player.m_localPlayer;nearby=player&&(player.transform.position-transform.position).sqrMagnitude<26*26;
            view.Register<ZPackage>(EventRpc,Receive);bound=true;Live.Add(this);
            ProfanedNativeAudio.SuppressOwnNativeVoice(gameObject);
            ProfanedAudioPlugin.Log("PROFANED_AUDIO_ATTACHED uid="+view.GetZDO().m_uid+" nativeStepsRetained=true");
            nextChantReport=Time.time+2;
        }
        AudioSource Loop(Transform at,string id,int priority)
        {
            var s=ProfanedAudioSource.Create(at,"Profaned "+id,ProfanedAudioPlugin.Mixer,priority);
            s.clip=ProfanedAudioPlugin.Bank.Clips[id].clip;s.loop=true;return s;
        }
        void Bed(AudioSource s,string id,float amount,float dt)
        {
            if(!s)return;float wanted=ProfanedAudioPlugin.Volume*ProfanedAudioPlugin.Bank.Clips[id].cue.gain*amount;
            s.volume=Mathf.MoveTowards(s.volume,wanted,dt*1.8f);
            if(wanted>.001f&&!s.isPlaying){s.UnPause();if(!s.isPlaying)s.Play();}
            if(wanted<=.001f&&s.volume<=.001f&&s.isPlaying)s.Pause();
        }
        public void Cue(string id,float gain=1)
        {
            if(!bound||dead||!nearby||ProfanedAudioPlugin.Volume<=0||!AudioMixPolicy.AllowsCue(id))return;
            Vector3 point=id.StartsWith("chain")||id.StartsWith("ember")||id.StartsWith("sweep")?own.EmberSocket?own.EmberSocket.position:transform.position:actor.GetCenterPoint();
            ProfanedAudioPlugin.Pool.Play(id,point,ProfanedAudioPlugin.Volume,gain);
            if(id.StartsWith("voice")||id.StartsWith("hurt"))voiceUntil=Mathf.Max(voiceUntil,Time.time+ProfanedAudioPlugin.Bank.Clips[id].clip.length+.15f);
            EventsPlayed++;
        }
        void TimelineEvent(string id)=>Cue(id);
        void LateUpdate()
        {
            if(!bound||!actor||!view||!view.IsValid()||dead)return;
            if(actor.IsDead()){Die();return;}float dt=Mathf.Min(Time.deltaTime,.1f);
            if(Time.time>=nearAt){nearAt=Time.time+.4f;var player=Player.m_localPlayer;nearby=player&&(player.transform.position-transform.position).sqrMagnitude<26*26;}
            int action=view.GetZDO().GetInt("cb_action",0);long started=view.GetZDO().GetLong("cb_start",0);
            float age=started>0?(float)((CenserInstance.NowTicks-started)/10000000d):0;
            if(action>=1&&action<=3&&age>CenserPolicy.Duration((CenserAction)action)+.25f)action=0;
            if(nearby)timeline.Poll(action,started,age,timelineEmit);
            bool alert=ai&&ai.IsAlerted();float speaking=Time.time<voiceUntil?.12f:1;
            bool target=ai&&ai.Target&&!ai.Target.IsDead();bool fighting=target||action!=0;
            Bed(chant,"chant",AudioMixPolicy.ChantFactor(nearby,action!=0,Time.time<voiceUntil)*Mathf.Clamp(ProfanedAudioPlugin.ChantVolume.Value,0,2),dt);
            Bed(idle,"voice_idle",nearby&&!fighting?speaking:0,dt);
            Bed(combat,"voice_combat",nearby&&fighting?speaking:0,dt);
            Bed(coals,"censer_coals",nearby?1:0,dt);
            if(nearby&&chant.isPlaying&&!chantStarted){chantStarted=true;ProfanedAudioPlugin.Log("PROFANED_CHANT_STARTED "+ChantStatus()+" alert="+alert+" target="+target);}
            if(nearby&&Time.time>=nextChantReport&&chantReports<3){nextChantReport=Time.time+20;chantReports++;ProfanedAudioPlugin.Log("PROFANED_CHANT_STATUS "+ChantStatus());}
            float speed=Vector3.ProjectOnPlane(actor.GetVelocity(),Vector3.up).magnitude;
            if(nearby&&action==0){
                if(speed>.12f&&Time.time>=clothAt){clothAt=Time.time+2.1f;Cue("cloth");}
                if(!alert&&Time.time>=prayerAt&&Time.time>=voiceUntil){prayerAt=Time.time+39+Math.Abs(gameObject.GetInstanceID()%13);Cue("voice_prayer");}
            }
        }
        string ChantStatus()=>"uid="+(view&&view.IsValid()?view.GetZDO().m_uid.ToString():"invalid")+" playing="+(chant&&chant.isPlaying)+" virtual="+(chant&&chant.isVirtual)+" active="+(chant&&chant.gameObject.activeInHierarchy)+" muted="+(chant&&chant.mute)+" volume="+(chant?chant.volume:0)+" priority="+(chant?chant.priority:0)+" sample="+(chant?chant.timeSamples:0)+" distance="+(chant&&Player.m_localPlayer?Vector3.Distance(chant.transform.position,Player.m_localPlayer.transform.position):-1)+" nearby="+nearby;
        public void Publish(int kind,Vector3 point,float amount=0)
        {
            if(!bound||!view.IsValid()||!view.IsOwner())return;
            var packet=new ZPackage();int sequence=++sentSequence;packet.Write(sequence);packet.Write(kind);packet.Write(point);packet.Write(amount);
            receiveOwner=view.GetZDO().GetOwner();receivedSequence=sequence;Deliver(kind,point,amount);
            view.InvokeRPC(ZNetView.Everybody,EventRpc,packet);
        }
        void Receive(long sender,ZPackage p)
        {
            ProfanedAudioPlugin.Safe(()=>{
                if(!bound||!view||!view.IsValid()||sender!=view.GetZDO().GetOwner())return;
                int sequence=p.ReadInt(),kind=p.ReadInt();Vector3 point=p.ReadVector3();float amount=p.ReadSingle();
                if(!Finite(point)||!float.IsFinite(amount)||amount<0||kind<1||kind>5||sequence<=0||(point-transform.position).sqrMagnitude>256)return;
                if(sender!=receiveOwner){receiveOwner=sender;receivedSequence=0;}
                if(sequence<=receivedSequence)return;receivedSequence=sequence;Deliver(kind,point,amount);
            });
        }
        static bool Finite(Vector3 v)=>float.IsFinite(v.x)&&float.IsFinite(v.y)&&float.IsFinite(v.z);
        void Deliver(int kind,Vector3 at,float amount)
        {
            switch(kind){
                case 1:case 2:if(!dead&&Time.time>=hurtAt){hurtAt=Time.time+.6f;Cue(kind==1?"hurt_light":"hurt_heavy");}break;
                case 3:Cue("voice_alert");break;
                case 4:Die();break;
                case 5:if(!dead){ProfanedAudioPlugin.Pool.Play("punch_hit",at,ProfanedAudioPlugin.Volume);EventsPlayed++;}break;
            }
        }
        public void Die()
        {
            if(dead||!bound)return;dead=true;StopBeds();
            ProfanedAudioPlugin.Pool.Play("death",actor?actor.GetCenterPoint():transform.position,ProfanedAudioPlugin.Volume,1,75);
            EventsPlayed++;
        }
        void StopBeds(){foreach(var s in new[]{chant,idle,combat,coals})if(s)s.Stop();}
        void OnDestroy(){Live.Remove(this);StopBeds();foreach(var s in new[]{chant,idle,combat,coals})if(s)Destroy(s.gameObject);}
        public static void StopAll(){foreach(var c in Live)if(c){c.StopBeds();c.bound=false;c.enabled=false;}}
    }
    public sealed class ProfanedCloudAudio:MonoBehaviour
    {
        CenserCloud cloud;AudioSource loop;
        void Start()
        {
            cloud=GetComponent<CenserCloud>();if(!cloud||cloud.age>=cloud.duration||ProfanedAudioPlugin.Bank?.Ready!=true)return;
            loop=ProfanedAudioSource.Create(transform,"Profaned choking cloud",ProfanedAudioPlugin.Mixer,165);
            if(cloud.centers.Count>0){Vector3 center=Vector3.zero;foreach(var point in cloud.centers)center+=point;loop.transform.position=center/cloud.centers.Count;}
            var cue=ProfanedAudioPlugin.Bank.Clips["cloud_body"];loop.clip=cue.clip;loop.loop=true;loop.volume=cue.cue.gain*ProfanedAudioPlugin.Volume;
            loop.time=Mathf.Repeat(cloud.age,cue.clip.length);loop.Play();
            if(cloud.age<.3f)ProfanedAudioPlugin.Pool.Play("sweep_release",transform.position+Vector3.up*.7f,ProfanedAudioPlugin.Volume);
        }
        void Update(){if(loop){float target=cloud&&cloud.age<cloud.duration?ProfanedAudioPlugin.Volume*.48f:0;loop.volume=Mathf.MoveTowards(loop.volume,target,Time.deltaTime*1.5f);if(loop.volume<=.001f&&target==0)loop.Stop();}}
    }
    public sealed class ProfanedProjectileAudio:MonoBehaviour
    {
        AudioSource flight;
        void Start()
        {
            if(ProfanedAudioPlugin.Bank?.Ready!=true)return;
            var cue=ProfanedAudioPlugin.Bank.Clips["ember_flight"];
            flight=ProfanedAudioSource.Create(transform,"Profaned ember flight",ProfanedAudioPlugin.Mixer,150);flight.clip=cue.clip;flight.loop=true;flight.volume=cue.cue.gain*ProfanedAudioPlugin.Volume;flight.Play();
            ProfanedAudioPlugin.Pool.Play("ember_release",transform.position,ProfanedAudioPlugin.Volume);
        }
        void Update(){if(flight)flight.volume=ProfanedAudioPlugin.Volume*.45f;}
    }
}
