namespace BlackAbbey.ProfanedAudio { public static class AudioSourceHash { public const string Manifest="1912312879cff34c07164479b79f78aefe1ea9d0206346fe7762c638968a07a1"; } }
