using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using Otherworld.Navigation.BlindAbbotInGame;
using UnityEngine;
using UnityEngine.AI;
using Object = UnityEngine.Object;

namespace BlackAbbey.BlindAbbot
{
    // The installed native tile bake spans Y=-500..5500. Abbey test rooms are
    // at Y~8000. Give compatible owned Abbots a leased regional nav bake;
    // keep native AI choices, caching and steering.
    public sealed class AbbotDungeonNavigation : MonoBehaviour
    {
        public const float DungeonAltitude = 7000f;
        const float RegionSpan = 72f, RegionSnap = 12f, RefreshSeconds = 1.5f;
        static readonly HashSet<AbbotDungeonNavigation> Active = new HashSet<AbbotDungeonNavigation>();
        static readonly MethodInfo NativeGetSettings = AccessTools.Method(typeof(Pathfinding), "GetSettings");
        static readonly FieldInfo LastNativeFindTime = AccessTools.Field(typeof(BaseAI), "m_lastFindPathTime");
        static readonly MethodInfo GetPathMethod = AccessTools.Method(typeof(Pathfinding), "GetPath", new[] { typeof(Vector3), typeof(Vector3), typeof(List<Vector3>), typeof(Pathfinding.AgentType), typeof(bool), typeof(bool), typeof(bool) });
        static readonly MethodInfo HavePathMethod = AccessTools.Method(typeof(Pathfinding), "HavePath", new[] { typeof(Vector3), typeof(Vector3), typeof(Pathfinding.AgentType) });
        BaseAI ai; Character character; ZNetView view; CapsuleCollider capsule;
        Action<string> log;
        NavMeshBuildSettings profile, settings;
        RegionalNavigationCache.Lease shared;
        readonly NavMeshPath path = new NavMeshPath();
        Bounds worldBounds;
        bool settingsCreated, ready, released;
        int sourceMask, sourceCount, checks, builds, completed, queries, successes, failures, cacheRefreshes, lastCornerCount;
        int observedRevision = -1;
        float nextRefresh, measuredHeight, measuredRadius, longestBuild;
        string failure, lastPathStatus, floorName;
        public bool Ready => this && Eligible && shared != null && shared.Valid && shared.Ready && shared.Matches(transform.position);

        public static AbbotDungeonNavigation Attach(GameObject actor, Action<string> logger = null)
        {
            if (!actor || !actor.GetComponent<AbbotEncounterController>()) return null;
            var existing = actor.GetComponent<AbbotDungeonNavigation>(); if (existing) return existing;
            var result = actor.AddComponent<AbbotDungeonNavigation>();
            result.ai = actor.GetComponent<BaseAI>(); result.character = actor.GetComponent<Character>();
            result.view = actor.GetComponent<ZNetView>(); result.capsule = actor.GetComponent<CapsuleCollider>();
            result.log = logger; Active.Add(result); return result;
        }
        bool Eligible => ai && character && !character.IsDead() && view && view.IsValid() && view.IsOwner()
            && GetComponent<AbbotEncounterController>() && transform.position.y > DungeonAltitude;
        static bool Finite(Vector3 p) => !(float.IsNaN(p.x) || float.IsNaN(p.y) || float.IsNaN(p.z)
            || float.IsInfinity(p.x) || float.IsInfinity(p.y) || float.IsInfinity(p.z));
        static float[] V(Vector3 v) => new[] { v.x, v.y, v.z };
        void Update()
        {
            if (!Eligible) { if (settingsCreated || shared != null) Release("ownership, altitude or lifecycle changed"); return; }
            if (!global::Otherworld.Distribution.AbbeyNavigationWork.MayUpdate(true)) return;
            if (released) released = false;
            try
            {
                if (!settingsCreated && Time.realtimeSinceStartup < nextRefresh) return;
                if (!settingsCreated || shared == null || !shared.Valid) Initialize();
                else if (!shared.Matches(transform.position)) AcquireRegion();
                RegionalNavigationCache.Tick();
                settings = shared.Settings; worldBounds = shared.WorldBounds; ready = shared.Ready;
                sourceCount = shared.SourceCount; checks = shared.Checks; builds = shared.Builds; completed = shared.Completed;
                longestBuild = shared.LongestBuild; failure = shared.Failure;
                if (ready && observedRevision != shared.Revision)
                {
                    observedRevision = shared.Revision;
                    // The record owns the bake; each actor invalidates only its
                    // own native failed-path cache once per ready revision.
                    LastNativeFindTime.SetValue(ai, Time.time - 6f); cacheRefreshes++;
                    if (Physics.Raycast(transform.position + Vector3.up * .5f, Vector3.down, out var floor, 3f, sourceMask, QueryTriggerInteraction.Ignore))
                        floorName = floor.collider ? floor.collider.name : null;
                    global::Otherworld.Distribution.AbbeyNavigationWork.Trace("BA_DUNGEON_NAV_LEASE_READY sources=" + sourceCount + " agent=" + settings.agentTypeID + " revision=" + observedRevision + "; counters are shared-region totals, not a new per-actor bake.");
                }
            }
            catch (Exception error)
            {
                failure = error.Message; Release("regional navigation unavailable");
                nextRefresh = Time.realtimeSinceStartup + 5f;
                log?.Invoke("BA_DUNGEON_NAV_FAILED " + error);
            }
        }
        void Initialize()
        {
            if (!capsule || !Pathfinding.instance || NativeGetSettings == null || LastNativeFindTime == null)
                throw new InvalidOperationException("Actual native pathfinder, capsule or cache API unavailable.");
            int layer = LayerMask.NameToLayer("static_solid");
            if (layer < 0 || (Pathfinding.instance.m_layers.value & (1 << layer)) == 0)
                throw new InvalidOperationException("Authored room layer is absent from native static geometry mask.");
            sourceMask = 1 << layer;
            var nativeAgent = NativeGetSettings.Invoke(Pathfinding.instance, new object[] { ai.m_pathAgentType });
            var nativeBuild = (NavMeshBuildSettings)AccessTools.Field(nativeAgent.GetType(), "m_build").GetValue(nativeAgent);
            measuredHeight = capsule.bounds.size.y;
            measuredRadius = Mathf.Max(capsule.bounds.extents.x, capsule.bounds.extents.z);
            if (measuredHeight < .2f || measuredHeight > 5 || measuredRadius < .05f || measuredRadius > 2)
                throw new InvalidOperationException("Own world capsule dimensions are invalid.");
            // Preserve the old effective native defaults plus the same capsule
            // margins/build overrides. Only the cache creates native settings.
            profile = nativeBuild;
            profile.agentHeight = measuredHeight + .025f; profile.agentRadius = measuredRadius + .025f;
            profile.agentSlope = nativeBuild.agentSlope; profile.agentClimb = nativeBuild.agentClimb;
            profile.minRegionArea = nativeBuild.minRegionArea;
            profile.overrideVoxelSize = true; profile.voxelSize = .08f;
            profile.overrideTileSize = true; profile.tileSize = 128;
            AcquireRegion();
        }
        void AcquireRegion()
        {
            shared?.Dispose(); shared = null; settingsCreated = false; ready = false; observedRevision = -1;
            shared = RegionalNavigationCache.Acquire(profile, transform.position, sourceMask, log, "BA");
            if (shared == null || !shared.Valid) throw new InvalidOperationException("Regional navigation session or capacity is unavailable.");
            settingsCreated = true; settings = shared.Settings; worldBounds = shared.WorldBounds; nextRefresh = 0;
        }
        bool Calculate(Vector3 from, Vector3 to, List<Vector3> result, bool requireFullPath)
        {
            if (!global::Otherworld.Distribution.AbbeyNavigationWork.MayUpdate(true)) { result?.Clear(); return false; }
            queries++; if (result != null) result.Clear(); lastCornerCount = 0;
            if (!Ready || !Finite(from) || !Finite(to) || !shared.WorldBounds.Contains(from) || !shared.WorldBounds.Contains(to))
            { failures++; lastPathStatus = "not ready or outside owned regional data"; return false; }
            var filter = new NavMeshQueryFilter { agentTypeID = shared.Settings.agentTypeID, areaMask = 1 };
            if (!NavMesh.SamplePosition(from, out var start, 1.25f, filter) || !NavMesh.SamplePosition(to, out var end, 1.25f, filter)
                || Mathf.Abs(start.position.y - from.y) > .8f || Mathf.Abs(end.position.y - to.y) > .8f)
            { failures++; lastPathStatus = "endpoint absent from same-floor own nav surface"; return false; }
            bool found = NavMesh.CalculatePath(start.position, end.position, filter, path);
            lastPathStatus = path.status.ToString();
            if (!found || path.status == NavMeshPathStatus.PathInvalid || (requireFullPath && path.status != NavMeshPathStatus.PathComplete))
            { failures++; return false; }
            var corners = path.corners; lastCornerCount = corners.Length;
            if (corners.Length < 2) { failures++; return false; }
            if (result != null) result.AddRange(corners);
            successes++; return true;
        }
        public object ProbeRoute(Vector3 from, Vector3 to)
        {
            var corners = new List<Vector3>(); bool result = Calculate(from, to, corners, true);
            return new { passed = result, from = V(from), to = V(to), corners = corners.Select(V).ToArray(), status = lastPathStatus, navigation = Snapshot() };
        }
        public bool TryRouteForProof(Vector3 from, Vector3 to, List<Vector3> corners, bool requireFullPath = true) => Calculate(from, to, corners, requireFullPath);
        public bool TryProbePath(Vector3 start, Vector3 goal, out List<Vector3> corners)
        { corners = new List<Vector3>(); return Calculate(start, goal, corners, true); }
        public static object TargetDiagnostics(GameObject actor, Character target)
        {
            if (!actor || !target) return new { available = false };
            var character = actor.GetComponent<Character>(); var ai = actor.GetComponent<BaseAI>();
            if (!character || !ai) return new { available = false };
            object Read(string name) => AccessTools.Field(ai.GetType(), name)?.GetValue(ai);
            object Call(string name)
            {
                try { return AccessTools.Method(typeof(BaseAI), name, new[] { typeof(Character) })?.Invoke(ai, new object[] { target }); }
                catch (Exception error) { return error.GetBaseException().Message; }
            }
            Vector3 eye = character.m_eye ? character.m_eye.position : character.GetCenterPoint();
            Vector3 targetEye = target.IsCrouching() || !target.m_eye ? target.GetCenterPoint() : target.m_eye.position;
            int mask = (int)AccessTools.Field(typeof(BaseAI), "m_viewBlockMask").GetValue(null);
            Vector3 delta = targetEye - eye;
            var occluders = Physics.RaycastAll(eye, delta.normalized, delta.magnitude, mask, QueryTriggerInteraction.UseGlobal)
                .OrderBy(hit => hit.distance).Select(hit => new { name = hit.collider ? hit.collider.name : null,
                    layer = hit.collider ? LayerMask.LayerToName(hit.collider.gameObject.layer) : null,
                    trigger = hit.collider && hit.collider.isTrigger, point = V(hit.point), hit.distance }).ToArray();
            var nativeCharacter = Read("m_character") as Character;
            var nativeView = Read("m_nview") as ZNetView;
            object playing;
            try { playing = AccessTools.Method(AccessTools.TypeByName("CinematicsManager"), "IsPlaying")?.Invoke(null, null); }
            catch (Exception error) { playing = error.GetBaseException().Message; }
            return new { available = true, readOnly = true, characterInGlobalList = Character.GetAllCharacters().Contains(character),
                targetInGlobalList = Character.GetAllCharacters().Contains(target), actorCharacter = character.m_name,
                actorFaction = character.GetFaction().ToString(), targetFaction = target.GetFaction().ToString(),
                character.m_aiCannotTargetOthers, targetSkip = target.m_aiSkipTarget, actorTamed = character.IsTamed(), targetTamed = target.IsTamed(),
                aiEnabled = ai.enabled, aiActive = ai.isActiveAndEnabled, sleeping = ai.IsSleeping(), alerted = ai.IsAlerted(),
                referencedCharacterIsOwn = nativeCharacter == character, referencedViewIsOwn = nativeView == actor.GetComponent<ZNetView>(),
                nativeViewOwner = nativeView && nativeView.IsValid() && nativeView.IsOwner(),
                canSee = Call("CanSeeTarget"), canHear = Call("CanHearTarget"), canSense = Call("CanSenseTarget"),
                enemy = AccessTools.Method(typeof(BaseAI), "IsEnemy", new[] { typeof(Character), typeof(Character) }).Invoke(null, new object[] { character, target }),
                passiveMobs = ZoneSystem.instance && ZoneSystem.instance.GetGlobalKey(GlobalKeys.PassiveMobs), cinematicsPlaying = playing,
                actorPosition = V(actor.transform.position), actorForward = V(actor.transform.forward), eye = V(eye), targetEye = V(targetEye),
                angle = Vector3.Angle(target.transform.position - actor.transform.position, actor.transform.forward),
                viewRange = ai.m_viewRange, viewAngle = ai.m_viewAngle, hearingRange = ai.m_hearRange,
                stealthFactor = target.GetStealthFactor(), targetNoise = target.GetNoiseRange(), targetGhost = target.InGhostMode(), targetCrouched = target.IsCrouching(),
                viewBlockMask = mask, viewBlockLayers = Enumerable.Range(0, 32).Where(i => (mask & (1 << i)) != 0).Select(LayerMask.LayerToName).ToArray(), occluders,
                updateTargetTimer = Read("m_updateTargetTimer"), timeSinceSensed = Read("m_timeSinceSensedTargetCreature"),
                lastNativeFindTime = Read("m_lastFindPathTime"), lastNativeFindResult = Read("m_lastFindPathResult"),
                aggravated = Read("m_aggravated"), passiveAggressive = ai.m_passiveAggresive,
                scope = "Reads native sensory/faction/target gates and real eye-line occluders only; does not call FindEnemy/UpdateTarget/SetTarget, alter world flags or force AI." };
        }
        public object Snapshot() => new { eligible = this && Eligible, ready = Ready, building = shared != null && shared.Building,
            agentTypeId = settingsCreated ? settings.agentTypeID : -1, measuredHeight, measuredRadius, buildHeight = settingsCreated ? settings.agentHeight : 0,
            buildRadius = settingsCreated ? settings.agentRadius : 0, sources = sourceCount, sourceMask, geometryChecks = checks, builds, completed, queries, successes, failures,
            lastPathStatus, lastCornerCount, cacheRefreshes, longestBuildSeconds = longestBuild, failure, floor = floorName,
            boundsCenter = V(worldBounds.center), boundsSize = V(worldBounds.size), released,
            nativeBakeCenterY = 2500, nativeBakeHeight = 6000, nativeUnmodified = true,
            sharedRegionRevision = shared != null && shared.Valid ? shared.Revision : -1,
            sharedRegion = RegionalNavigationCache.Snapshot(),
            scope = "Own owner-controlled high-altitude Abbot only. Compatible regional nav data shared from actual static_solid physics colliders; geometry/build/completion counters are regional totals. Native FindPath cache and MoveTo steering retained; no forced target/movement/teleport or global tile/mask edits." };
        void Release(string reason)
        {
            var previous = shared; shared = null;
            settingsCreated = false; ready = false; released = true; observedRevision = -1;
            previous?.Dispose();
            global::Otherworld.Distribution.AbbeyNavigationWork.Trace("BA_DUNGEON_NAV_RELEASE " + reason);
        }
        void OnDisable() { if (settingsCreated) Release("disabled"); }
        void OnDestroy() { if (settingsCreated) Release("destroyed"); Active.Remove(this); }
        public static void Shutdown() { try { foreach (var item in Active.ToArray()) if (item && (item.settingsCreated || item.shared != null)) item.Release("plugin shutdown"); } finally { RegionalNavigationCache.Shutdown(); } }

        static AbbotDungeonNavigation Own(BaseAI owner)
        {
            if (!owner || !owner.GetComponent<AbbotEncounterController>() || owner.transform.position.y <= DungeonAltitude) return null;
            var navigation = owner.GetComponent<AbbotDungeonNavigation>();
            return navigation && navigation.Eligible ? navigation : null;
        }

        // Keep native BaseAI caching and Monk's existing transpiler intact.
        // Only a synchronous query entered by an owned high-altitude Abbot
        // carries this thread-local context; finally always restores it.
        [ThreadStatic] static AbbotDungeonNavigation queryOwner;
        static void Enter(BaseAI actor,out AbbotDungeonNavigation previous){previous=queryOwner;queryOwner=Own(actor);}
        static Exception Exit(Exception error,AbbotDungeonNavigation previous){queryOwner=previous;return error;}
        [HarmonyPatch(typeof(BaseAI),"FindPath")]
        static class FindScope{
            static void Prefix(BaseAI __instance,out AbbotDungeonNavigation __state)=>Enter(__instance,out __state);
            static Exception Finalizer(Exception __exception,AbbotDungeonNavigation __state)=>Exit(__exception,__state);
        }
        [HarmonyPatch(typeof(BaseAI),"HavePath")]
        static class HaveScope{
            static void Prefix(BaseAI __instance,out AbbotDungeonNavigation __state)=>Enter(__instance,out __state);
            static Exception Finalizer(Exception __exception,AbbotDungeonNavigation __state)=>Exit(__exception,__state);
        }
        [HarmonyPatch(typeof(Pathfinding),nameof(Pathfinding.GetPath),new[]{typeof(Vector3),typeof(Vector3),typeof(List<Vector3>),typeof(Pathfinding.AgentType),typeof(bool),typeof(bool),typeof(bool)})]
        static class AbbotGetPath{
            static bool Prefix(Vector3 __0,Vector3 __1,List<Vector3> __2,bool __6,ref bool __result){var owner=queryOwner;if(!owner||!owner.Eligible)return true;__result=owner.Calculate(__0,__1,__2,__6);return false;}
        }
        [HarmonyPatch(typeof(Pathfinding),nameof(Pathfinding.HavePath),new[]{typeof(Vector3),typeof(Vector3),typeof(Pathfinding.AgentType)})]
        static class AbbotHavePath{
            static bool Prefix(Vector3 __0,Vector3 __1,ref bool __result){var owner=queryOwner;if(!owner||!owner.Eligible)return true;__result=owner.Calculate(__0,__1,null,true);return false;}
        }
    }
}
