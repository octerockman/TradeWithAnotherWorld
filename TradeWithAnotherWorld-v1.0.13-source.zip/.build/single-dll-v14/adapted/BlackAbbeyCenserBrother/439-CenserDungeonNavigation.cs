using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using UnityEngine.AI;
namespace BlackAbbey.CenserBrother
{
 public sealed class CenserDungeonNavigation:MonoBehaviour
 {
  public const float DungeonAltitude=7000;const float Span=60,Refresh=1.2f;static readonly HashSet<CenserDungeonNavigation> Active=new HashSet<CenserDungeonNavigation>();
  Character character;BaseAI ai;ZNetView view;CapsuleCollider capsule;CenserNavSurface surface;float next;ulong signature;Vector3 center;public string Failure;public int Sources,Queries,Failures;
  public bool Ready=>global::Otherworld.Distribution.AbbeyNavigationWork.MayUpdate(global::Otherworld.Distribution.AbbeyNavigationWork.InDungeon(transform.position.y))&&surface!=null&&surface.Ready;public int Revision=>surface?.Revision??0;
  public static CenserDungeonNavigation Attach(GameObject actor,Action<string> logger=null){var n=actor.GetComponent<CenserDungeonNavigation>();if(n)return n;n=actor.AddComponent<CenserDungeonNavigation>();n.character=actor.GetComponent<Character>();n.ai=actor.GetComponent<BaseAI>();n.view=actor.GetComponent<ZNetView>();n.capsule=actor.GetComponent<CapsuleCollider>();Active.Add(n);return n;}
  bool Eligible=>character&&!character.IsDead()&&view&&view.IsValid()&&view.IsOwner();
  void Update(){if(!Eligible){Release();return;}if(!global::Otherworld.Distribution.AbbeyNavigationWork.MayUpdate(global::Otherworld.Distribution.AbbeyNavigationWork.InDungeon(transform.position.y)))return;try{
   if(surface==null){if(Time.time<next)return;var origin=Snap(transform.position);float height=capsule.bounds.size.y+.025f,radius=Mathf.Max(capsule.bounds.extents.x,capsule.bounds.extents.z)+.025f;float climb=.3f,slope=45;
    if(Pathfinding.instance){var info=AccessTools.Method(typeof(Pathfinding),"GetSettings").Invoke(Pathfinding.instance,new object[]{ai.m_pathAgentType});var native=(NavMeshBuildSettings)AccessTools.Field(info.GetType(),"m_build").GetValue(info);climb=native.agentClimb;slope=native.agentSlope;}
    surface=new CenserNavSurface(height,radius,climb,slope,origin);next=0;}
   if(surface.Building)return;if(surface.Complete())global::Otherworld.Distribution.AbbeyNavigationWork.Trace("CB2_NAV_READY sources="+Sources+" revision="+Revision);
   if(Time.time<next)return;next=Time.time+Refresh;var c=Snap(transform.position);var bounds=new Bounds(c,Vector3.one*Span);var sources=new List<NavMeshBuildSource>();NavMeshBuilder.CollectSources(bounds,LayerMask.GetMask("terrain","static_solid","piece"),NavMeshCollectGeometry.PhysicsColliders,0,new List<NavMeshBuildMarkup>(),sources);sources.RemoveAll(s=>s.component is Collider col&&(!col.enabled||col.isTrigger||!col.gameObject.activeInHierarchy));
   if(sources.Count==0||sources.Count>4096)throw new InvalidOperationException("Missing/bounded world collision sources");sources.Sort((a,b)=>(a.component?a.component.GetInstanceID():0).CompareTo(b.component?b.component.GetInstanceID():0));ulong hash=1469598103934665603;
   unchecked{foreach(var s in sources){hash=(hash^(uint)(s.component?s.component.GetInstanceID():0))*1099511628211;hash=(hash^(uint)(s.sourceObject?s.sourceObject.GetInstanceID():0))*1099511628211;hash=(hash^(uint)s.size.GetHashCode())*1099511628211;hash=(hash^(uint)s.shape)*1099511628211;for(int i=0;i<16;i++)hash=(hash^(uint)s.transform[i].GetHashCode())*1099511628211;}}
   if(Ready&&signature==hash&&center==c)return;Sources=sources.Count;signature=hash;center=c;surface.Build(sources,bounds);Failure=null;
  }catch(Exception e){Failure=e.GetBaseException().Message;CenserPlugin.Trace("CB2_NAV_FAILED "+Failure);Release();next=Time.time+3;}}
  static Vector3 Snap(Vector3 p)=>new Vector3(Mathf.Round(p.x/10)*10,Mathf.Round(p.y/10)*10,Mathf.Round(p.z/10)*10);
  public bool TryProbePath(Vector3 a,Vector3 b,out List<Vector3> corners){Queries++;corners=new List<Vector3>();bool ok=global::Otherworld.Distribution.AbbeyNavigationWork.MayUpdate(global::Otherworld.Distribution.AbbeyNavigationWork.InDungeon(transform.position.y))&&surface!=null&&surface.Route(a,b,corners);if(!ok)Failures++;return ok;}
  public bool Straight(Vector3 a,Vector3 b)=>global::Otherworld.Distribution.AbbeyNavigationWork.MayUpdate(global::Otherworld.Distribution.AbbeyNavigationWork.InDungeon(transform.position.y))&&surface!=null&&surface.Straight(a,b);
  public string Status()=>"navReady="+Ready+" navBuilding="+(surface?.Building??false)+" navRevision="+Revision+" sources="+Sources+" queries="+Queries+" failed="+Failures+" navError="+Failure;
  void Release(){surface?.Dispose();surface=null;}void OnDisable()=>Release();void OnDestroy(){Release();Active.Remove(this);}public static void Shutdown(){foreach(var n in Active.ToArray())if(n)n.Release();}
 }
}
