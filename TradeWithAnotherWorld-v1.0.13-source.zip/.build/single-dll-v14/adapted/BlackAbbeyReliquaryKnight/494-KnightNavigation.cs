using System;
using System.Collections.Generic;
using System.Reflection;
using Otherworld.Navigation.BlackAbbeyReliquaryKnight;
using HarmonyLib;
using UnityEngine;
using UnityEngine.AI;

namespace BlackAbbey.ReliquaryKnight
{
    // Actor-scoped adapter. High-altitude rooms lease the existing bounded
    // regional cache; ordinary terrain retains the installed BaseAI path cache.
    // This component never moves, rotates, teleports or chooses targets.
    public sealed class KnightNavigation : MonoBehaviour
    {
        public const float DungeonAltitude = 7000f;
        public static Action<string> Log;
        static readonly HashSet<KnightNavigation> Active = new HashSet<KnightNavigation>();
        static readonly MethodInfo NativeFind = AccessTools.Method(typeof(BaseAI), "FindPath", new[] { typeof(Vector3) });
        static readonly FieldInfo NativePath = AccessTools.Field(typeof(BaseAI), "m_path");
        static readonly MethodInfo NativeSettings = AccessTools.Method(typeof(Pathfinding), "GetSettings");
        static readonly FieldInfo LastFind = AccessTools.Field(typeof(BaseAI), "m_lastFindPathTime");
        BaseAI ai; Character character; ZNetView view; CapsuleCollider capsule;
        RegionalNavigationCache.Lease region;
        NavMeshBuildSettings profile;
        readonly NavMeshPath meshPath = new NavMeshPath();
        readonly NavMeshPath localMeshPath = new NavMeshPath();
        readonly List<Vector3> corners = new List<Vector3>();
        readonly List<Vector3> localCorners = new List<Vector3>();
        Vector3 requested;
        Vector3 localRequested;
        float localNextQuery;
        int localCorner;
        bool localPathValid;
        float nextQuery, retryAt;
        int revision = -1, corner;
        bool configured, pathValid;
        string failure;

        bool Owner => ai && character && !character.IsDead() && view && view.IsValid() && view.IsOwner() && GetComponent<KnightActor>();
        bool Dungeon => transform.position.y > DungeonAltitude;
        public bool Ready => Owner && global::Otherworld.Distribution.AbbeyNavigationWork.MayUpdate(Dungeon) && (Dungeon ? region != null && region.Valid && region.Ready && region.Matches(transform.position) : Pathfinding.instance && NativeFind != null && NativePath != null);

        public static KnightNavigation Attach(GameObject actor)
        {
            if (!actor || !actor.GetComponent<KnightActor>()) return null;
            var existing = actor.GetComponent<KnightNavigation>(); if (existing) return existing;
            var result = actor.AddComponent<KnightNavigation>();
            result.ai = actor.GetComponent<BaseAI>(); result.character = actor.GetComponent<Character>();
            result.view = actor.GetComponent<ZNetView>(); result.capsule = actor.GetComponent<CapsuleCollider>();
            Active.Add(result); return result;
        }

        void Update()
        {
            if (!Owner) { Release(); return; }
            if (!Dungeon) { if(region!=null)Release(); return; }
            if (!global::Otherworld.Distribution.AbbeyNavigationWork.MayUpdate(true)) return;
            if (Time.realtimeSinceStartup < retryAt) return;
            try
            {
                if (!configured) Configure();
                if (region == null || !region.Valid || !region.Matches(transform.position)) Acquire();
                RegionalNavigationCache.Tick();
                if (region.Ready && revision != region.Revision)
                {
                    revision = region.Revision; pathValid = false; nextQuery = 0;
                    // Invalidate only this actor's cached native failure.
                    LastFind?.SetValue(ai, Time.time - 6f);
                    global::Otherworld.Distribution.AbbeyNavigationWork.Trace("RK_NAV_REGION_READY revision=" + revision + " sources=" + region.SourceCount + " agent=" + region.Settings.agentTypeID);
                }
            }
            catch (Exception e)
            {
                failure = e.GetBaseException().Message; Release(); retryAt = Time.realtimeSinceStartup + 5f;
                Log?.Invoke("RK_NAV_WAIT " + failure);
            }
        }

        void Configure()
        {
            if (!capsule || !Pathfinding.instance || NativeSettings == null) throw new InvalidOperationException("Native pathfinder, settings or own capsule unavailable.");
            var agent = NativeSettings.Invoke(Pathfinding.instance, new object[] { ai.m_pathAgentType });
            if (agent == null) throw new InvalidOperationException("Native agent profile unavailable.");
            var build = AccessTools.Field(agent.GetType(), "m_build");
            if (build == null) throw new InvalidOperationException("Native agent build profile unavailable.");
            profile = (NavMeshBuildSettings)build.GetValue(agent);
            float height = capsule.bounds.size.y, radius = Mathf.Max(capsule.bounds.extents.x, capsule.bounds.extents.z);
            if (!Finite(height) || !Finite(radius) || height < .2f || height > 5f || radius < .05f || radius > 2f)
                throw new InvalidOperationException("Own world capsule dimensions outside admitted profile.");
            profile.agentHeight = height + .025f; profile.agentRadius = radius + .025f;
            profile.overrideVoxelSize = true; profile.voxelSize = .08f;
            profile.overrideTileSize = true; profile.tileSize = 128;
            configured = true;
        }

        void Acquire()
        {
            region?.Dispose(); region = null; revision = -1; corners.Clear(); pathValid = false; nextQuery = 0;
            int layer = LayerMask.NameToLayer("static_solid");
            if (layer < 0 || (Pathfinding.instance.m_layers.value & (1 << layer)) == 0)
                throw new InvalidOperationException("Authored static_solid room geometry is unavailable in native layer contract.");
            region = RegionalNavigationCache.Acquire(profile, transform.position, 1 << layer, Log, "RK");
            if (region == null || !region.Valid) throw new InvalidOperationException("Bounded regional navigation cache has no available lease.");
        }

        public bool PathTo(Vector3 destination, out Vector3 direction)
        {
            direction = Vector3.zero;
            if (!Ready || !Finite(destination)) { pathValid = false; return false; }
            Vector3 from = transform.position;
            if (Mathf.Abs(destination.y - from.y) > 2f) return false;
            try
            {
                if (Time.time >= nextQuery || Vector3.SqrMagnitude(destination - requested) > .25f)
                {
                    nextQuery = Time.time + .25f; requested = destination; corners.Clear(); corner = 0;
                    pathValid = Dungeon ? DungeonPath(from, destination) : NativeRoute(destination);
                }
                if (!pathValid) return false;
                while (corner < corners.Count && Vector3.ProjectOnPlane(corners[corner] - from, Vector3.up).sqrMagnitude < .09f) corner++;
                if (corner >= corners.Count)
                {
                    // A complete path whose endpoint has already been reached.
                    return Vector3.ProjectOnPlane(destination - from, Vector3.up).sqrMagnitude < .16f;
                }
                direction = Vector3.ProjectOnPlane(corners[corner] - from, Vector3.up).normalized;
                return direction.sqrMagnitude > .5f;
            }
            catch (Exception e)
            {
                failure = e.GetBaseException().Message; corners.Clear(); pathValid = false;
                return false;
            }
        }

        bool NativeRoute(Vector3 destination)
        {
            if (!(bool)NativeFind.Invoke(ai, new object[] { destination })) return false;
            var native = NativePath.GetValue(ai) as List<Vector3>;
            if (native == null || native.Count == 0) return false;
            foreach (var point in native) { if (!Finite(point)) return false; corners.Add(point); }
            return true;
        }

        bool DungeonPath(Vector3 from, Vector3 destination)
        {
            if (!region.WorldBounds.Contains(from) || !region.WorldBounds.Contains(destination)) return false;
            var filter = new NavMeshQueryFilter { agentTypeID = region.Settings.agentTypeID, areaMask = 1 };
            if (!NavMesh.SamplePosition(from, out var start, 1.25f, filter) || !NavMesh.SamplePosition(destination, out var end, 1.25f, filter)
                || Mathf.Abs(start.position.y - from.y) > .8f || Mathf.Abs(end.position.y - destination.y) > .8f) return false;
            if (!NavMesh.CalculatePath(start.position, end.position, filter, meshPath) || meshPath.status != NavMeshPathStatus.PathComplete) return false;
            corners.AddRange(meshPath.corners);
            return corners.Count > 0;
        }

        // Source lateral/retreat goals retain target facing, but must follow a
        // supported, nearby route rather than blindly reusing a local delta.
        // This query owns separate cache/path storage and never replaces the
        // native AI search path or the long-distance source approach route.
        public bool LocalDirection(Vector3 destination, Vector3 desired, out Vector3 direction, out float firstLeg)
        {
            direction = Vector3.zero;firstLeg=0;
            if (!Ready || !Finite(destination) || !Finite(desired) || desired.sqrMagnitude < .5f) return false;
            try
            {
                if (!configured) Configure();
                Vector3 from = transform.position;
                var filter = new NavMeshQueryFilter { agentTypeID = Dungeon ? region.Settings.agentTypeID : profile.agentTypeID,
                    areaMask = Dungeon ? 1 : NavMesh.AllAreas };
                if (Time.time >= localNextQuery || (destination-localRequested).sqrMagnitude > .1225f)
                {
                    localNextQuery=Time.time+.15f; localRequested=destination; localCorners.Clear(); localCorner=0; localPathValid=false;
                    if (Dungeon && (!region.WorldBounds.Contains(from) || !region.WorldBounds.Contains(destination))) return false;
                    float tolerance = Mathf.Max(.2f, capsule.bounds.extents.x*.65f);
                    if (!NavMesh.SamplePosition(from,out var start,tolerance,filter)
                        || !NavMesh.SamplePosition(destination,out var end,tolerance,filter)
                        || Mathf.Abs(start.position.y-from.y)>.55f || Mathf.Abs(end.position.y-destination.y)>.55f) return false;
                    if (!NavMesh.CalculatePath(start.position,end.position,filter,localMeshPath)
                        || localMeshPath.status!=NavMeshPathStatus.PathComplete) return false;
                    localCorners.AddRange(localMeshPath.corners); localPathValid=localCorners.Count>0;
                }
                if (!localPathValid) return false;
                while(localCorner<localCorners.Count && Vector3.ProjectOnPlane(localCorners[localCorner]-transform.position,Vector3.up).sqrMagnitude<.04f) localCorner++;
                if(localCorner>=localCorners.Count){localNextQuery=0;return false;}
                Vector3 to=Vector3.ProjectOnPlane(localCorners[localCorner]-transform.position,Vector3.up);
                firstLeg=to.magnitude;direction=to.normalized;
                // A local strafe/backstep may go around a nearby edge, but
                // never becomes an opposite-direction run away from combat.
                return direction.sqrMagnitude>.5f && KnightMovementGoalPolicy.RouteCompatible(Vector3.Dot(direction,desired.normalized));
            }
            catch(Exception e) { failure=e.GetBaseException().Message; localPathValid=false; return false; }
        }

        static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        static bool Finite(Vector3 value) => Finite(value.x) && Finite(value.y) && Finite(value.z);
        void Release()
        {
            region?.Dispose(); region = null; configured = false; revision = -1;
            corners.Clear(); pathValid = false; nextQuery = 0;
            localCorners.Clear(); localPathValid=false; localNextQuery=0;
        }
        void OnDisable() { Release(); }
        void OnDestroy() { Release(); Active.Remove(this); }
        public string Diagnostics() => "ready=" + Ready + " dungeon=" + Dungeon + " revision=" + revision + " corners=" + corners.Count + " failure=" + (failure ?? "none");
        public static void Shutdown()
        {
            foreach (var item in Active) if (item) item.Release();
            RegionalNavigationCache.Shutdown();
        }
    }
}
